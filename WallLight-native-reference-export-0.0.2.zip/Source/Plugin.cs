using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using Assets.Scripts;
using Assets.Scripts.Objects.Structures;
using StationeersMods.Interface;
using UnityEngine;
using UnityEngine.Rendering;
namespace WallLightReference {
 [StationeersMod("kreezy.walllightreference","Wall Light Reference Export","0.0.2")]
 public sealed class Plugin:ModBehaviour {
  bool done;float next;
  public override void OnLoaded(ContentHandler content){base.OnLoaded(content);if(Application.isBatchMode)enabled=false;}
  void Update(){if(done||Time.realtimeSinceStartup<next)return;next=Time.realtimeSinceStartup+3;
   var world=UnityEngine.Object.FindObjectOfType<WorldManager>();if(world==null||world.SourcePrefabs==null)return;
   var lamps=world.SourcePrefabs.OfType<WallLight>().ToArray();if(lamps.Length==0)return;done=true;
   try{var asm=AppDomain.CurrentDomain.GetAssemblies().First(a=>a.GetName().Name=="ModularSwitchboards");var read=asm.GetType("ModularSwitchboards.CabinetGeometry").GetMethod("ReadNativeMesh",BindingFlags.NonPublic|BindingFlags.Static);
    string folder=Path.Combine(Application.persistentDataPath,"ModularSwitchboards-WallLight-reference-0.0.2");Directory.CreateDirectory(folder);
    var textures=new Dictionary<int,Texture>();var slices=new HashSet<int>{0,1,2};
    foreach(var lamp in lamps){var report=new Report{prefab=lamp.PrefabName,fields=Fields(lamp),bounds=lamp.Bounds};
     foreach(var c in lamp.GetComponentsInChildren<Component>(true))if(c!=null)report.components.Add(new ComponentInfo{path=PathOf(c.transform,lamp.transform),type=c.GetType().FullName,localPosition=c.transform.localPosition,localRotation=c.transform.localRotation,localScale=c.transform.localScale,fields=Fields(c)});
     foreach(var mf in lamp.GetComponentsInChildren<MeshFilter>(true)){if(mf.sharedMesh==null)continue;var part=new Part{path=PathOf(mf.transform,lamp.transform),name=mf.sharedMesh.name,matrix=lamp.transform.worldToLocalMatrix*mf.transform.localToWorldMatrix};
      try{object[] args={mf.sharedMesh,null,null,null};read.Invoke(null,args);part.vertices=(Vector3[])args[1];part.uv=(Vector2[])args[2];foreach(var ids in (int[][])args[3])part.triangles.Add(new Indices{values=ids});}catch(Exception e){part.error=e.ToString();}
      var renderer=mf.GetComponent<Renderer>();if(renderer!=null)foreach(var m in renderer.sharedMaterials){var mat=new MaterialInfo();if(m!=null){mat.name=m.name;mat.shader=m.shader==null?null:m.shader.name;if(m.shader!=null)for(int i=0;i<m.shader.GetPropertyCount();i++){string n=m.shader.GetPropertyName(i);var t=m.shader.GetPropertyType(i);string v;switch(t){case UnityEngine.Rendering.ShaderPropertyType.Color:v=m.GetColor(n).ToString("R");break;case UnityEngine.Rendering.ShaderPropertyType.Vector:v=m.GetVector(n).ToString("R");break;case UnityEngine.Rendering.ShaderPropertyType.Texture:var tex=m.GetTexture(n);v=tex==null?"null":tex.name+" "+tex.width+"x"+tex.height;break;default:v=m.GetFloat(n).ToString(System.Globalization.CultureInfo.InvariantCulture);break;}mat.properties.Add(new Field{name=n,value=v});}}if(m!=null){var block=new MaterialPropertyBlock();renderer.GetPropertyBlock(block,part.materials.Count);mat.nativeProperties=Properties(m,block,textures,slices);}
part.materials.Add(mat);}report.parts.Add(part);}
     foreach(var l in lamp.GetComponentsInChildren<Light>(true))report.lights.Add(new LightInfo{path=PathOf(l.transform,lamp.transform),position=lamp.transform.InverseTransformPoint(l.transform.position),rotation=Quaternion.Inverse(lamp.transform.rotation)*l.transform.rotation,type=l.type.ToString(),color=l.color,intensity=l.intensity,range=l.range,spotAngle=l.spotAngle,shadows=l.shadows.ToString(),cullingMask=l.cullingMask});
     File.WriteAllText(Path.Combine(folder,lamp.PrefabName+".json"),DiagnosticJson.Serialize(report));}
    var textureManifest=new TextureReport();foreach(var texture in textures.Values){if(texture is Texture2DArray array){foreach(int slice in slices.Where(i=>i>=0&&i<array.depth))textureManifest.textures.Add(ExportTexture(texture,slice,folder));}else textureManifest.textures.Add(ExportTexture(texture,0,folder));}
    File.WriteAllText(Path.Combine(folder,"Textures.json"),DiagnosticJson.Serialize(textureManifest));
    string zip=folder+".zip";if(File.Exists(zip))File.Delete(zip);System.IO.Compression.ZipFile.CreateFromDirectory(folder,zip);
    Debug.Log("[Wall Light Reference] SEND THIS ZIP: "+zip+"; prefabs="+lamps.Length+"; texture errors="+textureManifest.textures.Count(t=>t.error!=null));
   }catch(Exception e){Debug.LogError("[Wall Light Reference] "+e);}}
  static string PathOf(Transform t,Transform root){if(t==root)return ".";return t.parent==null?t.name:PathOf(t.parent,root)+"/"+t.name;}
  static List<Field> Fields(object obj){var list=new List<Field>();for(var type=obj.GetType();type!=null&&type!=typeof(UnityEngine.Object);type=type.BaseType)foreach(var f in type.GetFields(BindingFlags.Instance|BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.DeclaredOnly)){if(f.IsStatic||f.IsNotSerialized)continue;try{var v=f.GetValue(obj);if(v==null)continue;if(v is UnityEngine.Object u){list.Add(new Field{name=type.Name+"."+f.Name,value=u.name+" ("+u.GetType().Name+")"});continue;}if(f.FieldType.IsPrimitive||f.FieldType.IsEnum||v is string||v is Vector3||v is Vector2||v is Color||v is Bounds||v is Quaternion)list.Add(new Field{name=type.Name+"."+f.Name,value=Convert.ToString(v,System.Globalization.CultureInfo.InvariantCulture)});}catch{}}return list;}
        [Serializable] public sealed class Property
        {
            public string name,type,texture,blockTexture;public int textureId,blockTextureId;public bool blockHasProperty;
            public float value,blockFloat;public Color color,blockColor;public Vector4 vector,blockVector;public Vector2 scale,offset;
        }
        [Serializable] public sealed class TextureData
        {
            public int id,width,height,slice;public string name,dimension,format,file,error;
        }
        private static void AddSlice(HashSet<int> slices,float value){if(!float.IsNaN(value)&&!float.IsInfinity(value)&&value>=0&&value<2048&&Math.Abs(value-Math.Round(value))<.001f)slices.Add((int)Math.Round(value));}
        private static List<Property> Properties(Material material,MaterialPropertyBlock block,Dictionary<int,Texture> textures,HashSet<int> slices)
        {
            var result=new List<Property>();var shader=material.shader;
            for(int i=0;i<shader.GetPropertyCount();i++)
            {
                string name=shader.GetPropertyName(i);int id=Shader.PropertyToID(name);var type=shader.GetPropertyType(i);var p=new Property{name=name,type=type.ToString(),blockHasProperty=block.HasProperty(id)};result.Add(p);
                if(type==ShaderPropertyType.Texture)
                {
                    var texture=material.GetTexture(id);var overridden=block.GetTexture(id);p.texture=texture?.name;p.blockTexture=overridden?.name;p.textureId=texture==null?0:texture.GetInstanceID();p.blockTextureId=overridden==null?0:overridden.GetInstanceID();p.scale=material.GetTextureScale(name);p.offset=material.GetTextureOffset(name);
                    if(texture!=null)textures[texture.GetInstanceID()]=texture;if(overridden!=null)textures[overridden.GetInstanceID()]=overridden;
                }
                else if(type==ShaderPropertyType.Color){p.color=material.GetColor(id);if(p.blockHasProperty)p.blockColor=block.GetColor(id);}
                else if(type==ShaderPropertyType.Vector){p.vector=material.GetVector(id);if(p.blockHasProperty)p.blockVector=block.GetVector(id);}
                else if(type==ShaderPropertyType.Float||type==ShaderPropertyType.Range){p.value=material.GetFloat(id);if(p.blockHasProperty)p.blockFloat=block.GetFloat(id);if(name.IndexOf("Index",StringComparison.OrdinalIgnoreCase)>=0){AddSlice(slices,p.value);if(p.blockHasProperty)AddSlice(slices,p.blockFloat);}}
            }
            return result;
        }
        private static TextureData ExportTexture(Texture texture,int slice,string directory)
        {
            var info=new TextureData{id=texture.GetInstanceID(),name=texture.name,width=texture.width,height=texture.height,slice=slice,dimension=texture.dimension.ToString(),format=texture.graphicsFormat.ToString()};Texture2D readable=null;
            try
            {
                if(!(texture is Texture2D)&&!(texture is Texture2DArray))throw new InvalidOperationException("Unsupported texture dimension");
                if(texture.width<=0||texture.height<=0||texture.width>8192||texture.height>8192)throw new InvalidOperationException("Texture size exceeds readback bound");
                if(!SystemInfo.supportsAsyncGPUReadback)throw new InvalidOperationException("GPU texture readback unsupported on this renderer");
                var read=AsyncGPUReadback.Request(texture,0,0,texture.width,0,texture.height,slice,1,TextureFormat.RGBA32);read.WaitForCompletion();if(read.hasError)throw new InvalidOperationException("GPU readback failed");
                var pixels=read.GetData<byte>().ToArray();readable=new Texture2D(texture.width,texture.height,TextureFormat.RGBA32,false);readable.LoadRawTextureData(pixels);readable.Apply();
                string file="texture-"+texture.GetInstanceID()+"-slice-"+slice+".png";File.WriteAllBytes(Path.Combine(directory,file),readable.EncodeToPNG());info.file=file;
            }
            catch(Exception ex){info.error=ex.Message;}
            finally{if(readable!=null)UnityEngine.Object.Destroy(readable);}
            return info;
        }

[Serializable]public class TextureReport{public List<TextureData> textures=new List<TextureData>();}
  [Serializable]public class Field{public string name,value;}
  [Serializable]public class ComponentInfo{public string path,type;public Vector3 localPosition,localScale;public Quaternion localRotation;public List<Field> fields;}
  [Serializable]public class Indices{public int[] values;}
  [Serializable]public class MaterialInfo{public string name,shader;public List<Property> nativeProperties;public List<Field> properties=new List<Field>();}
  [Serializable]public class Part{public string path,name,error;public Matrix4x4 matrix;public Vector3[] vertices;public Vector2[] uv;public List<Indices> triangles=new List<Indices>();public List<MaterialInfo> materials=new List<MaterialInfo>();}
  [Serializable]public class LightInfo{public string path,type,shadows;public Vector3 position;public Quaternion rotation;public Color color;public float intensity,range,spotAngle;public int cullingMask;}
  [Serializable]public class Report{public string prefab;public Bounds bounds;public List<Field> fields;public List<Part> parts=new List<Part>();public List<ComponentInfo> components=new List<ComponentInfo>();public List<LightInfo> lights=new List<LightInfo>();}
 }
}
