using System;
using Assets.Scripts.Networking;
using LaunchPadBooster;
using LaunchPadBooster.Networking;
namespace CustomSpeakerSounds
{
 [HarmonyLib.HarmonyPatch(typeof(NetworkManager),"EndConnection")]
 internal static class SoundCatalogDisconnect {static void Prefix(){SoundCatalogHandshake.Clear();}}
 internal sealed class SoundCatalogHandshake:IJoinPrefixSerializer
 {
  internal static readonly object Gate=new object();
  internal static SoundEntry[] Local=Array.Empty<SoundEntry>(),Pending;
  internal static long Revision;
  internal static int ResetRequested;
  internal static void Configure(string soundDirectory){Local=ServerSoundCatalog.Scan(soundDirectory);var mod=new Mod("CustomSpeakerSounds","0.2.0");mod.Networking.Required=false;mod.Networking.JoinPrefixSerializer=new SoundCatalogHandshake();}
  public void SerializeJoinPrefix(RocketBinaryWriter writer){writer.WriteString(ServerSoundCatalog.Encode(Local));}
  public void DeserializeJoinPrefix(RocketBinaryReader reader){var entries=ServerSoundCatalog.Decode(reader.ReadString());lock(Gate){Pending=entries;Revision++;}}
  internal static void Clear(){lock(Gate){Pending=null;Revision++;}System.Threading.Interlocked.Exchange(ref ResetRequested,1);}
 }
}
