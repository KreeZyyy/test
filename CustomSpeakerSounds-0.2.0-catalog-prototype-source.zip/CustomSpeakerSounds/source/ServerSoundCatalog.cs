using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
namespace CustomSpeakerSounds
{
 public sealed class SoundEntry {public int Id;public string Name,Extension,Sha256;public long Bytes;}
 public static class ServerSoundCatalog
 {
  public const long MaxFile=32L*1024*1024,MaxTotal=128L*1024*1024;
  public static SoundEntry[] Scan(string folder)
  {
   Directory.CreateDirectory(folder);var result=new List<SoundEntry>();long total=0;
   foreach(var file in Directory.GetFiles(folder).OrderBy(f=>f,StringComparer.Ordinal)){
    var ext=Path.GetExtension(file).ToLowerInvariant();if(ext!=".wav"&&ext!=".ogg"&&ext!=".mp3")continue;
    var name=Path.GetFileNameWithoutExtension(file);var number=name.Split('_')[0];
    if(!int.TryParse(number,out int id)||id<100||id>199||result.Any(e=>e.Id==id))continue;
    var info=new FileInfo(file);if(info.Length<=0||info.Length>MaxFile||total+info.Length>MaxTotal)continue;
    string label=name.Substring(number.Length).TrimStart('_');if(string.IsNullOrWhiteSpace(label))label=name;label=new string(label.Select(c=>char.IsControl(c)?' ':c).ToArray());if(label.Length>96)label=label.Substring(0,96);
    string hash;using(var stream=File.OpenRead(file))using(var sha=SHA256.Create())hash=Hex(sha.ComputeHash(stream));
    result.Add(new SoundEntry{Id=id,Name=label,Extension=ext,Sha256=hash,Bytes=info.Length});total+=info.Length;
   }return result.ToArray();
  }
  public static string Encode(SoundEntry[] entries){Validate(entries);using(var stream=new MemoryStream()){using(var w=new BinaryWriter(stream,Encoding.UTF8,true)){w.Write(1);w.Write(entries.Length);foreach(var e in entries){w.Write(e.Id);w.Write(e.Name);w.Write(e.Extension);w.Write(e.Sha256);w.Write(e.Bytes);}}return Convert.ToBase64String(stream.ToArray());}}
  public static SoundEntry[] Decode(string payload){if(payload==null||payload.Length>65536)throw new InvalidDataException("Sound manifest too large.");byte[] data=Convert.FromBase64String(payload);using(var s=new MemoryStream(data))using(var r=new BinaryReader(s,Encoding.UTF8)){if(r.ReadInt32()!=1)throw new InvalidDataException("Sound protocol version mismatch.");int count=r.ReadInt32();if(count<0||count>100)throw new InvalidDataException("Sound count invalid.");var result=new SoundEntry[count];for(int i=0;i<count;i++)result[i]=new SoundEntry{Id=r.ReadInt32(),Name=r.ReadString(),Extension=r.ReadString(),Sha256=r.ReadString(),Bytes=r.ReadInt64()};if(s.Position!=s.Length)throw new InvalidDataException("Trailing manifest data.");Validate(result);return result;}}
  public static void Validate(SoundEntry[] entries){if(entries==null||entries.Length>100)throw new InvalidDataException("Sound count invalid.");var ids=new HashSet<int>();long total=0;foreach(var e in entries){if(e==null||e.Id<100||e.Id>199||!ids.Add(e.Id)||string.IsNullOrWhiteSpace(e.Name)||e.Name.Length>96||e.Name.Any(char.IsControl)||(e.Extension!=".wav"&&e.Extension!=".ogg"&&e.Extension!=".mp3")||e.Sha256==null||e.Sha256.Length!=64||e.Sha256.Any(c=>!(c>='0'&&c<='9'||c>='a'&&c<='f'))||e.Bytes<=0||e.Bytes>MaxFile)throw new InvalidDataException("Invalid server sound entry.");total+=e.Bytes;if(total>MaxTotal)throw new InvalidDataException("Sound manifest total too large.");}}
  public static string CachePath(string cache,SoundEntry e){Validate(new[]{e});return Path.Combine(cache,e.Sha256+e.Extension);}
  public static bool Cached(string cache,SoundEntry e){var path=CachePath(cache,e);var file=new FileInfo(path);if(!file.Exists||file.Length!=e.Bytes)return false;using(var s=File.OpenRead(path))using(var sha=SHA256.Create())return Hex(sha.ComputeHash(s))==e.Sha256;}
  static string Hex(byte[] b)=>BitConverter.ToString(b).Replace("-","").ToLowerInvariant();
 }
}
