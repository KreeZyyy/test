using System.Collections.Generic;using System.Linq;using ModularSwitchboards;
sealed class LampCleanupFixture{
 internal sealed class Item{internal long ReferenceId;}
 internal List<Item> Breakers=new(),Lamps=new(),Transformers=new(),StationBatteries=new(),Contactors=new();
 internal List<long> DisplayIds=new(),DialIds=new(),SmartIds=new();
 internal int Apply(List<CabinetWireSaveData> wires){var live=new HashSet<long>(Breakers.Select(m=>m.ReferenceId).Concat(Lamps.Select(l=>l.ReferenceId)).Concat(DisplayIds).Concat(DialIds).Concat(Transformers.Select(t=>t.ReferenceId)).Concat(StationBatteries.Select(t=>t.ReferenceId)).Concat(SmartIds).Concat(Contactors.Select(c=>c.ReferenceId)));int removed=wires.RemoveAll(w=>(w.From.Owner!=0&&!live.Contains(w.From.Owner))||(w.To.Owner!=0&&!live.Contains(w.To.Owner)));return removed;}}
