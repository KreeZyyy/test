using System;using System.IO;using System.Linq;using System.Collections.Generic;using System.Xml.Serialization;using ModularSwitchboards;
static class CabinetLampSaveHarness
{
 internal static void Run()
 {
  int checks=0;const long lampId=80000000001;
  foreach(var kind in new[]{CabinetWireKind.Normal,CabinetWireKind.Heavy,CabinetWireKind.SuperHeavy})foreach(long source in new long[]{0,10})
  {
   var wire=new CabinetWireSaveData{From=new CabinetWireEnd(source,source==0?0:1),To=new CabinetWireEnd(lampId,0),CableKind=kind,CableUnits=1,InputSlot=0,RouteVersion=9,ColorIndex=3,Points=new[]{0f,.03f,.06535f,.12f,.195f,.0244f}};
   var serializer=new XmlSerializer(typeof(CabinetWireSaveData[]));using var text=new StringWriter();serializer.Serialize(text,new[]{wire});using var reader=new StringReader(text.ToString());var restored=(CabinetWireSaveData[])serializer.Deserialize(reader);
   var fixture=new LampCleanupFixture();fixture.Breakers.Add(new(){ReferenceId=10});fixture.Lamps.Add(new(){ReferenceId=lampId});var wires=restored.ToList();
   if(fixture.Apply(wires)!=0||wires.Count!=1)throw new Exception("production deferred cleanup discarded restored lamp wire");checks++;
   if(wires[0].To.Owner!=lampId||wires[0].CableKind!=kind||wires[0].CableUnits!=1||!wires[0].Points.SequenceEqual(wire.Points))throw new Exception("lamp save payload changed");checks++;
   SerdeHarness.AssertRoundTrip(wire);checks++;
   // Really missing/deconstructed lamp must still be cleaned up.
   fixture.Lamps.Clear();if(fixture.Apply(wires)!=1||wires.Count!=0)throw new Exception("missing lamp wire retained forever");checks++;
  }
  Console.WriteLine(checks+" production cleanup/save/join lamp checks passed (all cable types, input or module source, 64-bit lamp ID)");
 }
}
