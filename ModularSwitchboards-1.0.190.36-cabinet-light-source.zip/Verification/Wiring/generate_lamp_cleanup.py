from pathlib import Path
r=Path(__file__).resolve().parents[2];source=(r/'Source/CabinetWiring.cs').read_text()
a=source.index('var live=new HashSet<long>(');b=source.index(';',a)+1;live=source[a:b]
a=source.index('int removed=wires.RemoveAll(',b);b=source.index(';',a)+1;remove=source[a:b]
text='''using System.Collections.Generic;using System.Linq;using ModularSwitchboards;
sealed class LampCleanupFixture{
 internal sealed class Item{internal long ReferenceId;}
 internal List<Item> Breakers=new(),Lamps=new(),Transformers=new(),StationBatteries=new(),Contactors=new();
 internal List<long> DisplayIds=new(),DialIds=new(),SmartIds=new();
 internal int Apply(List<CabinetWireSaveData> wires){'''+live+remove+'''return removed;}}
'''
(r/'Verification/Wiring/GeneratedLampCleanup.cs').write_text(text)
