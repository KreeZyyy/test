using System;using System.Linq;using ModularSwitchboards;
partial class RouteHarness
{
 internal static void RunDoorContactRoutes()
 {
  int checks=0;
  foreach(bool medium in new[]{false,true})foreach(int side in new[]{-1,1})foreach(int pin in new[]{0,1})foreach(var kind in new[]{CabinetWireKind.Normal,CabinetWireKind.Heavy,CabinetWireKind.SuperHeavy})
  {
   if(!medium&&side==1)continue;
   var h=new RouteHarness{Owner=new(){PrefabName=medium?"medium":"small"},routingHalfWidth=medium?.366f:.168f,routingHalfHeight=medium?.477f:.228f};
   h.moduleReservations=WireModuleSpace.Reservations(medium?.65f:.35f,medium?new[]{-.27f,0,.27f}:new[]{-.108f,.108f}).ToArray();
   var source=new CabinetWireEnd(10,1);var target=new CabinetWireEnd(90,0);h.PowerModules.Add(10);
   h.contacts[source]=new Contact{End=source,Position=new(0,medium?.219375f:.057375f,.043f),Exit=new(0,medium?.204f:.042f,WireRouting.Plane),Bounds=new(-.0198f,.0198f,medium?.219375f:.057375f,medium?.320625f:.158625f)};
   float center=side*(medium?.357f:.177f),x=center-side*.009f,y=-side*DoorContactLayout.ContactY(pin);
   var entry=new WirePoint(x,y,.0244f);var exit=new WirePoint(center-side*.030f,y,WireRouting.Plane);
   var bounds=new WireRect(x-(side==1?.009f:.018f),x+(side==1?.018f:.009f),y-.011f,y+.011f);
   h.contacts[target]=new Contact{End=target,Position=new(x,y,.0244f),Exit=new(exit.X,exit.Y,exit.Z),Bounds=bounds,LeadSide=-side};
   var other=new CabinetWireEnd(90,1);float oy=-side*DoorContactLayout.ContactY(1-pin);
   h.contacts[other]=new Contact{End=other,Position=new(x,oy,.0244f),Exit=new(exit.X,oy,exit.Z),Bounds=new WireRect(bounds.Left,bounds.Right,oy-.011f,oy+.011f),LeadSide=-side};
   if(bounds.Contains(exit,.004f))throw new Exception("sensor terminal exit is inside its own body");checks++;
   float blockedX=x-side*.016f;
   h.wires.Add(new CabinetWireSaveData{From=new(501,1),To=new(502,0),Points=new[]{blockedX,y-.010f,.0244f,blockedX,y+.010f,.0244f}});
   h.contacts[target].LeadSide=0;h.contacts[other].LeadSide=0;
   if(h.MakeRoute(source,target,out _,out _,kind)!=null)throw new Exception("legacy vertical contact lead did not reproduce wire obstruction");checks++;
   h.contacts[target].LeadSide=-side;h.contacts[other].LeadSide=-side;
   var path=h.MakeRoute(source,target,out _,out var failure,kind);if(path==null)throw new Exception("sensor route "+medium+" side"+side+" pin"+pin+" "+kind+": "+failure);checks++;
   if((path[path.Length-1]-entry).Squared>1e-10f)throw new Exception("sensor route misses terminal");checks++;
   var lamp=new CabinetWireEnd(80,0);float lx=medium?.300f:.140f,ly=medium?.425f:.195f;
   var lp=new WirePoint(lx-.009f,ly,.0244f);var le=CabinetLampWiringGeometry.Exit(lp);
   h.contacts[lamp]=new Contact{End=lamp,Position=new(lp.X,lp.Y,lp.Z),Exit=new(le.X,le.Y,le.Z),Bounds=CabinetLampWiringGeometry.PlateBounds(new WirePoint(lx,ly,.013f))};
   h.Breakers=new[]{new DinBreaker{ReferenceId=90,IsDoorContact=true}};
   var outgoing=h.MakeRoute(other,lamp,out _,out var outgoingFailure,kind);
   if(outgoing==null)throw new Exception("sensor OUT to lamp blocked: "+outgoingFailure);checks++;
   if((outgoing[outgoing.Length-1]-lp).Squared>1e-10f)throw new Exception("sensor OUT route misses lamp");checks++;

  }
  Console.WriteLine("Door Contact: "+checks+" terminal route checks passed.");
 }
}
