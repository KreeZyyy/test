using System;using System.IO;using ModularSwitchboards;
internal static class LampDepthHarness
{
 internal static void Run(string root)
 {
  int checks=0,rear=0,front=0;void Check(bool ok,string why){checks++;if(!ok)throw new Exception(why);}
  float Clamp(float v)=>Math.Clamp(v,0,1);
  foreach(string part in new[]{"Body","Diffuser"})
  {
   using var r=new BinaryReader(File.OpenRead(Path.Combine(root,"Assets","CabinetLamp",part+".meshbin")));r.ReadInt32();int n=r.ReadInt32();r.ReadInt32();
   for(int i=0;i<n;i++)
   {
    float nx=r.ReadSingle(),ny=r.ReadSingle(),nz=r.ReadSingle();r.ReadSingle();r.ReadSingle();
    float h=Clamp((ny-.13f)/.05f),z=.132f+(ny-.1624f)*.13f-.045f*Clamp((.1477f-ny)/.1477f);z=z*(1-h)+(.159f+(z-.159f)*1.3f)*h;
    float small=CabinetLampDepthProfile.Extend(z,ny,false,true,.1025f);
    Check(small==z,"Small geometry must remain exactly unchanged");
    float medium=CabinetLampDepthProfile.Extend(z,ny,true,true,.1025f);
    if(ny<=.13f||z>=.145f){Check(medium==z,"front edge or thin inlet moved");front++;}
    if(ny>=.133f&&z<=.133f){Check(Math.Abs(medium+.014f-.1065f)<.000001f,"Medium body and diffuser must stop4mm before cover");rear++;}
    if(ny>=.133f)Check(medium+.014f>=.1065f-.000001f,"extended body or diffuser crosses cover plane");
    Check(medium<=z+.000001f,"one-sided extension moved casing towards doors");
   }
  }
  Check(rear>0&&front>0,"test did not exercise both extension and fixed face");
  Console.WriteLine("Lamp depth: "+checks+" native-mesh checks passed; "+rear+" rear vertices, "+front+" fixed front/inlet/lens vertices.");
 }
}
