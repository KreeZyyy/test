namespace ModularSwitchboards
{
    internal static class DoorContactLayout
    {
        // Bridge board Z=.013, closed door rear Z=.185; compressed tip=.104+.008-.008.
        internal const float FrontOffset=.068f;
        internal static float BodyCenterX(bool medium)=>medium?-.018f:-.002f;
        internal static float BodyWidth(bool medium)=>medium?.050f:.042f;
        internal static float PlungerX(bool medium)=>medium?-.008f:.004f;
        internal static float ContactY(int pin)=>(1-pin)*.024f;
        private static readonly WirePoint[][] leads={BuildLead(0),BuildLead(1)};
        private static WirePoint[] BuildLead(int pin)
        {
            var start=new WirePoint(-.009f,pin*.024f,.0114f);var end=new WirePoint(-.014f,.004f+pin*.016f,.044f+FrontOffset);
            return DoorModuleLayout.DoorFlexGeometry.Build(start,start+new WirePoint(-.012f,0,.014f),end+new WirePoint(.006f,0,-.015f),end);
        }
        internal static WirePoint[] FixedLead(int pin)=>leads[pin];
        internal static WirePoint? Crossing(int pin,float plane)
        {
            var points=leads[pin];
            for(int i=1;i<points.Length;i++)
            {
                var a=points[i-1];var b=points[i];float dz=b.Z-a.Z;
                if(System.Math.Abs(dz)<.000001f)continue;
                float t=(plane-a.Z)/dz;if(t>=0&&t<=1)return a+(b-a)*t;
            }
            return null;
        }
        internal static WireRect CableWindow(WirePoint p)=>new WireRect(p.X-.0145f,p.X+.0145f,p.Y-.006f,p.Y+.006f);
        internal static bool Closed(bool ready,bool doorsOpen)=>ready&&doorsOpen;
        internal static bool Fits(int y,int min,int max,int slots)=>y>=min&&y+(slots-1)*10<=max&&y%10==0;
        internal static bool Overlaps(int a,int countA,int b,int countB)=>a<=b+(countB-1)*10&&b<=a+(countA-1)*10;
    }
}
