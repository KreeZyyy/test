using UnityEngine;
using System.Collections.Generic;
using UnityEngine.Rendering;
namespace ModularSwitchboards
{
    internal static class DoorContactModel
    {
        private static readonly Mesh[] bodies=new Mesh[2];
        internal static Mesh Body(bool medium)
        {
            int i=medium?1:0;return bodies[i]!=null?bodies[i]:(bodies[i]=DoorModules.Box(new Vector3(DoorContactLayout.BodyCenterX(medium),.012f,.065f),new Vector3(DoorContactLayout.BodyWidth(medium),.032f,.038f)));
        }
        internal static Mesh Blueprint(DinBreaker owner)
        {
            var filters=new List<MeshFilter>();
            for(int i=0;i<2;i++)
            {
                filters.AddRange(owner.transform.Find("DoorContactTerminal"+i).GetComponentsInChildren<MeshFilter>(true));
                filters.Add(owner.transform.Find("DoorContactFixedLead"+i).GetComponent<MeshFilter>());
            }
            filters.AddRange(owner.transform.Find("DoorContactRimAssembly").GetComponentsInChildren<MeshFilter>(true));
            var vertices=new List<Vector3>();var triangles=new List<int>();
            foreach(var filter in filters)
            {
                var mesh=filter.sharedMesh;if(mesh==null)continue;
                var matrix=owner.transform.worldToLocalMatrix*filter.transform.localToWorldMatrix;
                int offset=vertices.Count;Vector3[] points=null;bool mirrored=matrix.determinant<0;
                for(int sub=0;sub<mesh.subMeshCount;sub++)
                {
                    if(mesh.GetTopology(sub)!=MeshTopology.Triangles)continue;
                    var ids=mesh.GetTriangles(sub);
                    if(points==null){points=mesh.vertices;foreach(var point in points)vertices.Add(matrix.MultiplyPoint3x4(point));}
                    for(int i=0;i<ids.Length;i+=3){triangles.Add(offset+ids[i]);triangles.Add(offset+ids[i+(mirrored?2:1)]);triangles.Add(offset+ids[i+(mirrored?1:2)]);}
                }
            }
            var result=new Mesh{name="DoorContact.OwnPartsBlueprint",indexFormat=IndexFormat.UInt32};result.SetVertices(vertices);result.SetTriangles(triangles,0);result.RecalculateNormals();result.RecalculateBounds();return result;
        }
        internal static MeshRenderer Install(DinBreaker owner,Material black,Material grey)
        {
            for(int pin=0;pin<2;pin++)
            {
                var terminal=new GameObject("DoorContactTerminal"+pin){layer=owner.gameObject.layer};terminal.transform.SetParent(owner.transform,false);terminal.transform.localPosition=new Vector3(0,pin*.024f,0);DoorModules.TerminalCube(terminal.transform,1);
                var path=DoorContactLayout.FixedLead(pin);
                var wire=DoorModules.Part(owner.transform,"DoorContactFixedLead"+pin,WireMesh.Build(path),CabinetGeometry.Materials[3]);WireVisualLighting.Apply(wire);
            }
            var assembly=new GameObject("DoorContactRimAssembly"){layer=owner.gameObject.layer};assembly.transform.SetParent(owner.transform,false);assembly.transform.localPosition=new Vector3(0,0,DoorContactLayout.FrontOffset);
            var root=assembly.transform;
            var body=DoorModules.Part(root,"DoorContactHousing",Body(false),black);
            for(int pin=0;pin<2;pin++)
            {
                var inlet=DoorModules.Part(root,"DoorContactCableInlet",DoorModuleGeometry.Cylinder(.0032f,.042f,.048f),black);inlet.transform.localPosition=new Vector3(-.014f,.004f+pin*.016f,0);
            }
            var collar=DoorModules.Part(root,"DoorContactPlungerCollar",DoorModuleGeometry.Cylinder(.0055f,.083f,.089f),black);collar.transform.localPosition=new Vector3(DoorContactLayout.PlungerX(false),.012f,0);
            var plunger=new GameObject("DoorContactPlunger"){layer=owner.gameObject.layer};plunger.transform.SetParent(root,false);
            var actuator=DoorModules.Part(plunger.transform,"DoorContactActuator",DoorModuleGeometry.Cylinder(.0033f,.088f,.112f),grey);actuator.transform.localPosition=new Vector3(DoorContactLayout.PlungerX(false),.012f,0);
            var view=owner.gameObject.AddComponent<DoorContactView>();view.Owner=owner;view.Plunger=plunger.transform;return body;
        }
    }
    public sealed class DoorContactView:MonoBehaviour
    {
        public DinBreaker Owner;public Transform Plunger;
        private bool initialized,last;
        private int profile=-1,ghostProfile=-1;private Mesh ghost;
        internal void RefreshProfile()
        {
            if(Owner==null||Plunger==null)return;
            var host=CabinetWiring.CabinetOf(Owner);bool medium=host!=null?CabinetShape.Medium(host.PrefabName):profile==1;int key=medium?1:0;
            if(profile!=key)
            {
                var root=transform.Find("DoorContactRimAssembly");if(root==null)return;
                root.Find("DoorContactHousing").GetComponent<MeshFilter>().sharedMesh=DoorContactModel.Body(medium);
                root.Find("DoorContactPlungerCollar").localPosition=new Vector3(DoorContactLayout.PlungerX(medium),.012f,0);
                Plunger.Find("DoorContactActuator").localPosition=new Vector3(DoorContactLayout.PlungerX(medium),.012f,0);
                profile=key;ghostProfile=-1;FittedModelCollider.Rebuild(Owner);
            }
            var filter=Owner.IsCursor?Owner.Wireframe?.BlueprintMeshFilter:null;
            if(filter!=null&&ghostProfile!=key)
            {
                var mesh=DoorContactModel.Blueprint(Owner);var old=ghost;ghost=mesh;filter.sharedMesh=mesh;Owner.Wireframe.BlueprintBounds=mesh.bounds;
                PlacementOutline.Refresh(filter.gameObject,mesh);ghostProfile=key;if(old!=null)Destroy(old);
            }
        }
        private void OnDestroy(){if(ghost!=null)Destroy(ghost);}

        private void LateUpdate()
        {
            if(Owner==null||Plunger==null)return;
            RefreshProfile();
            bool open=CabinetWiring.CabinetOf(Owner)?.IsOpen==true;
            if(initialized&&open==last)return;initialized=true;last=open;
            Plunger.localPosition=new Vector3(0,0,open?0:-.008f);
            DoorModules.PaintCubes(transform);
        }
    }
}
