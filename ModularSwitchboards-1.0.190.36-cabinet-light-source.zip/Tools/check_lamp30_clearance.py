"""Check revised independent lamp geometry against own cabinet roof and cover plane."""
from pathlib import Path
import struct,re,json
r=Path(__file__).resolve().parents[1];s=(r/'Source/CabinetLampModel.cs').read_text()
depth=float(re.search(r'\(p.z-\.159f\)\*([\d.]+)f',s).group(1));heights=tuple(map(float,re.search(r'float height=.*?\?([\d.]+)f:([\d.]+)f;',s).groups()))
extension=(r/'Source/CabinetLampDepthProfile.cs').read_text()
gap=float(re.search(r'coverFront\+([\d.]+)f',extension).group(1))
def clamp(x):return max(0,min(1,x))
def adapt(v):
 x,y,z=v;return [x*.195,-(z-.1086)*.13,.132+(y-.1624)*.13-.045*clamp((.1477-y)/.1477)]
def profile(v,new,medium):
 x,y,z=adapt(v);h=clamp((v[1]-.13)/.05);roof=clamp((y-.003)/.0054)*h;upper=y*(1-roof)+.019419603*roof
 yy=upper*(1-h)+(.019419603+(upper-.019419603)*(heights[0 if medium else 1] if new else 1))*h
 zz=z*(1-h)+(.159+(z-.159)*(depth if new else 2.5))*h
 if new and medium:zz+=(.1025+gap-.014-zz)*clamp((.145-zz)/.012)*clamp((v[1]-.13)/.003)
 return [x,yy+(.488 if medium else .244)-.0002-.019419603,zz+.014]
b=(r/'Assets/CabinetLamp/Diffuser.meshbin').read_bytes();_,n,_=struct.unpack_from('<iii',b);v=[struct.unpack_from('<5f',b,12+20*i)[:3]for i in range(n)];report=[]
for medium in (False,True):
 old=[profile(p,False,medium)for p in v];new=[profile(p,True,medium)for p in v]
 roof=(.488 if medium else .244)-.0002
 assert max(p[1]for p in new)<roof
 assert min(p[1]for p in new)>min(p[1]for p in old)
 assert min(p[2]for p in new)>=.1025+gap-.000001
 if medium:assert abs(min(p[2]for p in new)-(.1025+gap))<.000001
 else:assert max(p[2]for p in new)-min(p[2]for p in new)<max(p[2]for p in old)-min(p[2]for p in old)
 report.append(dict(profile='Medium'if medium else'Small',diffuser_min_y=min(p[1]for p in new),cover_front=.1025,diffuser_min_z=min(p[2]for p in new),depth_range=max(p[2]for p in new)-min(p[2]for p in new)))
print(json.dumps(report));print('8 independent diffuser clearance checks passed; live cover fit still needs visual verification.')
