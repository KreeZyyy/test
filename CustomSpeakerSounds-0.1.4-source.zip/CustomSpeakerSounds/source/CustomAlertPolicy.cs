using System;
namespace CustomSpeakerSounds {
 public static class CustomAlertPolicy {
  public static bool TryId(double value,out int id) {
   id=0;if(double.IsNaN(value)||double.IsInfinity(value)||value<100||value>=200)return false;
   id=(int)value;return true;
  }
 }
}