using System;
using System.IO;
using System.Collections.Generic;
using Assets.Scripts.Objects;
using Assets.Scripts.UI;
using LibConstruct;
using HarmonyLib;
using Rendering;
using UnityEngine;
using UnityEngine.Rendering;
namespace ModularSwitchboards
{
    internal static class CabinetLampModel
    {
        internal const float Scale=.13f;
        // Front housing lives between the inner cover and the closed door. Lengthen only
        // the low-Y socket/support so the original socket stays behind the cover.
        internal static Vector3 Adapt(Vector3 native)=>new Vector3(native.x*Scale*1.5f,-(native.z-.1086f)*Scale,
            .132f+(native.y-.1624f)*Scale-.045f*Mathf.Clamp01((.1477f-native.y)/.1477f));
        // Original socket is behind the inner cover, in front of the mounting plate. Only the plate terminal is user-wired.
        // The prefab cable-grid anchor (.799) lies outside the visible mesh. End the
        // fixed lead just inside the actual socket mouth at original mesh X=.750.
        internal static readonly Vector3 NativeSocket=Adapt(new Vector3(.7495f,-.000207672f,0f));
        internal static Vector3 PlateTerminal(CabinetLamp owner)=>CabinetShape.Medium(owner.Cabinet?.PrefabName)?new Vector3(.300f,-.025f,-.001f):new Vector3(CabinetLampWiringGeometry.PlateX(false),-.006f,-.001f);
        internal static Vector3 Terminal(CabinetLamp owner)=>PlateTerminal(owner)+new Vector3(CabinetLampWiringGeometry.EntryX(CabinetShape.Medium(owner.Cabinet?.PrefabName)),0,.0114f);
        internal static Vector3 TerminalAim(CabinetLamp owner)=>PlateTerminal(owner)+new Vector3(CabinetLampWiringGeometry.AimX(CabinetShape.Medium(owner.Cabinet?.PrefabName)),0,.0198f);
        private const float OriginalWidth=1.528524f*.13f*1.5f;
        internal static float TargetWidth(string prefab)=>Mathf.Min(OriginalWidth*2f,CabinetShape.Width(prefab)-.07f);
        private static float[] bodyNativeY,lensNativeY;
        private static float Raise(CabinetLamp owner)
        {
            string host=owner.Cabinet?.PrefabName;
            // Own Cabinet.meshbin: inner roof spans X=+/- .180 at Y=.244.
            // MediumGeometry stretches XY by two. Leave only .2 mm clearance.
            float innerRoof=.244f*(CabinetShape.Medium(host)?2f:1f)-.0002f;
            return innerRoof-CabinetLamp.MountGrid(host).y*DinLayout.ModulePitch*.1f-.019419603f;
        }
        private static Vector3 ProfilePoint(CabinetLamp owner,Vector3 p,float nativeY,bool extendSurface=false)
        {
            float width=TargetWidth(owner.Cabinet?.PrefabName),ratio=width/OriginalWidth;
            float housing=Mathf.Clamp01((nativeY-.13f)/.05f);
            // Move the thin end support outward without making it thicker. Only housing
            // receives width/depth growth, with a continuous transition at its shoulder.
            float supportX=p.x+Mathf.Clamp(p.x/(OriginalWidth*.4f),-1,1)*(width-OriginalWidth)*.5f;
            float x=Mathf.Lerp(supportX,p.x*ratio,housing);
            float z=Mathf.Lerp(p.z,.159f+(p.z-.159f)*1.3f,housing);
            var cabinet=owner.Cabinet;
            float coverFront=cabinet!=null?cabinet.CoverProfile.Depth+cabinet.CoverProfile.Sheet*.5f:InnerCoverLayout.Plane+InnerCoverLayout.Thickness*.5f;
            z=CabinetLampDepthProfile.Extend(z,nativeY,CabinetShape.Medium(cabinet?.PrefabName),extendSurface,coverFront);
            // Fill the upper housing up to the highest original inlet point. The diffuser
            // follows the profile thickness; both sizes retain a flat roof under the cabinet ceiling.
            float roof=Mathf.Clamp01((p.y-.003f)/.0054f)*housing;
            float upper=Mathf.Lerp(p.y,.019419603f,roof);
            float height=CabinetShape.Medium(owner.Cabinet?.PrefabName)?.85f:.72f;
            float y=Mathf.Lerp(upper,.019419603f+(upper-.019419603f)*height,housing)+Raise(owner);
            return new Vector3(CabinetLampWiringGeometry.ProfileX(x,CabinetShape.Medium(owner.Cabinet?.PrefabName)),y,z);
        }
        private static Mesh ProfileMesh(CabinetLamp owner,Mesh source,float[] nativeY)
        {
            var mesh=UnityEngine.Object.Instantiate(source);mesh.name=source.name+".CabinetProfile";var vertices=source.vertices;
            for(int i=0;i<vertices.Length;i++)vertices[i]=ProfilePoint(owner,vertices[i],nativeY[i],source==body||source==lens);
            mesh.vertices=vertices;
            if(!CabinetShape.Medium(owner.Cabinet?.PrefabName))for(int sub=0;sub<mesh.subMeshCount;sub++)
            {
                var ids=mesh.GetTriangles(sub);CabinetLampWiringGeometry.MatchWinding(ids,false);mesh.SetTriangles(ids,sub);
            }
            mesh.RecalculateNormals();mesh.RecalculateTangents();mesh.RecalculateBounds();return mesh;
        }
        private static WirePoint[] LeadPath(CabinetLamp owner)
        {
            var socket=ProfilePoint(owner,NativeSocket,-.000207672f);
            // Terminal rotated 180 degrees: built-in lead exits right, user wire left.
            bool medium=CabinetShape.Medium(owner.Cabinet?.PrefabName);
            var start=PlateTerminal(owner)+new Vector3(-CabinetLampWiringGeometry.EntryX(medium),0,.0114f);
            return DoorModuleLayout.DoorFlexGeometry.Build(CabinetWiring.Point(start),CabinetLampWiringGeometry.FixedLeadControl(CabinetWiring.Point(start),CabinetShape.Medium(owner.Cabinet?.PrefabName)),CabinetWiring.Point(socket+new Vector3(medium?.020f:-.020f,0,0)),CabinetWiring.Point(socket));
        }
        internal static void Resize(CabinetLamp owner)
        {
            float width=TargetWidth(owner.Cabinet?.PrefabName);
            if(owner.LayoutWidth==width&&(!owner.IsCursor||owner.GhostWidth==width))return;
            var bodyRoot=owner.transform.Find("CabinetLampBody");var lensRoot=owner.transform.Find("CabinetLampDiffuser");
            if(bodyRoot==null||lensRoot==null||body==null)return;
            if(owner.LayoutWidth!=width)
            {
                var previousBody=owner.BodyMesh;var previousLens=owner.LensMesh;
                owner.BodyMesh=ProfileMesh(owner,body,bodyNativeY);owner.LensMesh=ProfileMesh(owner,lens,lensNativeY);
                bodyRoot.GetComponent<MeshFilter>().sharedMesh=owner.BodyMesh;lensRoot.GetComponent<MeshFilter>().sharedMesh=owner.LensMesh;
                bodyRoot.localScale=lensRoot.localScale=Vector3.one;bodyRoot.localPosition=lensRoot.localPosition=Vector3.zero;
                if(previousBody!=null)UnityEngine.Object.Destroy(previousBody);if(previousLens!=null)UnityEngine.Object.Destroy(previousLens);
                var socket=ProfilePoint(owner,NativeSocket,-.000207672f);
                var terminalRoot=owner.transform.Find("CabinetLampPlateTerminal");if(terminalRoot!=null){terminalRoot.localPosition=PlateTerminal(owner);terminalRoot.localRotation=Quaternion.Euler(0,0,CabinetLampWiringGeometry.TerminalRotation(CabinetShape.Medium(owner.Cabinet?.PrefabName)));}
                var path=LeadPath(owner);
                var filter=owner.transform.Find("CabinetLampFixedLead")?.GetComponent<MeshFilter>();if(filter!=null){var old=owner.LeadMesh;owner.LeadMesh=WireMesh.Build(path);filter.sharedMesh=owner.LeadMesh;if(old!=null)UnityEngine.Object.Destroy(old);}
                var bounds=owner.BodyMesh.bounds;bounds.Encapsulate(owner.LensMesh.bounds);
                var hit=owner.GetComponent<BoxCollider>();if(hit!=null){hit.center=bounds.center;hit.size=bounds.size;}
                bounds.Encapsulate(new Bounds(PlateTerminal(owner)+new Vector3(0,0,.01f),new Vector3(.022f,.024f,.024f)));bounds.Encapsulate(socket);owner.Bounds=bounds;owner.GridBounds=new GridBounds(owner);owner.LayoutWidth=width;owner.GhostWidth=0;
                RefreshLights(owner);
            }
            var ghostFilter=owner.Wireframe?.BlueprintMeshFilter;
            if(owner.IsCursor&&ghostFilter!=null&&owner.GhostWidth!=width)
            {
                var mesh=BuildBlueprint(owner);var old=owner.GhostMesh;owner.GhostMesh=mesh;ghostFilter.sharedMesh=mesh;owner.Wireframe.BlueprintBounds=mesh.bounds;owner.GhostWidth=width;PlacementOutline.Refresh(ghostFilter.gameObject,mesh);if(old!=null)UnityEngine.Object.Destroy(old);
            }
        }
        private static void RefreshLights(CabinetLamp owner)
        {
            var group=owner.transform.Find("CabinetLampGlow");if(group==null)return;
            bool medium=CabinetShape.Medium(owner.Cabinet?.PrefabName);float width=TargetWidth(owner.Cabinet?.PrefabName);
            group.localPosition=new Vector3(0,Raise(owner)-(medium?.018f:.013f),.155f);
            for(int i=0;i<CabinetLampLighting.Count;i++)
            {
                var node=group.Find("LampLight"+i);if(node==null)continue;
                node.localPosition=new Vector3(CabinetLampLighting.Offset(i,width),0,0);
                var light=node.GetComponent<Light>();if(light!=null){light.range=CabinetLampLighting.Range(medium);light.intensity=CabinetLampLighting.Intensity(medium);}
            }
        }
        private static Mesh BuildBlueprint(CabinetLamp owner)
        {
            var terminal=owner.transform.Find("CabinetLampPlateTerminal/BridgeTerminalCube");
            var terminalMesh=terminal?.GetComponent<MeshFilter>()?.sharedMesh;
            var matrix=terminal==null?Matrix4x4.identity:owner.transform.worldToLocalMatrix*terminal.localToWorldMatrix;
            var lead=owner.transform.Find("CabinetLampFixedLead")?.GetComponent<MeshFilter>()?.sharedMesh;
            return CabinetLampBlueprint.Build(owner.BodyMesh??body,owner.LensMesh??lens,terminalMesh,matrix,lead);
        }
        private static Mesh body,lens;
        private static Material bodyMaterial,lensMaterial;
        private static Stream Resource(string name)=>typeof(CabinetLampModel).Assembly.GetManifestResourceStream("ModularSwitchboards.CabinetLamp."+name)??throw new InvalidOperationException("Missing lamp asset: "+name);
        private static Mesh Load(string name)
        {
            using(var stream=Resource(name+".meshbin"))using(var r=new BinaryReader(stream))
            {
                if(r.ReadInt32()!=0x504d414c)throw new InvalidDataException("Invalid cabinet lamp mesh.");int count=r.ReadInt32(),groups=r.ReadInt32();
                if(count<3||count>65535||groups<1||groups>16)throw new InvalidDataException("Invalid lamp mesh counts.");
                var vertices=new List<Vector3>();var uv=new List<Vector2>();var nativeY=new float[count];
                for(int i=0;i<count;i++){var point=new Vector3(r.ReadSingle(),r.ReadSingle(),r.ReadSingle());nativeY[i]=point.y;vertices.Add(Adapt(point));uv.Add(new Vector2(r.ReadSingle(),r.ReadSingle()));}
                if(name=="Body")bodyNativeY=nativeY;else lensNativeY=nativeY;
                var mesh=new Mesh{name="CabinetLamp.NativeCopy."+name};mesh.SetVertices(vertices);mesh.SetUVs(0,uv);mesh.subMeshCount=groups;
                for(int i=0;i<groups;i++){int length=r.ReadInt32();if(length<0||length>1000000||length%3!=0)throw new InvalidDataException("Invalid lamp triangles.");var ids=new int[length];for(int j=0;j<length;j++){ids[j]=r.ReadInt32();if(ids[j]<0||ids[j]>=count)throw new InvalidDataException("Invalid lamp index.");}mesh.SetTriangles(ids,i);}
                if(stream.Position!=stream.Length)throw new InvalidDataException("Trailing lamp mesh bytes.");mesh.RecalculateNormals();mesh.RecalculateTangents();mesh.RecalculateBounds();return mesh;
            }
        }
        private static Material Surface(string name)
        {
            // Shader is a generic game surface; no original lamp mesh/material/prefab is referenced.
            var shader=ServerGraphics.FindShader("StandardInstanced")??ServerGraphics.FindShader("Standard");
            if(shader==null)throw new InvalidOperationException("Cabinet lamp shader unavailable.");
            var material=new Material(shader){name="CabinetLamp.Own."+name};material.SetColor("_Color",Color.white);material.SetFloat("_Glossiness",.5f);
            if(!ServerGraphics.Headless)using(var stream=Resource(name+".png")){var bytes=new byte[stream.Length];int total=0;while(total<bytes.Length){int n=stream.Read(bytes,total,bytes.Length-total);if(n==0)throw new EndOfStreamException();total+=n;}var texture=new Texture2D(2,2,TextureFormat.RGBA32,false);if(!texture.LoadImage(bytes))throw new InvalidDataException("Lamp texture decode failed.");texture.name="CabinetLamp.Own."+name;material.mainTexture=texture;}
            if(name=="Diffuser"){material.EnableKeyword("_EMISSION");material.SetColor("_EmissionColor",Color.black);}return material;
        }
        private static MeshRenderer Part(Transform parent,string name,Mesh mesh,Material material)
        {
            var go=new GameObject(name){layer=parent.gameObject.layer};go.transform.SetParent(parent,false);go.AddComponent<MeshFilter>().sharedMesh=mesh;var renderer=go.AddComponent<MeshRenderer>();renderer.sharedMaterial=material;renderer.shadowCastingMode=ShadowCastingMode.Off;return renderer;
        }
        internal static void Install(CabinetLamp owner,Transform storage)
        {
            foreach(var c in owner.GetComponentsInChildren<Renderer>(true))UnityEngine.Object.DestroyImmediate(c);
            foreach(var c in owner.GetComponentsInChildren<MeshFilter>(true))UnityEngine.Object.DestroyImmediate(c);
            foreach(var c in owner.GetComponentsInChildren<Collider>(true))UnityEngine.Object.DestroyImmediate(c);
            foreach(var c in owner.GetComponentsInChildren<Animator>(true))UnityEngine.Object.DestroyImmediate(c);
            if(body==null){body=Load("Body");lens=Load("Diffuser");bodyMaterial=Surface("Body");lensMaterial=Surface("Diffuser");}
            owner.BaseAnimator=null;owner.Renderers=new List<ThingRenderer>();owner.Interactables=new List<Interactable>();owner.Slots=new List<Slot>();
            owner._staticColliders=new List<Collider>();owner._dynamicColliders=new List<Collider>();owner._selfColliders=new List<Collider>();owner.MPBRenderers.Clear();owner.CustomNavMeshFilter=null;owner.ForceGridBounds.Clear();owner.BrokenBuildStates=new List<BrokenBuildState>();
            owner.HasColorState=false;owner.HasOnOffState=false;owner.HasPowerState=false;owner.PaintableMaterial=null;owner.UseCellPosition=false;owner.SelectionDisplay=SelectionHighlightMethod.Bounds;owner.StructureCollisionType=CollisionType.BlockCustom;owner.structureRenderMode=StructureRenderMode.Standard;
            Part(owner.transform,"CabinetLampBody",body,bodyMaterial);Part(owner.transform,"CabinetLampDiffuser",lens,lensMaterial);
            var terminalRoot=new GameObject("CabinetLampPlateTerminal"){layer=owner.gameObject.layer};terminalRoot.transform.SetParent(owner.transform,false);terminalRoot.transform.localPosition=PlateTerminal(owner);terminalRoot.transform.localRotation=Quaternion.Euler(0,0,CabinetLampWiringGeometry.TerminalRotation(CabinetShape.Medium(owner.Cabinet?.PrefabName)));
            DoorModules.TerminalCube(terminalRoot.transform,1);
            
            // Door Bridge-style fixed lead stays behind the inner cover, never behind the mounting plate.
            var fixedPath=LeadPath(owner);
            var lead=Part(owner.transform,"CabinetLampFixedLead",WireMesh.Build(fixedPath),CabinetGeometry.Materials[3]);WireVisualLighting.Apply(lead);
            var bodyBounds=body.bounds;bodyBounds.Encapsulate(lens.bounds);var bounds=bodyBounds;bounds.Encapsulate(Terminal(owner));bounds.Encapsulate(NativeSocket);bounds.Encapsulate(new Bounds(PlateTerminal(owner)+new Vector3(0,0,.01f),new Vector3(.022f,.024f,.024f)));
            var hit=owner.gameObject.AddComponent<BoxCollider>();hit.center=bodyBounds.center;hit.size=bodyBounds.size;
            var terminalHit=terminalRoot.AddComponent<BoxCollider>();terminalHit.center=new Vector3(0,0,.010f);terminalHit.size=new Vector3(.022f,.024f,.024f);
            owner.Bounds=bounds;owner.GridBounds=new GridBounds(owner);owner._staticColliders.Add(hit);owner._selfColliders.Add(hit);owner._staticColliders.Add(terminalHit);owner._selfColliders.Add(terminalHit);
            var state=owner.BuildStates[0];state.Visualizer=owner.transform.Find("CabinetLampBody").GetComponent<MeshRenderer>();state.LinkedGameObjects=new List<GameObject>{owner.transform.Find("CabinetLampDiffuser").gameObject,terminalRoot,lead.gameObject};state.Colliders=new List<Collider>{hit,terminalHit};state.Interactables=new List<Interactable>();state.StateMeshes=new List<Mesh>();state.RendererInstance=null;state.RenderMode=BuildStateRenderMode.OnMyState;state.Thumbnail=owner.Thumbnail;AccessTools.Field(typeof(BuildState),"initialDrawData").SetValue(state,new DrawData{mesh=null,materials=new Material[0]});PrefabAudioOwner.Rebind(owner);state.BlockAir=false;state.AlwaysBlockAir=false;state.BlockGravity=false;state.BlockLight=false;
            Resize(owner);
            var bp=new GameObject("CabinetLampBlueprint"){layer=owner.gameObject.layer};bp.transform.SetParent(storage,false);var mesh=BuildBlueprint(owner);bp.AddComponent<MeshFilter>().sharedMesh=mesh;var renderer=bp.AddComponent<MeshRenderer>();renderer.sharedMaterial=bodyMaterial;var wire=bp.AddComponent<Wireframe>();wire.BlueprintTransform=bp.transform;wire.BlueprintBounds=mesh.bounds;wire.BlueprintMeshFilter=bp.GetComponent<MeshFilter>();wire.BlueprintRenderer=renderer;bp.AddComponent<CabinetBlueprint>();owner.Blueprint=bp;owner.BlueprintOrientVector=Vector3.zero;Resize(owner);
            if(!ServerGraphics.Headless)
            {
                var glow=new GameObject("CabinetLampGlow"){layer=owner.gameObject.layer};glow.transform.SetParent(owner.transform,false);
                for(int i=0;i<CabinetLampLighting.Count;i++)
                {
                    var node=new GameObject("LampLight"+i){layer=owner.gameObject.layer};node.transform.SetParent(glow.transform,false);
                    var light=node.AddComponent<Light>();light.type=LightType.Point;light.intensity=CabinetLampLighting.Intensity(CabinetShape.Medium(owner.Cabinet?.PrefabName));light.color=Color.white;light.shadows=LightShadows.Soft;light.shadowStrength=1f;light.shadowBias=.01f;light.shadowNormalBias=.01f;light.shadowResolution=LightShadowResolution.Low;light.shadowCustomResolution=256;light.renderMode=LightRenderMode.ForcePixel;light.enabled=false;
                }
                RefreshLights(owner);owner.gameObject.AddComponent<CabinetLampView>();
            }
        }
    }
    public sealed class CabinetLampView:MonoBehaviour
    {
        private CabinetLamp owner;private MeshRenderer diffuser;private Light[] glows;
        private SwitchboardCabinet boundCabinet;private CabinetDoor door;
        private MaterialPropertyBlock block;
        private bool dirty=true,hasVisibility,lastVisibility;
        private static readonly int Emission=Shader.PropertyToID("_EmissionColor");
        private void OnEnable(){Bind();}
        private void Bind()
        {
            owner=GetComponent<CabinetLamp>();diffuser=transform.Find("CabinetLampDiffuser")?.GetComponent<MeshRenderer>();
            glows=transform.Find("CabinetLampGlow")?.GetComponentsInChildren<Light>(true);
            if(block==null)block=new MaterialPropertyBlock();
            boundCabinet=null;door=null;dirty=true;hasVisibility=false;
        }
        internal void Invalidate(){dirty=true;}
        private void OnDisable()
        {
            if(glows!=null)foreach(var light in glows)if(light!=null)light.enabled=false;
            hasVisibility=false;
        }
        private void LateUpdate()
        {
            if(owner==null)return;
            var cabinet=owner.Cabinet;
            if(cabinet!=boundCabinet){boundCabinet=cabinet;door=cabinet!=null?cabinet.GetComponent<CabinetDoor>():null;}
            bool on=!owner.IsCursor&&owner.IsStructureCompleted&&owner.Lit;
            bool aperture=cabinet!=null&&(cabinet.IsOpen||(door!=null&&door.Hinge!=null&&Quaternion.Angle(door.Hinge.localRotation,Quaternion.identity)>.5f));
            bool visible=CabinetLampLighting.Visible(on,aperture);
            if(dirty)DoorModules.PaintCubes(owner.transform);
            if(dirty||!hasVisibility||visible!=lastVisibility)
            {
                if(glows!=null)foreach(var light in glows)if(light!=null)light.enabled=visible;
                if(diffuser!=null){block.Clear();block.SetColor(Emission,visible?Color.white*1.2f:Color.black);diffuser.SetPropertyBlock(block);diffuser.SetPropertyBlock(block,0);}
                lastVisibility=visible;hasVisibility=true;dirty=false;
            }
        }
    }
}
