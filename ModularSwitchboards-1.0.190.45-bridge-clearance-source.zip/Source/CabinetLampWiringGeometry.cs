namespace ModularSwitchboards
{
    internal static class CabinetLampWiringGeometry
    {
        // The front lamp and fixed lead are not solid blockers in the plate routing
        // plane. Reserve only the real Door Bridge terminal footprint, not the
        // huge bounding box spanning plate terminal and front-mounted housing.
        internal static float PlateX(bool medium)=>medium?.300f:-.177f;
        internal static float LeadSide(bool medium)=>medium?0f:1f;
        internal static WirePoint FixedLeadControl(WirePoint start,bool medium)=>start+(medium?new WirePoint(.018f,0,.005f):new WirePoint(-.003f,0,.050f));
        internal const int SmallBridgeSlot=80;
        internal static float ProfileX(float x,bool medium)=>medium?x:-x;
        internal static void MatchWinding(int[] ids,bool medium)
        {
            if(medium)return;
            for(int i=0;i<ids.Length;i+=3){int swap=ids[i+1];ids[i+1]=ids[i+2];ids[i+2]=swap;}
        }
        internal static float EntryX(bool medium)=>medium?-.009f:.009f;
        internal static float AimX(bool medium)=>medium?-.0042f:.0042f;
        internal static float TerminalRotation(bool medium)=>medium?180f:0f;
        internal static bool ReservesSlot(bool medium,int y,int count)=>!medium&&DoorContactLayout.Overlaps(y,count,SmallBridgeSlot,1);
        internal static WireRect PlateBounds(WirePoint center)=>new WireRect(center.X-.011f,center.X+.011f,center.Y-.012f,center.Y+.012f);
        internal static WirePoint Exit(WirePoint entry,bool medium=true)=>new WirePoint(entry.X+(medium?-.020f:.020f),entry.Y,WireRouting.Plane);
    }
}
