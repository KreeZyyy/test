using System;
using System.IO;
using System.Collections.Generic;
using Assets.Scripts.Objects;
using Assets.Scripts.UI;
using LibConstruct;
using HarmonyLib;
using Rendering;
using UnityEngine;
using UnityEngine.Rendering;
namespace ModularSwitchboards
{
    internal static class CabinetLampModel
    {
        internal const float Scale=.13f;
        // Front housing lives between the inner cover and the closed door. Lengthen only
        // the low-Y socket/support so the original socket stays behind the cover.
        internal static Vector3 Adapt(Vector3 native)=>new Vector3(native.x*Scale*1.5f,-(native.z-.1086f)*Scale,
            .132f+(native.y-.1624f)*Scale-.045f*Mathf.Clamp01((.1477f-native.y)/.1477f));
        // Original socket is behind the inner cover, in front of the mounting plate. Only the plate terminal is user-wired.
        internal static readonly Vector3 NativeSocket=Adapt(new Vector3(.799f,-.000207672f,-.001871524f));
        internal static readonly Vector3 PlateTerminal=new Vector3(.125f,-.035f,-.014f);
        internal static readonly Vector3 Terminal=PlateTerminal+new Vector3(.009f,0,.0114f);
        internal static readonly Vector3 TerminalAim=PlateTerminal+new Vector3(.0042f,0,.0198f);
        private static Mesh body,lens;
        private static Material bodyMaterial,lensMaterial;
        private static Stream Resource(string name)=>typeof(CabinetLampModel).Assembly.GetManifestResourceStream("ModularSwitchboards.CabinetLamp."+name)??throw new InvalidOperationException("Missing lamp asset: "+name);
        private static Mesh Load(string name)
        {
            using(var stream=Resource(name+".meshbin"))using(var r=new BinaryReader(stream))
            {
                if(r.ReadInt32()!=0x504d414c)throw new InvalidDataException("Invalid cabinet lamp mesh.");int count=r.ReadInt32(),groups=r.ReadInt32();
                if(count<3||count>65535||groups<1||groups>16)throw new InvalidDataException("Invalid lamp mesh counts.");
                var vertices=new List<Vector3>();var uv=new List<Vector2>();
                for(int i=0;i<count;i++){vertices.Add(Adapt(new Vector3(r.ReadSingle(),r.ReadSingle(),r.ReadSingle())));uv.Add(new Vector2(r.ReadSingle(),r.ReadSingle()));}
                var mesh=new Mesh{name="CabinetLamp.NativeCopy."+name};mesh.SetVertices(vertices);mesh.SetUVs(0,uv);mesh.subMeshCount=groups;
                for(int i=0;i<groups;i++){int length=r.ReadInt32();if(length<0||length>1000000||length%3!=0)throw new InvalidDataException("Invalid lamp triangles.");var ids=new int[length];for(int j=0;j<length;j++){ids[j]=r.ReadInt32();if(ids[j]<0||ids[j]>=count)throw new InvalidDataException("Invalid lamp index.");}mesh.SetTriangles(ids,i);}
                if(stream.Position!=stream.Length)throw new InvalidDataException("Trailing lamp mesh bytes.");mesh.RecalculateNormals();mesh.RecalculateTangents();mesh.RecalculateBounds();return mesh;
            }
        }
        private static Material Surface(string name)
        {
            // Shader is a generic game surface; no original lamp mesh/material/prefab is referenced.
            var shader=ServerGraphics.FindShader("StandardInstanced")??ServerGraphics.FindShader("Standard");
            if(shader==null)throw new InvalidOperationException("Cabinet lamp shader unavailable.");
            var material=new Material(shader){name="CabinetLamp.Own."+name};material.SetColor("_Color",Color.white);material.SetFloat("_Glossiness",.5f);
            if(!ServerGraphics.Headless)using(var stream=Resource(name+".png")){var bytes=new byte[stream.Length];int total=0;while(total<bytes.Length){int n=stream.Read(bytes,total,bytes.Length-total);if(n==0)throw new EndOfStreamException();total+=n;}var texture=new Texture2D(2,2,TextureFormat.RGBA32,false);if(!texture.LoadImage(bytes))throw new InvalidDataException("Lamp texture decode failed.");texture.name="CabinetLamp.Own."+name;material.mainTexture=texture;}
            if(name=="Diffuser"){material.EnableKeyword("_EMISSION");material.SetColor("_EmissionColor",Color.black);}return material;
        }
        private static MeshRenderer Part(Transform parent,string name,Mesh mesh,Material material)
        {
            var go=new GameObject(name){layer=parent.gameObject.layer};go.transform.SetParent(parent,false);go.AddComponent<MeshFilter>().sharedMesh=mesh;var renderer=go.AddComponent<MeshRenderer>();renderer.sharedMaterial=material;renderer.shadowCastingMode=ShadowCastingMode.Off;return renderer;
        }
        internal static void Install(CabinetLamp owner,Transform storage)
        {
            foreach(var c in owner.GetComponentsInChildren<Renderer>(true))UnityEngine.Object.DestroyImmediate(c);
            foreach(var c in owner.GetComponentsInChildren<MeshFilter>(true))UnityEngine.Object.DestroyImmediate(c);
            foreach(var c in owner.GetComponentsInChildren<Collider>(true))UnityEngine.Object.DestroyImmediate(c);
            foreach(var c in owner.GetComponentsInChildren<Animator>(true))UnityEngine.Object.DestroyImmediate(c);
            if(body==null){body=Load("Body");lens=Load("Diffuser");bodyMaterial=Surface("Body");lensMaterial=Surface("Diffuser");}
            owner.BaseAnimator=null;owner.Renderers=new List<ThingRenderer>();owner.Interactables=new List<Interactable>();owner.Slots=new List<Slot>();
            owner._staticColliders=new List<Collider>();owner._dynamicColliders=new List<Collider>();owner._selfColliders=new List<Collider>();owner.MPBRenderers.Clear();owner.CustomNavMeshFilter=null;owner.ForceGridBounds.Clear();owner.BrokenBuildStates=new List<BrokenBuildState>();
            owner.HasColorState=false;owner.HasOnOffState=false;owner.HasPowerState=false;owner.PaintableMaterial=null;owner.UseCellPosition=false;owner.SelectionDisplay=SelectionHighlightMethod.Bounds;owner.StructureCollisionType=CollisionType.BlockCustom;owner.structureRenderMode=StructureRenderMode.Standard;
            Part(owner.transform,"CabinetLampBody",body,bodyMaterial);Part(owner.transform,"CabinetLampDiffuser",lens,lensMaterial);
            var terminalRoot=new GameObject("CabinetLampPlateTerminal"){layer=owner.gameObject.layer};terminalRoot.transform.SetParent(owner.transform,false);terminalRoot.transform.localPosition=PlateTerminal;
            DoorModules.TerminalCube(terminalRoot.transform,1);
            // Door Bridge-style fixed lead stays behind the inner cover, never behind the mounting plate.
            var start=PlateTerminal+new Vector3(-.009f,0,.0114f);
            var fixedPath=DoorModuleLayout.DoorFlexGeometry.Build(CabinetWiring.Point(start),CabinetWiring.Point(start+new Vector3(-.018f,0,.005f)),CabinetWiring.Point(NativeSocket+new Vector3(0,-.025f,-.016f)),CabinetWiring.Point(NativeSocket));
            var lead=Part(owner.transform,"CabinetLampFixedLead",WireMesh.Build(fixedPath),CabinetGeometry.Materials[3]);WireVisualLighting.Apply(lead);
            var bodyBounds=body.bounds;bodyBounds.Encapsulate(lens.bounds);var bounds=bodyBounds;bounds.Encapsulate(Terminal);bounds.Encapsulate(NativeSocket);bounds.Encapsulate(new Bounds(PlateTerminal+new Vector3(0,0,.01f),new Vector3(.022f,.024f,.024f)));
            var hit=owner.gameObject.AddComponent<BoxCollider>();hit.center=bodyBounds.center;hit.size=bodyBounds.size;
            var terminalHit=terminalRoot.AddComponent<BoxCollider>();terminalHit.center=new Vector3(0,0,.010f);terminalHit.size=new Vector3(.022f,.024f,.024f);
            owner.Bounds=bounds;owner.GridBounds=new GridBounds(owner);owner._staticColliders.Add(hit);owner._selfColliders.Add(hit);owner._staticColliders.Add(terminalHit);owner._selfColliders.Add(terminalHit);
            var state=owner.BuildStates[0];state.Visualizer=owner.transform.Find("CabinetLampBody").GetComponent<MeshRenderer>();state.LinkedGameObjects=new List<GameObject>{owner.transform.Find("CabinetLampDiffuser").gameObject,terminalRoot,lead.gameObject};state.Colliders=new List<Collider>{hit,terminalHit};state.Interactables=new List<Interactable>();state.StateMeshes=new List<Mesh>();state.RendererInstance=null;state.RenderMode=BuildStateRenderMode.OnMyState;state.Thumbnail=owner.Thumbnail;AccessTools.Field(typeof(BuildState),"initialDrawData").SetValue(state,new DrawData{mesh=null,materials=new Material[0]});PrefabAudioOwner.Rebind(owner);state.BlockAir=false;state.AlwaysBlockAir=false;state.BlockGravity=false;state.BlockLight=false;
            var bp=new GameObject("CabinetLampBlueprint"){layer=owner.gameObject.layer};bp.transform.SetParent(storage,false);var mesh=ModelBlueprint.Build(owner.transform);bp.AddComponent<MeshFilter>().sharedMesh=mesh;var renderer=bp.AddComponent<MeshRenderer>();renderer.sharedMaterial=bodyMaterial;var wire=bp.AddComponent<Wireframe>();wire.BlueprintTransform=bp.transform;wire.BlueprintBounds=mesh.bounds;wire.BlueprintMeshFilter=bp.GetComponent<MeshFilter>();wire.BlueprintRenderer=renderer;bp.AddComponent<CabinetBlueprint>();owner.Blueprint=bp;owner.BlueprintOrientVector=Vector3.zero;
            if(!ServerGraphics.Headless){var glow=new GameObject("CabinetLampGlow"){layer=owner.gameObject.layer};glow.transform.SetParent(owner.transform,false);glow.transform.localPosition=new Vector3(0,-.024f,.156f);glow.transform.localRotation=Quaternion.LookRotation(new Vector3(0,-1,-.35f));var light=glow.AddComponent<Light>();light.type=LightType.Spot;light.spotAngle=105;light.range=1.2f;light.intensity=1.2f;light.color=Color.white;light.shadows=LightShadows.Hard;light.enabled=false;owner.gameObject.AddComponent<CabinetLampView>();}
        }
    }
    public sealed class CabinetLampView:MonoBehaviour
    {
        private CabinetLamp owner;private MeshRenderer diffuser;private Light glow;
        private void LateUpdate()
        {
            if(owner==null){owner=GetComponent<CabinetLamp>();diffuser=transform.Find("CabinetLampDiffuser")?.GetComponent<MeshRenderer>();glow=transform.Find("CabinetLampGlow")?.GetComponent<Light>();}
            bool on=owner!=null&&!owner.IsCursor&&owner.IsStructureCompleted&&owner.Lit;
            if(glow!=null)glow.enabled=on;
            if(diffuser!=null){var block=new MaterialPropertyBlock();block.SetColor("_EmissionColor",on?Color.white*1.2f:Color.black);diffuser.SetPropertyBlock(block);diffuser.SetPropertyBlock(block,0);}
        }
    }
}
