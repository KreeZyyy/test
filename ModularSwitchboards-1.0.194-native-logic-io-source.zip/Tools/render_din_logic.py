import bpy,json,zipfile,struct,math
from pathlib import Path
from mathutils import Matrix,Vector
import sys
args=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else []
if not args:raise SystemExit('Usage: blender -b --python Tools/render_din_logic.py -- CAPTURE_ZIP [OUTPUT_DIRECTORY]')
root=Path(__file__).resolve().parents[1];out=Path(args[1]) if len(args)>1 else Path('/tmp/dinlogic-preview');out.mkdir(parents=True,exist_ok=True);z=zipfile.ZipFile(args[0]);d=json.loads(z.read('Models/LogicIO-kit-appearance.json'))
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
def material(name,color,metal=0):
 m=bpy.data.materials.new(name);m.diffuse_color=(*color,1);m.use_nodes=True;p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*color,1);p.inputs['Roughness'].default_value=.65;p.inputs['Metallic'].default_value=metal;return m
white=material('DIN body',(.62,.66,.65));black=material('Black',(.017,.02,.022));silver=material('Terminal screws',(.36,.39,.38),.6);plate=material('Backplate',(.09,.11,.12));railmat=material('DIN rail',(.25,.28,.29),.5)
textures={}
for t in d['textures']:
 p=out/t['file'];p.write_bytes(z.read('Models/'+t['file']));textures[t['id']]=bpy.data.images.load(str(p))
mats={}
for m in d['materials']:
 mat=material(m['name'],(.5,.5,.5));p=mat.node_tree.nodes.get('Principled BSDF')
 for prop in m['properties']:
  if prop['name']=='_MainTex' and prop['textureId'] in textures:
   tex=mat.node_tree.nodes.new('ShaderNodeTexImage');tex.image=textures[prop['textureId']];mat.node_tree.links.new(tex.outputs['Color'],p.inputs['Base Color'])
 mats[m['id']]=mat

def cube(name,pos,size,mat,bevel=0):
 bpy.ops.mesh.primitive_cube_add(size=1,location=pos);o=bpy.context.object;o.name=name;o.dimensions=size;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.append(mat)
 if bevel:mod=o.modifiers.new('DIN corners','BEVEL');mod.width=bevel;mod.segments=3;o.modifiers.new('Weighted normals','WEIGHTED_NORMAL')
 return o

def decode(file):
 with open(file,'rb') as f:
  def I():return struct.unpack('<i',f.read(4))[0]
  def S():return f.read(I()).decode()
  assert I()==0x4c494f31
  arr=[]
  for _ in range(I()):
   name=S();v=[];uv=[]
   for _ in range(I()):a=struct.unpack('<5f',f.read(20));v.append(a[:3]);uv.append(a[3:])
   tris=[];slots=[]
   for j in range(I()):
    ids=[I() for _ in range(I())]
    for k in range(0,len(ids),3):tris.append(ids[k:k+3]);slots.append(j)
   arr.append((name,v,uv,tris,slots))
  return arr
names=['StructureLogicReader','StructureLogicWriter','StructureLogicBatchReader','StructureLogicBatchWriter','StructureLogicSlotReader','StructureLogicBatchSlotReader','StructureLogicReagentReader','StructureLogicMirror']
for index,name in enumerate(names):
 before=set(bpy.data.objects)
 x=(index%4-1.5)*.119;y=.084 if index<4 else -.084;origin=Vector((x-.02025,y,0));v=next(v for v in d['variants'] if v['prefab']==name)
 for path,verts,uv,triangles,slots in decode(root/'Assets/LogicIO'/ (name+'.meshbin')):
  part=next(p for p in v['parts'] if '/'.join(q.split('[')[0] for q in p['path'].split('/')[1:])==path);a=part['meshToPrefab'];M=Matrix([[a['m'+str(i)+str(j)] for j in range(4)] for i in range(4)])
  vs=[tuple(origin+Vector((.02025,0,.066))+Vector((-.16*(M@Vector(p)).x,.16*(M@Vector(p)).y,.16*(M@Vector(p)).z))) for p in verts];me=bpy.data.meshes.new(path or name);me.from_pydata(vs,[],triangles);me.update();o=bpy.data.objects.new(name+path,me);bpy.context.collection.objects.link(o)
  for mid in part['materialIds']:me.materials.append(mats[mid])
  layer=me.uv_layers.new()
  for poly,j in zip(me.polygons,slots):
   poly.material_index=j
   for li,vi in zip(poly.loop_indices,poly.vertices):layer.data[li].uv=uv[vi]
 # Equivalent proportions to production DinBreakerModel.Build, scaled identically.
 cube('DIN lower body',(x,y,.029*1.15),(.0801,.075*1.35,.056*1.15),white,.0018*1.35)
 cube('DIN raised face',(x,y,.059*1.15),(.0801,.052*1.35,.008*1.15),white,.0015)
 for pin in range(3):
  px=x+(-.018 if pin==0 else .018 if pin==2 else 0);py=y+(-.042 if pin==1 else .042)
  cube('Terminal recess',(px,py,.067),(.014,.012,.003),black,.0008);cube('Screw',(px,py,.0685),(.011,.008,.0018),silver,.0004);cube('Slot',(px,py,.0695),(.008,.001,.0003),black)
 title=name.replace('StructureLogic','').replace('BatchSlot','Batch Slot ').replace('Batch','Batch ').replace('Reagent','Reagent ').replace('SlotReader','Slot Reader')
 bpy.ops.object.text_add(location=(x,y+.067,.003));o=bpy.context.object;o.data.body=title;o.data.align_x='CENTER';o.data.size=.008;o.data.extrude=0;o.data.materials.append(white)
 for owned in set(bpy.data.objects)-before:owned['din_logic_index']=index
for y in [-.084,.084]:cube('Rail',(0,y,-.008),(.48,.026,.014),railmat,.001)
cube('Mounting plate',(0,0,-.025),(.54,.34,.018),plate,.003)
world=bpy.context.scene.world;world.use_nodes=True;world.node_tree.nodes['Background'].inputs[0].default_value=(.18,.20,.22,1);world.node_tree.nodes['Background'].inputs[1].default_value=.5
for loc,power,size in [((-.3,.4,.65),4,.5),((.5,-.1,.45),2,.4)]:
 bpy.ops.object.light_add(type='AREA',location=loc);o=bpy.context.object;o.data.energy=power;o.data.shape='DISK';o.data.size=size;o.rotation_euler=(Vector((0,0,0))-o.location).to_track_quat('-Z','Y').to_euler()
bpy.ops.object.camera_add(location=(.015,.17,.9));cam=bpy.context.object;fw=(Vector((0,0,.01))-cam.location).normalized();rt=fw.cross(Vector((0,1,0))).normalized();up=rt.cross(fw).normalized();pos=cam.location.copy();cam.matrix_world=Matrix([[rt.x,up.x,-fw.x,pos.x],[rt.y,up.y,-fw.y,pos.y],[rt.z,up.z,-fw.z,pos.z],[0,0,0,1]]);cam.data.type='ORTHO';cam.data.ortho_scale=.58;bpy.context.scene.camera=cam
sc=bpy.context.scene;sc.render.engine='CYCLES';sc.cycles.samples=32;sc.cycles.use_denoising=False;sc.render.resolution_x=1400;sc.render.resolution_y=900;sc.render.resolution_percentage=100;sc.render.image_settings.file_format='PNG';sc.render.filepath=str(out/'DIN-Logic-IO-eight-variants.png');sc.view_settings.view_transform='Standard';bpy.ops.wm.save_as_mainfile(filepath=str(out/'DIN-Logic-IO.blend'));bpy.ops.render.render(write_still=True)

sc.cycles.samples=16;sc.render.resolution_x=192;sc.render.resolution_y=192;sc.render.film_transparent=True;cam.data.ortho_scale=.125
for index,name in enumerate(names):
 for ob in bpy.data.objects:
  if ob.type in {'MESH','FONT'}:ob.hide_render=ob.get('din_logic_index',-1)!=index or ob.type=='FONT'
 x=(index%4-1.5)*.119;y=.084 if index<4 else -.084;target=Vector((x,y,.04));pos=Vector((x+.008,y+.025,.4));fw=(target-pos).normalized();rt=fw.cross(Vector((0,1,0))).normalized();up=rt.cross(fw).normalized();cam.matrix_world=Matrix([[rt.x,up.x,-fw.x,pos.x],[rt.y,up.y,-fw.y,pos.y],[rt.z,up.z,-fw.z,pos.z],[0,0,0,1]])
 sc.render.filepath=str(root/'Assets/Icons'/ (name.replace('StructureLogic','DinLogic')+'.png'));bpy.ops.render.render(write_still=True)
