from pathlib import Path
import zipfile,json,struct,re,hashlib
import argparse
parser=argparse.ArgumentParser(description='Extract CPU-readable native Logic I/O faces from the validated game capture. Never changes the capture.')
parser.add_argument('capture',type=Path);parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1]);args=parser.parse_args()
r=args.root;z=zipfile.ZipFile(args.capture);d=json.loads(z.read('Models/LogicIO-kit-appearance.json'));meshes={m['id']:m for m in d['meshes']};manifest=[]
for v in d['variants']:
 if v['prefab']=='StructureLogicWriterSwitch':continue
 out=bytearray();add=lambda fmt,*x:out.extend(struct.pack('<'+fmt,*x))
 def string(s):
  b=s.encode();add('i',len(b));out.extend(b)
 add('ii',0x4c494f31,len(v['parts']))
 for p in v['parts']:
  path='/'.join(re.sub(r'\[\d+\]$','',x) for x in p['path'].split('/')[1:]);string(path);m=meshes[p['meshId']];groups=[]
  for g in m['submeshes']:
   assert g['topology']=='Triangles';ts=g['triangles'];ts=[i for a in range(0,len(ts),3) if path or (min(m['vertices'][i]['z'] for i in ts[a:a+3])>=.04999 and max(m['vertices'][i]['z'] for i in ts[a:a+3])>.05001) for i in ts[a:a+3]];groups.append(ts)
  ids=sorted(set(i for ts in groups for i in ts));remap={old:i for i,old in enumerate(ids)};assert ids
  add('i',len(ids))
  for i in ids:
   p0=m['vertices'][i];uv=m['uv'][i] if len(m['uv'])==len(m['vertices']) else {'x':0,'y':0};add('fffff',p0['x'],p0['y'],p0['z'],uv['x'],uv['y'])
  add('i',len(groups))
  for ts in groups:
   add('i',len(ts))
   for i in ts:add('i',remap[i])
  if path=='':manifest.append({'prefab':v['prefab'],'frontVertices':len(ids),'frontTriangles':sum(len(t) for t in groups)//3})
 p=r/'Assets/LogicIO'/ (v['prefab']+'.meshbin');p.write_bytes(out)
p=r/'Assets/LogicIO/manifest.json';p.write_text(json.dumps({'sourceSha256':hashlib.sha256(z.fp.name.encode()).hexdigest() if False else hashlib.sha256(Path(z.filename).read_bytes()).hexdigest(),'clipZ':.04999,'removeFlatBackingAtZ':.05,'frontScale':.16,'modules':manifest},indent=2));print(manifest)
