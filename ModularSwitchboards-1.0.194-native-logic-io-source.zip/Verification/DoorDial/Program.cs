using System;using System.Linq;using System.Collections.Generic;using ModularSwitchboards;using Assets.Scripts.Networks;using Assets.Scripts.Objects.Electrical;using Assets.Scripts.Objects.Pipes;
namespace HarmonyLib{static class AccessTools{internal static System.Reflection.PropertyInfo Property(Type t,string n)=>t.GetProperty(n);}}
namespace Assets.Scripts.Objects.Electrical{class Cable{internal CableNetwork CableNetwork;}}
namespace Assets.Scripts.Objects.Pipes{
 class Device{
  public Cable PowerCable{get;set;}public Cable[] PowerCables{get;set;}=Array.Empty<Cable>();public Cable[] DataCables{get;set;}=Array.Empty<Cable>();public Cable DataCable;public CableNetwork InputNetwork1,OutputNetwork1;
 }
}
namespace Assets.Scripts.Networks{
 class CableNetwork{
  public List<Device> DeviceList=new();public Dictionary<Device,List<Cable>> Registration=new();internal int Adds,Removes;
  internal void AddDevice(Cable c,Device d){Adds++;if(!DeviceList.Contains(d))DeviceList.Add(d);if(!Registration.TryGetValue(d,out var v))Registration[d]=v=new();if(!v.Contains(c))v.Add(c);}
  internal void RemoveDevice(Device d){Removes++;DeviceList.RemoveAll(x=>x==d);Registration.Remove(d);}
  internal List<Cable> GetDeviceRegistration(Device d)=>Registration.TryGetValue(d,out var v)?v:null;
  internal void DirtyPowerAndDataDeviceLists(){}internal void RefreshNetworkDevice(Device d){}
 }
}
namespace ModularSwitchboards{
 class CabinetWiring{internal Cable Selected;internal Cable DialCable(long id)=>Selected;}
 class DoorDial:Device{internal bool IsStructureCompleted=true,IsCursor,IsBeingDestroyed;internal CabinetWiring Wiring=new();internal long ReferenceId=10;internal Cable BoundCable;internal CableNetwork BoundNetwork;}
}
class Program{
 static int n;static void Check(bool ok,string why){n++;if(!ok)throw new Exception(why);}
 static CabinetWireSaveData W(long a,int p,long b,int q)=>new(){From=new(a,p),To=new(b,q)};
 static void Main(){
 long[] ds={100,101},bs={200,201};var path=new[]{W(0,1,200,2),W(200,3,100,0)};bool Valid(IEnumerable<CabinetWireSaveData> w)=>DoorDialCircuit.Valid(w,bs,ds);
 Check(Valid(path)&&DoorDialCircuit.Output(100,path,bs,ds)==1,"complete data route missing");
 Check(!DoorDialCircuit.PowerWires(path,bs,ds).Any(),"data wires entered power graph");
 for(int output=1;output<=3;output++)foreach(bool reverse in new[]{false,true}){
  var w=new[]{W(0,output,200,2),W(200,3,100,0)};if(reverse)w=w.Select(x=>W(x.To.Owner,x.To.Contact,x.From.Owner,x.From.Contact)).ToArray();
  Check(Valid(w)&&DoorDialCircuit.Output(100,w,bs,ds)==output,"Output/selection order changed data route");
  foreach(var edge in w){edge.Burnt=true;Check(DoorDialCircuit.Output(100,w,bs,ds)==0,"burnt path registered Dial");edge.Burnt=false;}
 }
 Check(Valid(path.Take(1))&&Valid(path.Skip(1))&&DoorDialCircuit.Output(100,path.Skip(1),bs,ds)==0,"partial wiring not supported");
 foreach(var edge in new[]{W(0,2,200,2),W(50,1,200,2),W(50,2,200,2),W(200,3,101,0),W(200,3,50,0),W(200,2,201,2)}){
  Check(!Valid(path.Concat(new[]{edge})),"mixed/shared data bridge accepted");
  Check(DoorDialCircuit.Output(100,path.Concat(new[]{edge}),bs,ds)==0,"malformed data route still registered");
 }
 foreach(var edge in new[]{W(100,0,0,1),W(100,1,200,3),W(100,0,200,2),W(100,0,50,1)})Check(!Valid(new[]{edge}),"Dial bypassed dedicated door bridge");
 var ordinary=W(0,0,50,0);var two=path.Concat(new[]{W(0,1,201,2),W(201,3,101,0),ordinary}).ToArray();
 Check(Valid(two)&&DoorDialCircuit.Output(101,two,bs,ds)==1,"two Dials cannot observe same external network");
 Check(DoorDialCircuit.PowerWires(two,bs,ds).SequenceEqual(new[]{ordinary}),"Dial filtering removed ordinary power wire");
 var split=path.Concat(new[]{W(100,0,201,3),W(0,2,201,2)}).ToArray();Check(DoorDialCircuit.Output(100,split,bs,ds)==0,"ambiguous Dial joined two networks");

 long[] nets={500,501};var local=new[]{W(200,2,500,0),W(200,3,100,0)};
 foreach(bool reverse in new[]{false,true}){
  var route=reverse?local.Select(w=>W(w.To.Owner,w.To.Contact,w.From.Owner,w.From.Contact)).ToArray():local;
  Check(DoorDialCircuit.Valid(route,bs,ds,nets)&&DoorDialCircuit.Net(100,route,bs,ds,nets)==500,"direct Net route or selection order rejected");
  Check(DoorDialCircuit.Output(100,route,bs,ds,nets)==0&&!DoorDialCircuit.PowerWires(route,bs,ds).Any(),"local Net route gained external output or power");
  Check(SmartDoorDisplayCircuit.Valid(route,bs,new long[]{300},new long[]{400}),"unrelated display validation blocks Dial Net route");
  foreach(var w in route){w.Burnt=true;Check(DoorDialCircuit.Net(100,route,bs,ds,nets)==0,"burnt local path remains visible");w.Burnt=false;}
  WireCircuit.Orient(route[0].From,route[0].To,out var from,out var to);Check(from.Owner==200&&from.Contact==2&&to.Owner==500&&to.Contact==0,"save orientation changed Net data leaf");
 }
 foreach(var edge in new[]{W(0,1,200,2),W(200,2,501,0),W(200,3,101,0),W(500,0,0,2),W(500,0,201,2),W(500,1,40,0)})Check(!DoorDialCircuit.Valid(local.Concat(new[]{edge}),bs,ds,nets),"Net route accepted shared, mixed or external network edge");
 Check(!DoorDialCircuit.Valid(new[]{W(200,2,500,1),W(200,3,100,0)},bs,ds,nets),"wrong Net contact accepted");
 Check(!DoorDialCircuit.Valid(new[]{W(200,2,400,1),W(200,3,100,0)},bs,ds,nets),"Dial connected to Smart Output");
 Check(!DoorDialCircuit.Valid(new[]{W(100,0,500,0)},bs,ds,nets),"Dial bypassed Bridge to Net");
 Check(!SmartDoorDisplayCircuit.Valid(new[]{W(200,2,500,0),W(200,3,300,0)},bs,new long[]{300},new long[]{400}),"display now connects to Net");
 Check(SmartDoorDisplayCircuit.Valid(new[]{W(400,1,200,2),W(200,3,300,0)},bs,new long[]{300},new long[]{400}),"display Smart Output route regressed");
 Check(DoorDialCircuit.Net(100,local.Take(1),bs,ds,nets)==0&&DoorDialCircuit.Net(100,local.Skip(1),bs,ds,nets)==0,"partial Net route resolves");
 var both=local.Concat(new[]{W(201,2,501,0),W(201,3,101,0)}).ToArray();Check(DoorDialCircuit.Net(101,both,bs,ds,nets)==501,"separate Net inputs cannot coexist");
 Check(WireCircuit.CanConnect(new(200,2),new(500,0),new List<CabinetWireSaveData>(),bs.Concat(ds).Concat(nets),out _,dataTaps:nets),"native wiring refuses Bridge to Net");
 Check(!WireCircuit.CanConnect(new(201,2),new(500,0),new List<CabinetWireSaveData>{local[0]},bs.Concat(ds).Concat(nets),out _,dataTaps:nets),"occupied Net accepts second data connection");
 var dial=new DoorDial();var a=new CableNetwork();var b=new CableNetwork();var cable=new Cable{CableNetwork=a};dial.Wiring.Selected=cable;
 DoorDialNetwork.Refresh(dial);Check(dial.BoundNetwork==a&&a.DeviceList.Contains(dial)&&dial.DataCable==cable&&dial.DataCables.SequenceEqual(new[]{cable}),"native data registration missing");
 Check(dial.PowerCable==null&&dial.PowerCables.Length==0&&dial.OutputNetwork1==null,"data device gained power registration");
 for(int i=0;i<100;i++)DoorDialNetwork.Refresh(dial);Check(a.Adds==1&&a.DeviceList.Count(x=>x==dial)==1,"steady refresh duplicated registration");
 a.DeviceList.Add(dial);DoorDialNetwork.Refresh(dial);Check(a.DeviceList.Count(x=>x==dial)==1,"duplicate native data entries not normalized");
 cable.CableNetwork=b;DoorDialNetwork.Refresh(dial);Check(!a.DeviceList.Contains(dial)&&b.DeviceList.Contains(dial)&&dial.BoundNetwork==b,"cable network migration left stale device");
 dial.Wiring.Selected=null;DoorDialNetwork.Refresh(dial);Check(!b.DeviceList.Contains(dial)&&dial.DataCable==null&&dial.DataCables.Length==0,"disconnect retained data endpoint");
 foreach(int state in new[]{0,1,2}){dial.Wiring.Selected=cable;dial.IsCursor=state==0;dial.IsBeingDestroyed=state==1;dial.IsStructureCompleted=state!=2;DoorDialNetwork.Refresh(dial);Check(dial.BoundNetwork==null,"unfinished/cursor/destroyed Dial registered");dial.IsCursor=dial.IsBeingDestroyed=false;dial.IsStructureCompleted=true;}
 DoorDialNetwork.Refresh(dial);DoorDialNetwork.Unbind(dial);Check(dial.BoundNetwork==null&&!b.DeviceList.Contains(dial),"destroy/unbind retained native data endpoint");
 Console.WriteLine(n+" production Dial routing/data-only registration checks passed: dedicated bridge, 3 Outputs, ambiguity/mixed power refusal, no power graph, topology changes and native registration cleanup.");
 }
}
