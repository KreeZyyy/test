from pathlib import Path
import struct,json,re
root=Path(__file__).resolve().parents[2];scale=.16;offset=(.02025,0,.066);count=0
manifest=json.loads((root/'Assets/LogicIO/manifest.json').read_text());assert len(manifest['modules'])==8
for entry in manifest['modules']:
 file=root/'Assets/LogicIO'/(entry['prefab']+'.meshbin')
 with file.open('rb') as f:
  def I():return struct.unpack('<i',f.read(4))[0]
  def S():return f.read(I()).decode()
  assert I()==0x4c494f31;parts=I();assert 2<=parts<=6
  for part in range(parts):
   path=S();n=I();assert 0<n<100000;vertices=[struct.unpack('<5f',f.read(20)) for _ in range(n)];assert all(all(abs(p)<100 for p in v) for v in vertices)
   for _ in range(I()):
    size=I();assert size%3==0;indices=[I() for _ in range(size)];assert all(0<=i<n for i in indices)
    if not path:
     for a in range(0,len(indices),3):
      ts=[vertices[i] for i in indices[a:a+3]];assert min(v[2] for v in ts)>=.04999 and max(v[2] for v in ts)>.05001
   if not path:
    assert max(abs(v[0]*scale) for v in vertices)<.04005,'face/pins overhang a two-position DIN body'
    assert max(abs(v[1]*scale) for v in vertices)<.0356,'face does not fit standard cover window'
    assert max(v[2]*scale+offset[2] for v in vertices)<.09
   count+=1
  assert not f.read(),'unparsed mesh bytes'
print(f'{count} CPU mesh parts validated: native front retained, substrate removed, valid UV/index buffers and two-position fit.')
