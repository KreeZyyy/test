using System.Collections.Generic;
using System.Xml.Serialization;
using Assets.Scripts;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Networking;
using Assets.Scripts.Networks;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Electrical;
using Assets.Scripts.Objects.Pipes;
using Assets.Scripts.Objects.Motherboards;
using LibConstruct;
using UnityEngine;
namespace ModularSwitchboards {
 public interface IDinLogic:IPlacementBoardStructure {LogicUnitBase Logic{get;} SwitchboardCabinet Cabinet{get;} CabinetWiring LastWiring{get;set;}}
 public sealed class DinLogicReaderSaveData:LogicReaderSaveData {[XmlElement] public PlacementBoardStructureSaveData RailBoard;}
 public sealed class DinLogicReader:LogicReader,IDinLogic {
  public LogicUnitBase Logic=>this;public CabinetWiring LastWiring{get;set;}
  public PlacementBoard Board{get;set;} public PlacementBoard.BoardCell[] BoardCells{get;set;}
  public SwitchboardCabinet Cabinet=>(Board?.PrimaryHost as DinRail)?.Board?.PrimaryHost as SwitchboardCabinet;
  public override void Awake(){PrefabAudioOwner.PrepareInstance(this);base.Awake();BoardStructureHooks.Awake(this);}
  public override Grid3 GetLocalGrid()=>Board==null?default(Grid3):Board.WorldToGrid(transform.position);
  public override CanConstructInfo CanConstruct()=>DinLogicRuntime.CanPlace(this);
  protected override CanConstructInfo CanDeconstruct()=>DinLogicRuntime.CanRemove(this);
  public override bool IsPowerProvider=>false; public override bool IsPowerInputOutput=>false;
  public override double GetLogicValue(LogicType t)=>t==LogicType.RequiredPower?(IsStructureCompleted&&OnOff?UsedPower:0):base.GetLogicValue(t);
  public override float GetUsedPower(CableNetwork n)=>0; public override void UsePower(CableNetwork n,float amount){}
  public override bool AllowSetPower(CableNetwork n)=>false;
  public override void InitializeDevice(){}
  protected override void CheckConnections(){}
  public override DelayedActionInstance AttackWith(Attack attack,bool doAction=true){if(Cabinet?.CanAccessModules!=true)return null;if(Cabinet.Wiring.TryAttack(attack,doAction,out var a))return a;return base.AttackWith(attack,doAction);}
  public override bool PreventInteraction(out DelayedActionInstance fail,Interactable c,Interaction i){if(!DinLogicRuntime.Access(this)){fail=DinLogicRuntime.Denied();return true;}return base.PreventInteraction(out fail,c,i);}
  public override DelayedActionInstance InteractWith(Interactable c,Interaction i,bool doAction=true)=>!DinLogicRuntime.Access(this)?DinLogicRuntime.Denied():base.InteractWith(c,i,doAction);
  public override PassiveTooltip GetPassiveTooltip(Collider hit){var t=base.GetPassiveTooltip(hit);t.Extended+="\nDIN: 2 positions. Top: DATA IN (left), POWER (right). Bottom: DATA OUT. Native 10 W load; screwdriver selects native settings.";return t;}
  public override void OnPowerTick(){DinLogicRuntime.Power(this);base.OnPowerTick();}
  private void LateUpdate()=>DinLogicRuntime.Refresh(this);
  public override void OnDeregistered(){DinLogicRuntime.Release(this);base.OnDeregistered();if(Board!=null)BoardStructureHooks.OnDeregistered(this);}
  public override void OnDestroy(){DinLogicRuntime.Release(this);base.OnDestroy();}
  public override ThingSaveData SerializeSave(){ThingSaveData data=new DinLogicReaderSaveData();InitialiseSaveData(ref data);return data;}
  protected override void InitialiseSaveData(ref ThingSaveData data){base.InitialiseSaveData(ref data);if(data is DinLogicReaderSaveData save&&Board!=null)save.RailBoard=BoardStructureHooks.SerializeSave(this);}
  public override void DeserializeSave(ThingSaveData data){base.DeserializeSave(data);if(data is DinLogicReaderSaveData save&&save.RailBoard!=null)BoardStructureHooks.DeserializeSave(this,save.RailBoard);}
  public override void SerializeOnJoin(RocketBinaryWriter writer){base.SerializeOnJoin(writer);BoardStructureHooks.SerializeOnJoin(writer,this);}
  public override void DeserializeOnJoin(RocketBinaryReader reader){base.DeserializeOnJoin(reader);BoardStructureHooks.DeserializeSave(this,new PlacementBoardStructureSaveData{BoardId=reader.ReadInt64(),PrimaryHostId=reader.ReadInt64(),Position=reader.ReadGrid3(),Rotation=reader.ReadSByte()});}
 }
 public sealed class DinLogicWriterSaveData:LogicWriterSaveData {[XmlElement] public PlacementBoardStructureSaveData RailBoard;}
 public sealed class DinLogicWriter:LogicWriter,IDinLogic {
  public LogicUnitBase Logic=>this;public CabinetWiring LastWiring{get;set;}
  public PlacementBoard Board{get;set;} public PlacementBoard.BoardCell[] BoardCells{get;set;}
  public SwitchboardCabinet Cabinet=>(Board?.PrimaryHost as DinRail)?.Board?.PrimaryHost as SwitchboardCabinet;
  public override void Awake(){PrefabAudioOwner.PrepareInstance(this);base.Awake();BoardStructureHooks.Awake(this);}
  public override Grid3 GetLocalGrid()=>Board==null?default(Grid3):Board.WorldToGrid(transform.position);
  public override CanConstructInfo CanConstruct()=>DinLogicRuntime.CanPlace(this);
  protected override CanConstructInfo CanDeconstruct()=>DinLogicRuntime.CanRemove(this);
  public override bool IsPowerProvider=>false; public override bool IsPowerInputOutput=>false;
  public override double GetLogicValue(LogicType t)=>t==LogicType.RequiredPower?(IsStructureCompleted&&OnOff?UsedPower:0):base.GetLogicValue(t);
  public override float GetUsedPower(CableNetwork n)=>0; public override void UsePower(CableNetwork n,float amount){}
  public override bool AllowSetPower(CableNetwork n)=>false;
  public override void InitializeDevice(){}
  protected override void CheckConnections(){}
  public override DelayedActionInstance AttackWith(Attack attack,bool doAction=true){if(Cabinet?.CanAccessModules!=true)return null;if(Cabinet.Wiring.TryAttack(attack,doAction,out var a))return a;return base.AttackWith(attack,doAction);}
  public override bool PreventInteraction(out DelayedActionInstance fail,Interactable c,Interaction i){if(!DinLogicRuntime.Access(this)){fail=DinLogicRuntime.Denied();return true;}return base.PreventInteraction(out fail,c,i);}
  public override DelayedActionInstance InteractWith(Interactable c,Interaction i,bool doAction=true)=>!DinLogicRuntime.Access(this)?DinLogicRuntime.Denied():base.InteractWith(c,i,doAction);
  public override PassiveTooltip GetPassiveTooltip(Collider hit){var t=base.GetPassiveTooltip(hit);t.Extended+="\nDIN: 2 positions. Top: DATA IN (left), POWER (right). Bottom: DATA OUT. Native 10 W load; screwdriver selects native settings.";return t;}
  public override void OnPowerTick(){DinLogicRuntime.Power(this);base.OnPowerTick();}
  private void LateUpdate()=>DinLogicRuntime.Refresh(this);
  public override void OnDeregistered(){DinLogicRuntime.Release(this);base.OnDeregistered();if(Board!=null)BoardStructureHooks.OnDeregistered(this);}
  public override void OnDestroy(){DinLogicRuntime.Release(this);base.OnDestroy();}
  public override ThingSaveData SerializeSave(){ThingSaveData data=new DinLogicWriterSaveData();InitialiseSaveData(ref data);return data;}
  protected override void InitialiseSaveData(ref ThingSaveData data){base.InitialiseSaveData(ref data);if(data is DinLogicWriterSaveData save&&Board!=null)save.RailBoard=BoardStructureHooks.SerializeSave(this);}
  public override void DeserializeSave(ThingSaveData data){base.DeserializeSave(data);if(data is DinLogicWriterSaveData save&&save.RailBoard!=null)BoardStructureHooks.DeserializeSave(this,save.RailBoard);}
  public override void SerializeOnJoin(RocketBinaryWriter writer){base.SerializeOnJoin(writer);BoardStructureHooks.SerializeOnJoin(writer,this);}
  public override void DeserializeOnJoin(RocketBinaryReader reader){base.DeserializeOnJoin(reader);BoardStructureHooks.DeserializeSave(this,new PlacementBoardStructureSaveData{BoardId=reader.ReadInt64(),PrimaryHostId=reader.ReadInt64(),Position=reader.ReadGrid3(),Rotation=reader.ReadSByte()});}
 }
 public sealed class DinLogicBatchReaderSaveData:LogicBatchReaderSaveData {[XmlElement] public PlacementBoardStructureSaveData RailBoard;}
 public sealed class DinLogicBatchReader:LogicBatchReader,IDinLogic {
  public LogicUnitBase Logic=>this;public CabinetWiring LastWiring{get;set;}
  public PlacementBoard Board{get;set;} public PlacementBoard.BoardCell[] BoardCells{get;set;}
  public SwitchboardCabinet Cabinet=>(Board?.PrimaryHost as DinRail)?.Board?.PrimaryHost as SwitchboardCabinet;
  public override void Awake(){PrefabAudioOwner.PrepareInstance(this);base.Awake();BoardStructureHooks.Awake(this);}
  public override Grid3 GetLocalGrid()=>Board==null?default(Grid3):Board.WorldToGrid(transform.position);
  public override CanConstructInfo CanConstruct()=>DinLogicRuntime.CanPlace(this);
  protected override CanConstructInfo CanDeconstruct()=>DinLogicRuntime.CanRemove(this);
  public override bool IsPowerProvider=>false; public override bool IsPowerInputOutput=>false;
  public override double GetLogicValue(LogicType t)=>t==LogicType.RequiredPower?(IsStructureCompleted&&OnOff?UsedPower:0):base.GetLogicValue(t);
  public override float GetUsedPower(CableNetwork n)=>0; public override void UsePower(CableNetwork n,float amount){}
  public override bool AllowSetPower(CableNetwork n)=>false;
  public override void InitializeDevice(){}
  protected override void CheckConnections(){}
  public override DelayedActionInstance AttackWith(Attack attack,bool doAction=true){if(Cabinet?.CanAccessModules!=true)return null;if(Cabinet.Wiring.TryAttack(attack,doAction,out var a))return a;return base.AttackWith(attack,doAction);}
  public override bool PreventInteraction(out DelayedActionInstance fail,Interactable c,Interaction i){if(!DinLogicRuntime.Access(this)){fail=DinLogicRuntime.Denied();return true;}return base.PreventInteraction(out fail,c,i);}
  public override DelayedActionInstance InteractWith(Interactable c,Interaction i,bool doAction=true)=>!DinLogicRuntime.Access(this)?DinLogicRuntime.Denied():base.InteractWith(c,i,doAction);
  public override PassiveTooltip GetPassiveTooltip(Collider hit){var t=base.GetPassiveTooltip(hit);t.Extended+="\nDIN: 2 positions. Top: DATA IN (left), POWER (right). Bottom: DATA OUT. Native 10 W load; screwdriver selects native settings.";return t;}
  public override void OnPowerTick(){DinLogicRuntime.Power(this);base.OnPowerTick();}
  private void LateUpdate()=>DinLogicRuntime.Refresh(this);
  public override void OnDeregistered(){DinLogicRuntime.Release(this);base.OnDeregistered();if(Board!=null)BoardStructureHooks.OnDeregistered(this);}
  public override void OnDestroy(){DinLogicRuntime.Release(this);base.OnDestroy();}
  public override ThingSaveData SerializeSave(){ThingSaveData data=new DinLogicBatchReaderSaveData();InitialiseSaveData(ref data);return data;}
  protected override void InitialiseSaveData(ref ThingSaveData data){base.InitialiseSaveData(ref data);if(data is DinLogicBatchReaderSaveData save&&Board!=null)save.RailBoard=BoardStructureHooks.SerializeSave(this);}
  public override void DeserializeSave(ThingSaveData data){base.DeserializeSave(data);if(data is DinLogicBatchReaderSaveData save&&save.RailBoard!=null)BoardStructureHooks.DeserializeSave(this,save.RailBoard);}
  public override void SerializeOnJoin(RocketBinaryWriter writer){base.SerializeOnJoin(writer);BoardStructureHooks.SerializeOnJoin(writer,this);}
  public override void DeserializeOnJoin(RocketBinaryReader reader){base.DeserializeOnJoin(reader);BoardStructureHooks.DeserializeSave(this,new PlacementBoardStructureSaveData{BoardId=reader.ReadInt64(),PrimaryHostId=reader.ReadInt64(),Position=reader.ReadGrid3(),Rotation=reader.ReadSByte()});}
 }
 public sealed class DinLogicBatchWriterSaveData:LogicBatchWriterSaveData {[XmlElement] public PlacementBoardStructureSaveData RailBoard;}
 public sealed class DinLogicBatchWriter:LogicBatchWriter,IDinLogic {
  public LogicUnitBase Logic=>this;public CabinetWiring LastWiring{get;set;}
  public PlacementBoard Board{get;set;} public PlacementBoard.BoardCell[] BoardCells{get;set;}
  public SwitchboardCabinet Cabinet=>(Board?.PrimaryHost as DinRail)?.Board?.PrimaryHost as SwitchboardCabinet;
  public override void Awake(){PrefabAudioOwner.PrepareInstance(this);base.Awake();BoardStructureHooks.Awake(this);}
  public override Grid3 GetLocalGrid()=>Board==null?default(Grid3):Board.WorldToGrid(transform.position);
  public override CanConstructInfo CanConstruct()=>DinLogicRuntime.CanPlace(this);
  protected override CanConstructInfo CanDeconstruct()=>DinLogicRuntime.CanRemove(this);
  public override bool IsPowerProvider=>false; public override bool IsPowerInputOutput=>false;
  public override double GetLogicValue(LogicType t)=>t==LogicType.RequiredPower?(IsStructureCompleted&&OnOff?UsedPower:0):base.GetLogicValue(t);
  public override float GetUsedPower(CableNetwork n)=>0; public override void UsePower(CableNetwork n,float amount){}
  public override bool AllowSetPower(CableNetwork n)=>false;
  public override void InitializeDevice(){}
  protected override void CheckConnections(){}
  public override DelayedActionInstance AttackWith(Attack attack,bool doAction=true){if(Cabinet?.CanAccessModules!=true)return null;if(Cabinet.Wiring.TryAttack(attack,doAction,out var a))return a;return base.AttackWith(attack,doAction);}
  public override bool PreventInteraction(out DelayedActionInstance fail,Interactable c,Interaction i){if(!DinLogicRuntime.Access(this)){fail=DinLogicRuntime.Denied();return true;}return base.PreventInteraction(out fail,c,i);}
  public override DelayedActionInstance InteractWith(Interactable c,Interaction i,bool doAction=true)=>!DinLogicRuntime.Access(this)?DinLogicRuntime.Denied():base.InteractWith(c,i,doAction);
  public override PassiveTooltip GetPassiveTooltip(Collider hit){var t=base.GetPassiveTooltip(hit);t.Extended+="\nDIN: 2 positions. Top: DATA IN (left), POWER (right). Bottom: DATA OUT. Native 10 W load; screwdriver selects native settings.";return t;}
  public override void OnPowerTick(){DinLogicRuntime.Power(this);base.OnPowerTick();}
  private void LateUpdate()=>DinLogicRuntime.Refresh(this);
  public override void OnDeregistered(){DinLogicRuntime.Release(this);base.OnDeregistered();if(Board!=null)BoardStructureHooks.OnDeregistered(this);}
  public override void OnDestroy(){DinLogicRuntime.Release(this);base.OnDestroy();}
  public override ThingSaveData SerializeSave(){ThingSaveData data=new DinLogicBatchWriterSaveData();InitialiseSaveData(ref data);return data;}
  protected override void InitialiseSaveData(ref ThingSaveData data){base.InitialiseSaveData(ref data);if(data is DinLogicBatchWriterSaveData save&&Board!=null)save.RailBoard=BoardStructureHooks.SerializeSave(this);}
  public override void DeserializeSave(ThingSaveData data){base.DeserializeSave(data);if(data is DinLogicBatchWriterSaveData save&&save.RailBoard!=null)BoardStructureHooks.DeserializeSave(this,save.RailBoard);}
  public override void SerializeOnJoin(RocketBinaryWriter writer){base.SerializeOnJoin(writer);BoardStructureHooks.SerializeOnJoin(writer,this);}
  public override void DeserializeOnJoin(RocketBinaryReader reader){base.DeserializeOnJoin(reader);BoardStructureHooks.DeserializeSave(this,new PlacementBoardStructureSaveData{BoardId=reader.ReadInt64(),PrimaryHostId=reader.ReadInt64(),Position=reader.ReadGrid3(),Rotation=reader.ReadSByte()});}
 }
 public sealed class DinLogicSlotReaderSaveData:LogicSlotReaderSaveData {[XmlElement] public PlacementBoardStructureSaveData RailBoard;}
 public sealed class DinLogicSlotReader:LogicSlotReader,IDinLogic {
  public LogicUnitBase Logic=>this;public CabinetWiring LastWiring{get;set;}
  public PlacementBoard Board{get;set;} public PlacementBoard.BoardCell[] BoardCells{get;set;}
  public SwitchboardCabinet Cabinet=>(Board?.PrimaryHost as DinRail)?.Board?.PrimaryHost as SwitchboardCabinet;
  public override void Awake(){PrefabAudioOwner.PrepareInstance(this);base.Awake();BoardStructureHooks.Awake(this);}
  public override Grid3 GetLocalGrid()=>Board==null?default(Grid3):Board.WorldToGrid(transform.position);
  public override CanConstructInfo CanConstruct()=>DinLogicRuntime.CanPlace(this);
  protected override CanConstructInfo CanDeconstruct()=>DinLogicRuntime.CanRemove(this);
  public override bool IsPowerProvider=>false; public override bool IsPowerInputOutput=>false;
  public override double GetLogicValue(LogicType t)=>t==LogicType.RequiredPower?(IsStructureCompleted&&OnOff?UsedPower:0):base.GetLogicValue(t);
  public override float GetUsedPower(CableNetwork n)=>0; public override void UsePower(CableNetwork n,float amount){}
  public override bool AllowSetPower(CableNetwork n)=>false;
  public override void InitializeDevice(){}
  protected override void CheckConnections(){}
  public override DelayedActionInstance AttackWith(Attack attack,bool doAction=true){if(Cabinet?.CanAccessModules!=true)return null;if(Cabinet.Wiring.TryAttack(attack,doAction,out var a))return a;return base.AttackWith(attack,doAction);}
  public override bool PreventInteraction(out DelayedActionInstance fail,Interactable c,Interaction i){if(!DinLogicRuntime.Access(this)){fail=DinLogicRuntime.Denied();return true;}return base.PreventInteraction(out fail,c,i);}
  public override DelayedActionInstance InteractWith(Interactable c,Interaction i,bool doAction=true)=>!DinLogicRuntime.Access(this)?DinLogicRuntime.Denied():base.InteractWith(c,i,doAction);
  public override PassiveTooltip GetPassiveTooltip(Collider hit){var t=base.GetPassiveTooltip(hit);t.Extended+="\nDIN: 2 positions. Top: DATA IN (left), POWER (right). Bottom: DATA OUT. Native 10 W load; screwdriver selects native settings.";return t;}
  public override void OnPowerTick(){DinLogicRuntime.Power(this);base.OnPowerTick();}
  private void LateUpdate()=>DinLogicRuntime.Refresh(this);
  public override void OnDeregistered(){DinLogicRuntime.Release(this);base.OnDeregistered();if(Board!=null)BoardStructureHooks.OnDeregistered(this);}
  public override void OnDestroy(){DinLogicRuntime.Release(this);base.OnDestroy();}
  public override ThingSaveData SerializeSave(){ThingSaveData data=new DinLogicSlotReaderSaveData();InitialiseSaveData(ref data);return data;}
  protected override void InitialiseSaveData(ref ThingSaveData data){base.InitialiseSaveData(ref data);if(data is DinLogicSlotReaderSaveData save&&Board!=null)save.RailBoard=BoardStructureHooks.SerializeSave(this);}
  public override void DeserializeSave(ThingSaveData data){base.DeserializeSave(data);if(data is DinLogicSlotReaderSaveData save&&save.RailBoard!=null)BoardStructureHooks.DeserializeSave(this,save.RailBoard);}
  public override void SerializeOnJoin(RocketBinaryWriter writer){base.SerializeOnJoin(writer);BoardStructureHooks.SerializeOnJoin(writer,this);}
  public override void DeserializeOnJoin(RocketBinaryReader reader){base.DeserializeOnJoin(reader);BoardStructureHooks.DeserializeSave(this,new PlacementBoardStructureSaveData{BoardId=reader.ReadInt64(),PrimaryHostId=reader.ReadInt64(),Position=reader.ReadGrid3(),Rotation=reader.ReadSByte()});}
 }
 public sealed class DinLogicBatchSlotReaderSaveData:LogicBatchSlotReaderSaveData {[XmlElement] public PlacementBoardStructureSaveData RailBoard;}
 public sealed class DinLogicBatchSlotReader:LogicBatchSlotReader,IDinLogic {
  public LogicUnitBase Logic=>this;public CabinetWiring LastWiring{get;set;}
  public PlacementBoard Board{get;set;} public PlacementBoard.BoardCell[] BoardCells{get;set;}
  public SwitchboardCabinet Cabinet=>(Board?.PrimaryHost as DinRail)?.Board?.PrimaryHost as SwitchboardCabinet;
  public override void Awake(){PrefabAudioOwner.PrepareInstance(this);base.Awake();BoardStructureHooks.Awake(this);}
  public override Grid3 GetLocalGrid()=>Board==null?default(Grid3):Board.WorldToGrid(transform.position);
  public override CanConstructInfo CanConstruct()=>DinLogicRuntime.CanPlace(this);
  protected override CanConstructInfo CanDeconstruct()=>DinLogicRuntime.CanRemove(this);
  public override bool IsPowerProvider=>false; public override bool IsPowerInputOutput=>false;
  public override double GetLogicValue(LogicType t)=>t==LogicType.RequiredPower?(IsStructureCompleted&&OnOff?UsedPower:0):base.GetLogicValue(t);
  public override float GetUsedPower(CableNetwork n)=>0; public override void UsePower(CableNetwork n,float amount){}
  public override bool AllowSetPower(CableNetwork n)=>false;
  public override void InitializeDevice(){}
  protected override void CheckConnections(){}
  public override DelayedActionInstance AttackWith(Attack attack,bool doAction=true){if(Cabinet?.CanAccessModules!=true)return null;if(Cabinet.Wiring.TryAttack(attack,doAction,out var a))return a;return base.AttackWith(attack,doAction);}
  public override bool PreventInteraction(out DelayedActionInstance fail,Interactable c,Interaction i){if(!DinLogicRuntime.Access(this)){fail=DinLogicRuntime.Denied();return true;}return base.PreventInteraction(out fail,c,i);}
  public override DelayedActionInstance InteractWith(Interactable c,Interaction i,bool doAction=true)=>!DinLogicRuntime.Access(this)?DinLogicRuntime.Denied():base.InteractWith(c,i,doAction);
  public override PassiveTooltip GetPassiveTooltip(Collider hit){var t=base.GetPassiveTooltip(hit);t.Extended+="\nDIN: 2 positions. Top: DATA IN (left), POWER (right). Bottom: DATA OUT. Native 10 W load; screwdriver selects native settings.";return t;}
  public override void OnPowerTick(){DinLogicRuntime.Power(this);base.OnPowerTick();}
  private void LateUpdate()=>DinLogicRuntime.Refresh(this);
  public override void OnDeregistered(){DinLogicRuntime.Release(this);base.OnDeregistered();if(Board!=null)BoardStructureHooks.OnDeregistered(this);}
  public override void OnDestroy(){DinLogicRuntime.Release(this);base.OnDestroy();}
  public override ThingSaveData SerializeSave(){ThingSaveData data=new DinLogicBatchSlotReaderSaveData();InitialiseSaveData(ref data);return data;}
  protected override void InitialiseSaveData(ref ThingSaveData data){base.InitialiseSaveData(ref data);if(data is DinLogicBatchSlotReaderSaveData save&&Board!=null)save.RailBoard=BoardStructureHooks.SerializeSave(this);}
  public override void DeserializeSave(ThingSaveData data){base.DeserializeSave(data);if(data is DinLogicBatchSlotReaderSaveData save&&save.RailBoard!=null)BoardStructureHooks.DeserializeSave(this,save.RailBoard);}
  public override void SerializeOnJoin(RocketBinaryWriter writer){base.SerializeOnJoin(writer);BoardStructureHooks.SerializeOnJoin(writer,this);}
  public override void DeserializeOnJoin(RocketBinaryReader reader){base.DeserializeOnJoin(reader);BoardStructureHooks.DeserializeSave(this,new PlacementBoardStructureSaveData{BoardId=reader.ReadInt64(),PrimaryHostId=reader.ReadInt64(),Position=reader.ReadGrid3(),Rotation=reader.ReadSByte()});}
 }
 public sealed class DinLogicReagentReaderSaveData:LogicReagentReaderSaveData {[XmlElement] public PlacementBoardStructureSaveData RailBoard;}
 public sealed class DinLogicReagentReader:ReagentReader,IDinLogic {
  public LogicUnitBase Logic=>this;public CabinetWiring LastWiring{get;set;}
  public PlacementBoard Board{get;set;} public PlacementBoard.BoardCell[] BoardCells{get;set;}
  public SwitchboardCabinet Cabinet=>(Board?.PrimaryHost as DinRail)?.Board?.PrimaryHost as SwitchboardCabinet;
  public override void Awake(){PrefabAudioOwner.PrepareInstance(this);base.Awake();BoardStructureHooks.Awake(this);}
  public override Grid3 GetLocalGrid()=>Board==null?default(Grid3):Board.WorldToGrid(transform.position);
  public override CanConstructInfo CanConstruct()=>DinLogicRuntime.CanPlace(this);
  protected override CanConstructInfo CanDeconstruct()=>DinLogicRuntime.CanRemove(this);
  public override bool IsPowerProvider=>false; public override bool IsPowerInputOutput=>false;
  public override double GetLogicValue(LogicType t)=>t==LogicType.RequiredPower?(IsStructureCompleted&&OnOff?UsedPower:0):base.GetLogicValue(t);
  public override float GetUsedPower(CableNetwork n)=>0; public override void UsePower(CableNetwork n,float amount){}
  public override bool AllowSetPower(CableNetwork n)=>false;
  public override void InitializeDevice(){}
  protected override void CheckConnections(){}
  public override DelayedActionInstance AttackWith(Attack attack,bool doAction=true){if(Cabinet?.CanAccessModules!=true)return null;if(Cabinet.Wiring.TryAttack(attack,doAction,out var a))return a;return base.AttackWith(attack,doAction);}
  public override bool PreventInteraction(out DelayedActionInstance fail,Interactable c,Interaction i){if(!DinLogicRuntime.Access(this)){fail=DinLogicRuntime.Denied();return true;}return base.PreventInteraction(out fail,c,i);}
  public override DelayedActionInstance InteractWith(Interactable c,Interaction i,bool doAction=true)=>!DinLogicRuntime.Access(this)?DinLogicRuntime.Denied():base.InteractWith(c,i,doAction);
  public override PassiveTooltip GetPassiveTooltip(Collider hit){var t=base.GetPassiveTooltip(hit);t.Extended+="\nDIN: 2 positions. Top: DATA IN (left), POWER (right). Bottom: DATA OUT. Native 10 W load; screwdriver selects native settings.";return t;}
  public override void OnPowerTick(){DinLogicRuntime.Power(this);base.OnPowerTick();}
  private void LateUpdate()=>DinLogicRuntime.Refresh(this);
  public override void OnDeregistered(){DinLogicRuntime.Release(this);base.OnDeregistered();if(Board!=null)BoardStructureHooks.OnDeregistered(this);}
  public override void OnDestroy(){DinLogicRuntime.Release(this);base.OnDestroy();}
  public override ThingSaveData SerializeSave(){ThingSaveData data=new DinLogicReagentReaderSaveData();InitialiseSaveData(ref data);return data;}
  protected override void InitialiseSaveData(ref ThingSaveData data){base.InitialiseSaveData(ref data);if(data is DinLogicReagentReaderSaveData save&&Board!=null)save.RailBoard=BoardStructureHooks.SerializeSave(this);}
  public override void DeserializeSave(ThingSaveData data){base.DeserializeSave(data);if(data is DinLogicReagentReaderSaveData save&&save.RailBoard!=null)BoardStructureHooks.DeserializeSave(this,save.RailBoard);}
  public override void SerializeOnJoin(RocketBinaryWriter writer){base.SerializeOnJoin(writer);BoardStructureHooks.SerializeOnJoin(writer,this);}
  public override void DeserializeOnJoin(RocketBinaryReader reader){base.DeserializeOnJoin(reader);BoardStructureHooks.DeserializeSave(this,new PlacementBoardStructureSaveData{BoardId=reader.ReadInt64(),PrimaryHostId=reader.ReadInt64(),Position=reader.ReadGrid3(),Rotation=reader.ReadSByte()});}
 }
 public sealed class DinLogicMirrorSaveData:LogicMirrorSaveData {[XmlElement] public PlacementBoardStructureSaveData RailBoard;}
 public sealed class DinLogicMirror:LogicMirror,IDinLogic {
  public LogicUnitBase Logic=>this;public CabinetWiring LastWiring{get;set;}
  public PlacementBoard Board{get;set;} public PlacementBoard.BoardCell[] BoardCells{get;set;}
  public SwitchboardCabinet Cabinet=>(Board?.PrimaryHost as DinRail)?.Board?.PrimaryHost as SwitchboardCabinet;
  public override void Awake(){PrefabAudioOwner.PrepareInstance(this);base.Awake();BoardStructureHooks.Awake(this);}
  public override Grid3 GetLocalGrid()=>Board==null?default(Grid3):Board.WorldToGrid(transform.position);
  public override CanConstructInfo CanConstruct()=>DinLogicRuntime.CanPlace(this);
  protected override CanConstructInfo CanDeconstruct()=>DinLogicRuntime.CanRemove(this);
  public override bool IsPowerProvider=>false; public override bool IsPowerInputOutput=>false;
  public override float GetUsedPower(CableNetwork n)=>0; public override void UsePower(CableNetwork n,float amount){}
  public override bool AllowSetPower(CableNetwork n)=>false;
  public override void InitializeDevice(){}
  protected override void CheckConnections(){}
  public override DelayedActionInstance AttackWith(Attack attack,bool doAction=true){if(Cabinet?.CanAccessModules!=true)return null;if(Cabinet.Wiring.TryAttack(attack,doAction,out var a))return a;return base.AttackWith(attack,doAction);}
  public override bool PreventInteraction(out DelayedActionInstance fail,Interactable c,Interaction i){if(!DinLogicRuntime.Access(this)){fail=DinLogicRuntime.Denied();return true;}return base.PreventInteraction(out fail,c,i);}
  public override DelayedActionInstance InteractWith(Interactable c,Interaction i,bool doAction=true)=>!DinLogicRuntime.Access(this)?DinLogicRuntime.Denied():base.InteractWith(c,i,doAction);
  public override PassiveTooltip GetPassiveTooltip(Collider hit){var t=base.GetPassiveTooltip(hit);t.Extended+="\nDIN: 2 positions. Top: DATA IN (left), POWER (right). Bottom: DATA OUT. Native 10 W load; screwdriver selects native settings.";return t;}
  public override void OnPowerTick(){DinLogicRuntime.Power(this);base.OnPowerTick();}
  private void LateUpdate()=>DinLogicRuntime.Refresh(this);
  public override void OnDeregistered(){DinLogicRuntime.Release(this);base.OnDeregistered();if(Board!=null)BoardStructureHooks.OnDeregistered(this);}
  public override void OnDestroy(){DinLogicRuntime.Release(this);base.OnDestroy();}
  public override ThingSaveData SerializeSave(){ThingSaveData data=new DinLogicMirrorSaveData();InitialiseSaveData(ref data);return data;}
  protected override void InitialiseSaveData(ref ThingSaveData data){base.InitialiseSaveData(ref data);if(data is DinLogicMirrorSaveData save&&Board!=null)save.RailBoard=BoardStructureHooks.SerializeSave(this);}
  public override void DeserializeSave(ThingSaveData data){base.DeserializeSave(data);if(data is DinLogicMirrorSaveData save&&save.RailBoard!=null)BoardStructureHooks.DeserializeSave(this,save.RailBoard);}
  public override void SerializeOnJoin(RocketBinaryWriter writer){base.SerializeOnJoin(writer);BoardStructureHooks.SerializeOnJoin(writer,this);}
  public override void DeserializeOnJoin(RocketBinaryReader reader){base.DeserializeOnJoin(reader);BoardStructureHooks.DeserializeSave(this,new PlacementBoardStructureSaveData{BoardId=reader.ReadInt64(),PrimaryHostId=reader.ReadInt64(),Position=reader.ReadGrid3(),Rotation=reader.ReadSByte()});}
 }
}
