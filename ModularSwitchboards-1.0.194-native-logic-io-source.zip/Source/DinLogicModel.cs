using System;using System.IO;using System.Linq;using System.Reflection;using System.Collections.Generic;
using Assets.Scripts;using Assets.Scripts.Objects.Motherboards;using Assets.Scripts.Objects;using Assets.Scripts.Objects.Electrical;using Assets.Scripts.Util;using Assets.Scripts.UI;using HarmonyLib;using Rendering;using UnityEngine;using UnityEngine.Rendering;
namespace ModularSwitchboards {
 internal static class DinLogicModel {
  internal const float Center=.02025f;
  internal static Vector3 Entry(int pin)=>new Vector3(Center+(pin==0?.018f:pin==2?-.018f:0),pin==1?-.050625f:.050625f,.03335f);
  internal static Vector3 Aim(int pin)=>new Vector3(Entry(pin).x,pin==1?-.042f:.042f,.0685f);
  private static readonly Dictionary<string,Dictionary<string,Mesh>> Cache=new Dictionary<string,Dictionary<string,Mesh>>();
  private static string ReadString(BinaryReader r){int n=r.ReadInt32();if(n<0||n>4096)throw new InvalidDataException("Invalid logic mesh path");return System.Text.Encoding.UTF8.GetString(r.ReadBytes(n));}
  private static Dictionary<string,Mesh> Meshes(string native){
   if(Cache.TryGetValue(native,out var found))return found;var result=new Dictionary<string,Mesh>();
   using(var s=Assembly.GetExecutingAssembly().GetManifestResourceStream("ModularSwitchboards.LogicIO."+native+".meshbin"))using(var r=new BinaryReader(s??throw new InvalidOperationException("Missing captured logic mesh "+native))){
    if(r.ReadInt32()!=0x4c494f31)throw new InvalidDataException("Unknown logic mesh format");int count=r.ReadInt32();for(int a=0;a<count;a++){string path=ReadString(r);int n=r.ReadInt32();var vs=new Vector3[n];var uv=new Vector2[n];for(int i=0;i<n;i++){vs[i]=new Vector3(r.ReadSingle(),r.ReadSingle(),r.ReadSingle());uv[i]=new Vector2(r.ReadSingle(),r.ReadSingle());}var m=new Mesh{name="Switchboards.NativeLogic."+native+"."+path};m.vertices=vs;m.uv=uv;m.subMeshCount=r.ReadInt32();for(int j=0;j<m.subMeshCount;j++){var ts=new int[r.ReadInt32()];for(int i=0;i<ts.Length;i++)ts[i]=r.ReadInt32();m.SetTriangles(ts,j);}m.RecalculateNormals();m.RecalculateTangents();m.RecalculateBounds();result[path]=m;}}
   Cache[native]=result;return result;
  }
  private static void BlackPart(Transform parent,string name,Vector3 point,Vector3 size){var g=new GameObject(name){layer=parent.gameObject.layer};g.transform.SetParent(parent,false);g.transform.localPosition=point;g.AddComponent<MeshFilter>().sharedMesh=DinBreakerModel.ControlMesh(name,Vector3.zero,size);var r=g.AddComponent<MeshRenderer>();r.sharedMaterials=Enumerable.Repeat(CabinetGeometry.Materials[3],5).ToArray();var b=new MaterialPropertyBlock();b.SetFloat(Thing.DiffuseIndexPropertyID,(int)ColorType.Black);b.SetColor(Thing.EMISSION_COLOR,Color.black);r.SetPropertyBlock(b);}
  internal static void Install(LogicUnitBase m,string native,Transform storage){
   var assets=Meshes(native);var rootFilter=m.GetComponent<MeshFilter>();var rootRenderer=m.GetComponent<MeshRenderer>();if(rootFilter==null||rootRenderer==null)throw new InvalidOperationException("Native logic front renderer missing");
   // Replace native GPU-only meshes with the exact captured CPU geometry for cursor/headless support.
   foreach(var pair in assets){if(pair.Key.Length==0)continue;var f=m.transform.Find(pair.Key)?.GetComponent<MeshFilter>();if(f==null)throw new InvalidOperationException("Native logic child missing: "+pair.Key);f.sharedMesh=pair.Value;}
   var face=new GameObject("NativeLogicFace"){layer=m.gameObject.layer};face.transform.SetParent(m.transform,false);
   face.AddComponent<MeshFilter>().sharedMesh=assets[""];var front=face.AddComponent<MeshRenderer>();front.sharedMaterials=rootRenderer.sharedMaterials;
   var mpb=new MaterialPropertyBlock();rootRenderer.GetPropertyBlock(mpb);front.SetPropertyBlock(mpb);
   foreach(var child in m.transform.Cast<Transform>().Where(t=>t!=face.transform).ToArray())child.SetParent(face.transform,false);
   foreach(var stage in m.BuildStates){if(stage.Visualizer==rootRenderer)stage.Visualizer=front;}
   UnityEngine.Object.DestroyImmediate(rootFilter);UnityEngine.Object.DestroyImmediate(rootRenderer);
   face.transform.localScale=Vector3.one*.16f;face.transform.localPosition=new Vector3(Center,0,.066f);
   // Native substrate/connection colliders are replaced; original screw and ON/OFF hitboxes remain.
   var controls=new HashSet<Collider>(m.Interactables.Where(i=>i.Collider!=null).Select(i=>i.Collider));
   foreach(var hit in m.GetComponentsInChildren<Collider>(true))if(!controls.Contains(hit))UnityEngine.Object.DestroyImmediate(hit);
   var body=new GameObject("DinBreakerModel"){layer=m.gameObject.layer};body.transform.SetParent(m.transform,false);body.transform.localScale=DinBreakerModel.VisualScale;
   var mesh=DinBreakerModel.Build(width:(DinLayout.SlotPitch*2-.0009f)/DinBreakerModel.VisualScale.x,centerX:Center/DinBreakerModel.VisualScale.x,plain:true,noTerminals:true);
   body.AddComponent<MeshFilter>().sharedMesh=mesh;var renderer=body.AddComponent<MeshRenderer>();renderer.sharedMaterials=CabinetGeometry.Materials;
   var box=body.AddComponent<BoxCollider>();box.center=mesh.bounds.center;box.size=mesh.bounds.size;
   m._staticColliders=new List<Collider>{box};m._dynamicColliders=new List<Collider>();m._selfColliders=new List<Collider>();
   for(int pin=0;pin<3;pin++){
    var go=new GameObject(pin==0?"LogicDataIn":pin==1?"LogicDataOut":"LogicPower"){layer=m.gameObject.layer};go.transform.SetParent(m.transform,false);go.transform.localPosition=Aim(pin);
    var screw=DinBreakerModel.ControlMesh("LogicTerminalScrew",Vector3.zero,new Vector3(.011f,.008f,.0018f));go.AddComponent<MeshFilter>().sharedMesh=screw;var sr=go.AddComponent<MeshRenderer>();sr.sharedMaterials=Enumerable.Repeat(CabinetGeometry.Materials[4],5).ToArray();var block=new MaterialPropertyBlock();block.SetFloat(Thing.DiffuseIndexPropertyID,(int)ColorType.Gray);block.SetColor(Thing.EMISSION_COLOR,Color.black);sr.SetPropertyBlock(block);
    BlackPart(go.transform,"ScrewRecess",new Vector3(0,0,-.0012f),new Vector3(.014f,.012f,.002f));
    BlackPart(go.transform,"ScrewSlot",new Vector3(0,0,.001f),new Vector3(.008f,.001f,.0003f));
    BlackPart(m.transform,"CableSocket"+pin,new Vector3(Entry(pin).x,Entry(pin).y+(pin==1?.00135f:-.00135f),Entry(pin).z),new Vector3(.014f,.003f,.012f));
    var h=go.AddComponent<BoxCollider>();h.size=new Vector3(.014f,.012f,.008f);m._staticColliders.Add(h);
    var c=m.OpenEnds[pin];var anchor=new GameObject("LogicCableEntry"+pin).transform;anchor.SetParent(m.transform,false);anchor.localPosition=Entry(pin);anchor.localRotation=Quaternion.LookRotation(pin==1?Vector3.up:Vector3.down,Vector3.forward);c.Transform=anchor;c.Collider=h;c.Parent=m;
   }
   m.Bounds=new Bounds(new Vector3(Center,0,.041f),new Vector3(.0801f,.10125f,.084f));m.GridBounds=new GridBounds(m);m.UseCellPosition=false;m.ForceGridBounds.Clear();m.StructureCollisionType=CollisionType.BlockCustom;m.SelectionDisplay=SelectionHighlightMethod.Bounds;m.SurfaceArea=.032f;m.UpgradePrefab=null;
   m.CustomColor=GameManager.GetColorSwatch((int)ColorType.White);m.EmissionColor=Color.black;DinBreakerModel.Refresh(m);
   m.HasColorState=false;m.MPBRenderers.Clear();m.PaintableMaterial=null;m.structureRenderMode=StructureRenderMode.Standard;
   m.Renderers=m.GetComponentsInChildren<MeshRenderer>(true).Select(rr=>new ThingRenderer(m,rr)).ToList();
   foreach(var c in m.Interactables)c.CacheBounds();
   var state=m.BuildStates[0];state.Visualizer=renderer;state.RendererInstance=null;state.StateMeshes=new List<Mesh>();state.Colliders=m.GetComponentsInChildren<Collider>(true).ToList();state.Interactables=m.Interactables;
   state.LinkedGameObjects=m.GetComponentsInChildren<Transform>(true).Where(t=>t!=m.transform).Select(t=>t.gameObject).ToList();state.RenderMode=BuildStateRenderMode.OnMineAndPreviousStates;
   AccessTools.Field(typeof(BuildState),"initialDrawData").SetValue(state,new DrawData{mesh=null,materials=new Material[0]});m.CacheStates(true);
   var all=ModelBlueprint.Build(m.transform,includeDisabled:true);FittedModelCollider.Install(m,all);foreach(var c in state.Colliders)if(c!=null&&!state.LinkedGameObjects.Contains(c.gameObject))state.LinkedGameObjects.Add(c.gameObject);
   var bp=new GameObject("DinLogicBlueprint"){layer=m.gameObject.layer};bp.transform.SetParent(storage,false);var f0=bp.AddComponent<MeshFilter>();f0.sharedMesh=all;var r0=bp.AddComponent<MeshRenderer>();r0.sharedMaterial=CabinetGeometry.Materials[4];var wire=bp.AddComponent<Wireframe>();wire.BlueprintTransform=bp.transform;wire.BlueprintBounds=all.bounds;wire.BlueprintMeshFilter=f0;wire.BlueprintRenderer=r0;bp.AddComponent<CabinetBlueprint>();m.Blueprint=bp;m.BlueprintOrientVector=Vector3.zero;
  }
 }
}
