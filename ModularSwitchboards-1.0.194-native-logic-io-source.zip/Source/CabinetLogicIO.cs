using System;using System.Collections.Generic;using System.Linq;
using Assets.Scripts.Objects;using Assets.Scripts.Objects.Electrical;using Assets.Scripts.Networks;using UnityEngine;
namespace ModularSwitchboards {
 public sealed partial class CabinetWiring {
  internal IEnumerable<IDinLogic> LogicModules=>Owner.RailBoard==null?Enumerable.Empty<IDinLogic>():Owner.RailBoard.Structures.OfType<DinRail>().Where(r=>r.Modules!=null).SelectMany(r=>r.Modules.Structures.OfType<IDinLogic>()).Where(m=>!m.Logic.IsBeingDestroyed);
  private IEnumerable<long> LogicIds=>LogicModules.Select(m=>m.Logic.ReferenceId);
  private readonly Dictionary<string,DinLogicDataView> logicViews=new Dictionary<string,DinLogicDataView>();private float nextLogicRefresh;
  private bool LogicData(CabinetWireEnd e)=>DinLogicCircuit.Data(e,LogicIds);
  private bool LogicEdge(CabinetWireEnd a,CabinetWireEnd b)=>DinLogicCircuit.Allowed(a,b,LogicIds);
  private bool LogicWireReady(CabinetWireSaveData w)=>LogicEdge(w.From,w.To)&&WireEndpointReady(w.From)&&WireEndpointReady(w.To);
  private Cable[] LogicAnchors(CabinetWireEnd[] component)=>component.Where(DinLogicCircuit.External).Select(e=>(e.Contact==1?Owner.Output1Connection:e.Contact==2?Owner.Output2Connection:Owner.Output3Connection)?.GetCable()).Where(c=>c?.CableNetwork!=null).Distinct().ToArray();
  private bool CanConnectLogic(CabinetWireEnd a,CabinetWireEnd b,out string reason){
   reason=null;if(!LogicEdge(a,b)){reason="Logic DATA connects to Logic DATA or an external Output data terminal; POWER must stay separate.";return false;}
   if(wires.Any(w=>w.From.Equals(a)&&w.To.Equals(b)||w.From.Equals(b)&&w.To.Equals(a))){reason="These data contacts are already connected.";return false;}
   foreach(var e in new[]{a,b}){int used=wires.Count(w=>(w.From.Equals(e)||w.To.Equals(e))&&(e.Owner!=0||w.LogicData||WireDataTap.Stored(w)));if(used>=(e.Owner==0?1:3)){reason="Data contact occupied.";return false;}}
   var candidate=new CabinetWireSaveData{From=a,To=b,LogicData=true};var comp=DinLogicCircuit.Component(a,wires.Concat(new[]{candidate}));
   if(LogicAnchors(comp).Select(c=>c.CableNetwork).Distinct().Count()>1){reason="Keep external data networks separate; this would join different networks.";return false;}return true;
  }
  private bool ValidLoadedLogic(CabinetWireSaveData w){bool Shape(CabinetWireEnd e)=>e.Owner==0?DinLogicCircuit.External(e):e.Contact==0||e.Contact==1;return !wires.Any(x=>x.From.Equals(w.From)&&x.To.Equals(w.To)||x.From.Equals(w.To)&&x.To.Equals(w.From))&&Shape(w.From)&&Shape(w.To)&&!w.From.Equals(w.To)&&(w.From.Owner!=0||w.To.Owner!=0)&&new[]{w.From,w.To}.All(e=>wires.Count(x=>x.LogicData&&(x.From.Equals(e)||x.To.Equals(e)))<(e.Owner==0?1:3));}
  internal void RefreshLogicNetworks(){
   if(Time.unscaledTime<nextLogicRefresh)return;nextLogicRefresh=Time.unscaledTime+.1f;
   var modules=LogicModules.ToArray();var valid=wires.Where(w=>w.LogicData&&!w.Burnt&&LogicWireReady(w)).ToArray();var used=new HashSet<string>();
   var nets=new Dictionary<CabinetWireEnd,CableNetwork>();var anchors=new Dictionary<CabinetWireEnd,Cable[]>();var changed=new HashSet<CableNetwork>();
   foreach(var module in modules.Where(m=>!m.Logic.IsCursor&&m.Logic.IsStructureCompleted))for(int pin=0;pin<2;pin++){
    var end=new CabinetWireEnd(module.Logic.ReferenceId,pin);if(nets.ContainsKey(end)||!valid.Any(w=>w.From.Equals(end)||w.To.Equals(end)))continue;
    var component=DinLogicCircuit.Component(end,valid);var cables=LogicAnchors(component);if(cables.Select(c=>c.CableNetwork).Distinct().Count()>1)continue;
    var key=string.Join(";",component.Select(e=>e.Owner+"/"+e.Contact));used.Add(key);if(!logicViews.TryGetValue(key,out var view))logicViews[key]=view=new DinLogicDataView();
    var devices=modules.Where(m=>component.Any(e=>e.Owner==m.Logic.ReferenceId)&&m.Logic.IsStructureCompleted&&!m.Logic.IsCursor).Select(m=>(Assets.Scripts.Objects.Pipes.Device)m.Logic).Concat(cables.SelectMany(c=>c.CableNetwork.DataDeviceList));
    if(view.Update(devices))changed.Add(view);
    foreach(var e in component){nets[e]=view;anchors[e]=cables;}
   }
   foreach(var m in modules){var input=new CabinetWireEnd(m.Logic.ReferenceId,0);var output=new CabinetWireEnd(m.Logic.ReferenceId,1);nets.TryGetValue(input,out var i);nets.TryGetValue(output,out var o);var cs=(anchors.TryGetValue(input,out var a)?a:Array.Empty<Cable>()).Concat(anchors.TryGetValue(output,out var b)?b:Array.Empty<Cable>()).ToArray();DinLogicNetwork.Bind(m.Logic,cs,i,o,changed.Contains(i)||changed.Contains(o));}
   foreach(var key in logicViews.Keys.Where(k=>!used.Contains(k)).ToArray())logicViews.Remove(key);
  }
  private void AddLogicContacts(){foreach(var m in LogicModules){var d=m.Logic;var min=Shell.InverseTransformPoint(d.transform.TransformPoint(new Vector3(-.0198f,-.050625f,0)));var max=Shell.InverseTransformPoint(d.transform.TransformPoint(new Vector3(.0603f,.050625f,0)));var bounds=new WireRect(Math.Min(min.x,max.x),Math.Max(min.x,max.x),Math.Min(min.y,max.y),Math.Max(min.y,max.y));for(int pin=0;pin<3;pin++){var p=Shell.InverseTransformPoint(d.transform.TransformPoint(DinLogicModel.Entry(pin)));var aim=Shell.InverseTransformPoint(d.transform.TransformPoint(DinLogicModel.Aim(pin)));AddContact(new CabinetWireEnd(d.ReferenceId,pin),p,aim,new Vector3(p.x,pin==1?bounds.Bottom-.016f:bounds.Top+.016f,WireRouting.Plane),bounds);}}}
 }
}
