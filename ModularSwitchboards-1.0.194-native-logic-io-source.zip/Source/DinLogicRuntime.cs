using System;
using DelayedActionInstance=Assets.Scripts.Objects.Thing.DelayedActionInstance;
using System.Linq;
using System.Collections.Generic;
using Assets.Scripts;
using Assets.Scripts.Networking;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Electrical;
using Assets.Scripts.Objects.Pipes;
using Assets.Scripts.Networks;
using LibConstruct;
using UnityEngine;
namespace ModularSwitchboards {
 internal static class DinLogicRuntime {
  internal const int Slots=2;internal const string Kit="ItemKitDinLogicIO";
  internal static bool Access(IDinLogic m)=>!m.Logic.IsCursor&&!m.Logic.IsBeingDestroyed&&m.Cabinet?.CanAccessModules==true;
  internal static DelayedActionInstance Denied()=>new DelayedActionInstance{Duration=0}.Fail("Open the cabinet and remove its cover first.");
  internal static CanConstructInfo CanPlace(IDinLogic mount){
   var m=mount.Logic;if(m.IsCursor){MountPlacement.AfterRaycast();MountBoardResolver.Resolve(CursorManager.Instance);}
   if(!(mount.Board is DinModuleBoard board)||!(board.PrimaryHost is DinRail rail))return CanConstructInfo.InvalidPlacement("Choose two free DIN positions inside an open cabinet.");
   var p=board.WorldToGrid(m.transform.position);
   if(m.IsCursor){if(MountPlacement.TryLockedGrid(m,board,out var locked))p=locked;else p=new Grid3(DoorModuleLayout.SnapSlot(p.x,DinLayout.FirstModuleSlot*10,(DinLayout.FirstModuleSlot+rail.ModuleCapacity-Slots)*10),0,0);PlacementBoard.CursorGrid=p;PlacementBoard.CursorRotation=0;m.transform.SetPositionAndRotation(board.GridToWorld(p),board.IndexToRotation(0));}
   return board.CanPlace(p,board.RotationToIndex(m.transform.rotation),Slots)?CanConstructInfo.ValidPlacement:CanConstructInfo.InvalidPlacement("Both DIN positions must be free.");
  }
  internal static CanConstructInfo CanRemove(IDinLogic m)=>!Access(m)?CanConstructInfo.InvalidPlacement("Open the cabinet and remove its cover first."):m.Cabinet.Wiring.CanRefundBreaker(m.Logic.ReferenceId)?CanConstructInfo.ValidPlacement:CanConstructInfo.InvalidPlacement("Cable coil prefab unavailable.");
  internal static void Power(IDinLogic m){
   if(!GameManager.RunSimulation||m.Logic.IsCursor)return;
   var d=m.Logic;bool live=d.IsStructureCompleted&&!d.IsBeingDestroyed&&m.Cabinet?.Wiring.Power.ServicePowered(d.ReferenceId)==true;
   if(d.InteractPowered!=null&&d.Powered!=live)OnServer.Interact(d.InteractPowered,live?1:0,skipAnimation:true);
  }
  internal static void Refresh(IDinLogic m){if(m.Logic.IsCursor)return;DinBreakerModel.Refresh(m.Logic);if(m.Cabinet!=null){m.LastWiring=m.Cabinet.Wiring;m.LastWiring.RefreshLogicNetworks();}}
  internal static void Release(IDinLogic m){DinLogicNetwork.Unbind(m.Logic);var wiring=m.Cabinet?.Wiring??m.LastWiring;m.LastWiring=null;if(wiring!=null){wiring.Power.RemoveOwnTransformer(m.Logic.ReferenceId);wiring.RemoveBreaker(m.Logic.ReferenceId);}}
  internal static bool SkipPrivateNetworkRegistration(CableNetwork network)=>!(network is DinLogicDataView);
  internal static bool SkipPhysical(Device __instance)=>!(__instance is IDinLogic);
 }
}
