using System;using System.Linq;using System.Collections.Generic;
using Assets.Scripts;using Assets.Scripts.Objects;using Assets.Scripts.Objects.Electrical;using UnityEngine;
namespace ModularSwitchboards {
 internal static class DinLogicCatalog {
  internal static readonly string[] Native={"StructureLogicReader","StructureLogicWriter","StructureLogicBatchReader","StructureLogicBatchWriter","StructureLogicSlotReader","StructureLogicBatchSlotReader","StructureLogicReagentReader","StructureLogicMirror"};
  internal static string Name(string native)=>"StructureDinLogic"+native.Substring("StructureLogic".Length);
  internal static bool Contains(string name)=>Native.Any(n=>Name(n)==name);
  internal static void Saves(){var mod=SwitchboardsMod.Mod;mod.AddSaveDataType<DinLogicReaderSaveData>();mod.AddSaveDataType<DinLogicWriterSaveData>();mod.AddSaveDataType<DinLogicBatchReaderSaveData>();mod.AddSaveDataType<DinLogicBatchWriterSaveData>();mod.AddSaveDataType<DinLogicSlotReaderSaveData>();mod.AddSaveDataType<DinLogicBatchSlotReaderSaveData>();mod.AddSaveDataType<DinLogicReagentReaderSaveData>();mod.AddSaveDataType<DinLogicMirrorSaveData>();}
  private static LogicUnitBase Replace(Structure s,int index){switch(index){case 0:return SwitchboardPrefabs.ReplaceComponent<DinLogicReader>(s,true);case 1:return SwitchboardPrefabs.ReplaceComponent<DinLogicWriter>(s,true);case 2:return SwitchboardPrefabs.ReplaceComponent<DinLogicBatchReader>(s,true);case 3:return SwitchboardPrefabs.ReplaceComponent<DinLogicBatchWriter>(s,true);case 4:return SwitchboardPrefabs.ReplaceComponent<DinLogicSlotReader>(s,true);case 5:return SwitchboardPrefabs.ReplaceComponent<DinLogicBatchSlotReader>(s,true);case 6:return SwitchboardPrefabs.ReplaceComponent<DinLogicReagentReader>(s,true);default:return SwitchboardPrefabs.ReplaceComponent<DinLogicMirror>(s,true);}}
  internal static void Install(List<Thing> sources,Transform storage,Item drill){
   var original=sources.OfType<MultiConstructor>().Where(k=>k.Constructables!=null&&Native.All(n=>k.Constructables.Any(c=>c!=null&&c.PrefabName==n))).OrderBy(k=>k.Constructables.Count).FirstOrDefault()??throw new InvalidOperationException("Original Logic I/O kit missing");
   var kit=UnityEngine.Object.Instantiate(original,storage);var variants=new List<Structure>();
   try{
    SwitchboardsMod.Identify(kit,DinLogicRuntime.Kit,"Kit (DIN Logic I/O)");kit.SetQuantity(1);kit.PaintableMaterial=null;kit.RecipeTier=MachineTier.TierOne;
    for(int i=0;i<Native.Length;i++){
     var source=original.Constructables.Single(s=>s.PrefabName==Native[i]);var m=Replace(UnityEngine.Object.Instantiate(source,storage),i);variants.Add(m);
     SwitchboardsMod.Identify(m,Name(Native[i]),"DIN "+source.DisplayName);m.HideInStationpedia=false;
     m.BuildStates=new List<BuildState>{SwitchboardsMod.MakeState(m.BuildStates.Last(),kit,1,null,0,drill)};
     DinLogicModel.Install(m,Native[i],storage);m.Thumbnail=CabinetIcons.Get(Name(Native[i]).Substring("Structure".Length));m.Thumbnails=new Sprite[0];m.BuildStates[0].Thumbnail=m.Thumbnail;
    }
    kit.Constructables=variants;kit.LastSelectedIndex=0;sources.Add(kit);sources.AddRange(variants);
    Debug.Log("[Modular Switchboards] DIN Logic I/O: 8 native variants, 2 slots, original controls and 10 W; DATA IN/POWER top, DATA OUT bottom. Writer Switch excluded.");
   }catch{foreach(var v in variants)if(v!=null)UnityEngine.Object.DestroyImmediate(v.gameObject);if(kit!=null)UnityEngine.Object.DestroyImmediate(kit.gameObject);throw;}
  }
 }
}
