## 1.0.194 — Eight native Logic I/O modules on DIN rails

Adds a separate Kit (DIN Logic I/O) with Logic Reader, Logic Writer, Batch Reader, Batch Writer, Slot Reader, Batch Slot Reader, Reagent Reader and Logic Mirror. Logic Writer Switch is excluded. Each variant occupies two DIN positions and uses one kit; print it in the Electronics Printer and choose a variant with right-click. Fit/remove with a Hand Drill inside an open cabinet with its cover removed.

Original native fronts, lettering, side contacts, ON/OFF indicator/button and screwdriver selectors sit on the existing DIN housing. The original rear substrate is removed. Full-resolution native materials remain borrowed unchanged from game prefabs; CPU-readable geometry captured from the game supports construction previews without runtime GPU extraction. Each variant has its own DIN icon and F1 entry.

Top-left: DATA IN. Top-right: POWER. Bottom: DATA OUT. Data contacts connect to other DIN Logic data contacts or to an external cabinet Output with a connected cable network. IN and OUT are separate unless explicitly wired together; POWER is a separately billed 10 W service load while ON. Data wires never enter the power solver, and links that would merge distinct external data networks are rejected. An existing route with conflicting external networks fails closed. Each data terminal permits up to three branches; an external Output retains one data-leaf slot independent of its power conductors. Direct Net, bridge or Smart Output signal contacts are not DIN Logic data sockets; use the cabinet's external data-network route.

Native subclasses retain original read/write, batch, slot, reagent and Mirror behavior, selector actions, save payloads and join payloads. DIN mounting metadata is appended to each corresponding native save type. The cabinet supplies native Powered state from its separate power accounting. Explicit data-wire flags survive XML and version -5 network packets; readers accept the previous packet formats too. All peers need the same mod version. Local data-only views do not allocate native network IDs, join real cable networks, register power providers or enter network announcements. Original vanilla prefabs and kit remain intact.

Automatic Logic I/O reference extraction is disabled now that the capture has been received; battery extraction remains removed. The authoring tools remain in source.

Validation: native compilation; compiled inheritance/native tick/save/join/resource contracts; actual CPU asset bounds/indices and two-position fit; data-graph isolation, XML/binary persistence, POWER pin 2 and eight-module 80 W accounting; previous power/overload/transformer/battery and Net data-route checks. Offline render previews proportions. Live in-game placement, controls, save/load, multiplayer and actual data-network refresh still need testing.

Implementation map:
- `DinLogicModules.cs`: eight native subclasses and eight matching native save subclasses. Native algorithms are inherited.
- `DinLogicCatalog.cs`: separate eight-choice native-kit clone and transactional variant preparation.
- `DinLogicModel.cs`, `Assets/LogicIO/*.meshbin`: captured native front/controls on a two-position body, with top IN/POWER and bottom OUT.
- `DinLogicCircuit.cs`, `CabinetLogicIO.cs`, `DinLogicNetwork.cs`: explicit data domain, components and private CableNetwork views; actual external anchor registrations are data only.
- `DinLogicRuntime.cs`: rail placement/access, separate service-power state, physical-grid probing exclusion and private-network registration exclusion.
- `CabinetPowerNode.ServiceContact`: service loads can tap POWER pin 2 without fabricating an IN/OUT bridge.
- `Verification/DinLogicNative`, `Verification/Wiring/DinLogicHarness.cs`: native contracts, assets, graph/domain/persistence/power checks.

Front reconstruction removes triangles behind z=0.04999 and the flat original substrate at z=0.05. Front vertices/UVs/material slots are otherwise retained. Uniform 0.16 scale keeps the full side-contact envelope within 80.1 mm; the front plane sits on the DIN face. Original native control collider transforms move with their matching geometry. Source capture SHA256 is recorded in `Assets/LogicIO/manifest.json`.

To rebuild CPU assets: `python3 Tools/create_din_logic_assets.py <NativeLogicIO-kit-reference-1.0.193.zip>`. Geometry/material previews are offline Blender renders and are not game screenshots.
