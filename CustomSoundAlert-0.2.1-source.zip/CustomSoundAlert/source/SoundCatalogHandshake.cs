using System;
using Assets.Scripts.Networking;
using LaunchPadBooster;
using LaunchPadBooster.Networking;
namespace CustomSoundAlert
{
 [HarmonyLib.HarmonyPatch(typeof(NetworkManager),"EndConnection")]
 internal static class SoundCatalogDisconnect {static void Prefix(){SoundCatalogHandshake.Clear();}}
 internal sealed class SoundCatalogHandshake:IJoinPrefixSerializer
 {
  internal static readonly object Gate=new object();
  internal static SoundEntry[] Local=Array.Empty<SoundEntry>(),Pending;
  internal static long Revision;
  internal static int ResetRequested;
  internal static void Configure(string soundDirectory){Local=ServerSoundCatalog.Scan(soundDirectory);var mod=new Mod("CustomSoundAlert","0.2.1");mod.Networking.Required=false;mod.Networking.JoinPrefixSerializer=new SoundCatalogHandshake();}
  public void SerializeJoinPrefix(RocketBinaryWriter writer){writer.WriteString(ServerSoundCatalog.Encode(Local));}
  public void DeserializeJoinPrefix(RocketBinaryReader reader){var entries=ServerSoundCatalog.Decode(reader.ReadString());lock(Gate){Pending=entries;System.Threading.Interlocked.Increment(ref Revision);}}
  internal static void Clear(){lock(Gate){Pending=null;System.Threading.Interlocked.Increment(ref Revision);}System.Threading.Interlocked.Exchange(ref ResetRequested,1);}
 }
}
