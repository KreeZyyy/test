# Verification

Requires .NET SDK 8. Run each fixture with `dotnet run --project <path> -c Release`:

- `source/tests/Check.csproj`: 16 custom alert ID checks.
- `Verification/Catalog/Check.csproj`: 58 shared enum/catalog checks.
- `Verification/Manifest/Check.csproj`: 128 manifest/cache checks using temporary files.
- `Verification/Cleanup/Check.csproj`: actual ReleaseClips body, 8 cleanup checks against native API stubs.
- `Verification/Performance/Check.csproj`: actual Update/IsReady bodies against API stubs, 100,000 stable updates and 200,000 ownership lookups, no managed allocations in the measured loops.

Performance/ExtractedUpdate.cs is copied from Plugin.cs between `void Update()` and `IEnumerator Load(`. Cleanup/ExtractedCleanup.cs is copied between `static void ReleaseClips()` and `bool loading;`. Refresh these files after implementation changes. Fixtures model Unity null/destroyed behavior but are not a live Unity runtime or an FPS benchmark. RESULTS.txt records this build's results.
