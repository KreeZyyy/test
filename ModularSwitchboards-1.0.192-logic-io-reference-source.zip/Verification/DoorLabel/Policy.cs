using System;using System.Linq;using Assets.Scripts.GridSystem;using LibConstruct; namespace ModularSwitchboards{public partial class DoorLabel{        internal static DinBreaker Target(PlacementBoard board,Grid3 p,bool emergency=false)
        {
            var host=board?.PrimaryHost as SwitchboardCabinet;
            return host?.DoorBoardFor(board)?.Structures.OfType<DinBreaker>().FirstOrDefault(m=>!m.IsBeingDestroyed&&m.IsStructureCompleted&&!m.IsCursor&&(emergency?m.IsDoorStop:m.IsDoorLed||m.IsDoorRoundSwitch||m.IsDoorButton)&&Same(host.DoorBoardFor(board).WorldToGrid(m.transform.position),p));
        }
        internal static bool HasTarget(PlacementBoard board,Grid3 p,bool emergency=false,bool display=false)=>display?DoorDisplayLabel.TargetDisplay(board,p)!=null:Target(board,p,emergency)!=null||!emergency&&DoorDial.Target(board,p)!=null;
        private static bool Same(Grid3 a,Grid3 b)=>a.x==b.x&&a.y==b.y&&a.z==b.z;
        internal static bool CanPlace(PlacementBoard board,Grid3 p,int rotation,bool emergency=false,bool display=false)
            =>board is DoorLabelBoard&&board.PrimaryHost is SwitchboardCabinet host&&host.IsStructureCompleted&&(p.x%10==0&&p.y%10==0&&System.Math.Abs(p.x)<=10&&p.y>=CabinetShape.MinDoorY(host.PrefabName)&&p.y<=10&&p.z==0&&rotation==0)&&HasTarget(board,p,emergency,display)&&!board.Structures.OfType<DoorLabel>().Any(l=>Same(board.WorldToGrid(l.transform.position),p));
        internal static bool Attached(DinBreaker owner)
        {
            var host=CabinetWiring.CabinetOf(owner);var board=host?.DoorLabelsFor(owner.Board);
            if(board==null||!(owner.Board is SwitchboardDoorBoard))return false;
            var p=owner.Board.WorldToGrid(owner.transform.position);
            return board.Structures.OfType<DoorLabel>().Any(l=>!l.IsBeingDestroyed&&Same(board.WorldToGrid(l.transform.position),p));
        }
}}