using System;using StationEmotes;
class MenuPolicyCheck{
 static int n;static void A(bool b,string m){n++;if(!b)throw new Exception(m);}static int At(double degrees){double a=degrees*Math.PI/180;return EmoteWheelPolicy.Select((float)(Math.Cos(a)*120),(float)(Math.Sin(a)*120));}
 static void Main(){
 A(EmoteWheelPolicy.Count==6,"catalogue sector count");
 for(int i=0;i<6;i++){
  double center=-90+i*60;
  A(At(center)==i,"sector center "+i);A(At(center-29)==i,"left interior "+i);A(At(center+29)==i,"right interior "+i);A(At(center+31)==(i+1)%6,"clockwise boundary/wrap "+i);
 }
 A(EmoteWheelPolicy.Select(0,0)==-1,"center triggered");A(EmoteWheelPolicy.Select(34,0)==-1,"dead zone triggered");A(EmoteWheelPolicy.Select(float.NaN,100)==-1,"NaN accepted");A(EmoteWheelPolicy.Select(0,float.PositiveInfinity)==-1,"infinity accepted");
 Console.WriteLine(n+" six-item wheel checks passed.");
 }
}
