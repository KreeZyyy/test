# Station Emotes0.1.6 — first test
Requires BepInEx and StationeersLaunchPad. Install exactly one StationEmotes folder and enable it in LaunchPad. Use the same test version on observing clients; server installation is recommended for a consistent test setup. No LibConstruct or sound mod dependency.

In a loaded world, empty both hands and stand still. Press F9 once to log body animator, avatar, layers, parameters, clip names and transform paths. Hold F10 to open the radial menu. Move the mouse toward Wave (up), Salute (right), Sit (down), or Hands up TEST (left), then release F10 to play. Releasing in the center cancels. Esc cancels selection. The OS cursor remains locked; a virtual pointer shows selection. Camera look axes are suppressed only while the menu is held. Native movement/physics are not paused. Hands up remains the3.5-second procedural pose. F11 cancels using the same native emote channel. Movement beyond20cm, taking a held item, death, leaving the world or component teardown also ends the local pose. New native emotes cancel it too.

First verify in third person with native camera controls or ask a second player to observe. First-person arms/viewmodel are not separately overridden. Do not judge success solely from first-person view.

If nothing happens, send BepInEx LogOutput.log containing StationEmotes RIG / BONE / TEST RIG lines. Generic rigs need an unambiguous supported arm chain; otherwise the prototype refuses to guess.

This is a procedural bone-pose test, NOT an imported Animator clip. It writes only four arm-bone rotations in LateUpdate, restores captured rotations when stopped, and does not move the character root, change colliders, modify the shared controller or create a new packet format. Existing AnimationEmoteMessage carries IDs41001(pose)/41002(cancel). All clients need these handlers for the pose to be visible.

Remaining live verification: Harmony installation, actual skeleton matching, rotation axes and IK order, suit/body variants, third-person appearance, existing native emotes and multiplayer visibility. Visual clipping or incorrect arm placement is possible in this experimental version. No live Unity test was available during preparation.

The menu closes without selection on lost application focus, game pause, UI/input windows, death, leaving the world or changing the controlled character. F11 closes the menu and sends the existing test-pose cancel. It does not promise to stop native wave/sit/salute clips. No new animation clips were added in0.1.1. Native choices use Emote.Trigger, and Hands up uses the previous native-message path.

##0.1.2 held sit
Sit uses the native EmoteIndex3 state without scheduling the original5-second reset. This intercepts the original emote sit command as well as menu selection. Movement input (using native mapped axes), external movement beyond10cm, Esc (when wheel closed), F11, another body emote or selecting Sit again stops it. New sitting from the menu is rejected while movement input is active.
The owning client sends the existing native custom-cancel message to observers on movement; remote movement also ends the local visual state without sending another player's cancel. Death, scene exit, disable and destroy clear the local state. No root motion, collider or physics controls are changed.
Live animation-controller behavior is still pending: a constant EmoteIndex3 may depend on native state transitions/clip behavior. All observers must use0.1.2 for consistent holding/cancellation. This does not synchronize an already-held pose to players joining later.

##0.1.3 held emotes
Wave repeats its native animation; Salute holds a middle phase; Sit holds its seated phase. This intercepts native emote wave/salute/sit commands too. Hands up is procedural, uses wider shoulders/elbows, aligns wrists using humanoid finger bones where available, blends in over0.55seconds, and has no fixed timeout.
Movement, Esc outside the wheel, F11, another emote or selecting the current emote again cancels. Mapped movement input blocks starting any menu emote while moving. Local movement cancellation uses the existing native cancel message. All observers need0.1.3.
Native hold/loop uses live clip-name matching from the user's F9 report (wave/SaluteL/SaluteR/Sitting) and current animator state. No global Animator.speed is changed. A missing matching state after3seconds cancels and requests F9 diagnostics rather than holding blindly. The actual hold phase and wave crossfade need visual validation in Unity.
No imported custom animation clip is bundled. Hands up is an improved experimental bone pose, not a polished authored clip. Late joiners do not yet receive a persistent held-state snapshot.

##0.1.4 switch/loop/facing test
Wave first plays its entry, then loops28–68percent of its1-second native clip with a60ms crossfade. These are initial visual tuning values, not confirmed clip markers.
Incoming emotes are queued on each character: stop old procedural/held pose, reset native EmoteIndex, wait at least2frames and until old emote clips/transitions clear, then apply latest request. A stuck transition cancels after3.5seconds and asks for F9. Existing native OnEmote sends exactly one message; queued local DoEmote does not send a second one. Cancel discards pending requests too.
Hands up now computes its geometric target using CharacterRotationY rather than the unrotated entity root. It remains a procedural test. Verify facing north/east/south/west, Wave→Hands up→Sit switching, and F11/Esc during a pending switch. Real Animator blending and network behavior still require live validation.

##0.1.5 Point test
F10 wheel now has5equal sectors clockwise from top: Wave, Salute, Sit, Hands up TEST, Point TEST. Move toward the actual displayed label; earlier four-direction instructions describe old versions.
Point uses native custom ID41003 and the same transition/cancel path. It poses only the right upper arm, forearm and wrist toward the visual body's CharacterRotationY forward direction. The left arm is not overridden. Turning on the spot should turn the arm with the body; look-up/down camera aiming is not implemented. Both hands must be empty. Steps/jump/external movement, Esc/F11, another emote or selecting Point again cancel.
This is a procedural arm-direction test, not an imported clip or an individually animated pointing finger. Appearance, wrist orientation and turning require live visual testing. All observers need0.1.5.

##0.1.6 Robot dance test
F10 now has6equal sectors clockwise from top: Wave, Salute, Sit, Hands up TEST, Point TEST, Robot dance TEST. Follow the displayed labels; old quadrant directions are historical.
Robot dance uses custom ID41004 and the same native message/transition/cancel path. Empty both hands and stand still. It loops a2-second procedural rhythm across upper arms, forearms, spine, thighs and lower legs with0.4second blend-in. The character root, colliders, Rigidbody and shared controller are not modified. Movement, Esc/F11, other emotes or choosing Robot dance again cancels and restores captured bone rotations.
Requires a complete humanoid rig. This is a mechanical prototype, not an authored imported clip: foot sliding, unsuitable knee/arm angles or suit clipping must be visually checked before considering it finished. First-person arms are not separately animated. All observing clients need0.1.6. Starts are relayed natively; dance phases are not synchronized to a shared server clock, and late joining pose restoration is not implemented.
