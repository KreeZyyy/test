using Assets.Scripts.Inventory;using Assets.Scripts.Objects;using Assets.Scripts.UI;
namespace ModularSwitchboards {
 internal static class DinLogicHelperWireframe {
  // Native helper outlines keep independent cached edges and ignore transform scale.
  // Suppress their GL draw, not the renderer/ref the native placement loop still uses.
  internal static bool BeforeRender(Wireframe __instance){
   var owner=__instance.GetComponentInParent<Structure>(true);
   if(!(owner is IDinLogic)||!owner.IsCursor)return true;
   for(var node=__instance.transform;node!=null&&node!=owner.transform;node=node.parent)
    if(node.CompareTag(InventoryManager.HelperTag))return false;
   return true;
  }
 }
}
