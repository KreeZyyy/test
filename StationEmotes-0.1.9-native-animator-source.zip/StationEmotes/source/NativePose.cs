using System;
using UnityEngine;
using UnityEngine.Animations;
using UnityEngine.Playables;
using Assets.Scripts.Objects.Entities;
namespace StationEmotes
{
 // Inserts one owned job into the EXISTING Animator output. Never owns its graph/controller.
 internal sealed class NativePose:IDisposable
 {
  private Animator animator; private AnimationPlayableOutput output;
  private Playable previous;private int port;private AnimationScriptPlayable playable;
  private PoseJob data;private bool attached;
  internal bool Attach(Animator a,Transform[] bones)
  {
   if(a==null||!a.isHuman||bones.Length>10)return false;
   var graph=a.playableGraph;if(!graph.IsValid())return false;
   for(int i=0;i<graph.GetOutputCount();i++)
   {
    var candidate=graph.GetOutput(i);
    if(candidate.GetPlayableOutputType()!=typeof(AnimationPlayableOutput))continue;
    var animation=(AnimationPlayableOutput)candidate;if(animation.GetTarget()!=a)continue;
    previous=animation.GetSourcePlayable();port=animation.GetSourceOutputPort();
    if(!previous.IsValid())continue;
    animator=a;output=animation;data=new PoseJob{Count=bones.Length};
    for(int j=0;j<bones.Length;j++)data.Set(j,new PoseSlot{Handle=a.BindStreamTransform(bones[j]),Rotation=bones[j].localRotation});
    try
    {
     playable=AnimationScriptPlayable.Create(graph,data,1);
     graph.Connect(previous,port,playable,0);playable.SetInputWeight(0,1f);
     output.SetSourcePlayable(playable,0);attached=true;return true;
    }
    catch(Exception e){if(playable.IsValid())graph.DestroyPlayable(playable);Plugin.Log.LogWarning("Native pose attachment failed: "+e);return false;}
   }
   return false;
  }
  internal void Set(int i,Quaternion rotation,float weight)
  {var slot=data.Get(i);slot.Rotation=rotation;slot.Weight=weight;data.Set(i,slot);}
  internal bool Submit(Human human,bool feet)
  {
   if(!attached||animator==null||!playable.IsValid())return false;
   data.Feet=false;
   if(feet)
   {
    if(!human.IsGrounded(human.AllButPlayerImmune,.08f))return false;
    var left=animator.GetBoneTransform(HumanBodyBones.LeftFoot);var right=animator.GetBoneTransform(HumanBodyBones.RightFoot);
    if(left==null||right==null)return false;
    RaycastHit l,r;
    if(!Physics.Raycast(left.position+Vector3.up*.3f,Vector3.down,out l,.8f,human.AllButPlayerImmune,QueryTriggerInteraction.Ignore)||
       !Physics.Raycast(right.position+Vector3.up*.3f,Vector3.down,out r,.8f,human.AllButPlayerImmune,QueryTriggerInteraction.Ignore)||l.normal.y<.7f||r.normal.y<.7f)return false;
    data.LeftFloor=l.point.y;data.RightFloor=r.point.y;data.Feet=true;
   }
   playable.SetJobData(data);return true;
  }
  public void Dispose()
  {
   if(!attached)return;attached=false;
   if(playable.IsValid())
   {
    var graph=playable.GetGraph();
    // Restore only if we still own the output. Do not overwrite another mod's replacement.
    if(output.IsOutputValid()&&output.GetSourcePlayable().Equals((Playable)playable))output.SetSourcePlayable(previous,port);
    if(graph.IsValid())graph.DestroyPlayable(playable);
   }
   animator=null;
  }
 }
 internal struct PoseSlot
 {
  public TransformStreamHandle Handle;public Quaternion Rotation;public float Weight;
  public void Apply(AnimationStream stream)
  {if(Handle.IsValid(stream))Handle.SetLocalRotation(stream,Quaternion.Slerp(Handle.GetLocalRotation(stream),Rotation,Weight));}
 }
 internal struct PoseJob:IAnimationJob
 {
  public int Count;public bool Feet;public float LeftFloor,RightFloor;
  public PoseSlot A,B,C,D,E,F,G,H,I,J;
  public PoseSlot Get(int i){switch(i){case 0:return A;case 1:return B;case 2:return C;case 3:return D;case 4:return E;case 5:return F;case 6:return G;case 7:return H;case 8:return I;default:return J;}}
  public void Set(int i,PoseSlot s){switch(i){case 0:A=s;break;case 1:B=s;break;case 2:C=s;break;case 3:D=s;break;case 4:E=s;break;case 5:F=s;break;case 6:G=s;break;case 7:H=s;break;case 8:I=s;break;default:J=s;break;}}
  public void ProcessRootMotion(AnimationStream stream){} // Original root motion passes through unchanged.
  public void ProcessAnimation(AnimationStream stream)
  {
   if(!stream.isHumanStream)return;
   var human=stream.AsHuman();
   // Capture the native stance BEFORE changing hips/legs. Let Unity solve knees/ankles.
   var left=human.GetGoalPositionFromPose(AvatarIKGoal.LeftFoot);
   var right=human.GetGoalPositionFromPose(AvatarIKGoal.RightFoot);
   var lr=human.GetGoalRotationFromPose(AvatarIKGoal.LeftFoot);var rr=human.GetGoalRotationFromPose(AvatarIKGoal.RightFoot);
   for(int i=0;i<Count;i++)Get(i).Apply(stream);
   if(!Feet)return;
   left.y=LeftFloor+human.leftFootHeight;right.y=RightFloor+human.rightFootHeight;
   human.SetGoalPosition(AvatarIKGoal.LeftFoot,left);human.SetGoalPosition(AvatarIKGoal.RightFoot,right);
   human.SetGoalRotation(AvatarIKGoal.LeftFoot,lr);human.SetGoalRotation(AvatarIKGoal.RightFoot,rr);
   human.SetGoalWeightPosition(AvatarIKGoal.LeftFoot,1f);human.SetGoalWeightPosition(AvatarIKGoal.RightFoot,1f);
   human.SetGoalWeightRotation(AvatarIKGoal.LeftFoot,1f);human.SetGoalWeightRotation(AvatarIKGoal.RightFoot,1f);
   human.SolveIK();
  }
 }
}
