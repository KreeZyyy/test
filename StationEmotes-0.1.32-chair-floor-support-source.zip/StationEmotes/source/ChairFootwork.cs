using UnityEngine;
namespace StationEmotes
{
 internal sealed class ChairFootwork
 {
  private sealed class Step{internal int Foot;internal float Start,Duration;internal Vector3 Position;internal Quaternion Rotation;}
  private readonly ChairTransition.Snapshot s;private readonly Step[] steps;
  private readonly Vector3[] initial=new Vector3[2],rawInitial=new Vector3[2];private readonly Quaternion[] initialRotation=new Quaternion[2];
  private readonly float[] sole=new float[2],floor=new float[2];private bool prepared,warned,reportedSupport,grounded=true;
  internal ChairFootwork(ChairTransition.Snapshot snapshot)
  {
   s=snapshot;steps=new Step[s.Plan.StepCount];initial[0]=s.LeftFootPosition;initial[1]=s.RightFootPosition;
   initialRotation[0]=s.LeftFootRotation;initialRotation[1]=s.RightFootRotation;
   for(int i=0;i<2;i++)
   {
    rawInitial[i]=initial[i];sole[i]=s.Standing.Sole[i];
    float expected=s.Seat.ThingTransform.position.y+s.Standing.FloorRelativeToSeat[i];
    ChairFloorContact contact;
    if(!ChairFloorProbe.Try(initial[i],s.Seat,s.Human,expected,out contact))
    {grounded=false;Plugin.Log.LogWarning("Chair transition skipped: no verified floor under the initial foot.");continue;}
    floor[i]=contact.Point.y;
    if(!s.Entering)initial[i].y=ChairFloorPolicy.Ankle(floor[i],sole[i]);
    Plugin.Log.LogInfo("Chair floor "+(s.Entering?"entry":"exit")+" "+(i==0?"L":"R")+": source ankleY="+rawInitial[i].y.ToString("F3")+", support ankleY="+initial[i].y.ToString("F3")+", floorY="+floor[i].ToString("F3")+", sole="+sole[i].ToString("F3")+", hit="+contact.Name+", rejected chair/human="+contact.Chairs+"/"+contact.Humans);
   }
  }
  internal bool Prepare(Vector3 end,Quaternion facing,ChairNativePose native)
  {
   if(!grounded)return false;
   if(!native.Ready)return true;
   if(prepared)
   {
    if(!s.Entering&&s.Plan.WalkSteps>0)
    {
     // Only the final pair converges to the unmodified native standing feet.
     for(int i=steps.Length-2;i<steps.Length;i++)
     {int foot=steps[i].Foot;var target=foot==0?native.Left:native.Right;ChairFloorContact contact;
      if(!ChairFloorProbe.Try(target,s.Seat,s.Human,floor[foot],out contact))return false;
      target.y=ChairFloorPolicy.Ankle(contact.Point.y,sole[foot]);steps[i].Position=target;steps[i].Rotation=foot==0?native.LeftRotation:native.RightRotation;}
    }
    return true;
   }
   var front=s.Front;front.y=s.Entering?s.Position.y:end.y;
   for(int i=0;i<steps.Length;i++)
   {
    float start,duration,advance;bool turning;s.Plan.Step(i,out start,out duration,out advance,out turning);
    int foot=i%2;Vector3 root;Quaternion rotation;
    if(turning){root=front;rotation=Quaternion.Slerp(s.Rotation,facing,advance);}
    else{root=Vector3.Lerp(s.Entering?s.Position:front,s.Entering?front:end,advance);rotation=s.Entering?s.Rotation:facing;}
    var point=root+rotation*s.Standing.Feet[foot];point.y=initial[foot].y;
    ChairFloorContact hit;
    if(!ChairFloorProbe.Try(point,s.Seat,s.Human,floor[foot],out hit))
    {Plugin.Log.LogWarning("Chair transition skipped: a planned footstep has no verified floor.");return false;}
    point.y=ChairFloorPolicy.Ankle(hit.Point.y,sole[foot]);
    steps[i]=new Step{Foot=foot,Start=start,Duration=duration,Position=point,Rotation=rotation*s.Standing.FootRotations[foot]};
   }
   prepared=true;return true;
  }
  internal Vector3 WeightShift(float elapsed,Quaternion rotation)=>Vector3.zero; // Pelvis follows foot support instead of shifting the complete model.
  internal void Apply(float elapsed,Transform visual,Quaternion facing,ChairNativePose native,ChairTorsoStream torso)
  {
   if(!prepared||!native.Ready)return;
   var left=initial[0];var right=initial[1];
   if(!s.Entering){float plant=s.Plan.Upright(elapsed);left=Vector3.Lerp(rawInitial[0],initial[0],plant);right=Vector3.Lerp(rawInitial[1],initial[1],plant);}var lr=initialRotation[0];var rr=initialRotation[1];
   int swing=-1;float swingProgress=0;
   foreach(var step in steps)
   {
    if(elapsed<step.Start)break;
    float p=ChairStepPolicy.Progress(elapsed,step.Start,step.Duration);
    var old=step.Foot==0?left:right;var oldRotation=step.Foot==0?lr:rr;
    var goal=Vector3.Lerp(old,step.Position,p)+Vector3.up*ChairStepPolicy.Lift(p);
    var rotation=Quaternion.Slerp(oldRotation,step.Rotation,p);
    if(step.Foot==0){left=goal;lr=rotation;}else{right=goal;rr=rotation;}
    if(p<1){swing=step.Foot;swingProgress=p;break;}
   }
   float body=s.Plan.Body(elapsed),end=s.Plan.EndRelease(elapsed);
   float settle=s.Entering?ChairBodyPath.Settle(body):end;
   var supportLeft=left;var supportRight=right;
   if(!s.Entering&&elapsed<.24f){supportLeft.y=initial[0].y;supportRight.y=initial[1].y;}
   left=Vector3.Lerp(left,native.Left,settle);right=Vector3.Lerp(right,native.Right,settle);
   lr=Quaternion.Slerp(lr,native.LeftRotation,settle);rr=Quaternion.Slerp(rr,native.RightRotation,settle);
   var middle=ChairBodyPath.Support(supportLeft,supportRight,swing,swingProgress);
   var standingHip=middle+visual.rotation*s.Standing.HipAboveFeet;
   if(!s.Entering&&!reportedSupport&&elapsed>=s.Plan.BodyStart)
   {reportedSupport=true;Plugin.Log.LogInfo("Chair rise support: seated pelvisY="+s.HipPosition.y.ToString("F3")+", floor ankleY="+middle.y.ToString("F3")+", calibrated hip offsetY="+(visual.rotation*s.Standing.HipAboveFeet).y.ToString("F3")+", standing pelvisY="+standingHip.y.ToString("F3")+", native standing pelvisY="+native.Hips.y.ToString("F3"));}
   Vector3 hipPosition;Quaternion hipRotation;
   float lean;
   if(s.Entering)
   {
    // Bend vertically before translating the pelvis back above the cushion.
    hipPosition=ChairBodyPath.Pelvis(true,s.HipPosition,standingHip,native.Hips,0,body,settle);
    lean=ChairBodyPath.Lean(true,0,body);
    hipRotation=Quaternion.Slerp(visual.rotation*s.Standing.HipRotation,native.HipRotation,ChairBodyPath.Posture(body));
   }
   else
   {
    // Transfer weight over planted feet while still seated, then rise over that support.
    float transfer=s.Plan.Preparation(elapsed);
    hipPosition=ChairBodyPath.Pelvis(false,s.HipPosition,standingHip,native.Hips,transfer,body,end);
    lean=ChairBodyPath.Lean(false,transfer,body);
    var upright=visual.rotation*s.Standing.HipRotation;
    hipRotation=Quaternion.Slerp(s.HipRotation,upright,s.Plan.Upright(elapsed));
    hipRotation=Quaternion.Slerp(hipRotation,native.HipRotation,end);
   }
   var hips=s.Bones[0];hips.SetPositionAndRotation(hipPosition,hipRotation);
   // Include every actual spine/neck ancestor, including unmapped UpperChest and Neck.
   // Use the same interpolation factor as the pelvis, with unmodified native samples.
   float posture=s.Entering?ChairBodyPath.Posture(body):s.Plan.Upright(elapsed);
   for(int i=0;i<s.Standing.Torso.Length;i++)
   {
    var node=s.Standing.Torso[i];if(node==null)continue;var sampled=torso.Get(i);
    var nativeLocal=sampled.Ready?sampled.NativeRotation:node.localRotation;
    var standingLocal=!s.Entering&&i>=s.Standing.Torso.Length-2&&sampled.Ready?nativeLocal:s.Standing.TorsoRotations[i];
    var authored=s.Entering?Quaternion.Slerp(s.Standing.TorsoRotations[i],nativeLocal,posture):Quaternion.Slerp(s.SourceTorso[i],standingLocal,posture);
    node.localRotation=s.Entering?authored:Quaternion.Slerp(authored,nativeLocal,end);
   }
   // The small preparation lean belongs to the spine, never the pelvis/whole leg chain.
   for(int i=0;i<Mathf.Min(2,s.Standing.Torso.Length);i++)
   {
    var node=s.Standing.Torso[i];if(node==null||node.parent==null)continue;
    var axis=Quaternion.Inverse(node.parent.rotation)*visual.right;
    node.localRotation=Quaternion.AngleAxis(lean*(i==0?.6f:.4f),axis)*node.localRotation;
   }
   if(!s.Entering&&end<1)
   {
    // Quaternion interpolation of individually rotated joints need not preserve
    // the anatomical torso direction. Match calibrated source/standing directions,
    // instead of clamping an arbitrary pelvis Euler axis or world-up angle.
    var desired=Vector3.Slerp(visual.rotation*s.SourceTorsoDirection,visual.rotation*s.Standing.TorsoDirection,s.Plan.Upright(elapsed)).normalized;
    desired=Quaternion.AngleAxis(lean,visual.right)*desired;
    var actual=s.Bones[3].position-hips.position;
    hips.rotation=ChairRiseOrientation.Align(hips.rotation,actual,desired,1-end);
   }
   // Small opposite arm swing; hands relax into the native seat pose during the last phase.
   if(swing>=0)
   {
    float arm=6f*Mathf.Sin(swingProgress*Mathf.PI)*(swing==0?1:-1);
    if(s.Bones[4]!=null)s.Bones[4].rotation=Quaternion.AngleAxis(arm,visual.right)*s.Bones[4].rotation;
    if(s.Bones[7]!=null)s.Bones[7].rotation=Quaternion.AngleAxis(-arm,visual.right)*s.Bones[7].rotation;
   }
   Solve(s.Bones[10],s.Bones[11],s.Bones[12],left,lr,visual.forward,1-settle);
   Solve(s.Bones[13],s.Bones[14],s.Bones[15],right,rr,visual.forward,1-settle);
   float turn=s.Plan.Turn(elapsed);
   float lead=Mathf.Clamp(Vector3.SignedAngle(visual.forward,facing*Vector3.forward,Vector3.up),-18,18)*Mathf.Sin(turn*Mathf.PI);
   if(s.Bones[2]!=null)s.Bones[2].rotation=Quaternion.AngleAxis(lead*.35f,Vector3.up)*s.Bones[2].rotation;
   if(s.Bones[3]!=null)s.Bones[3].rotation=Quaternion.AngleAxis(lead*.65f,Vector3.up)*s.Bones[3].rotation;
  }
  private void Solve(Transform upper,Transform lower,Transform foot,Vector3 target,Quaternion rotation,Vector3 forward,float weight)
  {
   if(weight<=0)return;
   if(upper==null||lower==null||foot==null)return;
   var originalUpper=upper.rotation;var originalLower=lower.rotation;var originalFoot=foot.rotation;
   var a=upper.position;var b=lower.position;var c=foot.position;
   float u=(b-a).magnitude,l=(c-b).magnitude,d=(target-a).magnitude;
   if(u<.01f||l<.01f||d<.001f)return;
   var direction=(target-a)/d;
   var pole=Vector3.ProjectOnPlane(forward,direction);
   if(pole.sqrMagnitude<.0001f)pole=Vector3.ProjectOnPlane(b-a,direction);
   if(pole.sqrMagnitude<.0001f)return;
   float axial,lateral;ChairStepPolicy.Knee(u,l,d,out axial,out lateral);
   var knee=a+direction*axial+pole.normalized*lateral;
   upper.rotation=Quaternion.FromToRotation(b-a,knee-a)*upper.rotation;
   lower.rotation=Quaternion.FromToRotation(foot.position-lower.position,target-lower.position)*lower.rotation;
   var solvedUpper=upper.rotation;var solvedLower=lower.rotation;
   upper.rotation=Quaternion.Slerp(originalUpper,solvedUpper,weight);
   lower.rotation=Quaternion.Slerp(originalLower,solvedLower,weight);
   foot.rotation=Quaternion.Slerp(originalFoot,rotation,weight);
   if(weight>.95f&&!warned&&(foot.position-target).sqrMagnitude>.0064f){warned=true;Plugin.Log.LogWarning("Chair foot contact is outside leg reach; send this log and a third-person view.");}
  }
 }
}
