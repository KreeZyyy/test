using System;using StationEmotes;using UnityEngine;using Assets.Scripts.Objects.Entities;
class Check{
 static int n;static void A(bool b){n++;if(!b)throw new Exception("torso calibration "+n);}
 static void Main(){
 var hip=new Transform();var spine=new Transform{parent=hip,localRotation=new Quaternion{Tag=1}};var chest=new Transform{parent=spine,localRotation=new Quaternion{Tag=2}};var upper=new Transform{parent=chest,localRotation=new Quaternion{Tag=3}};var neck=new Transform{parent=upper,localRotation=new Quaternion{Tag=4}};var head=new Transform{parent=neck,localRotation=new Quaternion{Tag=5},position=new Vector3(0,1.6f,0)};
 var s=new ChairTransition.Snapshot{Rotation=new Quaternion(),HipRotation=new Quaternion(),HipPosition=new Vector3(0,.9f,0),LeftFootPosition=new Vector3(-.1f,0,0),RightFootPosition=new Vector3(.1f,0,0),Bones=new[]{hip,spine,chest,head},Rotations=new Quaternion[16]};
 var pose=ChairStandingPose.Capture(s);A(pose!=null);A(pose.TorsoDirection.y>.99f);A(pose.Torso.Length==5);A(pose.Torso[2]==upper);A(pose.Torso[3]==neck);A(pose.Torso[4]==head);for(int i=0;i<5;i++)A(pose.TorsoRotations[i].Tag==i+1);A(Math.Abs(pose.HipAboveFeet.y-.9f)<.00001);
 var h=new Human();A(ChairStandingPose.Get(h)==null);ChairStandingPose.Remember(h,pose);A(ChairStandingPose.Get(h)==pose);A(ChairStandingPose.Get(new Human())==null);var replacement=ChairStandingPose.Capture(s);ChairStandingPose.Remember(h,replacement);A(ChairStandingPose.Get(h)==replacement);
 var node=hip;for(int i=0;i<10;i++)node=new Transform{parent=node};s.Bones[3]=node;A(ChairStandingPose.Capture(s)==null);
 Console.WriteLine(n+" production full torso-chain calibration/cache checks passed (transform stubs).");}}
namespace UnityEngine{
 public struct Vector3{public float x,y,z;public Vector3(float a,float b,float c){x=a;y=b;z=c;}public Vector3 normalized{get{float length=(float)Math.Sqrt(x*x+y*y+z*z);return length<.000001f?new Vector3():new Vector3(x/length,y/length,z/length);}}public static Vector3 operator +(Vector3 a,Vector3 b)=>new Vector3(a.x+b.x,a.y+b.y,a.z+b.z);public static Vector3 operator -(Vector3 a,Vector3 b)=>new Vector3(a.x-b.x,a.y-b.y,a.z-b.z);public static Vector3 operator *(Vector3 a,float b)=>new Vector3(a.x*b,a.y*b,a.z*b);}
 public struct Quaternion{public float Tag;public static Quaternion Inverse(Quaternion a)=>new Quaternion{Tag=-a.Tag};public static Quaternion operator *(Quaternion a,Quaternion b)=>new Quaternion{Tag=a.Tag+b.Tag};public static Vector3 operator *(Quaternion q,Vector3 v)=>v;}
 public class Transform{public Transform parent;public Quaternion localRotation;public Vector3 position;}}
namespace Assets.Scripts.Objects.Entities{public class Human{}}
namespace StationEmotes{internal class ChairTransition{internal class Snapshot{public Quaternion Rotation,HipRotation,LeftFootRotation,RightFootRotation;public Vector3 LeftFootPosition,RightFootPosition,HipPosition,Position;public Transform[] Bones;public Quaternion[] Rotations;}}}

namespace StationEmotes{internal static class ChairFloorProbe{internal static bool Calibrate(ChairTransition.Snapshot s,ChairStandingPose pose){for(int i=0;i<2;i++){pose.Sole[i]=.12f;pose.FloorRelativeToSeat[i]=0;}return true;}}}
