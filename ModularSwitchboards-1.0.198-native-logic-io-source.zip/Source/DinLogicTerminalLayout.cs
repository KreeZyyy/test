using UnityEngine;
namespace ModularSwitchboards {
 internal static class DinLogicTerminalLayout {
  // Positive local X is viewer-left on the cabinet front. Connection indices remain unchanged.
  internal const float Center=.02025f, Edge=.050625f, EntryZ=.03335f, SocketWidth=.009f;
  internal static Vector3 Entry(int pin)=>new Vector3(Center+(pin==0?.018f:pin==1?-.018f:0),pin==2?Edge:-Edge,EntryZ);
  internal static float ExitY(int pin,float bottom,float top)=>pin==2?top+.016f:bottom-.016f;
  internal static Vector3 Aim(int pin)=>new Vector3(Entry(pin).x,pin==2?.042f:-.042f,.067f);
 }
}
