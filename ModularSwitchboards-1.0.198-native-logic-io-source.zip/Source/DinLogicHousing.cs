using System.Collections.Generic;using UnityEngine;
namespace ModularSwitchboards {
 internal static class DinLogicHousing {
  // Cut only the flat end faces of our housing. The three entries share the cable-anchor layout.
  private struct P {internal Vector3 V,N;internal P(Vector3 v,Vector3 n){V=v;N=n;}}
  internal static void CutSockets(Mesh mesh){
   var groups=new List<List<int>>();var v=mesh.vertices;var n=mesh.normals;var vertices=new List<Vector3>();var normals=new List<Vector3>();
   for(int group=0;group<mesh.subMeshCount;group++){
    var output=new List<int>();var triangles=mesh.GetTriangles(group);
    for(int i=0;i<triangles.Length;i+=3){var poly=new List<P>();for(int j=0;j<3;j++)poly.Add(new P(Vector3.Scale(v[triangles[i+j]],DinBreakerModel.VisualScale),n[triangles[i+j]]));
     var pieces=new List<List<P>>{poly};
     for(int pin=0;pin<3;pin++){var entry=DinLogicTerminalLayout.Entry(pin);if(!poly.TrueForAll(p=>Mathf.Abs(p.V.y-entry.y)<.00001f))continue;
      var next=new List<List<P>>();foreach(var piece in pieces){var inside=piece;for(int plane=0;plane<4&&inside.Count>0;plane++){var outside=Clip(inside,entry,plane,true);if(outside.Count>=3)next.Add(outside);inside=Clip(inside,entry,plane,false);}}pieces=next;
     }
     foreach(var piece in pieces)for(int j=1;j+1<piece.Count;j++)foreach(var p in new[]{piece[0],piece[j],piece[j+1]}){output.Add(vertices.Count);vertices.Add(new Vector3(p.V.x/DinBreakerModel.VisualScale.x,p.V.y/DinBreakerModel.VisualScale.y,p.V.z/DinBreakerModel.VisualScale.z));normals.Add(p.N);}
    }
    groups.Add(output);
   }
   mesh.Clear();mesh.SetVertices(vertices);mesh.SetNormals(normals);mesh.subMeshCount=groups.Count;for(int i=0;i<groups.Count;i++)mesh.SetTriangles(groups[i],i);mesh.RecalculateBounds();groups.Clear();
  }
  private static float Distance(P p,Vector3 e,int plane){float half=DinLogicTerminalLayout.SocketWidth*.5f;switch(plane){case 0:return e.x-half-p.V.x;case 1:return p.V.x-e.x-half;case 2:return e.z-half-p.V.z;default:return p.V.z-e.z-half;}}
  private static List<P> Clip(List<P> poly,Vector3 e,int plane,bool outside){var r=new List<P>();if(poly.Count==0)return r;var a=poly[poly.Count-1];float da=Distance(a,e,plane)*(outside?1:-1);foreach(var b in poly){float db=Distance(b,e,plane)*(outside?1:-1);if((da>=0)!=(db>=0)){float f=da/(da-db);r.Add(new P(a.V+(b.V-a.V)*f,(a.N+(b.N-a.N)*f).normalized));}if(db>=0)r.Add(b);a=b;da=db;}return r;}
 }
}
