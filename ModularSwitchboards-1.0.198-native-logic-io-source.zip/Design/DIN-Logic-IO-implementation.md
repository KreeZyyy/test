## 1.0.198 — DIN Logic terminal alignment, own small helpers and shadows

All eight variants use bottom-left DATA IN (index 0), bottom-right DATA OUT (index 1), and one centred top POWER (index 2). Positive local X is viewer-left. Screw heads are now 7 × 6 mm; their smaller click boxes remain aligned with cable targets. IN / OUT / PWR markings sit on the white shoulders. A shared terminal layout drives screw centres, cable entries, socket cut-outs, and route escape direction. The old generic central end disks are suppressed with `noTerminals`. Actual 9 mm square openings are clipped from our end faces, with recessed black backs and liners; there are no extra fake holes.

Only the housing casts and receives shadows. The panel, glyphs, pads, controls, LED and terminal details no longer project tiny text/contact silhouettes onto the cabinet. Hidden copied cursor renderers explicitly stop casting shadows as well.

The existing native helper renderer/reference and port metadata stay intact, but its mesh is replaced by our own 12 mm arrow, with its tip at the exact cable entry. It is re-fitted after native placement updates, compensates for parent scale, suppresses extra helper child renderers, and casts no shadows. This removes reliance on the native arrow's bounds and pivot. Non-mesh helpers are hidden safely while retaining the native reference.

Moved saved DIN cable endpoints join the existing atomic rerouting check. Rerouting now preserves the LogicData flag (previously omitted from the copied wire record), alongside connections, cable type, colour, quantity and damage state. Routing failure retains the complete old wiring and reports manual rewiring, as before. Native selector actions, ticks, save/network contracts and pin identities remain unchanged.

Validation: native build with zero warnings/errors; 656 own geometry/control/cache/layout/socket checks; 308 palette/helper/shadow checks; 113 compiled native and moved-wire contracts. Updated tooltips, wiring labels and F1 help match the terminal layout. Updated own-model preview and eight icons. Blender is an authoring preview; real game placement arrows, shadows, cable migration and interactions still require client validation. Previous network/service regressions are carried forward, not claimed as freshly rerun.

## 1.0.197 — Restore DIN Logic role colours and fit cursor helpers

Fixes the blue, indistinguishable DIN Logic fronts reported from 1.0.196. Unity cloning does not retain MaterialPropertyBlocks, and the native colour writer was treating the whole authored model as a paintable unit. Only the housing now enters that native renderer list; native paint-cache discovery is disabled for the DIN Logic types. Restore our own per-role palette after native Awake, renderer registration and colour/material refresh, with a throttled fallback refresh. White casing/lettering, black face/recesses and grey screw/contact metal stay distinct. LED blocks are cleared without replacing the native state material, so its normal/error colours remain under native logic control.

Cursor helpers for these eight modules keep their original references, roles and types but are normalized to 18 mm and placed at the exact own terminal anchors. Native helper grid snapping no longer spreads the arrows away from the DIN body. Other game/cabinet helpers are unchanged.

Validation: native build; actual palette/helper source fixtures covering missing clone blocks, native blue tint, repeat restoration, untouched LED materials/unowned objects, exact anchors and stable 18 mm scaling; compiled native/control/save/join/collider ordering checks. Actual game rendering still needs confirmation. Own geometry/colliders and previous startup fixes are retained.

## 1.0.196 — Own DIN Logic models and interaction colliders

Replaces the imported native Logic I/O fronts with our own procedural panel, side pads, 5x7 lettering, hex screw heads and twelve-sided LED lens on the existing two-position DIN housing. Native geometry and original hitboxes are not retained. All clickable targets are newly created box/sphere colliders. Reference measurements are rounded to millimetres and colour/state references are used for consistency; the finished model contains our generated vertices only.

Original action IDs, native logic classes, state handling, save/network payloads and 10 W wiring behavior remain. New interactables bind our colliders to the existing actions. A fresh native state controller drives our LED renderer; no original control GameObject survives. No native face mesh resources or extraction code are compiled into the game DLL. Eight new icons match the authored models.

Fixes the cursor Awake collision failure: fitted-body replacement now removes the deleted box from all three collision caches as well as build-state lists and lookup. Each DIN Logic instance/cursor starts native Awake with fresh cache lists so native CacheColliders appends only the current hierarchy. This preserves real native collision handling rather than suppressing its exception. The 1.0.195 null-slot/isolated-kit fix remains.

Validated: native build, own geometry/hitbox separation and bounds, cursor/instance cache append simulations, compiled native inheritance/save/join and reset-before-Awake order. Full live-game placement, clicking and status changes still need testing.

Authoritative geometry: Source/DinLogicFrontGeometry.cs and RoundedGeometry.cs. Control positions/actions: Source/DinLogicControlLayout.cs (rounded reference measurements, not geometry). Own components/colliders and native logic wiring: DinLogicModel.cs. No native mesh arrays are imported or embedded for these eight variants.

Verification/DinLogicOwn links actual builders and ThingColliderCache; it exports an own-geometry JSON with no game geometry input. Render that JSON with Tools/render_din_logic.py. The Blender preview and icons use that export and are not game screenshots.
