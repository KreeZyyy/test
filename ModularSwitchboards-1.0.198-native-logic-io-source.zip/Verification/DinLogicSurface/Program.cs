using ModularSwitchboards;using UnityEngine;using Assets.Scripts.Objects;using Assets.Scripts.Objects.Motherboards;
int n=0;void Check(bool c,string m){n++;if(!c)throw new Exception(m);}bool Near(float a,float b)=>Math.Abs(a-b)<1e-6f;
MeshRenderer Surface(Thing owner,string name){var r=new MeshRenderer{Owner=owner,name=name};owner.Surfaces.Add(r);return r;}
void Blue(Renderer r){var b=new MaterialPropertyBlock();b.SetFloat(1,0);b.SetColor(3,new Color{Name="blue tint"});r.SetPropertyBlock(b);for(int i=0;i<5;i++)r.SetPropertyBlock(b,i);}
foreach(bool missingBlocks in new[]{true,false}){
 var m=new LogicModule{Inactive=missingBlocks};var body=Surface(m,"DinBreakerModel");var face=Surface(m,"AuthoredLogicFace");var labels=Surface(m,"AuthoredLogicFaceTerminals");var screw=Surface(m,"AuthoredLogicScrew31");var led=Surface(m,"AuthoredLogicLED");var terminal=Surface(m,"LogicDataIn");var recess=Surface(m,"ScrewRecess");var unrelated=Surface(m,"OtherRenderer");Blue(unrelated);var inserted=Surface(new Thing(),"AuthoredLogicFace");m.Surfaces.Add(inserted);Blue(inserted);
 var ledMaterial=new Material{Name="current native green/error state"};led.sharedMaterials[0]=ledMaterial;
 if(!missingBlocks)foreach(var r in new[]{body,face,screw,led,terminal,recess})Blue(r);
 for(int repeat=0;repeat<3;repeat++){
  DinLogicSurface.Restore(m);
  foreach(var r in new[]{body,face,screw,led,terminal,recess})Check(r.Global==null,"native global tint remains");
  Check(labels.Slots[2].Floats[1]==(int)ColorType.Black,"terminal labels invisible on white casing");
  Check(face.Slots[0].Floats[1]==(int)ColorType.Black&&face.Slots[2].Floats[1]==(int)ColorType.White,"face/text indistinguishable after cloning/paint");
  Check(screw.Slots[3].Floats[1]==(int)ColorType.Black&&screw.Slots[4].Floats[1]==(int)ColorType.Gray,"screw slot/metal colours lost");
  Check(body.shadowCastingMode==UnityEngine.Rendering.ShadowCastingMode.On&&body.receiveShadows,"housing shadow lost");
  Check(new[]{face,screw,led,terminal,recess}.All(r=>r.shadowCastingMode==UnityEngine.Rendering.ShadowCastingMode.Off&&!r.receiveShadows),"fine details still cast/receive text shadows");
  Check(body.Slots[1].Floats[1]==(int)ColorType.White,"native blue overrides DIN housing");
  Check(terminal.Slots.Values.All(b=>b.Floats[1]==(int)ColorType.Gray)&&recess.Slots.Values.All(b=>b.Floats[1]==(int)ColorType.Black),"terminal/recess palette wrong");
  Check(ReferenceEquals(led.sharedMaterials[0],ledMaterial)&&led.Slots.Count==0,"LED native material/status overwritten");
  Check(unrelated.Global!=null&&inserted.Global!=null,"unowned renderer changed");
 }
}
{var plain=new Thing();var r=Surface(plain,"AuthoredLogicFace");Blue(r);DinLogicSurface.Restore(plain);Check(r.Global!=null,"ordinary native thing repainted");}
foreach(float dimension in new[]{.01f,.1f,.5f,1f})foreach(float scale in new[]{.2f,1f,2f}){
 var m=new LogicModule{IsCursor=true};var target=new Transform{position=new(.012f,.050625f,.03335f),rotation=new(){Id=37}};var arrow=new Renderer{Filter=new MeshFilter{sharedMesh=new Mesh{bounds=new Bounds{size=new(dimension*.5f,dimension,dimension*.2f)}}}};arrow.transform.localScale=Vector3.one*scale;arrow.transform.ParentScale=new(2,.5f,3);arrow.transform.position=new(0,.25f,0);var port=new Connection{Transform=target,HelperRenderer=arrow};m.OpenEnds.Add(port);
 for(int i=0;i<3;i++){DinLogicPortHelpers.Fit(m);Check(Near(arrow.transform.position.x,target.position.x)&&Near(arrow.transform.position.y,target.position.y)&&Near(arrow.transform.position.z,target.position.z),"helper remains snapped to native grid");Check(arrow.transform.rotation.Id==37,"helper rotation not bound to own terminal");Check(Near(arrow.Filter.sharedMesh.bounds.size.z*arrow.transform.lossyScale.z,.012f),"helper not normalized to 12 mm or drifted on repeat");Check(arrow.shadowCastingMode==UnityEngine.Rendering.ShadowCastingMode.Off&&!arrow.receiveShadows,"helper casts shadows");Check(arrow.Filter.sharedMesh.name=="Switchboards.DinLogic.PortArrow","native arrow geometry retained");Check(port.Type=="Data"&&port.Role=="Input"&&ReferenceEquals(port.HelperRenderer,arrow),"native port metadata/helper reference changed");}
}
{var ordinary=new Structure{IsCursor=true};DinLogicPortHelpers.Fit(ordinary);var placed=new LogicModule();var arrow=new Renderer();placed.OpenEnds.Add(new(){HelperRenderer=arrow,Transform=new()});DinLogicPortHelpers.Fit(placed);Check(arrow.transform.localScale.x==1,"real instance helper changed");}
Console.WriteLine(n+" actual DIN palette restoration/helper sizing checks passed: clone/blue tint, native LED preservation, exact anchors, 12 mm and scope.");
