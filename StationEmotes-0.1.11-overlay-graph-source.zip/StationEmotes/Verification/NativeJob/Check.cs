// Control-flow regression harness only. Does not simulate the Unity engine/IK solver.
using System;using StationEmotes;using UnityEngine;using UnityEngine.Animations;
namespace UnityEngine {
 public struct Vector3 {public float y;public static Vector3 zero=>default;}
 public struct Quaternion {public static Quaternion identity=>default;public static Quaternion Slerp(Quaternion a,Quaternion b,float w)=>b;}
 public enum AvatarIKGoal {LeftFoot,RightFoot}
}
namespace UnityEngine.Animations {
 public interface IAnimationJob {void ProcessAnimation(AnimationStream s);void ProcessRootMotion(AnimationStream s);}
 public struct AnimationStream {public bool isHumanStream;public AnimationHumanStream AsHuman(){if(!isHumanStream)throw new Exception("AsHuman on generic stream");return new AnimationHumanStream();}}
 public struct TransformStreamHandle {
  public bool Valid;public bool IsValid(AnimationStream s)=>Valid;public void Resolve(AnimationStream s){}
  public Quaternion GetLocalRotation(AnimationStream s)=>default;public void SetLocalRotation(AnimationStream s,Quaternion r){Check.Writes++;}
 }
 public struct AnimationHumanStream {
  public float leftFootHeight=>.1f;public float rightFootHeight=>.2f;
  public Vector3 GetGoalPositionFromPose(AvatarIKGoal g)=>new Vector3{y=99};public Quaternion GetGoalRotationFromPose(AvatarIKGoal g)=>default;
  public void SetGoalPosition(AvatarIKGoal g,Vector3 p){if(g==AvatarIKGoal.LeftFoot)Check.Left=p.y;else Check.Right=p.y;}
  public void SetGoalRotation(AvatarIKGoal g,Quaternion q){}public void SetGoalWeightPosition(AvatarIKGoal g,float w){}public void SetGoalWeightRotation(AvatarIKGoal g,float w){}
  public void SolveIK(){Check.Solves++;}
 }
}
class Check {
 public static int Writes,Solves;public static float Left,Right;
 static void A(bool b,string why){if(!b)throw new Exception(why);}
 static void Main(){
  var j=new PoseJob{Count=3,Feet=true,LeftFloor=2,RightFloor=3};
  j.Set(0,new PoseSlot{Handle=new TransformStreamHandle{Valid=true},Rotation=Quaternion.identity,Weight=1});
  j.Set(1,new PoseSlot{Handle=new TransformStreamHandle{Valid=true},Rotation=Quaternion.identity,Weight=1});
  j.Set(2,new PoseSlot{Handle=new TransformStreamHandle{Valid=false},Weight=1});
  j.ProcessAnimation(new AnimationStream{isHumanStream=false});
  A(Writes==2,"generic stream dropped valid bone poses");A(Solves==0,"generic stream attempted human IK");A(j.Frames==1&&j.HumanFrames==0&&j.LastApplied==2,"generic diagnostics wrong");
  j.ProcessAnimation(new AnimationStream{isHumanStream=true});
  A(Writes==4&&Solves==1,"human stream did not apply poses and IK");A(Math.Abs(Left-2.1f)<.0001f&&Math.Abs(Right-3.2f)<.0001f,"floor/foot-height goals wrong");A(j.Frames==2&&j.HumanFrames==1,"human counters wrong");
  j.Feet=false;j.ProcessAnimation(new AnimationStream{isHumanStream=true});A(Writes==6&&Solves==1,"arm pose invoked foot IK");
  j.ProcessRootMotion(default);A(Writes==6,"root motion handler changes transforms");
  Console.WriteLine("8 production-job control-flow checks passed (Unity stubs; no live IK execution).");
 }
}
