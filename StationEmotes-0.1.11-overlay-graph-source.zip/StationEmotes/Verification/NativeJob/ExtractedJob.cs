using UnityEngine;using UnityEngine.Animations;
namespace StationEmotes {
 internal struct PoseSlot
 {
  public TransformStreamHandle Handle;public Quaternion Rotation;public float Weight;
  public bool Apply(AnimationStream stream)
  {if(!Handle.IsValid(stream))return false;Handle.Resolve(stream);Handle.SetLocalRotation(stream,Quaternion.Slerp(Handle.GetLocalRotation(stream),Rotation,Weight));return true;}
 }
 internal struct PoseJob:IAnimationJob
 {
  public int Count,Frames,HumanFrames,LastApplied;public bool Feet;public float LeftFloor,RightFloor;
  public PoseSlot A,B,C,D,E,F,G,H,I,J;
  public PoseSlot Get(int i){switch(i){case 0:return A;case 1:return B;case 2:return C;case 3:return D;case 4:return E;case 5:return F;case 6:return G;case 7:return H;case 8:return I;default:return J;}}
  public void Set(int i,PoseSlot s){switch(i){case 0:A=s;break;case 1:B=s;break;case 2:C=s;break;case 3:D=s;break;case 4:E=s;break;case 5:F=s;break;case 6:G=s;break;case 7:H=s;break;case 8:I=s;break;default:J=s;break;}}
  public void ProcessRootMotion(AnimationStream stream){} // Original root motion passes through unchanged.
  public void ProcessAnimation(AnimationStream stream)
  {
   Frames++;LastApplied=0;
   bool humanoid=stream.isHumanStream;
   if(humanoid)HumanFrames++;
   // Bone animation is valid for both generic and humanoid streams.
   // The Animator avatar being humanoid does not establish this stream's type.
   var human=humanoid?stream.AsHuman():default(AnimationHumanStream);
   // Capture the native stance BEFORE changing hips/legs. Let Unity solve knees/ankles.
   var left=humanoid?human.GetGoalPositionFromPose(AvatarIKGoal.LeftFoot):Vector3.zero;
   var right=humanoid?human.GetGoalPositionFromPose(AvatarIKGoal.RightFoot):Vector3.zero;
   var lr=humanoid?human.GetGoalRotationFromPose(AvatarIKGoal.LeftFoot):Quaternion.identity;var rr=humanoid?human.GetGoalRotationFromPose(AvatarIKGoal.RightFoot):Quaternion.identity;
   for(int i=0;i<Count;i++)if(Get(i).Apply(stream))LastApplied++;
   if(!Feet||!humanoid)return;
   left.y=LeftFloor+human.leftFootHeight;right.y=RightFloor+human.rightFootHeight;
   human.SetGoalPosition(AvatarIKGoal.LeftFoot,left);human.SetGoalPosition(AvatarIKGoal.RightFoot,right);
   human.SetGoalRotation(AvatarIKGoal.LeftFoot,lr);human.SetGoalRotation(AvatarIKGoal.RightFoot,rr);
   human.SetGoalWeightPosition(AvatarIKGoal.LeftFoot,1f);human.SetGoalWeightPosition(AvatarIKGoal.RightFoot,1f);
   human.SetGoalWeightRotation(AvatarIKGoal.LeftFoot,1f);human.SetGoalWeightRotation(AvatarIKGoal.RightFoot,1f);
   human.SolveIK();
  }
 }
}
