# Station Emotes 0.1.11
Requires BepInEx and StationeersLaunchPad. Replace the previous mod version, do not enable duplicate versions.

Hold F10 and select with the mouse; release to play. F11 or movement cancels. Esc closes the menu only. Native Wave loops; Salute and Sit hold. Custom Hands up, Point, Robot dance and Meme dance require empty hands. Observing clients should use the same version.

0.1.11 changes graph scheduling: an explicitly played, owned overlay graph targets the Animator using AnimationStreamSource.PreviousInputs and sorting order 1000. It consumes the preceding native animation output. The native Animator graph and controller are not rewired or destroyed. Cancel destroys only the overlay created by the mod.

Custom poses still use procedural stream bone updates, with humanoid foot IK for dance where available. No imported animation clip or new physical movement is included. Native animations and cancellation policies are unchanged.

The 0.1.10 client log repeatedly showed a connected output but zero processed frames and zero applied bones. This release changes the graph evaluation path. Execution counters remain logged after one second; actual Unity rendering, graph evaluation, foot IK and multiplayer appearance still require live verification.

Build: source/StationEmotes.csproj, net472. Set GameManagedDirectory, BepInExDirectory and LaunchPadDirectory. Use the installed game UnityEngine.AnimationModule (including UnityEngine.Experimental.Animations output extensions) and PhysicsModule. Do not ship game or loader DLLs.
