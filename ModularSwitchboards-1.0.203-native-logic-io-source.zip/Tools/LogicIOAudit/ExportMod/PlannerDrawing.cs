using System;using System.Collections.Generic;using System.Linq;using System.Text;
namespace LogicIOAuthoring { public static class PlannerDrawing {
  private static string Esc(string s)=>System.Security.SecurityElement.Escape(s??"");
  private static string Num(float x)=>x.ToString("0.###",System.Globalization.CultureInfo.InvariantCulture);
  public static string Draw(List<Layout> plans){
   var b=new StringBuilder();int rows=(plans.Count+2)/3;
   b.Append("<svg xmlns='http://www.w3.org/2000/svg' width='1440' height='").Append(rows*405+80).Append("'><rect width='100%' height='100%' fill='#15202a'/><style>text{font-family:sans-serif;fill:#edf1f3;font-size:12px}</style><text x='20' y='26'>Actual native ports — proposed DIN positions on TOP / BOTTOM only</text>");
   for(int i=0;i<plans.Count;i++){
    var p=plans[i];float x=20+i%3*475,y=45+i/3*405,cx=x+225,cy=y+202,scale=Math.Min(2.5f,400f/p.bodyWidthMm),w=p.bodyWidthMm*scale,h=p.bodyHeightMm*scale;
    b.Append("<g><text x='").Append(Num(x+8)).Append("' y='").Append(Num(y+18)).Append("'>").Append(Esc(p.prefab)).Append(" · ").Append(p.slots).Append(" slots · ").Append(Num(p.usedPower)).Append(" W</text>");
    b.Append("<rect x='").Append(Num(cx-w/2)).Append("' y='").Append(Num(cy-h*.5f)).Append("' width='").Append(Num(w)).Append("' height='").Append(Num(h)).Append("' rx='4' fill='#697570' stroke='#c8cecc'/>");
    foreach(var t in p.terminals){float tx=cx+t.localPositionMm[0]*scale,ty=cy-t.localPositionMm[1]*scale;
     b.Append("<circle cx='").Append(Num(tx)).Append("' cy='").Append(Num(ty)).Append("' r='6' fill='").Append(t.type.IndexOf("Power",StringComparison.OrdinalIgnoreCase)>=0?"#cc7474":"#74a7c9").Append("'/><text text-anchor='middle' x='").Append(Num(tx)).Append("' y='").Append(Num(ty+(t.edge=="top"?-14:24))).Append("' style='font-size:10px'>").Append(Esc("#"+t.originalIndex+" "+t.function.Replace(" + PWR",""))).Append("<title>").Append(Esc(t.type+" / "+t.role)).Append("</title></text>");
    }
    foreach(var c in p.controls.Where(c=>c.physical)){float tx=cx+c.facePositionMm[0]*scale,ty=cy-c.facePositionMm[1]*scale;
     b.Append("<circle cx='").Append(Num(tx)).Append("' cy='").Append(Num(ty)).Append("' r='11' fill='#aeb8b1' stroke='#202c34'/><text text-anchor='middle' x='").Append(Num(tx)).Append("' y='").Append(Num(ty-17)).Append("'>").Append(Esc(c.label)).Append("</text>");
    }
    b.Append("<text x='").Append(Num(x+8)).Append("' y='").Append(Num(y+383)).Append("'>Native IN index: ").Append(p.input1Index).Append(" / OUT index: ").Append(p.outputIndex).Append(" · ").Append(p.terminals.Length).Append(" physical connectors</text></g>");
   }return b.Append("</svg>").ToString();
  }
}}
