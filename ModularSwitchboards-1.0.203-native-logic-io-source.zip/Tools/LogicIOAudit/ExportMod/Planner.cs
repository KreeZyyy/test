using System;
using System.Collections.Generic;
using System.Linq;
namespace LogicIOAuthoring {
 [Serializable] public sealed class Templates {public Face[] modules;}
 [Serializable] public sealed class Face {public string name,nativeType;public int proposedDinSlots;public Mark[] controls;}
 [Serializable] public sealed class Mark {public string label,kind;public int actionId;public float[] dinCenterMm;}
 [Serializable] public sealed class Native {public string prefab,concreteType;public float usedPower;public int input1Index,outputIndex;public int[] openEndsPermutation;public Port[] ports;public Control[] controls;}
 [Serializable] public sealed class Port {public int index;public string type,role;}
 [Serializable] public sealed class Control {public int index,actionId;public string action,label;public bool physical;}
 [Serializable] public sealed class Layout {
  public string prefab,concreteType;public float usedPower,bodyWidthMm,bodyHeightMm=101.25f;
  public int slots,input1Index,outputIndex;public int[] openEndsPermutation;
  public Terminal[] terminals;public Target[] controls;
  public string semantics="Native power consumption, port types/roles/order, network indices and control actions retained. This is an authoring plan, not an implemented DIN module.";
 }
 [Serializable] public sealed class Terminal {public int originalIndex;public string type,role,function,edge;public bool inputNetwork,outputNetwork;public float[] localPositionMm,localForward;}
 [Serializable] public sealed class Target {public int originalIndex,actionId;public string action,label,kind;public bool physical;public float[] facePositionMm;}
 public static class Planner {
  public const float Pitch=40.5f,BaseWidth=39.6f,TerminalPitch=16f;
  public static Layout Build(Native original,Face face){
   if(original.concreteType!=face.nativeType)throw new ArgumentException("Native type/template mismatch.");
   var ports=original.ports??new Port[0];var controls=original.controls??new Control[0];var marks=face.controls??new Mark[0];
   if(ports.Length==0)throw new ArgumentException("Native cable port list is empty.");
   if(ports.Select(p=>p.index).Distinct().Count()!=ports.Length||ports.Any(p=>p.index<0||p.index>=ports.Length))throw new ArgumentException("Native port indices are not a complete unique OpenEnds sequence.");
   if(controls.Select(c=>c.index).Distinct().Count()!=controls.Length)throw new ArgumentException("Duplicate native interactable indices.");
   foreach(var mark in marks)if(!controls.Any(c=>c.actionId==mark.actionId))throw new ArgumentException("Native functional control missing: "+face.name+" "+mark.label);
   var terminals=ports.Select(p=>{
    bool input=p.index==original.input1Index,output=p.index==original.outputIndex,power=p.type=="Power"||p.type=="PowerAndData",data=p.type=="Data"||p.type=="PowerAndData";
    string edge=output&&!input?"bottom":input?"top":p.role!=null&&p.role.IndexOf("Output",StringComparison.OrdinalIgnoreCase)>=0?"bottom":"top";
    string function=data?(input&&output?"IN/OUT":input?"IN":output?"OUT":"AUX DATA"):power?"PWR":"AUX "+p.type;
    if(power&&data)function+=" + PWR";
    return new Terminal{originalIndex=p.index,type=p.type,role=p.role,inputNetwork=input,outputNetwork=output,edge=edge,function=function};
   }).OrderBy(p=>p.originalIndex).ToArray();
   int rowCount=Math.Max(terminals.Count(p=>p.edge=="top"),terminals.Count(p=>p.edge=="bottom"));
   for(int slots=Math.Max(1,face.proposedDinSlots);slots<=32;slots++){
    float width=BaseWidth+(slots-1)*Pitch;
    if(rowCount>0&&(rowCount-1)*TerminalPitch+20>width)continue;
    var placed=new List<Target>();bool fits=true;
    foreach(var originalControl in controls){
     var mark=marks.FirstOrDefault(m=>m.actionId==originalControl.actionId);
     bool physical=mark!=null||originalControl.physical;float[] pos=null;
     if(physical){
      if(mark!=null&&Free(mark.dinCenterMm[0],mark.dinCenterMm[1],width,placed))pos=(float[])mark.dinCenterMm.Clone();
      else foreach(float y in new[]{25f,8f,-10f,-27f}){foreach(float x in new[]{width*.5f-10,-width*.5f+10,0f})if(Free(x,y,width,placed)){pos=new[]{x,y};break;}if(pos!=null)break;}
      if(pos==null){fits=false;break;}
     }
     placed.Add(new Target{originalIndex=originalControl.index,actionId=originalControl.actionId,action=originalControl.action,label=mark==null?originalControl.label:mark.label,kind=mark==null?"native":mark.kind,physical=physical,facePositionMm=pos});
    }
    if(!fits)continue;
    foreach(string edge in new[]{"top","bottom"}){
     var row=terminals.Where(t=>t.edge==edge).OrderBy(t=>t.originalIndex).ToArray();
     for(int k=0;k<row.Length;k++){row[k].localPositionMm=new[]{(k-(row.Length-1)*.5f)*TerminalPitch,edge=="top"?50.625f:-50.625f,33.35f};row[k].localForward=new[]{0f,edge=="top"?1f:-1f,0f};}
    }
    return new Layout{prefab=original.prefab,concreteType=original.concreteType,usedPower=original.usedPower,slots=slots,bodyWidthMm=width,input1Index=original.input1Index,outputIndex=original.outputIndex,openEndsPermutation=original.openEndsPermutation==null?null:(int[])original.openEndsPermutation.Clone(),terminals=terminals,controls=placed.ToArray()};
   }
   throw new InvalidOperationException("Native ports/controls need more than 32 slots; review snapshot.");
  }
  private static bool Free(float x,float y,float width,IEnumerable<Target> placed)=>Math.Abs(x)+6<=width*.5f-2&&Math.Abs(y)<=32&&placed.Where(p=>p.physical).All(p=>Math.Pow(p.facePositionMm[0]-x,2)+Math.Pow(p.facePositionMm[1]-y,2)>=16*16);
 }
}
