using System;using System.IO;using UnityEngine;using UnityEngine.Rendering;
namespace LogicIOAuthoring { internal static class NativeMeshReader {
        internal static void Read(Mesh mesh, out Vector3[] vertices, out Vector2[] uv, out int[][] triangles)
        {
            triangles = new int[mesh.subMeshCount][];
            if (mesh.isReadable)
            {
                vertices=mesh.vertices;uv=mesh.uv;
                for(int i=0;i<triangles.Length;i++) triangles[i]=mesh.GetIndices(i);
                return;
            }
            if(SystemInfo.graphicsDeviceType==GraphicsDeviceType.Null)throw new InvalidOperationException("Native mesh '"+mesh.name+"' has no CPU-readable data on this headless server; GPU buffer access is disabled. Supply matching CPU mesh data rather than using a placeholder model.");
            vertices = new Vector3[mesh.vertexCount]; uv = new Vector2[mesh.vertexCount];
            foreach (var attribute in new[] { VertexAttribute.Position, VertexAttribute.TexCoord0 })
            {
                if(!mesh.HasVertexAttribute(attribute)){if(attribute==VertexAttribute.TexCoord0)uv=new Vector2[0];continue;}
                var format=mesh.GetVertexAttributeFormat(attribute);
                if (format != VertexAttributeFormat.Float32 && format != VertexAttributeFormat.Float16)
                    throw new InvalidOperationException("Unsupported native vertex format " + attribute + ": " + format);
                int size=format==VertexAttributeFormat.Float32?4:2;
                int stream=mesh.GetVertexAttributeStream(attribute), stride=mesh.GetVertexBufferStride(stream);
                int offset=mesh.GetVertexAttributeOffset(attribute);
                using(var buffer=mesh.GetVertexBuffer(stream))
                {
                    var data=new uint[buffer.count*buffer.stride/4];buffer.GetData(data);
                    var bytes=new byte[data.Length*4];Buffer.BlockCopy(data,0,bytes,0,bytes.Length);
                    for(int i=0;i<mesh.vertexCount;i++)
                    {
                        int start=i*stride+offset;
                        float x=ReadFloat(bytes,start,size),y=ReadFloat(bytes,start+size,size);
                        if(attribute==VertexAttribute.Position) vertices[i]=new Vector3(x,y,ReadFloat(bytes,start+size*2,size));
                        else uv[i]=new Vector2(x,y);
                    }
                }
            }
            using(var buffer=mesh.GetIndexBuffer())
            {
                bool wide=mesh.indexFormat==IndexFormat.UInt32;
                var bytes=new byte[buffer.count*buffer.stride];
                if(wide) { var raw=new uint[bytes.Length/4];buffer.GetData(raw);Buffer.BlockCopy(raw,0,bytes,0,bytes.Length); }
                else { var raw=new ushort[bytes.Length/2];buffer.GetData(raw);Buffer.BlockCopy(raw,0,bytes,0,bytes.Length); }
                for(int sub=0;sub<triangles.Length;sub++)
                {
                    var desc=mesh.GetSubMesh(sub);var indices=new int[desc.indexCount];
                    for(int j=0;j<indices.Length;j++)
                    {
                        int address=(desc.indexStart+j)*(wide?4:2);
                        indices[j]=(wide?(int)BitConverter.ToUInt32(bytes,address):BitConverter.ToUInt16(bytes,address))+desc.baseVertex;
                    }
                    triangles[sub]=indices;
                }
            }
        }

        private static float ReadFloat(byte[] bytes,int start,int size)
        {
            if(size==4) return BitConverter.ToSingle(bytes,start);
            int h=BitConverter.ToUInt16(bytes,start), sign=(h>>15)==0?1:-1, exponent=(h>>10)&31, mantissa=h&1023;
            if(exponent==31) throw new InvalidDataException("Non-finite native half vertex.");
            return sign*(exponent==0 ? mantissa*(float)Math.Pow(2,-24) : (1f+mantissa/1024f)*(float)Math.Pow(2,exponent-15));
        }

}}
