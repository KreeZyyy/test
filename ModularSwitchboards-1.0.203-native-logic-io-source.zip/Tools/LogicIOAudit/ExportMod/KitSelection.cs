using System;
using System.Collections.Generic;
using System.Linq;
namespace LogicIOAuthoring {
 public sealed class KitOption {public int sourceIndex;public string prefab;public string[] memberTypes;}
 public static class KitSelection {
  public static KitOption[] Match(IEnumerable<KitOption> options,ISet<string> wanted)=>options.Where(o=>o.memberTypes!=null&&wanted.SetEquals(o.memberTypes.Where(t=>wanted.Contains(t)))).OrderBy(o=>o.memberTypes.Length).ThenBy(o=>o.prefab,StringComparer.Ordinal).ToArray();
 }
}
