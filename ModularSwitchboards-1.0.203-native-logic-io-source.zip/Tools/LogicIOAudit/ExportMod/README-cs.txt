NATIVE LOGIC I/O KIT EXPORT — 0.2.0

Vytáhne všechny originální vzhledy přímo z Logic I/O kitu: modely, UV, materiály, textury, konstrukční stupně a hierarchii dílů včetně šroubků a konektorů. Přidá původní napájení a ovládání i návrh přesunu portů pouze nahoru/dolů.

INSTALACE A POUŽITÍ
1. Složku NativeLogicIOAudit z tohoto ZIPu dej do Documents/My Games/Stationeers/mods/ vedle ModularSwitchboards. Pokud máš starší audit 0.1.0, nahraď ho touto verzí; nezapínej dvě kopie.
2. Zapni Native Logic I/O Kit Export v LaunchPadu a spusť hru. Vyčká na skutečný konstrukční kit obsahující všech devět typů. Pokud prefaby hra načítá až se světem, otevři lokální testovací svět. Spusť v herním klientovi s grafikou; DS není potřeba.
3. Export může při čtení modelů a textur krátce pozastavit obraz. Po dokončení najdeš v NativeLogicIOAudit/Export/ soubor:
   NativeLogicIO-kit-reference-DATUM-CAS.zip
   Přesnou cestu vypíše log pod [Logic I/O Audit]. Při nedostupném zápisu do složky modu se použije Application.persistentDataPath/NativeLogicIOAudit.
4. Pošli výsledný referenční ZIP. Exportní mod pak můžeš vypnout.

OBSAH VÝSLEDKU
- LogicIO-kit.json: skutečný kit, jeho členové v původním pořadí, nativní názvy/třídy a případné chyby plánování.
- Models/LogicIO-kit-appearance.json: všechny varianty, hierarchie, konstrukční stupně, geometrie/UV/submeshe, materiály/shadery, vlastnosti a rendererové přepisy, odkazy na stavové materiály a souřadnice dílů.
- Models/*.obj: geometrie jednotlivých dílů v souřadnicích originálního prefabu. OBJ nepřenáší vlastní shader texturových polí; rozhodující jsou JSON a PNG.
- Models/*.png: snímky původních textur a používaných vrstev texturových polí. Neexportují se nepoužité barvy celé herní palety.
- Models/*.bin: původní vertex streamy, včetně normál, tangent a dalších UV kanálů pro přesnou rekonstrukci.
- NativeLogicIO-prefabs.json: původní napájení, porty a jejich typy/role/pozice, indexy sítí a ovládání.
- NativeLogicIO-top-bottom-plan.json a .svg: kompletní návrh přemístění skutečných konektorů nahoře/dole; při neúplných vstupních datech je tato část výslovně označena chybami.

DŮLEŽITÉ ROZLIŠENÍ
Tohle jsou originální podklady pro modelování, ne hotové hratelné DIN kopie a ne kompletní Unity AssetBundle. Původní herní funkce zůstanou v nativních třídách při následné implementaci. Skinned mesh, pokud se v kitu objeví, je označen jako snímek současné pózy.

Při chybě čtení GPU/modelu/textury se výsledek označí PARTIAL a chyby zůstanou v JSONu. I tak pošli ZIP, aby šla příčina určit. Export nic nestaví, nepřepisuje originální materiály/prefaby ani nemění kabely. Není součástí herního vydání Modular Switchboards 1.0.190. Sestavení a offline kontroly jsou ověřené, spuštění ve tvé hře se teprve ověří tímto exportem.
