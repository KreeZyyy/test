# Native Logic I/O audit

This authoring tool does not modify or load the game runtime. The production mod does not compile anything under this directory.

## Offline assembly audit (.NET 8)

```sh
dotnet run --project Tools/LogicIOAudit/Check.csproj -- /path/to/rocketstation_Data/Managed/Assembly-CSharp.dll /path/to/native-contracts.json
```

The report identifies the input assembly SHA-256/MVID and records the nine native Logic I/O types, their base classes/save types, field metadata, native enum constants and decoded method IL. Non-finite IL literals are encoded as named JSON strings. This confirms native control actions and logic behavior; it cannot confirm serialized prefab OpenEnds, power consumption, or physical positions. See Design/LogicIO-layouts.md for the curated mapping.

## Loaded prefab snapshot (Unity main thread)

`PrefabSnapshot.cs.example` is a compile-checked C# helper. The included `ExportMod` project now provides a loadable, separate LaunchPad authoring mod that calls it automatically after all nine original source types load. The helper can also be called from another authoring/debug integration:

```csharp
LogicIOPrefabSnapshot.Export(WorldManager.Instance.SourcePrefabs, absoluteOutputPath);
```

It reads original prefabs without modifying them and writes one JSON file containing prefab names/types, configured UsedPower, Input1Index/OutputIndex, OpenEndsPermutation, every actual port's index/type/role/position/forward, and every interactable's action/display name/collider center. Box collider size is explicitly in collider-local space. Non-box/sphere/capsule collider positions are marked as transform-origin estimates. It rejects an incomplete set of native types.

Do not infer connector counts from `Input1Index`/`OutputIndex` defaults. Consume the real snapshot before fixing a DIN connector layout. No runtime snapshot has been taken in this workspace. The production Modular Switchboards mod does not invoke it. The separate authoring mod invokes it when enabled; live Unity/LaunchPad execution still needs verification.

## Layout preview

The proposed controls and dimensions are stored separately in `Design/LogicIO-layouts.json`; their front-face overview is `Design/LogicIO-layouts.svg`. To render a PNG with Python/Pillow:

```sh
python Tools/LogicIOAudit/render_layouts.py --output /tmp/LogicIO-layouts.png
```

The wiring band is a reservation area, not a drawing of confirmed physical connectors. All original physical-port fields remain null until the loaded prefab snapshot is available.

## Complete top/bottom wiring planner

`ExportMod/Planner.cs` consumes the actual loaded native connectors and controls. Each OpenEnds entry appears exactly once with its original index, type and role. Input-network ports and independent power ports go on top; distinct output-network ports go on bottom; a shared native IN/OUT connector remains one top port. Combined PowerAndData is never split. Extra native ports remain present. Original network indices, port permutation, configured power and all native interactable IDs are retained. Native controls omitted from the earlier front template are allocated without overlap, or the body is widened. There are no side terminals. This creates an authoring plan, not playable native DIN copies.

`ExportMod/ExportMod.csproj` builds the optional LaunchPad collector. Supply GamePath and LaunchPadDirectory, then package the resulting NativeLogicIOAudit.dll under a local mod's Assemblies/ directory with About/About.xml. The prepared local ZIP does this already; see `ExportMod/README-cs.txt`.

It writes NativeLogicIO-prefabs.json, NativeLogicIO-top-bottom-plan.json and a concrete SVG beside the local mod under Export/ (falls back to Unity persistentDataPath if necessary). No game source prefabs, wiring or game saves are modified by the utility. Native assets and a live LaunchPad session are absent in this workspace; the actual snapshot must come from the user's local game.

PlannerChecks exercises role/index preservation, combined/separate power, shared and unused network indices, synthetic 2–12-port cases across all nine control templates, control clearance, width growth, and valid XML with escaped native labels. These checks do not establish actual original prefab port counts.

## Kit appearance export (0.2.0)

The separate LaunchPad collector now discovers the original MultiConstructor whose Constructables cover all nine native Logic I/O types. It preserves kit member order/original construction-option indices and exports every non-null member of that selected kit, including any additional variant. Candidate kits and raw construction-option count are recorded; no guessed kit prefab ID is used.

The output is one NativeLogicIO-kit-reference-UTC_TIMESTAMP.zip containing LogicIO-kit.json, the native connector/control snapshot, top/bottom plans, and Models/LogicIO-kit-appearance.json plus OBJ/PNG/raw vertex-stream files. The appearance JSON preserves original mesh-local geometry/UVs/submesh topology, transforms, active states, construction-stage renderer paths, shaders/material properties, per-renderer and per-material-slot property blocks, and material references found in switch/state components. Raw vertex streams and their attribute descriptions preserve imported normals, tangents, additional UVs and packed formats even when the mesh is not CPU readable. OBJ files are convenience geometry views, not replacements for custom texture-array shaders. Skinned meshes are explicitly marked as baked current pose.

Only referenced array indices and default/red/green/black/white slices are captured, not every unused paint palette layer. Original graphics format and readback RGBA32 format are recorded. Missing GPU/mesh/texture data is recorded as a partial export, never silently represented by substitute geometry. Native GPU capture requires a graphical game client. Actual Unity/LaunchPad/GPU execution has not been run in this workspace.

Native prefab objects and original meshes/materials are not edited. Texture readback creates and destroys only temporary readable Texture2D objects; skinned capture similarly owns its temporary baked mesh. The optional collector adds no playable DIN modules. Production Modular Switchboards remains 1.0.190.
