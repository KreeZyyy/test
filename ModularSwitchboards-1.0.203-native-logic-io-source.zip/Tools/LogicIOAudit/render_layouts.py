from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import json,argparse,tempfile
parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=Path(tempfile.gettempdir())/'LogicIO-layouts.png');args=parser.parse_args()
root=Path(__file__).resolve().parents[2]
plan=json.loads((root/'Design/LogicIO-layouts.json').read_text());S=2
im=Image.new('RGB',(1260*S,1170*S),'#101820');d=ImageDraw.Draw(im)
fontpath='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
def text(x,y,s,size=13,color='#e4e8eb',anchor=None):d.text((x*S,y*S),s,font=ImageFont.truetype(fontpath,size*S),fill=color,anchor=anchor)
def box(rect,fill,outline=None,width=1,radius=0):d.rounded_rectangle(tuple(int(a*S)for a in rect),radius*S,fill=fill,outline=outline,width=width*S)
def line(coords,fill,width=1):d.line(tuple(a*S for a in coords),fill=fill,width=width*S)
text(30,18,'Logic I/O — 9 proposed DIN faces',23);text(30,49,'Native control roles verified. Dimensions proposed. Actual cable sockets are copied by the top/bottom prefab planner.',12,'#aab7c0')
for index,m in enumerate(plan['modules']):
 x0=20+(index%3)*413;y0=82+(index//3)*355;w=m['proposedBodyWidthMm']*2.7;cx=x0+197;top=y0+38;cy=top+137
 box((x0,y0,x0+397,y0+340),'#1a2631',radius=10);text(x0+15,y0+8,m['name'],16)
 text(cx,top-6,'NATIVE IN / POWER GROUP',8,anchor='mm')
 box((cx-w/2,top,cx+w/2,top+273),'#a6aba9','#d0d5d1',radius=5);box((cx-w/2+6,top+9,cx+w/2-6,top+239),'#303b42',radius=3)
 d.ellipse(((cx-w/2+12)*S,(top+17)*S,(cx-w/2+20)*S,(top+25)*S),fill='#ca5049');text(cx,top+38,m['name'],10,anchor='mm')
 for c in m['controls']:
  x=cx+c['dinCenterMm'][0]*2.7;y=cy-c['dinCenterMm'][1]*2.7;text(x,y-27,c['label'],10,anchor='mm')
  if c['kind']=='screw':
   d.ellipse(((x-12)*S,(y-12)*S,(x+12)*S,(y+12)*S),fill='#788781',outline='#d3d8d2',width=S);line((x-7,y,x+7,y),'#1a2228',3)
  else:box((x-19,y-12,x+19,y+12),'#141d23','#c3cbc7',radius=3);line((x+5,y-6,x+5,y+6),'#e4e8eb',4)
 box((cx-w/2+7,top+243,cx+w/2-7,top+263),None,'#718c9d');text(cx,top+253,'NATIVE OUT GROUP',8,anchor='mm')
 n=sum(c['kind']=='screw'for c in m['controls']);caption=f"{m['proposedDinSlots']} slot(s) · {m['proposedBodyWidthMm']:.1f} mm · {n} screws"+(' + toggle'if any(c['kind']=='toggle'for c in m['controls'])else'');text(cx,y0+322,caption,12,'#aab7c0',anchor='mm')
text(30,1148,'Shared casing style; individual controls. Writer Switch activation remains a separate native hand control.',12,'#aab7c0')
im.resize((1260,1170),Image.Resampling.LANCZOS).save(args.output)
