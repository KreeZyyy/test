using System.Reflection;
using System.Reflection.Emit;
using System.Reflection.Metadata;
using System.Reflection.Metadata.Ecma335;
using System.Reflection.PortableExecutable;
using System.Security.Cryptography;
using System.Text.Json;

if(args.Length!=2){Console.Error.WriteLine("Usage: LogicIOAudit Assembly-CSharp.dll report.json");return 2;}
var bytes=File.ReadAllBytes(args[0]);using var pe=new PEReader(new MemoryStream(bytes));var r=pe.GetMetadataReader();
var names=new HashSet<string>{"LogicReader","LogicWriter","LogicBatchReader","LogicBatchWriter","LogicSlotReader","LogicMirror","ReagentReader","LogicBatchSlotReader","LogicWriterSwitch","LogicReaderBase","LogicReaderDeviceBase","LogicWriterBase","LogicInputBase","LogicUnitBase","LogicReaderSaveData","LogicWriterSaveData","LogicBatchReaderSaveData","LogicBatchWriterSaveData","LogicSlotReaderSaveData","LogicMirrorSaveData","LogicReagentReaderSaveData","LogicBatchSlotReaderSaveData","LogicWriterSwitchSaveData","InteractableType","LogicBatchMethod","LogicReagentMode"};
string Token(int n){try{var h=MetadataTokens.EntityHandle(n);return h.Kind switch{
 HandleKind.MethodDefinition=>Method((MethodDefinitionHandle)h),
 HandleKind.FieldDefinition=>Field((FieldDefinitionHandle)h),
 HandleKind.MemberReference=>Member((MemberReferenceHandle)h),
 HandleKind.MethodSpecification=>Token(MetadataTokens.GetToken(r.GetMethodSpecification((MethodSpecificationHandle)h).Method)),
 HandleKind.TypeDefinition=>r.GetString(r.GetTypeDefinition((TypeDefinitionHandle)h).Name),
 HandleKind.TypeReference=>r.GetString(r.GetTypeReference((TypeReferenceHandle)h).Name),_=>h.Kind.ToString()};}catch{return n.ToString("X8");}}
string Method(MethodDefinitionHandle h){var m=r.GetMethodDefinition(h);return r.GetString(r.GetTypeDefinition(m.GetDeclaringType()).Name)+"."+r.GetString(m.Name);}
string Field(FieldDefinitionHandle h){var f=r.GetFieldDefinition(h);return r.GetString(r.GetTypeDefinition(f.GetDeclaringType()).Name)+"."+r.GetString(f.Name);}
string Member(MemberReferenceHandle h){var m=r.GetMemberReference(h);return Token(MetadataTokens.GetToken(m.Parent))+"."+r.GetString(m.Name);}
var ops=typeof(OpCodes).GetFields().Where(f=>f.FieldType==typeof(OpCode)).Select(f=>(OpCode)f.GetValue(null)!).ToDictionary(o=>(ushort)o.Value);
var types=new List<object>();
foreach(var h in r.TypeDefinitions){var t=r.GetTypeDefinition(h);var name=r.GetString(t.Name);if(!names.Contains(name))continue;
 var fields=t.GetFields().Select(h=>{var f=r.GetFieldDefinition(h);object? value=null;var c=f.GetDefaultValue();if(!c.IsNil){var data=r.GetBlobBytes(r.GetConstant(c).Value);value=data.Length==4?BitConverter.ToInt32(data):Convert.ToHexString(data);}return new{name=r.GetString(f.Name),attributes=f.Attributes.ToString(),signature=Convert.ToHexString(r.GetBlobBytes(f.Signature)),constant=value};}).ToArray();
 var methods=new List<object>();foreach(var mh in t.GetMethods()){var m=r.GetMethodDefinition(mh);var instructions=new List<object>();
  if(m.RelativeVirtualAddress!=0){var b=pe.GetMethodBody(m.RelativeVirtualAddress).GetILBytes()!;for(int i=0;i<b.Length;){int at=i;ushort code=b[i++];if(code==0xfe)code=(ushort)(0xfe00+b[i++]);var op=ops[code];object? operand=null;int len=0;
   switch(op.OperandType){case OperandType.InlineNone:break;
    case OperandType.ShortInlineI:len=1;operand=(int)(sbyte)b[i];break;
    case OperandType.ShortInlineVar:len=1;operand=b[i];break;
    case OperandType.ShortInlineBrTarget:len=1;operand=(i+len+(sbyte)b[i]).ToString("X4");break;
    case OperandType.InlineVar:len=2;operand=BitConverter.ToUInt16(b,i);break;
    case OperandType.InlineI8:len=8;operand=BitConverter.ToInt64(b,i);break;
    case OperandType.InlineR:len=8;operand=BitConverter.ToDouble(b,i);break;
    case OperandType.ShortInlineR:len=4;operand=BitConverter.ToSingle(b,i);break;
    case OperandType.InlineSwitch:int count=BitConverter.ToInt32(b,i);len=4+count*4;operand=Enumerable.Range(0,count).Select(k=>(i+len+BitConverter.ToInt32(b,i+4+k*4)).ToString("X4")).ToArray();break;
    default:len=4;int v=BitConverter.ToInt32(b,i);operand=op.OperandType==OperandType.InlineString?r.GetUserString(MetadataTokens.UserStringHandle(v&0xffffff)):op.OperandType==OperandType.InlineI?v:op.OperandType==OperandType.InlineBrTarget?(i+len+v).ToString("X4"):Token(v);break;
   }i+=len;instructions.Add(new{offset=at.ToString("X4"),opcode=op.Name,operand});
  }}methods.Add(new{name=r.GetString(m.Name),attributes=m.Attributes.ToString(),instructions});
 }types.Add(new{name,attributes=t.Attributes.ToString(),ns=r.GetString(t.Namespace),baseType=Token(MetadataTokens.GetToken(t.BaseType)),fields,methods});
}
var report=new{assemblySha256=Convert.ToHexString(SHA256.HashData(bytes)).ToLowerInvariant(),moduleMvid=r.GetGuid(r.GetModuleDefinition().Mvid),assemblyVersion=r.GetAssemblyDefinition().Version.ToString(),limitations=new[]{"Metadata and IL only. No Unity code executed.","Prefab OpenEnds, network connector types/counts, used power, material references and physical control coordinates are serialized assets, not proven by this report."},types};
var output=Path.GetFullPath(args[1]);Directory.CreateDirectory(Path.GetDirectoryName(output)!);var temp=output+".tmp";File.WriteAllText(temp,JsonSerializer.Serialize(report,new JsonSerializerOptions{WriteIndented=true,NumberHandling=System.Text.Json.Serialization.JsonNumberHandling.AllowNamedFloatingPointLiterals}));File.Move(temp,output,true);Console.WriteLine($"Audited {types.Count} native types; report: {output}");return 0;
