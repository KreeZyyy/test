using LogicIOAuthoring;
using System.Text.Json;
int checks=0;void Check(bool condition,string message){checks++;if(!condition)throw new Exception(message);}
var path=args.Length==0?"work/headless-fix-draft/Design/LogicIO-layouts.json":args[0];var templates=JsonSerializer.Deserialize<Templates>(File.ReadAllText(path),new JsonSerializerOptions{IncludeFields=true});
// Exercise the production reader and report writer against the actual nine-module input.
var runtimeTemplates=Newtonsoft.Json.JsonConvert.DeserializeObject<Templates>(File.ReadAllText(path));
Check(runtimeTemplates.modules.Length==9,"runtime JSON reader lost module array");
Check(runtimeTemplates.modules.Sum(m=>m.controls.Length)==25,"runtime JSON reader lost native controls");
Check(runtimeTemplates.modules.Select(m=>m.nativeType).SequenceEqual(templates.modules.Select(m=>m.nativeType)),"runtime template types changed");
Check(runtimeTemplates.modules.SelectMany(m=>m.controls).All(c=>c.dinCenterMm.Length==2),"runtime JSON reader lost coordinates");
var jsonRoundTrip=ModularSwitchboards.DiagnosticJson.Serialize(runtimeTemplates);
var roundTrip=Newtonsoft.Json.JsonConvert.DeserializeObject<Templates>(jsonRoundTrip);
Check(roundTrip.modules.Length==9&&roundTrip.modules.Sum(m=>m.controls.Length)==25,"report JSON writer lost nested collections");
var previousCulture=System.Globalization.CultureInfo.CurrentCulture;
try{System.Globalization.CultureInfo.CurrentCulture=System.Globalization.CultureInfo.GetCultureInfo("cs-CZ");
 var reportJson=ModularSwitchboards.DiagnosticJson.Serialize(new[]{new Native{prefab="kit \"name\"",usedPower=7.25f,ports=new[]{new Port{index=3,type="PowerAndData"}},openEndsPermutation=new[]{2,1}}});
 var reports=Newtonsoft.Json.JsonConvert.DeserializeObject<Native[]>(reportJson);
 Check(reports[0].usedPower==7.25f&&reports[0].ports.Single().index==3&&reports[0].openEndsPermutation.SequenceEqual(new[]{2,1})&&reports[0].prefab=="kit \"name\"","report JSON locale/escaping/port arrays corrupted");
}finally{System.Globalization.CultureInfo.CurrentCulture=previousCulture;}
if(args.Length>1){
 var production=System.Reflection.Assembly.LoadFile(Path.GetFullPath(args[1]));
 using var input=production.GetManifestResourceStream("LogicIOAudit.Layouts.json");
 Check(input!=null,"production assembly missing template resource");
 using var reader=new StreamReader(input);var embedded=Newtonsoft.Json.JsonConvert.DeserializeObject<Templates>(reader.ReadToEnd());
 Check(embedded.modules.Length==9&&embedded.modules.Sum(m=>m.controls.Length)==25,"production embedded templates fail runtime parser");
}
void Verify(Native n,Face f){var plan=Planner.Build(n,f);Check(plan.terminals.Length==n.ports.Length,"invented/deleted connector");Check(plan.input1Index==n.input1Index&&plan.outputIndex==n.outputIndex,"changed native network indices");Check(plan.usedPower==n.usedPower,"changed native power consumption");Check(plan.openEndsPermutation.SequenceEqual(n.openEndsPermutation)&&!ReferenceEquals(plan.openEndsPermutation,n.openEndsPermutation),"changed/shared native port permutation");
 foreach(var port in n.ports){var p=plan.terminals.Single(p=>p.originalIndex==port.index);Check(p.type==port.type&&p.role==port.role,"changed native connector type/role");Check(p.edge=="top"||p.edge=="bottom","side cable connection");Check(Math.Abs(p.localPositionMm[1])==50.625f&&p.localForward[1]==(p.edge=="top"?1:-1),"incorrect cable edge or direction");Check(Math.Abs(p.localPositionMm[0])+10<=plan.bodyWidthMm*.5f,"terminal clipped outside body");}
 foreach(var row in plan.terminals.GroupBy(p=>p.edge)){var xs=row.Select(p=>p.localPositionMm[0]).OrderBy(x=>x).ToArray();for(int i=1;i<xs.Length;i++)Check(xs[i]-xs[i-1]>=16,"cable terminals overlap");}
 var svg=System.Xml.Linq.XDocument.Parse(PlannerDrawing.Draw(new List<Layout>{plan}));Check(svg.Root.Name.LocalName=="svg","invalid XML drawing");Check(svg.Descendants().Count(x=>x.Name.LocalName=="circle")==plan.terminals.Length+plan.controls.Count(c=>c.physical),"drawing omits port/control");
 Check(plan.controls.Length==n.controls.Length,"native interactable lost");foreach(var c in n.controls){var p=plan.controls.Single(p=>p.originalIndex==c.index);Check(p.actionId==c.actionId&&p.action==c.action,"native action remapped");}
 var targets=plan.controls.Where(c=>c.physical).ToArray();foreach(var a in targets)foreach(var b in targets.Where(b=>b.originalIndex>a.originalIndex))Check(Math.Pow(a.facePositionMm[0]-b.facePositionMm[0],2)+Math.Pow(a.facePositionMm[1]-b.facePositionMm[1],2)>=256,"control hitboxes overlap");
}
foreach(var face in templates.modules){
 var ctr=face.controls.Select((c,i)=>new Control{index=i,actionId=c.actionId,action=c.kind=="toggle"?"Activate":"Button",label=c.label,physical=true}).Concat(new[]{new Control{index=50,actionId=100,label="Power ON/OFF",action="OnOff",physical=true},new Control{index=51,actionId=101,label="Hidden native state",action="State",physical=false}}).ToArray();
 foreach(int count in Enumerable.Range(2,11)){
  var ports=Enumerable.Range(0,count).Select(i=>new Port{index=i,type=i==0?"PowerAndData":"Data",role=i==1?"Output1":"Input1"}).ToArray();
  var n=new Native{prefab=face.name+" & native<profile>",concreteType=face.nativeType,usedPower=7.25f,input1Index=0,outputIndex=1,openEndsPermutation=new[]{4,3,2,1,0,5},ports=ports,controls=ctr};Verify(n,face);
  var first=Planner.Build(n,face);n.ports=n.ports.Reverse().ToArray();var second=Planner.Build(n,face);Check(first.terminals.Select(p=>string.Join(",",p.localPositionMm)).SequenceEqual(second.terminals.Select(p=>string.Join(",",p.localPositionMm))),"input list ordering changed stable port mapping");
 }
 var separate=new Native{prefab=face.name+" & native<profile>",concreteType=face.nativeType,usedPower=10,input1Index=2,outputIndex=0,openEndsPermutation=new[]{1,0},ports=new[]{new Port{index=0,type="Data",role="Output1"},new Port{index=1,type="Power",role="PowerInput"},new Port{index=2,type="Data",role="Input1"}},controls=ctr};Verify(separate,face);var split=Planner.Build(separate,face);Check(split.terminals.Single(p=>p.originalIndex==0).edge=="bottom"&&split.terminals.Single(p=>p.originalIndex==2).edge=="top","reversed native index mapping ignored");Check(split.terminals.Count(p=>p.function=="PWR")==1,"separate power turned into data");
 separate.input1Index=0;Verify(separate,face);Check(Planner.Build(separate,face).terminals.Single(p=>p.originalIndex==0).function=="IN/OUT","shared IN/OUT connector duplicated");
 separate.input1Index=-1;Verify(separate,face);Check(!Planner.Build(separate,face).terminals.Any(p=>p.inputNetwork),"unused IN created extra input connector");
 separate.ports=new Port[0];bool failed=false;try{Planner.Build(separate,face);}catch(ArgumentException){failed=true;}Check(failed,"empty prefab accepted as complete wiring plan");
}

var wanted=new HashSet<string>(templates.modules.Select(m=>m.nativeType));var all=wanted.ToArray();
var complete=new KitOption{sourceIndex=4,prefab="KitLogicIO",memberTypes=all};
Check(KitSelection.Match(new[]{complete},wanted).Single()==complete,"complete original kit not found");
Check(KitSelection.Match(new[]{new KitOption{prefab="Incomplete",memberTypes=all.Take(8).Concat(new[]{all[0]}).ToArray()}},wanted).Length==0,"duplicate type hides missing ninth variant");
Check(KitSelection.Match(new[]{new KitOption{memberTypes=null}},wanted).Length==0,"null kit accepted");
var extra=new KitOption{sourceIndex=1,prefab="Extra",memberTypes=all.Concat(new[]{"UnknownExtraVariant"}).ToArray()};
Check(KitSelection.Match(new[]{extra,complete},wanted)[0]==complete,"unrelated larger constructor preferred over exact kit");
var chosen=KitSelection.Match(new[]{extra},wanted).Single();Check(chosen.memberTypes.Length==10&&chosen.memberTypes[9]=="UnknownExtraVariant"&&chosen.sourceIndex==1,"kit membership/extra appearance/source index lost");
var alpha=new KitOption{prefab="AA",memberTypes=all};Check(KitSelection.Match(new[]{complete,alpha},wanted)[0]==alpha,"equivalent candidates unstable");
Check(KitSelection.Match(new[]{new KitOption{memberTypes=all.Concat(new string[]{null}).ToArray()}},wanted).Length==1,"empty construction slot hides real variants");
Console.WriteLine($"{checks} top/bottom authoring planner checks passed across nine control templates and synthetic 2–12-port profiles. Actual prefab counts are not inferred by these checks.");
