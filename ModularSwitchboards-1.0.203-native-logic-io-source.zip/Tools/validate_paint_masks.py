"""Validate the exported geometry, normals/winding, material roles, and custom state icons."""
from pathlib import Path
import struct,math
base=Path(__file__).resolve().parent.parent
b=(base/'Assets/Cabinet.meshbin').read_bytes()
assert b[:4]==b'SBMS'
version,materials,groups=struct.unpack_from('<iii',b,4)
assert (version,materials,groups)==(1,5,4)
colors=[struct.unpack_from('<6f',b,16+i*24) for i in range(materials)]
assert all(.65<v<.8 for v in colors[1][:3])
assert colors[2][0]>.9 and colors[2][1]>.6 and colors[2][2]<.03
assert max(colors[3][:3])<.03
pos=16+24*materials;counts=[];total=0
for group in range(groups):
 n,=struct.unpack_from('<i',b,pos);pos+=4
 assert 3<=n<65536
 vertices=[];normals=[]
 for _ in range(n):
  values=struct.unpack_from('<6f',b,pos);pos+=24
  assert all(math.isfinite(v) for v in values)
  v=values[:3];assert abs(v[1])<=.251, 'Geometry outside cabinet height';normal=values[3:];vertices.append(v);normals.append(normal)
  assert .99<sum(x*x for x in normal)<1.01
 per_material=[]
 for m in range(materials):
  count,=struct.unpack_from('<i',b,pos);pos+=4
  assert count%3==0
  indices=struct.unpack_from('<%di'%count,b,pos) if count else []
  assert all(0<=i<n for i in indices)
  pos+=count*4;per_material.append(count//3);total+=count//3
  for j in range(0,count,3):
   a,c,d=indices[j:j+3]
   u=[vertices[c][k]-vertices[a][k] for k in range(3)]
   v=[vertices[d][k]-vertices[a][k] for k in range(3)]
   cross=(u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0])
   mean=[sum(normals[i][k] for i in (a,c,d)) for k in range(3)]
   assert sum(cross[k]*mean[k] for k in range(3))>0, f'Winding opposes normal in group {group}, material {m}'
 if group==2:
  assert abs(max(v[0] for v in vertices)-.192)<1e-6
  assert abs(max(v[1] for v in vertices)-.242)<1e-6
  assert abs(min(v[0] for v in vertices)+.192)<1e-6
  assert abs(min(v[1] for v in vertices)+.242)<1e-6
 if group in (1,3):
  corners=[(abs(v[0]-(.2 if group==3 else 0)),abs(v[1])) for v in vertices
           if abs(v[0]-(.2 if group==3 else 0))>.18 and abs(v[1])>.23]
  assert len(corners)>100, 'Rounded shell/door corner geometry missing'
  assert all((x-.18)**2+(y-.23)**2<=.0201**2 for x,y in corners), 'Cabinet silhouette has square corners'
 counts.append(per_material)
assert pos==len(b)
# Door extends toward +X from its outside-view right hinge. Negative Y rotation opens toward +Z.
assert (base/'Source/CabinetDoor.cs').read_text().find('? -110f : 0f')>=0
assert -.2*math.sin(math.radians(-110))>0
assert sum(counts[0])==counts[0][4] and counts[0][4]>0, 'Bare frame must contain only metal supports.'
assert [g for g in range(groups) if counts[g][0]>0]==[1,3]
assert counts[2][4]>0 and counts[2][1]>0 and counts[2][3]>0
assert counts[2][0]==0 and counts[2][2]==0, 'Backplate and four screws must be fixed metal, not paintable shell' 
assert counts[1][3]==0, "Side vent backing must paint with the shell"
assert counts[1][1]==0 and counts[3][1]==0, "Only the separate mounting plate may have fixed grey faces"
assert counts[3][2]==0 and counts[3][3]>0, "Native warning must replace the approximate exported symbol"
assert total==9428
icons=[(base/'Assets/Icons'/f'{n}.png').read_bytes() for n in ['Frame','Cabinet']]
assert len(set(icons))==2
for icon in icons:
 assert icon[:8]==b'\x89PNG\r\n\x1a\n' and struct.unpack_from('>II',icon,16)==(256,256)
print('9428 triangles: winding matches normals; bare frame and completed shell; shell and both door sides paintable; only mounting plate fixed; 2 custom construction icons; kit uses native icon.')
