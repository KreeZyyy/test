# Logic I/O: audit devíti variant a návrh DIN čel

Stav: ověřené funkce ovládacích prvků z aktuálního herního DLL, navržené DIN rozložení. Herní mod zůstává na 1.0.190; žádný Logic I/O modul zatím není implementován ani publikován. Rozložení není export původních fyzických souřadnic.

## Přehled

Čísla B1–B4 znamenají původní `InteractableType.Button1` až `Button4`, nikoli pořadí šroubků na novém čele. Jejich hodnoty jsou 31–34. Aktivace Writer Switche je samostatné `Activate` = 41. Počty šroubků v tabulce nezahrnují společné napájecí ON/OFF ovládání zařízení; to musí zůstat podle původního prefabu.

| Varianta | Ověřené nastavovací prvky | Návrh čela | DIN sloty – návrh |
|---|---|---|---:|
| Logic Reader | B1 `IN`: zařízení; B2 `VAR`: čtená vlastnost | IN a VAR vedle sebe | 2 |
| Logic Writer | B1 `OUT`: cílové zařízení; B2 `VAR`: zapisovaná vlastnost; B3 `IN`: zdroj hodnoty Setting | OUT nahoře; IN a VAR dole | 2 |
| Batch Writer | B1 `TYPE`: typ cílových zařízení; B2 `VAR`: zapisovaná vlastnost; B3 `IN`: zdroj Setting | TYPE nahoře; IN a VAR dole | 2 |
| Logic Mirror | B1 `IN`: zrcadlené zařízení | Jeden šroubek uprostřed | 1 |
| Slot Reader | B1 `IN`: zařízení; B2 `SLOT`: jeho slot; B3 `VAR`: vlastnost slotu | IN / SLOT / VAR v jedné řadě | 2 |
| Batch Reader | B1 `MODE`: agregace; B2 `VAR`: vlastnost; B3 `TYPE`: typ zařízení | MODE nahoře; TYPE a VAR dole | 2 |
| Reagent Reader | B1 `IN`: zařízení; B2 `MODE`: režim; B3 `REAG`: reagent | IN / MODE / REAG v jedné řadě | 2 |
| Batch Slot Reader | B1 `TYPE`: typ zařízení; B2 `SLOT`: slot; B3 `VAR`: vlastnost slotu; B4 `MODE`: agregace | TYPE a MODE nahoře; SLOT a VAR dole | 2 |
| Logic Writer Switch | B1 `OUT`: cílové zařízení; B2 `VAR`: zapisovaná vlastnost; `Activate`: vlastní 0/1 | OUT a VAR nahoře; samostatný přepínač dole | 2 |

Všechny uvedené nastavovací akce používají původní kontrolu šroubováku. Aktivace Writer Switche má vlastní větev pro ruční přepnutí; nesmí se nahradit dalším nastavovacím šroubkem.

## Společný vzhled a prostor

- Zachovat vzhled našich DIN modulů: světlé matné tělo, tmavé čelo, název a původní stavová signalizace nahoře. Nepřebarvovat indikaci podle logiky Smart Netu; ponechat stavy původního modulu.
- Každá varianta má vlastní mapu akcí a rozmístění. Nepředpokládat, že B1 znamená IN: u Writeru je OUT, u Batch Readeru MODE.
- Návrhová hlava šroubku 9 mm, zóna zásahu 12 mm, vzdálenost středů alespoň 16 mm. Přesné návrhové souřadnice jsou v `LogicIO-layouts.json`.
- Současný projekt má fyzickou rozteč DIN slotů 40,5 mm (`DinLayout.SlotPitch`). Základní tělo má 39,6 mm, dvouslotové 80,1 mm. Tohle nejsou běžné reálné DIN rozměry 18 mm.
- Mirror na jeden slot pojme jediný selektor. Dva sloty ostatním dovolí čitelné popisy i případné oddělené kabelové skupiny. Batch Slot Reader nepotřebuje automaticky třetí slot: čtyři selektory se vejdou do dvou řad. Rozměry potvrdit po exportu konektorů a skutečném náhledu ve hře.

## Kabely: co víme a co zatím ne

`IN`, `OUT`, `VAR` či `SLOT` na čele jsou **nastavovací selektory, nikoli kabelové zásuvky**. Počet šroubků neurčuje počet kabelů.

Z IL je ověřeno:

- Readery vybírají zdroj z `InputNetwork1`; výsledek ukládají jako nativní `Setting`.
- Writer a Batch Writer vybírají zdroj z `InputNetwork1` a cíle z `OutputNetwork1`.
- Writer Switch nemá externí výběr IN: `Input1` vrací samotný modul, zapisovaná hodnota je jeho `Activate` (0/1). Cíl vybírá na `OutputNetwork1`.
- Mirror vybírá zařízení z `InputNetwork1` a předává jeho podporované čtení **i zápis**. Neznamená to fyzické sloučení dvou sítí. Respektuje původní podmínky napájení.
- `LogicUnitBase.CheckConnections()` používá indexy `Input1Index` a `OutputIndex` do `OpenEnds`. Konstruktor základní třídy dává výchozí indexy 0 a 1; prefab je ale může přepsat.

DLL neobsahuje instanci původního seznamu `OpenEnds`. Z dostupných podkladů tedy nejsou potvrzeny **počty fyzických konektorů, jejich Power/Data/PowerAndData typ, role, souřadnice ani nastavená spotřeba**. Ve strojovém návrhu jsou tato pole úmyslně `null`. Fotografie prvních šesti čel pomáhá s rozmístěním původních selektorů, ale neukazuje všechny konektory devíti variant.

Kabelové konektory musí být **výhradně nahoře nebo dole**, nikoli na bočních stěnách. Kompletní pravidla pro každý původní port:

| Nativní funkce portu | Umístění na DIN těle | Co se zachová |
|---|---|---|
| Samostatný Power | Nahoře, PWR | Typ Power, původní role a odběr |
| Datový vstup podle skutečného Input1Index | Nahoře, IN | Původní výběr zdroje a vstupní síť |
| Kombinovaný vstup PowerAndData | Nahoře, IN + PWR | Jediný kombinovaný konektor, bez rozdělení na nové porty |
| Výstup podle skutečného OutputIndex | Dole, OUT | Původní cílová/výstupní síť; typ portu se nemění |
| Jeden fyzický port sdílený pro IN i OUT | Nahoře, IN/OUT | Stále jeden port a původní sdílená síť, bez duplikace |
| Další původní port | Výstupní role dole, ostatní nahoře | Původní index, typ a role beze změny |

Původní pořadí OpenEnds a OpenEndsPermutation se zachová, i když se port fyzicky přesune na jinou hranu. Kabely míří od horní hrany nahoru a od dolní dolů. Návrhová rozteč svorek je 16 mm; modul se případně rozšíří, aby se vešly všechny skutečné porty a původní fyzické ovládání.

| Modul | Funkce horní skupiny | Funkce spodní skupiny |
|---|---|---|
| Reader | Napájení a síť vybraného zdroje | Nativní výstup / Setting |
| Slot Reader | Napájení a síť vybraného zařízení/slotu | Nativní výstup / Setting |
| Reagent Reader | Napájení a síť vybraného zařízení s reagenty | Nativní výstup / Setting |
| Batch Reader | Napájení a síť čtených zařízení podle typu | Nativní výstup / agregované Setting |
| Batch Slot Reader | Napájení a síť čtených zařízení/slotů podle typu | Nativní výstup / agregované Setting |
| Writer | Napájení a síť vybraného zdroje Setting | Síť cílového zařízení a vybrané zapisované VAR |
| Batch Writer | Napájení a síť vybraného zdroje Setting | Síť cílových zařízení vybraného typu a VAR |
| Mirror | Napájení a síť zrcadleného zařízení | Nativní zpřístupnění proxy; čtení i zápis |
| Writer Switch | Napájení; zdroj hodnoty je vlastní Activate, nikoli dodatečná IN zásuvka | Síť vybraného zařízení, zápis 0/1 do VAR |

Tabulka popisuje funkce skupin, nikoli odhad počtu zásuvek. Pokud má originál společný port nebo některou skupinu nemá, kopíruje se skutečný seznam místo vytváření chybějící zásuvky.

Hotový plánovač v `Tools/LogicIOAudit/ExportMod` zpracuje načtený původní prefab a vygeneruje konkrétní počet, popisy a 3D pozice všech svorek, jejich směry, indexy, typy, role, nativní odběr a všechny původní ovládací prvky. Připojení má jedině na horní/spodní hraně. Návrhový pás v prvním obrázku tedy už není jediné řešení: skutečný úplný kabelový plán vygeneruje přiložený spustitelný autorovací mod z reálných dat hry. V tomto workspace chybí serializovaná prefabová data, proto zatím nelze poctivě napsat konkrétní počty portů pro každou variantu.

## Rozdíly, které se nesmějí ztratit

- Mirror není pouze další Reader: přeposílá také `CanLogicWrite` a `SetLogicValue`.
- Writer Switch není náš Door Round Switch: zapisuje 0/1 do vybrané logické vlastnosti zařízení, zatímco dveřní switch spíná kabelovou větev.
- Reagent Reader používá `LogicReagentMode`: Contents, Required, Recipe, TotalContents. Dostupnost výběru REAG závisí na režimu a musí zůstat nativní.
- Batch varianty používají původní `LogicBatchMethod`, který v tomto DLL obsahuje Average, Sum, Minimum, Maximum a Count.
- Slot Reader a Batch Slot Reader používají `LogicSlotType`, ne obyčejný `LogicType`.
- Nesjednocovat datové formáty: Mirror má `LogicMirrorSaveData : StructureSaveData`; ostatní zde auditované varianty mají vlastní save typy odvozené od `LogicBaseSaveData`.

## Zachování současného systému

Nové moduly budou samostatné DIN prvky; tento návrh z nich nedělá rozšíření Smart Core busu. Stávající adresy d0–d5 a zapojení Smart modulů se nemění. Smart Door Display zůstává pouze přes vyhrazený Bridge na Smart Outputu. Pro případné přímé zapojení Door Dialu do budoucího DIN Readeru bude třeba doplnit jeho datovou cestu; nynější 1.0.190 podporuje Net nebo vnější datovou síť.

## Podklady a ověření

Auditovaná assembly SHA-256: `6caeb8414a83cf47bdc86e0978b0b011ee3ced898a2d7940a9dc66003acf0850`.

- `Tools/LogicIOAudit/Program.cs`: reprodukovatelný metadata/IL audit bez spouštění Unity.
- `Tools/LogicIOAudit/PrefabSnapshot.cs.example`: čtecí helper pro načtené původní prefaby. Exportuje přesné OpenEnds, typy/role, indexy sítí, lokální souřadnice a ovládací prvky. Není připojen ani automaticky spuštěn v modu.
- `Tools/LogicIOAudit/README.md`: použití obou částí a jejich omezení.
- `Design/LogicIO-layouts.json`: devět návrhů včetně původních action ID a návrhových souřadnic.
- `Design/LogicIO-layouts.svg`: přehled čel; přerušovaný pás dole znamená rezervovaný prostor, ne potvrzené konektory.

Auditovací nástroj i prefab helper se sestavily bez varování proti dostupným API. Kontrola devíti map ověřila akce v původním GetContextualName, přítomnost kontroly šroubováku a návrhové rozestupy. Běh exportu ve skutečné hře a finální fyzické porty zatím ověřeny nejsou. DS pro tento export není potřeba; stačí načtené originální prefaby v lokální hře.
