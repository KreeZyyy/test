## 1.0.167 — Filled grey display back and fuller label

Fills the complete rear display silhouette with the same grey material as its perimeter. The black button-style housing, single DATA IN screw and cable endpoint remain in front of the grey panel.

Widens the display label rim to a 5 mm outward offset and reduces the clearance around the native bezel to 0.25 mm. The original upper nameplate and native screen opening remain clear. Display logic, power, placement, wiring and save/network formats are unchanged.

Native compilation and production geometry checks verify face orientation, clear bezel opening and full rear-face area without holes or overlapping fill. In-game appearance still needs confirmation.

