## 1.0.170 — Display label sits flat on the cabinet door

Corrects the display label mounting plane: like the existing button label, its ring lies from -0.8 to +1.2 mm relative to the door board. It no longer follows the raised LED bezel height or covers the screen. Its opening fits around the native display bezel, leaving that bezel and the complete LED face exposed.

Retains the slightly wider white nameplate and larger text from 169, its compact row height, placement clearance checks, grey rear panel and upper screw/top cable entry. Display logic, energy and save/network formats remain unchanged. Existing labels adopt the corrected geometry without moving their board anchors.

Native compilation and geometry tests verify that every label mesh vertex stays within the original thin door-label depth and the opening clears the entire native bezel. Appearance still needs an in-game check.

