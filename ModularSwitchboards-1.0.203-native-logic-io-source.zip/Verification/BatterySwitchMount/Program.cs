using System;using ModularSwitchboards;
class Program {static int n;static void Check(bool b,string m){n++;if(!b)throw new Exception(m);}static void Main(){
 foreach(float sign in new[]{-1f,1f}){Check(BatterySwitchMount.Axis(sign*.8f,.2f)==0,"side switch presented edge-on");Check(BatterySwitchMount.Sign(sign*.8f,.2f)==sign,"side mount faces inward");Check(BatterySwitchMount.Axis(.2f,sign*.8f)==2,"front switch wrong mount axis");Check(BatterySwitchMount.Sign(.2f,sign*.8f)==sign,"front mount faces inward");}
 foreach(float scale in new[]{.01f,.5f,2f,10f})foreach(float back in new[]{-.3f,0f,.6f}){
 float surface=.074f,offset=BatterySwitchMount.Seat(surface,back,scale);Check(Math.Abs(offset+back*scale-surface)<.000001f,"bezel back does not touch DIN face");Check(offset+(back+.01f)*scale>surface,"rocker buried inside DIN body");}
 Console.WriteLine(n+" production switch mount checks passed: side direction and bezel-back seating across scales.");}}
