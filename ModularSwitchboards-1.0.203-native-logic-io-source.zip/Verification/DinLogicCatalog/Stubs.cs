using System;using System.Linq;using System.Collections.Generic;
namespace UnityEngine {
 public class Transform{}
 public class Sprite{}
 public class GameObject {public bool Destroyed;}
 public static class Debug {public static List<string> Errors=new();public static void Log(string s){}public static void LogError(string s)=>Errors.Add(s);}
 public class Object {
  public static List<GameObject> Created=new();
  public static T Instantiate<T>(T original,Transform parent) where T:Assets.Scripts.Objects.Thing {
   var t=(T)original.Clone();t.gameObject=new GameObject();Created.Add(t.gameObject);return t;
  }
  public static void DestroyImmediate(GameObject g){g.Destroyed=true;}
 }
}
namespace Assets.Scripts {public enum MachineTier {TierOne}}
namespace Assets.Scripts.Objects {
 public class Thing {public string PrefabName,DisplayName;public UnityEngine.GameObject gameObject=new();public object PaintableMaterial;public UnityEngine.Sprite Thumbnail;public UnityEngine.Sprite[] Thumbnails;public bool HideInStationpedia;public object Clone()=>MemberwiseClone();}
 public class Item:Thing {public Assets.Scripts.MachineTier RecipeTier;public int Quantity;public void SetQuantity(int q)=>Quantity=q;}
 public class MultiConstructor:Item {public List<Structure> Constructables=new();public int LastSelectedIndex;}
 public class Structure:Thing {public List<BuildState> BuildStates=new(){new()};public UnityEngine.GameObject Blueprint;}
 public class BuildState {public UnityEngine.Sprite Thumbnail;}
}
namespace Assets.Scripts.Objects.Electrical {public class LogicUnitBase:Assets.Scripts.Objects.Structure{}}
namespace ModularSwitchboards {
 public class DinLogicReader:Assets.Scripts.Objects.Electrical.LogicUnitBase{}public class DinLogicWriter:Assets.Scripts.Objects.Electrical.LogicUnitBase{}
 public class DinLogicBatchReader:Assets.Scripts.Objects.Electrical.LogicUnitBase{}public class DinLogicBatchWriter:Assets.Scripts.Objects.Electrical.LogicUnitBase{}
 public class DinLogicSlotReader:Assets.Scripts.Objects.Electrical.LogicUnitBase{}public class DinLogicBatchSlotReader:Assets.Scripts.Objects.Electrical.LogicUnitBase{}
 public class DinLogicReagentReader:Assets.Scripts.Objects.Electrical.LogicUnitBase{}public class DinLogicMirror:Assets.Scripts.Objects.Electrical.LogicUnitBase{}
 public class DinLogicReaderSaveData{}public class DinLogicWriterSaveData{}public class DinLogicBatchReaderSaveData{}public class DinLogicBatchWriterSaveData{}public class DinLogicSlotReaderSaveData{}public class DinLogicBatchSlotReaderSaveData{}public class DinLogicReagentReaderSaveData{}public class DinLogicMirrorSaveData{}
 public class FakeMod {public void AddSaveDataType<T>(){}}
 static class SwitchboardsMod {
  internal static readonly FakeMod Mod=new();
  internal static void Identify(Assets.Scripts.Objects.Thing t,string n,string label){t.PrefabName=n;t.DisplayName=label;}
  internal static Assets.Scripts.Objects.BuildState MakeState(Assets.Scripts.Objects.BuildState v,Assets.Scripts.Objects.Item kit,int q,Assets.Scripts.Objects.Item second,int n,Assets.Scripts.Objects.Item drill)=>new();
 }
 static class SwitchboardPrefabs {
  internal static int FailAt=-1,Calls;
  internal static T ReplaceComponent<T>(Assets.Scripts.Objects.Structure s,bool preserveNativeScripts=false) where T:Assets.Scripts.Objects.Structure,new(){if(Calls++==FailAt)throw new InvalidOperationException("injected component failure");return new T{PrefabName=s.PrefabName,DisplayName=s.DisplayName,gameObject=s.gameObject,BuildStates=s.BuildStates,Blueprint=s.Blueprint};}
 }
 static class DinLogicRuntime {internal const string Kit="ItemKitDinLogicIO";}
 static class CabinetIcons {internal static UnityEngine.Sprite Get(string n)=>new();}
 static class DinLogicModel {
  internal static int FailAt=-1;internal static List<string> Installed=new();internal static List<UnityEngine.GameObject> Blueprints=new();
  internal static void Install(Assets.Scripts.Objects.Electrical.LogicUnitBase m,string native,UnityEngine.Transform storage){if(m.GetType().Name!="DinLogic"+native.Substring("StructureLogic".Length))throw new InvalidOperationException("wrong native adapter type");if(Installed.Count==FailAt)throw new InvalidOperationException("injected model failure");Installed.Add(native);m.Blueprint=new UnityEngine.GameObject();Blueprints.Add(m.Blueprint);}
 }
}
