using Assets.Scripts.Objects;using ModularSwitchboards;using UnityEngine;
int checks=0;void Check(bool c,string m){checks++;if(!c)throw new Exception(m);}
List<Thing> World(int nullIndex){var entries=new[]{0,1,3,7,4,2,6,5}.Select(i=>DinLogicCatalog.Native[i]).Select(n=>new Structure{PrefabName=n,DisplayName=n,Blueprint=new GameObject()}).Append(new Structure{PrefabName="StructureLogicWriterSwitch",DisplayName="Writer Switch"}).ToList();entries.Insert(nullIndex,null);return new(){new Structure{PrefabName="ExistingCabinet"},new MultiConstructor{PrefabName="ItemKitLogicInputOutput",Constructables=entries}};}
void Reset(){UnityEngine.Object.Created.Clear();Debug.Errors.Clear();DinLogicModel.Installed.Clear();DinLogicModel.Blueprints.Clear();DinLogicModel.FailAt=-1;SwitchboardPrefabs.FailAt=-1;SwitchboardPrefabs.Calls=0;}
foreach(int nullIndex in Enumerable.Range(0,10)){
 Reset();var world=World(nullIndex);var original=(MultiConstructor)world[1];var sourceOptions=original.Constructables.ToArray();var core=world[0];
 Check(DinLogicCatalog.TryInstall(world,new(),new()),"empty slot "+nullIndex+" breaks actual catalog install");
 var kit=world.OfType<MultiConstructor>().Single(k=>k.PrefabName==DinLogicRuntime.Kit);
 Check(kit.Constructables.Count==8,"wrong DIN variant count");Check(DinLogicModel.Installed.SequenceEqual(DinLogicCatalog.Native),"source order/type mismatch");
 Check(original.Constructables.SequenceEqual(sourceOptions)&&original.Constructables.Count==10,"vanilla kit options changed");Check(!kit.Constructables.Any(s=>s.PrefabName.Contains("WriterSwitch")),"excluded Writer Switch added");Check(ReferenceEquals(world[0],core)&&!core.gameObject.Destroyed,"base cabinet removed");Check(DinLogicCatalog.SetupFailure==null&&Debug.Errors.Count==0,"success marked failed");
}
foreach(bool failComponent in new[]{false,true}){
 Reset();var world=World(9);var prior=world.ToArray();if(failComponent)SwitchboardPrefabs.FailAt=3;else DinLogicModel.FailAt=3;
 Check(!DinLogicCatalog.TryInstall(world,new(),new()),"injected failure ignored");Check(world.SequenceEqual(prior)&&!prior[0].gameObject.Destroyed,"failed kit touched core source prefabs");Check(UnityEngine.Object.Created.All(g=>g.Destroyed),"partial cloned kit/module leaked");Check(DinLogicModel.Blueprints.All(g=>g.Destroyed),"prepared blueprint leaked");Check(DinLogicCatalog.SetupFailure!=null&&Debug.Errors.Count==1,"missing isolated failure diagnostic");
}
Reset();{var world=World(9);((MultiConstructor)world[1]).Constructables.RemoveAt(0);var prior=world.ToArray();Check(!DinLogicCatalog.TryInstall(world,new(),new()),"missing native variant accepted");Check(world.SequenceEqual(prior)&&UnityEngine.Object.Created.Count==0,"missing source cloned/published partial kit");}
Reset();Check(DinLogicCatalog.TryInstall(World(9),new(),new())&&DinLogicCatalog.SetupFailure==null,"stale failure retained after recovery");
Console.WriteLine(checks+" actual DIN catalog startup/rollback checks passed, including the captured ten-slot kit with trailing null.");
