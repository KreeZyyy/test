using System;using System.IO;using UnityEngine;namespace ModularSwitchboards{internal static class NativeBatteryReference{        internal static void WriteObj(string path,Vector3[] vertices,Vector2[] uv,int[][] groups)
        {
            using(var output=new StreamWriter(path))
            {
                output.WriteLine("# Native prefab-local metres; material groups match Batteries-reference.json");
                foreach(var p in vertices)output.WriteLine(FormattableString.Invariant($"v {p.x:R} {p.y:R} {p.z:R}"));
                foreach(var p in uv)output.WriteLine(FormattableString.Invariant($"vt {p.x:R} {p.y:R}"));
                for(int g=0;g<groups.Length;g++){output.WriteLine("g submesh_"+g);var ids=groups[g];for(int i=0;i<ids.Length;i+=3)
                {int a=ids[i]+1,b=ids[i+1]+1,c=ids[i+2]+1;output.WriteLine(uv.Length==vertices.Length?$"f {a}/{a} {b}/{b} {c}/{c}":$"f {a} {b} {c}");}}
            }
        }
}}