from pathlib import Path
r=Path(__file__).resolve().parents[2]
s=(r/'Source/CabinetWiringInput.cs').read_text()
def method(start):
 i=s.index(start);b=s.index('{',i);d=1;j=b+1
 while d:
  if s[j]=='{':d+=1
  elif s[j]=='}':d-=1
  j+=1
 return s[i:j]
imports=s[:s.index('namespace ModularSwitchboards')].replace('using HarmonyLib;','')
text=imports+'namespace ModularSwitchboards{internal static class CabinetWiringInput{private static Structure hiddenCursor;private static DynamicThing editingItem;private static bool cursorWasVisible,panelWasVisible;'+method('internal static bool ModePrefix(')+method('private static void Restore(')+'private static bool PaintMode(InventoryManager inventory,SwitchboardCabinet cabinet,DynamicThing active)=>true;}}'
p=r/'Verification/BatteryInput/Harness.cs'
q=p.with_name(p.name+'.new');q.write_text(text);q.replace(p)
