# Audit 1.0.140 proti 1.0.143 a opravy 1.0.144

Srovnány neměnné snapshoty release1140 a release1143, včetně všech změněných zdrojových souborů; opravy jsou v headless-fix-draft/release1144. Toto je audit kódu a offline testů, nikoli potvrzení celé hry nebo multiplayeru.

## Výsledky

1. **143 již opravuje doložený pád náhledu.** Neaktivní sklad prefabů způsoboval, že GetComponentInParent bez includeInactive nevrátil vlastníka a filtr vyřadil všechny meshe. Starý produkční filtr vyvolal ve scénářovém fixture přesnou výjimku z logu; opravený prošel.
2. **Kontrola registrace baterií zaměňovala runtime cache za uložená data.** InteractOnOff vrací privátní _interactableOnOff; není Unity-serialized a OnPrefabLoad jej neobnovuje. Cache nastavená na autorovacím vzoru se nezaručuje na neaktivním registrovaném klonu. Obě poslední hlášky jsou s tím konzistentní; starý souhrnný log ale nerozlišoval pět podmínek. 144 ověřuje skutečné serializované ovladače, kapacitu, šířku a kit. Skutečné chybějící či poškozené položky stále hlásí, nyní se jménem prefabu a konkrétním důvodem. Testy simulují klon s vynechanou privátní cache, nikoli skutečný Unity Instantiate.
3. **Nedokončená baterie mohla být zachycena režimem kabeláže.** Původní materiál nebo kabel v ruce se neměl měnit na pokus o vodič. Oprava nechává celou nedokončenou baterii nativní konstrukci; dokončené baterie zůstávají zapojitelné. Stejný test skutečného ModePrefix selže na143 a projde na144.
4. Headless cesta navíc čistí seznam animátorových pomocníků po odstranění nativních skriptů, stejně jako původní Transformer. Nejde o potvrzenou příčinu uživatelova klientského logu.

## Celý rozdíl zdrojů

140 má277 souborů Source,143 má282:5nových,21změněných,0odstraněných. Všechny zbývající zdroje jsou totožné po bajtech. 87souborů runtime Assets a kompletní GameData/electronics.xml zůstávají beze změny. Reference na assemblies i NuGet balíčky jsou stejné. Totéž platí pro původní DinBreaker/Holder a SmartModule, používané kontakty a receptové XML.

| Soubor | Závěr přezkumu |
|---|---|
| Source/BatteryEnergyStore.cs | Živý adaptér energie; identita držáku/článku a limit 1000 zachované. |
| Source/CabinetCombinerPower.cs | Pouze čtení/zápis přes adaptér; rezervace a účtování přezkoumány, společné testy140/144 prošly. |
| Source/CabinetCoverWindows.cs | Přidány otvory pro4/6pozic. Skutečné zakrytí nativního čela vyžaduje kontrolu ve hře. |
| Source/CabinetPowerNode.cs | Volitelné nativní úložiště, původní BatteryCell cesta zůstává. |
| Source/CabinetWiring.cs | Kontakty, kapacity, živé zdroje, obnovování a ochrana před osiřelými vodiči zahrnují baterie. |
| Source/CabinetWiringDamage.cs | Nové uzly vstupují do stejné fyzické sítě a ochrany; DATA výjimka140 zachována. |
| Source/CabinetWiringInput.cs | Nalezena kolize nedokončené baterie s režimem vodičů. Opraveno144 a reprodukováno starým143hookem. |
| Source/DinModuleBoard.cs | Obsazení DIN pozic rozšířeno o nový typ; původní pravidla prostoru se nemění. |
| Source/DinModuleCatalog.cs | Dva nové stabilní názvy, šířky4/6, stejný kit; původní varianty ponechány. |
| Source/DinParts.cs | Nový typ zahrnut do šířek a seznamu dílů, blokuje místo i průchod Smart sběrnice. |
| Source/DinStationBattery.cs | Nativní kapacita/náboj/save/join, board hooks, vypínač a stavové indikátory. Externí nativní účtování vypnuté, aby nevznikl druhý zdroj. |
| Source/DinStationBatteryModel.cs | Původní komponenty v jednotně škálovaném podstromu, velká90°; přemapování odkazů, vlastní ghost a headless větev. Reálné animace/hitboxy stále neověřené ve hře. |
| Source/DinStationBatteryNetwork.cs | Stejný vzor datové registrace jako Transformer140; žádný další nativní power provider. |
| Source/ModelBlueprint.cs | Potvrzená chyba neaktivního vlastníka opravená143. Oprava zachovává oddělení cizích Thing; starý kód reprodukoval přesnou výjimku. |
| Source/ModuleDismantle.cs | Nový typ používá původní potvrzený refund/odpojení vodičů, nikoli hover/preview. |
| Source/MountBoardResolver.cs | Nový typ řeší hostitele a existující desku stejným postupem jako Transformer. |
| Source/MountPlacementTool.cs | Nové baterie patří do původního modulu kitu, ostatní nástroje beze změny. |
| Source/NativeBatterySetup.cs | Sjednocení stage-only ovladačů, nulových seznamů a vlastníků před registrací. Soukromá cache se může ztratit při pozdějším klonování. |
| Source/OwnPreviewPolicy.cs | Nový typ má vlastní náhled, nepřepisuje se jeho původní ovládací kolizní geometrie obecným fitted tělem. |
| Source/PrefabAudioOwner.cs | Rozšířeno pouze o null-safe seznamy; aliasy, vlastníci a kopie událostí ověřeny26kontrolami. |
| Source/StationpediaCatalog.cs | Nový typ zařazen do baterií; původní kategorie zachované. |
| Source/SwitchboardCursorTarget.cs | Cíl může být nový modul; pravidla původních dílů neměněna. |
| Source/SwitchboardDescriptions.cs | Přidáno F1 pro nové baterie a oddělené IN/OUT. |
| Source/SwitchboardNames.cs | Přidány pouze dvě jména; původní identity a migrace beze změny. |
| Source/SwitchboardPrefabs.cs | Defaultní cesta pro staré komponenty zachována; pouze baterie mají normalizaci a volitelné zachování skriptů. |
| Source/SwitchboardsMod.cs | Dvě nové varianty, save typ a validace montáže; atomická příprava zůstává. Nalezena chybná kontrola privátní cache vypínače, opraveno144. |

144 navíc přidává Source/NativeBatteryRegistration.cs pro validaci serializovaných dat a konkrétní diagnostiku.

## Ověření obou verzí

Obě skutečné verze zdrojů sestaveny proti stejným nativním DLL:140 i144 mají0warningů a0chyb. Pro140 se použily současné testové fixtures s původními produkčními soubory;28nových testů stacionárního úložiště bylo v baseline vynecháno, protože tato funkce v140 neexistuje. Pomocný nový adaptér je v baseline přiložen pouze kvůli sdíleným stubům, starý produkční solver jej nepoužívá.

| Kontrola | 140 | 144 |
|---|---:|---:|
| Produkční společný energetický solver |4791|4791+28nových bateriových=4819|
| Obvody, rozpočty, persistence a routing |12464|12464|
| Validace baterií včetně prázdné privátní cache |neexistovala|25|
| Vstupní hook včetně nedokončené baterie |původní funkce|21|
| Inicializace nativních baterií |neexistovala|12|
| Zvukové události |netestováno v tomto běhu|26|
| Náhledy / rodiny / výběry / hitboxy |netestováno v tomto běhu|35+154|
| Vazby služeb |netestováno v tomto běhu|33|
| F1 / katalog a hledání / migrace jmen |netestováno v tomto běhu|15/104/23|

Varování nevyužitých polí v testových stubech nejsou varování nativního buildu. Samostatné logy obsahují celý výstup.

## Co nelze offline potvrdit

Původní vzhled/rotace/switch animace, viditelnost všech segmentů v krytu, reálná stavba s původním kitem, nové BatterySaveData při skutečném save/load/late join a Linux/Windows headless provoz potřebují běh Unity. Starší multiplayerový problém tisku zůstává samostatný. TypeLoadException zmiňující StationeersMods.AssemblyMod nelze z posledního snímku přiřadit této změně; v porovnaných referencích se loader ani knihovny nemění a tato výjimka nebyla reprodukována. Nepřepisujeme kvůli ní energetiku ani recepty.
