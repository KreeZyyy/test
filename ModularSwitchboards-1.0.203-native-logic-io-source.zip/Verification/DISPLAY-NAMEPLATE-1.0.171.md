## 1.0.171 — Filled door-label shoulders and wider white caption

The caption grows upward and sideways while its lower edge stays fixed. The white field is 179 x 15 mm inside a 184 x 21 mm plate, using the same 2.5 mm side borders as the door LED labels. The dark grey upper shoulders now fill to the full caption width, removing the cut-out corners. The display bezel remains free and the label stays flat on the cabinet door. Placement checks reserve the enlarged outline and retain clearance from the standard upper control row.

Rear connections, display logic, power and save/network formats are unchanged. Native compilation and geometry/clearance checks run offline; final appearance requires an in-game check.

