# First DIN-front battery test (145)

- Build Small4slots and Large6slots. Both must use the same DIN case and top/bottom terminals as transformers. No complete stock battery cabinet, side, rear, feet, base or ventilation grille should remain.
- Inspect the front:5native segment sockets on the left, original rocker on the right, capacity below. Check both normal and reverse cabinets; native front parts face the player, not the wall or side.
- Verify all original build materials/tools, incomplete-case visibility, then the completed front and switch target. Check the inner-cover opening and independent case paint; charged segments/switch colors must not be recolored with the body.
- Toggle OFF/ON, charge, drain and check segment thresholds/critical blink and native switch position/color/audio. Native SwitchOnOff is preferred; a legacy-source fallback is explicitly logged.
- Load a144test save with wired battery modules:slot position, width, charge and ON/OFF should persist. Wire endpoint geometry has changed to DIN terminal coordinates; old wires should reroute via the existing migration logic. Use a test-save copy for the first check.
- Try matching client/server late join. Headless rendering assets are omitted while native storage/controls/contact identities stay the same. Actual Unity and dedicated runs were not available during development.
