## 1.0.169 — Thin display label and larger caption

Removes the deep label walls that made the LED surround look like a black enclosure. The surround is now a 1.2 mm skin seated above the native bezel, with only a 1.5 mm outward extension. The LED opening and native visible characters remain clear.

Widens the white caption face from 150 to 160 mm (outer frame 170 mm) and slightly enlarges its text. Nameplate height and vertical position stay unchanged, preserving clearance to the controls above. The grey rear, upper screw, top cable entry, logic, power and save/network formats stay unchanged.

Native compilation and geometry tests verify thin surround walls, clear LED opening and placement clearance. Final appearance still needs an in-game check.

