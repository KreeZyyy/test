## 1.0.168 — Compact display nameplate, LED surround and top cable entry

The optional display label now fills inward to the actual visible LED opening, above the original raised bezel. Its opening is the intersection of the native LED mesh and the native bezel's inner front boundary: letters remain in the same visible area and white bezel corners are covered. The upper white nameplate is narrower (150 mm face) and lower (12 mm face), positioned immediately above the display instead of protruding into the control row above.

Placement checks reserve room for the display and its nameplate on the correct door leaf. New displays/labels cannot overlap existing control or label bounds; controls and labels cannot be placed into an existing display's reserved footprint by reversing build order. Ordinary neighboring stop/main-switch controls fit above the new compact nameplate. Existing objects are not deleted or moved; their nameplate adopts the revised geometry.

The single rear screw moves to the upper position used by buttons. Cable entry now matches their top entry (Y 23 mm, Z -30 mm); the screw is at Y 16 mm, Z -38.5 mm. Existing endpoint-drift checks reroute saved display leads using the established atomic migration. The filled grey rear panel, two-position door mounting, Output addresses, display logic, energy accounting and save/network format stay unchanged.

Offline validation covers native compilation, native captured bezel opening extraction, visible LED clipping, exact-corner polygon cleanup, front/rear normals, compact-header screenshot reproduction, both construction orders, overlapping labels, rotated door frames and separate leaves, plus existing display/preview/mount/wiring tests. In-game appearance and multiplayer still require a live check.

