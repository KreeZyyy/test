using System;
namespace ModularSwitchboards
{
    // Same DIN case/face proportions as the transformer, in owner-local metres.
    internal static class StationBatteryPanelLayout
    {
        internal const float FaceZ=.074f,GaugeY=.006f,GaugeHeight=.020f,SwitchWidth=.022f,SwitchHeight=.027f;
        internal static float Center(int slots)=>(slots-1)*DinLayout.SlotPitch*.5f;
        internal static float Width(int slots)=>.0176f*2.25f+(slots-1)*DinLayout.SlotPitch;
        internal static float GaugeWidth(int slots)=>Width(slots)-.055f;
        internal static float GaugeX(int slots)=>Center(slots)-.019f;
        internal static float SwitchX(int slots)=>Center(slots)+Width(slots)*.5f-.018f;
        internal static float Fit(float width,float height,float depth,float targetWidth,float targetHeight,float targetDepth)
        {
            if(width<=0||height<=0||depth<0||float.IsNaN(width+height+depth)||float.IsInfinity(width+height+depth)||targetWidth<=0||targetHeight<=0||targetDepth<=0)throw new ArgumentException("Native battery face geometry has invalid bounds.");
            return Math.Min(targetWidth/width,Math.Min(targetHeight/height,targetDepth/Math.Max(.0001f,depth)));
        }
    }
}
