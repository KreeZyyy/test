using System.Collections.Generic;
using System.Linq;
namespace ModularSwitchboards
{
    internal static class SmartCircuit
    {
        // A single-input consumer shares its feeder's data network. It never
        // inserts an IN -> OUT edge into the protective power circuit.
        internal static int Selection(long id,IEnumerable<CabinetWireSaveData> wires,IEnumerable<long> conducting,IEnumerable<long> protective,int tapContact=0,IEnumerable<CabinetWireEnd> inputs=null)
        {
            var graph=wires.Where(w=>!w.Burnt).ToArray();var closed=conducting.ToArray();var protection=protective.ToArray();
            // An explicit Output tap observes that physical external cable network,
            // even when the output is unpowered or also reachable from Input.
            int direct=0;
            foreach(var wire in graph.Where(w=>!w.Burnt&&w.To.Equals(new CabinetWireEnd(id,tapContact))&&WireDataTap.Stored(w)))
                direct|=wire.From.Contact==3?8:1<<(wire.From.Contact-1);
            if(direct!=0)return direct;
            var input=new CabinetWireEnd(0,0);var tap=new CabinetWireEnd(id,tapContact);
            var topology=closed.Concat(protection).Distinct().ToArray();
            var sources=(inputs??new[]{input}).ToArray();
            bool supplied=sources.Any(feed=>WireCircuit.Reachable(feed,tap,graph,topology));
            bool behind=protection.Any(p=>sources.Any(feed=>WireCircuit.Reachable(feed,new CabinetWireEnd(p,0),graph,topology))&&
                WireCircuit.Reachable(new CabinetWireEnd(p,1),tap,graph,topology));
            if(supplied&&!behind)return AnalyserCircuit.Input;
            // Follow the feeder shared by IN and an external output, including
            // neutral door bridges. An open upstream protector must not migrate
            // a downstream consumer into the cabinet's Input network.
            var feeds=graph.Where(w=>w.To.Equals(tap)).Select(w=>w.From).ToArray();
            int outputs=0;
            foreach(int i in new[]{1,2,3})if(feeds.Any(f=>WireCircuit.Reachable(f,new CabinetWireEnd(0,i),graph,closed)))outputs|=i==3?8:1<<(i-1);
            return outputs;
        }
    }
}
