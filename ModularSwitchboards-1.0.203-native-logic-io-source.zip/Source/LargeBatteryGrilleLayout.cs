using UnityEngine;
namespace ModularSwitchboards
{
    internal static class LargeBatteryGrilleLayout
    {
        // Original Large153capture:102triangles of front louvres+surround,
        // excluding the mirrored rear vent and the lower cabinet pedestal.
        internal static readonly Bounds NativeRegion=new Bounds(new Vector3(.25f,.405f,-.175f),new Vector3(.70f,.25f,.09f));
        internal static float VerticalScale(float scale,float nativeHeight,float availableHeight)=>System.Math.Min(scale*2f,availableHeight/nativeHeight);
        internal static readonly Bounds Target=new Bounds(new Vector3(DinLayout.SlotPitch*.5f,0,StationBatteryPanelLayout.FaceZ),new Vector3(.068f,.040f,.014f));
    }
}
