using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Electrical;
using HarmonyLib;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class NativeStationBatteryFace
    {
        private static readonly FieldInfo Indicators=AccessTools.Field(typeof(Battery),"displayRenderers");
        internal static void Install(DinStationBattery owner,Battery source,Transform front,BoxCollider switchHit)
        {
            SmallNativeBatteryFace.Install(owner,source,front,switchHit);
        }
        private static Vector3 BodyCenter(Battery source)
        {
            var bounds=new Bounds();bool first=true;
            foreach(var filter in source.GetComponentsInChildren<MeshFilter>(true))if(filter.sharedMesh!=null)
            {var b=CabinetWallMount.TransformedBounds(filter.sharedMesh.bounds,source.transform.worldToLocalMatrix*filter.transform.localToWorldMatrix);if(first){bounds=b;first=false;}else bounds.Encapsulate(b);}
            return bounds.center;
        }
        private static Vector3 OutwardNormal(MeshRenderer renderer,Transform space,Vector3 bodyCenter)
        {
            var mesh=renderer.GetComponent<MeshFilter>().sharedMesh;var size=mesh.bounds.size;
            var axis=size.x<=size.y&&size.x<=size.z?Vector3.right:size.y<=size.z?Vector3.up:Vector3.forward;
            var matrix=space.worldToLocalMatrix*renderer.transform.localToWorldMatrix;var normal=matrix.inverse.transpose.MultiplyVector(axis).normalized;
            var center=matrix.MultiplyPoint3x4(mesh.bounds.center);if(Vector3.Dot(normal,center-bodyCenter)<0)normal=-normal;return normal;
        }
        private static Vector3 PerpendicularUp(Vector3 normal,Vector3 preferred)
        {
            var up=preferred-normal*Vector3.Dot(preferred,normal);
            if(up.sqrMagnitude<.0001f){preferred=Mathf.Abs(Vector3.Dot(normal,Vector3.up))<.9f?Vector3.up:Vector3.forward;up=preferred-normal*Vector3.Dot(preferred,normal);}
            return up.normalized;
        }
        private static void Fit(Transform frame,Bounds bounds,Quaternion rotation,float width,float height,float depth,Vector3 targetFront)
        {
            var b=CabinetWallMount.TransformedBounds(bounds,Matrix4x4.Rotate(rotation));
            float scale=StationBatteryPanelLayout.Fit(b.size.x,b.size.y,b.size.z,width,height,depth);
            frame.localRotation=rotation;frame.localScale=Vector3.one*scale;frame.localPosition=targetFront-new Vector3(b.center.x,b.center.y,b.max.z)*scale;
        }
        private static MeshRenderer CopyBaked(MeshRenderer original,Transform space,Transform parent,string name)
        {
            var old=original.GetComponent<MeshFilter>().sharedMesh;CabinetGeometry.ReadNativeMesh(old,out var points,out var uv,out var groups);
            var matrix=space.worldToLocalMatrix*original.transform.localToWorldMatrix;var mesh=new Mesh{name=name,indexFormat=old.indexFormat};mesh.vertices=points.Select(matrix.MultiplyPoint3x4).ToArray();if(uv.Length==points.Length)mesh.uv=uv;
            mesh.subMeshCount=groups.Length;for(int i=0;i<groups.Length;i++){var triangles=groups[i];if(matrix.determinant<0){triangles=(int[])triangles.Clone();for(int k=0;k<triangles.Length;k+=3){int t=triangles[k+1];triangles[k+1]=triangles[k+2];triangles[k+2]=t;}}mesh.SetTriangles(triangles,i);}
            mesh.RecalculateNormals();mesh.RecalculateTangents();mesh.RecalculateBounds();var go=new GameObject(name){layer=parent.gameObject.layer};go.transform.SetParent(parent,false);go.AddComponent<MeshFilter>().sharedMesh=mesh;var r=go.AddComponent<MeshRenderer>();NativePortSurface.Capture(original,r);return r;
        }
        private static void InstallSwitch(DinStationBattery owner,Battery source,Objects.SwitchOnOff native,Transform front,BoxCollider hit)
        {
            var type=typeof(Objects.SwitchOnOff);var pivot=(Transform)AccessTools.Field(type,"switchTransform").GetValue(native);var originalRenderer=(MeshRenderer)AccessTools.Field(type,"switchRenderer").GetValue(native);
            if(pivot==null||pivot==source.transform||originalRenderer==null||!originalRenderer.transform.IsChildOf(pivot))
            {InstallLegacySwitch(owner,source,front,hit,(MeshRenderer[])Indicators.GetValue(source));return;}
            var frame=new GameObject("NativeBatterySwitchAssembly"){layer=owner.gameObject.layer};frame.transform.SetParent(front,false);var map=new Dictionary<Transform,Transform>();
            Transform copy(Transform old,Transform parent)
            {
                var go=new GameObject(old.name){layer=owner.gameObject.layer};go.transform.SetParent(parent,false);go.transform.localPosition=old.localPosition;go.transform.localRotation=old.localRotation;go.transform.localScale=old.localScale;map.Add(old,go.transform);
                var filter=old.GetComponent<MeshFilter>();var renderer=old.GetComponent<MeshRenderer>();if(filter?.sharedMesh!=null&&renderer!=null){go.AddComponent<MeshFilter>().sharedMesh=filter.sharedMesh;NativePortSurface.Capture(renderer,go.AddComponent<MeshRenderer>());}
                foreach(Transform child in old)copy(child,go.transform);return go.transform;
            }
            var replacementPivot=copy(pivot,frame.transform);var parentSpace=pivot.parent;var bounds=new Bounds();bool first=true;
            foreach(var filter in pivot.GetComponentsInChildren<MeshFilter>(true))if(filter.sharedMesh!=null)
            {var b=CabinetWallMount.TransformedBounds(filter.sharedMesh.bounds,parentSpace.worldToLocalMatrix*filter.transform.localToWorldMatrix);if(first){bounds=b;first=false;}else bounds.Encapsulate(b);}
            var body=parentSpace.InverseTransformPoint(source.transform.TransformPoint(BodyCenter(source)));var normal=OutwardNormal(originalRenderer,parentSpace,body);var up=PerpendicularUp(normal,parentSpace.InverseTransformDirection(originalRenderer.transform.up));
            Fit(frame.transform,bounds,Quaternion.Inverse(Quaternion.LookRotation(normal,up)),StationBatteryPanelLayout.SwitchWidth,StationBatteryPanelLayout.SwitchHeight,.012f,new Vector3(StationBatteryPanelLayout.SwitchX(owner.ModuleWidth),0,StationBatteryPanelLayout.FaceZ+.005f));
            var driver=owner.gameObject.AddComponent<DinBatteryNativeSwitch>();
            foreach(string field in new[]{"offPosition","onPosition","off","on","onPowered","error"})AccessTools.Field(type,field).SetValue(driver,AccessTools.Field(type,field).GetValue(native));
            AccessTools.Field(type,"switchTransform").SetValue(driver,replacementPivot);AccessTools.Field(type,"switchRenderer").SetValue(driver,map[originalRenderer.transform].GetComponent<MeshRenderer>());AccessTools.Field(type,"interactionTrigger").SetValue(driver,hit);driver.SetParentThing(owner);AccessTools.Field(typeof(Thing),"switchOnOff").SetValue(owner,driver);
            Bezel(front,"BatterySwitchBezel",new Vector3(StationBatteryPanelLayout.SwitchX(owner.ModuleWidth),0,StationBatteryPanelLayout.FaceZ-.0004f),new Vector3(.026f,.031f,.0014f));
        }
        private static void InstallLegacySwitch(DinStationBattery owner,Battery source,Transform front,BoxCollider hit,MeshRenderer[] indicators)
        {
            var control=source.Interactables.Concat(source.BuildStates.SelectMany(s=>s.Interactables)).FirstOrDefault(c=>c.Action==InteractableType.OnOff&&c.Collider!=null);
            var target=control?.Collider?.bounds.center??source.transform.position;
            var candidates=source.GetComponentsInChildren<MeshRenderer>(true).Where(r=>!indicators.Contains(r)&&r.GetComponent<MeshFilter>()?.sharedMesh!=null&&(r.name.IndexOf("switch",StringComparison.OrdinalIgnoreCase)>=0||r.name.IndexOf("button",StringComparison.OrdinalIgnoreCase)>=0)).OrderBy(r=>(r.bounds.center-target).sqrMagnitude).ToArray();
            if(candidates.Length==0)throw new InvalidOperationException("Native battery ON/OFF mesh unavailable: "+source.PrefabName);
            var original=candidates[0];var frame=new GameObject("NativeBatteryLegacySwitch"){layer=owner.gameObject.layer};frame.transform.SetParent(front,false);var renderer=CopyBaked(original,source.transform,frame.transform,"NativeBatteryLegacyRocker");var bounds=renderer.GetComponent<MeshFilter>().sharedMesh.bounds;var normal=OutwardNormal(original,source.transform,BodyCenter(source));var up=PerpendicularUp(normal,source.transform.InverseTransformDirection(original.transform.up));
            Fit(frame.transform,bounds,Quaternion.Inverse(Quaternion.LookRotation(normal,up)),StationBatteryPanelLayout.SwitchWidth,StationBatteryPanelLayout.SwitchHeight,.012f,new Vector3(StationBatteryPanelLayout.SwitchX(owner.ModuleWidth),0,StationBatteryPanelLayout.FaceZ+.005f));
            var mesh=renderer.GetComponent<MeshFilter>().sharedMesh;var points=mesh.vertices;for(int i=0;i<points.Length;i++)points[i]-=bounds.center;mesh.vertices=points;mesh.RecalculateBounds();renderer.transform.localPosition=bounds.center;
            var view=renderer.gameObject.AddComponent<DinBatteryLegacySwitch>();view.Owner=owner;view.Axis=Vector3.Cross(up,normal).normalized;
            Debug.LogWarning("[Modular Switchboards] Battery uses legacy ON/OFF mesh without SwitchOnOff driver: "+source.PrefabName);
        }
        private static void Caption(DinStationBattery owner,Transform parent)
        {
            Font font=null;foreach(var name in new[]{"LegacyRuntime.ttf","Arial.ttf"}){try{font=Resources.GetBuiltinResource<Font>(name);}catch(Exception){}if(font!=null)break;}if(font==null)return;
            var go=new GameObject("BatteryCapacityLabel"){layer=owner.gameObject.layer};go.transform.SetParent(parent,false);go.transform.localPosition=new Vector3(StationBatteryPanelLayout.GaugeX(owner.ModuleWidth),-.018f,StationBatteryPanelLayout.FaceZ+.001f);go.transform.localRotation=Quaternion.Euler(0,180,0);
            var text=go.AddComponent<TextMesh>();text.font=font;text.fontSize=96;text.fontStyle=FontStyle.Bold;text.characterSize=.006f;text.anchor=TextAnchor.MiddleCenter;text.alignment=TextAlignment.Center;text.richText=false;text.color=Color.white;text.text=(owner.PowerMaximum/1000000f).ToString("0.#",System.Globalization.CultureInfo.InvariantCulture)+" MJ";font.RequestCharactersInTexture(text.text,text.fontSize,text.fontStyle);DepthLabelText.Apply(text);var view=go.AddComponent<DinBatteryCapacityLabel>();view.Text=text;view.Fit();
        }
        private static void Bezel(Transform parent,string name,Vector3 center,Vector3 size)
        {
            var v=new List<Vector3>();var n=new List<Vector3>();var t=new List<int>();RoundedGeometry.Box(v,n,t,center,size,.001f);var mesh=new Mesh{name=name};mesh.SetVertices(v);mesh.SetNormals(n);mesh.SetTriangles(t,0);mesh.RecalculateBounds();CabinetGeometry.ApplyNativeUv(mesh);var go=new GameObject(name){layer=parent.gameObject.layer};go.transform.SetParent(parent,false);go.AddComponent<MeshFilter>().sharedMesh=mesh;var renderer=go.AddComponent<MeshRenderer>();renderer.sharedMaterial=CabinetGeometry.Materials[3];var block=new MaterialPropertyBlock();block.SetFloat(Thing.DiffuseIndexPropertyID,CabinetGeometry.PaletteIndices[3]);block.SetFloat(Thing.SmoothnessIndexPropertyID,0);block.SetColor(Thing.EMISSION_COLOR,Color.black);renderer.SetPropertyBlock(block);
        }
    }
    public sealed class DinBatteryCapacityLabel:MonoBehaviour
    {
        public TextMesh Text;
        internal void Fit(){if(Text==null)return;var size=Text.GetComponent<MeshRenderer>().localBounds.size;if(size.x>.00001f&&size.y>.00001f)Text.transform.localScale=Vector3.one*Mathf.Min(.07f/size.x,.007f/size.y);}
        private void LateUpdate(){Fit();}
    }
    public sealed class DinBatteryLegacySwitch:MonoBehaviour
    {
        public DinStationBattery Owner;public Vector3 Axis;
        private void LateUpdate(){if(Owner!=null)transform.localRotation=Quaternion.AngleAxis(Owner.OnOff?12f:-12f,Axis);}
    }
    // Native switch positions, native color/error states and native click audio.
    // Force an initial refresh after Unity clones nonserialized runtime fields.
    public sealed class DinBatteryNativeSwitch:Objects.SwitchOnOff
    {
        private bool initialized;
        public override void RefreshState(bool skipAnim=false)
        {
            // DevicePart.Transform is a serialized field, not initialized by
            // Awake or SetParentThing. Dynamically created drivers must bind it
            // before native switch audio reads Transform.localPosition.
            if(Transform==null)Transform=transform;
            if(!initialized&&parentThing!=null){initialized=true;IsOn=!parentThing.OnOff;_currentColorState=(Objects.SwitchColorState)(-1);}
            base.RefreshState(skipAnim);
        }
    }
}
