using UnityEngine;
namespace ModularSwitchboards {
 internal static class DinLogicHousing {
  // Same established two-position casing and dimensions as our battery holder.
  // No battery opening, spindle, decorative end disks or post-build mesh edits.
  internal static Mesh Build()=>SmartContactorModel.Body(noTerminals:true);
 }
}
