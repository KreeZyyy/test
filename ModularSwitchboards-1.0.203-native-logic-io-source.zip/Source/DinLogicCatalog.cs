using System;using System.Linq;using System.Collections.Generic;
using Assets.Scripts;using Assets.Scripts.Objects;using Assets.Scripts.Objects.Electrical;using UnityEngine;
namespace ModularSwitchboards {
 internal static class DinLogicCatalog {
  internal static string SetupFailure{get;private set;}
  internal static bool TryInstall(List<Thing> sources,Transform storage,Item drill){SetupFailure=null;try{Install(sources,storage,drill);return true;}catch(Exception e){SetupFailure=e.ToString();Debug.LogError("[Modular Switchboards] DIN Logic I/O setup failed; the existing switchboard modules remain available: "+e);return false;}}
  internal static readonly string[] Native={"StructureLogicReader","StructureLogicWriter","StructureLogicBatchReader","StructureLogicBatchWriter","StructureLogicSlotReader","StructureLogicBatchSlotReader","StructureLogicReagentReader","StructureLogicMirror"};
  internal static string Name(string native)=>"StructureDinLogic"+native.Substring("StructureLogic".Length);
  internal static bool Contains(string name)=>Native.Any(n=>Name(n)==name);
  internal static void Saves(){var mod=SwitchboardsMod.Mod;mod.AddSaveDataType<DinLogicReaderSaveData>();mod.AddSaveDataType<DinLogicWriterSaveData>();mod.AddSaveDataType<DinLogicBatchReaderSaveData>();mod.AddSaveDataType<DinLogicBatchWriterSaveData>();mod.AddSaveDataType<DinLogicSlotReaderSaveData>();mod.AddSaveDataType<DinLogicBatchSlotReaderSaveData>();mod.AddSaveDataType<DinLogicReagentReaderSaveData>();mod.AddSaveDataType<DinLogicMirrorSaveData>();}
  private static LogicUnitBase Replace(Structure s,int index){switch(index){case 0:return SwitchboardPrefabs.ReplaceComponent<DinLogicReader>(s,true);case 1:return SwitchboardPrefabs.ReplaceComponent<DinLogicWriter>(s,true);case 2:return SwitchboardPrefabs.ReplaceComponent<DinLogicBatchReader>(s,true);case 3:return SwitchboardPrefabs.ReplaceComponent<DinLogicBatchWriter>(s,true);case 4:return SwitchboardPrefabs.ReplaceComponent<DinLogicSlotReader>(s,true);case 5:return SwitchboardPrefabs.ReplaceComponent<DinLogicBatchSlotReader>(s,true);case 6:return SwitchboardPrefabs.ReplaceComponent<DinLogicReagentReader>(s,true);default:return SwitchboardPrefabs.ReplaceComponent<DinLogicMirror>(s,true);}}
  internal static void Install(List<Thing> sources,Transform storage,Item drill){
   var original=sources.OfType<MultiConstructor>().Where(k=>k.Constructables!=null&&Native.All(n=>k.Constructables.Any(c=>c!=null&&c.PrefabName==n))).OrderBy(k=>k.Constructables.Count).FirstOrDefault()??throw new InvalidOperationException("Original Logic I/O kit missing");
   // The actual kit has ten slots: nine native variants and one empty slot.
   // Resolve the eight requested sources before cloning anything; Single must never dereference the empty entry.
   var candidates=original.Constructables.Where(s=>s!=null).ToArray();
   var prototypes=Native.Select(name=>candidates.Single(s=>s.PrefabName==name)).ToArray();
   var kit=UnityEngine.Object.Instantiate(original,storage);var variants=new List<Structure>();var clones=new List<GameObject>();var ownedBlueprints=new List<GameObject>();
   try{
    SwitchboardsMod.Identify(kit,DinLogicRuntime.Kit,"Kit (DIN Logic I/O)");kit.SetQuantity(1);kit.PaintableMaterial=null;kit.RecipeTier=MachineTier.TierOne;
    for(int i=0;i<Native.Length;i++){
     var source=prototypes[i];var clone=UnityEngine.Object.Instantiate(source,storage);clones.Add(clone.gameObject);var m=Replace(clone,i);variants.Add(m);
     SwitchboardsMod.Identify(m,Name(Native[i]),"DIN "+source.DisplayName);m.HideInStationpedia=false;
     m.BuildStates=new List<BuildState>{SwitchboardsMod.MakeState(m.BuildStates.Last(),kit,1,null,0,drill)};
     DinLogicModel.Install(m,Native[i],storage);if(m.Blueprint!=null&&m.Blueprint!=source.Blueprint)ownedBlueprints.Add(m.Blueprint);m.Thumbnail=CabinetIcons.Get(Name(Native[i]).Substring("Structure".Length));m.Thumbnails=new Sprite[0];m.BuildStates[0].Thumbnail=m.Thumbnail;
    }
    kit.Constructables=variants;kit.LastSelectedIndex=0;sources.Add(kit);sources.AddRange(variants);
    Debug.Log("[Modular Switchboards] DIN Logic I/O: 8 native functions, own models/colliders, 2 slots and 10 W; POWER top, DATA IN/OUT bottom. Writer Switch excluded.");
   }catch{foreach(var bp in ownedBlueprints)if(bp!=null)UnityEngine.Object.DestroyImmediate(bp);foreach(var clone in clones)if(clone!=null)UnityEngine.Object.DestroyImmediate(clone);if(kit!=null)UnityEngine.Object.DestroyImmediate(kit.gameObject);throw;}
  }
 }
}
