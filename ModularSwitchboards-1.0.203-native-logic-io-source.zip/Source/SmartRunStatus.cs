namespace ModularSwitchboards
{
    internal enum SmartRunState:byte { Off,Running,Fault,Idle }
    internal static class SmartRunStatus
    {
        internal static SmartRunState Evaluate(bool powered,bool on,bool chip,bool fault,bool program)
        {
            if(!powered||!on)return SmartRunState.Off;
            if(!chip)return SmartRunState.Idle;
            if(fault)return SmartRunState.Fault;
            // A healthy loaded program remains WORK after EOF or while execution is paused.
            return program?SmartRunState.Running:SmartRunState.Idle;
        }
    }
}
