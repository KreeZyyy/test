using System;using System.Linq;using Assets.Scripts.Objects.Pipes;using Assets.Scripts.Networks;using Assets.Scripts.Objects.Electrical;using HarmonyLib;
namespace ModularSwitchboards {
 internal static class DoorDialNetwork {
  private static readonly System.Reflection.PropertyInfo PowerCable=AccessTools.Property(typeof(Device),"PowerCable"),PowerCables=AccessTools.Property(typeof(Device),"PowerCables"),DataCables=AccessTools.Property(typeof(Device),"DataCables");
  internal static void Refresh(DoorDial dial){
   var cable=!dial.IsStructureCompleted||dial.IsCursor||dial.IsBeingDestroyed?null:dial.Wiring?.DialCable(dial.ReferenceId);
   var network=cable?.CableNetwork;
   foreach(var n in new[]{dial.BoundNetwork,network}.Where(n=>n!=null).Distinct())Normalize(dial,n);
   if(network==dial.BoundNetwork&&cable==dial.BoundCable&&dial.DataCable==cable&&dial.DataCables.SequenceEqual(cable==null?Array.Empty<Cable>():new[]{cable})&&dial.PowerCable==null&&dial.PowerCables.Length==0&&(network==null||network.GetDeviceRegistration(dial)?.Contains(cable)==true))return;
   Unbind(dial);dial.BoundCable=cable;dial.BoundNetwork=network;dial.DataCable=cable;
   DataCables.SetValue(dial,cable==null?Array.Empty<Cable>():new[]{cable},null);dial.InputNetwork1=network;
   if(network!=null){network.AddDevice(cable,dial);network.DirtyPowerAndDataDeviceLists();network.RefreshNetworkDevice(dial);}
  }
  private static void Normalize(DoorDial dial,CableNetwork network){
   bool seen=false,changed=false;
   lock(network.DeviceList)for(int i=network.DeviceList.Count-1;i>=0;i--)if(ReferenceEquals(network.DeviceList[i],dial)){if(seen){network.DeviceList.RemoveAt(i);changed=true;}else seen=true;}
   if(changed){network.DirtyPowerAndDataDeviceLists();network.RefreshNetworkDevice(dial);}
  }
  internal static void Unbind(DoorDial dial){
   dial.BoundNetwork?.RemoveDevice(dial);dial.BoundCable=null;dial.BoundNetwork=null;dial.DataCable=null;dial.InputNetwork1=null;dial.OutputNetwork1=null;
   PowerCable.SetValue(dial,null,null);PowerCables.SetValue(dial,Array.Empty<Cable>(),null);DataCables.SetValue(dial,Array.Empty<Cable>(),null);
  }
 }
}
