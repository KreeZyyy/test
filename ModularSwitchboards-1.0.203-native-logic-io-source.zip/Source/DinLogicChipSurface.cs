using System;using UnityEngine;using UnityEngine.Rendering;
namespace ModularSwitchboards {
 internal static class DinLogicChipSurface {
  private static Material body,pins;
  private static Color ReferenceColor(Color srgb)=>QualitySettings.activeColorSpace==ColorSpace.Linear?srgb.linear:srgb;
  private static void Ensure(){if(body!=null&&pins!=null)return;var shader=ServerGraphics.FindShader("Standard");if(shader==null||!ServerGraphics.ShaderAvailable(shader))throw new InvalidOperationException("Logic chip surface shader unavailable");
   // Median sRGB samples from the user's 1.0.193 original reference: ColorBlack / contact texture.
   body=new Material(shader){name="Switchboards.Logic.ReferenceBlack",color=ReferenceColor(new Color(33f/255,33f/255,33f/255))};
   pins=new Material(shader){name="Switchboards.Logic.ReferencePins",color=ReferenceColor(new Color(184f/255,186f/255,189f/255))};
   CabinetMatteSurface.Configure(body);CabinetMatteSurface.Configure(pins);pins.SetFloat("_Metallic",.35f);pins.SetFloat("_Glossiness",.25f);
  }
  internal static void Restore(MeshRenderer r){Ensure();r.SetPropertyBlock(null);for(int i=0;i<r.sharedMaterials.Length;i++)r.SetPropertyBlock(null,i);r.sharedMaterials=new[]{body,body,body,body,pins};r.shadowCastingMode=ShadowCastingMode.Off;r.receiveShadows=false;}
 }
}
