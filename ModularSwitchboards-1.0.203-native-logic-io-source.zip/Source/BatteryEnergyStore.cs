using System;
using Assets.Scripts.Objects.Items;
namespace ModularSwitchboards
{
    // One live store; adapters never copy charge or introduce a second energy balance.
    internal sealed class BatteryEnergyStore
    {
        internal readonly object Identity;
        private readonly Func<float> read,free;
        private readonly Action<float> write;
        internal readonly float ChargeLimit;
        internal BatteryEnergyStore(object identity,Func<float> read,Action<float> write,Func<float> free,float chargeLimit)
        {Identity=identity;this.read=read;this.write=write;this.free=free;ChargeLimit=chargeLimit;}
        internal float PowerStored {get=>read();set=>write(value);}
        internal float PowerDelta=>free();
        internal static BatteryEnergyStore Cell(BatteryCell cell)=>cell==null?null:new BatteryEnergyStore(cell,()=>cell.PowerStored,v=>cell.PowerStored=v,()=>cell.PowerDelta,1000f);
    }
}
