using System;using System.Linq;using System.Collections.Generic;using System.Xml.Serialization;
using Assets.Scripts;using Assets.Scripts.GridSystem;using Assets.Scripts.Networking;using Assets.Scripts.Networks;using Assets.Scripts.Objects;using Assets.Scripts.Objects.Electrical;using Assets.Scripts.Objects.Motherboards;using LibConstruct;using UnityEngine;
namespace ModularSwitchboards {
 public sealed class DoorSmartDisplaySaveData:LogicBaseSaveData {
  [XmlElement]public PlacementBoardStructureSaveData Mount;
  [XmlElement]public int DisplayColor=(int)ColorType.Green;
 }
 public sealed class DoorSmartDisplay:LogicDisplay,IPlacementBoardStructure {
  public const string PrefabId="StructureSwitchboardDoorSmartDisplay";
  public PlacementBoard Board{get;set;}public PlacementBoard.BoardCell[] BoardCells{get;set;}
  internal SwitchboardCabinet Cabinet=>Board?.PrimaryHost as SwitchboardCabinet;
  private CabinetWiring oldWiring;
  private CabinetWiring Wiring{get{if(Cabinet!=null)oldWiring=Cabinet.Wiring;return oldWiring;}}
  private int displayColor=(int)ColorType.Green;
  public override void Awake(){PrefabAudioOwner.PrepareInstance(this);base.Awake();BoardStructureHooks.Awake(this);}
  public override Grid3 GetLocalGrid()=>Board==null?default(Grid3):Board.WorldToGrid(transform.position);
  internal static bool CanPlace(PlacementBoard board,Grid3 p,int rotation) {
   if(!(board is SwitchboardDoorBoard)||!(board.PrimaryHost is SwitchboardCabinet host)||!host.IsStructureCompleted||!DoorDisplayLayout.Fits(p.x,p.y,p.z,rotation,CabinetShape.MinDoorY(host.PrefabName)))return false;
   return DoorDisplayClearance.DisplayFits(board,p)&&!board.Structures.OfType<Structure>().Where(s=>!s.IsBeingDestroyed&&!s.IsCursor).Any(s=>{var q=board.WorldToGrid(s.transform.position);return DoorDisplayLayout.Overlaps(p.x,p.y,2,q.x,q.y,s is DoorSmartDisplay?2:1);});
  }
  public override CanConstructInfo CanConstruct() {
   if(!(Board is SwitchboardDoorBoard)||Cabinet==null||IsCursor&&PlacementBoard.CursorBoard!=Board)return CanConstructInfo.InvalidPlacement("Aim at the outside of a completed cabinet door.");
   var p=GetLocalGrid();if(IsCursor){if(MountPlacement.TryLockedGrid(this,Board,out var locked))p=locked;else p=new Grid3(DoorModuleLayout.SnapSlot(p.x,-10,0),DoorModuleLayout.SnapSlot(p.y,CabinetShape.MinDoorY(Cabinet.PrefabName),10),0);PlacementBoard.CursorGrid=p;PlacementBoard.CursorRotation=0;transform.SetPositionAndRotation(Board.GridToWorld(p),Board.IndexToRotation(0));}
   return CanPlace(Board,p,Board.RotationToIndex(transform.rotation))?CanConstructInfo.ValidPlacement:CanConstructInfo.InvalidPlacement("Choose two free positions side by side with clear space for the display label.");
  }
  protected override CanConstructInfo CanDeconstruct() {
   if(DoorDisplayLabel.Attached(this))return CanConstructInfo.InvalidPlacement("Remove the display label first.");
   if(Cabinet?.CanAccessModules!=true)return CanConstructInfo.InvalidPlacement("Open the cabinet first.");
   if(Wiring?.HasWires(ReferenceId)==true)return CanConstructInfo.InvalidPlacement("Remove the display cable first.");return CanConstructInfo.ValidPlacement;
  }
  public override bool CanLogicRead(LogicType type)=>type==LogicType.Mode||type==LogicType.Color||base.CanLogicRead(type);
  public override bool CanLogicWrite(LogicType type)=>type==LogicType.Mode||type==LogicType.Color||base.CanLogicWrite(type);
  public override double GetLogicValue(LogicType type)=>type==LogicType.Color?displayColor:base.GetLogicValue(type);
  public override void SetLogicValue(LogicType type,double value) {
   if(type!=LogicType.Color){base.SetLogicValue(type,value);return;}
   if(double.IsNaN(value)||double.IsInfinity(value)||value<int.MinValue||value>int.MaxValue||!GameManager.IsValidColor((int)value))return;
   displayColor=(int)value;if(NetworkManager.IsServer)NetworkUpdateFlags|=512;
  }
  public override float GetUsedPower(CableNetwork network)=>-1;
  public override bool AllowSetPower(CableNetwork network)=>false;
  protected override void AssessPower(CableNetwork network,bool on)=>RefreshSupply();
  private void RefreshSupply(){if(GameManager.RunSimulation){var output=Wiring?.OutputForDisplay(ReferenceId);SetPower(null,!IsCursor&&!IsBeingDestroyed&&IsStructureCompleted&&output!=null&&output.Conducting);}}
  private void LateUpdate(){if(IsCursor)return;RefreshSupply();var swatch=GameManager.GetColorSwatch(GameManager.IsValidColor(displayColor)?displayColor:(int)ColorType.Green);if(swatch?.Emissive!=null)DigitOn=swatch.Emissive;if(GameManager.IsMainThread&&DigitTransform!=null&&GameManager.GameState==GameState.Running){string text=Powered&&OnOff?SmartNativeDisplayText.Read(this):"";SetDisplay((text??"").ToCharArray());}}
  public override PassiveTooltip GetPassiveTooltip(Collider hit){var tip=base.GetPassiveTooltip(hit);var output=Wiring?.OutputForDisplay(ReferenceId);tip.Extended=(output==null?"No Smart Output connected.":"Smart Output "+(SmartOutputAddresses.Valid(output.OutputAddress)?"d"+output.OutputAddress:"unassigned")+" — "+(Powered?"powered":"unpowered"))+"\nWire DATA IN through a dedicated Door Bridge to Smart Output OUT. Program Mode, Setting, Color and On through its d0–d5 address.";return tip;}
  public override void OnDeregistered(){Wiring?.RemoveBreaker(ReferenceId);base.OnDeregistered();if(Board!=null)BoardStructureHooks.OnDeregistered(this);}
  public override void OnDestroy(){Wiring?.RemoveBreaker(ReferenceId);base.OnDestroy();}
  public override ThingSaveData SerializeSave(){ThingSaveData data=new DoorSmartDisplaySaveData();InitialiseSaveData(ref data);return data;}
  protected override void InitialiseSaveData(ref ThingSaveData data){base.InitialiseSaveData(ref data);if(data is DoorSmartDisplaySaveData save){save.DisplayColor=displayColor;if(Board!=null)save.Mount=BoardStructureHooks.SerializeSave(this);}}
  public override void DeserializeSave(ThingSaveData data){base.DeserializeSave(data);if(data is DoorSmartDisplaySaveData save){displayColor=GameManager.IsValidColor(save.DisplayColor)?save.DisplayColor:(int)ColorType.Green;if(save.Mount!=null)BoardStructureHooks.DeserializeSave(this,save.Mount);}}
  public override void SerializeOnJoin(RocketBinaryWriter writer){base.SerializeOnJoin(writer);BoardStructureHooks.SerializeOnJoin(writer,this);writer.WriteInt32(displayColor);}
  public override void DeserializeOnJoin(RocketBinaryReader reader){base.DeserializeOnJoin(reader);BoardStructureHooks.DeserializeOnJoin(reader,this);displayColor=reader.ReadInt32();}
  public override void BuildUpdate(RocketBinaryWriter writer,ushort flags){base.BuildUpdate(writer,flags);if(Thing.IsNetworkUpdateRequired(512,flags))writer.WriteInt32(displayColor);}
  public override void ProcessUpdate(RocketBinaryReader reader,ushort flags){base.ProcessUpdate(reader,flags);if(Thing.IsNetworkUpdateRequired(512,flags))displayColor=reader.ReadInt32();}
 }
}
