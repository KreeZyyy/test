using System;using System.Collections.Generic;using System.Linq;using Assets.Scripts;using UnityEngine;
namespace ModularSwitchboards
{
    // Render only copied mesh/transform data: never instantiate a live Battery
    // or run native device/network scripts for a Stationpedia thumbnail.
    internal static class DinBatteryThumbnail
    {
        internal static Sprite Create(DinStationBattery owner,Transform front,MeshRenderer finalBody)
        {
            if(GameManager.IsBatchMode||ServerGraphics.Headless)return null;
            GameObject root=null;RenderTexture target=null;Texture2D texture=null;var previous=RenderTexture.active;
            try
            {
                root=new GameObject("DIN Battery Icon Geometry");root.transform.position=new Vector3(1000,1000,1000);
                var map=new Dictionary<Transform,Transform>{{owner.transform,root.transform}};
                var renderers=new List<MeshRenderer>();
                foreach(var source in new[]{finalBody}.Concat(front.GetComponentsInChildren<MeshRenderer>(true)))
                {
                    var mesh=source.GetComponent<MeshFilter>()?.sharedMesh;if(mesh==null)continue;
                    var node=Frame(source.transform,owner.transform,map);node.gameObject.layer=31;
                    node.gameObject.AddComponent<MeshFilter>().sharedMesh=mesh;
                    var copy=node.gameObject.AddComponent<MeshRenderer>();copy.sharedMaterials=source.sharedMaterials;
                    var block=new MaterialPropertyBlock();source.GetPropertyBlock(block);copy.SetPropertyBlock(block);
                    for(int i=0;i<source.sharedMaterials.Length;i++){source.GetPropertyBlock(block,i);copy.SetPropertyBlock(block,i);}
                    renderers.Add(copy);
                }
                if(renderers.Count==0)return null;
                var bounds=renderers[0].bounds;foreach(var part in renderers.Skip(1))bounds.Encapsulate(part.bounds);
                var cameraObject=new GameObject("DIN Icon Camera");cameraObject.transform.SetParent(root.transform,false);
                var camera=cameraObject.AddComponent<Camera>();camera.enabled=false;camera.orthographic=true;
                camera.clearFlags=CameraClearFlags.SolidColor;camera.backgroundColor=Color.clear;camera.cullingMask=1<<31;
                camera.nearClipPlane=.01f;camera.farClipPlane=3;camera.orthographicSize=bounds.extents.magnitude*.95f;
                camera.transform.position=bounds.center+new Vector3(.07f,.045f,.3f);camera.transform.LookAt(bounds.center,Vector3.up);
                var lamp=new GameObject("DIN Icon Light");lamp.transform.SetParent(root.transform,false);lamp.transform.rotation=Quaternion.Euler(30,200,0);
                var light=lamp.AddComponent<Light>();light.type=LightType.Directional;light.intensity=1.5f;light.cullingMask=1<<31;light.shadows=LightShadows.None;
                target=RenderTexture.GetTemporary(512,512,24,RenderTextureFormat.ARGB32);camera.targetTexture=target;camera.Render();
                RenderTexture.active=target;texture=new Texture2D(512,512,TextureFormat.RGBA32,false){name="DIN Battery F1 "+owner.ModuleWidth};
                texture.ReadPixels(new Rect(0,0,512,512),0,0);texture.Apply();
                var sprite=Sprite.Create(texture,new Rect(0,0,512,512),new Vector2(.5f,.5f),100);sprite.name="DIN Battery "+owner.ModuleWidth+" positions";
                return sprite;
            }
            catch(Exception ex){if(texture!=null)UnityEngine.Object.DestroyImmediate(texture);Debug.LogWarning("[Modular Switchboards] Battery F1 preview unavailable: "+ex.Message);return null;}
            finally{RenderTexture.active=previous;if(root!=null)UnityEngine.Object.DestroyImmediate(root);if(target!=null)RenderTexture.ReleaseTemporary(target);}
        }
        private static Transform Frame(Transform source,Transform owner,Dictionary<Transform,Transform> map)
        {
            if(map.TryGetValue(source,out var result))return result;
            var parent=Frame(source.parent,owner,map);var go=new GameObject(source.name);go.transform.SetParent(parent,false);
            go.transform.localPosition=source.localPosition;go.transform.localRotation=source.localRotation;go.transform.localScale=source.localScale;
            map[source]=go.transform;return go.transform;
        }
    }
}
