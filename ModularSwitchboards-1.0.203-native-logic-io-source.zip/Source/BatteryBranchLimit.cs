using System;
using System.Collections.Generic;
using System.Linq;
namespace ModularSwitchboards
{
    // Physical branch domains ignore switch state, charge, cell presence and registration order.
    // Directional device paths keep common charging feeds separate while detecting downstream merges.
    internal static class BatteryBranchLimit
    {
        internal const string Rule="One Battery Holder per wired output branch, including paths through OFF breakers or switches. Additional holders require separate branches.";
        internal const string Warning="Battery backup limit exceeded — connect to a separate output branch.";
        private sealed class Slice
        {
            internal WeakReference Owner;
            internal int Id;
            internal CabinetWireSaveData[] Wires;
            internal long[] Holders,Through,Transit,NormallyClosed;
            internal KeyValuePair<CabinetWireEnd,WeakReference>[] Ports;
        }
        private static readonly object gate=new object();
        private static readonly List<Slice> slices=new List<Slice>();
        private static HashSet<long> blocked=new HashSet<long>();
        private static int nextId,version;
        internal static int Version{get{lock(gate)return version;}}
        private static void UpdateBlocked(){var next=Calculate(null,null);if(!next.SetEquals(blocked)){blocked=next;version++;}}
        internal static void Publish(object owner,IEnumerable<CabinetWireSaveData> wires,CabinetPowerNode[] nodes,IEnumerable<KeyValuePair<CabinetWireEnd,object>> ports)
        {
            lock(gate)
            {
                bool pruned=slices.RemoveAll(s=>!s.Owner.IsAlive)>0;
                var slice=slices.FirstOrDefault(s=>ReferenceEquals(s.Owner.Target,owner));
                if(slice==null){slice=new Slice{Owner=new WeakReference(owner),Id=++nextId};slices.Add(slice);}
                var nextWires=wires.Where(w=>!w.Burnt).Select(w=>new CabinetWireSaveData{From=new CabinetWireEnd(w.From.Owner,w.From.Contact),To=new CabinetWireEnd(w.To.Owner,w.To.Contact)}).ToArray();
                // Reserve physical paths even when breakers, contactors or holders are OFF.
                var nextHolders=nodes.Where(n=>n.IsBatteryModule).Select(n=>n.ReferenceId).ToArray();
                var nextThrough=nodes.Where(n=>n.ReferenceId<0||n.IsContactor||n.IsAnalyserModule||n.IsDoorPart).Select(n=>n.ReferenceId).ToArray();
                var nextTransit=nodes.Where(n=>!n.IsServiceLoad).Select(n=>n.ReferenceId).ToArray();
                var nextNormallyClosed=nodes.Where(n=>n.IsContactor&&n.HasNormallyClosedContact).Select(n=>n.ReferenceId).ToArray();
                var nextPorts=ports.Select(p=>new KeyValuePair<CabinetWireEnd,WeakReference>(p.Key,new WeakReference(p.Value))).ToArray();
                bool same=!pruned&&slice.Wires!=null&&slice.Holders.SequenceEqual(nextHolders)&&slice.Through.SequenceEqual(nextThrough)&&slice.Transit.SequenceEqual(nextTransit)&&slice.NormallyClosed.SequenceEqual(nextNormallyClosed)
                    &&slice.Wires.Length==nextWires.Length&&slice.Wires.Zip(nextWires,(a,b)=>a.From.Equals(b.From)&&a.To.Equals(b.To)).All(v=>v)
                    &&slice.Ports.Length==nextPorts.Length&&slice.Ports.Zip(nextPorts,(a,b)=>a.Key.Equals(b.Key)&&ReferenceEquals(a.Value.Target,b.Value.Target)).All(v=>v);
                if(same)return;
                slice.Wires=nextWires;slice.Holders=nextHolders;slice.Through=nextThrough;slice.Ports=nextPorts;slice.Transit=nextTransit;slice.NormallyClosed=nextNormallyClosed;
                UpdateBlocked();
            }
        }
        internal static void Remove(object owner){lock(gate){slices.RemoveAll(s=>!s.Owner.IsAlive||ReferenceEquals(s.Owner.Target,owner));UpdateBlocked();}}
        internal static bool IsBlocked(long id){lock(gate)return blocked.Contains(id);}
        internal static bool CanJoin(object owner,CabinetWireEnd a,CabinetWireEnd b)
        {
            lock(gate)return !Calculate(owner,new CabinetWireSaveData{From=a,To=b}).Except(blocked).Any();
        }
        private static HashSet<long> Calculate(object changed,CabinetWireSaveData extra)
        {
            var parent=new Dictionary<string,string>();
            Func<string,string> root=x=>{
                if(!parent.ContainsKey(x))return parent[x]=x;
                string at=x;while(parent[at]!=at)at=parent[at];
                while(parent[x]!=x){string next=parent[x];parent[x]=at;x=next;}return at;
            };
            Action<string,string> join=(a,b)=>{a=root(a);b=root(b);if(a!=b)parent[a]=b;};
            Func<Slice,CabinetWireEnd,string> key=(s,e)=>s.Id+":"+e.Owner+"/"+e.Contact;
            var nets=new List<object>();
            foreach(var s in slices.Where(s=>s.Owner.IsAlive))
            {
                foreach(var w in s.Wires)join(key(s,w.From),key(s,w.To));
                if(extra!=null&&ReferenceEquals(s.Owner.Target,changed))join(key(s,extra.From),key(s,extra.To));
                foreach(long id in s.Through)join(key(s,new CabinetWireEnd(id,0)),key(s,new CabinetWireEnd(id,1)));
                foreach(long id in s.NormallyClosed)join(key(s,new CabinetWireEnd(id,0)),key(s,new CabinetWireEnd(id,ContactorCircuit.NcPin)));
                foreach(var port in s.Ports)
                {
                    var net=port.Value.Target;if(net==null)continue;
                    int index=nets.FindIndex(n=>ReferenceEquals(n,net));if(index<0){index=nets.Count;nets.Add(net);}
                    join(key(s,port.Key),"network:"+index);
                }
            }
            var holders=slices.Where(s=>s.Owner.IsAlive).SelectMany(s=>s.Holders.Select(id=>new{Id=id,Input=key(s,new CabinetWireEnd(id,0)),Output=key(s,new CabinetWireEnd(id,1))})).ToArray();
            // Follow IN -> OUT through devices without walking backwards into the
            // common charging feed. Converging downstream paths form one branch,
            // even if users insert breakers/transformers after individual holders.
            var routes=new Dictionary<string,List<string>>();
            foreach(var slice in slices.Where(s=>s.Owner.IsAlive))foreach(long id in slice.Transit)
            {
                string from=root(key(slice,new CabinetWireEnd(id,0))),to=root(key(slice,new CabinetWireEnd(id,1)));
                if(!routes.TryGetValue(from,out var targets))routes[from]=targets=new List<string>();targets.Add(to);
            }
            var walks=holders.Select(h=>new{Holder=h,Start=root(h.Output)}).ToArray();
            var meet=new Dictionary<string,string>();
            var merges=new List<KeyValuePair<string,string>>();
            foreach(var walk in walks)
            {
                var seen=new HashSet<string>();var queue=new Queue<string>();queue.Enqueue(walk.Start);
                while(queue.Count>0)
                {
                    string at=queue.Dequeue();if(!seen.Add(at))continue;
                    if(meet.TryGetValue(at,out var previous))merges.Add(new KeyValuePair<string,string>(previous,walk.Start));else meet[at]=walk.Start;
                    if(routes.TryGetValue(at,out var targets))foreach(string target in targets)queue.Enqueue(target);
                }
            }
            foreach(var merge in merges)join(merge.Key,merge.Value);
            return new HashSet<long>(holders.GroupBy(h=>root(h.Output)).SelectMany(g=>g.Select(h=>h.Id).Distinct().OrderBy(id=>id).Skip(1)));
        }
    }
}
