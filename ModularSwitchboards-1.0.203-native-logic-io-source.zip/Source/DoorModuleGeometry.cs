using System.Collections.Generic;
using UnityEngine;

namespace ModularSwitchboards
{
    internal static class DoorModuleGeometry
    {
        internal static Mesh Cylinder(float radius,float back,float front)
        {
            const int steps=32;
            var vertices=new List<Vector3>();var normals=new List<Vector3>();var triangles=new List<int>();
            for(int i=0;i<steps;i++)
            {
                float a=i*2*Mathf.PI/steps,b=(i+1)*2*Mathf.PI/steps;
                var na=new Vector3(Mathf.Cos(a),Mathf.Sin(a),0);var nb=new Vector3(Mathf.Cos(b),Mathf.Sin(b),0);
                var ab=new Vector3(radius*na.x,radius*na.y,back);var bb=new Vector3(radius*nb.x,radius*nb.y,back);
                var af=new Vector3(ab.x,ab.y,front);var bf=new Vector3(bb.x,bb.y,front);int p=vertices.Count;
                // Radial side normals are continuous around the circumference.
                // Both planar caps own separate vertices: no bevel-like smoothing
                // into a cap and no differently averaged normal in each triangle.
                vertices.AddRange(new[]{ab,bb,af,bf,new Vector3(0,0,back),bb,ab,new Vector3(0,0,front),af,bf});
                normals.AddRange(new[]{na,nb,na,nb,new Vector3(0,0,-1),new Vector3(0,0,-1),new Vector3(0,0,-1),new Vector3(0,0,1),new Vector3(0,0,1),new Vector3(0,0,1)});
                triangles.AddRange(new[]{p,p+1,p+2,p+1,p+3,p+2,p+4,p+5,p+6,p+7,p+8,p+9});
            }
            var mesh=new Mesh{name="Door module smooth cylinder"};mesh.SetVertices(vertices);mesh.SetNormals(normals);mesh.SetTriangles(triangles,0);mesh.RecalculateBounds();return mesh;
        }

        // Shared hollow, domed silver collar for the pushbutton and rotary selector.
        // Keep the original 31 mm diameter so existing door labels still fit.
        internal static Mesh ControlBezel()
        {
            const int steps=48;
            float[] radius={.0123f,.0142f,.0150f,.0155f,.0155f,.0151f,.0143f,.0133f,.0123f,.0119f,.0119f,.0123f};
            float[] depth ={.001f, .001f, .002f, .004f, .0065f,.0085f,.0105f,.0117f,.012f, .0115f,.008f, .003f};
            var vertices=new List<Vector3>();var normals=new List<Vector3>();var triangles=new List<int>();
            var nr=new float[radius.Length];var nz=new float[radius.Length];
            for(int j=0;j<radius.Length;j++)
            {
                int previous=(j+radius.Length-1)%radius.Length,next=(j+1)%radius.Length;
                float ar=radius[j]-radius[previous],az=depth[j]-depth[previous],br=radius[next]-radius[j],bz=depth[next]-depth[j];
                float al=(float)System.Math.Sqrt(ar*ar+az*az),bl=(float)System.Math.Sqrt(br*br+bz*bz);
                float x=az/al+bz/bl,z=-ar/al-br/bl,len=(float)System.Math.Sqrt(x*x+z*z);
                nr[j]=x/len;nz[j]=z/len;
            }
            for(int i=0;i<steps;i++)for(int j=0;j<radius.Length;j++)
            {
                float a=i*2*Mathf.PI/steps,b=(i+1)*2*Mathf.PI/steps;int k=(j+1)%radius.Length,p=vertices.Count;
                vertices.AddRange(new[]{new Vector3(radius[j]*Mathf.Cos(a),radius[j]*Mathf.Sin(a),depth[j]),new Vector3(radius[j]*Mathf.Cos(b),radius[j]*Mathf.Sin(b),depth[j]),new Vector3(radius[k]*Mathf.Cos(b),radius[k]*Mathf.Sin(b),depth[k]),new Vector3(radius[k]*Mathf.Cos(a),radius[k]*Mathf.Sin(a),depth[k])});
                normals.AddRange(new[]{new Vector3(nr[j]*Mathf.Cos(a),nr[j]*Mathf.Sin(a),nz[j]),new Vector3(nr[j]*Mathf.Cos(b),nr[j]*Mathf.Sin(b),nz[j]),new Vector3(nr[k]*Mathf.Cos(b),nr[k]*Mathf.Sin(b),nz[k]),new Vector3(nr[k]*Mathf.Cos(a),nr[k]*Mathf.Sin(a),nz[k])});
                triangles.AddRange(new[]{p,p+1,p+2,p,p+2,p+3});
            }
            var mesh=new Mesh{name="Rounded hollow door control bezel"};mesh.SetVertices(vertices);mesh.SetNormals(normals);mesh.SetTriangles(triangles,0);mesh.RecalculateBounds();return mesh;
        }

        // Raised hood, with a 120 degree opening below the mushroom.
        internal const float GuardInner=.0235f,GuardOuter=.0285f,GuardBack=.0025f,GuardFront=.036f;
        internal static Mesh StopGuard()
        {
            const int steps=32;var vertices=new List<Vector3>();var normals=new List<Vector3>();var triangles=new List<int>();
            var forward=new Vector3(0,0,1);var back=new Vector3(0,0,-1);
            System.Action<Vector3,Vector3,Vector3,Vector3,Vector3,Vector3,Vector3,Vector3> quad=(a,b,c,d,na,nb,nc,nd)=>
            {
                int p=vertices.Count;vertices.AddRange(new[]{a,b,c,d});normals.AddRange(new[]{na,nb,nc,nd});
                float ux=b.x-a.x,uy=b.y-a.y,uz=b.z-a.z,vx=c.x-a.x,vy=c.y-a.y,vz=c.z-a.z;
                float dot=(uy*vz-uz*vy)*na.x+(uz*vx-ux*vz)*na.y+(ux*vy-uy*vx)*na.z;
                triangles.AddRange(dot>=0?new[]{p,p+1,p+2,p,p+2,p+3}:new[]{p,p+2,p+1,p,p+3,p+2});
            };
            for(int i=0;i<steps;i++)
            {
                float a=(-30f+240f*i/steps)*Mathf.PI/180f,b=(-30f+240f*(i+1)/steps)*Mathf.PI/180f;
                float ax=Mathf.Cos(a),ay=Mathf.Sin(a),bx=Mathf.Cos(b),by=Mathf.Sin(b);
                var na=new Vector3(ax,ay,0);var nb=new Vector3(bx,by,0);var ia=new Vector3(-ax,-ay,0);var ib=new Vector3(-bx,-by,0);
                var oab=new Vector3(ax*GuardOuter,ay*GuardOuter,GuardBack);var obb=new Vector3(bx*GuardOuter,by*GuardOuter,GuardBack);
                var oaf=new Vector3(oab.x,oab.y,GuardFront);var obf=new Vector3(obb.x,obb.y,GuardFront);
                var iab=new Vector3(ax*GuardInner,ay*GuardInner,GuardBack);var ibb=new Vector3(bx*GuardInner,by*GuardInner,GuardBack);
                var iaf=new Vector3(iab.x,iab.y,GuardFront);var ibf=new Vector3(ibb.x,ibb.y,GuardFront);
                quad(oab,obb,obf,oaf,na,nb,nb,na);quad(iab,ibb,ibf,iaf,ia,ib,ib,ia);
                quad(iaf,oaf,obf,ibf,forward,forward,forward,forward);quad(iab,oab,obb,ibb,back,back,back,back);
                if(i==0){var n=new Vector3(ay,-ax,0);quad(iab,oab,oaf,iaf,n,n,n,n);}
                if(i==steps-1){var n=new Vector3(-by,bx,0);quad(ibb,obb,obf,ibf,n,n,n,n);}
            }
            var mesh=new Mesh{name="TOTAL STOP yellow protective hood"};mesh.SetVertices(vertices);mesh.SetNormals(normals);mesh.SetTriangles(triangles,0);mesh.RecalculateBounds();return mesh;
        }
    }
}
