namespace ModularSwitchboards
{
    internal static class SwitchboardNames
    {
        internal const string SmartCoreTitle="DIN Smart Core Module";
        internal const string DoorKitTitle="Kit (Switchboard Door Modules)";
        internal static string LabelTitle(int width)=>"Switchboard Label";
        internal static string Default(string prefab)
        {
            if(prefab==DinStationBattery.SmallName)return "DIN Station Battery";
            if(prefab==DinStationBattery.LargeName)return "DIN Station Battery (Large)";
            if(prefab==SmartContactor.PrefabNameId)return "DIN Smart Output Module";
            if(prefab==DinTransformer.MediumPrefabNameId)return "DIN Transformer (Medium)";
            if(prefab==DinTransformer.PrefabNameId)return "DIN Transformer (Small)";
            if(prefab==DinContactorModel.NcPrefabName)return "DIN Contactor (NC)";
            if(prefab==DinContactorModel.PrefabName)return "DIN Contactor";
            if(prefab==SmartOutputModel.PrefabName)return "DIN Smart Net Module";
            if(prefab=="StructureDinSmartModule")return SmartCoreTitle;
            if(prefab==SwitchboardsMod.DoorKitName)return DoorKitTitle;
            if(prefab==SwitchboardsMod.CoverKitName)return "Kit (Switchboard Cover)";
            if(prefab==SwitchboardsMod.RailKitName)return "Kit (Switchboard Rails)";
            if(prefab==SwitchboardsMod.SmartKitName)return "Kit (DIN Smart Modules)";
            if(prefab==SwitchboardsMod.BreakerKitName)return "Kit (Switchboard Modules)";
            if(prefab==SwitchboardsMod.CoverName)return "Switchboard Cover";
            if(prefab==SwitchboardsMod.RailName)return "Switchboard Rail";
            return null;
        }
        internal static string Migrate(string prefab,string saved)
        {
            if(prefab=="StructureDinSmartModule"&&(saved=="Smart Module"||saved=="DIN Smart Module"||saved=="Smart Core Module"))return Default(prefab);
            if(prefab==SmartOutputModel.PrefabName&&(saved=="Smart Output Module"||saved=="Smart Net Module"))return Default(prefab);
            if(prefab==DinTransformer.PrefabNameId&&saved=="DIN Transformer")return Default(prefab);
            if(prefab==SmartContactor.PrefabNameId&&saved=="DIN Smart Contactor")return Default(prefab);
            foreach(int width in new[]{1,2,3,4,6})if(prefab=="StructureSwitchboardLabel"+width&&(saved=="Switchboard Label ("+width+" module"+(width==1?"":"s")+")"||saved=="Switchboard Label "+width+" module"+(width==1?"":"s")))return LabelTitle(width);
            bool old=(prefab==SwitchboardsMod.DoorKitName&&saved=="Switchboards Doors Module")||
                (prefab==SwitchboardsMod.CoverKitName&&saved=="Kit (Inner Cover)")||
                (prefab==SwitchboardsMod.RailKitName&&saved=="Kit (DIN Rail)")||
                (prefab==SwitchboardsMod.BreakerKitName&&(saved=="Kit (DIN Modules)"||saved=="Kit (DIN Breaker)"||saved=="Kit (DIN Breaker 1P)"))||
                (prefab==SwitchboardsMod.CoverName&&saved=="Switchboard Inner Cover")||
                (prefab==SwitchboardsMod.RailName&&saved=="DIN Rail");
            return old?Default(prefab):saved;
        }
    }
}
