using System.Collections.Generic;using System.Linq;
namespace ModularSwitchboards {
 internal static class SmartDoorDisplayCircuit {
  internal static long Target(long output,IEnumerable<CabinetWireSaveData> wires,IEnumerable<long> bridges,IEnumerable<long> displays,IEnumerable<long> outputs) {
   var physical=wires.ToArray();if(!Valid(physical,bridges,displays,outputs))return 0;
   var graph=WireCircuit.Through(wires.Where(w=>!w.Burnt),bridges).ToArray();
   var found=displays.Where(d=>WireCircuit.Reachable(new CabinetWireEnd(output,1),new CabinetWireEnd(d,0),graph,new long[0])).ToArray();
   if(found.Length!=1)return 0;
   return outputs.Count(o=>WireCircuit.Reachable(new CabinetWireEnd(o,1),new CabinetWireEnd(found[0],0),graph,new long[0]))==1?found[0]:0;
  }
  // A display signal uses a dedicated bridge, never a power feeder or coil branch.
  internal static bool Valid(IEnumerable<CabinetWireSaveData> wires,IEnumerable<long> bridges,IEnumerable<long> displays,IEnumerable<long> outputs) {
   var bs=new HashSet<long>(bridges);var ds=new HashSet<long>(displays);var os=new HashSet<long>(outputs);
   var physical=wires.Where(w=>!w.Burnt).ToArray();
   foreach(var w in physical)foreach(var end in new[]{w.From,w.To}){
    var other=end.Equals(w.From)?w.To:w.From;
    if(ds.Contains(end.Owner)&&(end.Contact!=0||!bs.Contains(other.Owner)||other.Contact!=3))return false;
    if(os.Contains(end.Owner)&&bs.Contains(other.Owner)&&(end.Contact!=1||other.Contact!=2))return false;
   }
   var edges=WireCircuit.Through(physical,bs).ToArray();var parent=new Dictionary<CabinetWireEnd,CabinetWireEnd>();
   System.Func<CabinetWireEnd,CabinetWireEnd> root=null;root=e=>{if(!parent.TryGetValue(e,out var p))return parent[e]=e;return p.Equals(e)?p:parent[e]=root(p);};
   foreach(var w in edges){var a=root(w.From);var b=root(w.To);if(!a.Equals(b))parent[a]=b;}
   var ends=parent.Keys.ToArray();
   foreach(var group in ends.GroupBy(root)) {
    var pins=group.ToArray();bool signal=pins.Any(e=>ds.Contains(e.Owner))||pins.Any(e=>os.Contains(e.Owner))&&pins.Any(e=>bs.Contains(e.Owner));
    if(!signal)continue;
    if(pins.Where(e=>os.Contains(e.Owner)).Select(e=>e.Owner).Distinct().Count()>1||pins.Where(e=>ds.Contains(e.Owner)).Select(e=>e.Owner).Distinct().Count()>1)return false;
    if(pins.Any(e=>!(bs.Contains(e.Owner)&&(e.Contact==2||e.Contact==3)||os.Contains(e.Owner)&&e.Contact==1||ds.Contains(e.Owner)&&e.Contact==0)))return false;
   }
   return true;
  }
 }
}
