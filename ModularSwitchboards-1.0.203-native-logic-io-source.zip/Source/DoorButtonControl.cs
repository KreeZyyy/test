using Assets.Scripts.Objects;
using Assets.Scripts.Networking;
namespace ModularSwitchboards
{
    // LogicButton.WaitThenStop in the installed game waits 550 ms.
    internal sealed class DoorButtonPulse
    {
        internal const float Seconds=.55f;
        private float remaining;
        private bool armed;
        internal void Set(bool on){if(!on){armed=false;remaining=0;}else if(!armed){armed=true;remaining=Seconds;}}
        internal bool Tick(bool on,float delta)
        {
            Set(on);if(!armed||float.IsNaN(delta)||float.IsInfinity(delta)||delta<=0)return false;
            remaining-=delta;return remaining<=0;
        }
    }
    internal static class DoorButtonControl
    {
        internal const string ActionName="Press";
        internal static bool CanUse(DinBreaker owner)=>owner!=null&&!owner.IsCursor&&!owner.IsBeingDestroyed&&owner.IsStructureCompleted&&owner.Board?.PrimaryHost is SwitchboardCabinet host&&host.IsStructureCompleted;
        internal static Thing.DelayedActionInstance Interact(DinBreaker owner,Interactable control,bool doAction)
        {
            var result=new Thing.DelayedActionInstance{Duration=0,ActionMessage=ActionName};
            if(!CanUse(owner))return result.Fail("Install the button on a completed door first.");
            if(owner.OnOff)return result.Fail("Button already pressed.");
            if(doAction)OnServer.Interact(control,1);
            return result.Succeed();
        }
    }
}
