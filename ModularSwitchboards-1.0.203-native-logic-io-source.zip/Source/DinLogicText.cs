using System;using System.Collections.Generic;using UnityEngine;
namespace ModularSwitchboards {
 // Same actual font, weight, depth-tested ink and orientation as Smart NET/Output.
 internal static class DinLogicText {
  private static readonly Dictionary<Font,Material> inks=new Dictionary<Font,Material>();
  private static readonly Dictionary<Font,Material> darkInks=new Dictionary<Font,Material>();
  private static Material Ink(Font font,Color color){var palette=color==Color.black?darkInks:inks;if(!palette.TryGetValue(font,out var m)){m=new Material(DepthLabelText.For(font)){name="Switchboards.Logic.SmartFontInk",color=Color.white};palette[font]=m;Font.textureRebuilt+=f=>{if(inks.TryGetValue(f,out var ink))ink.mainTexture=f.material.mainTexture;if(darkInks.TryGetValue(f,out var dark))dark.mainTexture=f.material.mainTexture;};}m.mainTexture=font.material.mainTexture;m.color=color;m.EnableKeyword("_EMISSION");m.SetColor("_EmissionColor",color==Color.black?Color.black:new Color(.65f,.7f,.65f));return m;}

  internal static void Install(Transform owner,string native){var font=SmartModuleFont.Get();if(font==null)throw new InvalidOperationException("Smart module font unavailable");
   var name=native.Substring("StructureLogic".Length);name=name.Replace("BatchSlot","Batch Slot").Replace("BatchReader","Batch\nReader").Replace("BatchWriter","Batch\nWriter").Replace("SlotReader","Slot\nReader").Replace("ReagentReader","Reagent\nReader");if(name=="Reader"||name=="Writer"||name=="Mirror")name="Logic\n"+name;
   Add(owner,font,name,new Vector3(DinLogicModel.Center,0,DinLogicFaceLayout.PrintZ),.052f,.019f,Color.white);
   foreach(var p in DinLogicControlLayout.For(native))if(DinLogicFaceLayout.LabelVisible(p.Action))Add(owner,font,p.Label,new Vector3(DinLogicModel.Center+p.X*DinLogicFaceLayout.ScaleX,DinLogicFaceLayout.LabelY(p.Y),DinLogicFaceLayout.PrintZ),.016f,.0044f,Color.white);
  }
  internal static void Restore(Assets.Scripts.Objects.Thing owner){foreach(var t in owner.GetComponentsInChildren<TextMesh>(true)){if(t.GetComponentInParent<Assets.Scripts.Objects.Thing>(true)!=owner)continue;var fit=t.GetComponent<DinLogicLabelFit>();if(fit==null)continue;var r=t.GetComponent<MeshRenderer>();r.SetPropertyBlock(null);for(int i=0;i<r.sharedMaterials.Length;i++)r.SetPropertyBlock(null,i);t.color=fit.InkColor;r.sharedMaterial=Ink(t.font,fit.InkColor);r.shadowCastingMode=UnityEngine.Rendering.ShadowCastingMode.Off;r.receiveShadows=false;}}
  private static void Add(Transform parent,Font font,string value,Vector3 point,float width,float height,Color color){var go=new GameObject("DinLogicPrintedText"){layer=parent.gameObject.layer};go.transform.SetParent(parent,false);go.transform.localPosition=point;go.transform.localRotation=Quaternion.Euler(0,180,0);
   var t=go.AddComponent<TextMesh>();t.font=font;t.fontSize=64;t.fontStyle=FontStyle.Bold;t.characterSize=.004f;t.anchor=TextAnchor.MiddleCenter;t.alignment=TextAlignment.Center;t.richText=false;t.color=color;t.text=value;font.RequestCharactersInTexture(value,64,FontStyle.Bold);
   var generated=t.GetComponent<MeshFilter>()?.sharedMesh;if(generated!=null)generated.RecalculateBounds();var size=generated!=null?generated.bounds.size:t.GetComponent<MeshRenderer>().localBounds.size;float scale=Mathf.Min(width/Mathf.Max(.0001f,size.x),height/Mathf.Max(.0001f,size.y));go.transform.localScale=Vector3.one*scale;DepthLabelText.Apply(t);t.GetComponent<MeshRenderer>().sharedMaterial=Ink(font,color);var fit=go.AddComponent<DinLogicLabelFit>();fit.Width=width;fit.Height=height;fit.InkColor=color;fit.Refresh();
  }
 }
}

namespace ModularSwitchboards {
 public sealed class DinLogicLabelFit:MonoBehaviour {
  public float Width,Height;public Color InkColor=Color.white;
  internal void Refresh(){var t=GetComponent<TextMesh>();if(t==null)return;var r=t.GetComponent<MeshRenderer>();var size=r.localBounds.size;if(size.x<=.00001f||size.y<=.00001f){transform.localScale=Vector3.one;return;}float s=Mathf.Min(Width/size.x,Height/size.y);transform.localScale=Vector3.one*s;}
  private void LateUpdate()=>Refresh();
 }
}
