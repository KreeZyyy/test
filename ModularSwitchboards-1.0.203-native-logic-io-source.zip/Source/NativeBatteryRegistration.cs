using System;
using System.Collections.Generic;
using System.Linq;
using Assets.Scripts.Objects;
namespace ModularSwitchboards
{
    internal static class NativeBatteryRegistration
    {
        // Prefab registration clones serialized data, not Thing's private
        // _interactableOnOff cache. Never treat an unawakened cache as data loss.
        internal static string Failure(DinStationBattery battery,int expectedWidth,string mountKit)
        {
            if(battery==null)return "prefab missing";
            var reasons=new List<string>();
            if(battery.ModuleWidth!=expectedWidth)reasons.Add("width="+battery.ModuleWidth+", expected="+expectedWidth);
            if(battery.PowerMaximum<=0||float.IsNaN(battery.PowerMaximum)||float.IsInfinity(battery.PowerMaximum))reasons.Add("invalid capacity="+battery.PowerMaximum);
            var states=battery.BuildStates;
            bool onOff=battery.Interactables?.Any(c=>c!=null&&c.Action==InteractableType.OnOff)==true||states?.Any(s=>s?.Interactables?.Any(c=>c!=null&&c.Action==InteractableType.OnOff)==true)==true;
            if(!onOff)reasons.Add("serialized ON/OFF control missing");
            if(states==null||states.Count<2)reasons.Add("native construction stages missing");
            var mount=states?.FirstOrDefault()?.Tool;
            if(mount?.ToolEntry?.PrefabName!=mountKit||mount.EntryQuantity!=1)reasons.Add("mount kit="+(mount?.ToolEntry?.PrefabName??"missing")+", expected="+mountKit+" x1");
            return reasons.Count==0?null:string.Join("; ",reasons);
        }
    }
}
