using Assets.Scripts.Objects.Items;
namespace ModularSwitchboards
{
    // Immutable-by-convention snapshot of Unity state, read by the power bridge.
    internal sealed class CabinetPowerNode
    {
        internal CabinetPowerNode Disabled(){var copy=(CabinetPowerNode)MemberwiseClone();copy.Conducting=false;return copy;}
        internal long ReferenceId;
        internal bool Conducting,IsContactor,HasNormallyClosedContact,IsBatteryModule,IsAnalyserModule,IsDoorPart,IsDoorBridge,IsBeingDestroyed,IsTransformer,ServiceEnabled;
        internal float RatedWatts,TransferLimit,OwnWatts;
        internal BatteryCell Battery;
        internal BatteryEnergyStore Store;
        internal BatteryEnergyStore Energy=>Store??BatteryEnergyStore.Cell(Battery);
        internal bool IsServiceLoad;
        internal long ServiceOwner,ServiceDependency;
        internal int ServiceContact;
        internal CabinetWireEnd ServiceTap=>new CabinetWireEnd(ServiceOwner==0?ReferenceId:ServiceOwner,ServiceContact);
        internal static CabinetPowerNode From(DinBreaker m)=>new CabinetPowerNode{ReferenceId=m.ReferenceId,Conducting=m.Conducting,IsContactor=m.IsContactor,HasNormallyClosedContact=m.HasNormallyClosedContact,IsBatteryModule=m.IsBatteryModule,IsAnalyserModule=m.IsAnalyserModule,IsDoorPart=m.IsDoorPart,IsDoorBridge=m.IsDoorBridge,IsBeingDestroyed=m.IsBeingDestroyed,RatedWatts=m.RatedWatts,Battery=m.Battery};
    }
}
