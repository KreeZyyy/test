using Assets.Scripts.Objects;using Assets.Scripts.Objects.Motherboards;
namespace ModularSwitchboards {
 internal static class DinLogicPaint {
  internal static void Mark(ThingSaveData data){if(data is IDinLogicPaintSave paint)paint.BodyPaintVersion=1;}
  internal static void Migrate(ThingSaveData data){if(data is IDinLogicPaintSave paint&&paint.BodyPaintVersion<1)data.CustomColorIndex=(int)ColorType.White;}
 }
}
