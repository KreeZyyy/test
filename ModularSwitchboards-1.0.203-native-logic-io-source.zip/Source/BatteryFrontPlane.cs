using System;using UnityEngine;
namespace ModularSwitchboards {
 internal static class BatteryFrontPlane {
 internal static Vector3 Normal(Vector3[] points,int[][] groups){foreach(var ids in groups)for(int i=0;i<ids.Length;i+=3){var a=points[ids[i+1]]-points[ids[i]];var b=points[ids[i+2]]-points[ids[i]];var n=new Vector3(a.y*b.z-a.z*b.y,a.z*b.x-a.x*b.z,a.x*b.y-a.y*b.x);float length=(float)Math.Sqrt(Dot(n,n));if(length>1e-8f)return n*(1/length);}throw new ArgumentException("Native meter front has no face.");}
 internal static float Dot(Vector3 a,Vector3 b)=>a.x*b.x+a.y*b.y+a.z*b.z;
 internal static int[][] Select(Vector3[] points,int[][] groups,Vector3 normal,float distance){var result=new int[groups.Length][];for(int g=0;g<groups.Length;g++){var keep=new System.Collections.Generic.List<int>();var ids=groups[g];for(int i=0;i<ids.Length;i+=3)if(Math.Abs(Dot(points[ids[i]],normal)-distance)<.0001f&&Math.Abs(Dot(points[ids[i+1]],normal)-distance)<.0001f&&Math.Abs(Dot(points[ids[i+2]],normal)-distance)<.0001f){keep.Add(ids[i]);keep.Add(ids[i+1]);keep.Add(ids[i+2]);}result[g]=keep.ToArray();}return result;}
 }
}
