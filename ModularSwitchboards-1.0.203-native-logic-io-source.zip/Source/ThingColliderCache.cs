using System.Collections.Generic;using Assets.Scripts.Objects;using UnityEngine;
namespace ModularSwitchboards {
 internal static class ThingColliderCache {
  // Thing.Awake appends all live hierarchy colliders. Prefab caches must not be inherited by a cursor/instance.
  internal static void Reset(Thing owner){owner._staticColliders=new List<Collider>();owner._dynamicColliders=new List<Collider>();owner._selfColliders=new List<Collider>();}
  internal static void Forget(Structure owner,Collider removed){owner._staticColliders?.Remove(removed);owner._dynamicColliders?.Remove(removed);owner._selfColliders?.Remove(removed);foreach(var stage in owner.BuildStates)stage.Colliders?.Remove(removed);Thing._colliderLookup.Remove(removed);}
 }
}
