using System;
namespace ModularSwitchboards
{
    // A new powered session must clear old commands before exposing the bus.
    internal sealed class SmartOutputSession
    {
        internal bool Ready{get;private set;}
        private bool initialized;
        internal void Refresh(bool active,Action reset)
        {
            if(initialized&&active==Ready)return;
            Ready=false;
            reset();
            initialized=true;Ready=active;
        }
    }
}
