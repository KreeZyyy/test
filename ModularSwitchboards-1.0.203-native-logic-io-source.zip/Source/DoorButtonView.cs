using UnityEngine;
namespace ModularSwitchboards
{
    public sealed class DoorButtonView:MonoBehaviour
    {
        public DinBreaker Owner;
        public Transform Button;
        private void Bind(){Owner=GetComponent<DinBreaker>();Button=transform.Find("DoorPushButton");}
        private void Awake(){Bind();}
        private void OnEnable(){Bind();}
        private void LateUpdate()
        {
            if(Owner==null||Owner.gameObject!=gameObject||Button==null||Button.parent!=transform)Bind();
            if(Owner==null||Button==null)return;
            var p=Button.localPosition;
            p.z=Mathf.MoveTowards(p.z,Owner.OnOff?-.002f:0,.05f*Mathf.Max(0,Time.deltaTime));
            Button.localPosition=p;
        }
    }
}
