using System;using System.Linq;using System.Collections.Generic;using UnityEngine;
namespace ModularSwitchboards {
 internal static class DoorDisplayOpening {
  private static float Cross(Vector3 a,Vector3 b,Vector3 c)=>(b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x);
  private static float Area(IList<Vector3> p){float a=0;for(int i=0;i<p.Count;i++){var b=p[(i+1)%p.Count];a+=p[i].x*b.y-b.x*p[i].y;}return a*.5f;}
  internal static Vector3[] Visible(Vector3[] vertices,int[][] groups,Vector3[] screen){
   var used=groups.SelectMany(g=>g).Distinct().ToArray();if(used.Length==0)return screen;float front=used.Max(i=>vertices[i].z);
   var points=new List<Vector3>();var keys=new Dictionary<Tuple<long,long>,int>();var edges=new Dictionary<Tuple<int,int>,int>();
   Func<Vector3,int> point=p=>{var k=Tuple.Create((long)Math.Round(p.x*1e7),(long)Math.Round(p.y*1e7));if(!keys.TryGetValue(k,out int id)){keys[k]=id=points.Count;points.Add(new Vector3(p.x,p.y,0));}return id;};
   foreach(var group in groups)for(int i=0;i<group.Length;i+=3){var a=vertices[group[i]];var b=vertices[group[i+1]];var c=vertices[group[i+2]];if(Math.Abs(a.z-front)>.000002f||Math.Abs(b.z-front)>.000002f||Math.Abs(c.z-front)>.000002f||Cross(a,b,c)<=1e-12)continue;var ids=new[]{point(a),point(b),point(c)};for(int j=0;j<3;j++){int x=ids[j],y=ids[(j+1)%3];var key=Tuple.Create(Math.Min(x,y),Math.Max(x,y));edges.TryGetValue(key,out int n);edges[key]=n+1;}}
   var adjacent=new Dictionary<int,List<int>>();foreach(var e in edges.Where(e=>e.Value==1)){int a=e.Key.Item1,b=e.Key.Item2;if(!adjacent.TryGetValue(a,out var aa))adjacent[a]=aa=new List<int>();if(!adjacent.TryGetValue(b,out var bb))adjacent[b]=bb=new List<int>();aa.Add(b);bb.Add(a);}
   if(adjacent.Count==0||adjacent.Values.Any(v=>v.Count!=2))return screen;
   var visited=new HashSet<int>();var loops=new List<Vector3[]>();foreach(int start in adjacent.Keys){if(visited.Contains(start))continue;int at=start,previous=-1;var loop=new List<Vector3>();do{visited.Add(at);loop.Add(points[at]);int next=adjacent[at][0]==previous?adjacent[at][1]:adjacent[at][0];previous=at;at=next;}while(at!=start&&loop.Count<=adjacent.Count);if(at!=start)return screen;loops.Add(loop.ToArray());}
   if(loops.Count<2)return screen;var hole=loops.OrderBy(l=>Math.Abs(Area(l))).First();if(Area(hole)<0)Array.Reverse(hole);
   return Clip(screen,hole);
  }
  internal static Vector3[] Clip(Vector3[] screen,Vector3[] hole){
   var result=screen.ToList();for(int i=0;i<hole.Length&&result.Count>0;i++){var a=hole[i];var b=hole[(i+1)%hole.Length];var input=result;result=new List<Vector3>();var previous=input[input.Count-1];float pv=Cross(a,b,previous);foreach(var current in input){float cv=Cross(a,b,current);bool pi=pv>=-1e-10f,ci=cv>=-1e-10f;if(pi!=ci){float t=pv/(pv-cv);result.Add(previous+(current-previous)*t);}if(ci)result.Add(current);previous=current;pv=cv;}}
   var unique=result.GroupBy(p=>Tuple.Create(Math.Round(p.x,7),Math.Round(p.y,7))).Select(g=>g.First()).ToArray();return unique.Length>=3?unique:screen;
  }
 }
}
