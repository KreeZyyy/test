using System;using System.Linq;using UnityEngine;
namespace ModularSwitchboards {
 internal static class SmartModuleFont {
  internal static Font Get(){Font font=null;foreach(var name in new[]{"LegacyRuntime.ttf","Arial.ttf"}){try{font=Resources.GetBuiltinResource<Font>(name);}catch(Exception){}if(font!=null)break;}return font??Resources.FindObjectsOfTypeAll<Font>().FirstOrDefault();}
 }
}
