using System;
namespace ModularSwitchboards
{
    internal static class CabinetWallClearance
    {
        // Native wall skins can lie entirely on one side of the mounting grid.
        // Mirror their outer mounting envelope instead of pulling a back-mounted
        // cabinet into the supporting wall/frame to reach the thin rear skin.
        internal static bool TryFace(float rear,float front,float gridStep,bool positive,out float face)
        {
            face=0;
            if(!Finite(rear)||!Finite(front)||!Finite(gridStep)||gridStep<=0||front<rear)return false;
            double centre=((double)rear+front)*.5;
            double plane=Math.Round(centre/gridStep,MidpointRounding.ToEven)*gridStep;
            double depth=Math.Max(0,Math.Max(front-plane,plane-rear));
            double result=plane+(positive?depth:-depth);
            if(double.IsNaN(result)||double.IsInfinity(result)||result>float.MaxValue||result< -float.MaxValue)return false;
            face=(float)result;return true;
        }
        private static bool Finite(float value)=>!float.IsNaN(value)&&!float.IsInfinity(value);
    }
}
