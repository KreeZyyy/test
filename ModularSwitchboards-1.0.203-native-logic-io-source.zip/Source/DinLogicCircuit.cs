using System;using System.Collections.Generic;using System.Linq;
namespace ModularSwitchboards {
 internal static class DinLogicCircuit {
  internal static bool Data(CabinetWireEnd e,IEnumerable<long> ids)=>e!=null&&e.Owner!=0&&(e.Contact==0||e.Contact==1)&&ids.Contains(e.Owner);
  internal static bool External(CabinetWireEnd e)=>e!=null&&e.Owner==0&&e.Contact>=1&&e.Contact<=3;
  internal static bool Allowed(CabinetWireEnd a,CabinetWireEnd b,IEnumerable<long> ids)=>a!=null&&b!=null&&!a.Equals(b)&&(Data(a,ids)&&(Data(b,ids)||External(b))||Data(b,ids)&&External(a));
  internal static CabinetWireEnd[] Component(CabinetWireEnd start,IEnumerable<CabinetWireSaveData> wires){var visited=new HashSet<CabinetWireEnd>{start};var q=new Queue<CabinetWireEnd>();q.Enqueue(start);var all=wires.Where(w=>w.LogicData&&!w.Burnt).ToArray();while(q.Count>0){var p=q.Dequeue();foreach(var w in all){var next=w.From.Equals(p)?w.To:w.To.Equals(p)?w.From:null;if(next!=null&&visited.Add(next))q.Enqueue(next);}}return visited.OrderBy(e=>e.Owner).ThenBy(e=>e.Contact).ToArray();}
 }
}
