using System;using System.Collections.Generic;using System.Linq;
using Assets.Scripts.Networks;using Assets.Scripts.Objects.Electrical;using Assets.Scripts.Objects.Pipes;using HarmonyLib;
namespace ModularSwitchboards {
 // A private data-only view. It never joins real CableNetworks, owns cables or enters power ticks/save/network sync.
 internal sealed class DinLogicDataView:CableNetwork {
  private string signature;
  // SwitchboardsMod patches AssignReference for this private subclass only. All base field initializers
  // run normally, but no native ID, hint, global pool entry or MP network announcement is allocated.
  internal DinLogicDataView(){if(ReferenceId!=0)throw new InvalidOperationException("DIN data isolation hook is missing");}
  public override void OnPowerTick(){}
  internal bool Update(IEnumerable<Device> devices){var ds=devices.Where(d=>d!=null&&!d.IsBeingDestroyed).Distinct().OrderBy(d=>d.ReferenceId).ToArray();var next=string.Join(",",ds.Select(d=>d.ReferenceId+":"+d.CustomName));if(signature==next)return false;signature=next;lock(DeviceList){DeviceList.Clear();DeviceList.AddRange(ds);}DirtyPowerAndDataDeviceLists();return true;}
  protected override void RefreshPowerAndDataDeviceLists(){lock(DeviceList){_dataDeviceList.Clear();_dataDeviceList.AddRange(DeviceList);_powerDeviceList.Clear();}DataDeviceListDirty=false;PowerDeviceListDirty=false;}
 }
 internal static class DinLogicNetwork {
  private static readonly System.Reflection.PropertyInfo DataCables=AccessTools.Property(typeof(Device),"DataCables"),PowerCables=AccessTools.Property(typeof(Device),"PowerCables"),PowerCable=AccessTools.Property(typeof(Device),"PowerCable");
  private static readonly Dictionary<LogicUnitBase,Cable[]> Bound=new Dictionary<LogicUnitBase,Cable[]>();
  internal static void Bind(LogicUnitBase m,Cable[] cables,CableNetwork input,CableNetwork output,bool changed){
   cables=cables.Where(c=>c?.CableNetwork!=null).Distinct().ToArray();
   bool same=Bound.TryGetValue(m,out var old)&&old.SequenceEqual(cables)&&cables.All(c=>c.CableNetwork.GetDeviceRegistration(m)?.Contains(c)==true);
   if(!same){Unbind(m);Bound[m]=cables;m.DataCable=cables.FirstOrDefault();DataCables.SetValue(m,cables,null);PowerCable.SetValue(m,null,null);PowerCables.SetValue(m,Array.Empty<Cable>(),null);foreach(var c in cables)c.CableNetwork.AddDevice(c,m);}
   if(m.InputNetwork1!=input||m.OutputNetwork1!=output||changed){m.InputNetwork1=input;m.OutputNetwork1=output;m.OnNetworkChange();}
  }
  internal static void Unbind(LogicUnitBase m){
   foreach(var n in m.ConnectedCableNetworks.ToArray())n?.RemoveDevice(m);Bound.Remove(m);
   m.InputNetwork1=null;m.OutputNetwork1=null;m.DataCable=null;DataCables.SetValue(m,Array.Empty<Cable>(),null);PowerCable.SetValue(m,null,null);PowerCables.SetValue(m,Array.Empty<Cable>(),null);
  }
 }
}
