using System.Collections.Generic;
using System.Linq;
using Assets.Scripts.Objects;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class NativeBatterySetup
    {
        // Stock controls can still belong to individual build stages before
        // native registration flattens them onto Thing.Interactables.
        internal static void Normalize(DinStationBattery battery)
        {
            battery.Interactables=(battery.Interactables??new List<Interactable>()).Where(c=>c!=null).Distinct().ToList();
            battery.AudioEvents=battery.AudioEvents??new List<Assets.Scripts.Sound.GameAudioEvent>();
            foreach(var state in battery.BuildStates)
            {
                state.StateMeshes=state.StateMeshes??new List<Mesh>();
                state.Colliders=state.Colliders??new List<Collider>();
                state.LinkedGameObjects=state.LinkedGameObjects??new List<GameObject>();
                state.Interactables=(state.Interactables??new List<Interactable>()).Where(c=>c!=null).Distinct().ToList();
                foreach(var control in state.Interactables.Where(c=>c!=null))
                    if(!battery.Interactables.Contains(control))battery.Interactables.Add(control);
            }
            foreach(var control in battery.Interactables.Where(c=>c!=null))
            {
                control.Parent=battery;
                control.AssociatedAudioEvents=control.AssociatedAudioEvents??new List<Assets.Scripts.Sound.GameAudioEvent>();
            }
            battery.CacheStates(true);
        }
    }
}
