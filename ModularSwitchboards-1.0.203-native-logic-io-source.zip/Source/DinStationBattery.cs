using System;
using System.Xml.Serialization;
using Assets.Scripts;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Networking;
using Assets.Scripts.Networks;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Electrical;
using Assets.Scripts.UI;
using LibConstruct;
using UnityEngine;
namespace ModularSwitchboards
{
    public sealed class DinStationBatterySaveData:BatterySaveData
    {
        [XmlElement]public PlacementBoardStructureSaveData RailBoard;
    }
    // Keep the stock Battery as the single owner of charge, controls, indicators
    // and network serialization. Only its external energy transfer is replaced.
    public sealed class DinStationBattery:Battery,IPlacementBoardStructure
    {
        internal const string SmallName="StructureDinStationBattery",LargeName="StructureDinStationBatteryLarge";
        [SerializeField]internal bool LargeVariant=false;
        [SerializeField]internal Bounds ModelBounds;
        [SerializeField]internal int NativeIndicatorCount;
        internal int ModuleWidth=>LargeVariant?6:4;
        public PlacementBoard Board{get;set;}
        public PlacementBoard.BoardCell[] BoardCells{get;set;}
        public Vector3 InternalInput,InternalOutput,InternalInputAim,InternalOutputAim;
        public SwitchboardCabinet Cabinet=>(Board?.PrimaryHost as DinRail)?.Board?.PrimaryHost as SwitchboardCabinet;
        private CabinetWiring lastWiring;
        internal CabinetWiring Wiring {get{if(Cabinet!=null)lastWiring=Cabinet.Wiring;return lastWiring;}}
        internal bool Conducting=>!IsCursor&&!IsBeingDestroyed&&IsStructureCompleted&&Board!=null&&OnOff&&!IsBroken;
        internal BatteryEnergyStore Energy=>new BatteryEnergyStore(this,()=>PowerStored,v=>PowerStored=v,()=>Math.Max(0,PowerMaximum-PowerStored),PowerMaximum);
        internal CabinetPowerNode PowerNode()=>new CabinetPowerNode{ReferenceId=ReferenceId,Conducting=Conducting,IsBatteryModule=true,Store=Energy};
        public override bool IsPowerProvider=>false;
        public override bool IsPowerInputOutput=>false;
        public override bool DoSubmergableTick=>false;
        protected override void RefreshAnimState(bool skipAnimation=false){if(!GameManager.IsBatchMode)base.RefreshAnimState(skipAnimation);}
        public override float GetGeneratedPower(CableNetwork network)=>0;
        public override float GetUsedPower(CableNetwork network)=>0;
        public override void UsePower(CableNetwork network,float amount){}
        public override void ReceivePower(CableNetwork network,float amount){}
        public override bool AllowSetPower(CableNetwork network)=>false;
        protected override void CheckConnections(){}
        public override void OnAddCableNetwork(CableNetwork network){}
        public override void OnRemoveCableNetwork(CableNetwork network){}
        public override void OnAtmosphericTick(){if(!IsCursor&&!IsBeingDestroyed&&IsStructureCompleted&&Board!=null&&GridController!=null)base.OnAtmosphericTick();}
        public override void Awake(){CacheStates(true);PrefabAudioOwner.PrepareInstance(this);base.Awake();BoardStructureHooks.Awake(this);}
        public override void OnRegistered(Cell cell){CacheStates(true);base.OnRegistered(cell);}
        public override Grid3 GetLocalGrid()=>Board==null?default(Grid3):Board.WorldToGrid(transform.position);
        public override CanConstructInfo CanConstruct()
        {
            if(IsCursor){MountPlacement.AfterRaycast();MountBoardResolver.Resolve(CursorManager.Instance);}
            if(!(Board is DinModuleBoard board)||!(board.PrimaryHost is DinRail rail))return CanConstructInfo.InvalidPlacement("Choose free DIN positions inside an open cabinet.");
            var p=board.WorldToGrid(transform.position);
            if(IsCursor)
            {
                if(MountPlacement.TryLockedGrid(this,board,out var locked))p=locked;
                else p=new Grid3(DoorModuleLayout.SnapSlot(p.x,DinLayout.FirstModuleSlot*10,(DinLayout.FirstModuleSlot+rail.ModuleCapacity-ModuleWidth)*10),0,0);
                PlacementBoard.CursorGrid=p;PlacementBoard.CursorRotation=0;transform.SetPositionAndRotation(board.GridToWorld(p),board.IndexToRotation(0));
            }
            return board.CanPlace(p,board.RotationToIndex(transform.rotation),ModuleWidth)?CanConstructInfo.ValidPlacement:CanConstructInfo.InvalidPlacement("The full battery footprint must be free.");
        }
        protected override CanConstructInfo CanDeconstruct()=>Cabinet?.CanAccessModules!=true?CanConstructInfo.InvalidPlacement("Open the cabinet and remove its cover first."):Wiring?.CanRefundBreaker(ReferenceId)==false?CanConstructInfo.InvalidPlacement("Cable coil prefab unavailable."):CanConstructInfo.ValidPlacement;
        public override DelayedActionInstance AttackWith(Attack attack,bool doAction=true)
        {
            if(Cabinet?.CanAccessModules!=true)return null;
            if(IsStructureCompleted&&Wiring!=null&&Wiring.TryAttack(attack,doAction,out var action))return action;
            return base.AttackWith(attack,doAction);
        }
        public override bool PreventInteraction(out DelayedActionInstance fail,Interactable control,Interaction interaction)
        {
            if(IsCursor||IsBeingDestroyed||Cabinet?.CanAccessModules!=true){fail=new DelayedActionInstance{Duration=0}.Fail("Open the cabinet and remove its cover first.");return true;}
            return base.PreventInteraction(out fail,control,interaction);
        }
        public override DelayedActionInstance InteractWith(Interactable control,Interaction interaction,bool doAction=true)
        {
            if(IsCursor||IsBeingDestroyed||Cabinet?.CanAccessModules!=true)return new DelayedActionInstance{Duration=0}.Fail("Open the cabinet and remove its cover first.");
            return base.InteractWith(control,interaction,doAction);
        }

        public override PassiveTooltip GetPassiveTooltip(Collider hit)
        {
            var tip=new PassiveTooltip(toDefault:true);tip.Title=DisplayName;tip.Extended=(PowerStored/1000000f).ToString("0.###")+" / "+(PowerMaximum/1000000f).ToString("0.###")+" MJ ("+(PowerRatio*100).ToString("0")+"%) — "+(OnOff?"ON":"OFF");return tip;
        }
        private float next;
        private void LateUpdate()
        {
            if(IsCursor)return;
            DinBreakerModel.Refresh(this);
            if(Time.unscaledTime>=next){next=Time.unscaledTime+.15f;DinStationBatteryNetwork.Refresh(this);}
        }
        public override void OnDeregistered(){Wiring?.RemoveBreaker(ReferenceId);DinStationBatteryNetwork.Unbind(this);base.OnDeregistered();if(Board!=null)BoardStructureHooks.OnDeregistered(this);}
        public override void OnDestroy(){DinStationBatteryNetwork.Unbind(this);base.OnDestroy();}
        public override ThingSaveData SerializeSave(){ThingSaveData data=new DinStationBatterySaveData();InitialiseSaveData(ref data);return data;}
        protected override void InitialiseSaveData(ref ThingSaveData data){base.InitialiseSaveData(ref data);if(data is DinStationBatterySaveData save&&Board!=null)save.RailBoard=BoardStructureHooks.SerializeSave(this);}
        public override void DeserializeSave(ThingSaveData data){base.DeserializeSave(data);if(data is DinStationBatterySaveData save&&save.RailBoard!=null)BoardStructureHooks.DeserializeSave(this,save.RailBoard);}
        public override void SerializeOnJoin(RocketBinaryWriter writer){base.SerializeOnJoin(writer);BoardStructureHooks.SerializeOnJoin(writer,this);}
        public override void DeserializeOnJoin(RocketBinaryReader reader){base.DeserializeOnJoin(reader);var mount=new PlacementBoardStructureSaveData{BoardId=reader.ReadInt64(),PrimaryHostId=reader.ReadInt64(),Position=reader.ReadGrid3(),Rotation=reader.ReadSByte()};BoardStructureHooks.DeserializeSave(this,mount);}
    }
}
