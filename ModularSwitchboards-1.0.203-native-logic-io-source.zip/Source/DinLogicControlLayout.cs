using System;
namespace ModularSwitchboards {
 // Authored DIN control layout. Reference measurements rounded to whole millimetres; no imported mesh or collider data.
 internal sealed class DinLogicControlPose {internal int Action;internal string Label;internal float X,Y;internal DinLogicControlPose(int action,string label,float x,float y){Action=action;Label=label;X=x;Y=y;}}
 internal static class DinLogicControlLayout {
 internal static DinLogicControlPose[] For(string native){switch(native){
case "StructureLogicBatchReader":return new[]{new DinLogicControlPose(36,"ON",0.022f,0.024f),new DinLogicControlPose(31,"MODE",-0.023f,0.024f),new DinLogicControlPose(32,"VAR",-0.023f,-0.024f),new DinLogicControlPose(33,"TYPE",0.023f,-0.024f)};
case "StructureLogicBatchSlotReader":return new[]{new DinLogicControlPose(36,"ON",0.022f,0.024f),new DinLogicControlPose(31,"TYPE",0.023f,-0.024f),new DinLogicControlPose(32,"SLOT",0.000f,-0.024f),new DinLogicControlPose(33,"VAR",-0.023f,-0.024f),new DinLogicControlPose(34,"MODE",-0.023f,0.024f)};
case "StructureLogicBatchWriter":return new[]{new DinLogicControlPose(36,"ON",0.022f,0.024f),new DinLogicControlPose(31,"TYPE",-0.023f,0.024f),new DinLogicControlPose(32,"VAR",-0.023f,-0.024f),new DinLogicControlPose(33,"IN",0.023f,-0.024f)};
case "StructureLogicMirror":return new[]{new DinLogicControlPose(36,"ON",0.022f,0.024f),new DinLogicControlPose(31,"IN",0.000f,-0.024f)};
case "StructureLogicReader":return new[]{new DinLogicControlPose(36,"ON",0.022f,0.024f),new DinLogicControlPose(31,"IN",0.022f,-0.024f),new DinLogicControlPose(32,"VAR",-0.023f,-0.024f)};
case "StructureLogicReagentReader":return new[]{new DinLogicControlPose(36,"ON",0.022f,0.024f),new DinLogicControlPose(31,"IN",0.023f,-0.024f),new DinLogicControlPose(32,"MODE",0.000f,-0.024f),new DinLogicControlPose(33,"REAG",-0.023f,-0.024f)};
case "StructureLogicSlotReader":return new[]{new DinLogicControlPose(36,"ON",0.022f,0.024f),new DinLogicControlPose(31,"IN",0.023f,-0.024f),new DinLogicControlPose(32,"SLOT",0.000f,-0.024f),new DinLogicControlPose(33,"VAR",-0.023f,-0.024f)};
case "StructureLogicWriter":return new[]{new DinLogicControlPose(36,"ON",0.022f,0.024f),new DinLogicControlPose(31,"OUT",-0.023f,0.024f),new DinLogicControlPose(32,"VAR",-0.023f,-0.024f),new DinLogicControlPose(33,"IN",0.023f,-0.024f)};
default:throw new ArgumentException("Unknown DIN Logic variant: "+native);}}
 }
}
