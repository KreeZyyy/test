using System;
namespace ModularSwitchboards
{
    internal static class BatterySwitchMount
    {
        // Cardinal side-plane selection is independent of the animated paddle.
        internal static int Axis(float x,float z)=>Math.Abs(x)>=Math.Abs(z)?0:2;
        internal static float Sign(float x,float z)=> (Axis(x,z)==0?x:z)>=0?1f:-1f;
        internal static float Seat(float surface,float bezelBack,float scale)=>surface-bezelBack*scale;
    }
}
