[assembly:System.Reflection.AssemblyVersion("0.2.9.0")]
[assembly:System.Reflection.AssemblyFileVersion("0.2.9.0")]
[assembly:System.Runtime.Versioning.TargetFramework(".NETFramework,Version=v4.7.2")]
