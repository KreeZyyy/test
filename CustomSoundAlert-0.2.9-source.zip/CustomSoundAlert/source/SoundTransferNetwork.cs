using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using Assets.Scripts;
using Assets.Scripts.Util;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Networking;
using HarmonyLib;
using LaunchPadBooster;
using LaunchPadBooster.Networking;
using UnityEngine;
using Assets.Scripts.UI;
using ImGuiNET;
namespace CustomSoundAlert
{
    internal static class SoundTransferNetwork
    {
        static readonly object gate=new object();
        static readonly Dictionary<long,SoundRequest> requests=new Dictionary<long,SoundRequest>();
        static readonly Queue<long> order=new Queue<long>();
        static readonly Queue<SoundResponse> incoming=new Queue<SoundResponse>();
        static readonly Dictionary<long,double> nextAllowed=new Dictionary<long,double>();
        static readonly FieldInfo hostField=AccessTools.Field(typeof(NetworkManager),"_hostId");
        static SoundFileServer server;
        static SoundDownload download;
        static Action<string> log;
        static long host;
        static double lastTick,tokens=SoundDownload.ChunkSize*4,nextLog,visibleUntil,nextCleanup;
        static readonly List<long> disconnected=new List<long>();
        static string status;
        static bool audioReady,panelReported;
        internal static void Trace(string message){log?.Invoke(message);}
        internal static bool Ready=>download!=null&&download.Ready;
        internal static bool Verified(SoundEntry entry)=>download!=null&&download.IsVerified(entry);
        internal static void Configure(Mod mod,string folder,SoundEntry[] catalog,Action<string> logger)
        {
            log=logger;server=new SoundFileServer(folder,catalog);
            mod.Networking.RegisterMessage<SoundRequestMessage>();mod.Networking.RegisterMessage<SoundResponseMessage>();
            log?.Invoke("Chunked sound transfer registered (8 KiB chunks; global server limit 256 KiB/s; one pending request per client).");
        }
        internal static void Begin(string cache,SoundEntry[] catalog)
        {
            Cancel();host=(long)hostField.GetValue(null);
            download=new SoundDownload(cache,catalog,request=>new SoundRequestMessage{Request=request}.SendToHost(),Show);
        }
        internal static void Cancel()
        {
            download?.Dispose();download=null;
            lock(gate){incoming.Clear();requests.Clear();order.Clear();nextAllowed.Clear();}
            status=null;audioReady=false;panelReported=false;visibleUntil=0;tokens=SoundDownload.ChunkSize*4;lastTick=Time.unscaledTime;
        }
        static void Show(string message)
        {
            status=message;visibleUntil=Time.unscaledTime+12;
            if(message.IndexOf("%",StringComparison.Ordinal)<0||Time.unscaledTime>=nextLog)
            {log?.Invoke(message.Replace('\n',' '));nextLog=Time.unscaledTime+2;}
        }
        internal static void Tick()
        {
            double now=Time.unscaledTime;
            if(NetworkManager.IsServer)
            {
                tokens=Math.Min(SoundDownload.ChunkSize*4,tokens+Math.Max(0,now-lastTick)*262144);lastTick=now;
                // Remove disconnected clients; queues and rate state stay bounded.
                if(nextAllowed.Count>0&&now>=nextCleanup)
                {
                    nextCleanup=now+5;disconnected.Clear();
                    foreach(long id in nextAllowed.Keys)if(!NetworkBase.Clients.Any(c=>c.connectionId==id))disconnected.Add(id);
                    foreach(long id in disconnected)nextAllowed.Remove(id);
                }
                lock(gate){if(order.Count==0)return;}
                for(int count=0;count<4&&tokens>=SoundDownload.ChunkSize;count++)
                {
                    long id;SoundRequest request;
                    lock(gate){if(order.Count==0)break;id=order.Dequeue();request=requests[id];requests.Remove(id);}
                    var client=NetworkBase.Clients.FirstOrDefault(c=>c.connectionId==id);if(client==null)continue;
                    if(nextAllowed.TryGetValue(id,out double after)&&now<after){Enqueue(id,request);continue;}
                    tokens-=SoundDownload.ChunkSize;nextAllowed[id]=now+.025;
                    try{new SoundResponseMessage{Response=server.Read(request)}.SendToClient(client);}
                    catch(Exception ex){log?.Invoke("Sound chunk send failed: "+ex.Message);}
                }
                return;
            }
            if(!NetworkManager.IsClient||download==null)return;
            // Booster messages are accepted after world join. Do not send during the password/join screens.
            if(GameManager.GameState!=GameState.Running||ImGuiLoadingScreen.IsShowing)return;
            for(int i=0;i<32;i++)
            {
                SoundResponse response;lock(gate){if(incoming.Count==0)break;response=incoming.Dequeue();}
                download.Receive(response,now);
            }
            download.Tick(now);
        }
        static void Enqueue(long id,SoundRequest request)
        {
            lock(gate){if(requests.ContainsKey(id))return;if(requests.Count>=32)return;requests[id]=request;order.Enqueue(id);}
        }
        internal static void ReceiveRequest(long sender,SoundRequest request)
        {
            if(!NetworkManager.IsServer||server==null)return;
            if(!NetworkBase.Clients.Any(c=>c.connectionId==sender))return;
            Enqueue(sender,request);
        }
        internal static void ReceiveResponse(long sender,SoundResponse response)
        {
            if(!NetworkManager.IsClient||NetworkManager.IsServer||download==null||sender!=host)return;
            lock(gate){if(incoming.Count<32)incoming.Enqueue(response);}
        }
        internal static void Failed(string message){audioReady=true;Show("Server sounds failed: "+message);}
        internal static void Loading(){audioReady=false;Show("Please wait: loading verified server sounds...");}
        internal static void Loaded(int count){audioReady=true;Show(download?.CatalogCount==0?"Server has no custom sounds.":count>0?"Ready to play: "+count+" server sounds.":"No server sounds could be loaded. See the log.");}
        internal static void Draw()
        {
            if(GameManager.IsBatchMode||!NetworkManager.IsClient||GameManager.GameState!=GameState.Running||
                ImGuiLoadingScreen.IsShowing||string.IsNullOrEmpty(status)||audioReady&&Time.unscaledTime>visibleUntil)return;
            if(ImGui.GetCurrentContext()==IntPtr.Zero)return;
            ImGui.SetNextWindowPos(new Vector2(Math.Max(12,Screen.width-460),80),ImGuiCond.Always);
            ImGui.SetNextWindowSize(new Vector2(Math.Min(440,Math.Max(200,Screen.width-24)),0),ImGuiCond.Always);
            bool open=ImGui.Begin("Custom SoundAlert",ImGuiWindowFlags.NoResize|ImGuiWindowFlags.NoMove|ImGuiWindowFlags.NoCollapse|
                ImGuiWindowFlags.NoSavedSettings|ImGuiWindowFlags.NoFocusOnAppearing|ImGuiWindowFlags.NoInputs);
            try
            {
                if(open)
                {
                    if(!panelReported){panelReported=true;Trace("Download status panel rendered after world loading completed.");}
                    ImGui.PushTextWrapPos(0);
                    try
                    {
                        ImGui.TextUnformatted(status);
                    }
                    finally{ImGui.PopTextWrapPos();}
                }
            }
            finally{ImGui.End();}
        }

    }
    internal static class SoundWire
    {
        internal static string Encode(SoundRequest r)=>r.Token+"|"+r.Id.ToString(CultureInfo.InvariantCulture)+"|"+r.Offset.ToString(CultureInfo.InvariantCulture);
        internal static bool ParseHeader(string payload,int fields,int max,out string[] parts,out SoundRequest request)
        {
            parts=null;request=null;if(payload==null||payload.Length>max)return false;
            parts=payload.Split('|');if(parts.Length!=fields||parts[0].Length!=32)return false;
            foreach(char c in parts[0])if(!(c>='0'&&c<='9'||c>='a'&&c<='f'))return false;
            if(!int.TryParse(parts[1],NumberStyles.None,CultureInfo.InvariantCulture,out int id)||id<100||id>199||
               !long.TryParse(parts[2],NumberStyles.None,CultureInfo.InvariantCulture,out long offset)||offset<0||offset>=ServerSoundCatalog.MaxFile||offset%SoundDownload.ChunkSize!=0)return false;
            request=new SoundRequest{Token=parts[0],Id=id,Offset=offset};return true;
        }
    }
    public sealed class SoundRequestMessage:INetworkMessage
    {
        internal SoundRequest Request;
        public void Serialize(RocketBinaryWriter writer)=>writer.WriteString(SoundWire.Encode(Request));
        public void Deserialize(RocketBinaryReader reader){if(!SoundWire.ParseHeader(reader.ReadString(),3,100,out _,out Request))Request=null;}
        public void Process(long clientId){if(Request!=null)SoundTransferNetwork.ReceiveRequest(clientId,Request);}
    }
    public sealed class SoundResponseMessage:INetworkMessage
    {
        internal SoundResponse Response;
        public void Serialize(RocketBinaryWriter writer)=>writer.WriteString(SoundWire.Encode(new SoundRequest{Token=Response.Token,Id=Response.Id,Offset=Response.Offset})+"|"+Response.Status+"|"+Convert.ToBase64String(Response.Data));
        public void Deserialize(RocketBinaryReader reader)
        {
            Response=null;if(!SoundWire.ParseHeader(reader.ReadString(),5,11200,out var parts,out var header)||!int.TryParse(parts[3],out int status)||status<0||status>2)return;
            byte[] data;try{data=Convert.FromBase64String(parts[4]);}catch(FormatException){return;}
            if(data.Length>SoundDownload.ChunkSize||status!=0&&data.Length!=0)return;
            Response=new SoundResponse{Token=header.Token,Id=header.Id,Offset=header.Offset,Status=status,Data=data};
        }
        public void Process(long clientId){if(Response!=null)SoundTransferNetwork.ReceiveResponse(clientId,Response);}
    }
}
