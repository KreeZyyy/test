using System;
namespace StationEmotes
{
 internal static class FacepalmLayout
 {
  private static bool Eye(float value)=>!float.IsNaN(value)&&!float.IsInfinity(value)&&value>-.25f&&value<.35f;
  internal static float Forward(bool helmet,float measuredFront,float eyeFront=float.NaN)
  {
   float bare=Eye(eyeFront)?Math.Max(.11f,eyeFront+.055f):.135f;
   if(!helmet)return bare;
   if(float.IsNaN(measuredFront)||float.IsInfinity(measuredFront)||measuredFront<.06f||measuredFront>.50f)return Math.Max(.23f,bare+.08f);
   return Math.Max(Math.Max(.225f,bare+.08f),measuredFront+.045f);
  }
  internal static float PalmHeight(bool helmet,float eyeHeight=float.NaN)=>Eye(eyeHeight)?eyeHeight+.005f:helmet?.110f:.095f;
  internal static float WristHeight(bool helmet)=>helmet?-.005f:-.025f;
 }
}
