using System;using System.Linq;using System.Collections.Generic;
namespace UnityEngine {
 public struct Vector3 {public float x,y,z;public Vector3(float x,float y,float z){this.x=x;this.y=y;this.z=z;}public static Vector3 zero=>new();public static Vector3 one=>new(1,1,1);public static Vector3 operator*(Vector3 v,float f)=>new(v.x*f,v.y*f,v.z*f);public static Vector3 Scale(Vector3 a,Vector3 b)=>new(a.x*b.x,a.y*b.y,a.z*b.z);}
 public struct Quaternion {public int Id;}
 public class Transform {public Vector3 position,localScale=Vector3.one;public Quaternion rotation;public Vector3 ParentScale=Vector3.one;public Vector3 lossyScale=>Vector3.Scale(localScale,ParentScale);public void SetPositionAndRotation(Vector3 p,Quaternion q){position=p;rotation=q;}}
 public struct Bounds {public Vector3 size;}
 public class Mesh {public string name;public Bounds bounds;public Vector3[] vertices;public int[] triangles;public void RecalculateNormals(){}public void RecalculateBounds(){bounds=new Bounds{size=new(vertices.Max(v=>v.x)-vertices.Min(v=>v.x),vertices.Max(v=>v.y)-vertices.Min(v=>v.y),vertices.Max(v=>v.z)-vertices.Min(v=>v.z))};}}
 public class MeshFilter {public Mesh sharedMesh;}
 public struct Color {public string Name;public static Color black=>new(){Name="black"};}
 public class Material {public string Name;}
 public class MaterialPropertyBlock {public Dictionary<int,float> Floats=new();public Dictionary<int,Color> Colors=new();public void SetFloat(int id,float x)=>Floats[id]=x;public void SetColor(int id,Color c)=>Colors[id]=c;public MaterialPropertyBlock Copy()=>new(){Floats=new(Floats),Colors=new(Colors)};}
 public class Renderer {public bool forceRenderingOff;public T[] GetComponentsInChildren<T>(bool includeInactive)=>new[]{this}.OfType<T>().ToArray();public UnityEngine.Rendering.ShadowCastingMode shadowCastingMode;public bool receiveShadows;public string name;public Assets.Scripts.Objects.Thing Owner;public Transform transform=new();public Material[] sharedMaterials=Enumerable.Range(0,5).Select(i=>new Material{Name="original"+i}).ToArray();public MaterialPropertyBlock Global;public Dictionary<int,MaterialPropertyBlock> Slots=new();public MeshFilter Filter;public Bounds bounds;public void SetPropertyBlock(MaterialPropertyBlock b)=>Global=b?.Copy();public void SetPropertyBlock(MaterialPropertyBlock b,int i){if(b==null)Slots.Remove(i);else Slots[i]=b.Copy();}public T GetComponent<T>() where T:class=>Filter as T;public T GetComponentInParent<T>(bool includeInactive=false) where T:class=>(includeInactive||Owner?.Inactive!=true)?Owner as T:null;}
 public class MeshRenderer:Renderer{}
 public static class Mathf {public static float Abs(float x)=>MathF.Abs(x);public static float Max(float a,float b)=>MathF.Max(a,b);}
}
namespace Assets.Scripts.Objects.Motherboards {public enum ColorType {Blue,Gray,Green,Orange,Red,Yellow,White,Black}}
namespace Assets.Scripts.Objects {public class Thing {public bool Inactive;public const int DiffuseIndexPropertyID=1,SmoothnessIndexPropertyID=2,EMISSION_COLOR=3;public List<UnityEngine.MeshRenderer> Surfaces=new();public List<Connection> OpenEnds=new();public T[] GetComponentsInChildren<T>(bool inactive)=>Surfaces.OfType<T>().ToArray();}public class Structure:Thing {public bool IsCursor;}public class Connection {public UnityEngine.Renderer HelperRenderer;public UnityEngine.Transform Transform;public string Type="Data",Role="Input";}}
namespace ModularSwitchboards {interface IDinLogic {Assets.Scripts.Objects.Thing Logic{get;}}class LogicModule:Assets.Scripts.Objects.Structure,IDinLogic {public Assets.Scripts.Objects.Thing Logic=>this;}static class CabinetGeometry {internal static int[] PaletteIndices={1,6,5,7,1};}}

namespace UnityEngine.Rendering {public enum ShadowCastingMode {Off,On}}

namespace ModularSwitchboards {static class DinLogicText {internal static void Restore(Assets.Scripts.Objects.Thing owner){}}static class HousingAddressScrew {internal static void RestoreLogic(UnityEngine.MeshRenderer r){}}}
