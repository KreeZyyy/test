using System;using System.Linq;
namespace CustomSoundAlert {partial class Plugin {
        void RefreshCatalogContext()
        {
            if(System.Threading.Interlocked.Exchange(ref SoundCatalogHandshake.ResetRequested,0)!=0)roleInitialized=false;
            bool remote=Remote;
            if(!roleInitialized||remote!=selectedRemote)
            {
                bool leaving=roleInitialized&&selectedRemote&&!remote;
                ClearCustomState();selectedRemote=remote;roleInitialized=true;remoteCatalog=Array.Empty<SoundEntry>();seenCatalog=-1;

                Info(remote?"Multiplayer: local sounds hidden; waiting for server catalog.":"Singleplayer/local host: using local sounds folder.");
            }
            if(remote)
            {
                if(System.Threading.Interlocked.Read(ref SoundCatalogHandshake.Revision)==seenCatalog)return;
                SoundEntry[] pending;long revision;lock(SoundCatalogHandshake.Gate){pending=SoundCatalogHandshake.Pending;revision=SoundCatalogHandshake.Revision;}
                if(pending!=null&&seenCatalog!=revision)
                {
                    ClearCustomState();remoteCatalog=pending;seenCatalog=revision;
                    foreach(var e in pending)labels[e.Id]=e.Name;BuildModes();
                    int cached=pending.Count(e=>ServerSoundCatalog.Cached(CacheDirectory,e));
                    Info("Server catalog: "+pending.Length+" sounds; verified cache "+cached+". File transfer is not implemented in this catalog prototype.");
                }
            }
        }
}}
