using System.Collections.Generic;
using UnityEngine;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Motherboards;

namespace ModularSwitchboards
{
    internal static class DinFuseModel
    {
        private sealed class Shape
        {
            internal readonly List<Vector3> V=new List<Vector3>(),N=new List<Vector3>();
            internal readonly List<int>[] T={new List<int>(),new List<int>(),new List<int>(),new List<int>(),new List<int>()};
            internal void Box(Vector3 p,Vector3 size,int role)=>RoundedGeometry.Box(V,N,T[role],p,size,.0004f);
            internal void Cylinder(float y,float length,float radius,int role)
            {
                const int count=32;float z=.046f;
                for(int i=0;i<count;i++)
                {
                    float a=i*Mathf.PI*2/count,b=(i+1)*Mathf.PI*2/count;
                    var ra=new Vector3(Mathf.Cos(a)*radius/DinBreakerModel.VisualScale.x,0,Mathf.Sin(a)*radius/DinBreakerModel.VisualScale.z);
                    var rb=new Vector3(Mathf.Cos(b)*radius/DinBreakerModel.VisualScale.x,0,Mathf.Sin(b)*radius/DinBreakerModel.VisualScale.z);
                    var lo=new Vector3(0,y-length*.5f,z);var hi=new Vector3(0,y+length*.5f,z);
                    var na=new Vector3(Mathf.Cos(a)*DinBreakerModel.VisualScale.x,0,Mathf.Sin(a)*DinBreakerModel.VisualScale.z).normalized;
                    var nb=new Vector3(Mathf.Cos(b)*DinBreakerModel.VisualScale.x,0,Mathf.Sin(b)*DinBreakerModel.VisualScale.z).normalized;
                    SmoothTriangle(lo+ra,hi+ra,lo+rb,na,na,nb,role);SmoothTriangle(lo+rb,hi+ra,hi+rb,nb,na,nb,role);
                    Triangle(lo,lo+ra,lo+rb,role);Triangle(hi,hi+rb,hi+ra,role);
                }
            }
            internal void Seat(float y)
            {
                // Extrude a closed cross-section with a circular saddle matching the
                // physical (non-uniformly scaled) end cap, plus 0.2 mm clearance.
                const int segments=32;
                const float half=.00525f,back=.0345f,front=.0465f,radius=.0084f;
                var edge=new List<Vector3>();
                edge.Add(new Vector3(-half,0,back));edge.Add(new Vector3(half,0,back));
                edge.Add(new Vector3(half,0,front));
                float rx=radius/DinBreakerModel.VisualScale.x;
                edge.Add(new Vector3(rx,0,front));
                for(int i=0;i<=segments;i++)
                {
                    float angle=i*Mathf.PI/segments;
                    edge.Add(new Vector3(Mathf.Cos(angle)*rx,0,.046f-Mathf.Sin(angle)*radius/DinBreakerModel.VisualScale.z));
                }
                edge.Add(new Vector3(-rx,0,front));edge.Add(new Vector3(-half,0,front));
                // Each strip is convex and has its own back edge; this avoids a
                // triangle fan crossing the concave notch.
                for(int i=2;i<edge.Count-1;i++)
                {
                    var a=edge[i];var b=edge[i+1];
                    if(Mathf.Abs(a.x-b.x)<.0000001f)continue;
                    var c=new Vector3(b.x,0,back);var d=new Vector3(a.x,0,back);
                    var lo=new Vector3(0,y-.00225f,0);var hi=new Vector3(0,y+.00225f,0);
                    Triangle(a+lo,b+lo,c+lo,4);Triangle(a+lo,c+lo,d+lo,4);
                    Triangle(a+hi,c+hi,b+hi,4);Triangle(a+hi,d+hi,c+hi,4);
                }
                for(int i=0;i<edge.Count;i++)
                {
                    var a=edge[i];var b=edge[(i+1)%edge.Count];
                    var lo=new Vector3(0,y-.00225f,0);var hi=new Vector3(0,y+.00225f,0);
                    Triangle(a+lo,b+lo,a+hi,4);Triangle(b+lo,b+hi,a+hi,4);
                }
            }
            private void SmoothTriangle(Vector3 a,Vector3 b,Vector3 c,Vector3 na,Vector3 nb,Vector3 nc,int role)
            {int first=V.Count;V.AddRange(new[]{a,b,c});N.AddRange(new[]{na,nb,nc});T[role].AddRange(new[]{first,first+1,first+2});}
            private void Triangle(Vector3 a,Vector3 b,Vector3 c,int role)
            {int first=V.Count;var normal=Vector3.Cross(b-a,c-a).normalized;V.AddRange(new[]{a,b,c});N.AddRange(new[]{normal,normal,normal});T[role].AddRange(new[]{first,first+1,first+2});}
            internal Mesh Finish(string name){var mesh=new Mesh{name=name};mesh.SetVertices(V);mesh.SetNormals(N);mesh.subMeshCount=5;for(int i=0;i<5;i++)mesh.SetTriangles(T[i],i);CabinetGeometry.ApplyNativeUv(mesh);mesh.RecalculateBounds();return mesh;}
        }
        internal static Mesh Housing()
        {
            // Same continuous casing as the breaker, with a narrow fuse aperture.
            // Separate rounded rails and end blocks would leave visible seams.
            var mesh=DinBreakerModel.Build(.0176f,0,true,.0125f,.044f);
            mesh.name="Switchboards.HollowFuseHolder";return mesh;
        }
        internal static Mesh Contacts()
        {
            var g=new Shape();
            foreach(float end in new[]{-1f,1f})
                // Small smooth seats behind the original white end caps.
                g.Seat(end*.014f);
            return g.Finish("Switchboards.FixedFuseContacts");
        }
        internal static Mesh Cartridge(bool burnt)
        {
            var g=new Shape();
            if(!burnt)g.Cylinder(0,.024f,.007f,0);
            else
            {
                // Two charred halves with an actual missing section, not an indicator.
                g.Cylinder(-.008f,.008f,.007f,3);g.Cylinder(.008f,.008f,.007f,3);
                g.Box(new Vector3(-.0012f,-.0035f,.048f),new Vector3(.002f,.003f,.003f),3);
                g.Box(new Vector3(.001f,.0035f,.044f),new Vector3(.0018f,.003f,.003f),3);
            }
            return g.Finish(burnt?"Switchboards.BurntFuse":"Switchboards.IntactFuse");
        }
        internal static Mesh Caps()
        {
            var g=new Shape();foreach(float sign in new[]{-1f,1f})g.Cylinder(sign*.014f,.005f,.0082f,1);
            return g.Finish("Switchboards.WhiteFuseCaps");
        }
        internal static Material[] CapMaterials()=>FuseSurfaces.White;
        internal static void PaintCaps(Renderer renderer)
        {
            // Dedicated plain material owns the colour; do not send palette indices to it.
            renderer.SetPropertyBlock(null);
            for(int role=0;role<renderer.sharedMaterials.Length;role++)renderer.SetPropertyBlock(null,role);
        }
        internal static void Paint(Renderer renderer,float watts)
        {
            int colour=DinModuleColours.Index(watts);
            for(int role=0;role<renderer.sharedMaterials.Length;role++)
            {var block=new MaterialPropertyBlock();block.SetFloat(Thing.DiffuseIndexPropertyID,role==0?colour:CabinetGeometry.PaletteIndices[role]);block.SetColor(Thing.EMISSION_COLOR,Color.black);renderer.SetPropertyBlock(block,role);}
        }
    }
    public sealed class DinFuseView:MonoBehaviour
    {
        public DinBreaker Owner;public GameObject Intact,Burnt,Caps;
        private bool appearanceReady,lastFilled,lastTripped;
        private float lastWatts;
        private void LateUpdate()
        {
            if(Owner==null)return;
            bool filled=Owner.Conducting;
            if(appearanceReady&&filled==lastFilled&&Owner.Tripped==lastTripped&&Owner.RatedWatts==lastWatts)return;
            appearanceReady=true;lastFilled=filled;lastTripped=Owner.Tripped;lastWatts=Owner.RatedWatts;
            Intact.SetActive(filled);Burnt.SetActive(Owner.Tripped);Caps.SetActive(filled||Owner.Tripped);
            if(filled||Owner.Tripped)DinFuseModel.PaintCaps(Caps.GetComponent<MeshRenderer>());
            if(filled)DinFuseModel.Paint(Intact.GetComponent<MeshRenderer>(),Owner.RatedWatts);
            if(Owner.Tripped)DinFuseModel.Paint(Burnt.GetComponent<MeshRenderer>(),Owner.RatedWatts);
        }
    }
}
