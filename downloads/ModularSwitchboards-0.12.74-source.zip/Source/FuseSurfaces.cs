using System;
using UnityEngine;

namespace ModularSwitchboards
{
    // Plain surfaces deliberately bypass the texture-array atlas on these small parts.
    internal static class FuseSurfaces
    {
        private static Material[] white,metal;
        internal static Material[] White=>white??(white=Create("Switchboards.Fuse.White",Color.white,0f,.20f));
        internal static Material[] Metal=>metal??(metal=Create("Switchboards.Fuse.Contacts",new Color(.90f,.91f,.92f,1f),0f,0f));
        private static Material[] Create(string name,Color colour,float metallic,float gloss)
        {
            var shader=Shader.Find("StandardInstanced");
            if(shader==null||!shader.isSupported)throw new InvalidOperationException("Native StandardInstanced shader unavailable for fuse surfaces");
            var material=new Material(shader){name=name};
            material.SetTexture("_MainTex",Texture2D.whiteTexture);
            material.SetColor("_Color",colour);material.SetColor("_EmissionColor",Color.black);
            material.SetFloat("_Metallic",metallic);material.SetFloat("_Glossiness",gloss);
            if(name=="Switchboards.Fuse.Contacts")
            {
                material.SetFloat("_GlossMapScale",0);material.SetFloat("_SpecularHighlights",0);material.SetFloat("_GlossyReflections",0);
                material.DisableKeyword("_METALLICGLOSSMAP");material.EnableKeyword("_SPECULARHIGHLIGHTS_OFF");material.EnableKeyword("_GLOSSYREFLECTIONS_OFF");
            }
            // All geometry roles reference the same dedicated material, never the cabinet palette.
            return new[]{material,material,material,material,material};
        }
    }
}
