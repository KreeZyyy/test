using System;
using System.Collections.Generic;
using System.Linq;
using Assets.Scripts;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Objects.Electrical;
using Assets.Scripts.Sound;
using Assets.Scripts.Util;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class CabinetWireDamage
    {
        private static Material charred;
        internal static Mesh Build(WirePoint[] path,CabinetWireKind kind)
        {
            var halves=WireDamageShape.Split(path);var meshes=halves.Select(p=>WireVisualGenerator.Build(p,kind)).ToArray();
            var combines=new List<CombineInstance>();foreach(var mesh in meshes)for(int i=0;i<mesh.subMeshCount;i++)combines.Add(new CombineInstance{mesh=mesh,subMeshIndex=i,transform=Matrix4x4.identity});
            var result=new Mesh{name="Switchboards.RupturedWire"};result.indexFormat=UnityEngine.Rendering.IndexFormat.UInt32;result.CombineMeshes(combines.ToArray(),true,false);foreach(var mesh in meshes)UnityEngine.Object.Destroy(mesh);return result;
        }
        internal static void Surface(MeshRenderer renderer)
        {
            if(charred==null){charred=new Material(Shader.Find("Standard")){name="Switchboards.CharredWire",color=new Color(.055f,.045f,.035f)};CabinetMatteSurface.Configure(charred);}
            renderer.sharedMaterials=new[]{charred};renderer.SetPropertyBlock(null);renderer.SetPropertyBlock(null,0);
        }
        internal static void Play(Vector3 position)
        {
            if(GameManager.GameState!=GameState.Running||GameManager.IsBatchMode)return;
            var world=WorldManager.Instance;if(world!=null&&world.Sparker!=null)world.Sparker.Emit(new ParticleSystem.EmitParams{position=position},100);
            var audio=Singleton<AudioManager>.Instance;if(audio!=null)audio.PlayAudioClipsData(CableRuptured.CableSparkHash,position);
        }
    }
}
