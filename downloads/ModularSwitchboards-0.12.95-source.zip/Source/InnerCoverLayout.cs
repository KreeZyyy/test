using System;
using System.Collections.Generic;
using System.Linq;
namespace ModularSwitchboards
{
    internal static class InnerCoverLayout
    {
        internal const float HalfWidth=.173f,HalfHeight=.233f,Plane=.119f,Thickness=.002f;
        internal struct Cell
        {
            internal float Left,Right,Bottom,Top;
            internal bool West,East,South,North;
        }
        internal static WireRect Window(float centerX,float centerY,int slots,bool battery)
        {
            float half=(DinLayout.ModuleHalfWidth*2+(slots-1)*DinLayout.SlotPitch-.004f)*.5f;
            float height=battery?.035f:.032f;
            return new WireRect(centerX-half,centerX+half,centerY-height,centerY+height);
        }
        internal static List<Cell> Cells(IEnumerable<WireRect> windows)
        {
            var holes=windows.Select(w=>new WireRect(Math.Max(-HalfWidth,(float)Math.Round(w.Left,6)),Math.Min(HalfWidth,(float)Math.Round(w.Right,6)),Math.Max(-HalfHeight,(float)Math.Round(w.Bottom,6)),Math.Min(HalfHeight,(float)Math.Round(w.Top,6))))
                .Where(w=>w.Left<w.Right&&w.Bottom<w.Top).ToArray();
            var xs=new SortedSet<float>{-HalfWidth,HalfWidth};var ys=new SortedSet<float>{-HalfHeight,HalfHeight};
            foreach(var w in holes){xs.Add(w.Left);xs.Add(w.Right);ys.Add(w.Bottom);ys.Add(w.Top);}
            var x=xs.ToArray();var y=ys.ToArray();var filled=new bool[x.Length-1,y.Length-1];
            for(int i=0;i<x.Length-1;i++)for(int j=0;j<y.Length-1;j++)
                filled[i,j]=!holes.Any(w=>(x[i]+x[i+1])*.5f>w.Left&&(x[i]+x[i+1])*.5f<w.Right&&(y[j]+y[j+1])*.5f>w.Bottom&&(y[j]+y[j+1])*.5f<w.Top);
            var cells=new List<Cell>();
            for(int i=0;i<x.Length-1;i++)for(int j=0;j<y.Length-1;j++)if(filled[i,j])
                cells.Add(new Cell{Left=x[i],Right=x[i+1],Bottom=y[j],Top=y[j+1],West=i==0||!filled[i-1,j],East=i==x.Length-2||!filled[i+1,j],South=j==0||!filled[i,j-1],North=j==y.Length-2||!filled[i,j+1]});
            return cells;
        }
    }
}
