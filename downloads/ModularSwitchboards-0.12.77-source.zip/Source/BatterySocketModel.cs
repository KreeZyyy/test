using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class BatterySocketModel
    {
        internal static Mesh Build()=>Build(new Vector3(-.0968359262f,-.115021147f,.129955426f),ApcBatteryRegion.FitScale(new Vector3(ApcBatteryRegion.NativeSocketHeight,ApcBatteryRegion.NativeSocketHeight,0)));
        internal static Mesh Build(Vector3 sourceCenter,float scale,int surface=-1)
        {
            var v=new List<Vector3>();var n=new List<Vector3>();var t=new[]{new List<int>(),new List<int>()};
            using(var stream=typeof(BatterySocketModel).Assembly.GetManifestResourceStream("ModularSwitchboards.BatterySocket.meshbin"))
            using(var reader=new BinaryReader(stream??throw new InvalidOperationException("APC socket profile resource missing")))
            {
                if(new string(reader.ReadChars(4))!="BS01")throw new InvalidDataException("Invalid APC socket profile");
                int count=reader.ReadInt32();if(count!=134)throw new InvalidDataException("Unexpected APC socket triangle count");
                for(int i=0;i<count;i++)
                {
                    int role=reader.ReadByte();if(role>1)throw new InvalidDataException("Invalid APC socket material role");
                    var p=new Vector3[3];for(int k=0;k<3;k++)p[k]=ApcBatteryRegion.Map(new Vector3(reader.ReadSingle(),reader.ReadSingle(),reader.ReadSingle()),sourceCenter,0,scale);
                    if(surface>=0&&role!=surface)continue;
                    var normal=Vector3.Cross(p[1]-p[0],p[2]-p[0]).normalized;int start=v.Count;
                    v.AddRange(p);n.AddRange(new[]{normal,normal,normal});t[role].AddRange(new[]{start,start+1,start+2});
                }
            }
            var mesh=new Mesh{name="Switchboards.ApcProfileBatterySocket"};mesh.SetVertices(v);mesh.SetNormals(n);mesh.subMeshCount=2;
            for(int i=0;i<2;i++)mesh.SetTriangles(t[i],i);mesh.RecalculateBounds();return mesh;
        }
    }
}
