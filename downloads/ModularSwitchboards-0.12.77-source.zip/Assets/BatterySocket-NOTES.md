# APC battery socket profile

Extracted from the preserved original APC export represented by Verification/FuseGeometry/NativeBayFixture.json. Whole triangles selected within ApcBatteryRegion.Contains:134 triangles. Components joined by equal positions (rounded to7 decimal places) identify one86-triangle casing and six separate8-triangle contact pieces. Positions are not redesigned or inferred from screenshot pixels. No source UVs, shader parameters or texture assets are used.

BatterySocket.meshbin: ASCII BS01, little-endian int32 triangle count134, then each triangle has uint8 material role (0 casing,1 gold contact) and9 float32 source APC coordinates. Runtime maps the profile with the native slot pose/scale. The verification compares each mapped vertex with the preserved original fixture within1 micrometre.
