using System;
using System.Collections.Generic;
using System.Linq;
using Assets.Scripts;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Electrical;
using Assets.Scripts.Objects.Motherboards;
using Assets.Scripts.UI;
using HarmonyLib;
using Rendering;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class DinStationBatteryModel
    {
        internal static void RecessFace(DinStationBattery owner,Bounds pocket)
        {
            var scale=DinBreakerModel.VisualScale;var inverse=new Vector3(1/scale.x,1/scale.y,1/scale.z);
            var local=new Bounds(Vector3.Scale(pocket.center,inverse),Vector3.Scale(pocket.size,inverse));
            var bodies=owner.GetComponentsInChildren<MeshFilter>(true).Where(f=>f.name=="DinBreakerModel").ToArray();
            if(bodies.Length==0)throw new InvalidOperationException("DIN switch pocket has no case.");
            var mesh=TransformerCasePocket.Cut(bodies[0].sharedMesh,local);
            foreach(var body in bodies)body.sharedMesh=mesh;
        }
        internal static void Install(DinStationBattery owner,Battery source,Transform storage)
        {
            // Keep only audio channels from the clone. No native cabinet, back,
            // ventilation grille, legs or external cable connector survives.
            var audio=new HashSet<Transform>();
            foreach(var channel in owner.AudioSources)
                if(channel?.AudioSource!=null&&channel.AudioSource.transform!=owner.transform)
                {var t=channel.AudioSource.transform;t.SetParent(owner.transform,false);t.localPosition=new Vector3(StationBatteryPanelLayout.Center(owner.ModuleWidth),0,.04f);audio.Add(t);}
            foreach(var a in owner.GetComponentsInChildren<Animator>(true))UnityEngine.Object.DestroyImmediate(a);
            foreach(var a in owner.GetComponentsInChildren<Renderer>(true))UnityEngine.Object.DestroyImmediate(a);
            foreach(var a in owner.GetComponentsInChildren<MeshFilter>(true))UnityEngine.Object.DestroyImmediate(a);
            foreach(var a in owner.GetComponentsInChildren<Collider>(true))UnityEngine.Object.DestroyImmediate(a);
            foreach(var child in owner.transform.Cast<Transform>().ToArray())if(!audio.Contains(child))UnityEngine.Object.DestroyImmediate(child.gameObject);
            owner.BaseAnimator=null;owner.Screen=null;owner.Renderers=new List<ThingRenderer>();owner.MPBRenderers.Clear();owner.Slots=new List<Slot>();
            owner._staticColliders=new List<Collider>();owner._dynamicColliders=new List<Collider>();owner._selfColliders=new List<Collider>();
            owner.OpenEnds.Clear();owner.InputConnection=null;owner.OutputConnection=null;owner.InputNetwork=null;owner.OutputNetwork=null;
            owner.CustomNavMeshFilter=null;owner.ForceGridBounds.Clear();owner.BrokenBuildStates=new List<BrokenBuildState>();owner.UseCellPosition=false;owner.StructureCollisionType=CollisionType.BlockCustom;owner.SelectionDisplay=SelectionHighlightMethod.Bounds;
            foreach(string field in new[]{"switchOnOff","activateButton","leverAnimationComponent","MaterialChanger"})AccessTools.Field(typeof(Thing),field).SetValue(owner,null);
            owner.AnimComponents=new List<Effects.StateMaterialChanger>();owner.structureRenderMode=StructureRenderMode.Standard;
            owner.DiffuseIndex=(int)ColorType.White;owner.EmissionColor=Color.black;owner.CustomColor=GameManager.GetColorSwatch((int)ColorType.White);owner.PaintableMaterial=owner.CustomColor.Normal;owner.HasColorState=false;
            var oldControls=owner.Interactables.ToArray();owner.Interactables=new List<Interactable>();
            var hitObject=new GameObject("BatterySwitchTarget"){layer=owner.gameObject.layer};hitObject.transform.SetParent(owner.transform,false);
            hitObject.transform.localPosition=new Vector3(owner.LargeVariant?StationBatteryPanelLayout.SwitchX(owner.ModuleWidth):SmallBatteryFaceLayout.SwitchX,0,StationBatteryPanelLayout.FaceZ+.004f);
            var switchHit=hitObject.AddComponent<BoxCollider>();switchHit.size=new Vector3(.026f,.031f,.014f);
            foreach(var action in new[]{InteractableType.OnOff,InteractableType.Mode,InteractableType.Powered,InteractableType.Error})
            {
                var old=oldControls.FirstOrDefault(c=>c.Action==action);
                var control=new Interactable{Parent=owner,Action=action,Collider=action==InteractableType.OnOff?switchHit:null,JoinInProgressSync=true,CanKeyInteract=action==InteractableType.OnOff,KeyMap=action==InteractableType.OnOff?"PrimaryAction":null,AssociatedAudioEvents=old?.AssociatedAudioEvents??new List<Assets.Scripts.Sound.GameAudioEvent>()};
                // Copy the serialized default, never a stale Animator/runtime cache.
                if(old!=null)AccessTools.Field(typeof(Interactable),"_state").SetValue(control,AccessTools.Field(typeof(Interactable),"_state").GetValue(old));
                control.CacheBounds();owner.Interactables.Add(control);
            }
            var front=new GameObject("BatteryFrontParts"){layer=owner.gameObject.layer};front.transform.SetParent(owner.transform,false);
            var bodies=new List<MeshRenderer>();var bodyMesh=TransformerPanelLayout.Body(owner.ModuleWidth);
            for(int stage=0;stage<owner.BuildStates.Count;stage++)
            {
                var body=new GameObject("DinBreakerModel"){layer=owner.gameObject.layer};body.transform.SetParent(owner.transform,false);body.transform.localScale=DinBreakerModel.VisualScale;
                body.AddComponent<MeshFilter>().sharedMesh=bodyMesh;var renderer=body.AddComponent<MeshRenderer>();renderer.sharedMaterials=CabinetGeometry.Materials;bodies.Add(renderer);
                var hit=body.AddComponent<BoxCollider>();hit.center=bodyMesh.bounds.center;hit.size=bodyMesh.bounds.size;
                var state=owner.BuildStates[stage];state.Visualizer=renderer;state.StateMeshes=new List<Mesh>();state.RendererInstance=null;state.RenderMode=BuildStateRenderMode.OnMyState;
                state.Colliders=new List<Collider>{hit};state.Interactables=owner.Interactables;state.InteractableParent=owner.gameObject;state.LinkedGameObjects=new List<GameObject>{body};
                if(stage==owner.BuildStates.Count-1){state.Colliders.Add(switchHit);state.LinkedGameObjects.Add(front);state.LinkedGameObjects.Add(hitObject);}
                state.BlockAir=state.AlwaysBlockAir=state.BlockLight=state.BlockGravity=false;AccessTools.Field(typeof(BuildState),"initialDrawData").SetValue(state,new DrawData{mesh=null,materials=new Material[0]});
            }
            if(!GameManager.IsBatchMode)NativeStationBatteryFace.Install(owner,source,front.transform,switchHit);
            else{AccessTools.Field(typeof(Battery),"displayRenderers").SetValue(owner,Array.Empty<MeshRenderer>());owner.NativeIndicatorCount=0;}
            for(int i=1;i<bodies.Count;i++)bodies[i].gameObject.SetActive(false);
            // Entries and visible screw aiming use the same original DIN terminals.
            float x=StationBatteryPanelLayout.Center(owner.ModuleWidth);
            owner.InternalInput=Vector3.Scale(new Vector3(x/DinBreakerModel.VisualScale.x,WireContactLayout.BreakerEntryY,WireContactLayout.BreakerEntryZ),DinBreakerModel.VisualScale);
            owner.InternalOutput=Vector3.Scale(new Vector3(x/DinBreakerModel.VisualScale.x,-WireContactLayout.BreakerEntryY,WireContactLayout.BreakerEntryZ),DinBreakerModel.VisualScale);
            owner.InternalInputAim=Vector3.Scale(new Vector3(x/DinBreakerModel.VisualScale.x,WireContactLayout.BreakerScrewY,WireContactLayout.BreakerScrewZ),DinBreakerModel.VisualScale);
            owner.InternalOutputAim=Vector3.Scale(new Vector3(x/DinBreakerModel.VisualScale.x,-WireContactLayout.BreakerScrewY,WireContactLayout.BreakerScrewZ),DinBreakerModel.VisualScale);
            owner.CacheStates(true);DinBreakerModel.Refresh(owner);var mesh=ModelBlueprint.Build(owner.transform,owner,true);owner.Bounds=owner.ModelBounds=mesh.bounds;owner.GridBounds=new GridBounds(owner);owner.SurfaceArea=.016f*owner.ModuleWidth;
            var bp=new GameObject("DinStationBatteryBlueprint"){layer=owner.gameObject.layer};bp.transform.SetParent(storage,false);var filter=bp.AddComponent<MeshFilter>();filter.sharedMesh=mesh;var paint=bp.AddComponent<MeshRenderer>();paint.sharedMaterial=CabinetGeometry.Materials[4];var wire=bp.AddComponent<Wireframe>();wire.BlueprintTransform=bp.transform;wire.BlueprintBounds=mesh.bounds;wire.BlueprintMeshFilter=filter;wire.BlueprintRenderer=paint;bp.AddComponent<CabinetBlueprint>();owner.Blueprint=bp;owner.BlueprintOrientVector=Vector3.zero;
            front.SetActive(false);hitObject.SetActive(false);
            Debug.Log("[Modular Switchboards] DIN station battery assembled from DIN case + native face parts: "+owner.PrefabName+", slots="+owner.ModuleWidth+", capacity="+owner.PowerMaximum+", segments="+owner.NativeIndicatorCount);
        }
    }
}
