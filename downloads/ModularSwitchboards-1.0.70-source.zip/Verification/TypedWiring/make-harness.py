from pathlib import Path
p=Path(__file__).resolve();s=(p.parents[2]/'Source/CabinetWiring.cs').read_text()
a=s.index('        internal bool TryAttack(');b=s.index('        private int WireAt(',a)
c=s.index('        private static bool CanRefundWires(');d=s.index('        internal static float[] Flatten',c)
(p.parent/'Extracted.cs').write_text('using System;using System.Linq;using System.Collections.Generic;using Assets.Scripts;using Assets.Scripts.Objects;using Assets.Scripts.Objects.Items;using Assets.Scripts.Objects.Motherboards;using UnityEngine;namespace ModularSwitchboards{partial class CabinetWiring{'+s[a:b]+s[c:d]+'}}')
