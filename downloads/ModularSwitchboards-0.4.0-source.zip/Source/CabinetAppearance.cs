using System;
using System.Collections.Generic;
using Assets.Scripts;
using Assets.Scripts.Objects;
using HarmonyLib;
using UnityEngine;

namespace ModularSwitchboards
{
    internal static class CabinetAppearance
    {
        private static readonly System.Reflection.FieldInfo PaintMappings =
            AccessTools.Field(typeof(Thing), "_customMaterials");

        // Native automatic caching marks every texture-array submesh as paintable and
        // rewrites its material immediately. Use explicit mappings for our own mesh only.
        internal static bool CanCacheRenderer(Thing __instance, ref bool __result)
        {
            if (__instance.PrefabName != SwitchboardsMod.CabinetName) return true;
            __result = false;
            return false;
        }

        internal static void RegisterRenderers(Thing __instance)
        {
            if (__instance.PrefabName != SwitchboardsMod.CabinetName) return;
            var model = __instance.transform.Find("SwitchboardModel");
            if (model == null) return;
            __instance.Renderers = new List<ThingRenderer>();
            var mappings = new List<CustomColorMapping>();
            int defaultColor = GameManager.GetColorIndex(__instance.PaintableMaterial);
            foreach (var renderer in model.GetComponentsInChildren<MeshRenderer>(true))
            {
                var materials = renderer.sharedMaterials;
                var tr = new ThingRenderer(__instance, renderer);
                __instance.Renderers.Add(tr);
                for (int i = 0; i < materials.Length; i++)
                {
                    if (tr.MeshFilter.sharedMesh.GetIndexCount(i) == 0) continue;
                    int role = Array.IndexOf(CabinetGeometry.Materials, materials[i]);
                    // Stored prefab renderers may already carry the game's paint material.
                    if (role < 0 && (renderer.name == "Housing" || renderer.name == "Door") && i == 0)
                        role = CabinetGeometry.PaintableMaterialIndex;
                    if (role < 0) continue;
                    if (role == CabinetGeometry.PaintableMaterialIndex)
                        mappings.Add(new CustomColorMapping(tr, i, defaultColor));
                    else
                    {
                        var block = new MaterialPropertyBlock();
                        renderer.GetPropertyBlock(block, i);
                        block.SetFloat(Thing.DiffuseIndexPropertyID, CabinetGeometry.PaletteIndices[role]);
                        block.SetFloat(Thing.SmoothnessIndexPropertyID, __instance.SmoothnessIndex);
                        block.SetColor(Thing.EMISSION_COLOR, Color.black);
                        renderer.SetPropertyBlock(block, i);
                    }
                }
            }
            if (PaintMappings == null) throw new MissingFieldException("Thing._customMaterials");
            PaintMappings.SetValue(__instance, mappings);
            Debug.Log("[Modular Switchboards] Selective paint mappings ready: " + mappings.Count + "; fixed internals and warning symbol.");
        }
    }
}
