using System;
using System.IO;
using Assets.Scripts;
using UnityEngine;
using Assets.Scripts.Objects.Motherboards;

namespace ModularSwitchboards
{
    // Blender geometry baked as embedded mesh data. No Unity editor/runtime importer required.
    internal static class CabinetGeometry
    {
        internal static Mesh[] Meshes;
        internal static Material[] Materials;
        internal static int[] PaletteIndices;
        internal const int PaintableMaterialIndex = 0;

        private static ColorType PaletteColor(Color color)
        {
            float max = Mathf.Max(color.r, Mathf.Max(color.g, color.b));
            float min = Mathf.Min(color.r, Mathf.Min(color.g, color.b));
            if (max - min < .15f) return max < .13f ? ColorType.Black : max < .5f ? ColorType.Gray : ColorType.White;
            if (color.b > color.r * 1.4f && color.b > color.g * 1.4f) return ColorType.Blue;
            if (color.g > color.r * 1.4f && color.g > color.b * 1.4f) return ColorType.Green;
            if (color.r > .6f && color.g > .4f && color.b < .2f) return ColorType.Yellow;
            if (color.r > .65f && color.g < .5f && color.b < .2f) return ColorType.Orange;
            if (color.r > color.g * 1.5f && color.r > color.b * 1.5f) return ColorType.Brown;
            return ColorType.Gray;
        }

        internal static void EnsureLoaded(Material fallback)
        {
            if (Meshes != null) return;

            using (var stream = typeof(CabinetGeometry).Assembly.GetManifestResourceStream("ModularSwitchboards.Cabinet.meshbin"))
            {
                if (stream == null) throw new InvalidOperationException("Embedded cabinet mesh is missing.");
                using (var reader = new BinaryReader(stream))
                {
                    if (new string(reader.ReadChars(4)) != "SBMS" || reader.ReadInt32() != 1)
                        throw new InvalidDataException("Unsupported cabinet mesh format.");
                    int materialCount = reader.ReadInt32(), meshCount = reader.ReadInt32();
                    if (materialCount < 1 || materialCount > 32 || meshCount != 4)
                        throw new InvalidDataException("Invalid cabinet mesh counts.");
                    var materials = new Material[materialCount];
                    var indicesByMaterial = new int[materialCount];
                    for (int i = 0; i < materialCount; i++)
                    {
                        var color = new Color(reader.ReadSingle(), reader.ReadSingle(), reader.ReadSingle(), reader.ReadSingle());
                        float metal = reader.ReadSingle(), rough = reader.ReadSingle();
                        // Reuse compiled, working game material variants and texture bindings.
                        // Shader.Find can return a shader whose variant cannot render in this player.
                        Material template = null;
                        try { template = GameManager.GetColorSwatch((int)PaletteColor(color)).Normal; }
                        catch (Exception ex) { Debug.LogWarning("[Modular Switchboards] Palette fallback: " + ex.Message); }
                        if (template == null || template.shader == null || !template.shader.isSupported)
                            template = fallback;
                        if (template == null || template.shader == null || !template.shader.isSupported)
                            throw new InvalidOperationException("No supported native material for the cabinet.");
                        indicesByMaterial[i] = GameManager.GetColorSwatch((int)PaletteColor(color)).Index;
                        var material = new Material(template) { name = "Switchboards.NativeMaterial." + i };
                        if (material.HasProperty("_Metallic")) material.SetFloat("_Metallic", metal);
                        if (material.HasProperty("_Glossiness")) material.SetFloat("_Glossiness", 1f - rough);
                        if (material.HasProperty("_Smoothness")) material.SetFloat("_Smoothness", 1f - rough);
                        materials[i] = material;
                    }
                    var meshes = new Mesh[meshCount];
                    for (int i = 0; i < meshCount; i++)
                    {
                        int count = reader.ReadInt32();
                        if (count < 3 || count > 65535) throw new InvalidDataException("Invalid vertex count.");
                        var vertices = new Vector3[count]; var normals = new Vector3[count];
                        for (int v = 0; v < count; v++)
                        {
                            vertices[v] = new Vector3(reader.ReadSingle(), reader.ReadSingle(), reader.ReadSingle());
                            normals[v] = new Vector3(reader.ReadSingle(), reader.ReadSingle(), reader.ReadSingle());
                        }
                        var mesh = new Mesh { name = "Switchboards." + new[] { "Housing", "Mounting", "Wiring", "Door" }[i] };
                        var uv = new Vector2[count];
                        for (int v = 0; v < count; v++)
                        {
                            var n = normals[v]; var p = vertices[v];
                            if (Mathf.Abs(n.x) > Mathf.Abs(n.y) && Mathf.Abs(n.x) > Mathf.Abs(n.z))
                                uv[v] = new Vector2(p.z * 2f, p.y * 2f);
                            else if (Mathf.Abs(n.y) > Mathf.Abs(n.z)) uv[v] = new Vector2(p.x * 2f, p.z * 2f);
                            else uv[v] = new Vector2(p.x * 2f, p.y * 2f);
                        }
                        mesh.vertices = vertices; mesh.normals = normals; mesh.uv = uv; mesh.subMeshCount = materialCount;
                        for (int m = 0; m < materialCount; m++)
                        {
                            int n = reader.ReadInt32();
                            if (n < 0 || n > count * 3 || n % 3 != 0) throw new InvalidDataException("Invalid triangle count.");
                            var indices = new int[n];
                            for (int j = 0; j < n; j++)
                            {
                                indices[j] = reader.ReadInt32();
                                if (indices[j] < 0 || indices[j] >= count) throw new InvalidDataException("Invalid mesh index.");
                            }
                            mesh.SetTriangles(indices, m, false);
                        }
                        mesh.RecalculateBounds(); mesh.RecalculateTangents(); meshes[i] = mesh;
                    }
                    if (stream.Position != stream.Length) throw new InvalidDataException("Unexpected cabinet mesh data.");
                    Materials = materials; PaletteIndices = indicesByMaterial; Meshes = meshes;
                }
            }
            Debug.Log("[Modular Switchboards] Cabinet native shader: " + Materials[0].shader.name);
            Debug.Log("[Modular Switchboards] Blender geometry loaded: housing, mounting, wiring, door.");
        }
    }
}
