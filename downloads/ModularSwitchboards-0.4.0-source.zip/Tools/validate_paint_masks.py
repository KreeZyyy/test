"""Validate material roles in the embedded Blender geometry without Unity."""
from pathlib import Path
import struct,math
b=(Path(__file__).resolve().parent.parent/'Assets/Cabinet.meshbin').read_bytes()
assert b[:4]==b'SBMS'
version,materials,groups=struct.unpack_from('<iii',b,4)
assert version==1 and groups==4
colors=[struct.unpack_from('<6f',b,16+i*24) for i in range(materials)]
# Fixed shell role and warning-sign roles used by CabinetAppearance.
assert all(abs(a-c)<1e-5 for a,c in zip(colors[0][:3],[.38,.42,.43]))
assert colors[6][0]>.9 and colors[6][1]>.6 and colors[6][2]<.03
assert max(colors[3][:3])<.03
pos=16+24*materials
counts=[]
for group in range(groups):
 n,=struct.unpack_from('<i',b,pos);pos+=4+n*24
 per_material=[]
 for m in range(materials):
  count,=struct.unpack_from('<i',b,pos);pos+=4+count*4;per_material.append(count//3)
 counts.append(per_material)
assert pos==len(b)
assert [g for g in range(groups) if counts[g][0]>0]==[0,3], 'Painted material must exist only in housing and door.'
assert counts[3][6]==1, 'Yellow warning triangle must remain a separate, fixed material.'
assert counts[3][3]>0, 'Black handle and warning bolt must remain fixed.'
assert counts[1][2]>0 and counts[2][10]>0 and counts[2][11]>0, 'Rail and wire material identities must survive painting.'
print('Paint-mask contract passes: shell and door only; fixed yellow triangle, black bolt, rails and wires.')
