"""Package a compiled mod + source. Never include user props/configs or game DLLs."""
from pathlib import Path
import argparse
import hashlib
import os
import shutil
import zipfile
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
NAME = 'ScriptedScreensLiteGeminiAI'
VERSION = '0.1.4'
parser = argparse.ArgumentParser()
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
output = args.output.resolve()
output.mkdir(parents=True, exist_ok=True)
binary = ROOT / 'bin/Release/netstandard2.1' / (NAME + '.dll')
if not binary.exists():
    raise SystemExit('Build the Release project first.')
metadata = ET.parse(ROOT / 'About/About.xml').getroot()
assert metadata.findtext('Version') == VERSION
assert metadata.findtext('Author') == 'KreeZy'
thumbnail = (ROOT / 'About/thumb.png').read_bytes()
assert thumbnail.startswith(b'\x89PNG\r\n\x1a\n') and len(thumbnail) < 1024 * 1024
assert thumbnail[24:26] == bytes([8, 6]), 'Use an 8-bit RGBA PNG thumbnail.'
# A PackageReference is used, but libraries need to be explicitly shipped for the mod loader.
nuget_root = Path(os.environ.get('NUGET_PACKAGES', str(Path.home() / '.nuget/packages')))
newtonsoft = nuget_root / 'newtonsoft.json/13.0.3/lib/netstandard2.0/Newtonsoft.Json.dll'
notice = nuget_root / 'newtonsoft.json/13.0.3/LICENSE.md'
if not newtonsoft.exists():
    raise SystemExit('Newtonsoft.Json 13.0.3 was not found in the NuGet cache.')
release = output / (NAME + '-' + VERSION + '.zip')
with zipfile.ZipFile(release, 'w', zipfile.ZIP_DEFLATED) as archive:
    archive.write(binary, NAME + '/' + binary.name)
    archive.write(newtonsoft, NAME + '/Newtonsoft.Json.dll')
    if notice.exists(): archive.write(notice, NAME + '/THIRD-PARTY/Newtonsoft.Json-LICENSE.md')
    for name in ['README.md', 'API.md', 'INSTALACE.txt', 'BUILD-INFO.txt', 'AKTUALIZACE.txt', 'PIPER-INSTALACE.txt']:
        archive.write(ROOT / name, NAME + '/' + name)
    for directory in ['About', 'examples']:
        for file in sorted((ROOT / directory).rglob('*')):
            if file.is_file(): archive.write(file, NAME + '/' + file.relative_to(ROOT).as_posix())
source = output / (NAME + '-' + VERSION + '-source.zip')
with zipfile.ZipFile(source, 'w', zipfile.ZIP_DEFLATED) as archive:
    for name in ['ScriptedScreensLiteGeminiAI.csproj', 'Stationeers.User.props.example',
                 'README.md', 'API.md', 'INSTALACE.txt', 'BUILD-INFO.txt', 'AKTUALIZACE.txt', 'PIPER-INSTALACE.txt', '.gitignore']:
        archive.write(ROOT / name, NAME + '/' + name)
    for directory in ['src', 'tests', 'scripts', 'About', 'examples']:
        for file in sorted((ROOT / directory).rglob('*')):
            if file.is_file() and file.suffix in ['.cs', '.csproj', '.py', '.lua', '.xml', '.png'] and not any(p in ['bin','obj','__pycache__'] for p in file.parts):
                archive.write(file, NAME + '/' + file.relative_to(ROOT).as_posix())
for archive in [release, source]:
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        assert not any(n.endswith('.cfg') or n.endswith('/Stationeers.User.props') for n in z.namelist())
    print(archive.name, archive.stat().st_size, 'bytes')
(output/'SHA256SUMS.txt').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name+'\n' for p in [release,source]),'utf-8')
shutil.copyfile(ROOT/'INSTALACE.txt',output/'INSTALACE.txt')
shutil.copyfile(ROOT/'README.md',output/'README.md')
