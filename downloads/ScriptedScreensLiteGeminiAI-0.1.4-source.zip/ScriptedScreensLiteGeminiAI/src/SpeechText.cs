using System.Text.RegularExpressions;

namespace ScriptedScreensLiteGeminiAI;

/// <summary>Plain spoken text; the displayed answer and stored conversation stay intact.</summary>
public static class SpeechText
{
    public static string ForPiper(string text)
    {
        // Fenced code is unsuitable for speech, including an unfinished final block.
        text = Regex.Replace(text, @"(?ms)^\s*(`{3,}|~{3,})[^\r\n]*\r?\n.*?(?:^\s*\1\s*$|\z)", " ");
        text = Regex.Replace(text, @"!\[([^\]]*)\]\([^\r\n)]*\)", " ");
        text = Regex.Replace(text, @"\[([^\]]+)\]\([^\r\n)]*\)", "$1");
        text = Regex.Replace(text, @"\[([^\]]+)\]\[[^\]]*\]", "$1");
        text = Regex.Replace(text, @"(?m)^\s*\[[^\]]+\]:\s*\S+.*$", " ");
        text = Regex.Replace(text, @"(?m)^\s*(?:[-*_]\s*){3,}$", " ");
        text = Regex.Replace(text, @"(?m)^\s*(?:#{1,6}\s+|>\s*|[-+*]\s+|\d+[.)]\s+)", "");
        text = Regex.Replace(text, @"`+([^`\r\n]+)`+", "$1");
        text = Regex.Replace(text, @"\*{1,3}([^*\r\n]+)\*{1,3}", "$1");
        text = Regex.Replace(text, @"(?<!\w)_{1,3}([^_\r\n]+)_{1,3}(?!\w)", "$1");
        text = Regex.Replace(text, @"~~([^~\r\n]+)~~", "$1");
        return Regex.Replace(text, @"\s+", " ").Trim();
    }
}
