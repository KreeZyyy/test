using System;using System.Linq;using System.Collections.Generic;using ModularSwitchboards;
namespace ModularSwitchboards {
 enum LogicType{On,Power,RequiredPower,PrefabHash,ReferenceId,NameHash,Mode,Setting,Color,SettingInput}
 class Device {internal bool OnOff;internal float UsedPower=2;protected readonly Dictionary<LogicType,double> values=new();public virtual bool CanLogicRead(LogicType t)=>true;public virtual bool CanLogicWrite(LogicType t)=>t==LogicType.On;public virtual double GetLogicValue(LogicType t)=>t==LogicType.On?(OnOff?1:0):values.TryGetValue(t,out var v)?v:0;public virtual void SetLogicValue(LogicType t,double v){values[t]=v;if(t==LogicType.On)OnOff=v!=0;}}
 class DoorSmartDisplay:Device {public override bool CanLogicWrite(LogicType t)=>t==LogicType.On||t==LogicType.Mode||t==LogicType.Setting||t==LogicType.Color;}
}
class Program {
 static int count;static void Check(bool ok,string message){count++;if(!ok)throw new Exception(message);}static CabinetWireSaveData W(long a,int p,long b,int q)=>new(){From=new(a,p),To=new(b,q)};
 static long[] outputs={100,101},bridges={200,201},displays={300,301};
 static long Target(long id,IEnumerable<CabinetWireSaveData> ws)=>SmartDoorDisplayCircuit.Target(id,ws,bridges,displays,outputs);
 static bool Valid(IEnumerable<CabinetWireSaveData> ws)=>SmartDoorDisplayCircuit.Valid(ws,bridges,displays,outputs);
 static void Wiring(){
 var ws=new List<CabinetWireSaveData>{W(100,1,200,2),W(200,3,300,0)};
 Check(Valid(ws)&&Target(100,ws)==300,"dedicated bridge display not resolved");Check(Target(101,ws)==0,"unconnected output gained display");
 foreach(var w in ws){w.Burnt=true;Check(Target(100,ws)==0,"burnt signal still drives display");w.Burnt=false;}
 Check(Target(100,ws.Take(1))==0&&Target(100,ws.Skip(1))==0,"half-connected route resolves");
 Check(!Valid(new[]{W(100,1,300,0)}),"direct plate-to-door display bypass accepted");Check(Target(100,new[]{W(100,1,300,0)})==0,"malformed save direct bypass resolved");
 Check(!Valid(ws.Concat(new[]{W(101,1,200,2)})),"two outputs drive one display");Check(Target(100,ws.Concat(new[]{W(101,1,200,2)}))==0,"ambiguous save still drives display");
 Check(!Valid(ws.Concat(new[]{W(200,3,301,0)})),"one output drives two displays");
 foreach(var end in new[]{new CabinetWireEnd(0,0),new CabinetWireEnd(0,1),new CabinetWireEnd(400,0),new CabinetWireEnd(400,2)})Check(!Valid(ws.Concat(new[]{new CabinetWireSaveData{From=end,To=new(200,2)}})),"power/coil mixed into display bridge");
 var dual=ws.Concat(new[]{W(101,1,201,2),W(201,3,301,0)}).ToArray();Check(Valid(dual)&&Target(100,dual)==300&&Target(101,dual)==301,"separate outputs interfere");
 Check(Valid(ws.Concat(new[]{W(101,1,400,2)})),"unrelated classic contactor rejected");
 Check(SmartContactorCircuit.Allowed(new(100,1),new(200,2),outputs,new long[]{400},bridges),"output-to-plate bridge rejected");Check(SmartContactorCircuit.Allowed(new(200,2),new(100,1),outputs,new long[]{400},bridges),"reverse click order rejected");
 Check(!SmartContactorCircuit.Allowed(new(100,1),new(200,3),outputs,new long[]{400},bridges),"output-to-door side accepted");Check(SmartContactorCircuit.Allowed(new(100,1),new(400,2),outputs,new long[]{400},bridges),"classic A1 behavior changed");
 foreach(bool reverse in new[]{false,true}){var wire=reverse?W(200,3,300,0):W(300,0,200,3);Check(Valid(new[]{W(100,1,200,2),wire}),"display wiring validation depends on click order");}
 // Saved wire orientation is assigned by the production helper, not by click order.
 foreach(bool reverse in new[]{false,true}){WireCircuit.Orient(reverse?new(300,0):new(200,3),reverse?new(200,3):new(300,0),out var from,out var to);Check(Target(100,new[]{W(100,1,200,2),new CabinetWireSaveData{From=from,To=to}})==300,"oriented door lead not resolved");}
 }
 static void Layout(){foreach(int minY in new[]{-10,-20})foreach(int x in Enumerable.Range(-20,41))foreach(int y in Enumerable.Range(-30,51)){
 bool expected=(x==-10||x==0)&&y>=minY&&y<=10&&y%10==0;
 Check(DoorDisplayLayout.Fits(x,y,0,0,minY)==expected,"door footprint bounds");Check(!DoorDisplayLayout.Fits(x,y,1,0,minY)&&!DoorDisplayLayout.Fits(x,y,0,1,minY),"depth/rotation accepted");}
 foreach(int anchor in new[]{-10,0})foreach(int slot in new[]{-10,0,10}){bool occupied=slot==anchor||slot==anchor+10;Check(DoorDisplayLayout.Overlaps(anchor,0,2,slot,0,1)==occupied,"two-slot display overlaps button incorrectly");Check(DoorDisplayLayout.Overlaps(slot,0,1,anchor,0,2)==occupied,"button can overlap display second slot");Check(!DoorDisplayLayout.Overlaps(anchor,0,2,slot,10,1),"next row blocked");}
 Check(DoorDisplayLayout.Overlaps(-10,0,2,0,0,2),"two displays overlap in middle column");}
 static void Proxy(){var o=new SmartContactor();Check(o.CanLogicWrite(LogicType.On)&&!o.CanLogicWrite(LogicType.Mode)&&!o.CanLogicWrite(LogicType.Color),"unconnected output lost A1 contract");o.SetLogicValue(LogicType.On,1);Check(o.OnOff,"classic A1 ON lost");
 var d=new DoorSmartDisplay{UsedPower=10};o.Display=d;
 foreach(var type in new[]{LogicType.Mode,LogicType.Setting,LogicType.Color}){Check(o.CanLogicRead(type)&&o.CanLogicWrite(type),"display property not exposed");o.SetLogicValue(type,3);Check(d.GetLogicValue(type)==3&&o.GetLogicValue(type)==3,"display store/read not forwarded");}
 o.SetLogicValue(LogicType.On,0);Check(!o.OnOff&&!d.OnOff,"OFF not forwarded");o.SetLogicValue(LogicType.On,1);Check(o.OnOff&&d.OnOff,"ON not forwarded");d.OnOff=false;Check(o.GetLogicValue(LogicType.On)==0,"display/output disagreement hidden from IC10 store comparison");o.SetLogicValue(LogicType.On,1);Check(d.OnOff&&o.OnOff,"reasserted ON did not restore display");Check(o.GetLogicValue(LogicType.RequiredPower)==12,"display power not accounted");Check(!o.CanLogicWrite(LogicType.SettingInput),"unsupported display property exposed");o.Display=null;Check(!o.CanLogicWrite(LogicType.Mode),"detached display still writable");Check(d.GetLogicValue(LogicType.Setting)==3,"disconnect erased stored setting");}
 static void Main(){Wiring();Layout();Proxy();Console.WriteLine(count+" production door-display checks passed: two-position bounds/overlap, dedicated bridge isolation, corrupt/ambiguous/burnt routes, click orientation, separate displays and extracted native Output proxy properties.");}
}
