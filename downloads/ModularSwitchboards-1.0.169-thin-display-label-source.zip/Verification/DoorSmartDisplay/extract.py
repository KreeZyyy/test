from pathlib import Path
r=Path(__file__).resolve().parents[2]
s=(r/'Source/SmartContactor.cs').read_text()
def method(signature):
 a=s.index(signature);arrow=s.find('=>',a);brace=s.find('{',a)
 if arrow>=0 and arrow<brace:return s[a:s.index(';',arrow)+1]
 depth=0
 for i in range(brace,len(s)):
  if s[i]=='{':depth+=1
  elif s[i]=='}':
   depth-=1
   if depth==0:return s[a:i+1]
parts=[method(x)for x in ['private static bool DisplayProperty','public override bool CanLogicRead','public override bool CanLogicWrite','public override void SetLogicValue','public override double GetLogicValue']]
out=Path(__file__).parent/'ProxyExtracted.cs';tmp=out.with_suffix('.tmp165');tmp.write_text('namespace ModularSwitchboards {class SmartContactor:Device {internal DoorSmartDisplay Display;internal bool IsStructureCompleted=true;'+''.join(parts)+'}}');tmp.replace(out)
