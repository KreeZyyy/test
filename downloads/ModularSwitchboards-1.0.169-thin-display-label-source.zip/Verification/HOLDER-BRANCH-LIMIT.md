## 1.0.164 — One Battery Holder per connected output branch

One Battery Holder per electrically connected output branch. Additional holders require separate branches.

The holder with the lowest persistent ReferenceId remains active. Additional completed holders on the same branch neither charge nor supply power; their cells and stored energy are preserved. Empty holders still reserve their branch. Existing cables are not deleted and no artificial short circuit is introduced. Separating branches or removing the active holder restores the next eligible holder automatically. New internal wires that create an additional conflicting holder are refused with an explanatory message. Existing conflicts do not prevent unrelated wiring edits.

Branch detection includes linked cabinet outputs, shared external cable networks across cabinets, downstream input links and series holders. Directional paths through breakers and transformers detect downstream merges without treating a common charging supply as a single backed-up output. Cell presence and state of charge never affect ownership. Power reservations are invalidated when the limit changes, including offers already cached in another cabinet. Native electricity ticks refresh external network membership before service and output calculations.

F1 includes the English rule. Inactive holder tooltips show: “Battery backup limit exceeded — connect to a separate output branch.” The stationary DIN battery experiments remain removed; the breaker-trip priority fix is retained. Cell capacity, native cell identities, construction costs and slot handling are unchanged.

Verification: native API compilation, production holder-limit regression (26 holders, energy preservation, branch split/merge, cross-cabinet links, cached offers, downstream protection, deterministic priority and wire adapter), existing combiner, wiring, protection and Stationpedia regressions. These are offline tests; Unity gameplay, save/reload and multiplayer behavior require an in-game check before public deployment.

