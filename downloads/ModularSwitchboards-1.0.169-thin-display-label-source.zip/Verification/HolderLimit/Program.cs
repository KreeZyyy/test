using System;using System.Linq;using System.Collections.Generic;using ModularSwitchboards;using Assets.Scripts.Networks;using Assets.Scripts.Objects;using Assets.Scripts.Objects.Items;using Assets.Scripts.Objects.Electrical;
class Program {
 static int count;static void Check(bool ok,string why){count++;if(!ok)throw new Exception(why);}static void Near(float a,float b,string why)=>Check(Math.Abs(a-b)<.01f,why+": "+a+" != "+b);
 static CabinetWireSaveData W(long a,int p,long b,int q)=>new(){From=new(a,p),To=new(b,q)};
 static Connection Port(CableNetwork n)=>new(){cable=new Cable{CableNetwork=n}};
 static CabinetPowerNode Holder(long id,float charge=4000)=>new(){ReferenceId=id,IsBatteryModule=true,Conducting=true,Battery=new BatteryCell{PowerStored=charge}};
 static (SwitchboardCabinet,CableNetwork,CableNetwork) Host(){var input=new CableNetwork{PotentialLoad=0};var output=new CableNetwork{RequiredLoad=100000};var h=new SwitchboardCabinet{Output1Connection=Port(output)};h.Feeds[0]=Port(input);return(h,input,output);}
 static void Bank(){
 var(h,input,output)=Host();input.PotentialLoad=100000;var nodes=Enumerable.Range(0,26).Select(i=>Holder(1000+i)).Reverse().ToArray();
 var wires=nodes.SelectMany(n=>new[]{W(0,0,n.ReferenceId,0),W(n.ReferenceId,1,0,1)}).ToList();var p=new CabinetCombinerPower();p.RefreshNodes(h,wires,nodes);
 Check(!BatteryBranchLimit.IsBlocked(1000),"lowest stable reference must win regardless of registration order");Check(nodes.Count(n=>BatteryBranchLimit.IsBlocked(n.ReferenceId))==25,"26-holder bank not limited");
 Near(p.Used(input),1000,"bank charging limit");p.Receive(input,1000);Near(nodes.Single(n=>n.ReferenceId==1000).Battery.PowerStored,5000,"winner charging");foreach(var n in nodes.Where(n=>n.ReferenceId!=1000))Near(n.Battery.PowerStored,4000,"inactive holder charge changed");
 input.PotentialLoad=0;p.BeginOwnTick();p.EndOwnTick();Near(p.Generated(output),5000,"bank offered multiple cells");p.Use(output,3000);Near(nodes.Single(n=>n.ReferenceId==1000).Battery.PowerStored,2000,"winner discharge");foreach(var n in nodes.Where(n=>n.ReferenceId!=1000))Near(n.Battery.PowerStored,4000,"inactive holder discharged");
 var separate=new CableNetwork();h.Output2Connection=Port(separate);wires.RemoveAll(w=>w.From.Owner==1001&&w.From.Contact==1);wires.Add(W(1001,1,0,2));p.RefreshNodes(h,wires,nodes);Check(!BatteryBranchLimit.IsBlocked(1001),"separation did not reactivate holder");Near(p.Generated(separate),4000,"separated holder has no output");
 Check(!p.CanJoinBatteryBranch(new(0,1),new(0,2)),"new branch join accepted");Check(p.CanJoinBatteryBranch(new(0,0),new(7000,0)),"unrelated wire rejected by legacy bank");
 p.StopOwnPower();Check(!BatteryBranchLimit.IsBlocked(1002),"destroyed cabinet retained policy");}
 static void CrossCabinet(){
 var(h1,i1,o1)=Host();var(h2,i2,o2)=Host();var first=Holder(2000);var second=Holder(2001);var p1=new CabinetCombinerPower();var p2=new CabinetCombinerPower();var wires1=new[]{W(0,0,2000,0),W(2000,1,0,1)};var wires2=new[]{W(0,0,2001,0),W(2001,1,0,1)};
 p2.RefreshNodes(h2,wires2,new[]{second});Near(p2.Generated(o2),4000,"initial isolated offer");i2.PotentialLoad=100000;Near(p2.Used(i2),1000,"initial isolated charge offer");
 h1.Output1Connection=Port(o2);p1.RefreshNodes(h1,wires1,new[]{first});Check(BatteryBranchLimit.IsBlocked(2001),"external cable failed to join cabinets");p2.Use(o2,4000);p2.Receive(i2,1000);Near(second.Battery.PowerStored,4000,"stale cross-cabinet offer changed blocked cell");Near(p2.Generated(o2),0,"blocked holder still supplied output");Near(p2.Used(i2),0,"blocked holder still charged");
 i2.PotentialLoad=0;h1.Output1Connection=Port(o1);p1.RefreshBatteryBranch();Check(!BatteryBranchLimit.IsBlocked(2001),"external split did not restore");Near(p2.Generated(o2),4000,"cross cabinet split output");
 // Input sockets also share native networks; a downstream cabinet cannot hide a bank.
 h2.Feeds[0]=Port(o1);var linked=new[]{W(0,0,0,1),W(0,0,2001,0),W(2001,1,0,1)};p2.RefreshNodes(h2,linked,new[]{second});Check(BatteryBranchLimit.IsBlocked(2001),"output to downstream input bypassed limit");
 p1.StopOwnPower();Check(!BatteryBranchLimit.IsBlocked(2001),"removing upstream holder did not reactivate");p2.StopOwnPower();}
 static void Domains(){
 var(h,input,output)=Host();var output2=new CableNetwork();h.Output2Connection=Port(output2);var a=Holder(3000);var b=Holder(3001);var breaker=new CabinetPowerNode{ReferenceId=3010,Conducting=true,RatedWatts=10000};var other=new CabinetPowerNode{ReferenceId=3011,Conducting=true,RatedWatts=10000};
 var wires=new List<CabinetWireSaveData>{W(0,0,3010,0),W(0,0,3011,0),W(3010,1,3000,0),W(3011,1,3001,0),W(3000,1,0,1),W(3001,1,0,2)};var p=new CabinetCombinerPower();p.RefreshNodes(h,wires,new[]{a,b,breaker,other});Check(!BatteryBranchLimit.IsBlocked(3000)&&!BatteryBranchLimit.IsBlocked(3001),"common charging feed merged separate branches");
 wires.Add(W(3000,1,3001,0));p.RefreshNodes(h,wires,new[]{a,b,breaker,other});Check(BatteryBranchLimit.IsBlocked(3001),"series holder bypass accepted");Near(p.Generated(output2),0,"disabled series holder conducts input to output");
 wires.RemoveAt(wires.Count-1);h.Output2Connection=Port(output);p.RefreshNodes(h,wires,new[]{a,b,breaker,other});Check(BatteryBranchLimit.IsBlocked(3001),"linked outputs bypass accepted");p.StopOwnPower();
 // Production physical-wire adapter inserts negative passive nodes.
 h.Output2Connection=Port(output2);wires=new(){W(3000,1,0,1),W(3001,1,0,1)};var bridge=new CabinetWirePower(wires,wires,_=>100000);p=new CabinetCombinerPower();p.RefreshNodes(h,bridge.Graph,new[]{a,b}.Concat(bridge.Nodes).ToArray());Check(BatteryBranchLimit.IsBlocked(3001),"virtual wire nodes split physical branch");p.StopOwnPower();
 }
 static void DownstreamMerge(){
 var(h,input,output)=Host();var a=Holder(4000);var b=Holder(4001);
 var first=new CabinetPowerNode{ReferenceId=4010,Conducting=true,RatedWatts=5000};var second=new CabinetPowerNode{ReferenceId=4011,Conducting=true,IsTransformer=true,TransferLimit=5000};
 var wires=new[]{W(4000,1,4010,0),W(4001,1,4011,0),W(4010,1,0,1),W(4011,1,0,1)};var p=new CabinetCombinerPower();p.RefreshNodes(h,wires,new[]{a,b,first,second});Check(BatteryBranchLimit.IsBlocked(4001),"breakers/transformers before common output bypassed limit");
 second.Conducting=false;p.RefreshNodes(h,wires,new[]{a,b,first,second});Check(!BatteryBranchLimit.IsBlocked(4001),"opening branch did not separate holders");
 // An empty winner reserves its branch: swapping cells cannot change priority.
 a.Battery=null;second.Conducting=true;p.RefreshNodes(h,wires,new[]{a,b,first,second});Check(BatteryBranchLimit.IsBlocked(4001),"cell presence changed deterministic ownership");Near(b.Battery.PowerStored,4000,"empty winner drained other cell");p.RemoveOwnTransformer(4011);p.RefreshBatteryBranch();Check(!BatteryBranchLimit.IsBlocked(4001),"tick resurrected removed transformer path");p.StopOwnPower();
 }
 static void Main(){Bank();CrossCabinet();Domains();DownstreamMerge();Console.WriteLine(count+" holder-limit checks passed: 26 holders, preserved native energy, separate/linked outputs, external networks, input links, series chains, stale offers, stable winner, virtual wires, preflight and reactivation.");}
}
