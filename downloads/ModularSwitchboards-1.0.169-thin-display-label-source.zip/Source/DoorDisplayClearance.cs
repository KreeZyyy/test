using System.Linq;using Assets.Scripts.GridSystem;using Assets.Scripts.Objects;using LibConstruct;using UnityEngine;
namespace ModularSwitchboards {
 internal static class DoorDisplayClearance {
  internal static Bounds ReservedBounds {
   get{var edge=DoorDisplayContour.Offset(.005f);float left=edge.Min(p=>p.x),right=edge.Max(p=>p.x),bottom=edge.Min(p=>p.y),top=System.Math.Max(edge.Max(p=>p.y),DoorDisplayLayout.NameY+.009f);return new Bounds(new Vector3((left+right)*.5f,(bottom+top)*.5f,0),new Vector3(right-left,top-bottom,.001f));}
  }
  internal static bool Overlaps(Bounds a,Bounds b)=>a.min.x<b.max.x+.001f&&a.max.x>b.min.x-.001f&&a.min.y<b.max.y+.001f&&a.max.y>b.min.y-.001f;
  internal static bool DisplayFits(PlacementBoard board,Grid3 p)=>Fits(board,p,ReservedBounds,null,true);
  internal static bool ControlFits(PlacementBoard board,Grid3 p,Structure control)=>control==null||Fits(board,p,control.Bounds,control,false);
  internal static bool LabelFits(PlacementBoard board,Grid3 p,bool emergency,bool display){
   Structure target=display?(Structure)DoorDisplayLabel.TargetDisplay(board,p):DoorLabel.Target(board,p,emergency);
   var bounds=display?ReservedBounds:emergency?new Bounds(new Vector3(0,0,.001f),new Vector3(.078f,.078f,.006f)):new Bounds(new Vector3(0,.015f,.001f),new Vector3(.044f,.072f,.006f));
   return target!=null&&Fits(board,p,bounds,target,display);
  }
  private static bool Fits(PlacementBoard board,Grid3 p,Bounds local,Structure ignore,bool display){
   if(!(board?.PrimaryHost is SwitchboardCabinet host))return false;
   var frame=host.IsRightBoard(board)?host.RightDoorOrigin:host.DoorOrigin;if(frame==null)return false;
   var candidate=local;candidate.center+=frame.InverseTransformPoint(board.GridToWorld(p));
   var door=host.DoorBoardFor(board);var labels=host.DoorLabelsFor(board);if(door==null||labels==null)return false;
   foreach(var other in door.Structures.Concat(labels.Structures).OfType<Structure>().Where(s=>!s.IsBeingDestroyed&&!s.IsCursor&&s!=ignore)){
    if(other is DoorDisplayLabel)continue; // Its display already reserves the full future label footprint.
    if(!display&&!(other is DoorSmartDisplay))continue;
    var bounds=other is DoorSmartDisplay?ReservedBounds:other.Bounds;
    var actual=CabinetWallMount.TransformedBounds(bounds,frame.worldToLocalMatrix*other.transform.localToWorldMatrix);
    if(Overlaps(candidate,actual))return false;
   }
   return true;
  }
 }
}
