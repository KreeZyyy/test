using System;
namespace ModularSwitchboards {
 internal static class DoorDisplayLayout {
  internal const int Width=2;
  internal const float NameY=.042f;
  internal static bool Fits(int x,int y,int z,int rotation,int minY)=>x%10==0&&x>=-10&&x<=0&&y%10==0&&y>=minY&&y<=10&&z==0&&rotation==0;
  internal static bool Overlaps(int x,int y,int width,int otherX,int otherY,int otherWidth)=>y==otherY&&x<otherX+otherWidth*10&&otherX<x+width*10;
 }
}
