using System.Xml.Serialization;
using Assets.Scripts;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Networking;
using Assets.Scripts.Objects;
using Assets.Scripts.Localization2;
using LibConstruct;
using UnityEngine;

namespace ModularSwitchboards
{
    public sealed class DinBreakerSaveData : StructureSaveData
    {
        [XmlElement] public PlacementBoardStructureSaveData RailBoard;
        [XmlElement] public bool Tripped;
    }

    public sealed class DinBreaker : Structure, IPlacementBoardStructure
    {
        public float RatedWatts=1000f;
        public bool IsFuseHolder;
        public int[] AllowedFuseKits=new int[0];
        public bool Tripped;
        private const ushort ModuleUpdate=32768;
        public bool Conducting=>!IsBeingDestroyed&&(IsFuseHolder?!Tripped&&Slots.Count==1&&Slots[0].Get() is MultiConstructor kit&&kit.Quantity==1&&System.Array.IndexOf(AllowedFuseKits,kit.PrefabHash)>=0:OnOff);
        internal void Trip()
        {
            if(!GameManager.RunSimulation||!Conducting)return;
            if(IsFuseHolder){var kit=Slots[0].Get() as MultiConstructor;if(kit!=null)kit.RemoveQuantity(1);}
            else {OnOff=false;}
            Tripped=true;NetworkUpdateFlags|=ModuleUpdate;
        }
        public PlacementBoard Board { get; set; }
        public PlacementBoard.BoardCell[] BoardCells { get; set; }
        public override void Awake()
        {
            base.Awake();
            BoardStructureHooks.Awake(this);
            DinBreakerModel.Refresh(this);
            if(IsFuseHolder&&Slots.Count==1)Slots[0].OnEnter+=()=>{if(GameManager.RunSimulation){Tripped=false;NetworkUpdateFlags|=ModuleUpdate;}};
        }
        public override Grid3 GetLocalGrid() => Board == null ? default(Grid3) : Board.WorldToGrid(Transform.position);

        public int ModuleWidth => 1;
        internal static bool CanPlace(PlacementBoard board, Grid3 position, int rotation)
            => board is DinModuleBoard modules && modules.CanPlace(position, rotation, 1);
        public override string GetContextualName(Interactable interactable)
        {
            if(IsFuseHolder&&interactable.Action==InteractableType.Slot1)return (Tripped?"Remove blown fuse":Conducting?"Remove fuse":"Insert fuse")+" — "+DinModuleCatalog.Rating(RatedWatts);
            if(!IsFuseHolder&&interactable.Action==InteractableType.OnOff)return (Tripped?"Reset":OnOff?"Switch OFF":"Switch ON")+" — "+DinModuleCatalog.Rating(RatedWatts);
            return base.GetContextualName(interactable);
        }
        public override DelayedActionInstance HandleSwitch(Interaction interaction,int slot,DelayedActionInstance result,bool doAction=true,bool force=false)
        {
            if(!IsFuseHolder||slot!=0)return base.HandleSwitch(interaction,slot,result,doAction,force);
            if(!(Board?.PrimaryHost is DinRail rail)||!rail.CanFitModules)return result.Fail("Open the cabinet first.");
            var source=interaction.SourceSlot;var destination=Slots[0];
            if(Tripped)
            {
                result.ActionMessage="Remove blown fuse";
                if(doAction&&GameManager.RunSimulation)
                {
                    // The cartridge was already consumed on blowing. Its broken
                    // model remains until this explicit removal, with no usable refund.
                    if(destination.Get()!=null)return result.Fail("Remove the remaining cartridge first.");
                    Tripped=false;NetworkUpdateFlags|=ModuleUpdate;
                }
                return result.Succeed();
            }
            if(destination.Get()!=null)
            {
                if(source?.Get()==null)return base.HandleSwitch(interaction,slot,result,doAction,force);
                if(!(source.Get() is MultiConstructor held)||!(destination.Get() is MultiConstructor installed)||
                    installed.Quantity!=1||held==installed||!held.CanStack(installed))
                    return result.Fail("Use an empty hand or hold the same Cable Fuse kit to remove the fuse.");
                if(held.Quantity>=held.MaxQuantity)return result.Fail("The fuse stack in your hand is full.");
                result.ActionMessage="Take fuse into stack";
                if(doAction&&GameManager.RunSimulation)
                {
                    // Native merge handles quantity replication, slot exit and destruction
                    // of the consumed one-unit stack. Never manufacture a refund item.
                    int before=held.Quantity;held.Merge(installed);
                    if(held.Quantity!=before+1)return result.Fail("Could not merge the fuse into your stack.");
                }
                return result.Succeed();
            }
            if(!(source?.Get() is MultiConstructor kit)||kit.Quantity<1||System.Array.IndexOf(AllowedFuseKits,kit.PrefabHash)<0)
                return result.Fail("Hold the matching Cable Fuse kit; one unit will be inserted.");
            result.ActionMessage="Insert one fuse";
            if(doAction&&GameManager.RunSimulation)
            {
                if(kit.Quantity==1){OnServer.MoveToSlot(kit,destination);if(destination.Get()!=kit)return result.Fail("Fuse slot is unavailable.");}
                else
                {
                    var one=kit.SplitStack(1,destination);
                    if(one==null){kit.AddQuantity(1);return result.Fail("Could not create the fuse cartridge.");}
                    if(destination.Get()!=one)OnServer.MoveToSlot(one,destination);
                    if(destination.Get()!=one){kit.AddQuantity(1);OnServer.Destroy(one);return result.Fail("Fuse slot is unavailable.");}
                }
            }
            return result.Succeed();
        }
        public override CanConstructInfo CanConstruct()
        {
            if ((IsCursor && PlacementBoard.CursorBoard != Board) || !(Board is DinModuleBoard modules)) return CanConstructInfo.InvalidPlacement("Aim at an installed DIN rail inside an open cabinet.");
            var position = Board.WorldToGrid(Transform.position);
            if (IsCursor)
            {
                position = new Grid3(position.x, 0, 0);
                Transform.SetPositionAndRotation(Board.GridToWorld(position), Board.IndexToRotation(0));
            }
            return CanPlace(Board, position, Board.RotationToIndex(Transform.rotation))
                ? CanConstructInfo.ValidPlacement : CanConstructInfo.InvalidPlacement("Choose a free module position on an installed rail.");
        }
        protected override CanConstructInfo CanDeconstruct()
            => IsFuseHolder&&HasOccupiedSlot?CanConstructInfo.InvalidPlacement("Remove the fuse first."):CabinetWiring.CabinetOf(this)?.Wiring.HasWires(ReferenceId)==true?CanConstructInfo.InvalidPlacement("Remove internal wires first."):Board?.PrimaryHost is DinRail host && host.CanFitModules
                ? CanConstructInfo.ValidPlacement : CanConstructInfo.InvalidPlacement("Open the cabinet first.");
        public override DelayedActionInstance AttackWith(Attack attack, bool doAction = true)
        {
            var cabinet=CabinetWiring.CabinetOf(this);
            if(cabinet!=null&&cabinet.Wiring.TryAttack(attack,doAction,out var wireAction))return wireAction;
            if(cabinet?.Wiring.HasWires(ReferenceId)==true && (attack.SourceItem?.PrefabName=="ItemWrench"||attack.SourceItem?.PrefabName=="ItemDrill"))return null;
            if (!(Board?.PrimaryHost is DinRail host) || !host.CanFitModules) return null;
            return base.AttackWith(attack, doAction);
        }
        public override bool PreventInteraction(out DelayedActionInstance failResult, Interactable interactable, Interaction interaction)
        {
            if ((interactable.Action == InteractableType.OnOff || interactable.Action == InteractableType.Slot1) &&
                (!(Board?.PrimaryHost is DinRail rail) || !rail.CanFitModules))
            {
                failResult = new DelayedActionInstance { Duration=0f, ActionMessage="Open the cabinet first." }.Fail();
                return true;
            }
            return base.PreventInteraction(out failResult, interactable, interaction);
        }
        public override DelayedActionInstance InteractWith(Interactable interactable, Interaction interaction, bool doAction=true)
        {
            if ((interactable.Action==InteractableType.OnOff || interactable.Action==InteractableType.Slot1) &&
                (!(Board?.PrimaryHost is DinRail rail) || !rail.CanFitModules))
                return new DelayedActionInstance { Duration=0f, ActionMessage="Open the cabinet first." }.Fail();
            var result=base.InteractWith(interactable, interaction, doAction);
            if(doAction&&GameManager.RunSimulation&&interactable.Action==InteractableType.OnOff&&OnOff){Tripped=false;NetworkUpdateFlags|=ModuleUpdate;}
            return result;
        }
        public override void BuildUpdate(RocketBinaryWriter writer,ushort flags){base.BuildUpdate(writer,flags);if(Thing.IsNetworkUpdateRequired(ModuleUpdate,flags)){writer.WriteBoolean(Tripped);writer.WriteBoolean(!IsFuseHolder&&OnOff);}}
        public override void ProcessUpdate(RocketBinaryReader reader,ushort flags){base.ProcessUpdate(reader,flags);if(Thing.IsNetworkUpdateRequired(ModuleUpdate,flags)){Tripped=reader.ReadBoolean();bool on=reader.ReadBoolean();if(!IsFuseHolder)OnOff=on;}}
        public override void OnDeregistered()
        {
            CabinetWiring.CabinetOf(this)?.Wiring.RemoveBreaker(ReferenceId);
            base.OnDeregistered();
            if (Board != null) BoardStructureHooks.OnDeregistered(this);
        }
        public override ThingSaveData SerializeSave()
        {
            ThingSaveData data = new DinBreakerSaveData();
            InitialiseSaveData(ref data);
            return data;
        }
        protected override void InitialiseSaveData(ref ThingSaveData data)
        {
            base.InitialiseSaveData(ref data);
            if (data is DinBreakerSaveData save){save.Tripped=Tripped;if(Board!=null)save.RailBoard=BoardStructureHooks.SerializeSave(this);}
        }
        public override void DeserializeSave(ThingSaveData data)
        {
            base.DeserializeSave(data);
            if (data is DinBreakerSaveData save){Tripped=save.Tripped;if(save.RailBoard!=null)BoardStructureHooks.DeserializeSave(this,save.RailBoard);}
        }
        public override void SerializeOnJoin(RocketBinaryWriter writer)
        {
            base.SerializeOnJoin(writer);
            BoardStructureHooks.SerializeOnJoin(writer, this);writer.WriteBoolean(Tripped);
        }
        public override void DeserializeOnJoin(RocketBinaryReader reader)
        {
            base.DeserializeOnJoin(reader);
            BoardStructureHooks.DeserializeOnJoin(reader, this);Tripped=reader.ReadBoolean();
        }
    }
}
