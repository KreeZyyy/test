# Lua / HTTP API — v0.1.3

Control API: `http://localhost:18766`, všechny endpointy vyžadují
`X-Station-Token: <Bridge.Token>`. JSON UTF-8, max 16 KiB body. API je vždy
IPv4 loopback-only. Media je oddělený listener s vlastním portem.

## POST /ask

```json
{
  "question": "Ahoj, řekni mi krátký vtip.",
  "source_ref_id": "123456",
  "conversation_id": "device:123456",
  "remember": true,
  "speak": true,
  "system_prompt": "Jsi Oasis. Odpovídej česky a stručně.",
  "speech_style": "Speak calmly in Czech.",
  "voice": "Kore",
  "max_output_tokens": 300,
  "temperature": 0.7
}
```

Povinné jsou `question` a `source_ref_id`. ReferenceId posílej jako **string**,
například `tostring(ic.host_info().ref_id)`. `conversation_id` je volitelné;
výchozí `device:<source_ref_id>`. Vlastní ID dovolí sdílet konverzaci mezi
skripty/zařízeními v daném WorldId. Povolené znaky: písmena ASCII, čísla, `_ . : -`.

`system_prompt`, `speech_style` a `voice` přepíší výchozí nastavení pro daný
dotaz, nemění trvale konfiguraci. Instrukce osobnosti nejsou odpověď systému a
nepředstavují oprávnění ke skutečným herním akcím. `model` a `tts_model` jsou
volitelné a fungují pouze při `Gemini.AllowLuaModelOverrides=true`. Hodnota
`max_output_tokens` smí pouze snížit serverový limit. `speak=false` znamená
bez volání TTS. `remember=false` nečte ani neukládá historii. Změna osobnosti
nezruší historii; pro čerstvou osobnost použij nové conversation_id nebo reset.

Přijetí: HTTP 202:

```json
{"id":"0123456789abcdef0123456789abcdef"}
```

Skutečné ID je 32 znaků hexadecimálního GUID. Plná paměť nebo současný dotaz ve
stejné konverzaci: 409. Fronta/cooldown/minutový limit: 429. Chybějící klíč: 503.
Neopakuj dotazy automaticky: po přijetí již mohou spotřebovat kredity.

## GET /jobs/<id>

Stavy `queued`, `running`, `done`, `error`. Příklad výsledku:

```json
{
  "id": "0123456789abcdef0123456789abcdef",
  "state": "done",
  "source_ref_id": "123456",
  "conversation_id": "device:123456",
  "text": "Ahoj!",
  "audio_url": "http://server:18767/audio/0123456789abcdef0123456789abcdef.wav",
  "audio_duration_seconds": 3.25,
  "audio_stop_after_seconds": 2.25,
  "audio_expires_utc": "2026-10-11T12:30:00Z",
  "voice_error": null,
  "memory_error": null,
  "reply_truncated": false,
  "error": null
}
```

Při selhání hlasu je stav stále `done`: `text` je dostupný, `audio_url=null`,
`voice_error` obsahuje bezpečnou chybu. Selhání uložení historie je oddělené
`memory_error`. Dlouhé odpovědi se omezí na MaxReplyChars a označí
`reply_truncated=true`; nad MaxSpeechChars se TTS nevolá. Vrácené ReferenceId
je routovací metadata převzaté od volajícího, nikoli serverový důkaz identity
fyzického chipu. Knihovna ověří, že výsledek odpovídá původnímu source_ref_id.

Polling jednou za sekundu stačí. HTTP timeout na jedno načtení 10 sekund.
Knihovna má celkový UI timeout 240 sekund; nastavení lze zvýšit, pokud
správce zvýší časový limit na serveru. Timeout/zavření UI neruší již přijatou
serverovou práci. Pozdní odpovědi nesmí přepsat další dotaz.

## Paměť

`GET /conversations` vrátí seznam `{id,turns,busy}` pro nakonfigurovaný WorldId.
`POST /memory/reset` s `{ "source_ref_id":"123456", "conversation_id":"optional" }`
smaže vybranou konverzaci. Bez conversation_id smaže paměť daného zařízení.
Reset běžící konverzace vrací 409. Neexistující konverzace vrací úspěch.
Všechny skripty s Bridge Tokenem mají společné oprávnění spravovat paměť.

## GET /health

Vrátí `status`, verzi, zda je nastavený Gemini klíč a zda je TTS povolené.
Nevrací klíč, token, historii ani cesty k souborům.

## Media GET /audio/<náhodné-id>.wav

Bez Bridge Tokenu, read-only, podporuje HEAD a jednoduchý byte Range.
Platnost a velikost souborů jsou omezené. Veřejný listener neposkytuje API,
konfiguraci, adresářový listing ani chat historii. Unikátní URL je přístupový
odkaz k danému zvuku, nikoli stabilní veřejná knihovna.

V Lua: `ss.play_sound(result.audio_url, {id="geminiai_voice", volume=0.8, loop=false})`.
Zastavení: `ss.stop_sound("geminiai_voice")`. Zvuk se váže na zařízení
volajícího ScriptedScreens skriptu; mod sám zvuk nepřehrává ani nerozesílá WAV
jako herní síťový paket.

SDK používá audio_stop_after_seconds pro časované zastavení uvnitř koncového
ochranného ticha; audio_duration_seconds udává skutečnou délku celého WAV. Každá odpověď
má vlastní sound ID a stejný job se nespouští dvakrát. Podrobnosti a omezení
časování jsou v AKTUALIZACE.txt. Při chybě zápisu zůstává kontext pouze v RAM.


## Místní diagnostika bez Gemini

`POST /memory/test` s prázdným JSON `{}` zapisuje, přepisuje a načte testovací
soubor v konverzační složce, pak ho smaže. Odpověď `{status:"ok"}`. Nemění chat.

`POST /audio/test` s `{"source_ref_id":"123"}` vrátí přímo hotový JobResult,
bez `/jobs` pollingu. WAV obsahuje tři tóny, audio_duration_seconds=5 a
 audio_stop_after_seconds=4. Nevolá Google, funguje i s prázdným Gemini klíčem.
Testovací WAV se počítá do MaxAudioFiles a respektuje ochranu a limity cache.
Oba endpointy jsou pouze na control portu a vyžadují Bridge Token.

SDK: `ai:test_memory(callback)`, `ai:test_audio(callback)` a
`ai:play_audio(result,true)` pro výslovné znovupřehrání stejné odpovědi.
Výchozí volání `play_audio(result)` stále blokuje opětovné spuštění stejného jobu.
`audio_start_grace` je výchozí 0; u nové verze není nutné přidávat rezervu
pro běžný tick, protože ji obsahuje koncové ticho WAV.

Na disku se drží maximálně MaxAudioFiles (výchozí 5) WAV, další soubor vytěsní
nejstarší nechráněný. Pokud jsou všechny pozice chráněné nebo rezervované,
nový hlas se nevygeneruje. Stažení chrání soubor po dobu otevřeného streamu,
pak ještě délku WAV + 15 s. Nový soubor má 15 s na doručení. Jde o odhad
přehrávání, nikoli klientský callback z Unity; podrobnosti v AKTUALIZACE.txt.

## Piper (0.1.3)

`GET /health` uvádí `speech_provider`. Hostitel vybírá `[Speech] Provider`: Gemini
nebo Piper. Lua nemůže měnit executable/model/provider. V režimu Piper se
`tts_model` odmítá; Gemini `voice` a `speech_style` místní hlas nemění.

Autentizovaný `POST /speech/test` s `{"source_ref_id":"123"}` vrací HTTP 202
a `{id}`, poté se čte běžné `/jobs/{id}`. SDK: `ai:test_piper(callback)`.
Vyžaduje povolený hlas a Provider=Piper; jinak HTTP 409. Pevná česká věta
nevolá textové ani hlasové Google API, nepotřebuje klíč a neukládá konverzaci.
Platí běžné limity fronty, požadavků a WAV cache. Piper vytváří mono PCM16 WAV
s nativní frekvencí modelu (například 22050 Hz), s obvyklým ochranným tichem.
Chyba procesu/timeout se vrací jako voice_error, textová odpověď zůstává.
