-- Put geminiai.lua into a library chip with the --@module geminiai annotation on the same network.
local GeminiAI = require("geminiai")
local ai = GeminiAI.new({
    token = "PASTE_LOCAL_BRIDGE_TOKEN_HERE",
    system_prompt = "Jsi klidný palubní asistent. Odpovídej stručně česky.",
    voice = "Kore",
})
local sent, err = ai:ask("Ahoj! Řekni mi krátký vesmírný vtip.", {speak=true}, function(result, error)
    if error then print(error); return end
    print(result.text)
    if result.audio_url then
        local sound, play_error = ai:play_audio(result)
        if not sound and play_error then print(play_error) end
    elseif result.voice_error then print(result.voice_error) end
end)
if not sent then print(err) end
function tick(dt) ai:tick(dt) end
