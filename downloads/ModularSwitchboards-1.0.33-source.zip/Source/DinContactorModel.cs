using System;
using System.Collections.Generic;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Motherboards;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class DinContactorModel
    {
        internal const string PrefabName="StructureDinContactor";
        internal static void Install(DinBreaker module)
        {
            var model=module.transform.Find("DinBreakerModel");
            foreach(var name in new[]{"BreakerLever","BreakerIndicator","BreakerControl"}){var t=model.Find(name);if(t!=null)UnityEngine.Object.DestroyImmediate(t.gameObject);}
            var oldView=module.GetComponent<BreakerSwitchView>();if(oldView!=null)UnityEngine.Object.DestroyImmediate(oldView);
            var mesh=Build();
            model.GetComponent<MeshFilter>().sharedMesh=mesh;
            var hit=model.GetComponent<BoxCollider>();hit.center=mesh.bounds.center;hit.size=mesh.bounds.size;
            module.Interactables=new List<Interactable>();module.HasOnOffState=false;module.ContactorClosed=false;
            var state=module.BuildStates[0];state.Interactables=module.Interactables;state.Colliders=new List<Collider>{hit};
            module.Thumbnail=CabinetIcons.Get("DinContactor");module.Thumbnails=new Sprite[0];state.Thumbnail=module.Thumbnail;
            if(module.Blueprint!=null)
            {
                var ghost=new Mesh{name="ContactorBlueprint"};var pieces=new CombineInstance[5];
                for(int i=0;i<5;i++)pieces[i]=new CombineInstance{mesh=mesh,subMeshIndex=i,transform=Matrix4x4.Scale(DinBreakerModel.VisualScale)};
                ghost.CombineMeshes(pieces,true,true);ghost.RecalculateBounds();
                module.Blueprint.GetComponent<MeshFilter>().sharedMesh=ghost;
                var wireframe=module.Blueprint.GetComponent<Assets.Scripts.UI.Wireframe>();wireframe.BlueprintBounds=ghost.bounds;
            }
            module.CacheStates(true);
            var slider=new GameObject("ContactorMechanicalSlider"){layer=module.gameObject.layer};slider.transform.SetParent(model,false);
            slider.transform.localPosition=new Vector3(0,.007f,0);
            Panel(slider.transform,true);Panel(slider.transform,false);
            var view=module.gameObject.AddComponent<DinContactorView>();view.Owner=module;view.Slider=slider.transform;
            Font font=null;foreach(var name in new[]{"LegacyRuntime.ttf","Arial.ttf"}){try{font=Resources.GetBuiltinResource<Font>(name);}catch(Exception){}if(font!=null)break;}
            if(font!=null)
            {
                Label(model,module.gameObject.layer,font,"IN",.004f,.022f,.0023f);
                Label(model,module.gameObject.layer,font,"A1",-.004f,.022f,.0023f);
                Label(model,module.gameObject.layer,font,"OUT",0,-.022f,.003f);
                foreach(bool on in new[]{true,false})
                {
                    var text=Label(slider.transform,module.gameObject.layer,font,on?"ON":"OFF",0,on?.005f:-.005f,.0065f);
                    text.transform.localPosition=new Vector3(0,on?.005f:-.005f,.0621f);text.color=Color.white;
                    text.GetComponent<MeshRenderer>().sharedMaterial=new Material(DepthLabelText.For(font)){name="Contactor.WhiteMechanicalInk",color=Color.white};
                }
            }
        }
        internal static Mesh Build()
        {
            var body=DinBreakerModel.Build(plain:true);
            // Replace the single top terminal with two independently aimed terminals.
            var cropped=NativeMeshCrop.Outside(body,new Bounds(new Vector3(0,.030f,.059f),new Vector3(.011f,.011f,.005f)),"Contactor.Housing");
            var cavity=NativeMeshCrop.Outside(cropped,new Bounds(new Vector3(0,.002f,.063f),new Vector3(.010f,.033f,.012f)),"Contactor.WindowCavity");
            UnityEngine.Object.DestroyImmediate(cropped);cropped=cavity;
            var v=new List<Vector3>(cropped.vertices);var n=new List<Vector3>(cropped.normals);var g=new List<int>[5];for(int i=0;i<5;i++)g[i]=new List<int>(cropped.GetTriangles(i));
            foreach(float x in new[]{-.004f,.004f})
            {
                RoundedGeometry.Box(v,n,g[4],new Vector3(x,.030f,.058f),new Vector3(.0057f,.009f,.0015f),.0004f);
                RoundedGeometry.Box(v,n,g[3],new Vector3(x,.030f,.059f),new Vector3(.0035f,.001f,.0005f),.0001f);
                RoundedGeometry.Box(v,n,g[4],new Vector3(x,.03755f,.029f),new Vector3(.0035f,.0003f,.006f),.0001f);
            }
            // A real recessed aperture: the sliding coloured strip sits behind the
            // opaque fascia, so the unused half cannot show through or overlap it.
            RoundedGeometry.Box(v,n,g[3],new Vector3(0,.002f,.0575f),new Vector3(.010f,.033f,.001f),.0002f);
            foreach(float x in new[]{-.0048f,.0048f})
                RoundedGeometry.Box(v,n,g[4],new Vector3(x,.002f,.0615f),new Vector3(.001f,.011f,.006f),.00015f);
            foreach(float y in new[]{-.009f,.013f})
                RoundedGeometry.Box(v,n,g[3],new Vector3(0,y,.0635f),new Vector3(.010f,.012f,.001f),.0002f);
            // Metal rim and shallow fastener slots keep the same DIN vocabulary.
            foreach(float x in new[]{-.0051f,.0051f})
                RoundedGeometry.Box(v,n,g[4],new Vector3(x,.002f,.0644f),new Vector3(.0007f,.0114f,.001f),.0002f);
            foreach(float y in new[]{-.0035f,.0075f})
                RoundedGeometry.Box(v,n,g[4],new Vector3(0,y,.0644f),new Vector3(.0108f,.0008f,.001f),.0002f);
            foreach(float y in new[]{-.0165f,.0175f})
            {
                RoundedGeometry.Box(v,n,g[4],new Vector3(0,y,.0642f),new Vector3(.0024f,.0024f,.0005f),.0005f);
                RoundedGeometry.Box(v,n,g[3],new Vector3(0,y,.0645f),new Vector3(.0016f,.0003f,.0002f),.00005f);
            }
            RoundedGeometry.Box(v,n,g[4],new Vector3(0,-.022f,.0642f),new Vector3(.010f,.004f,.0007f),.0002f);
            foreach(float x in new[]{-.004f,.004f})RoundedGeometry.Box(v,n,g[4],new Vector3(x,.022f,.0642f),new Vector3(.006f,.004f,.0007f),.0002f);
            var mesh=new Mesh{name="DIN.Contactor.Body"};mesh.SetVertices(v);mesh.SetNormals(n);mesh.subMeshCount=5;for(int i=0;i<5;i++)mesh.SetTriangles(g[i],i);CabinetGeometry.ApplyNativeUv(mesh);mesh.RecalculateBounds();
            UnityEngine.Object.DestroyImmediate(body);UnityEngine.Object.DestroyImmediate(cropped);return mesh;
        }
        private static void Panel(Transform slider,bool on)
        {
            var go=new GameObject(on?"ContactorOnFlag":"ContactorOffFlag"){layer=slider.gameObject.layer};go.transform.SetParent(slider,false);
            go.AddComponent<MeshFilter>().sharedMesh=DinBreakerModel.ControlMesh(go.name,new Vector3(0,on?.005f:-.005f,.0615f),new Vector3(.0088f,.010f,.0007f));
            var renderer=go.AddComponent<MeshRenderer>();renderer.sharedMaterials=CabinetGeometry.Materials;
            for(int role=0;role<5;role++)
            {
                var block=new MaterialPropertyBlock();block.SetFloat(Thing.DiffuseIndexPropertyID,(int)(on?ColorType.Green:ColorType.Red));
                block.SetColor(Thing.EMISSION_COLOR,Color.black);renderer.SetPropertyBlock(block,role);
            }
        }
        private static TextMesh Label(Transform model,int layer,Font font,string value,float x,float y,float width)
        {
            var go=new GameObject("ContactorLabel."+value){layer=layer};go.transform.SetParent(model,false);go.transform.localPosition=new Vector3(x,y,.065f);go.transform.localRotation=Quaternion.Euler(0,180,0);
            var text=go.AddComponent<TextMesh>();text.font=font;text.fontSize=64;text.characterSize=.002f;text.anchor=TextAnchor.MiddleCenter;text.alignment=TextAlignment.Center;text.text=value;text.color=Color.black;
            var size=go.GetComponent<MeshRenderer>().localBounds.size;go.transform.localScale=Vector3.one*Mathf.Min(width/Mathf.Max(.0001f,size.x),.004f/Mathf.Max(.0001f,size.y));DepthLabelText.Apply(text);return text;
        }
    }
    // Only the visual follows the replicated contact state. Initial load/join/preview
    // snaps silently; subsequent changes animate and play one local native clack.
    public sealed class DinContactorView:MonoBehaviour
    {
        public DinBreaker Owner;
        public Transform Slider;
        private readonly ContactorIndicatorMotion motion=new ContactorIndicatorMotion();
        private void LateUpdate()
        {
            if(Owner==null)Owner=GetComponent<DinBreaker>();
            if(Owner==null||Slider==null)return;
            bool active=!Owner.IsCursor&&!Owner.IsBeingDestroyed&&Owner.Board!=null;
            bool changed=motion.Tick(active,Owner.ContactorClosed,Time.deltaTime);
            Slider.localPosition=new Vector3(0,.002f+motion.Offset,0);
            if(changed)BreakerSwitchAudio.Play(Owner,Owner.ContactorClosed);
        }
    }
}
