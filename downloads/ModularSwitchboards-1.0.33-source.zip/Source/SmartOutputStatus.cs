namespace ModularSwitchboards
{
    internal enum SmartOutputLight { Off, Disconnected, Connected }
    internal static class SmartOutputStatus
    {
        // The indicator reports a usable bus/data connection, independently of IC execution or power.
        internal static bool Connected(DinBreaker module)
        {
            if(module==null||!module.IsSmartOutputModule||module.IsBeingDestroyed||module.IsCursor)return false;
            var core=SmartBus.Core(module);
            return core!=null&&core.Cabinet?.Wiring.SmartCable(module.ReferenceId)?.CableNetwork!=null;
        }
        internal static SmartOutputLight Light(DinBreaker module)
        {
            if(module==null||!module.IsSmartOutputModule||module.IsBeingDestroyed||module.IsCursor)return SmartOutputLight.Off;
            var core=SmartBus.Core(module);
            if(core==null||!core.Powered||!core.OnOff)return SmartOutputLight.Off;
            return core.Cabinet?.Wiring.SmartCable(module.ReferenceId)?.CableNetwork!=null?SmartOutputLight.Connected:SmartOutputLight.Disconnected;
        }
    }
}
