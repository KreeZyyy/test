using Assets.Scripts.Objects;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class SmartOutputScrewTarget
    {
        internal static SelectionInstance Selection(SmartContactor owner,Interactable control)
        {
            // Native tool previews default to the whole Thing; interactables add
            // another 10 mm on every side. Use only this screw's actual target.
            if(control.Collider is BoxCollider box)
            {
                var scale=box.transform.lossyScale;
                return new SelectionInstance{Position=box.transform.position,Rotation=box.transform.rotation,
                    Bounds=new Bounds(Vector3.Scale(box.center,scale),Vector3.Scale(box.size,new Vector3(Mathf.Abs(scale.x),Mathf.Abs(scale.y),Mathf.Abs(scale.z)))),
                    ParentThingRefernceId=owner.ReferenceId,InteractableId=control.InteractableId};
            }
            var selection=owner.GetSelection(control.Collider);selection.InteractableId=control.InteractableId;return selection;
        }
        internal static void AfterSelection(Interactable __instance,ref SelectionInstance __result)
        {
            if(__instance.Parent is SmartContactor owner&&__instance.Action==InteractableType.Mode&&__instance.Collider!=null)
                __result=Selection(owner,__instance);
        }
        internal static bool Contains(Interactable control,Vector3 worldPoint)
        {
            if(control?.Collider is BoxCollider box)
            {
                // Raycast points lie on the surface; allow only tiny float error
                // after inverse transforms so the screwdriver preview cannot flicker.
                var size=box.size;size.x+=.0001f;size.y+=.0001f;size.z+=.0001f;
                return new Bounds(box.center,size).Contains(box.transform.InverseTransformPoint(worldPoint));
            }
            return false;
        }
    }
}
