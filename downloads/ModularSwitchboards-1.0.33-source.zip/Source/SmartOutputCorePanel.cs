using System;
using System.Linq;
using System.Collections.Generic;
using Assets.Scripts;
using UnityEngine;
namespace ModularSwitchboards
{
    // Copy only the prepared Core's render surfaces: no second Thing, IC holder,
    // network device, power consumer or display logic is instantiated.
    internal static class SmartOutputCorePanel
    {
        internal const float Scale=.55f;
        internal static readonly Vector3 Center=new Vector3(SmartContactor.CenterX*DinBreakerModel.VisualScale.x,.00135f,SmartModuleModel.DisplayCenter.z);
        internal static void Install(SmartContactor module,SmartContactorView view,SmartModule core)
        {
            if(core==null||core.ScreenMesh==null||core.DigitTransform==null)throw new InvalidOperationException("Prepared Core LED panel unavailable.");
            var mount=new GameObject("CoreLEDDisplayMount"){layer=module.gameObject.layer};mount.transform.SetParent(module.transform,false);
            mount.transform.localPosition=Center-SmartModuleModel.DisplayCenter*Scale;mount.transform.localScale=Vector3.one*Scale;
            var frames=new Dictionary<Transform,Transform>{{core.transform,mount.transform}};
            foreach(var source in core.GetComponentsInChildren<MeshRenderer>(true).Where(r=>r==core.ScreenMesh||r.name=="NativeLEDBezel"||r.name=="NativeLEDHousingDetails"))
            {
                var mesh=source.GetComponent<MeshFilter>()?.sharedMesh;if(mesh==null)continue;
                var frame=CopyFrame(source.transform,frames,module.gameObject.layer);
                frame.gameObject.AddComponent<MeshFilter>().sharedMesh=mesh;var renderer=frame.gameObject.AddComponent<MeshRenderer>();
                renderer.shadowCastingMode=source.shadowCastingMode;renderer.receiveShadows=source.receiveShadows;renderer.lightProbeUsage=source.lightProbeUsage;renderer.reflectionProbeUsage=source.reflectionProbeUsage;
                NativePortSurface.Capture(source,renderer);
            }
            var digits=new GameObject("OutputAddressDisplay"){layer=module.gameObject.layer};
            digits.transform.SetParent(CopyFrame(core.DigitTransform.parent,frames,module.gameObject.layer),false);
            // Preserve the native transform chain (including mirrored axes).
            // SetDisplay owns only the leaf's centering offset, so start it at zero.
            digits.transform.localRotation=core.DigitTransform.localRotation;digits.transform.localScale=core.DigitTransform.localScale;
            view.Digits=digits.transform;view.MaxPixels=(int)(core.MaxPixelWidth/GameManager.DigitPixel);
        }
        internal static void ApplyWidth(SmartContactor module,float ratio)
        {
            var mount=module.transform.Find("CoreLEDDisplayMount");if(mount==null)return;
            float scale=Scale*ratio;var center=Center;if(module.ModuleWidth==1)center.x=0;
            mount.localScale=Vector3.one*scale;mount.localPosition=center-SmartModuleModel.DisplayCenter*scale;
        }
        private static Transform CopyFrame(Transform source,Dictionary<Transform,Transform> frames,int layer)
        {
            if(frames.TryGetValue(source,out var existing))return existing;
            var parent=CopyFrame(source.parent,frames,layer);var frame=new GameObject(source.name){layer=layer}.transform;
            frame.SetParent(parent,false);frame.localPosition=source.localPosition;frame.localRotation=source.localRotation;frame.localScale=source.localScale;
            frames.Add(source,frame);return frame;
        }
    }
}
