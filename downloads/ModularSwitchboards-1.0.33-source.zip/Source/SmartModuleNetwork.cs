using System;
using System.Linq;
using Assets.Scripts.Networks;
using Assets.Scripts.Objects.Electrical;
using Assets.Scripts.Objects.Pipes;
using HarmonyLib;
namespace ModularSwitchboards
{
    internal static class SmartModuleNetwork
    {
        private static readonly System.Reflection.PropertyInfo PowerCable=AccessTools.Property(typeof(Device),"PowerCable");
        private static readonly System.Reflection.PropertyInfo PowerCables=AccessTools.Property(typeof(Device),"PowerCables");
        private static readonly System.Reflection.PropertyInfo DataCables=AccessTools.Property(typeof(Device),"DataCables");
        internal static void Refresh(SmartModule module)
        {
            var power=module.Cabinet?.Wiring.SmartPowerCable(module);
            var feeds=SmartBus.Outputs(module).Select(m=>module.Cabinet?.Wiring.SmartCable(m.ReferenceId))
                .Where(c=>c?.CableNetwork!=null).Distinct().ToArray();
            var data=feeds.FirstOrDefault();
            foreach(var network in module.BoundDataNetworks.Concat(new[]{module.BoundPowerNetwork}).Where(n=>n!=null).Distinct())Normalize(module,network);
            if(power==module.BoundPowerCable&&power?.CableNetwork==module.BoundPowerNetwork&&feeds.SequenceEqual(module.BoundDataCables)&&feeds.Select(c=>c.CableNetwork).SequenceEqual(module.BoundDataNetworks)&&module.PowerCable==power&&module.PowerCables.SequenceEqual(power?.CableNetwork==null?Array.Empty<Cable>():new[]{power})&&module.DataCable==data&&module.DataCables.SequenceEqual(feeds)&&module.InputNetwork1==data?.CableNetwork&&module.OutputNetwork1==null&&Registered(module,power)&&feeds.All(c=>Registered(module,c)))return;
            var oldNetworks=module.BoundDataNetworks.Concat(new[]{module.BoundPowerNetwork,module.BoundNetwork}).Where(n=>n!=null).Distinct().ToArray();
            if(module.BoundPowerNetwork!=power?.CableNetwork)module.ClearSupplyPower();
            module.BoundPowerCable=power;module.BoundPowerNetwork=power?.CableNetwork;
            module.BoundDataCables=feeds;module.BoundDataNetworks=feeds.Select(c=>c.CableNetwork).ToArray();module.BoundCable=data;module.BoundNetwork=data?.CableNetwork;
            module.DataCable=data;PowerCable.SetValue(module,power,null);
            PowerCables.SetValue(module,power?.CableNetwork==null?Array.Empty<Cable>():new[]{power},null);
            DataCables.SetValue(module,feeds,null);
            module.InputNetwork1=data?.CableNetwork;module.OutputNetwork1=null;
            var wanted=(power?.CableNetwork==null?Array.Empty<Cable>():new[]{power}).Concat(feeds).Distinct().ToArray();
            var newNetworks=wanted.Select(c=>c.CableNetwork).Distinct().ToArray();
            foreach(var network in oldNetworks.Where(n=>!newNetworks.Contains(n)))network.RemoveDevice(module);
            foreach(var cable in wanted)cable.CableNetwork.AddDevice(cable,module);
            foreach(var network in newNetworks)
            {
                var registration=network.GetDeviceRegistration(module);
                if(registration!=null)foreach(var stale in registration.Where(c=>!wanted.Any(w=>w==c&&w.CableNetwork==network)).ToArray())network.RemoveDevice(stale,module);
                network.DirtyPowerAndDataDeviceLists();network.RefreshNetworkDevice(module);
            }
        }
        private static bool Registered(SmartModule module,Cable cable)=>cable?.CableNetwork==null||cable.CableNetwork.GetDeviceRegistration(module)?.Contains(cable)==true;
        private static void Normalize(SmartModule module,CableNetwork network)
        {
            if(network==null)return;bool changed=false,found=false;
            lock(network.DeviceList)
                for(int i=network.DeviceList.Count-1;i>=0;i--)
                    if(ReferenceEquals(network.DeviceList[i],module)){if(found){network.DeviceList.RemoveAt(i);changed=true;}else found=true;}
            if(changed){network.DirtyPowerAndDataDeviceLists();network.RefreshNetworkDevice(module);}
        }
        internal static void Unbind(SmartModule module)
        {
            foreach(var network in module.BoundDataNetworks.Concat(new[]{module.BoundPowerNetwork,module.BoundNetwork}).Where(n=>n!=null).Distinct())network.RemoveDevice(module);
            module.BoundDataCables=Array.Empty<Cable>();module.BoundDataNetworks=Array.Empty<CableNetwork>();module.BoundCable=null;module.BoundNetwork=null;module.BoundPowerCable=null;module.BoundPowerNetwork=null;module.DataCable=null;
            PowerCable.SetValue(module,null,null);PowerCables.SetValue(module,Array.Empty<Cable>(),null);DataCables.SetValue(module,Array.Empty<Cable>(),null);
            module.InputNetwork1=null;module.OutputNetwork1=null;
        }
    }
}
