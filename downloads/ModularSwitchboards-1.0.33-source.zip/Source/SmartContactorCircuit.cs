using System.Collections.Generic;using System.Linq;
namespace ModularSwitchboards
{
    internal static class SmartContactorCircuit
    {
        internal const int OutputPin=1;
        internal static bool Allowed(CabinetWireEnd a,CabinetWireEnd b,IEnumerable<long> outputs,IEnumerable<long> coils)
        {
            var ids=new HashSet<long>(outputs);var contactors=new HashSet<long>(coils);
            foreach(var end in new[]{a,b})if(ids.Contains(end.Owner))
            {
                var other=end.Equals(a)?b:a;
                if(end.Contact!=OutputPin||other.Contact!=ContactorCircuit.CoilPin||!contactors.Contains(other.Owner)||ids.Contains(other.Owner))return false;
            }
            return true;
        }
        internal static IEnumerable<CabinetWireSaveData> ValidWires(IEnumerable<CabinetWireSaveData> wires,IEnumerable<long> outputs,IEnumerable<long> coils)
        {
            var ids=outputs.ToArray();var contacts=coils.ToArray();
            return wires.Where(w=>Allowed(w.From,w.To,ids,contacts));
        }
    }
}
