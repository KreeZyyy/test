using System;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class SmartControlHeader
    {
        internal static void Install(SmartContactor module,Transform model,SmartContactorView view,DinBreaker net)
        {
            var source=net.transform.Find("DinBreakerModel");
            var plate=Copy(source,model,"SmartOutputHeader","OutputHeader");
            plate.localPosition=new Vector3(SmartContactor.CenterX,0,.0009f);plate.localScale=new Vector3(.029f/.0127f,1,1);
            var lens=Copy(source,model,"SmartOutputLens","OutputStatusLED");
            lens.localPosition=new Vector3(SmartContactor.CenterX+.0095f,SmartModuleHeaderLayout.CenterY,.065f);view.Lens=lens.GetComponent<MeshRenderer>();
            var glow=Copy(source,model,"SmartOutputGlow","OutputGlow");
            glow.localPosition=new Vector3(SmartContactor.CenterX+.0095f,SmartModuleHeaderLayout.CenterY,.0659f);view.Glow=glow.GetComponent<Light>();
            if(source.Find("SmartOutputText")==null)return; // NET also permits a font-less server prefab.
            var caption=Copy(source,model,"SmartOutputText","OutputHeaderText");
            caption.localPosition=new Vector3(SmartContactor.CenterX-.0015f,SmartModuleHeaderLayout.CenterY,.06505f);
            var text=caption.GetComponent<TextMesh>();text.text="Output";text.font.RequestCharactersInTexture(text.text,text.fontSize,text.fontStyle);
            // The same font, bold style, white ink, depth test and emission as NET.
            // Fit again after Unity regenerates the cloned text's glyph mesh.
            var ink=new Material(caption.GetComponent<MeshRenderer>().sharedMaterial){name="Switchboards.Output.HeaderInk"};
            ink.mainTexture=text.font.material.mainTexture;caption.GetComponent<MeshRenderer>().sharedMaterial=ink;
            view.HeaderText=text;
        }
        private static Transform Copy(Transform source,Transform target,string name,string cloneName)
        {
            var original=source.Find(name);if(original==null)throw new InvalidOperationException("NET header reference unavailable: "+name);
            var copy=UnityEngine.Object.Instantiate(original.gameObject,target,false);copy.name=cloneName;return copy.transform;
        }
    }
}
