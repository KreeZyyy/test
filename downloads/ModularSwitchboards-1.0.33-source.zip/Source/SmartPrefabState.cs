using System;
using System.Linq;
using Assets.Scripts.Objects;
using HarmonyLib;
namespace ModularSwitchboards
{
    internal static class SmartPrefabState
    {
        private static readonly System.Reflection.FieldInfo SerializedState=AccessTools.Field(typeof(Interactable),"_state");
        internal static void Configure(Thing module,bool onByDefault=true)
        {
            var on=module.Interactables.FirstOrDefault(i=>i.Action==InteractableType.OnOff);
            var powered=module.Interactables.FirstOrDefault(i=>i.Action==InteractableType.Powered);
            if(on==null||powered==null)throw new InvalidOperationException("Native LED prefab requires OnOff and Powered interactions.");
            if(SerializedState==null)throw new MissingFieldException(typeof(Interactable).FullName,"_state");
            // This is serialized prefab authoring, before Unity runs Awake.
            // State's public setter invokes the live LED, sound and network
            // callbacks; those require the caches that Awake has not built yet.
            SerializedState.SetValue(on,onByDefault?1:0);
            SerializedState.SetValue(powered,0);
            module.CacheStates(true);
        }
    }
}
