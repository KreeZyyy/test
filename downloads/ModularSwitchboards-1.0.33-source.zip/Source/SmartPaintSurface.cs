using System;
using Assets.Scripts.Objects;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class SmartPaintSurface
    {
        internal static bool IsPainted(string name)=>name=="DinBreakerModel"||name=="NativeLEDBezel";
        internal static int WhiteSubmesh(Material[] materials,Material white)
        {
            for(int i=0;i<materials.Length;i++)
                if(materials[i]!=null&&(materials[i]==white||materials[i].name=="ColorWhite"))return i;
            throw new InvalidOperationException("Native LED white bezel material unavailable; refusing to paint the dark backing.");
        }
        internal static Mesh ExtractFrame(Mesh native,int framePart)
        {
            var indices=native.GetTriangles(framePart);
            if(indices.Length==0)throw new InvalidOperationException("Native LED white bezel extraction empty.");
            var painted=UnityEngine.Object.Instantiate(native);painted.name="Smart.PaintableLEDBezel";
            painted.subMeshCount=5;
            for(int role=0;role<5;role++)painted.SetTriangles(role==1?indices:new int[0],role);
            CabinetGeometry.ApplyNativeUv(painted);
            // Original UVs and all other material slots stay on the fixed backing.
            native.SetTriangles(new int[0],framePart);
            return painted;
        }
        internal static void RestoreNative(Thing owner)
        {
            if(!(owner is SmartModule)&&!(owner is SmartContactor))return;
            foreach(var surface in owner.GetComponentsInChildren<NativePortSurface>(true))
            {
                var renderer=surface.GetComponent<MeshRenderer>();
                if(renderer==null||renderer.GetComponentInParent<Thing>()!=owner||IsPainted(renderer.name))continue;
                // Empty native per-material blocks cannot override an inherited
                // global tint/emission, so clear it before restoring the template.
                renderer.SetPropertyBlock(null);
                surface.Restore();
            }
        }
    }
}
