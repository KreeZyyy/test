using System;
using System.Collections.Generic;
using System.Linq;
using Assets.Scripts.Objects;
namespace ModularSwitchboards
{
    internal static class VendingSelection
    {
        internal static Structure[] Select(IEnumerable<Structure> structures)=>
            (structures??Enumerable.Empty<Structure>()).Where(p=>p!=null&&!string.IsNullOrEmpty(p.PrefabName)&&p.PrefabName.IndexOf("Vending",StringComparison.OrdinalIgnoreCase)>=0)
                .GroupBy(p=>p.PrefabName).Select(g=>g.First())
                .OrderBy(p=>p.PrefabName=="StructureVendingMachine"?0:1).ThenBy(p=>p.PrefabName,StringComparer.Ordinal).ToArray();
    }
}
