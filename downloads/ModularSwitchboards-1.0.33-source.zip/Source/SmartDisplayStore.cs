using Assets.Scripts.Objects.Pipes;
using Assets.Scripts.Objects.Electrical;
using Assets.Scripts.Objects.Motherboards;
namespace ModularSwitchboards
{
    internal static class SmartDisplayStore
    {
        // IC10 skips SetLogicValue when the stored value already matches. Keep
        // its comparison/read value intact, but record the actual store intent.
        internal static double ReadForStore(ILogicable device,LogicType type)
        {
            double value=device.GetLogicValue(type);
            if(type==LogicType.Setting&&device is SmartModule smart&&smart.CanLogicWrite(type))smart.RecordDisplayWrite();
            return value;
        }
    }
}
