using System;
using System.Collections.Generic;
using System.Linq;
using Assets.Scripts.Networks;
using Assets.Scripts.Objects.Items;
using Assets.Scripts.Objects.Pipes;

namespace ModularSwitchboards
{
    // Activated only in cabinets using the new module. The original non-battery
    // bridge remains unchanged. Native BatteryCell owns charge/save/network state.
    internal sealed class CabinetBatteryPower
    {
        private sealed class Source
        {
            internal BatteryCell Cell;
            internal bool Charge;
            internal readonly bool[] Output=new bool[3];
            internal readonly long[][] Paths=new long[3][];
            internal long[] ChargePath=new long[0];
        }
        private sealed class Reservation
        {
            internal Source Source;internal float Energy;internal long[] Path;
        }
        private sealed class Offer
        {
            internal int Branch,Revision;internal float External;internal long[] Path;
            internal readonly List<Reservation> Cells=new List<Reservation>();
            internal float Total=>External+Cells.Sum(c=>c.Energy);
        }
        private readonly Dictionary<CableNetwork,Offer> offers=new Dictionary<CableNetwork,Offer>();
        private sealed class State
        {
            internal CableNetwork Input;
            internal readonly CableNetwork[] Output=new CableNetwork[3];
            internal readonly float[] External=new float[3];
            internal readonly long[][] ExternalPaths={new long[0],new long[0],new long[0]};
            internal Source[] Cells=new Source[0];
            internal Dictionary<long,float> Limits=new Dictionary<long,float>();
        }
        private readonly object gate=new object();
        private State state=new State();
        private float debt;
        private readonly Dictionary<long,float[]> loads=new Dictionary<long,float[]>();
        private readonly HashSet<long> trips=new HashSet<long>();
        private string topology="";
        private int revision;
        internal CabinetBatteryPower(float pendingDebt){debt=pendingDebt;}
        internal void Refresh(SwitchboardCabinet owner,IList<CabinetWireSaveData> wires,DinBreaker[] modules)
        {
            var next=new State();
            if(owner.IsStructureCompleted&&!owner.IsCursor&&owner.GridController!=null)
            {
                next.Input=owner.InputConnection?.GetCable()?.CableNetwork;
                var closed=modules.Where(m=>m.Conducting).ToArray();var ids=closed.Select(m=>m.ReferenceId).ToArray();
                var input=new CabinetWireEnd(0,0);
                Func<CabinetWireEnd,CabinetWireEnd,bool> reach=(a,b)=>WireCircuit.Reachable(a,b,wires,ids);
                Func<CabinetWireEnd,CabinetWireEnd,long[]> path=(a,b)=>closed.Where(m=>!m.IsBatteryModule&&reach(a,new CabinetWireEnd(m.ReferenceId,0))&&reach(new CabinetWireEnd(m.ReferenceId,1),b)).Select(m=>m.ReferenceId).ToArray();
                var cells=new List<Source>();
                foreach(var module in closed.Where(m=>m.IsBatteryModule))
                {
                    var cell=module.Battery;if(cell==null)continue;
                    var source=new Source{Cell=cell,Charge=reach(input,new CabinetWireEnd(module.ReferenceId,0)),ChargePath=path(input,new CabinetWireEnd(module.ReferenceId,0))};
                    for(int i=0;i<3;i++){source.Output[i]=reach(new CabinetWireEnd(module.ReferenceId,1),new CabinetWireEnd(0,i+1));source.Paths[i]=path(new CabinetWireEnd(module.ReferenceId,1),new CabinetWireEnd(0,i+1));}
                    cells.Add(source);
                }
                next.Cells=cells.ToArray();var ext=new bool[3];
                for(int i=0;i<3;i++)
                {
                    var end=new CabinetWireEnd(0,i+1);ext[i]=reach(input,end);
                    if(ext[i]||cells.Any(s=>s.Output[i]))next.Output[i]=i==0?owner.Output1Connection?.GetCable()?.CableNetwork:i==1?owner.Output2Connection?.GetCable()?.CableNetwork:owner.Output3Connection?.GetCable()?.CableNetwork;
                    if(ReferenceEquals(next.Output[i],next.Input))next.Output[i]=null;
                    next.ExternalPaths[i]=path(input,end);
                }
                for(int i=0;i<3;i++)for(int j=0;j<i;j++)if(ReferenceEquals(next.Output[i],next.Output[j]))next.Output[i]=null;
                var allocation=WireCircuit.AllocateSupply(next.Input?.PotentialLoad??0,next.Output.Select(n=>n?.RequiredLoad??0).ToArray(),Enumerable.Range(0,3).Select(i=>ext[i]&&next.Output[i]!=null).ToArray());
                for(int i=0;i<3;i++)next.External[i]=allocation[i];
                next.Limits=closed.Where(m=>!m.IsContactor&&!m.IsBatteryModule&&!m.IsAnalyserModule&&!m.IsDoorPart).ToDictionary(m=>m.ReferenceId,m=>m.RatedWatts);
            }
            string signature=string.Join(";",wires.Select(w=>w.From.Owner+"/"+w.From.Contact+">"+w.To.Owner+"/"+w.To.Contact))+":"+string.Join(",",modules.Where(m=>m.Conducting).Select(m=>m.ReferenceId))+":"+string.Join(",",next.Cells.Select(c=>c.Cell.ReferenceId));
            lock(gate){if(signature!=topology||!ReferenceEquals(next.Input,state.Input)||!ReferenceEquals(next.Output[0],state.Output[0])||!ReferenceEquals(next.Output[1],state.Output[1])||!ReferenceEquals(next.Output[2],state.Output[2])){loads.Clear();topology=signature;revision++;}state=next;}
        }
        private int Branch(CableNetwork network)=>network==null?-1:ReferenceEquals(network,state.Output[0])?0:ReferenceEquals(network,state.Output[1])?1:ReferenceEquals(network,state.Output[2])?2:-1;
        private float CellShare(Source cell,int branch)
        {
            if(!cell.Output[branch]||state.Output[branch]==null)return 0;
            var p=WireCircuit.Allocate(cell.Cell.PowerStored,state.Output.Select(n=>n?.RequiredLoad??0).ToArray(),Enumerable.Range(0,3).Select(i=>cell.Output[i]&&state.Output[i]!=null).ToArray());
            return p[branch];
        }
        internal float Generated(CableNetwork network)
        {
            lock(gate)
            {
                if(network==null)return 0;
                int branch=Branch(network);if(branch<0)return 0;
                if(offers.TryGetValue(network,out var existing))return existing.Revision==revision?existing.Total:0;
                // An older query can still own its promised share while demand changes.
                // Reserve that external supply just as we reserve shared cell energy.
                float reservedExternal=offers.Values.Where(o=>o.Revision==revision).Sum(o=>o.External);
                float availableExternal=Math.Max(0,WireCircuit.Finite(state.Input?.PotentialLoad??0)-reservedExternal);
                var offer=new Offer{Branch=branch,Revision=revision,External=Math.Min(state.External[branch],availableExternal),Path=state.ExternalPaths[branch]};
                foreach(var source in state.Cells)
                {
                    float reserved=offers.Values.Sum(o=>o.Cells.Where(c=>ReferenceEquals(c.Source.Cell,source.Cell)).Sum(c=>c.Energy));
                    float available=Math.Max(0,source.Cell.PowerStored-reserved);
                    float amount=Math.Min(available,CellShare(source,branch));
                    if(amount>0)offer.Cells.Add(new Reservation{Source=source,Energy=amount,Path=source.Paths[branch]});
                }
                // The native tick queries twice, then finishes with Use or ObserveIdle.
                // Pin this offer across both queries and reserve shared cell energy.
                if(offer.Total>0)offers[network]=offer;
                return offer.Total;
            }
        }
        internal float Used(CableNetwork network)
        {
            lock(gate){if(network==null||!ReferenceEquals(network,state.Input))return 0;return debt+state.Cells.Where(c=>c.Charge).Sum(c=>Math.Min(1000f,WireCircuit.Finite(c.Cell.PowerDelta)));}
        }
        private void ClearLoad(int index){foreach(var value in loads.Values)value[index]=0;}
        private void AddLoad(IEnumerable<long> path,int index,float value)
        {foreach(long id in path){if(!loads.TryGetValue(id,out var load))loads[id]=load=new float[4];load[index]+=value;}}
        private void CheckTrips(){foreach(var pair in loads)if(state.Limits.TryGetValue(pair.Key,out float limit)&&pair.Value.Sum()>limit)trips.Add(pair.Key);}
        internal void Use(CableNetwork network,float amount)
        {
            lock(gate)
            {
                amount=WireCircuit.Finite(amount);
                if(network==null||!offers.TryGetValue(network,out var offer)){debt+=amount;return;}
                ClearLoad(offer.Branch);float external=Math.Min(amount,offer.External);float remainder=amount-external;
                foreach(var reservation in offer.Cells)
                {
                    float used=Math.Min(remainder,Math.Min(reservation.Energy,WireCircuit.Finite(reservation.Source.Cell.PowerStored)));
                    if(used<=0)continue;reservation.Source.Cell.PowerStored-=used;remainder-=used;AddLoad(reservation.Path,offer.Branch,used);
                }
                external+=remainder;debt=Math.Min(float.MaxValue/2,debt+external);AddLoad(offer.Path,offer.Branch,external);
                offers.Remove(network);CheckTrips();
            }
        }
        internal void Receive(CableNetwork network,float amount)
        {
            lock(gate)
            {
                if(network==null||!ReferenceEquals(network,state.Input))return;
                amount=WireCircuit.Finite(amount);float repaid=Math.Min(debt,amount);debt-=repaid;amount-=repaid;ClearLoad(3);
                foreach(var source in state.Cells)
                {
                    if(!source.Charge||amount<=0)continue;
                    float charged=Math.Min(amount,Math.Min(1000f,WireCircuit.Finite(source.Cell.PowerDelta)));
                    source.Cell.PowerStored+=charged;amount-=charged;AddLoad(source.ChargePath,3,charged);
                }
                CheckTrips();
            }
        }
        internal void ObserveIdle(CableNetwork network){lock(gate){int branch=Branch(network);if(branch>=0)ClearLoad(branch);if(network!=null)offers.Remove(network);}}
        internal long[] DrainTrips(){lock(gate){var result=trips.ToArray();trips.Clear();return result;}}
        internal bool AllowsPower(CableNetwork network){lock(gate)return network!=null&&ReferenceEquals(network,state.Input);}
        internal bool IsProviderTo(Device self,Device other,ref List<long> visited)
        {
            CableNetwork input;lock(gate)input=state.Input;
            if(other==null||input?.PowerTick?.InputOutputDevices==null||visited.Contains(self.ReferenceId))return false;
            visited.Add(self.ReferenceId);var providers=input.PowerTick.InputOutputDevices;
            if(providers.Any(p=>p?.Device==other))return true;
            foreach(var provider in providers){if(provider?.Device==null)continue;if(visited.Count>=Device.MaxProviderRecursionIterations)return false;if(provider.Device.IsProviderToDevice(other,ref visited))return true;}return false;
        }
    }
}
