using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using Assets.Scripts.Objects.Electrical;
using Assets.Scripts.Objects.Motherboards;
using Assets.Scripts.Objects.Pipes;
using HarmonyLib;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class SmartDisplayStoreHooks
    {
        private static readonly MethodInfo Read=AccessTools.Method(typeof(ILogicable),nameof(ILogicable.GetLogicValue),new[]{typeof(LogicType)});
        private static readonly MethodInfo StoreRead=AccessTools.Method(typeof(SmartDisplayStore),nameof(SmartDisplayStore.ReadForStore));
        internal static void Configure(Harmony harmony)
        {
            foreach(string name in new[]{"_S_Operation","_SD_Operation","_SB_Operation","_SBN_Operation"})
            {
                var type=AccessTools.Inner(typeof(ProgrammableChip),name);var execute=type==null?null:AccessTools.Method(type,"Execute");
                if(execute==null){Debug.LogWarning("[Modular Switchboards] Smart display store hook unavailable: "+name);continue;}
                harmony.Patch(execute,transpiler:new HarmonyMethod(typeof(SmartDisplayStoreHooks),nameof(Transpile)));
            }
        }
        internal static IEnumerable<CodeInstruction> Transpile(IEnumerable<CodeInstruction> instructions)
        {
            var codes=instructions.ToList();
            if(Read==null||StoreRead==null||codes.Count(c=>c.Calls(Read))!=1)
            {Debug.LogWarning("[Modular Switchboards] Smart display store hook skipped: native store layout changed.");return codes;}
            return codes.Select(code=>code.Calls(Read)?new CodeInstruction(code){opcode=OpCodes.Call,operand=StoreRead}:code).ToArray();
        }
    }
}
