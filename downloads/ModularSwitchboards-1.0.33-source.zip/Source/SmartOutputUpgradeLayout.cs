using System.Collections.Generic;
using System.Linq;
namespace ModularSwitchboards
{
    internal readonly struct SmartUpgradePart
    {
        internal readonly long Id;internal readonly int X,Width;internal readonly bool Core,Extension,Output;
        internal SmartUpgradePart(long id,int x,int width,bool core,bool extension,bool output){Id=id;X=x;Width=width;Core=core;Extension=extension;Output=output;}
    }
    internal static class SmartOutputUpgradeLayout
    {
        // A bus is upgraded atomically: keep Core fixed and shift only its own
        // continuous extensions outward. Never overlap/move an unrelated module.
        internal static Dictionary<long,SmartUpgradePart> Plan(IEnumerable<SmartUpgradePart> input,int first,int capacity)
        {
            var parts=input.ToDictionary(p=>p.Id);int last=first+capacity;
            foreach(var core in parts.Values.Where(p=>p.Core).OrderBy(p=>p.X).ToArray())
            {
                var group=new List<SmartUpgradePart>();int next=core.X+core.Width;
                while(true)
                {
                    var adjacent=parts.Values.Where(p=>p.X==next).ToArray();
                    if(adjacent.Length!=1||!adjacent[0].Extension)break;
                    var p=adjacent[0];if(p.Width<1||group.Any(g=>g.Id==p.Id))break;group.Add(p);next+=p.Width;
                }
                if(!group.Any(p=>p.Output&&p.Width<2))continue;
                int x=core.X+core.Width;var proposed=new List<SmartUpgradePart>();
                foreach(var p in group){int width=p.Output?2:p.Width;proposed.Add(new SmartUpgradePart(p.Id,x,width,false,true,p.Output));x+=width;}
                var ids=new HashSet<long>(group.Select(p=>p.Id));
                if(proposed.Any(p=>p.X<first||p.X+p.Width>last||parts.Values.Any(o=>!ids.Contains(o.Id)&&p.X<o.X+o.Width&&o.X<p.X+p.Width)||p.Id==proposed.Last().Id&&parts.Values.Any(o=>!ids.Contains(o.Id)&&o.Extension&&o.X==p.X+p.Width)))continue;
                foreach(var p in proposed)parts[p.Id]=p;
            }
            return parts;
        }
    }
}
