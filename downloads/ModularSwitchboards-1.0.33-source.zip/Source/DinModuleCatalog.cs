using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Electrical;

namespace ModularSwitchboards
{
    internal static class DinModuleCatalog
    {
        internal sealed class Spec
        {
            internal string Name,Title;
            internal float Watts;
            internal bool Fuse,Battery,Analyser,Smart,SmartOutput,SmartContactor,Contactor;
            internal bool Selectable=true;
            internal int Width=>Smart?4:Analyser?3:Battery?DinBatteryLayout.Slots:1;
            internal int[] FuseKits=new int[0];
        }
        internal static readonly Dictionary<string,Spec> Specs=new Dictionary<string,Spec>();
        internal static string Rating(float watts)=>(watts/1000f).ToString("0.###",CultureInfo.InvariantCulture)+" kW";
        internal static readonly float[] BreakerRatings={1000,5000,50000,100000,500000};
        internal static string Colour(float watts)=>watts<=1000?"Green":watts<=5000?"Yellow":watts<=50000?"Orange":watts<=100000?"Red":"Purple";
        internal static List<Spec> Discover(IEnumerable<Thing> sources)
        {
            var kits=sources.OfType<MultiConstructor>().ToArray();
            var native=sources.OfType<CableFuse>().Where(f=>f.PowerBreak>0&&!float.IsInfinity(f.PowerBreak)&&!float.IsNaN(f.PowerBreak)).ToArray();
            var ratings=native.Select(f=>f.PowerBreak).Distinct().OrderBy(w=>w).ToArray();
            if(ratings.Length==0)throw new InvalidOperationException("No native CableFuse ratings found.");
            var specs=new List<Spec>();
            var breakerRatings=BreakerRatings;
            foreach(var watts in breakerRatings)specs.Add(new Spec{Name=specs.Count==0?SwitchboardsMod.BreakerName:"StructureDinBreaker"+watts.ToString("0",CultureInfo.InvariantCulture),Title="DIN Breaker "+Rating(watts),Watts=watts});
            foreach(var watts in ratings)
            {
                var hashes=kits.Where(k=>k.Constructables!=null&&k.Constructables.OfType<CableFuse>().Any(f=>f.PowerBreak==watts)).Select(k=>k.PrefabHash).Distinct().ToArray();
                if(hashes.Length==0)continue;
                specs.Add(new Spec{Name="StructureDinFuseHolder"+watts.ToString("0",CultureInfo.InvariantCulture),Title="DIN Fuse Holder "+Rating(watts),Watts=watts,Fuse=true,FuseKits=hashes});
            }
            if(!specs.Any(s=>s.Fuse))throw new InvalidOperationException("No native Cable Fuse construction kit found.");
            if(sources.OfType<AreaPowerControl>().Any())specs.Add(new Spec{Name="StructureDinBatteryBackup",Title="DIN Battery Backup",Battery=true});
            if(sources.OfType<CableAnalyser>().Any())specs.Add(new Spec{Name="StructureDinCableAnalyser",Title="DIN Cable Analyzer",Analyser=true});
            specs.Add(new Spec{Name="StructureDinSmartModule",Title=SwitchboardNames.SmartCoreTitle,Smart=true});
            specs.Add(new Spec{Name=SmartOutputModel.PrefabName,Title="DIN Smart Net Module",SmartOutput=true});
            specs.Add(new Spec{Name=ModularSwitchboards.SmartContactor.PrefabNameId,Title="DIN Smart Output Module",SmartContactor=true});
            specs.Add(new Spec{Name=DinContactorModel.PrefabName,Title="DIN Contactor",Contactor=true});
            // Keep the 0.12.39 intermediate prefab readable without another menu option.
            specs.Add(new Spec{Name="StructureDinBreaker20000",Title="DIN Breaker 20 kW (legacy)",Watts=20000,Selectable=false});
            Specs.Clear();foreach(var spec in specs)Specs.Add(spec.Name,spec);return specs;
        }
    }
}
