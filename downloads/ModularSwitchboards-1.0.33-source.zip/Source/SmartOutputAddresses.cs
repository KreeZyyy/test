using System.Collections.Generic;using System.Linq;
namespace ModularSwitchboards
{
    internal static class SmartOutputAddresses
    {
        internal const int Count=6;
        internal static bool Valid(int value)=>value>=0&&value<Count;
        internal static int FirstFree(IEnumerable<int> used)=>Enumerable.Range(0,Count).Where(i=>!used.Contains(i)).DefaultIfEmpty(-1).First();
        internal static int NextFree(int current,IEnumerable<int> used)
        {
            var taken=new HashSet<int>(used);
            for(int step=1;step<=Count;step++){int candidate=(current+step+Count)%Count;if(!taken.Contains(candidate))return candidate;}
            return -1;
        }
        // Keep valid unique saved addresses first. New/colliding modules get a
        // free address without shifting the remaining physical assembly.
        internal static Dictionary<long,int> Resolve(IEnumerable<KeyValuePair<long,int>> ordered)
        {
            var items=ordered.ToArray();var result=new Dictionary<long,int>();var used=new HashSet<int>();
            foreach(var p in items)if(Valid(p.Value)&&used.Add(p.Value))result[p.Key]=p.Value;
            foreach(var p in items)if(!result.ContainsKey(p.Key)){int next=FirstFree(used);result[p.Key]=next;if(next>=0)used.Add(next);}
            return result;
        }
    }
}
