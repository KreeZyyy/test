using System;using System.Linq;using Assets.Scripts.Objects.Pipes;using Assets.Scripts.Objects.Electrical;using Assets.Scripts.Networks;using HarmonyLib;
namespace ModularSwitchboards
{
    internal static class SmartContactorNetwork
    {
        private static readonly System.Reflection.PropertyInfo PowerCable=AccessTools.Property(typeof(Device),"PowerCable"),PowerCables=AccessTools.Property(typeof(Device),"PowerCables"),DataCables=AccessTools.Property(typeof(Device),"DataCables");
        internal static void Refresh(SmartContactor module)
        {
            foreach(var n in new[]{module.OldPower,module.OldData}.Where(n=>n!=null).Distinct())Normalize(module,n);
            var core=SmartBus.Core(module);var power=core!=null&&core.Powered&&core.OnOff?core.BoundPowerCable:null;Cable data=null;
            var wanted=new[]{power,data}.Where(c=>c?.CableNetwork!=null).Distinct().ToArray();
            if(power==module.PowerFeed&&data==module.DataFeed&&power?.CableNetwork==module.OldPower&&data?.CableNetwork==module.OldData&&module.DataCable==data&&module.PowerCable==power&&module.PowerCables.SequenceEqual(power?.CableNetwork==null?Array.Empty<Cable>():new[]{power})&&module.DataCables.SequenceEqual(data?.CableNetwork==null?Array.Empty<Cable>():new[]{data})&&wanted.All(c=>c.CableNetwork.GetDeviceRegistration(module)?.Contains(c)==true))return;
            var old=new[]{module.OldPower,module.OldData}.Where(n=>n!=null).Distinct().ToArray();
            if(power?.CableNetwork!=module.OldPower)module.ClearSupply();
            module.PowerFeed=power;module.DataFeed=data;module.OldPower=power?.CableNetwork;module.OldData=data?.CableNetwork;
            module.DataCable=data;PowerCable.SetValue(module,power,null);PowerCables.SetValue(module,power?.CableNetwork==null?Array.Empty<Cable>():new[]{power},null);DataCables.SetValue(module,data?.CableNetwork==null?Array.Empty<Cable>():new[]{data},null);
            var networks=wanted.Select(c=>c.CableNetwork).Distinct().ToArray();foreach(var network in old.Where(n=>!networks.Contains(n)))network.RemoveDevice(module);
            foreach(var cable in wanted)cable.CableNetwork.AddDevice(cable,module);
            foreach(var network in networks)
            {
                var registrations=network.GetDeviceRegistration(module);if(registrations!=null)foreach(var stale in registrations.Where(c=>!wanted.Contains(c)).ToArray())network.RemoveDevice(stale,module);
                Normalize(module,network);network.DirtyPowerAndDataDeviceLists();network.RefreshNetworkDevice(module);
            }
        }
        private static void Normalize(Device module,CableNetwork network)
        {
            bool found=false,changed=false;lock(network.DeviceList)
                for(int i=network.DeviceList.Count-1;i>=0;i--)if(ReferenceEquals(network.DeviceList[i],module)){if(found){network.DeviceList.RemoveAt(i);changed=true;}else found=true;}
            if(changed){network.DirtyPowerAndDataDeviceLists();network.RefreshNetworkDevice(module);}
        }
        internal static void Unbind(SmartContactor module)
        {
            foreach(var n in new[]{module.OldPower,module.OldData}.Where(n=>n!=null).Distinct())n.RemoveDevice(module);
            module.PowerFeed=null;module.DataFeed=null;module.OldPower=null;module.OldData=null;module.DataCable=null;
            PowerCable.SetValue(module,null,null);PowerCables.SetValue(module,Array.Empty<Cable>(),null);DataCables.SetValue(module,Array.Empty<Cable>(),null);
        }
    }
}
