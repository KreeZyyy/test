using System;
using System.IO;
using System.Linq;
using System.Reflection;
using Assets.Scripts;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class HousingAddressScrew
    {
        internal static readonly Vector3 Center=new Vector3(SmartContactor.CenterX,-.013f,.0605f);
        internal static Mesh Build()
        {
            using(var reader=new BinaryReader(Assembly.GetExecutingAssembly().GetManifestResourceStream("ModularSwitchboards.HousingAddressScrew.meshbin")))
            {
                int count=reader.ReadInt32(),groups=reader.ReadInt32();var positions=new Vector3[count];var uv=new Vector2[count];
                for(int i=0;i<count;i++){positions[i]=new Vector3(reader.ReadSingle(),reader.ReadSingle(),reader.ReadSingle());uv[i]=new Vector2(reader.ReadSingle(),reader.ReadSingle());}
                var bounds=new Bounds(positions[0],Vector3.zero);foreach(var p in positions)bounds.Encapsulate(p);
                float fit=.016f/Mathf.Max(bounds.size.x,bounds.size.y);
                // Reference positions are already in housing space. Retain the
                // original six-sided face, recessed slot and UV coordinates.
                for(int i=0;i<count;i++)positions[i]=Center+new Vector3((positions[i].x-bounds.center.x)*fit/DinBreakerModel.VisualScale.x,
                    (positions[i].y-bounds.center.y)*fit/DinBreakerModel.VisualScale.y,(positions[i].z-bounds.min.z)*fit/DinBreakerModel.VisualScale.z);
                var mesh=new Mesh{name="DIN.Output.OriginalHousingSelector"};mesh.vertices=positions;mesh.uv=uv;mesh.subMeshCount=groups;
                for(int g=0;g<groups;g++){int n=reader.ReadInt32();var triangles=new int[n];for(int i=0;i<n;i++)triangles[i]=reader.ReadInt32();mesh.SetTriangles(triangles,g);}
                mesh.RecalculateNormals();mesh.RecalculateBounds();return mesh;
            }
        }
        internal static Bounds TargetBounds(Bounds head)
        {
            // Include the visible head and 1 mm around its edge; do not expose
            // the shaft buried behind the fascia as an interaction surface.
            float back=Mathf.Max(head.min.z,.0637f),front=head.max.z+.0005f/DinBreakerModel.VisualScale.z;
            return new Bounds(new Vector3(head.center.x,head.center.y,(back+front)*.5f),
                new Vector3(head.size.x+.002f/DinBreakerModel.VisualScale.x,head.size.y+.002f/DinBreakerModel.VisualScale.y,front-back));
        }
        internal static void Install(Transform model,int layer,out BoxCollider hit)
        {
            var housing=WorldManager.Instance.SourcePrefabs.First(p=>p!=null&&p.GetType().Name=="CircuitHousing");
            var original=housing.GetComponentsInChildren<MeshRenderer>(true).First(r=>r.name=="SphereColliderTriggerRendererButton1NoShadow");
            var go=new GameObject("OutputAddressScrew"){layer=layer};go.transform.SetParent(model,false);
            var mesh=Build();go.AddComponent<MeshFilter>().sharedMesh=mesh;NativePortSurface.Capture(original,go.AddComponent<MeshRenderer>());
            var target=new GameObject("OutputAddressTarget"){layer=layer};target.transform.SetParent(model,false);hit=target.AddComponent<BoxCollider>();
            var targetBounds=TargetBounds(mesh.bounds);target.transform.localPosition=targetBounds.center;hit.center=Vector3.zero;hit.size=targetBounds.size;
        }
    }
}
