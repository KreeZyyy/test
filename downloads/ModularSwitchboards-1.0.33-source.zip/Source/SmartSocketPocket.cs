using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class SmartSocketPocket
    {
        internal static Mesh Cut(Mesh casing,Bounds pocket,float cornerX=0,float cornerY=0,int wallRole=3)
        {
            var mesh=NativeMeshCrop.Outside(casing,pocket,"Smart.CasingWithIC10Pocket");
            if(mesh==null)throw new InvalidOperationException("IC10 pocket removed the whole casing.");
            var vertices=mesh.vertices.ToList();var uv=mesh.uv.ToList();var groups=Enumerable.Range(0,mesh.subMeshCount).Select(i=>mesh.GetTriangles(i).ToList()).ToArray();
            var colourUv=groups[wallRole].Count>0?uv[groups[wallRole][0]]:default(Vector2);
            var lo=pocket.min;var hi=pocket.max;float back=lo.z,front=casing.bounds.max.z;
            Action<Vector3,Vector3,Vector3,Vector3,Vector3> quad=(a,b,c,d,normal)=>
            {
                int start=vertices.Count;vertices.AddRange(new[]{a,b,c,d});uv.AddRange(new[]{colourUv,colourUv,colourUv,colourUv});
                var cross=Vector3.Cross(b-a,c-a);bool forward=cross.x*normal.x+cross.y*normal.y+cross.z*normal.z>0;
                groups[wallRole].AddRange(forward?new[]{start,start+1,start+2}:new[]{start,start+2,start+1});
                if(Vector3.Cross(c-a,d-a).sqrMagnitude>1e-16f)groups[wallRole].AddRange(forward?new[]{start,start+2,start+3}:new[]{start,start+3,start+2});
            };
            if(cornerX>0&&cornerY>0)
            {
                // Continue the original fascia into the four corners, then line
                // the actual octagonal socket opening. No rectangular shadow gap.
                var ring=new[]{new Vector3(lo.x+cornerX,lo.y,0),new Vector3(hi.x-cornerX,lo.y,0),new Vector3(hi.x,lo.y+cornerY,0),new Vector3(hi.x,hi.y-cornerY,0),new Vector3(hi.x-cornerX,hi.y,0),new Vector3(lo.x+cornerX,hi.y,0),new Vector3(lo.x,hi.y-cornerY,0),new Vector3(lo.x,lo.y+cornerY,0)};
                var corners=new[]{new Vector3(hi.x,lo.y,front),new Vector3(hi.x,hi.y,front),new Vector3(lo.x,hi.y,front),new Vector3(lo.x,lo.y,front)};
                var middle=new Vector3(pocket.center.x,pocket.center.y,back);
                for(int i=0;i<8;i++)
                {
                    var a=ring[i];var b=ring[(i+1)%8];
                    var floorA=new Vector3(a.x,a.y,back);var floorB=new Vector3(b.x,b.y,back);
                    quad(middle,floorA,floorB,middle,new Vector3(0,0,1));
                    quad(floorA,floorB,new Vector3(b.x,b.y,front),new Vector3(a.x,a.y,front),new Vector3(a.y-b.y,b.x-a.x,0));
                    if(i%2==1)quad(new Vector3(a.x,a.y,front),corners[i/2],new Vector3(b.x,b.y,front),new Vector3(a.x,a.y,front),new Vector3(0,0,1));
                }
            }
            else
            {
                quad(new Vector3(lo.x,lo.y,back),new Vector3(hi.x,lo.y,back),new Vector3(hi.x,hi.y,back),new Vector3(lo.x,hi.y,back),new Vector3(0,0,1));
                quad(new Vector3(lo.x,lo.y,back),new Vector3(lo.x,hi.y,back),new Vector3(lo.x,hi.y,front),new Vector3(lo.x,lo.y,front),new Vector3(1,0,0));
                quad(new Vector3(hi.x,lo.y,back),new Vector3(hi.x,hi.y,back),new Vector3(hi.x,hi.y,front),new Vector3(hi.x,lo.y,front),new Vector3(-1,0,0));
                quad(new Vector3(lo.x,lo.y,back),new Vector3(hi.x,lo.y,back),new Vector3(hi.x,lo.y,front),new Vector3(lo.x,lo.y,front),new Vector3(0,1,0));
                quad(new Vector3(lo.x,hi.y,back),new Vector3(hi.x,hi.y,back),new Vector3(hi.x,hi.y,front),new Vector3(lo.x,hi.y,front),new Vector3(0,-1,0));
            }
            mesh.SetVertices(vertices);mesh.SetUVs(0,uv);for(int i=0;i<groups.Length;i++)mesh.SetTriangles(groups[i],i);
            mesh.RecalculateNormals();mesh.RecalculateTangents();mesh.RecalculateBounds();return mesh;
        }
    }
}
