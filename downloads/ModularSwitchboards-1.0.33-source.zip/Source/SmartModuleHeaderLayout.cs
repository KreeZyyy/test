namespace ModularSwitchboards
{
    internal static class SmartModuleHeaderLayout
    {
        internal const float CenterY=.017f;
    }
}
