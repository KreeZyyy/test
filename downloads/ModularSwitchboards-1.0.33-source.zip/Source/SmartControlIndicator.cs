using System.Collections.Generic;
using System.Linq;
namespace ModularSwitchboards
{
    internal enum SmartControlLight { Off, Disconnected, Open, Energized }
    internal static class SmartControlIndicator
    {
        internal static SmartControlLight Evaluate(bool busPowered,bool connected,bool conducting)
            =>!busPowered?SmartControlLight.Off:!connected?SmartControlLight.Disconnected:conducting?SmartControlLight.Energized:SmartControlLight.Open;
        internal static bool Connected(long output,IEnumerable<CabinetWireSaveData> wires,IEnumerable<long> coils)
        {
            var ids=new HashSet<long>(coils);
            return wires.Any(w=>Matches(output,w.From,w.To,ids)||Matches(output,w.To,w.From,ids));
        }
        private static bool Matches(long output,CabinetWireEnd from,CabinetWireEnd to,HashSet<long> coils)
            =>from.Owner==output&&from.Contact==SmartContactorCircuit.OutputPin&&to.Contact==ContactorCircuit.CoilPin&&coils.Contains(to.Owner);
    }
}
