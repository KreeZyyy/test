using UnityEngine;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Motherboards;
namespace ModularSwitchboards
{
    public sealed class SmartOutputView:MonoBehaviour
    {
        private DinBreaker owner;
        private MeshRenderer lens,boundLens;
        private Material lensMaterial;
        private Light glow;
        private readonly MaterialPropertyBlock block=new MaterialPropertyBlock();
        private SmartOutputLight state,reportedState;
        private bool reported;
        private float nextCheck;
        private static readonly int ColorId=Shader.PropertyToID("_Color"),EmissionId=Shader.PropertyToID("_EmissionColor");
        private void Bind()
        {
            glow=transform.Find("DinBreakerModel/SmartOutputGlow")?.GetComponent<Light>();
            owner=GetComponent<DinBreaker>();lens=transform.Find("DinBreakerModel/SmartOutputLens")?.GetComponent<MeshRenderer>();
            if(lens!=null&&(lensMaterial==null||boundLens!=lens))
            {
                if(lensMaterial!=null)Destroy(lensMaterial);
                lensMaterial=new Material(lens.sharedMaterial){name="Switchboards.SmartOutput.Indicator.Live"};
                lensMaterial.EnableKeyword("_EMISSION");
                lensMaterial.SetFloat("_Glossiness",0f);lensMaterial.SetFloat("_SpecularHighlights",0f);lensMaterial.SetFloat("_GlossyReflections",0f);
                lensMaterial.EnableKeyword("_SPECULARHIGHLIGHTS_OFF");lensMaterial.EnableKeyword("_GLOSSYREFLECTIONS_OFF");
                lens.sharedMaterial=lensMaterial;boundLens=lens;
            }
        }
        private void OnEnable()
        {
            // Bind the placed instance, including after prefab cloning or re-enabling.
            Bind();state=SmartOutputLight.Off;nextCheck=0f;Paint();
        }
        private void LateUpdate()
        {
            if(owner==null||lens==null||lensMaterial==null)Bind();
            if(owner==null||lens==null||lensMaterial==null)return;
            if(Time.unscaledTime>=nextCheck)
            {nextCheck=Time.unscaledTime+.15f;state=SmartOutputStatus.Light(owner);}
            // Native material-slot blocks override renderer-wide blocks. Reapply
            // both every frame even when the connection itself has not changed.
            Paint();
        }
        private void Paint()
        {
            if(lens==null||lensMaterial==null)return;
            if(lens.sharedMaterial!=lensMaterial)lens.sharedMaterial=lensMaterial;
            bool connected=state==SmartOutputLight.Connected;bool lit=state!=SmartOutputLight.Off;
            int palette=(int)(lit?(connected?ColorType.Green:ColorType.Orange):ColorType.Black);
            var color=!lit?new Color(.025f,.03f,.025f):connected?new Color(.08f,1f,.12f):new Color(1f,.38f,.015f);
            var emission=!lit?Color.black:connected?DoorLedColours.For(DoorLedColours.GreenName).Emission:new Color(1.4f,.45f,.025f);
            if(glow!=null){glow.color=connected?new Color(.04f,1f,.08f):new Color(1f,.38f,.015f);glow.enabled=lit;}
            lensMaterial.SetFloat(Thing.DiffuseIndexPropertyID,palette);lensMaterial.SetFloat(Thing.SmoothnessIndexPropertyID,0f);
            lensMaterial.SetColor(ColorId,color);lensMaterial.SetColor(EmissionId,emission);
            block.Clear();block.SetFloat(Thing.DiffuseIndexPropertyID,palette);block.SetFloat(Thing.SmoothnessIndexPropertyID,0f);block.SetColor(ColorId,color);block.SetColor(EmissionId,emission);
            lens.SetPropertyBlock(block);lens.SetPropertyBlock(block,0);
            if(owner!=null&&owner.ReferenceId!=0&&!owner.IsCursor&&(!reported||reportedState!=state))
            {
                Debug.Log("[Modular Switchboards] Smart Output LED "+owner.ReferenceId+": "+(!lit?"off":connected?"green":"orange")+"; native palette="+palette+"; shader="+lensMaterial.shader.name+"; mod="+SwitchboardsMod.Version);
                reported=true;reportedState=state;
            }
        }
        private void OnDestroy(){if(lensMaterial!=null)Destroy(lensMaterial);}
    }
}
