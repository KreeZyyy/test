"""Store the supplied IC housing selector mesh, preserving native UVs/topology."""
from pathlib import Path
import json,struct
root=Path(__file__).resolve().parents[1]
doc=json.loads((root/'Art/CircuitHousing-reference.json').read_text())
p=next(m for m in doc['Meshes'] if m['Name']=='SphereColliderTriggerRendererButton1NoShadow')
assert len(p['Vertices'])==83 and sum(len(g['Triangles'])for g in p['Parts'])==120
out=root/'Assets/HousingAddressScrew.meshbin'
with out.open('wb')as f:
 f.write(struct.pack('<ii',len(p['Vertices']),len(p['Parts'])))
 for v,uv in zip(p['Vertices'],p['Uv']):f.write(struct.pack('<fffff',v['x'],v['y'],v['z'],uv['x'],uv['y']))
 for g in p['Parts']:
  f.write(struct.pack('<i',len(g['Triangles'])))
  f.write(struct.pack('<'+'i'*len(g['Triangles']),*g['Triangles']))
print('Housing selector exported: 83 vertices, 40 triangles, native UVs retained.')
