from pathlib import Path
r=Path(__file__).resolve().parents[1]
s=(r/'Source/SmartContactor.cs').read_text()
def method(marker):
 a=s.index(marker);b=s.index('{',a);end=b+1;level=1
 while level:
  level+=(s[end]=='{')-(s[end]=='}');end+=1
 return s[a:end]
(r/'Verification/SmartOutputJoin/Extracted.cs').write_text('namespace ModularSwitchboards{public partial class SmartContactor{'+method('public override void SerializeOnJoin(')+method('public override void DeserializeOnJoin(')+'}}')
