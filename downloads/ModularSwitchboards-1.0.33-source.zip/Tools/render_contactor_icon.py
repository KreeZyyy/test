"""Classic contactor: production body mesh plus mechanical indicator, no LED."""
import bpy,json,math
from pathlib import Path
from mathutils import Vector
root=Path(__file__).resolve().parents[1]
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
def mat(name,rgb):
 m=bpy.data.materials.new(name);m.diffuse_color=(*rgb,1);m.use_nodes=True;n=m.node_tree.nodes.get('Principled BSDF');n.inputs['Base Color'].default_value=(*rgb,1);n.inputs['Roughness'].default_value=.85;return m
white=mat('White casing',(.78,.81,.8));dark=mat('Dark fascia',(.035,.035,.035));gray=mat('Metal',(.28,.30,.30));red=mat('OFF red',(.65,.035,.035));green=mat('ON green',(.035,.50,.07))
palette=[gray,white,gray,dark,gray]
def point(p):return(-p[0]*2.25,-p[2]*1.15,p[1]*1.35)
data=json.loads((root/'Art/ContactorGeometry.json').read_text());faces=[];roles=[]
for role,indices in data['triangles'].items():
 for i in range(0,len(indices),3):faces.append(indices[i:i+3]);roles.append(int(role))
mesh=bpy.data.meshes.new('Actual contactor body');mesh.from_pydata([point(p)for p in data['vertices']],[],faces);mesh.update();ob=bpy.data.objects.new(mesh.name,mesh);bpy.context.collection.objects.link(ob)
for m in palette:mesh.materials.append(m)
for p,r in zip(mesh.polygons,roles):p.material_index=r
panels=[];texts=[]
def box(name,p,size,m):
 bpy.ops.mesh.primitive_cube_add(size=1,location=point(p));o=bpy.context.object;o.name=name;o.dimensions=(size[0]*2.25,size[2]*1.15,size[1]*1.35);o.data.materials.append(m);return o
for on in [True,False]:
 # Initial OFF strip: local +/- .005 plus root .007.
 y=(.005 if on else -.005)+.007
 panels.append(box('Moving ON'if on else'Moving OFF',(0,y,.0615),(.0088,.010,.0007),green if on else red))
def label(value,x,y,z,width,m):
 bpy.ops.object.text_add(location=point((x,y,z)),rotation=(math.pi/2,0,0));o=bpy.context.object;o.data.body=value;o.data.align_x='CENTER';o.data.align_y='CENTER';o.data.materials.append(m);bpy.context.view_layer.update();o.scale=(width*2.25/max(.0001,o.dimensions.x),.0038*1.35/max(.0001,o.dimensions.y),1);return o
label('IN',.004,.022,.065,.0023,dark);label('A1',-.004,.022,.065,.0023,dark);label('OUT',0,-.022,.065,.003,dark)
texts=[label('ON',0,.012,.0621,.0065,white),label('OFF',0,.002,.0621,.0065,white)]
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=32;scene.cycles.use_denoising=False;scene.render.film_transparent=True;scene.view_settings.view_transform='Standard';scene.world.color=(.22,.22,.22)
center=Vector(point((0,0,.031)));bpy.ops.object.camera_add(location=center+Vector((.07,-.31,.07)));cam=bpy.context.object;cam.rotation_euler=(center-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=.135;scene.camera=cam
for pos,power in [((.15,-.22,.25),2.5),((-.20,-.08,.10),.8)]:
 bpy.ops.object.light_add(type='AREA',location=pos);o=bpy.context.object;o.data.energy=power;o.data.size=.35;o.rotation_euler=(center-o.location).to_track_quat('-Z','Y').to_euler()
scene.render.resolution_percentage=100
for size,path in [(256,root/'Assets/Icons/DinContactor.png'),(640,root.parent/'DinContactor-1.0.33-OFF-preview.png')]:
 scene.render.resolution_x=size;scene.render.resolution_y=size;scene.render.filepath=str(path);bpy.ops.render.render(write_still=True)
for o in panels+texts:o.location.z-=.010*1.35
scene.render.filepath=str(root.parent/'DinContactor-1.0.33-ON-preview.png');bpy.ops.render.render(write_still=True)
