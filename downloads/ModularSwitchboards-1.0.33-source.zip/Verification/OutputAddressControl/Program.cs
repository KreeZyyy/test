using System;using System.Linq;using System.Collections.Generic;using ModularSwitchboards;using Assets.Scripts.Objects;using Assets.Scripts.Networking;
namespace Assets.Scripts.Objects
{
 public enum InteractableType{OnOff,Mode}
 public class Interactable{public SmartContactor Parent;public InteractableType Action;public int State;}
 public class Item{public string PrefabName;}
 public class Slot{public Item Item;public Item Get()=>Item;}
 public class Interaction{public Slot SourceSlot;public Item SourceThing;}
 public class NativeDevice
 {
  public class DelayedActionInstance{public object Selection;public float Duration;public string ActionMessage,Reason;public bool Success;public DelayedActionInstance Fail(string m){Reason=m;return this;}public DelayedActionInstance Succeed(){Success=true;return this;}}
  public virtual string GetContextualName(Interactable i)=>"native";
  public virtual DelayedActionInstance InteractWith(Interactable i,Interaction action,bool doAction=true)=>new();
  public virtual void OnInteractableUpdated(Interactable i){if(i.Action==InteractableType.OnOff)((SmartContactor)this).OnOff=i.State!=0;}
 }
}
namespace Assets.Scripts.Networking
{
 public static class NetworkManager{public static bool IsServer=true;}
 public static class OnServer{public static int Sends;public static void Interact(Interactable i,int state){Sends++;i.State=state;i.Parent.OnInteractableUpdated(i);}}
}
namespace ModularSwitchboards
{
 public static class SmartOutputScrewTarget{public static object Selection(SmartContactor o,Interactable c)=>new object();}
 public class Cabinet{public bool CanAccessModules=true;}
 public class SmartModule{public List<SmartContactor> Outputs=new();}
 public static class SmartBus{public static SmartModule Core(SmartContactor c)=>c.Core;public static IEnumerable<SmartContactor> PowerOutputs(SmartModule c)=>c.Outputs;}
 public partial class SmartContactor:NativeDevice
 {
  public int OutputAddress=-1;public bool OnOff,IsCursor,IsBeingDestroyed,IsStructureCompleted=true;public SmartModule Core;public Cabinet Cabinet=new();public Interactable InteractOnOff;public Interactable Screw;public ushort NetworkUpdateFlags;private const ushort AddressUpdate=32768;
  private void RestoreAddressState(){Screw.State=Math.Max(0,OutputAddress);}
 }
}
class Program
{
 static int n;static void Check(bool v,string m){n++;if(!v)throw new Exception(m);}
 static void Main()
 {
  var core=new SmartModule();var a=new SmartContactor{Core=core,OutputAddress=0,OnOff=true};a.Screw=new(){Parent=a,Action=InteractableType.Mode};a.InteractOnOff=new(){Parent=a,Action=InteractableType.OnOff,State=1};core.Outputs.Add(a);core.Outputs.Add(new(){OutputAddress=1});core.Outputs.Add(new(){OutputAddress=2});
  var screwdriver=new Interaction{SourceSlot=new(){Item=new(){PrefabName="ItemScrewdriver"}}};var wrong=new Interaction{SourceSlot=new(){Item=new(){PrefabName="ItemDrill"}}};
  Check(!a.InteractWith(a.Screw,wrong).Success&&a.OutputAddress==0&&a.OnOff,"wrong tool changed address");
  var before=OnServer.Sends;Check(a.InteractWith(a.Screw,screwdriver,false).Success&&OnServer.Sends==before&&a.OutputAddress==0&&a.OnOff,"preview changed address or power");
  Check(a.InteractWith(a.Screw,screwdriver).Success&&a.OutputAddress==3&&!a.OnOff,"hardware change did not skip occupied addresses or open output");
  Check(a.Screw.State==3&&(a.NetworkUpdateFlags&32768)!=0,"actual address not replicated/restored");
  a.Cabinet.CanAccessModules=false;Check(!a.InteractWith(a.Screw,screwdriver).Success&&a.OutputAddress==3,"closed cover allowed config");a.Cabinet.CanAccessModules=true;
  a.Core=null;Check(!a.InteractWith(a.Screw,screwdriver).Success,"standalone output can configure");a.Core=core;
  a.IsCursor=true;Check(!a.InteractWith(a.Screw,screwdriver).Success,"placement cursor changed address");a.IsCursor=false;
  a.OnOff=true;OnServer.Interact(a.Screw,1);Check(a.OutputAddress==3&&a.Screw.State==3&&a.OnOff,"server accepted duplicate address or failed to restore native transport state");
  OnServer.Interact(a.Screw,99);Check(a.OutputAddress==3&&a.Screw.State==3,"server accepted invalid address");
  NetworkManager.IsServer=false;OnServer.Interact(a.Screw,4);Check(a.OutputAddress==3,"client assigned itself address");NetworkManager.IsServer=true;
  a.OnOff=false;OnServer.Interact(a.Screw,4);Check(a.OutputAddress==4&&a.Screw.State==4,"valid retry blocked by prior native request state");
  for(int d=0;d<6;d++)if(d!=4&&!core.Outputs.Any(o=>o.OutputAddress==d))core.Outputs.Add(new(){OutputAddress=d});
  Check(!a.InteractWith(a.Screw,screwdriver).Success&&a.OutputAddress==4,"full assembly replaced another module");
  Console.WriteLine(n+" Output hardware address controls passed: screwdriver, preview, cabinet/core guards, occupied/invalid requests, authority, native retry and power-open reset.");
 }
}
