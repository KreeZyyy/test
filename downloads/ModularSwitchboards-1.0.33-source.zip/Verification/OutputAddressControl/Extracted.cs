using System;using System.Linq;using Assets.Scripts.Objects;using Assets.Scripts.Networking;namespace ModularSwitchboards{public partial class SmartContactor{internal void SetOutputAddress(int value)
        {
            if(OutputAddress==value)return;
            if(OnOff&&InteractOnOff!=null)OnServer.Interact(InteractOnOff,0);
            OutputAddress=value;RestoreAddressState();NetworkUpdateFlags|=(ushort)(AddressUpdate|2);
        }        private int NextAddress()=>SmartOutputAddresses.NextFree(OutputAddress,SmartBus.Core(this) is SmartModule core?SmartBus.PowerOutputs(core).Where(o=>o!=this).Select(o=>o.OutputAddress):System.Array.Empty<int>());        public override string GetContextualName(Interactable interactable)=>interactable.Action==InteractableType.Mode?"Address "+(SmartOutputAddresses.Valid(OutputAddress)?"d"+OutputAddress:"unassigned")+" — screwdriver to next free d":base.GetContextualName(interactable);public override DelayedActionInstance InteractWith(Interactable interactable,Interaction interaction,bool doAction=true)
        {
            if(interactable.Action!=InteractableType.Mode)return base.InteractWith(interactable,interaction,doAction);
            if(interaction.SourceSlot?.Get()?.PrefabName!="ItemScrewdriver"&&interaction.SourceThing?.PrefabName!="ItemScrewdriver")return new DelayedActionInstance{Duration=0f}.Fail("Use a screwdriver on the address screw.");
            return AddressAction(interactable,doAction);
        }private DelayedActionInstance AddressAction(Interactable control,bool doAction)
        {
            var result=new DelayedActionInstance{Duration=.25f,ActionMessage="Set Output address",Selection=SmartOutputScrewTarget.Selection(this,control)};
            if(IsCursor||IsBeingDestroyed||!IsStructureCompleted||Cabinet?.CanAccessModules!=true||SmartBus.Core(this)==null)return result.Fail("Open the cabinet, remove the cover and attach to a Core first.");
            int next=NextAddress();if(next<0||next==OutputAddress)return result.Fail("No other free d0–d5 address.");
            if(doAction)OnServer.Interact(control,next);return result.Succeed();
        }public override void OnInteractableUpdated(Interactable interactable)
        {
            base.OnInteractableUpdated(interactable);
            if(interactable.Action!=InteractableType.Mode||!NetworkManager.IsServer)return;
            var core=SmartBus.Core(this);int requested=interactable.State;
            if(core!=null&&Cabinet?.CanAccessModules==true&&SmartOutputAddresses.Valid(requested)&&!SmartBus.PowerOutputs(core).Any(o=>o!=this&&o.OutputAddress==requested))SetOutputAddress(requested);
            RestoreAddressState();NetworkUpdateFlags|=(ushort)(AddressUpdate|2);
        }}}