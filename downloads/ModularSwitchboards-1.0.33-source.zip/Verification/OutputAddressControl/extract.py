from pathlib import Path
r=Path(__file__).resolve().parents[2]
s=(r/'Source/SmartContactor.cs').read_text();a=s.index('        internal void SetOutputAddress(');b=s.index('        public override void BuildUpdate',a)
(Path(__file__).parent/'Extracted.cs').write_text('using System;using System.Linq;using Assets.Scripts.Objects;using Assets.Scripts.Networking;namespace ModularSwitchboards{public partial class SmartContactor{'+s[a:b]+'}}')
