using System;using System.IO;using System.Linq;using System.Reflection;using System.Runtime.Loader;using System.Reflection.Emit;
string managed=Path.GetFullPath(args[0]);AssemblyLoadContext.Default.Resolving+=(context,name)=>File.Exists(Path.Combine(managed,name.Name+".dll"))?context.LoadFromAssemblyPath(Path.Combine(managed,name.Name+".dll")):null;
var game=AssemblyLoadContext.Default.LoadFromAssemblyPath(Path.Combine(managed,"Assembly-CSharp.dll"));
var logic=game.GetType("Assets.Scripts.Objects.Pipes.ILogicable",true);var setting=game.GetType("Assets.Scripts.Objects.Electrical.LogicType",false)??game.GetType("Assets.Scripts.Objects.Motherboards.LogicType",true);
var read=logic.GetMethod("GetLogicValue",new[]{setting});if(read==null)throw new Exception("Store read signature changed");Console.WriteLine(read);
var chip=game.GetType("Assets.Scripts.Objects.Electrical.ProgrammableChip",true);
var opcodes=typeof(OpCodes).GetFields(BindingFlags.Public|BindingFlags.Static).Where(f=>f.FieldType==typeof(OpCode)).Select(f=>(OpCode)f.GetValue(null)).ToDictionary(op=>unchecked((ushort)op.Value));
foreach(var name in new[]{"_S_Operation","_SD_Operation","_SB_Operation","_SBN_Operation"}){var type=chip.GetNestedType(name,BindingFlags.NonPublic|BindingFlags.Public);var execute=type?.GetMethod("Execute",BindingFlags.Instance|BindingFlags.Public|BindingFlags.NonPublic);if(execute?.GetMethodBody()==null)throw new Exception("Native store layout changed: "+name);var il=execute.GetMethodBody().GetILAsByteArray();int reads=0;
 for(int at=0;at<il.Length;){ushort value=il[at++];if(value==0xfe)value=(ushort)(0xfe00|il[at++]);var op=opcodes[value];
  if(op.OperandType==OperandType.InlineMethod){try{var called=execute.Module.ResolveMethod(BitConverter.ToInt32(il,at));if(called.DeclaringType==logic&&called.Name==read.Name)reads++;}catch(ArgumentException){}}
  int width=op.OperandType switch{OperandType.InlineNone=>0,OperandType.ShortInlineBrTarget or OperandType.ShortInlineI or OperandType.ShortInlineVar=>1,OperandType.InlineVar=>2,OperandType.InlineI8 or OperandType.InlineR=>8,OperandType.InlineSwitch=>4+4*BitConverter.ToInt32(il,at),_=>4};at+=width;
 }
 if(reads!=1)throw new Exception("Expected one native store read, got "+reads+": "+name);Console.WriteLine(type.FullName+"."+execute.Name+": one matching IL read");}
Console.WriteLine("Native store reflection targets verified; no Unity execution performed.");
