from pathlib import Path
r=Path(__file__).resolve().parents[2]
s=(r/'Source/CabinetWiring.cs').read_text();a=s.index('        internal Assets.Scripts.Objects.Electrical.Cable SmartPowerCable(SmartModule module)');b=s.index('        private IEnumerable<CabinetWireSaveData> CircuitWires',a)
out='using System;using System.Linq;using System.Collections.Generic;using Assets.Scripts.Objects.Pipes;using Assets.Scripts.Networks;\nnamespace ModularSwitchboards{partial class CabinetWiring{'+s[a:b]+next(line for line in s.splitlines() if 'private int Capacity(CabinetWireEnd e)' in line)+'internal int ContactCapacity(CabinetWireEnd e)=>Capacity(e);'+'}\n'
s=(r/'Source/SmartModule.cs').read_text();a=s.index('        public bool IsValidIndex(');b=s.index('        public List<LogicBinding>',a)
out+='partial class SmartModule{'+s[a:b]+next(line for line in s.splitlines() if 'internal void ClearSupplyPower()' in line)+'}}'
(Path(__file__).parent/'Extracted.cs').write_text(out)
s=(r/'Source/SwitchboardsMod.cs').read_text();a=s.index('            if(__0.StructurePrefab is DinBreaker extension&&extension.IsSmartOutputModule)');b=s.index('            if (__0.StructurePrefab is DinBreaker module)',a)
(Path(__file__).parent/'Authority.cs').write_text('using Assets.Scripts.Objects;using ModularSwitchboards;using static ModularSwitchboards.SwitchboardsMod;\nstatic class Authority{public static bool Allows(Request __0){'+s[a:b]+'return false;}}')
