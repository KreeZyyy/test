using System;using System.Linq;using System.Collections.Generic;using Assets.Scripts.Objects.Pipes;using Assets.Scripts.Networks;
namespace ModularSwitchboards{partial class CabinetWiring{        internal Assets.Scripts.Objects.Electrical.Cable SmartPowerCable(SmartModule module)
        {
            if(Owner==null||Owner.IsCursor||!Owner.IsStructureCompleted||Owner.GridController==null)return null;
            // Power follows the live internal circuit, independently of any external data/output cable.
            return WireCircuit.Reachable(new CabinetWireEnd(0,0),new CabinetWireEnd(module.ReferenceId,0),
                CircuitWires,Breakers.Where(b=>b.Conducting).Select(b=>b.ReferenceId))?Owner.InputConnection?.GetCable():null;
        }
        internal Assets.Scripts.Objects.Electrical.Cable SmartCable(SmartModule module)
        {
            return SmartCable(module.ReferenceId);
        }
        internal Assets.Scripts.Objects.Electrical.Cable SmartCable(long id,int tapContact=0)
        {
            if(Owner==null||Owner.IsCursor||!Owner.IsStructureCompleted||Owner.GridController==null)return null;
            var modules=Breakers.ToArray();
            int selection=SmartCircuit.Selection(id,CircuitWires,
                modules.Where(b=>b.Conducting).Select(b=>b.ReferenceId),
                modules.Where(b=>!b.IsAnalyserModule&&!b.IsBatteryModule&&!b.IsSmartOutputModule&&!b.IsDoorPart).Select(b=>b.ReferenceId).Concat(Contactors.Select(c=>c.ReferenceId)),tapContact);
            if(selection==AnalyserCircuit.Input)return Owner.InputConnection?.GetCable();
            if(selection==0)return null;
            var cables=new[]{Owner.Output1Connection,Owner.Output2Connection,Owner.Output3Connection}
                .Select((port,i)=>new{port,bit=i==2?8:1<<i}).Where(p=>(selection&p.bit)!=0)
                .Select(p=>p.port?.GetCable()).ToArray();
            // Register the real device on exactly one native network. Never bridge
            // unrelated output data networks through the internal module.
            if(cables.Select(c=>c?.CableNetwork).Distinct().Count()!=1)return null;
            return cables.FirstOrDefault(c=>c!=null&&c.CableNetwork!=null);
        }

        private int Capacity(CabinetWireEnd e)=>e.Owner==0?e.Capacity:e.Contact==1&&Breakers.FirstOrDefault(b=>b.ReferenceId==e.Owner&&!b.IsBatteryModule&&!b.IsAnalyserModule&&!b.IsDoorPart&&!b.IsSmartOutputModule) is DinBreaker module?(module.IsFuseHolder?2:3):1;internal int ContactCapacity(CabinetWireEnd e)=>Capacity(e);}
partial class SmartModule{        public bool IsValidIndex(int index)=>index==int.MaxValue||SmartOutputAddresses.Valid(index);
        public ILogicable GetLogicableFromIndex(int index,int networkIndex=int.MinValue)=>index==int.MaxValue?(networkIndex==int.MinValue?this:SmartBus.NetworkAt(this,networkIndex)):index>=0&&networkIndex==int.MinValue?SmartBus.OutputAt(this,index):null;
        public ILogicable GetLogicableFromId(int id,int networkIndex=int.MinValue)
        {
            if(id==ReferenceId)return networkIndex==int.MinValue?this:SmartBus.NetworkAt(this,networkIndex);
            var device=Referencable.Find<Device>(id);
            return device!=null&&(SmartBus.AddressedOutputs(this).Any(o=>o==device)||SmartBus.Networks(this).Any(n=>n.DataDeviceList.Contains(device)))?networkIndex==int.MinValue?(ILogicable)device:device.GetNetwork(networkIndex):null;
        }
        public List<ILogicable> GetBatchOutput()=>SmartBus.Networks(this).SelectMany(n=>n.DataDeviceList).Concat(SmartBus.AddressedOutputs(this).Cast<Device>()).GroupBy(d=>d.ReferenceId).Select(g=>(ILogicable)g.First()).ToList();
        internal void ClearSupplyPower()=>AssessPower(null,false);}}