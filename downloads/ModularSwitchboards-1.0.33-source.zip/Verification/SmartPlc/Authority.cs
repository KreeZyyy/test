using Assets.Scripts.Objects;using ModularSwitchboards;using static ModularSwitchboards.SwitchboardsMod;
static class Authority{public static bool Allows(Request __0){            if(__0.StructurePrefab is DinBreaker extension&&extension.IsSmartOutputModule)
                return __0.Constructor!=null&&__0.Constructor.PrefabName==SmartKitName&&__0.Board is DinModuleBoard outputBoard&&SmartBus.CanPlace(outputBoard,__0.Position,__0.Rotation);
return false;}}