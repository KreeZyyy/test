using System;using System.Linq;using ModularSwitchboards;
class Program
{
 static int n;static void Check(bool v,string m){n++;if(!v)throw new Exception(m);}
 static CabinetWireSaveData W(long a,int p,long b,int q)=>new(){From=new(a,p),To=new(b,q)};
 static void Main()
 {
  long[] outputs={20,21},coils={10,11};
  bool Allowed(long a,int p,long b,int q)=>SmartContactorCircuit.Allowed(new(a,p),new(b,q),outputs,coils);
  Check(Allowed(20,1,10,2)&&Allowed(10,2,20,1),"OUT to A1 must accept either click order");
  Check(!Allowed(20,1,0,1),"PLC output wired directly to cabinet load");
  Check(!Allowed(20,1,10,0),"PLC output wired to contactor mains IN");
  Check(!Allowed(20,0,10,2)&&!Allowed(20,2,10,2),"removed IN/DATA still available");
  Check(!Allowed(20,1,21,1),"outputs shorted together");
  Check(!Allowed(20,1,30,2),"output connected to door bridge");
  Check(Allowed(0,0,10,2)&&Allowed(30,1,10,2),"ordinary supply/button cannot feed A1");
  var old=new[]{W(0,0,20,0),W(20,1,0,1),W(20,1,10,2),W(0,0,10,0),W(10,1,0,1),W(21,1,11,2)};
  var graph=SmartContactorCircuit.ValidWires(old,outputs,coils).ToArray();
  Check(graph.Length==4&&graph.All(w=>w.From.Owner!=20||w.To.Contact==2),"legacy load wires not excluded");
  long[] Solve(long[] active,bool mains=true)=>ContactorCircuit.Resolve(graph,Array.Empty<long>(),coils,Array.Empty<long>(),mains,Array.Empty<long>(),active.Select(id=>new CabinetWireEnd(id,1))).OrderBy(x=>x).ToArray();
  Check(Solve(Array.Empty<long>()).Length==0,"main supply energizes PLC coil while OFF");
  Check(Solve(new long[]{20}).SequenceEqual(new long[]{10}),"d0 does not isolate d1");
  Check(Solve(new long[]{21}).SequenceEqual(new long[]{11}),"d1 does not isolate d0");
  Check(Solve(outputs).SequenceEqual(coils),"both channels cannot energize together");
  Check(Solve(new long[]{20},false).SequenceEqual(new long[]{10}),"coil needs separate main supply despite Core control");
  Check(!WireCircuit.Reachable(new(20,1),new(0,1),graph,new long[]{10}),"PLC control backfeeds mains");
  Check(WireCircuit.Reachable(new(0,0),new(0,1),graph,new long[]{10}),"energized contactor fails to pass its independent mains");
  Check(!WireCircuit.Reachable(new(0,0),new(0,1),graph,Array.Empty<long>()),"open contactor passes mains");
  Check(ContactorCircuit.Resolve(graph,Array.Empty<long>(),coils,new long[]{10,11},true,Array.Empty<long>()).Count==0,"Core power loss fails to release coils");
  var button=new[]{W(0,0,30,0),W(30,1,10,2)};
  Check(ContactorCircuit.Resolve(button,new long[]{30},coils,Array.Empty<long>(),true,Array.Empty<long>()).Contains(10),"normal button control no longer works");
  Check(!ContactorCircuit.Resolve(button,Array.Empty<long>(),coils,new long[]{10},true,Array.Empty<long>()).Any(),"button release fails");
  Console.WriteLine(n+" PLC control circuit checks passed: OUT/A1 rules, channel isolation, independent mains, Core loss, legacy cleanup, buttons.");
 }
}
