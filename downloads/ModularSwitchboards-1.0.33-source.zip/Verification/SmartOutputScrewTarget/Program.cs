using System;using ModularSwitchboards;using Assets.Scripts.Objects;using UnityEngine;
namespace UnityEngine
{
 public struct Quaternion{public float Angle;public Quaternion(float angle){Angle=angle;}}public static class Mathf{public static float Abs(float v)=>Math.Abs(v);}
 public struct Vector3{public static Vector3 Scale(Vector3 a,Vector3 b)=>new(a.x*b.x,a.y*b.y,a.z*b.z);public float x,y,z;public Vector3(float x,float y,float z){this.x=x;this.y=y;this.z=z;}}
 public struct Bounds{public Vector3 center,size;public Bounds(Vector3 c,Vector3 s){center=c;size=s;}public bool Contains(Vector3 p)=>Math.Abs(p.x-center.x)<=size.x/2&&Math.Abs(p.y-center.y)<=size.y/2&&Math.Abs(p.z-center.z)<=size.z/2;}
 public class Transform{public Vector3 lossyScale=>Scale;public Vector3 position=>Position;public Quaternion rotation=>new(Angle);public float Angle;public Vector3 Position,Scale=new(1,1,1);public Vector3 InverseTransformPoint(Vector3 p){float x=p.x-Position.x,y=p.y-Position.y;return new((x*MathF.Cos(Angle)+y*MathF.Sin(Angle))/Scale.x,(-x*MathF.Sin(Angle)+y*MathF.Cos(Angle))/Scale.y,(p.z-Position.z)/Scale.z);}}
 public class Collider{public Bounds bounds;}
 public class BoxCollider:Collider{public Vector3 center,size;public Transform transform=new();}
}
namespace Assets.Scripts.Objects
{
 public class SelectionInstance{public Vector3 Position;public Quaternion Rotation;public Bounds Bounds;public int InteractableId;public long ParentThingRefernceId;public bool IsWorldMode;}
 public enum InteractableType{Mode,OnOff}
 public class Thing{}
 public class Interactable{public Thing Parent;public InteractableType Action;public Collider Collider;public int InteractableId;}
}
namespace ModularSwitchboards
{
 public class SmartContactor:Thing{public long ReferenceId=42;public SelectionInstance GetSelection(Collider c)=>new(){Bounds=c.bounds,ParentThingRefernceId=ReferenceId,IsWorldMode=true,InteractableId=-1};}
}
class Program
{
 static int n;static void Check(bool v,string message){n++;if(!v)throw new Exception(message);}
 static void Main()
 {
  var owner=new SmartContactor();var hit=new BoxCollider{center=new(),size=new(.016f,.014f,.003f),bounds=new(new(1,2,3),new(.016f,.014f,.003f))};
  var control=new Interactable{Parent=owner,Action=InteractableType.Mode,Collider=hit,InteractableId=7};
  var native=new SelectionInstance{Bounds=new(new(),new(.08f,.1f,.08f))};SmartOutputScrewTarget.AfterSelection(control,ref native);
  Check(!native.IsWorldMode&&native.Bounds.size.x==.016f&&native.Position.x==hit.transform.Position.x,"barehand preview retains whole-module bounds/padding");Check(native.InteractableId==7&&native.ParentThingRefernceId==42,"screw preview loses native target identity");
  var tool=SmartOutputScrewTarget.Selection(owner,control);Check(tool.Bounds.size.x==native.Bounds.size.x&&tool.InteractableId==native.InteractableId,"screwdriver preview differs from barehand target");
  Check(SmartOutputScrewTarget.Contains(control,new(0,0,0))&&SmartOutputScrewTarget.Contains(control,new(.007f,.006f,0)),"click inside head rejected");
  Check(!SmartOutputScrewTarget.Contains(control,new(.012f,0,0))&&!SmartOutputScrewTarget.Contains(control,new(0,.02f,0)),"body/display click accepted as screw");
  Check(SmartOutputScrewTarget.Contains(control,new(0,0,.00150001f)),"raycast surface roundoff makes tool preview flicker");
  Check(!SmartOutputScrewTarget.Contains(control,new(0,0,.0018f)),"raycast tolerance extends far beyond head");
  hit.transform.Position=new(1,2,3);hit.transform.Angle=MathF.PI/4;hit.transform.Scale=new(2,1,1);
  var rotated=SmartOutputScrewTarget.Selection(owner,control);Check(!rotated.IsWorldMode&&rotated.Position.x==1&&rotated.Rotation.Angle==hit.transform.Angle&&rotated.Bounds.size.x==.032f,"rotated tool highlight becomes a world-axis bounding box");
  Check(SmartOutputScrewTarget.Contains(control,new(1,2,3)),"rotated/mounted screw centre rejected");
  Check(!SmartOutputScrewTarget.Contains(control,new(1.015f,2,3)),"world-AABB corner outside rotated head accepted");
  var original=new SelectionInstance();native=original;control.Parent=new Thing();SmartOutputScrewTarget.AfterSelection(control,ref native);Check(ReferenceEquals(native,original),"vanilla housing/other Thing selection modified");
  control.Parent=owner;control.Action=InteractableType.OnOff;SmartOutputScrewTarget.AfterSelection(control,ref native);Check(ReferenceEquals(native,original),"non-address selection modified");
  control.Action=InteractableType.Mode;control.Collider=null;SmartOutputScrewTarget.AfterSelection(control,ref native);Check(ReferenceEquals(native,original)&&!SmartOutputScrewTarget.Contains(control,new()),"missing/cached collider targeted");
  Console.WriteLine(n+" actual screw targeting checks passed: barehand/tool bounds, native identity, head-only hits, rotated transforms and vanilla isolation.");
 }
}
