using System;using System.Linq;using System.Collections.Generic;using ModularSwitchboards;
class Program
{
 static int n;static void Check(bool v,string m){n++;if(!v)throw new Exception(m);}
 static SmartUpgradePart Core(long id,int x)=>new(id,x,4,true,false,false);
 static SmartUpgradePart Net(long id,int x)=>new(id,x,1,false,true,false);
 static SmartUpgradePart Output(long id,int x,int width=1)=>new(id,x,width,false,true,true);
 static SmartUpgradePart Fixed(long id,int x,int width=1)=>new(id,x,width,false,false,false);
 static void Main()
 {
  var row=new[]{Core(1,1),Net(2,5),Output(3,6),Net(4,7)};var plan=SmartOutputUpgradeLayout.Plan(row,1,10);
  Check(plan[1].X==1&&plan[2].X==5,"Core/inner NET moved");Check(plan[3].X==6&&plan[3].Width==2&&plan[4].X==8,"legacy Output failed to expand and shift outer NET");
  var second=SmartOutputUpgradeLayout.Plan(plan.Values,1,10);Check(second.All(p=>plan[p.Key].X==p.Value.X&&plan[p.Key].Width==p.Value.Width),"reload migrates twice");
  plan=SmartOutputUpgradeLayout.Plan(row,1,7);Check(plan[3].Width==1&&plan[4].X==7,"full rail overwritten");
  plan=SmartOutputUpgradeLayout.Plan(row.Append(Fixed(5,8)),1,10);Check(plan[3].Width==1&&plan[5].X==8,"unrelated module displaced");
  plan=SmartOutputUpgradeLayout.Plan(new[]{Core(1,1),Output(2,5),Output(3,6),Net(4,7)},1,10);Check(plan[2].X==5&&plan[2].Width==2&&plan[3].X==7&&plan[3].Width==2&&plan[4].X==9,"multiple legacy outputs overlap");
  plan=SmartOutputUpgradeLayout.Plan(new[]{Core(1,1),Output(2,5),Output(3,7)},1,10);Check(plan[2].Width==1&&plan[3].Width==1&&plan[3].X==7,"expansion silently closed an intentional bus gap");
  plan=SmartOutputUpgradeLayout.Plan(new[]{Core(1,1),Output(2,5,2),Net(3,7)},1,10);Check(plan[2].Width==2&&plan[3].X==7,"new two-slot model unnecessarily moved");
  plan=SmartOutputUpgradeLayout.Plan(new[]{Core(1,1),Output(2,5),Core(3,7),Output(4,11)},1,14);Check(plan[2].Width==2&&plan[4].Width==2&&plan[3].X==7,"separate Cores interfere");
  var rng=new Random(130);for(int run=0;run<1000;run++)
  {
   var parts=new List<SmartUpgradePart>{Core(1,1)};int x=5,count=rng.Next(1,8),extra=0;
   for(int i=0;i<count;i++){bool output=rng.Next(2)==0;int width=output?rng.Next(1,3):1;parts.Add(new(i+2,x,width,false,true,output));x+=width;if(output&&width==1)extra++;}
   int gap=rng.Next(0,8);parts.Add(Fixed(100,x+gap));int capacity=x+gap+2;var p=SmartOutputUpgradeLayout.Plan(parts,1,capacity);
   Check(p[100].X==x+gap&&p[1].X==1,"random fixture moves unrelated modules");
   Check(p.Values.All(a=>a.X>=1&&a.X+a.Width<=1+capacity),"random rail overflow");
   foreach(var a in p.Values)Check(!p.Values.Any(b=>a.Id!=b.Id&&a.X<b.X+b.Width&&b.X<a.X+a.Width),"random overlapping footprints");
   bool canFit=extra<=gap;Check(parts.Where(a=>a.Output).All(a=>p[a.Id].Width==(canFit?2:a.Width)),"partial/incorrect group migration");
  }
  Console.WriteLine(n+" Output width migration checks passed: saved mixed bus, atomic expansion, two-slot occupancy, blockers, capacity, gaps, idempotence and random layouts.");
 }
}
