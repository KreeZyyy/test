using System;using System.Collections.Generic;using System.Linq;using Assets.Scripts.Objects;using ModularSwitchboards;using UnityEngine;
class Program{
 static int n;static void Check(bool v,string message){n++;if(!v)throw new Exception(message);}
 static void Main(){
 var white=new Material{name="ColorWhite"};var dark=new Material{name="spaceships_dif"};
 Check(SmartPaintSurface.WhiteSubmesh(new[]{dark,white},white)==1,"wrong white material");
 Check(SmartPaintSurface.WhiteSubmesh(new[]{new Material{name="ColorWhite"},dark},white)==0,"native name fallback missing");
 bool failed=false;try{SmartPaintSurface.WhiteSubmesh(new[]{dark},white);}catch(InvalidOperationException){failed=true;}Check(failed,"dark backing accepted as bezel");
 var native=new Mesh{subMeshCount=2};native.SetTriangles(new[]{0,1,2},0);native.SetTriangles(new[]{3,4,5,5,6,3},1);native.Geometry="native vertex positions";
 var frame=SmartPaintSurface.ExtractFrame(native,0);
 Check(frame.GetTriangles(1).SequenceEqual(new[]{0,1,2}),"frame contains dark triangles");
 Check(Enumerable.Range(0,5).Where(i=>i!=1).All(i=>frame.GetTriangles(i).Length==0),"paint leaks to other roles");
 Check(native.GetTriangles(0).Length==0&&native.GetTriangles(1).SequenceEqual(new[]{3,4,5,5,6,3}),"backing lost native triangles");
 Check(native.UV=="native"&&frame.UV=="casing"&&frame.Geometry==native.Geometry,"UV/material split altered original geometry or native backing UV");
 var smart=new SmartModule();var screen=Surface(smart,"Screen");var socket=Surface(smart,"OriginalSocketFrame");var backing=Surface(smart,"NativeLEDHousingDetails");var painted=Surface(smart,"NativeLEDBezel");var chip=Surface(new Thing(),"Chip");
 smart.Surfaces.AddRange(new[]{screen,socket,backing,painted,chip});
 SmartPaintSurface.RestoreNative(smart);
 foreach(var p in new[]{screen,socket,backing})Check(p.Restores==1&&p.Renderer.Tint==null&&p.Renderer.Material=="original"&&p.Renderer.Emission=="original","native part retains paint or emission");
 Check(painted.Restores==0&&painted.Renderer.Tint=="red"&&chip.Restores==0,"painted bezel or inserted chip reset");
 SmartPaintSurface.RestoreNative(smart);Check(screen.Restores==2&&screen.Renderer.Tint==null,"repeat refresh restores tint");
 var ordinary=new Thing();var ordinarySurface=Surface(ordinary,"Screen");ordinary.Surfaces.Add(ordinarySurface);SmartPaintSurface.RestoreNative(ordinary);Check(ordinarySurface.Restores==0,"ordinary LED changed");
 foreach(var name in new[]{"Screen","OriginalSocketFrame","NativeLEDHousingDetails","DigitTransform","Chip"})Check(!SmartPaintSurface.IsPainted(name),"protected renderer offered to native painter");
 Check(SmartPaintSurface.IsPainted("DinBreakerModel")&&SmartPaintSurface.IsPainted("NativeLEDBezel"),"casing/rim not paintable");
 var output=new SmartContactor();var nativeOutputScreen=Surface(output,"Screen");var nativeScrew=Surface(output,"OutputAddressScrew");var outputRim=Surface(output,"NativeLEDBezel");output.Surfaces.AddRange(new[]{nativeOutputScreen,nativeScrew,outputRim});SmartPaintSurface.RestoreNative(output);Check(nativeOutputScreen.Restores==1&&nativeScrew.Restores==1&&outputRim.Restores==0,"Output screen/screw protected or bezel paint lost");
 Console.WriteLine(n+" Smart paint isolation checks passed: white-rim-only geometry, native backing UV, protected grid/socket, no inherited emission, other Things untouched.");
 }
 static NativePortSurface Surface(Thing owner,string name)=>new(){Renderer=new(){Owner=owner,name=name,Tint="red",Material="painted",Emission="white glow"}};
}
namespace Assets.Scripts.Objects{public class Thing{internal List<NativePortSurface> Surfaces=new();public T[] GetComponentsInChildren<T>(bool include)=>Surfaces.Cast<T>().ToArray();}}
namespace ModularSwitchboards{
 class SmartModule:Thing{} class SmartContactor:Thing{}
 class NativePortSurface{public MeshRenderer Renderer;public int Restores;public T GetComponent<T>()where T:class=>Renderer as T;public void Restore(){Restores++;Renderer.Material="original";Renderer.Emission="original";}}
 static class CabinetGeometry{public static void ApplyNativeUv(Mesh mesh)=>mesh.UV="casing";}
}
namespace UnityEngine{
 class Object{public static Mesh Instantiate(Mesh source)=>source.Clone();}
 class Material{public string name;}
 class Mesh{
 public string name,Geometry,UV="native";int[][] indices=Array.Empty<int[]>();
 public int subMeshCount{get=>indices.Length;set{Array.Resize(ref indices,value);for(int i=0;i<value;i++)indices[i]??=Array.Empty<int>();}}
 public int[] GetTriangles(int i)=>indices[i];public void SetTriangles(int[] a,int i)=>indices[i]=a.ToArray();
 public Mesh Clone(){var m=new Mesh{Geometry=Geometry,UV=UV,subMeshCount=subMeshCount};for(int i=0;i<indices.Length;i++)m.SetTriangles(indices[i],i);return m;}
 }
 class MeshRenderer{public string name,Tint,Material,Emission;public Thing Owner;public T GetComponentInParent<T>()where T:class=>Owner as T;public void SetPropertyBlock(object block)=>Tint=null;}
}
