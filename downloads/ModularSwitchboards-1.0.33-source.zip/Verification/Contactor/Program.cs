using System;using System.Linq;using ModularSwitchboards;
class Program
{
 static int checks;static void Check(bool v,string name){checks++;if(!v)throw new Exception(name);}
 static CabinetWireSaveData W(long a,int p,long b,int q)=>new CabinetWireSaveData{From=new CabinetWireEnd(a,p),To=new CabinetWireEnd(b,q)};
 static long[] Solve(CabinetWireSaveData[] w,bool live,long[] old=null,long[] fixedClosed=null,long[] cells=null,long[] ids=null)=>ContactorCircuit.Resolve(w,fixedClosed??new long[0],ids??new long[]{10},old??new long[0],live,cells??new long[0]).OrderBy(x=>x).ToArray();
 static void Main()
 {
  var main=new[]{W(0,0,10,0),W(10,1,0,1)};
  Check(Solve(main,true).Length==0,"coil unconnected stays open");
  var direct=main.Append(W(0,0,10,2)).ToArray();var picked=Solve(direct,true);
  Check(picked.SequenceEqual(new long[]{10}),"powered coil picks up");
  Check(WireCircuit.Reachable(new CabinetWireEnd(0,0),new CabinetWireEnd(0,1),direct,picked),"mains closed");
  Check(!WireCircuit.Reachable(new CabinetWireEnd(10,2),new CabinetWireEnd(10,1),direct,picked),"coil cannot feed main OUT");
  Check(Solve(direct,false,new long[]{10}).Length==0,"supply loss releases");
  var switched=main.Concat(new[]{W(0,0,20,0),W(20,1,10,2)}).ToArray();
  Check(Solve(switched,true,fixedClosed:new long[]{20}).Length==1,"control switch closes coil");
  Check(Solve(switched,true,new long[]{10}).Length==0,"control switch opens coil");
  Check(Solve(main,true,new long[]{10}).Length==0,"coil wire removal releases");
  var isolated=new[]{W(0,0,10,2),W(10,1,0,1)};
  Check(Solve(isolated,true).Length==1,"coil may close without main IN");
  Check(!WireCircuit.Reachable(new CabinetWireEnd(0,0),new CabinetWireEnd(0,1),isolated,new long[]{10}),"coil never backfeeds lamp");
  var held=main.Append(W(10,1,10,2)).ToArray();
  Check(Solve(held,true).Length==0,"self-fed coil cannot cold-start");
  Check(Solve(held,true,new long[]{10}).Length==1,"live held circuit retained");
  Check(Solve(held,false,new long[]{10}).Length==0,"held circuit releases without source");
  Check(Solve(held,true).Length==0,"restore source does not resurrect dropped latch");
  var backup=main.Append(W(30,1,10,2)).ToArray();
  Check(Solve(backup,false,cells:new long[]{30}).Length==1,"live backup feeds coil");
  Check(Solve(backup,false,new long[]{10}).Length==0,"empty backup releases");
  var chain=new[]{W(0,0,10,2),W(0,0,10,0),W(10,1,11,2),W(10,1,11,0),W(11,1,0,1)};
  Check(Solve(chain,true,ids:new long[]{11,10}).Length==2,"cascaded coils settle independent of order");
  Check(Solve(chain,false,new long[]{10,11},ids:new long[]{11,10}).Length==0,"cascaded supply loss releases all");
  Check(!WireCircuit.Reachable(new CabinetWireEnd(0,0),new CabinetWireEnd(0,1),main,new long[0]),"open contact blocks mains");
  Console.WriteLine(checks+" Contactor circuit checks passed: pickup/release, control/mains isolation, held circuits, source loss, backup, cascades.");
 }
}
