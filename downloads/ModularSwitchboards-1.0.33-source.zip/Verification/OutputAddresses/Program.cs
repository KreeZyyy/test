using System;using System.Linq;using System.Collections.Generic;using ModularSwitchboards;
class Program
{
 static int checks;static void Check(bool v,string m){checks++;if(!v)throw new Exception(m);}
 static KeyValuePair<long,int> P(long id,int d)=>new(id,d);
 static void Main()
 {
  var first=SmartOutputAddresses.Resolve(new[]{P(10,-1),P(20,-1),P(30,-1)});Check(first[10]==0&&first[20]==1&&first[30]==2,"initial free addresses");
  var reordered=SmartOutputAddresses.Resolve(new[]{P(30,2),P(10,0),P(20,1)});Check(reordered[10]==0&&reordered[20]==1&&reordered[30]==2,"physical order changes existing addresses");
  var removed=SmartOutputAddresses.Resolve(new[]{P(20,1),P(30,2),P(40,-1)});Check(removed[20]==1&&removed[30]==2&&removed[40]==0,"removal shifts existing channels");
  var collision=SmartOutputAddresses.Resolve(new[]{P(10,2),P(20,2),P(30,5)});Check(collision[10]==2&&collision[20]==0&&collision[30]==5,"load collision policy");
  var full=SmartOutputAddresses.Resolve(Enumerable.Range(0,7).Select(i=>P(i+1,-1)));Check(full.Values.Count(v=>v==-1)==1&&full.Values.Where(v=>v>=0).Distinct().Count()==6,"more than six outputs aliased");
  Check(SmartOutputAddresses.NextFree(0,new[]{1,2,3})==4,"cycle skips occupied channels");
  Check(SmartOutputAddresses.NextFree(5,new[]{0,1,3,4})==2,"cycle wraps correctly");
  Check(SmartOutputAddresses.NextFree(2,new[]{0,1,3,4,5})==2,"full assembly should retain current address");
  Check(SmartOutputAddresses.NextFree(-1,Enumerable.Range(0,6))==-1,"full allocation invented free address");
  var random=new Random(128);for(int n=0;n<500;n++)
  {
   var list=Enumerable.Range(0,random.Next(1,12)).Select(i=>P(i+1,random.Next(-2,9))).ToArray();var result=SmartOutputAddresses.Resolve(list);var valid=result.Values.Where(SmartOutputAddresses.Valid).ToArray();
   Check(valid.Distinct().Count()==valid.Length,"random duplicate");Check(valid.Length==Math.Min(6,list.Length),"random free slot lost");
   Check(SmartOutputAddresses.Resolve(result.Reverse()).OrderBy(p=>p.Key).SequenceEqual(result.OrderBy(p=>p.Key)),"save/reload address instability");
  }
  Console.WriteLine(checks+" Output address checks passed: uniqueness, persistence, collisions, removal, six-channel bound and cycling.");
 }
}
