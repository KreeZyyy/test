using System;
using System.Linq;
using ModularSwitchboards;
using Assets.Scripts.Objects;
namespace Assets.Scripts.Objects {public class Structure {public string PrefabName;}}
class Program
{
 static Structure S(string n)=>new Structure{PrefabName=n};
 static void Main()
 {
  var normal=S("StructureVendingMachine");var cold=S("StructureRefrigeratedVendingMachine");
  var list=new[]{null,cold,S(null),S(""),normal,S("StructureLamp"),null,normal};
  var result=VendingSelection.Select(list);
  if(result.Length!=2||result[0]!=normal||result[1]!=cold)throw new Exception("null filtering/deduplication/order");
  if(VendingSelection.Select(null).Length!=0||VendingSelection.Select(new Structure[]{null,S(null)}).Length!=0)throw new Exception("empty input");
  // Mirrors a kit list containing missing constructables: the 1.0.15 crash.
  var combined=new[]{cold}.Concat(new Structure[]{null,normal,null});
  if(VendingSelection.Select(combined).Length!=2)throw new Exception("kit null regression");
  Console.WriteLine("Vending selection regression passed: null entries/names/collection, duplicate entries, ordinary priority, kit nulls.");
 }
}
