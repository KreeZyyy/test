using System;using System.IO;using ModularSwitchboards;
namespace ModularSwitchboards
{
 public struct Grid3{public int x,y,z;public Grid3(int x,int y,int z){this.x=x;this.y=y;this.z=z;}}
 public class RocketBinaryWriter:BinaryWriter{public RocketBinaryWriter(Stream s):base(s){}public void WriteInt32(int n)=>Write(n);public void WriteInt64(long n)=>Write(n);public void WriteGrid3(Grid3 p){Write(p.x);Write(p.y);Write(p.z);}public void WriteSByte(sbyte n)=>Write(n);}
 public class RocketBinaryReader:BinaryReader{public RocketBinaryReader(Stream s):base(s){}public Grid3 ReadGrid3()=>new(ReadInt32(),ReadInt32(),ReadInt32());}
 public class PlacementBoardStructureSaveData{public long BoardId,PrimaryHostId;public Grid3 Position;public int Rotation;}
 public class NativeDevice{public virtual void SerializeOnJoin(RocketBinaryWriter w)=>w.WriteInt32(130);public virtual void DeserializeOnJoin(RocketBinaryReader r){if(r.ReadInt32()!=130)throw new Exception("native prefix corrupt");}}
 public partial class SmartContactor:NativeDevice{public const int SlotCount=2;public int ModuleWidth=2,OutputAddress=-1,RegisteredWidth,AppliedWidth;public bool Restored;public PlacementBoardStructureSaveData BoardData;private void RestoreAddressState(){Restored=true;}}
 public static class BoardStructureHooks
 {
  public static void SerializeOnJoin(RocketBinaryWriter w,SmartContactor m){var b=m.BoardData;w.WriteInt64(b.BoardId);w.WriteInt64(b.PrimaryHostId);w.WriteGrid3(b.Position);w.WriteSByte((sbyte)b.Rotation);}
  public static void DeserializeSave(SmartContactor m,PlacementBoardStructureSaveData b){if(m.AppliedWidth!=m.ModuleWidth||!m.Restored)throw new Exception("occupancy registered before width/address restored");m.RegisteredWidth=m.ModuleWidth;m.BoardData=b;}
 }
 public static class SmartContactorModel{public static void ApplyWidth(SmartContactor m){m.AppliedWidth=m.ModuleWidth;}}
}
class Program
{
 static int n;static void Check(bool v,string m){n++;if(!v)throw new Exception(m);}
 static void Main(){foreach(int width in new[]{1,2})for(int address=0;address<6;address++)
 {
  var original=new SmartContactor{ModuleWidth=width,OutputAddress=address,BoardData=new(){BoardId=123,PrimaryHostId=456,Position=new(60,0,0),Rotation=0}};
  using var stream=new MemoryStream();var w=new RocketBinaryWriter(stream);original.SerializeOnJoin(w);stream.Position=0;
  var joined=new SmartContactor();joined.DeserializeOnJoin(new RocketBinaryReader(stream));
  Check(joined.OutputAddress==address&&joined.ModuleWidth==width,"saved address/width changed");Check(joined.RegisteredWidth==width,"legacy join briefly claimed second DIN position");Check(joined.BoardData.BoardId==123&&joined.BoardData.PrimaryHostId==456&&joined.BoardData.Position.x==60,"board metadata corrupt");Check(stream.Position==stream.Length,"join leaves unread bytes");
 }
 Console.WriteLine(n+" actual Output join checks passed: all six addresses, one/two-slot saves, native prefix, metadata, width-before-occupancy and byte consumption.");}
}
