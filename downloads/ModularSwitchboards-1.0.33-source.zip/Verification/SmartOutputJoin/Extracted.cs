namespace ModularSwitchboards{public partial class SmartContactor{public override void SerializeOnJoin(RocketBinaryWriter writer){base.SerializeOnJoin(writer);BoardStructureHooks.SerializeOnJoin(writer,this);writer.WriteInt32(OutputAddress);writer.WriteInt32(ModuleWidth);}public override void DeserializeOnJoin(RocketBinaryReader reader)
        {
            base.DeserializeOnJoin(reader);
            var savedBoard=new PlacementBoardStructureSaveData{BoardId=reader.ReadInt64(),PrimaryHostId=reader.ReadInt64(),Position=reader.ReadGrid3(),Rotation=reader.ReadSByte()};
            OutputAddress=reader.ReadInt32();ModuleWidth=reader.ReadInt32()==SlotCount?SlotCount:1;SmartContactorModel.ApplyWidth(this);RestoreAddressState();
            // Width must be known before RegisterLoading computes occupancy cells.
            BoardStructureHooks.DeserializeSave(this,savedBoard);
        }}}