using System;using System.Linq;using System.Collections.Generic;using System.Reflection;using ModularSwitchboards;using LibConstruct;using Assets.Scripts.Objects;using Assets.Scripts.GridSystem;
namespace Assets.Scripts{public static class GameManager{public static bool RunSimulation=true;}}
namespace UnityEngine{public static class Debug{public static List<string> Warnings=new();public static void Log(string s){}public static void LogWarning(string s)=>Warnings.Add(s);}}
namespace HarmonyLib{public static class AccessTools{public static FieldInfo Field(Type type,string name)=>type.GetField(name,BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.Static|BindingFlags.Instance);}}
namespace Assets.Scripts.GridSystem{public struct Grid3{public int x,y,z;public Grid3(int a,int b,int c){x=a;y=b;z=c;}}}
namespace Assets.Scripts.Objects{public class Structure{public long ReferenceId;public object transform=new();public object Bounds;}}
namespace LibConstruct
{
 internal interface IBoardRef{PlacementBoard Board{get;}}
 internal class BoardRef:IBoardRef{public PlacementBoard Actual;PlacementBoard IBoardRef.Board=>Actual;}
 public class PlacementBoardStructureSaveData{public Grid3 Position;public int Rotation;}
 public class PlacementBoard
 {
  private class StructurePair{public Structure Structure;public PlacementBoardStructureSaveData SaveData;}
  private static Dictionary<long,IBoardRef> LoadingRefs=new();private List<StructurePair> AwaitingRegister=new();
  public object PrimaryHost;public class BoardCell{public object Structure;}
  public List<BoardCell> CurrentCells=new();public IEnumerable<BoardCell> ValidBoundsCells(object transform,object bounds)=>CurrentCells;
  public void Add(Structure part,PlacementBoardStructureSaveData save)=>AwaitingRegister.Add(new(){Structure=part,SaveData=save});
  public static void Seed(params PlacementBoard[] boards){LoadingRefs.Clear();for(int i=0;i<boards.Length;i++)LoadingRefs.Add(i,new BoardRef{Actual=boards[i]});UnityEngine.Debug.Warnings.Clear();}
 }
}
namespace ModularSwitchboards
{
 public class SwitchboardCabinet{public string PrefabName;}
 public class DinRail:Structure{public PlacementBoard Board;}
 public class DinModuleBoard:PlacementBoard{}
 public class SmartModule:Structure{}
 public class DinBreaker:Structure{public bool IsSmartOutputModule;public int ModuleWidth=1;}
 public class SmartContactor:Structure{public const int SlotCount=2;public int ModuleWidth=1,OutputAddress;public PlacementBoard Board;public PlacementBoard.BoardCell[] BoardCells;public bool Applied;}
 public static class DinLayout{public const int FirstModuleSlot=1;public static int ModuleCount(float width)=>(int)width;}
 public static class CabinetShape{public static float RailWidth(string name)=>name=="Medium"?14:7;}
 public static class DinParts{public static int Width(Structure p)=>p is SmartModule?4:p is SmartContactor o?o.ModuleWidth:((DinBreaker)p).ModuleWidth;}
 public static class SmartContactorModel{public static void ApplyWidth(SmartContactor output){output.Applied=true;}}
}
class Program
{
 static int n;static void Check(bool v,string name){n++;if(!v)throw new Exception(name);}
 static PlacementBoardStructureSaveData S(int x)=>new(){Position=new(x*10,0,0)};
 static void Main()
 {
  var cabinet=new SwitchboardCabinet{PrefabName="Medium"};var outer=new PlacementBoard{PrimaryHost=cabinet};var rail=new DinRail{ReferenceId=1};outer.Add(rail,S(1));
  var board=new DinModuleBoard{PrimaryHost=rail};var core=new SmartModule{ReferenceId=2};var inner=new DinBreaker{ReferenceId=3,IsSmartOutputModule=true};var output=new SmartContactor{ReferenceId=4,OutputAddress=2};var outerNet=new DinBreaker{ReferenceId=5,IsSmartOutputModule=true};
  var positions=new[]{S(1),S(5),S(6),S(7)};board.Add(core,positions[0]);board.Add(inner,positions[1]);board.Add(output,positions[2]);board.Add(outerNet,positions[3]);
  PlacementBoard.Seed(board,outer);SmartOutputUpgrade.BeforeFinishLoad();
  Check(output.ModuleWidth==2&&output.Applied,"actual load prefix fails to expand saved Output");Check(output.OutputAddress==2,"migration changed d address");
  Check(positions[0].Position.x==10&&positions[1].Position.x==50&&positions[2].Position.x==60&&positions[3].Position.x==80,"saved board coordinates wrong");Check(UnityEngine.Debug.Warnings.Count==0,"valid Medium migration warned");
  SmartOutputUpgrade.BeforeFinishLoad();Check(output.ModuleWidth==2&&positions[3].Position.x==80,"second load shifts bus again");
  // Rail has not been registered yet. Small/Medium must come from its pending host.
  output.ModuleWidth=1;positions[3].Position=new(70,0,0);cabinet.PrefabName="Small";SmartOutputUpgrade.BeforeFinishLoad();Check(output.ModuleWidth==1&&positions[3].Position.x==70,"Small row overflowed");Check(UnityEngine.Debug.Warnings.Count==1,"blocked upgrade has no explanation");
  cabinet.PrefabName="Medium";Assets.Scripts.GameManager.RunSimulation=false;SmartOutputUpgrade.BeforeFinishLoad();Check(output.ModuleWidth==1,"client modifies saved layout");Assets.Scripts.GameManager.RunSimulation=true;
  PlacementBoard.Seed(board);SmartOutputUpgrade.BeforeFinishLoad();Check(output.ModuleWidth==1,"missing host guessed capacity and migrated");
  PlacementBoard.Seed(board,outer);positions[2].Rotation=1;SmartOutputUpgrade.BeforeFinishLoad();Check(output.ModuleWidth==1,"invalid saved rotation migrated");positions[2].Rotation=0;
  // Reindex after joining must release only this instance's old cells.
  var owned=new PlacementBoard.BoardCell{Structure=output};var neighbour=new PlacementBoard.BoardCell{Structure=inner};var target=new PlacementBoard.BoardCell();output.Board=board;output.BoardCells=new[]{owned,neighbour};board.CurrentCells.Add(target);SmartOutputUpgrade.Reindex(output);
  Check(owned.Structure==null&&ReferenceEquals(neighbour.Structure,inner)&&ReferenceEquals(target.Structure,output),"reindex destroys another instance's cell ownership");
  Console.WriteLine(n+" actual Output load-upgrade checks passed: private LibConstruct records, delayed host, Small/Medium limits, client guards, address retention, idempotence and occupancy reindex.");
 }
}
