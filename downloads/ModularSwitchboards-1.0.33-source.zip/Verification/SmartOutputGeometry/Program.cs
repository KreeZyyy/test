using System;using System.IO;using System.Linq;using System.Text.Json;using ModularSwitchboards;using UnityEngine;
class Program
{
 static int checks;static void Check(bool v,string name){checks++;if(!v)throw new Exception(name);}
 static void Main(string[] args)
 {
  var root=args[0];var body=DinBreakerModel.Build(SmartContactor.BodyWidth,SmartContactor.CenterX,plain:true,bottomOnly:true);var screw=HousingAddressScrew.Build();
  var net=SmartOutputModel.Housing();
  var netFace=net.T[3].Select(i=>net.V[i]).Where(p=>p.z>.063f).ToArray();var outputFace=body.T[3].Select(i=>body.V[i]).Where(p=>p.z>.063f).ToArray();
  Check(Math.Abs(netFace.Min(p=>p.y)-outputFace.Min(p=>p.y))<1e-6&&Math.Abs(netFace.Max(p=>p.y)-outputFace.Max(p=>p.y))<1e-6,"NET and Output dark faces have different top/bottom heights");
  Check(Math.Abs(body.V.Max(p=>p.x)-body.V.Min(p=>p.x)-SmartContactor.BodyWidth)<1e-6,"body width must cover two slots");
  Check(body.V.All(p=>p.z<=.06401f),"body keeps the obsolete proxy display rim");
  Check(screw.V.Count==83&&screw.T[0].Length==120,"original housing selector topology changed");
  using var source=JsonDocument.Parse(File.ReadAllText(Path.Combine(root,"Art/CircuitHousing-reference.json")));var mesh=source.RootElement.GetProperty("Meshes").EnumerateArray().Single(m=>m.GetProperty("Name").GetString()=="SphereColliderTriggerRendererButton1NoShadow");
  var original=mesh.GetProperty("Vertices").EnumerateArray().Select(v=>new Vector3(v.GetProperty("x").GetSingle(),v.GetProperty("y").GetSingle(),v.GetProperty("z").GetSingle())).ToArray();
  var uv=mesh.GetProperty("Uv").EnumerateArray().Select(v=>new Vector2(v.GetProperty("x").GetSingle(),v.GetProperty("y").GetSingle())).ToArray();
  Check(mesh.GetProperty("Parts")[0].GetProperty("Triangles").EnumerateArray().Select(t=>t.GetInt32()).SequenceEqual(screw.T[0]),"housing screw triangles differ from supplied reference");
  var bounds=new Bounds(original[0],new Vector3());foreach(var p in original)bounds.Encapsulate(p);float fit=.016f/Math.Max(bounds.size.x,bounds.size.y);
  for(int i=0;i<83;i++)
  {
   var p=original[i];var q=screw.V[i];Check(Math.Abs((q.x-HousingAddressScrew.Center.x)*2.25f-(p.x-bounds.center.x)*fit)<1e-7&&Math.Abs((q.y-HousingAddressScrew.Center.y)*1.35f-(p.y-bounds.center.y)*fit)<1e-7&&Math.Abs((q.z-HousingAddressScrew.Center.z)*1.15f-(p.z-bounds.min.z)*fit)<1e-7,"native screw is distorted or offset");
   Check(screw.uv[i].x==uv[i].x&&screw.uv[i].y==uv[i].y,"native screw UVs changed");
  }
  Check(screw.V.Max(p=>p.y)<-.007f&&screw.V.Min(p=>p.y)>-.023f,"screw overlaps screen or lower terminal");
  Check(screw.V.Max(p=>p.z)>.064f&&screw.V.Max(p=>p.z)<.068f,"screw head hidden or protrudes too far");
  var target=HousingAddressScrew.TargetBounds(screw.bounds);
  Check(Math.Abs(target.size.x*2.25f-.018f)<1e-6,"16 mm head needs exactly 1 mm target margin on each side");
  Check(target.min.z>=.06369f&&target.max.z>screw.bounds.max.z&&target.min.z>screw.bounds.min.z,"screw hitbox exposes buried shaft or hides head");
  foreach(var p in screw.V.Where(p=>p.z>=target.min.z))Check(target.Contains(p),"visible screw vertex escapes target collider");
  Check(target.max.y<-.007f&&target.min.y>-.024f,"larger target overlaps LED screen or lower terminal");
  // Regression: in 1.0.31 the fascia concealed the native groove floor,
  // leaving two disconnected-looking halves when viewed straight on.
  float groove=original.Select(v=>v.z).Distinct().OrderBy(z=>z).Skip(1).First();
  var floor=screw.V.Where((p,i)=>Math.Abs(original[i].z-groove)<1e-7).ToArray();
  Check(floor.Length>0&&floor.All(p=>p.z>.0643f),"fascia still hides the native screw groove floor");
  Check(screw.bounds.max.z*1.15f-.064f*1.15f>.003f,"head does not project far enough to read as a screw");
  using var core=JsonDocument.Parse(File.ReadAllText(Path.Combine(root,"Art/CoreLED-reference.json")));var nativePanel=core.RootElement.EnumerateArray().Select(p=>new{name=p.GetProperty("name").GetString(),vertices=p.GetProperty("vertices").EnumerateArray().Select(v=>new[]{.02025f+(v[0].GetSingle()-.085f)*.55f,.00135f+v[1].GetSingle()*.55f,.0743f+(v[2].GetSingle()-.0743f)*.55f}).ToArray(),triangles=p.GetProperty("triangles").EnumerateArray().Select(g=>g.EnumerateArray().Select(i=>i.GetInt32()).ToArray()).ToArray()}).ToArray();
  foreach(var p in nativePanel){Check(p.vertices.All(v=>v[0]>-.0198f&&v[0]<.0603f&&v[1]>-.012f&&v[1]<.015f),"Core LED outside two-slot fascia");if(p.name=="screen")Check(p.vertices.All(v=>v[2]>.0736f),"native LED screen hidden inside body");}
  object Dump(Mesh m)=>new{vertices=m.V.Select(v=>new[]{v.x,v.y,v.z}),triangles=m.T};File.WriteAllText(Path.Combine(root,"Art/SmartOutputGeometry.json"),JsonSerializer.Serialize(new{body=Dump(body),screw=Dump(screw),nativePanel}));
  Console.WriteLine(checks+" exact Output geometry checks passed: two slots, original 83-vertex screw/UVs/40 triangles, recess, Core LED clearance and native screen depth.");
 }
}
