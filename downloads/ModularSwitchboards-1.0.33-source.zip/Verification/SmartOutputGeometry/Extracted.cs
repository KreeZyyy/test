using System;using System.IO;using System.Reflection;using System.Linq;using System.Collections.Generic;using UnityEngine;namespace ModularSwitchboards{static class DinBreakerModel{internal static Vector3 VisualScale=new(2.25f,1.35f,1.15f);internal static Mesh Build(float width=.0176f,float centerX=0f,bool battery=false,float openingX=0f,float openingY=0f,bool plain=false,bool inputOnly=false,bool bottomOnly=false)
        {
            var vertices=new List<Vector3>();var normals=new List<Vector3>();var triangles=new List<int>[5];
            for(int i=0;i<5;i++)triangles[i]=new List<int>();
            System.Action<Vector3,Vector3,int,float> shape=(center,size,role,radius)=>
            {
                center.x+=centerX;
                if(!battery){RoundedGeometry.Box(vertices,normals,triangles[role],center,size,radius);return;}
                // Same breaker surfaces, with only the seated battery aperture cut out.
                float holeX=openingX>0?openingX:ApcBatteryRegion.SocketHeight/VisualScale.x;
                float holeY=openingY>0?openingY:ApcBatteryRegion.SocketHeight/VisualScale.y;
                BatteryAperture.Box(vertices,normals,triangles[role],center,size,radius,holeX,holeY,openingX>0?0:holeX*.1f,openingX>0?0:holeY*.1f);

            };
            shape(new Vector3(0,0,.029f),new Vector3(width,.075f,.056f),1,.0018f);
            shape(new Vector3(0,0,.059f),new Vector3(width,.052f,.008f),1,.0015f);
            shape(new Vector3(0,0,.0635f),new Vector3(width-.0046f,.045f,.001f),3,.0004f);
            if(battery)
            {
                // The slightly larger native cell extends just behind the former
                // rear plane. Recess only its rear cover; fuse rear walls stay put.
                float rear=openingX>0?.003f:-.0018f,depth=openingX>0?.002f:.0016f;
                // One continuous liner from the closed rear to the actual front.
                // The former three overlapping wall sets are deliberately absent.
                float holeX=openingX>0?openingX:ApcBatteryRegion.SocketHeight/VisualScale.x;
                float holeY=openingY>0?openingY:ApcBatteryRegion.SocketHeight/VisualScale.y;
                float rearFace=rear+depth*.5f;
                BatteryAperture.Walls(vertices,normals,triangles[3],new Vector3(centerX,0,(rearFace+.064f)*.5f),
                    new Vector3(width,.075f,.064f-rearFace),holeX,holeY,openingX>0?0:holeX*.1f,openingX>0?0:holeY*.1f);
                RoundedGeometry.Box(vertices,normals,triangles[3],new Vector3(centerX,0,rear),new Vector3(width,.075f,depth),.0007f);
            }
            foreach(float side in bottomOnly?new[]{-1f}:inputOnly?new[]{1f}:new[]{-1f,1f})
            {
                RoundedGeometry.Box(vertices,normals,triangles[4],new Vector3(centerX,side*.03f,.0577f),new Vector3(.009f,.009f,.0015f),.0005f);
                RoundedGeometry.Box(vertices,normals,triangles[3],new Vector3(centerX,side*.03f,.0586f),new Vector3(.006f,.001f,.0005f),.00015f);
            }
            foreach(float side in bottomOnly?new[]{-1f}:inputOnly?new[]{1f}:new[]{-1f,1f})
            {
                EndDisk(vertices,normals,triangles[4],new Vector3(centerX,side*(WireContactLayout.BreakerEntryY+.0001f),WireContactLayout.BreakerEntryZ),.0042f,side);
                EndDisk(vertices,normals,triangles[3],new Vector3(centerX,side*(WireContactLayout.BreakerEntryY+.0002f),WireContactLayout.BreakerEntryZ),.0032f,side);
            }
            // Two fixed spindle bearings straddle the flap, matching the APC's mounting.
            // Their inner edges clear the 12 mm plate while enclosing its axle ends.
            if(!battery&&!plain)foreach(float side in bottomOnly?new[]{-1f}:inputOnly?new[]{1f}:new[]{-1f,1f})
                RoundedGeometry.Box(vertices,normals,triangles[4],new Vector3(centerX+side*.0073f,0,.0667f),
                    new Vector3(.0022f,.0042f,.0048f),.0007f);
            var mesh=new Mesh{name="Switchboards.RoundedBreaker"};mesh.SetVertices(vertices);mesh.SetNormals(normals);mesh.subMeshCount=5;
            for(int i=0;i<5;i++)mesh.SetTriangles(triangles[i],i);
            CabinetGeometry.ApplyNativeUv(mesh);mesh.RecalculateBounds();return mesh;
        }private static void EndDisk(List<Vector3> vertices,List<Vector3> normals,List<int> triangles,Vector3 center,float worldRadius,float side)
        {
            for(int i=0;i<16;i++)
            {
                float a=i*Mathf.PI/8,b=(i+1)*Mathf.PI/8;
                var p=center+new Vector3(Mathf.Cos(a)*worldRadius/VisualScale.x,0,Mathf.Sin(a)*worldRadius/VisualScale.z);
                var q=center+new Vector3(Mathf.Cos(b)*worldRadius/VisualScale.x,0,Mathf.Sin(b)*worldRadius/VisualScale.z);
                int start=vertices.Count;vertices.AddRange(side>0?new[]{center,q,p}:new[]{center,p,q});normals.AddRange(new[]{Vector3.up*side,Vector3.up*side,Vector3.up*side});triangles.AddRange(new[]{start,start+1,start+2});
            }
        }}static class HousingAddressScrew{internal static Vector3 Center=new(SmartContactor.CenterX,-.013f,.0605f);internal static Mesh Build()
        {
            using(var reader=new BinaryReader(Assembly.GetExecutingAssembly().GetManifestResourceStream("ModularSwitchboards.HousingAddressScrew.meshbin")))
            {
                int count=reader.ReadInt32(),groups=reader.ReadInt32();var positions=new Vector3[count];var uv=new Vector2[count];
                for(int i=0;i<count;i++){positions[i]=new Vector3(reader.ReadSingle(),reader.ReadSingle(),reader.ReadSingle());uv[i]=new Vector2(reader.ReadSingle(),reader.ReadSingle());}
                var bounds=new Bounds(positions[0],Vector3.zero);foreach(var p in positions)bounds.Encapsulate(p);
                float fit=.016f/Mathf.Max(bounds.size.x,bounds.size.y);
                // Reference positions are already in housing space. Retain the
                // original six-sided face, recessed slot and UV coordinates.
                for(int i=0;i<count;i++)positions[i]=Center+new Vector3((positions[i].x-bounds.center.x)*fit/DinBreakerModel.VisualScale.x,
                    (positions[i].y-bounds.center.y)*fit/DinBreakerModel.VisualScale.y,(positions[i].z-bounds.min.z)*fit/DinBreakerModel.VisualScale.z);
                var mesh=new Mesh{name="DIN.Output.OriginalHousingSelector"};mesh.vertices=positions;mesh.uv=uv;mesh.subMeshCount=groups;
                for(int g=0;g<groups;g++){int n=reader.ReadInt32();var triangles=new int[n];for(int i=0;i<n;i++)triangles[i]=reader.ReadInt32();mesh.SetTriangles(triangles,g);}
                mesh.RecalculateNormals();mesh.RecalculateBounds();return mesh;
            }
        }internal static Bounds TargetBounds(Bounds head)
        {
            // Include the visible head and 1 mm around its edge; do not expose
            // the shaft buried behind the fascia as an interaction surface.
            float back=Mathf.Max(head.min.z,.0637f),front=head.max.z+.0005f/DinBreakerModel.VisualScale.z;
            return new Bounds(new Vector3(head.center.x,head.center.y,(back+front)*.5f),
                new Vector3(head.size.x+.002f/DinBreakerModel.VisualScale.x,head.size.y+.002f/DinBreakerModel.VisualScale.y,front-back));
        }}static class WireContactLayout{internal const float BreakerEntryY=.0375f,BreakerEntryZ=.029f;}}namespace ModularSwitchboards{static class SmartOutputModel{internal static Mesh Housing()
        {
            var vertices=new List<Vector3>();var normals=new List<Vector3>();var groups=new List<int>[5];
            for(int i=0;i<5;i++)groups[i]=new List<int>();
            Action<int,Vector3,Vector3,float> box=(role,center,size,radius)=>RoundedGeometry.Box(vertices,normals,groups[role],center,size,radius);
            // Dedicated single-position casing, with the existing bottom cable endpoint.
            box(1,new Vector3(0,0,.029f),new Vector3(.0176f,.075f,.056f),.0018f);
            box(1,new Vector3(0,0,.059f),new Vector3(.0176f,.052f,.008f),.0015f);
            box(4,new Vector3(0,-.03f,.0577f),new Vector3(.009f,.009f,.0015f),.0005f);
            box(3,new Vector3(0,-.03f,.0586f),new Vector3(.006f,.001f,.0005f),.00015f);
            box(4,new Vector3(0,-WireContactLayout.BreakerEntryY,WireContactLayout.BreakerEntryZ),new Vector3(.0037f,.0004f,.0064f),.0003f);
            // One shallow fascia, without raised rails or a separate bezel.
            box(3,new Vector3(0,0,.0632f),new Vector3(.0145f,.045f,.0004f),.00035f);
            // Smooth paintable top, matching the Core casing.
            var mesh=new Mesh{name="Smart.Output.PlcHousing"};mesh.SetVertices(vertices);mesh.SetNormals(normals);mesh.subMeshCount=5;
            for(int i=0;i<5;i++)mesh.SetTriangles(groups[i],i);
            CabinetGeometry.ApplyNativeUv(mesh);mesh.RecalculateBounds();return mesh;
        }}}