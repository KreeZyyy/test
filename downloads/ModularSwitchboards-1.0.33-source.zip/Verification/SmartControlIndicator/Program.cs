using System;using System.Linq;using ModularSwitchboards;
class Program
{
 static int n;static void Check(bool v,string m){n++;if(!v)throw new Exception(m);}
 static CabinetWireSaveData W(long a,int p,long b,int q)=>new(){From=new(a,p),To=new(b,q)};
 static void Main()
 {
  var wires=Array.Empty<CabinetWireSaveData>();long[] coils={10,11};
  SmartControlLight State(long output,bool bus,bool conducting)=>SmartControlIndicator.Evaluate(bus,SmartControlIndicator.Connected(output,wires,coils),conducting);
  Check(State(20,true,false)==SmartControlLight.Disconnected,"unwired OFF must be orange");
  Check(State(20,true,true)==SmartControlLight.Disconnected,"unwired ON must stay orange, not green");
  wires=new[]{W(20,1,10,2)};Check(State(20,true,false)==SmartControlLight.Open,"wired OFF must be red");Check(State(20,true,true)==SmartControlLight.Energized,"wired energized OUT must be green");
  Check(State(21,true,true)==SmartControlLight.Disconnected,"other output's wire makes this one green");
  Check(State(20,false,true)==SmartControlLight.Off&&State(20,false,false)==SmartControlLight.Off,"Core OFF must extinguish lamp even with stored On");
  coils=new long[]{11};Check(State(20,true,true)==SmartControlLight.Disconnected,"destroyed contactor leaves green lamp");
  coils=new long[]{10,11};wires=new[]{W(20,1,10,0)};Check(State(20,true,true)==SmartControlLight.Disconnected,"mains IN counted as A1 connection");
  wires=new[]{W(20,0,10,2)};Check(State(20,true,true)==SmartControlLight.Disconnected,"removed power IN counted as OUT");
  wires=new[]{W(20,1,30,2)};Check(State(20,true,true)==SmartControlLight.Disconnected,"non-contactor terminal counted as A1");
  wires=new[]{W(10,2,20,1)};Check(State(20,true,true)==SmartControlLight.Energized,"wire selection order changes connection indicator");
  wires=new[]{W(20,1,10,2),W(21,1,11,2)};Check(State(20,true,false)==SmartControlLight.Open&&State(21,true,true)==SmartControlLight.Energized,"independent outputs share indicator state");
  wires=wires.Skip(1).ToArray();Check(State(20,true,true)==SmartControlLight.Disconnected&&State(21,true,true)==SmartControlLight.Energized,"cutting one wire affects another output");
  Console.WriteLine(n+" control LED checks passed: unwired orange, wired OFF red, energized green, Core OFF dark, wrong/removed targets and independent channels.");
 }
}
