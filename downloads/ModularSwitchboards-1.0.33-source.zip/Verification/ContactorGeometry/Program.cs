using System;using System.Linq;using System.IO;using System.Text.Json;using UnityEngine;using ModularSwitchboards;
class Program
{
 static int checks;static void Check(bool v,string why){checks++;if(!v)throw new Exception(why);}
 static float Front(Mesh mesh,float x,float y)
 {
  float z=float.NegativeInfinity;var v=mesh.vertices;
  foreach(var t in mesh.T.Values)for(int i=0;i<t.Length;i+=3)
  {
   var a=v[t[i]];var b=v[t[i+1]];var c=v[t[i+2]];
   float d=(b.y-c.y)*(a.x-c.x)+(c.x-b.x)*(a.y-c.y);if(Math.Abs(d)<1e-12f)continue;
   float u=((b.y-c.y)*(x-c.x)+(c.x-b.x)*(y-c.y))/d;
   float w=((c.y-a.y)*(x-c.x)+(a.x-c.x)*(y-c.y))/d;float r=1-u-w;
   if(u>=0&&w>=0&&r>=0)z=Math.Max(z,u*a.z+w*b.z+r*c.z);
  }
  return z;
 }
 static void Main(string[] args)
 {
  var mesh=DinContactorModel.Build();Check(mesh.subMeshCount==5,"native material roles retained");
  Check(mesh.bounds.size.x<.018f&&mesh.bounds.size.y<=DinBreakerModel.Build(plain:true).bounds.size.y+.0001f,"one DIN footprint");
  // Sample the real cut geometry: neither the old white body nor fascia may
  // occlude the moving strip at z .06185 inside the visible opening.
  for(int x=-3;x<=3;x++)for(int y=-3;y<=3;y++)Check(Front(mesh,x*.001f,.002f+y*.001f)<.061f,"unobstructed mechanical window");
  foreach(float y in new[]{-.008f,.012f})Check(Front(mesh,0,y)>.063f,"opaque fascia masks unused flag");
  foreach(var t in mesh.T.Values)Check(t.All(i=>i>=0&&i<mesh.vertices.Length),"valid triangles");
  var data=new{vertices=mesh.vertices.Select(v=>new[]{v.x,v.y,v.z}),triangles=mesh.T.ToDictionary(p=>p.Key.ToString(),p=>p.Value)};
  File.WriteAllText(args[0],JsonSerializer.Serialize(data));Console.WriteLine(checks+" contactor geometry checks passed.");
 }
}
