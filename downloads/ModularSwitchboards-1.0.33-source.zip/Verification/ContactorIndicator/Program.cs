using System;using ModularSwitchboards;
class Program
{
 static int checks;static void Check(bool v,string why){checks++;if(!v)throw new Exception(why);}
 static void Main()
 {
  var m=new ContactorIndicatorMotion();
  Check(!m.Tick(false,true,1)&&m.Offset==.005f,"cursor stays OFF and silent");
  Check(!m.Tick(true,true,0)&&m.Offset==-.005f,"joining energized contact snaps silently");
  Check(!m.Tick(true,true,1),"steady ON silent");
  Check(m.Tick(true,false,.03f)&&m.Offset>-.005f&&m.Offset<.005f,"release changes once and moves strip");
  Check(!m.Tick(true,false,.1f)&&m.Offset==.005f,"release finishes without second sound");
  Check(m.Tick(true,true,.03f)&&m.Offset<.005f&&m.Offset>-.005f,"pickup moves opposite direction");
  Check(m.Tick(true,false,.005f),"reversal is a new transition");
  for(int i=0;i<100;i++)Check(!m.Tick(true,false,.016f),"no repeated clacks");
  Check(m.Offset==.005f,"no motion overshoot");
  Check(!m.Tick(false,false,.1f)&&!m.Tick(true,true,.01f),"reinstalled contact establishes silent baseline");
  Check(m.Tick(true,false,-1)&&m.Offset==-.005f,"negative delta does not reverse motion");
  Console.WriteLine(checks+" contactor indicator checks passed.");
 }
}
