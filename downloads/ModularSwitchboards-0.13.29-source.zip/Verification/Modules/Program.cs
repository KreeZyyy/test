using System;
using System.Linq;
using System.Collections.Generic;
using System.IO;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Electrical;
using Assets.Scripts;
using Assets.Scripts.Networking;
using ModularSwitchboards;
namespace LibConstruct{static class PlacementBoard{public static bool Loading;}public class PlacementBoardStructureSaveData{public int Row;}static class BoardStructureHooks{public static PlacementBoardStructureSaveData SerializeSave(DinBreaker m)=>new(){Row=m.Board.Row};public static void DeserializeSave(DinBreaker m,PlacementBoardStructureSaveData d){m.Board=new(){Row=d.Row};}public static void SerializeOnJoin(RocketBinaryWriter w,DinBreaker m)=>w.WriteInt32(m.Board?.Row??0);public static void DeserializeOnJoin(RocketBinaryReader r,DinBreaker m){m.Board=new(){Row=r.ReadInt32()};}}}
namespace Assets.Scripts {static class AudioEvent{public static void Create(Thing position,int hash){position.SoundCount++;position.LastSound=hash;}}static class GameManager{public static bool RunSimulation=true;}}
namespace Assets.Scripts.Objects{
 public class ThingSaveData{public bool OnOff;} public class StructureSaveData:ThingSaveData{}
 class Thing {public Thing ThingTransformPosition=>this;public int SoundCount,LastSound;public void PlayNetworkSound(int hash){SoundCount++;LastSound=hash;}public Slot ParentSlot;public class DelayedActionInstance{public bool Disabled;public string ActionMessage;public DelayedActionInstance Fail(string text){Disabled=true;return this;}public DelayedActionInstance Succeed()=>this;}public virtual DelayedActionInstance HandleSwitch(Interaction interaction,int slot,DelayedActionInstance result,bool doAction=true,bool force=false){if(doAction&&GameManager.RunSimulation){var module=(DinBreaker)this;OnServer.MoveToSlot(module.Slots[slot].Get(),interaction.SourceSlot);}return result.Succeed();}public virtual ThingSaveData SerializeSave()=>new StructureSaveData();protected virtual void InitialiseSaveData(ref ThingSaveData d){d.OnOff=((DinBreaker)this).OnOff;}public virtual void DeserializeSave(ThingSaveData d){((DinBreaker)this).OnOff=d.OnOff;}public virtual void SerializeOnJoin(RocketBinaryWriter w)=>w.WriteBoolean(((DinBreaker)this).OnOff);public virtual void DeserializeOnJoin(RocketBinaryReader r){((DinBreaker)this).OnOff=r.ReadBoolean();}public int PrefabHash;public static bool IsNetworkUpdateRequired(uint flag,ushort flags)=>(flag&flags)!=0;public virtual void BuildUpdate(RocketBinaryWriter w,ushort f){}public virtual void ProcessUpdate(RocketBinaryReader r,ushort f){}}
 class Structure:Thing{}
 class Stackable:Thing{public int Quantity=1,Removed,MaxQuantity=10;public bool CanStack(Stackable other)=>other!=null&&other.PrefabHash==PrefabHash;public void Merge(Stackable other){int n=Math.Min(other.Quantity,MaxQuantity-Quantity);other.RemoveQuantity(n);Quantity+=n;}public static bool FailSplit;public virtual void RemoveQuantity(int n){Removed+=n;Quantity-=n;if(Quantity==0&&ParentSlot!=null){ParentSlot.Item=null;ParentSlot=null;}}public int AddQuantity(int n){Quantity+=n;return n;}public Stackable SplitStack(int n,Slot slot){Quantity-=n;if(FailSplit)return null;var one=new MultiConstructor{PrefabHash=PrefabHash,Quantity=n};OnServer.MoveToSlot(one,slot);return one;}}
 class MultiConstructor:Stackable{public List<Structure> Constructables=new();}
 struct Interaction{public Slot SourceSlot;}
 static class OnServer{public static bool FailMove;public static void MoveToSlot(Thing item,Slot slot){if(FailMove)return;if(item.ParentSlot!=null)item.ParentSlot.Item=null;slot.Item=item;item.ParentSlot=slot;}public static void Destroy(Thing item){if(item.ParentSlot!=null)item.ParentSlot.Item=null;}}
 class Slot{public Thing Parent;public Thing Item;public Thing Get()=>Item;}
 struct CanEnterResult{public bool Valid;public static CanEnterResult Fail(string reason)=>new(){Valid=false};}
}
namespace Assets.Scripts.Objects.Electrical {static class CableRuptured{public const int CableSparkHash=73123;}class AreaPowerControl:Structure{}class CableAnalyser:Structure{}class CableFuse:Structure{public float PowerBreak;}}
namespace Assets.Scripts.Networking {
 class RocketBinaryWriter {readonly BinaryWriter w;public RocketBinaryWriter(Stream s){w=new(s);}public void WriteBoolean(bool b)=>w.Write(b);public void WriteInt32(int n)=>w.Write(n);}
 class RocketBinaryReader {readonly BinaryReader r;public RocketBinaryReader(Stream s){r=new(s);}public bool ReadBoolean()=>r.ReadBoolean();public int ReadInt32()=>r.ReadInt32();}
}
namespace ModularSwitchboards{static class DinBatteryLayout{public const int Slots=2;}
 static class SwitchboardsMod{public const string BreakerName="StructureDinBreaker1P";}
 class Board{public int Row;public object PrimaryHost;}
 class DinRail{public bool CanFitModules=true,Covered;public bool CanAccessModules=>CanFitModules||Covered;}
 partial class DinBreaker:Thing{public float RatedWatts;
  public bool IsFuseHolder,IsBatteryModule,IsAnalyserModule,OnOff,Tripped;public ushort NetworkUpdateFlags;const ushort ModuleUpdate=32768;
  public int[] AllowedFuseKits=Array.Empty<int>();public Board Board=new(){PrimaryHost=new DinRail()};public List<Slot> Slots=new();
  public bool Conducting=>IsFuseHolder?!Tripped&&Slots.Count==1&&Slots[0].Get() is MultiConstructor kit&&kit.Quantity==1&&AllowedFuseKits.Contains(kit.PrefabHash):OnOff;
 }
}
static class Program{
 static int count;static void Check(bool ok,string msg){count++;if(!ok)throw new Exception(msg);}
 static void Main(){
  string slotName="<N:EN:Cable Fuse>";var namedHolder=new DinBreaker{IsFuseHolder=true,RatedWatts=100000};Check(!DinModuleAccess.SlotName(new Slot{Parent=namedHolder},ref slotName)&&slotName=="Cable Fuse","Fuse slot localization still returns an error token");
  slotName="Vanilla";Check(DinModuleAccess.SlotName(new Slot(),ref slotName)&&slotName=="Vanilla","Non-mod slot name changed");

  var native=new float[]{1000,5000,50000,100000,500000}.Select(w=>new CableFuse{PowerBreak=w}).ToArray();var f4=native[0];var kit=new MultiConstructor{PrefabHash=17,Constructables=native.Cast<Structure>().ToList()};
  var specs=DinModuleCatalog.Discover(native.Cast<Thing>().Append(kit));Check(specs.Count(s=>s.Selectable)==10,"Variant count");Check(specs.Count(s=>s.Fuse)==5,"Fuse variants");Check(specs[0].Name==SwitchboardsMod.BreakerName,"Legacy prefab identity lost");Check(specs.Where(s=>s.Fuse).All(s=>s.FuseKits.SequenceEqual(new[]{17})),"Fuse kit match wrong");Check(specs.Select(s=>s.Name).Distinct().Count()==11,"Duplicate prefabs");Check(specs.Any(s=>!s.Selectable&&s.Watts==20000),"Legacy intermediate breaker missing");Check(specs.Where(s=>s.Selectable&&!s.Fuse).Select(s=>s.Watts).SequenceEqual(new float[]{1000,5000,50000,100000,500000}),"Requested breaker ratings differ");Check(new float[]{1000,5000,50000,100000,500000}.Select(DinModuleCatalog.Colour).SequenceEqual(new[]{"Green","Yellow","Orange","Red","Purple"}),"Requested colours differ");Check(DinModuleCatalog.Rating(4000)=="4 kW","Power label");
  bool rejected=false;try{DinModuleCatalog.Discover(new Thing[]{f4});}catch(InvalidOperationException){rejected=true;}Check(rejected,"Missing native fuse kit accepted");
  var breaker=new DinBreaker{OnOff=true};breaker.Trip();Check(!breaker.OnOff&&breaker.Tripped&&breaker.NetworkUpdateFlags==32768,"Breaker didn't trip with sync flag");Check(breaker.SoundCount==0,"Breaker plays fuse burn sound");breaker.OnOff=true;GameManager.RunSimulation=false;breaker.Trip();Check(breaker.OnOff,"Client mutation");GameManager.RunSimulation=true;
  var holder=new DinBreaker{IsFuseHolder=true,AllowedFuseKits=new[]{17}};holder.Slots.Add(new(){Parent=holder,Item=kit});var result=new CanEnterResult();Check(DinModuleAccess.CanEnter(kit,holder.Slots[0],ref result),"Valid fuse rejected");kit.Quantity=2;Check(!DinModuleAccess.CanEnter(kit,holder.Slots[0],ref result),"Whole stack admitted");kit.Quantity=1;((DinRail)holder.Board.PrimaryHost).CanFitModules=false;Check(!DinModuleAccess.CanEnter(kit,holder.Slots[0],ref result),"Closed cabinet admitted fuse");LibConstruct.PlacementBoard.Loading=true;Check(DinModuleAccess.CanEnter(kit,holder.Slots[0],ref result),"Saved fuse rejected during board restore");LibConstruct.PlacementBoard.Loading=false;((DinRail)holder.Board.PrimaryHost).CanFitModules=true;
  Check(!DinModuleAccess.CanEnter(new MultiConstructor{PrefabHash=99},holder.Slots[0],ref result),"Wrong kit accepted");holder.Trip();Check(kit.Removed==1&&!holder.Conducting&&holder.Tripped,"Fuse didn't consume one cartridge");holder.Trip();Check(kit.Removed==1,"Repeated trip consumed another cartridge");Check(holder.SoundCount==1&&holder.LastSound==CableRuptured.CableSparkHash,"Fuse sound absent or repeated");
  holder.Tripped=false;var replacement=new MultiConstructor{PrefabHash=17,Quantity=1};OnServer.MoveToSlot(replacement,holder.Slots[0]);GameManager.RunSimulation=false;holder.Trip();Check(holder.SoundCount==1&&holder.Conducting,"Client sounded fuse");GameManager.RunSimulation=true;holder.Trip();Check(holder.SoundCount==2&&!holder.Conducting,"Second blown cartridge missing sound");
  var coveredHost=(DinRail)holder.Board.PrimaryHost;coveredHost.CanFitModules=false;coveredHost.Covered=true;holder.Tripped=false;var coveredKit=new MultiConstructor{PrefabHash=17,Quantity=1};Check(DinModuleAccess.CanEnter(coveredKit,holder.Slots[0],ref result),"Cover blocked exposed fuse-slot access");coveredHost.Covered=false;coveredHost.CanFitModules=true;
  var target=new DinBreaker{IsFuseHolder=true,AllowedFuseKits=new[]{17}};target.Slots.Add(new(){Parent=target});var hand=new Slot();var stack=new MultiConstructor{PrefabHash=17,Quantity=9};OnServer.MoveToSlot(stack,hand);var interaction=new Interaction{SourceSlot=hand};
  target.HandleSwitch(interaction,0,new(),false);Check(stack.Quantity==9&&target.Slots[0].Get()==null,"Preview consumes cartridge");
  GameManager.RunSimulation=false;target.HandleSwitch(interaction,0,new(),true);Check(stack.Quantity==9&&target.Slots[0].Get()==null,"Client consumes cartridge");GameManager.RunSimulation=true;
  target.HandleSwitch(interaction,0,new());Check(stack.Quantity==8&&((MultiConstructor)target.Slots[0].Get()).Quantity==1,"Stack insert didn't transfer exactly one");
  target.HandleSwitch(interaction,0,new(),false);Check(stack.Quantity==8&&target.Conducting,"Removal preview mutated stack");
  GameManager.RunSimulation=false;target.HandleSwitch(interaction,0,new());Check(stack.Quantity==8&&target.Conducting,"Client removal mutated stack");GameManager.RunSimulation=true;
  stack.Quantity=10;var full=target.HandleSwitch(interaction,0,new());Check(full.Disabled&&stack.Quantity==10&&target.Conducting,"Full stack consumed fuse");stack.Quantity=8;
  stack.PrefabHash=99;var wrong=target.HandleSwitch(interaction,0,new());Check(wrong.Disabled&&stack.Quantity==8&&target.Conducting,"Wrong kit accepted removal");stack.PrefabHash=17;
  ((DinRail)target.Board.PrimaryHost).CanFitModules=false;var closed=target.HandleSwitch(interaction,0,new());Check(closed.Disabled&&stack.Quantity==8&&target.Conducting,"Closed cabinet removal mutated stack");((DinRail)target.Board.PrimaryHost).CanFitModules=true;
  target.HandleSwitch(interaction,0,new());Check(stack.Quantity==9&&target.Slots[0].Get()==null&&!target.Conducting&&hand.Get()==stack,"Removal didn't merge one into held stack");
  target.HandleSwitch(interaction,0,new());Check(stack.Quantity==8&&target.Conducting,"Reinsert after merge failed");
  stack.Quantity=9;target.HandleSwitch(interaction,0,new());Check(stack.Quantity==10&&target.Slots[0].Get()==null,"Last stack capacity not filled exactly");target.HandleSwitch(interaction,0,new());Check(stack.Quantity==9&&target.Conducting,"Reinsert from full stack failed");stack.Quantity=8;
  target.Trip();Check(target.Tripped&&target.Slots[0].Get()==null&&!target.Conducting&&stack.Quantity==8,"Burnt state missing or incorrect consumption");
  target.HandleSwitch(interaction,0,new(),false);Check(target.Tripped,"Preview removes burnt model");target.HandleSwitch(interaction,0,new());Check(!target.Tripped&&target.Slots[0].Get()==null&&stack.Quantity==8,"Burnt removal returned usable fuse");
  Stackable.FailSplit=true;target.HandleSwitch(interaction,0,new());Check(stack.Quantity==8&&target.Slots[0].Get()==null,"Failed split loses units");Stackable.FailSplit=false;
  OnServer.FailMove=true;target.HandleSwitch(interaction,0,new());Check(stack.Quantity==8&&target.Slots[0].Get()==null,"Failed insertion loses units");OnServer.FailMove=false;
  var single=new MultiConstructor{PrefabHash=17,Quantity=1};OnServer.MoveToSlot(single,hand);OnServer.FailMove=true;var failed=target.HandleSwitch(interaction,0,new());Check(failed.Disabled&&hand.Get()==single&&single.Quantity==1,"Failed single-item move loses unit");OnServer.FailMove=false;target.HandleSwitch(interaction,0,new());Check(target.Slots[0].Get()==single&&hand.Get()==null&&single.Quantity==1,"Single unit not moved intact");target.HandleSwitch(interaction,0,new());Check(hand.Get()==single&&target.Slots[0].Get()==null,"Healthy fuse not recovered");
  foreach(ushort flags in new ushort[]{0,64,32768,65535}){using var stream=new MemoryStream();breaker.OnOff=true;breaker.Tripped=false;breaker.BuildUpdate(new(stream),flags);stream.Position=0;var peer=new DinBreaker();peer.ProcessUpdate(new(stream),flags);Check(stream.Position==stream.Length,"Update framing");Check(peer.OnOff==((flags&32768)!=0),"Trip/reset state not synchronized");Check(peer.SoundCount==0,"State update replays burn sound");}
  breaker.OnOff=false;breaker.Tripped=true;breaker.Board.Row=60;var data=(DinBreakerSaveData)breaker.SerializeSave();var xml=new System.Xml.Serialization.XmlSerializer(typeof(DinBreakerSaveData));using var text=new StringWriter();xml.Serialize(text,data);var saved=(DinBreakerSaveData)xml.Deserialize(new StringReader(text.ToString()));var restored=new DinBreaker();restored.DeserializeSave(saved);Check(restored.Tripped&&!restored.OnOff&&restored.Board.Row==60,"Save/restore trip and board state");Check(restored.SoundCount==0,"Loading replays burn sound");
  using(var stream=new MemoryStream()){breaker.SerializeOnJoin(new(stream));stream.Position=0;restored=new();restored.DeserializeOnJoin(new(stream));Check(restored.Tripped&&!restored.OnOff&&restored.Board.Row==60&&stream.Position==stream.Length,"Join/restore trip and board framing");Check(restored.SoundCount==0,"Joining replays burn sound");}
  var withBattery=DinModuleCatalog.Discover(native.Cast<Thing>().Append(kit).Append(new AreaPowerControl()));var backup=withBattery.Single(s=>s.Battery);Check(backup.Width==2&&backup.Selectable&&!backup.Fuse&&withBattery.Count(s=>s.Selectable)==11,"Battery module catalog/width wrong");
  Console.WriteLine($"Production DIN module catalog, insertion policy, trip mutation and update serialization passed {count} checks.");
 }
}
