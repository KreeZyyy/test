using UnityEngine;namespace ModularSwitchboards{public sealed partial class CabinetWiring{        private int WireAt(Vector3 world,float radius=.012f)
        {
            var p=Point(Shell.InverseTransformPoint(world));float best=radius*radius;int found=-1;
            for(int i=0;i<wires.Count;i++){var path=Expand(wires[i].Points);for(int j=1;j<path.Length;j++){float distance=WireRouting.SegmentDistanceSquared(p,p,path[j-1],path[j]);if(distance<best){best=distance;found=i;}}}return found;
        }
}}