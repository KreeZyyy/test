using System;using System.Linq;using System.Collections.Generic;using System.IO;using ModularSwitchboards;
class RocketBinaryWriter{readonly BinaryWriter w;public RocketBinaryWriter(Stream s){w=new(s);}public void WriteInt32(int i)=>w.Write(i);public void WriteInt64(long i)=>w.Write(i);public void WriteSingle(float f)=>w.Write(f);}
class RocketBinaryReader{readonly BinaryReader r;public RocketBinaryReader(Stream s){r=new(s);}public int ReadInt32()=>r.ReadInt32();public long ReadInt64()=>r.ReadInt64();public float ReadSingle()=>r.ReadSingle();}
static class GameManager{public static bool RunSimulation=false;}
class SerdeHarness{const int CurrentRouteVersion=4;readonly List<CabinetWireSaveData> wires=new();readonly Dictionary<long,CabinetWireEnd> pending=new();readonly Dictionary<long,float> pendingUntil=new();string topology;int revision,routeRevision;bool rebuild,needsReroute;
        internal static float[] Flatten(IList<WirePoint> points){var result=new float[points.Count*3];for(int i=0;i<points.Count;i++){result[i*3]=points[i].X;result[i*3+1]=points[i].Y;result[i*3+2]=points[i].Z;}return result;}
        internal static WirePoint[] Expand(float[] values)
        {if(values==null||values.Length%3!=0)return new WirePoint[0];var result=new WirePoint[values.Length/3];for(int i=0;i<result.Length;i++)result[i]=new WirePoint(values[i*3],values[i*3+1],values[i*3+2]);return result;}
        internal CabinetWireSaveData[] Save()=>wires.ToArray();
        internal void Load(IEnumerable<CabinetWireSaveData> saved)
        {
            wires.Clear();pending.Clear();pendingUntil.Clear();
            if(saved!=null)foreach(var w in saved.Take(64))
                if(Valid(w)&&WireCircuit.CanConnect(w.From,w.To,wires,wires.SelectMany(x=>new[]{x.From.Owner,x.To.Owner}).Concat(new[]{w.From.Owner,w.To.Owner}).Where(id=>id!=0).Distinct(),out _,allowLegacyBypass:true))wires.Add(w);
            needsReroute=GameManager.RunSimulation&&wires.Any(w=>w.RouteVersion<CurrentRouteVersion);
            topology=null;revision++;routeRevision=-1;rebuild=true;
        }
        private static bool Valid(CabinetWireSaveData w)=>w!=null&&ValidEnd(w.From)&&ValidEnd(w.To)&&w.From.IsSource&&!w.To.IsSource&&w.Points!=null&&w.Points.Length>=6&&w.Points.Length<=1536&&w.Points.Length%3==0&&w.CableUnits==1&&w.RouteVersion>=0&&w.RouteVersion<=CurrentRouteVersion&&w.InputSlot>=0&&w.InputSlot<16&&
            Expand(w.Points).All(p=>!float.IsNaN(p.X)&&!float.IsInfinity(p.X)&&!float.IsNaN(p.Y)&&!float.IsInfinity(p.Y)&&!float.IsNaN(p.Z)&&!float.IsInfinity(p.Z)&&Math.Abs(p.X)<=.18f&&Math.Abs(p.Y)<=.24f&&p.Z>=0&&p.Z<=.15f);
        private static bool ValidEnd(CabinetWireEnd e)=>e!=null&&e.Owner>=0&&e.Contact>=0&&e.Contact<(e.Owner==0?3:2);
        internal void Write(RocketBinaryWriter writer)
        {
            writer.WriteInt32(-2);writer.WriteInt32(wires.Count);foreach(var w in wires){WriteEnd(writer,w.From);WriteEnd(writer,w.To);writer.WriteInt32(w.InputSlot);writer.WriteInt32(w.RouteVersion);writer.WriteInt32(w.ColorIndex);writer.WriteInt32(w.Points.Length);foreach(var p in w.Points)writer.WriteSingle(p);}
            writer.WriteInt32(pending.Count);foreach(var p in pending){writer.WriteInt64(p.Key);WriteEnd(writer,p.Value);}
        }
        internal void Read(RocketBinaryReader reader)
        {
            int header=reader.ReadInt32();bool colored=header==-2;int count=colored?reader.ReadInt32():header;if(count<0||count>64)throw new InvalidOperationException("Invalid cabinet wire count.");var loaded=new List<CabinetWireSaveData>();
            for(int i=0;i<count;i++){var w=new CabinetWireSaveData{From=ReadEnd(reader),To=ReadEnd(reader),InputSlot=reader.ReadInt32(),RouteVersion=reader.ReadInt32()};if(colored)w.ColorIndex=reader.ReadInt32();int n=reader.ReadInt32();if(n<6||n>1536||n%3!=0)throw new InvalidOperationException("Invalid cabinet wire path.");w.Points=new float[n];for(int j=0;j<n;j++)w.Points[j]=reader.ReadSingle();loaded.Add(w);}Load(loaded);
            count=reader.ReadInt32();if(count<0||count>128)throw new InvalidOperationException("Invalid cabinet wire selection count.");for(int i=0;i<count;i++){long actor=reader.ReadInt64();var end=ReadEnd(reader);if(ValidEnd(end))pending[actor]=end;}
        }
        private static void WriteEnd(RocketBinaryWriter writer,CabinetWireEnd end){writer.WriteInt64(end.Owner);writer.WriteInt32(end.Contact);}
        private static CabinetWireEnd ReadEnd(RocketBinaryReader reader)=>new CabinetWireEnd(reader.ReadInt64(),reader.ReadInt32());

 internal static void Run(){var h=new SerdeHarness();var a=new CabinetWireEnd(0,0);var b=new CabinetWireEnd(51,0);var wire=new CabinetWireSaveData{From=a,To=b,InputSlot=3,RouteVersion=2,ColorIndex=7,Points=new[]{0f,.217f,.0463f,.012f,.171f,.108f}};h.Load(new[]{wire});h.pending[123]=a;using var stream=new MemoryStream();h.Write(new(stream));stream.Position=0;var restored=new SerdeHarness();restored.Read(new(stream));if(restored.wires.Count!=1||restored.wires[0].ColorIndex!=7||restored.wires[0].InputSlot!=3||restored.wires[0].RouteVersion!=2||!restored.wires[0].To.Equals(b)||!restored.wires[0].Points.SequenceEqual(wire.Points)||!restored.pending[123].Equals(a))throw new Exception("Wire network roundtrip failed");
 var serializer=new System.Xml.Serialization.XmlSerializer(typeof(CabinetWireSaveData));var sw=new StringWriter();serializer.Serialize(sw,wire);var painted=(CabinetWireSaveData)serializer.Deserialize(new StringReader(sw.ToString()));if(painted.ColorIndex!=7)throw new Exception("Wire XML color lost");var oldXml=sw.ToString().Replace(" ColorIndex=\"7\"","");var oldWire=(CabinetWireSaveData)serializer.Deserialize(new StringReader(oldXml));if(oldWire.ColorIndex!=-1)throw new Exception("Old save no longer defaults red");
 using(var legacy=new MemoryStream()){var lw=new RocketBinaryWriter(legacy);lw.WriteInt32(1);WriteEnd(lw,wire.From);WriteEnd(lw,wire.To);lw.WriteInt32(wire.InputSlot);lw.WriteInt32(wire.RouteVersion);lw.WriteInt32(wire.Points.Length);foreach(float value in wire.Points)lw.WriteSingle(value);lw.WriteInt32(0);legacy.Position=0;var oldReader=new SerdeHarness();oldReader.Read(new(legacy));if(oldReader.wires.Count!=1||oldReader.wires[0].ColorIndex!=-1||!oldReader.wires[0].Points.SequenceEqual(wire.Points))throw new Exception("Legacy binary wire packet unreadable");}
 Console.WriteLine("Wire color: XML and versioned binary roundtrip, legacy XML defaults red, legacy binary reader preserves routes.");
 GameManager.RunSimulation=true;restored.Load(new[]{wire});if(!restored.needsReroute)throw new Exception("Version 2 migration not scheduled");var old=new CabinetWireSaveData{From=new(0,0),To=new(0,2),RouteVersion=0,Points=new[]{0f,.205f,.0463f,.1f,-.205f,.0463f}};restored.Load(new[]{old});if(restored.wires.Count!=1||!restored.needsReroute)throw new Exception("Legacy bypass or migration request lost");GameManager.RunSimulation=false;
 wire.Points[0]=float.NaN;restored.Load(new[]{wire});if(restored.wires.Count!=0)throw new Exception("Invalid path accepted");using var bad=new MemoryStream();new RocketBinaryWriter(bad).WriteInt32(65);bad.Position=0;bool rejected=false;try{restored.Read(new(bad));}catch(InvalidOperationException){rejected=true;}if(!rejected)throw new Exception("Invalid network count accepted");Console.WriteLine("Production wire save/network serialization passed: endpoints, exact path, fan slot, player selection and malformed data guards.");}
}
