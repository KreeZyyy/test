using System;using System.Collections.Generic;using System.Linq;using ModularSwitchboards;using Assets.Scripts.Objects;using Assets.Scripts.UI;
namespace Assets.Scripts{public interface ICreativeSpawnable{}}
namespace Assets.Scripts.Objects{public class Thing:Assets.Scripts.ICreativeSpawnable{public string PrefabName,DisplayName;public int PrefabHash;public bool HideInStationpedia;public object Thumbnail;}public static class Prefab{public static List<Thing> AllPrefabs=new();}}
namespace Assets.Scripts.UI{public class StationCategoryInsert{public string PageLink,NameOfThing;public int PrefabHash;public object InsertImage;}public class SPDADataHandler{public Dictionary<string,Dictionary<string,List<StationCategoryInsert>>> _listDictionary=new();public void AddNewListItem(string tab,string group,StationCategoryInsert entry){if(!_listDictionary.ContainsKey(tab))_listDictionary[tab]=new();if(!_listDictionary[tab].ContainsKey(group))_listDictionary[tab][group]=new();_listDictionary[tab][group].Add(entry);}}public class Stationpedia{public static SPDADataHandler DataHandler=new();}public class SlotInfo{public string SlotName,SlotType,SlotIndex;}public class StationpediaPage{public string PrefabName;public List<SlotInfo> SlotInserts=new();}}
namespace ModularSwitchboards{public static class SwitchboardsMod{public const string KitName="kit",CabinetName="cabinet",CoverKitName="coverkit",CoverName="cover",RailKitName="railkit",RailName="rail",BreakerKitName="modulekit";}public static class DinModuleCatalog{public class Spec{public bool Selectable=true,Analyser,Battery,Fuse;public string Title;}public static Dictionary<string,Spec> Specs=new(){["breaker"]=new(){Title="DIN Breaker 100 kW"},["fuse"]=new(){Fuse=true,Title="DIN Fuse Holder 500 kW"},["battery"]=new(){Battery=true},["analyser"]=new(){Analyser=true},["legacy"]=new(){Selectable=false}};}}
class Program{
 static int n;static void Check(bool ok,string m){n++;if(!ok)throw new Exception(m);}
 static string Query(string s)=>string.Join("",s.Split(' ').Select(t=>"(?=.*"+t+")"));
 static void Main(){
 var page=new StationpediaPage{SlotInserts=new(){new(){SlotIndex="0",SlotName="Cable Fuse",SlotType="Cable Fuse"}}};SwitchboardStationpedia.FormatSlots(new Thing{PrefabName="fuse"},ref page);Check(page.SlotInserts[0].SlotName+"Slot"=="Cable Fuse Slot"&&page.SlotInserts[0].SlotType=="Cable Fuse","F1 slot suffix has no separating space");

 Check(StationpediaCatalog.ExpandQuery("měřák")=="měřák,merak","Native ASCII sanitizer loses accented alias");Check(StationpediaCatalog.ExpandQuery("rozvaděč")=="rozvaděč,rozvadec","Accented cabinet alias not expanded");Check(StationpediaCatalog.ExpandQuery("unrelated") == "unrelated","Unrelated input changed");
 string expanded=StationpediaCatalog.ExpandQuery("měřák");string nativePattern=string.Join("|",expanded.Split(',').Select(q=>Query(System.Text.RegularExpressions.Regex.Replace(q,"[^a-zA-Z0-9-]+",""))));Check(StationpediaCatalog.Matches("analyser",nativePattern),"Actual native sanitizer still breaks Czech search");
 bool creative=false;Check(!SwitchboardStationpedia.CreativeSearch(new Thing{PrefabName="analyser"},"",nativePattern,ref creative)&&creative,"Creative menu does not search aliases");

 foreach(var pair in new[]{("cabinet","rozvaděč"),("kit","skříň"),("rail","DIN lišta"),("railkit","montážní lišta"),("cover","kryt"),("coverkit","inner cover"),("breaker","jistič"),("breaker","jističe 100 kW"),("fuse","pojistka"),("fuse","fuse holder 500 kW"),("battery","baterka"),("battery","akumulátor"),("analyser","elektroměr"),("analyser","analyzátor"),("analyser","analyser"),("analyser","cable analyzer"),("modulekit","moduly")})Check(StationpediaCatalog.Matches(pair.Item1,Query(pair.Item2)),"Missing alias "+pair);
 Check(!StationpediaCatalog.Matches("breaker",Query("500 kW")),"Wrong breaker rating matched");
 foreach(string key in new[]{"vanilla","legacy",null})Check(!StationpediaCatalog.Matches(key,".*"),"Unrelated/legacy page intercepted");
 foreach(string pattern in new[]{null,"","(",new string('a',1025)})Check(!StationpediaCatalog.Matches("cabinet",pattern),"Invalid query accepted");
 bool result=false;Check(SwitchboardStationpedia.Search(new(){PrefabName="vanilla"},"hash",Query("jistič"),ref result)&&!result,"Vanilla search overridden");Check(!SwitchboardStationpedia.Search(new(){PrefabName="breaker"},"hash",Query("jistič"),ref result)&&result,"Alias not forwarded to F1");
 var names=new[]{"kit","cabinet","coverkit","cover","railkit","rail","modulekit","breaker","fuse","battery","analyser"};
 foreach(var name in names)Prefab.AllPrefabs.Add(new(){PrefabName=name,DisplayName=name,PrefabHash=Prefab.AllPrefabs.Count,Thumbnail=new object()});
 Prefab.AllPrefabs.Add(new(){PrefabName="legacy",HideInStationpedia=true});Prefab.AllPrefabs.Add(new(){PrefabName="vanilla"});
 Stationpedia.DataHandler.AddNewListItem("Furniture","Lockers",new(){PageLink="Thingcabinet"});Stationpedia.DataHandler.AddNewListItem("Electronics","Vanilla",new(){PageLink="Thingvanilla"});
 for(int i=0;i<3;i++)SwitchboardStationpedia.PopulateLists();
 var entries=Stationpedia.DataHandler._listDictionary["Electronics"]["Modular Switchboards"];
 Check(entries.Count==names.Length&&entries.Select(e=>e.PageLink).Distinct().Count()==names.Length,"Missing/duplicated Electronics entries");
 Check(Stationpedia.DataHandler._listDictionary["Furniture"]["Lockers"].Count==0,"Cabinet stayed under furniture");Check(Stationpedia.DataHandler._listDictionary["Electronics"]["Vanilla"].Count==1,"Vanilla entries removed");
 foreach(var entry in entries)Check(entry.InsertImage!=null&&Prefab.AllPrefabs.Any(t=>entry.PageLink=="Thing"+t.PrefabName&&entry.PrefabHash==t.PrefabHash),"Icon/link/prefab mismatch");
 Console.WriteLine($"Production F1 catalog/search: {n} checks passed; aliases with accents, native multiword patterns/ratings, all categories and kit links, icons, repeated regeneration, vanilla isolation and legacy exclusion.");
 }
}
