using System.Collections.Generic;
using System.Linq;
using System.Xml.Serialization;
using Assets.Scripts;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Networking;
using Assets.Scripts.Objects;
using Assets.Scripts.Localization2;
using Assets.Scripts.UI;
using Assets.Scripts.Objects.Motherboards;
using LibConstruct;
using HarmonyLib;
using Rendering;
using UnityEngine;

namespace ModularSwitchboards
{
    public sealed class InnerCoverSaveData:StructureSaveData
    {
        [XmlElement] public PlacementBoardStructureSaveData Mount;
    }
    // A separate board keeps the cover's footprint independent of rails/modules.
    public sealed class CabinetCoverBoard:PlacementBoard
    {
        public override float GridSize=>DinLayout.ModulePitch;
        public override IPlacementBoardStructure EquivalentStructure(Structure structure)
            =>null;
    }
    public sealed class InnerCoverModule:Structure,IPlacementBoardStructure
    {
        public PlacementBoard Board{get;set;}
        public PlacementBoard.BoardCell[] BoardCells{get;set;}
        private Mesh ownedMesh;
        private string signature;
        internal SwitchboardCabinet Host=>Board?.PrimaryHost as SwitchboardCabinet;
        internal static bool CanPlace(PlacementBoard board,Grid3 position,int rotation)
            =>board is CabinetCoverBoard&&board.PrimaryHost is SwitchboardCabinet host&&host.CanFitRails&&
                position.x==0&&position.y==0&&position.z==0&&rotation==0&&board.Structures.Count==0;
        public override void Awake(){base.Awake();BoardStructureHooks.Awake(this);}
        public override Grid3 GetLocalGrid()=>Board==null?default(Grid3):Board.WorldToGrid(Transform.position);
        public override CanConstructInfo CanConstruct()=>CanConstructInfo.InvalidPlacement("Use Kit (Switchboard Cover) directly inside an open switchboard.");
        protected override CanConstructInfo CanDeconstruct()=>Host!=null&&Host.CanAccessModules?CanConstructInfo.ValidPlacement:
            CanConstructInfo.InvalidPlacement("Open the cabinet first.");
        public override DelayedActionInstance AttackWith(Attack attack,bool doAction=true)
        {
            if(Host==null||!Host.CanAccessModules)return new DelayedActionInstance{Duration=0}.Fail("Open the cabinet first.");
            return base.AttackWith(attack,doAction);
        }
        private void LateUpdate()
        {
            if(IsCursor||Host==null)return;
            var model=transform.Find("InnerCoverModel");if(model==null)return;
            var collider=model.GetComponent<MeshCollider>();
            collider.enabled=Host.IsOpen;
            Thing._colliderLookup[collider]=this;
            var modules=Host.Wiring.Breakers.Where(b=>!b.IsBeingDestroyed&&b.transform.Find("DinBreakerModel")!=null).OrderBy(b=>b.ReferenceId).ToArray();
            var centers=modules.Select(b=>transform.InverseTransformPoint(b.transform.Find("DinBreakerModel").TransformPoint(new Vector3(b.ContactOffsetX,0,0)))).ToArray();
            string next=Host.CoverProfile.Signature+";"+string.Join(";",modules.Select((b,i)=>b.ReferenceId+":"+b.ModuleWidth+":"+b.IsBatteryModule+":"+centers[i].ToString("F6")));
            if(next!=signature)
            {
                var fresh=CabinetInnerCover.Build(modules.Select((b,i)=>InnerCoverLayout.Window(centers[i].x,centers[i].y,b.ModuleWidth,b.IsBatteryModule)),Host.CoverProfile);
                model.GetComponent<MeshFilter>().sharedMesh=fresh;collider.sharedMesh=fresh;
                Bounds=fresh.bounds;
                var old=ownedMesh;ownedMesh=fresh;signature=next;if(old!=null)Destroy(old);
            }
            // Cover matches the cabinet finish without sharing mutable materials.
            var renderer=model.GetComponent<MeshRenderer>();
            var block=new MaterialPropertyBlock();
            renderer.GetPropertyBlock(block,0);
            block.SetFloat(Thing.DiffuseIndexPropertyID,Host.CustomColor==null?(int)ColorType.White:Host.CustomColor.Index);
            block.SetFloat(Thing.SmoothnessIndexPropertyID,Host.SmoothnessIndex);block.SetColor(Thing.EMISSION_COLOR,Host.EmissionColor);
            renderer.SetPropertyBlock(block,0);
        }
        public override void OnDeregistered(){base.OnDeregistered();if(Board!=null)BoardStructureHooks.OnDeregistered(this);}
        public override void OnDestroy(){if(ownedMesh!=null)Destroy(ownedMesh);base.OnDestroy();}
        public override ThingSaveData SerializeSave(){ThingSaveData data=new InnerCoverSaveData();InitialiseSaveData(ref data);return data;}
        protected override void InitialiseSaveData(ref ThingSaveData data)
        {base.InitialiseSaveData(ref data);if(data is InnerCoverSaveData save&&Board!=null)save.Mount=BoardStructureHooks.SerializeSave(this);}
        public override void DeserializeSave(ThingSaveData data)
        {base.DeserializeSave(data);if(data is InnerCoverSaveData save&&save.Mount!=null)BoardStructureHooks.DeserializeSave(this,save.Mount);}
        public override void SerializeOnJoin(RocketBinaryWriter writer){base.SerializeOnJoin(writer);BoardStructureHooks.SerializeOnJoin(writer,this);}
        public override void DeserializeOnJoin(RocketBinaryReader reader){base.DeserializeOnJoin(reader);BoardStructureHooks.DeserializeOnJoin(reader,this);}
        internal static void Install(InnerCoverModule cover,Transform storage)
        {
            foreach(var component in cover.GetComponentsInChildren<Renderer>(true))Object.DestroyImmediate(component);
            foreach(var component in cover.GetComponentsInChildren<MeshFilter>(true))Object.DestroyImmediate(component);
            foreach(var component in cover.GetComponentsInChildren<Collider>(true))Object.DestroyImmediate(component);
            foreach(var component in cover.GetComponentsInChildren<Animator>(true))Object.DestroyImmediate(component);
            cover.BaseAnimator=null;cover.Renderers=new List<ThingRenderer>();cover.Interactables=new List<Interactable>();cover.Slots=new List<Slot>();
            cover._staticColliders=new List<Collider>();cover._dynamicColliders=new List<Collider>();cover._selfColliders=new List<Collider>();
            cover.CustomNavMeshFilter=null;cover.structureRenderMode=StructureRenderMode.Standard;cover.ForceGridBounds.Clear();
            cover.BrokenBuildStates=new List<BrokenBuildState>();cover.StructureCollisionType=CollisionType.BlockCustom;
            cover.SelectionDisplay=SelectionHighlightMethod.Bounds;cover.UseCellPosition=false;
            cover.PaintableMaterial=null;cover.HasColorState=false;cover.MPBRenderers.Clear();
            var model=new GameObject("InnerCoverModel"){layer=cover.gameObject.layer};model.transform.SetParent(cover.transform,false);
            var mesh=CabinetInnerCover.Build(new WireRect[0]);model.AddComponent<MeshFilter>().sharedMesh=mesh;
            var renderer=model.AddComponent<MeshRenderer>();renderer.sharedMaterials=CabinetGeometry.Materials;CabinetMatteSurface.Apply(renderer);
            var collider=model.AddComponent<MeshCollider>();collider.sharedMesh=mesh;
            cover.Bounds=mesh.bounds;cover.SurfaceArea=.16f;cover.GridBounds=new GridBounds(cover);
            cover.Thumbnail=CabinetIcons.Get("InnerCover");cover.Thumbnails=new Sprite[0];
            var state=cover.BuildStates[0];state.Visualizer=renderer;state.StateMeshes=new List<Mesh>();state.RendererInstance=null;
            state.Colliders=new List<Collider>{collider};state.Interactables=new List<Interactable>();state.LinkedGameObjects=new List<GameObject>();
            state.RenderMode=BuildStateRenderMode.OnMyState;state.BlockAir=state.AlwaysBlockAir=state.BlockLight=state.BlockGravity=false;state.Thumbnail=cover.Thumbnail;
            AccessTools.Field(typeof(BuildState),"initialDrawData").SetValue(state,new DrawData{mesh=null,materials=new Material[0]});
            var blueprint=new GameObject("InnerCoverBlueprint"){layer=cover.gameObject.layer};blueprint.transform.SetParent(storage,false);
            var filter=blueprint.AddComponent<MeshFilter>();filter.sharedMesh=mesh;
            var br=blueprint.AddComponent<MeshRenderer>();br.sharedMaterial=CabinetGeometry.Materials[0];
            var wire=blueprint.AddComponent<Wireframe>();wire.BlueprintTransform=blueprint.transform;wire.BlueprintBounds=mesh.bounds;
            wire.BlueprintMeshFilter=filter;wire.BlueprintRenderer=br;blueprint.AddComponent<CabinetBlueprint>();
            cover.Blueprint=blueprint;cover.BlueprintOrientVector=Vector3.zero;
        }
    }
}
