using System;
using System.IO;
using System.Collections.Generic;
using Assets.Scripts.Objects;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class ModuleKitModel
    {
        internal const string RendererName="Switchboards.ModuleKitModel";
        private static Material material;
        internal const string RailRendererName="Switchboards.RailKitModel";
        internal const string CoverRendererName="Switchboards.CoverKitModel";
        private static Mesh Mesh(bool rails,bool cover)
        {
            using(var s=typeof(ModuleKitModel).Assembly.GetManifestResourceStream(cover?"ModularSwitchboards.CoverKit.Model.meshbin":rails?"ModularSwitchboards.RailKit.Model.meshbin":"ModularSwitchboards.ModuleKit.Model.meshbin"))
            using(var r=new BinaryReader(s??throw new InvalidDataException("Module kit model missing")))
            {
                if(new string(r.ReadChars(4))!="MKIT")throw new InvalidDataException("Invalid module kit model");
                int count=r.ReadInt32(),length=r.ReadInt32();
                if(count<1||count>250000||length<3||length%3!=0||length>750000)throw new InvalidDataException("Invalid module kit counts");
                var v=new List<Vector3>();var n=new List<Vector3>();var uv=new List<Vector2>();
                for(int i=0;i<count;i++){v.Add(new Vector3(r.ReadSingle(),r.ReadSingle(),r.ReadSingle()));n.Add(new Vector3(r.ReadSingle(),r.ReadSingle(),r.ReadSingle()));uv.Add(new Vector2(r.ReadSingle(),r.ReadSingle()));}
                var t=new int[length];for(int i=0;i<length;i++){t[i]=r.ReadInt32();if(t[i]<0||t[i]>=count)throw new InvalidDataException("Invalid module kit index");}
                if(s.Position!=s.Length)throw new InvalidDataException("Unexpected module kit trailing data");
                var mesh=new Mesh{name=cover?CoverRendererName:rails?RailRendererName:RendererName,indexFormat=count>65535?UnityEngine.Rendering.IndexFormat.UInt32:UnityEngine.Rendering.IndexFormat.UInt16};mesh.SetVertices(v);mesh.SetNormals(n);mesh.SetUVs(0,uv);mesh.SetTriangles(t,0);mesh.RecalculateBounds();return mesh;
            }
        }
        private static Material Surface()
        {
            if(material!=null)return material;
            var shader=Shader.Find("Standard");if(shader==null||!shader.isSupported)shader=Shader.Find("StandardInstanced");
            if(shader==null||!shader.isSupported)throw new InvalidOperationException("Module kit standard shader unavailable");
            using(var s=typeof(ModuleKitModel).Assembly.GetManifestResourceStream("ModularSwitchboards.ModuleKit.Surface.png"))
            using(var b=new MemoryStream())
            {
                if(s==null)throw new InvalidDataException("Module kit texture missing");s.CopyTo(b);
                var texture=new Texture2D(2,2,TextureFormat.RGBA32,true,false){name="Switchboards.ModuleKit.Surface"};
                if(!ImageConversion.LoadImage(texture,b.ToArray(),true)){UnityEngine.Object.Destroy(texture);throw new InvalidDataException("Invalid module kit texture");}
                texture.wrapMode=TextureWrapMode.Repeat;
                material=new Material(shader){name="Switchboards.ModuleKit.Material",mainTexture=texture,color=Color.white};
                material.SetFloat("_Glossiness",.5f);material.SetFloat("_Metallic",0f);return material;
            }
        }
        internal static void Install(MultiConstructor kit,Bounds original,bool rails=false,bool cover=false)
        {
            var mesh=Mesh(rails,cover);var surface=Surface();
            foreach(var lod in kit.GetComponentsInChildren<LODGroup>(true))UnityEngine.Object.DestroyImmediate(lod);
            foreach(var old in kit.GetComponentsInChildren<MeshRenderer>(true))UnityEngine.Object.DestroyImmediate(old);
            foreach(var old in kit.GetComponentsInChildren<MeshFilter>(true))UnityEngine.Object.DestroyImmediate(old);
            var model=new GameObject(cover?CoverRendererName:rails?RailRendererName:RendererName){layer=kit.gameObject.layer};model.transform.SetParent(kit.transform,false);
            // Both crates share the rail crate reference envelope; contents must not resize the shell.
            var crateReference=new Vector3(.5399921f,.4360011f,.5461208f);
            float fit=cover?1f:SwitchboardKitGeometry.Fit(original.size,rails?mesh.bounds.size:crateReference);
            model.transform.localScale=Vector3.one*fit;model.transform.localPosition=original.center-(cover||rails?mesh.bounds.center:new Vector3(0f,.2180002f,0f))*fit;
            model.AddComponent<MeshFilter>().sharedMesh=mesh;var renderer=model.AddComponent<MeshRenderer>();renderer.sharedMaterial=surface;
            kit.Renderers=new List<ThingRenderer>{new ThingRenderer(kit,renderer)};kit.PaintableMaterial=null;kit.HasColorState=false;
            kit.Thumbnail=CabinetIcons.Get(cover?"KitCover":rails?"KitRails":"KitModules");kit.Thumbnails=new Sprite[0];Refresh(renderer);
            SwitchboardKitModel.InstallBlueprint(kit,model.transform,mesh);
        }
        internal static void Refresh(MeshRenderer renderer)
        {
            renderer.SetPropertyBlock(null);for(int i=0;i<renderer.sharedMaterials.Length;i++)renderer.SetPropertyBlock(null,i);
            renderer.sharedMaterial=Surface();
        }
    }
}
