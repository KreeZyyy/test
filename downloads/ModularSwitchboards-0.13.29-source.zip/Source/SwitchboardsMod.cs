using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Assets.Scripts;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Electrical;
using Assets.Scripts.Objects.Structures;
using Assets.Scripts.Util;
using HarmonyLib;
using LaunchPadBooster;
using Reagents;
using UnityEngine;
using Object = UnityEngine.Object;

namespace ModularSwitchboards
{
    public sealed class SwitchboardsMod : MonoBehaviour
    {
        public const string Version = "0.13.29";
        // Keep the 0.1.0 identity so saved kits continue to work.
        public const string KitName = "ItemKitModularSwitchboard";
        public const string CabinetName = "StructureModularSwitchboard";
        public const string CoverKitName="ItemKitSwitchboardInnerCover";
        public const string CoverName="StructureSwitchboardInnerCover";
        public const string RailKitName = "ItemKitDinRail";
        public const string RailName = "StructureSwitchboardDinRail";
        public const string BreakerKitName = "ItemKitDinBreaker1P";
        public const string BreakerName = "StructureDinBreaker1P";
        public static readonly Mod Mod = new Mod("ModularSwitchboards", Version);
        private static bool loaded;
        private static GameObject storage;
        private static readonly MethodInfo CloneMethod = AccessTools.Method(typeof(object), "MemberwiseClone");

        public void OnLoaded(List<GameObject> prefabs)
        {
            if (loaded) return;
            LibConstructDependency.Validate();
            Mod.AddSaveDataType<SwitchboardCabinetSaveData>();
            Mod.AddSaveDataType<DinRailSaveData>();
            Mod.AddSaveDataType<InnerCoverSaveData>();
            Mod.AddSaveDataType<DinBreakerSaveData>();
            var harmony = new Harmony("modularswitchboards.prototype");
            harmony.Patch(AccessTools.Method(typeof(Assets.Scripts.UI.Stationpedia),"PopulateLists"),
                postfix:new HarmonyMethod(typeof(SwitchboardStationpedia),nameof(SwitchboardStationpedia.PopulateLists)));
            harmony.Patch(AccessTools.Method(typeof(Assets.Scripts.UI.Stationpedia),"AddBuildStates"),
                postfix:new HarmonyMethod(typeof(SwitchboardStationpedia),nameof(SwitchboardStationpedia.FormatBuildStates)));
            harmony.Patch(AccessTools.Method(typeof(Assets.Scripts.UI.Stationpedia),"AddSlotInfo"),
                postfix:new HarmonyMethod(typeof(SwitchboardStationpedia),nameof(SwitchboardStationpedia.FormatSlots)));
            harmony.Patch(AccessTools.Method(typeof(Assets.Scripts.UI.Stationpedia),"ForceSearch"),
                prefix:new HarmonyMethod(typeof(SwitchboardStationpedia),nameof(SwitchboardStationpedia.ExpandQuery)));
            harmony.Patch(AccessTools.Method(typeof(Assets.Scripts.UI.ImGuiUi.ImguiCreativeSpawnMenu),"ForceSearch"),
                prefix:new HarmonyMethod(typeof(SwitchboardStationpedia),nameof(SwitchboardStationpedia.ExpandQuery)));
            harmony.Patch(AccessTools.Method(typeof(Assets.Scripts.UI.ImGuiUi.ImguiCreativeSpawnMenu),"IsRegexMatch"),
                prefix:new HarmonyMethod(typeof(SwitchboardStationpedia),nameof(SwitchboardStationpedia.CreativeSearch)));
            harmony.Patch(AccessTools.Method(typeof(Assets.Scripts.UI.StationpediaPage),"IsRegexMatch"),
                prefix:new HarmonyMethod(typeof(SwitchboardStationpedia),nameof(SwitchboardStationpedia.Search)));
            harmony.Patch(AccessTools.Method(typeof(Assets.Scripts.Inventory.InventoryManager),"SetMultiConstructorItemPlacement"),
                prefix:new HarmonyMethod(typeof(SwitchboardCoverInput),nameof(SwitchboardCoverInput.PlacementPrefix)));
            harmony.Patch(AccessTools.Method(typeof(Assets.Scripts.Objects.Pipes.Device), "OnDestroy"),
                prefix: new HarmonyMethod(typeof(SwitchboardPrefabs), nameof(SwitchboardPrefabs.AllowNativeDestroy)));
            harmony.Patch(AccessTools.Method(typeof(Thing), "OnDestroy"),
                prefix: new HarmonyMethod(typeof(SwitchboardPrefabs), nameof(SwitchboardPrefabs.AllowNativeDestroy)));
            harmony.Patch(AccessTools.Method(typeof(LibConstruct.PlacementBoard), "CreateBoardStructure"),
                prefix: new HarmonyMethod(typeof(SwitchboardsMod), nameof(ValidateRailCreation)));
            harmony.Patch(AccessTools.Method(typeof(Prefab), "LoadAll"),
                prefix: new HarmonyMethod(typeof(SwitchboardsMod), nameof(PreparePrefabs)));
            harmony.Patch(AccessTools.Method(typeof(DynamicThingRecipeComparable), "GenerateRecipieList"),
                prefix: new HarmonyMethod(typeof(SwitchboardsMod), nameof(PrepareRecipe)));
            harmony.Patch(AccessTools.Method(typeof(Localization), "GetThingName"),
                prefix: new HarmonyMethod(typeof(SwitchboardsMod), nameof(LocalizeName)));
            harmony.Patch(AccessTools.Method(typeof(Localization), "GetThingDescription"),
                prefix: new HarmonyMethod(typeof(SwitchboardsMod), nameof(LocalizeDescription)));
            harmony.Patch(AccessTools.Method(typeof(Structure), "CachePrefabBounds"),
                prefix: new HarmonyMethod(typeof(SwitchboardsMod), nameof(CacheCabinetBounds)));
            harmony.Patch(AccessTools.Method(typeof(Thing), "CanCacheRenderer"),
                prefix: new HarmonyMethod(typeof(CabinetAppearance), nameof(CabinetAppearance.CanCacheRenderer)));
            harmony.Patch(AccessTools.Method(typeof(Thing), "Awake"),
                postfix: new HarmonyMethod(typeof(CabinetAppearance), nameof(CabinetAppearance.RegisterRenderers)));
            harmony.Patch(AccessTools.Method(typeof(Thing), "DeserializeSave"),
                prefix: new HarmonyMethod(typeof(SwitchboardsMod), nameof(MigrateBreakerName)));
            harmony.Patch(AccessTools.Method(typeof(Structure), "DeserializeSave"),
                prefix: new HarmonyMethod(typeof(SwitchboardsMod), nameof(MigrateCabinetSave)));
            harmony.Patch(AccessTools.Method(typeof(Thing), "SetCustomColor", new[] { typeof(int), typeof(bool) }),
                postfix: new HarmonyMethod(typeof(CabinetAppearance), nameof(CabinetAppearance.RefreshPaint)));
            harmony.Patch(AccessTools.Method(typeof(Thing), "SetCustomColor", new[] { typeof(bool) }),
                postfix: new HarmonyMethod(typeof(CabinetAppearance), nameof(CabinetAppearance.RefreshPaint)));
            harmony.Patch(AccessTools.Method(typeof(Structure), "UpdateAllMaterialPropertyBlocks"),
                postfix: new HarmonyMethod(typeof(CabinetAppearance), nameof(CabinetAppearance.RefreshPaint)));
            harmony.Patch(AccessTools.Method(typeof(Structure), "StructureDestroyed"),
                prefix:new HarmonyMethod(typeof(ModuleDismantle),nameof(ModuleDismantle.Refund)));
            harmony.Patch(AccessTools.Method(typeof(Structure), "AttackWith"),
                prefix: new HarmonyMethod(typeof(CabinetAppearance), nameof(CabinetAppearance.BeginBuildColor)),
                postfix: new HarmonyMethod(typeof(CabinetAppearance), nameof(CabinetAppearance.ApplyCompletedWhite)));
            harmony.Patch(AccessTools.Method(typeof(Assets.Scripts.Inventory.InventoryManager),"NormalMode"),
                prefix:new HarmonyMethod(typeof(CabinetWiringInput),nameof(CabinetWiringInput.ModePrefix)));
            harmony.Patch(AccessTools.Method(typeof(Assets.Scripts.Inventory.InventoryManager),"PlacementMode"),
                prefix:new HarmonyMethod(typeof(CabinetWiringInput),nameof(CabinetWiringInput.ModePrefix)));
            harmony.Patch(AccessTools.Method(typeof(Localization),"GetName",new[]{typeof(Slot)}),
                prefix:new HarmonyMethod(typeof(DinModuleAccess),nameof(DinModuleAccess.SlotName)));
            harmony.Patch(AccessTools.Method(typeof(Thing),"CanEnter",new[]{typeof(Slot)}),
                prefix:new HarmonyMethod(typeof(DinModuleAccess),nameof(DinModuleAccess.CanEnter)));
            harmony.Patch(AccessTools.Method(typeof(Assets.Scripts.Networks.PowerProvider),"ApplyPower"),
                postfix:new HarmonyMethod(typeof(SwitchboardsMod),nameof(ObserveIdleProvider)));
            Mod.Networking.Required = true;
            Prefab.OnPrefabsLoaded += VerifyRegistration;
            WorldManager.OnGameDataLoaded += VerifyRecipe;
            loaded = true;
            Debug.Log("[Modular Switchboards] " + Version + " loaded.");
        }

        private static T Source<T>(IEnumerable<Thing> sources, string name) where T : Thing
        {
            var result = sources.OfType<T>().FirstOrDefault(p => p.PrefabName == name || p.name == name);
            if (result == null) throw new InvalidOperationException("Missing source prefab: " + name);
            return result;
        }

        private static void Identify(Thing thing, string name, string title)
        {
            thing.name = name;
            thing.PrefabName = name;
            thing.PrefabHash = Animator.StringToHash(name);
            thing.CustomName = SwitchboardNames.Default(name)??title;
            thing.HideInStationpedia=false;
        }

        // Called before LoadAll reads SourcePrefabs. Build complete clones before publishing them.
        private static void PreparePrefabs()
        {
            if (WorldManager.Instance == null)
            {
                Debug.LogError("[Modular Switchboards] WorldManager unavailable.");
                return;
            }
            var sources = WorldManager.Instance.SourcePrefabs;
            if (sources.Any(p => p != null && p.PrefabName == KitName)) return;
            MultiConstructor kit = null;
            Structure cabinet = null;
            MultiConstructor railKit = null;
            DinRail rail = null;
            MultiConstructor coverKit=null;InnerCoverModule cover=null;
            MultiConstructor breakerKit = null;
            var moduleVariants=new List<DinBreaker>();
            DinBreaker breaker = null;
            try
            {
                LibConstructDependency.RequireInitialized();
                foreach (var name in new[] { KitName, CabinetName, RailKitName, RailName, CoverKitName, CoverName, BreakerKitName, BreakerName })
                    if (sources.Any(p => p != null && p.PrefabHash == Animator.StringToHash(name)))
                        throw new InvalidOperationException("Prefab identity collision: " + name);
                var kitSource = Source<MultiConstructor>(sources, "ItemKitLogicSwitch");
                var locker = sources.OfType<Locker>().FirstOrDefault(p => p.PrefabName == "StructureLockerSmall")
                    ?? sources.OfType<Locker>().FirstOrDefault(p => p.PrefabName == "StructureLocker")
                    ?? sources.OfType<Locker>().Where(p => p.GetType() == typeof(Locker) &&
                        p.BuildStates != null && p.BuildStates.Count > 0)
                        .OrderBy(p => p.PrefabName, StringComparer.Ordinal).FirstOrDefault();
                if (locker == null) throw new InvalidOperationException("No vanilla Locker prefab with build states found.");
                var wrench = Source<Item>(sources, "ItemWrench");
                var drill = Source<Item>(sources, "ItemDrill");
                var sheets = Source<Item>(sources, "ItemIronSheets");
                var plastic=sources.OfType<Assets.Scripts.Objects.Items.PlasticSheet>().FirstOrDefault();
                if(plastic==null)throw new InvalidOperationException("Native Plastic Sheet prefab unavailable.");

                if (storage == null)
                {
                    storage = new GameObject("ModularSwitchboards.SourcePrefabs");
                    storage.SetActive(false);
                    Object.DontDestroyOnLoad(storage);
                }
                kit = Object.Instantiate(kitSource, storage.transform);
                Identify(kit, KitName, "Kit (Switchboard)");
                kit.SetQuantity(1);
                // Do not transfer the temporary vanilla kit's legacy colour to the new shell.
                // Painting is supported on the assembled cabinet itself.
                kit.PaintableMaterial = null;
                kit.RecipeTier = MachineTier.TierOne;
                cabinet = SwitchboardPrefabs.ReplaceComponent<SwitchboardCabinet>(Object.Instantiate<Structure>(locker, storage.transform));
                Identify(cabinet, CabinetName, "Switchboard Small");
                if (cabinet.BuildStates == null || cabinet.BuildStates.Count == 0)
                    throw new InvalidOperationException("Locker has no build state visuals.");

                // Copy from the cloned prefab: its renderer/collider references already point to the clone.
                var visual = cabinet.BuildStates[cabinet.BuildStates.Count - 1];
                cabinet.BuildStates = new List<BuildState>
                {
                    MakeState(visual, kit, 1, null, 0, drill),
                    MakeState(visual, wrench, 0, plastic, 2, drill)
                };
                cabinet.UpgradePrefab = null;
                // This is a cabinet shell, not a general-purpose storage locker.
                cabinet.Slots = new List<Slot>();
                cabinet.Interactables = cabinet.Interactables.Where(i => i != null && i.Slot == null).ToList();
                CabinetModel.Install(cabinet);
                NativeRearBox.Install((SwitchboardCabinet)cabinet);
                OvenInputPanel.Install((SwitchboardCabinet)cabinet);
                OvenInputSupport.Install((SwitchboardCabinet)cabinet);
                ((SwitchboardCabinet)cabinet).PortBodyGrids=(Assets.Scripts.GridSystem.Grid3[])cabinet.GetLocalSmallGridBounds();
                ExternalCablePorts.InstallRearBody((SwitchboardCabinet)cabinet);
                ExternalCablePorts.TryInstall((SwitchboardCabinet)cabinet);
                CabinetPowerOutputs.TryInstall((SwitchboardCabinet)cabinet);
                CabinetNameplate.Install((SwitchboardCabinet)cabinet);
                CabinetTerminalBlocks.Install((SwitchboardCabinet)cabinet);
                var host = (SwitchboardCabinet)cabinet;
                var origin = new GameObject("DinRailBoard") { layer = cabinet.gameObject.layer };
                origin.transform.SetParent(cabinet.transform.Find("SwitchboardModel/CompletedShell"), false);
                origin.transform.localPosition = new Vector3(0f, 0f, .014f);
                host.RailOrigin = origin.transform;
                host.RailSurface = origin.AddComponent<BoxCollider>();
                host.RailSurface.size = new Vector3(DinLayout.CabinetInnerWidth, .43f, .002f);
                cabinet.BuildStates[1].Colliders.Add(host.RailSurface);
                // Retain stage 2 solely to read/remove existing 0.12.94 covers.
                var legacyCover=MakeState(cabinet.BuildStates[1],null,0,sheets,1,wrench);
                CabinetInnerCover.Install(host,legacyCover);
                var coverOrigin=new GameObject("InnerCoverBoard"){layer=cabinet.gameObject.layer};
                coverOrigin.transform.SetParent(cabinet.transform.Find("SwitchboardModel/CompletedShell"),false);
                host.CoverOrigin=coverOrigin.transform;host.CoverSurface=coverOrigin.AddComponent<BoxCollider>();
                host.CoverSurface.center=new Vector3(0,0,host.CoverProfile.Depth);
                host.CoverSurface.size=new Vector3(host.CoverProfile.Width,host.CoverProfile.Height,host.CoverProfile.Sheet*.5f);host.CoverSurface.enabled=false;
                cabinet.BuildStates[1].Colliders.Add(host.CoverSurface);legacyCover.Colliders.Add(host.CoverSurface);
                coverKit=Object.Instantiate(kitSource,storage.transform);
                Identify(coverKit,CoverKitName,"Kit (Switchboard Cover)");coverKit.SetQuantity(1);
                coverKit.PaintableMaterial=null;coverKit.RecipeTier=MachineTier.TierOne;
                cover=SwitchboardPrefabs.ReplaceComponent<InnerCoverModule>(Object.Instantiate<Structure>(locker,storage.transform));
                Identify(cover,CoverName,"Switchboard Cover");
                cover.BuildStates=new List<BuildState>{MakeState(cover.BuildStates.Last(),coverKit,1,null,0,wrench)};
                cover.UpgradePrefab=null;InnerCoverModule.Install(cover,storage.transform);
                coverKit.Constructables=new List<Structure>{cover};coverKit.LastSelectedIndex=0;
                coverKit.Thumbnail=kitSource.Thumbnail;coverKit.Thumbnails=kitSource.Thumbnails;

                railKit = Object.Instantiate(kitSource, storage.transform);
                Identify(railKit, RailKitName, "Kit (Switchboard Rails)");
                railKit.SetQuantity(1); railKit.PaintableMaterial = null; railKit.RecipeTier = MachineTier.TierOne;
                rail = SwitchboardPrefabs.ReplaceComponent<DinRail>(Object.Instantiate<Structure>(locker, storage.transform));
                Identify(rail, RailName, "Switchboard Rail");
                rail.BuildStates = new List<BuildState> { MakeState(rail.BuildStates.Last(), railKit, 1, null, 0, drill) };
                rail.UpgradePrefab = null;
                DinRailModel.Install(rail, storage.transform);
                railKit.Constructables = new List<Structure> { rail }; railKit.LastSelectedIndex = 0;
                railKit.Thumbnail=kitSource.Thumbnail;railKit.Thumbnails=kitSource.Thumbnails;
                breakerKit = Object.Instantiate(kitSource, storage.transform);
                Identify(breakerKit, BreakerKitName, "Kit (Switchboard Modules)");
                breakerKit.SetQuantity(1); breakerKit.PaintableMaterial = null; breakerKit.RecipeTier = MachineTier.TierOne;
                var moduleSpecs=DinModuleCatalog.Discover(sources);
                foreach(var spec in moduleSpecs)
                {
                    var module=SwitchboardPrefabs.ReplaceComponent<DinBreaker>(Object.Instantiate<Structure>(locker, storage.transform));
                    moduleVariants.Add(module);Identify(module,spec.Name,spec.Title);
                    module.RatedWatts=spec.Watts;module.IsFuseHolder=spec.Fuse;module.IsBatteryModule=spec.Battery;module.IsAnalyserModule=spec.Analyser;module.AllowedFuseKits=spec.FuseKits;
                    module.BuildStates=new List<BuildState>{MakeState(module.BuildStates.Last(),breakerKit,spec.Width,null,0,drill)};
                    module.HideInStationpedia=!spec.Selectable;module.UpgradePrefab=null;DinBreakerModel.Install(module,storage.transform);DinModuleAccess.Install(module);if(spec.Battery)DinBatteryModel.Install(module);if(spec.Analyser)DinAnalyserModel.Install(module);
                    if(spec.Name==BreakerName)breaker=module;
                }
                breakerKit.Constructables=moduleVariants.Where(m=>DinModuleCatalog.Specs[m.PrefabName].Selectable).Cast<Structure>().ToList();breakerKit.LastSelectedIndex=0;
                breakerKit.Thumbnail=kitSource.Thumbnail;breakerKit.Thumbnails=kitSource.Thumbnails;
                kit.Constructables = new List<Structure> { cabinet };
                kit.LastSelectedIndex = 0;
                kit.Thumbnail = kitSource.Thumbnail;
                kit.Thumbnails = kitSource.Thumbnails;
                SwitchboardKitModel.Install(kit,SwitchboardKitKind.Cabinet);
                SwitchboardKitModel.Install(railKit,SwitchboardKitKind.Rails);
                SwitchboardKitModel.Install(breakerKit,SwitchboardKitKind.Modules);
                SwitchboardKitModel.Install(coverKit,SwitchboardKitKind.Cover);
                sources.Add(kit);
                sources.Add(cabinet);
                sources.Add(coverKit);sources.Add(cover);
                sources.Add(railKit);
                sources.Add(rail);
                sources.Add(breakerKit);
                sources.AddRange(moduleVariants);
                Debug.Log("[Modular Switchboards] Prepared kit + 2-stage empty cabinet with Blender geometry; native base: " + locker.PrefabName);
            }
            catch (Exception ex)
            {
                // Never publish a partially configured prefab pair.
                if(coverKit!=null){sources.Remove(coverKit);Object.Destroy(coverKit.gameObject);}
                if(cover!=null){sources.Remove(cover);Object.Destroy(cover.gameObject);}
                if (kit != null) { sources.Remove(kit); Object.Destroy(kit.gameObject); }
                if (cabinet != null) { sources.Remove(cabinet); Object.Destroy(cabinet.gameObject); }
                if (railKit != null) { sources.Remove(railKit); Object.Destroy(railKit.gameObject); }
                if (rail != null) { sources.Remove(rail); Object.Destroy(rail.gameObject); }
                if (breakerKit != null) { sources.Remove(breakerKit); Object.Destroy(breakerKit.gameObject); }
                foreach(var module in moduleVariants){sources.Remove(module);if(module!=null)Object.Destroy(module.gameObject);}
                Debug.LogError("[Modular Switchboards] Prefab setup failed: " + ex);
            }
        }

        private static BuildState MakeState(BuildState visual, Item entry, int quantity,
            Item entry2, int quantity2, Item exit)
        {
            // Preserve private batched drawing data, but give each stage its own mutable collections/tool.
            var state = (BuildState)CloneMethod.Invoke(visual, null);
            state.StateMeshes = new List<Mesh>(visual.StateMeshes);
            state.Colliders = new List<Collider>(visual.Colliders);
            state.LinkedGameObjects = new List<GameObject>(visual.LinkedGameObjects);
            state.Interactables = visual.Interactables == null ? new List<Interactable>() :
                visual.Interactables.Where(i => i != null && i.Slot == null).ToList();
            state.RendererInstance = null;
            state.RenderMode = BuildStateRenderMode.OnMyState;
            state.CanManufacture = false;
            state.Tool = new ToolUse
            {
                ToolEntry = entry, EntryQuantity = quantity,
                ToolEntry2 = entry2, EntryQuantity2 = quantity2,
                ToolExit = exit, ExitQuantity = 0, EntryTime = 2f, ExitTime = 2f
            };
            return state;
        }

        // Runs after game/mod recipe files have loaded and before tier lists and recipe hashes are generated.
        private static void PrepareRecipe(DynamicThingRecipeComparable __instance)
        {
            if (!ReferenceEquals(__instance, ElectronicsPrinter.RecipeComparable)) return;
            var coverKit=Prefab.Find<MultiConstructor>(CoverKitName);
            var kit = Prefab.Find<MultiConstructor>(KitName);
            var railKit = Prefab.Find<MultiConstructor>(RailKitName);
            if (railKit != null && !__instance.AllRecipes.ContainsKey(railKit))
                __instance.AddRecipe(new WorldManager.RecipeData {
                    PrefabName = RailKitName, RecipeTier = MachineTier.TierOne, Output = 1f,
                    Recipe = new Recipe { Iron = 1, Time = 2f, Energy = 200f }
                }, null);
            if(coverKit!=null&&!__instance.AllRecipes.ContainsKey(coverKit))
                __instance.AddRecipe(new WorldManager.RecipeData{PrefabName=CoverKitName,RecipeTier=MachineTier.TierOne,Output=1f,
                    Recipe=new Recipe{Iron=1,Time=2f,Energy=200f}},null);
            var breakerKit = Prefab.Find<MultiConstructor>(BreakerKitName);
            if (breakerKit != null && !__instance.AllRecipes.ContainsKey(breakerKit))
                __instance.AddRecipe(new WorldManager.RecipeData {
                    PrefabName = BreakerKitName, RecipeTier = MachineTier.TierOne, Output = 1f,
                    Recipe = new Recipe { Iron = 2, Copper = 1, Time = 3f, Energy = 400f }
                }, null);
            if (kit == null || __instance.AllRecipes.ContainsKey(kit)) return;
            var recipe = new WorldManager.RecipeData
            {
                PrefabName = KitName, RecipeTier = MachineTier.TierOne, Output = 1f,
                Recipe = new Recipe { Iron = 10, Copper = 10, Electrum = 10, Time = 5f, Energy = 1000f }
            };
            if (__instance.AddRecipe(recipe, null))
                Debug.Log("[Modular Switchboards] Electronics Printer recipe added: 10 Copper + 10 Iron + 10 Electrum -> 1 kit.");
        }

        private static void ObserveIdleProvider(Assets.Scripts.Networks.PowerProvider __instance)
        {
            if(__instance.Device is SwitchboardCabinet cabinet&&__instance.EnergyUsed<=0)cabinet.Wiring.Power.ObserveIdle(__instance.CableNetwork);
        }

        private static bool LocalizeName(string __0, ref string __result)
        {
            if (__0 == KitName) __result = "Kit (Switchboard)";
            else if(__0==CoverKitName)__result="Kit (Switchboard Cover)";
            else if(__0==CoverName)__result="Switchboard Cover";
            else if (__0 == RailKitName) __result = "Kit (Switchboard Rails)";
            else if (__0 == RailName) __result = "Switchboard Rail";
            else if (__0 == BreakerKitName) __result = "Kit (Switchboard Modules)";
            else if (DinModuleCatalog.Specs.TryGetValue(__0,out var spec)) __result = spec.Title;
            else if (__0 == CabinetName) __result = "Switchboard Small";
            else return true;
            return false;
        }

        private static bool LocalizeDescription(string __0, ref string __result)
        {
            if(DinModuleCatalog.Specs.TryGetValue(__0,out var descriptionSpec)&&descriptionSpec.Analyser)
            {
                __result="Three-position DIN Cable Analyzer. Requires 3 x Kit (Switchboard Modules); dismantling returns 3 kits. Internal Cable Coil wiring from its OUT determines whether it reads the cable network at Output 1 or Output 2. Reports Actual, Required and Potential for the entire connected cable network, not an individual branch current. No separate data cable required. Remove the inner cover before fitting/removing the module. Electronics Printer kit: 2 Iron + 1 Copper.";
                return false;
            }
            if(descriptionSpec!=null&&descriptionSpec.Battery)
            {
                __result="Two-position DIN Battery Backup. Requires 2 x Kit (Switchboard Modules); dismantling returns 2 kits. Uses the original APC battery holder and a replaceable native battery. Top input, bottom output; connect the desired protected branch with internal Cable Coil wiring. Open the cabinet to swap the battery. Remove the inner cover before fitting/removing the module. Electronics Printer kit: 2 Iron + 1 Copper.";
                return false;
            }
            if (__0 == BreakerKitName || DinModuleCatalog.Specs.ContainsKey(__0))
            {
                __result="Switchboard Modules kits build the listed modules: 1 kit per breaker or fuse holder, 2 kits for Battery Backup, 3 kits for Cable Analyzer. Dismantling returns the corresponding number of kits. Choose type and kW rating with the native placement variant selector. " +
                    "Top input, bottom output; internal wiring uses Cable Coil. Breakers trip OFF above their rated actual throughput and can be reset. " +
                    "Fuse holders require one unit of the matching native Cable Fuse kit in their cartridge slot; insertion takes one unit from a held stack. A blown cartridge remains visible until removed. " +
                    "Open the cabinet to insert/remove a fuse. Remove wires and the fuse before dismantling. Electronics Printer: 2 Iron + 1 Copper.";
                return false;
            }
            if(__0==CoverKitName||__0==CoverName)
            {
                __result="Optional inner cover for an open completed switchboard. Electronics Printer: 1 Iron -> 1 kit. Hold the kit, aim inside the open switchboard and hold left click to fit it. No placement preview or rotation is required. Openings follow installed modules. Remove with a Wrench to recover the kit; wiring stays connected. Remove before editing wiring or dismantling modules.";
                return false;
            }
            if (__0 == RailKitName || __0 == RailName)
            {
                __result = "DIN mounting rail. Electronics Printer: 1 Iron -> 1 kit. Open a completed Switchboard Cabinet, " +
                    "right-click with the kit and aim at the upper or lower half of the mounting plate. One kit per row. " +
                    "Drill removes the rail and returns its kit. 8 module positions per row. Use the Switchboard Modules kit to select a rated breaker or fuse holder. Remove modules before dismantling the rail. Cable Coil connects module top inputs and bottom outputs inside the cabinet.";
                return false;
            }
            if (__0 != KitName && __0 != CabinetName) return true;
            __result = "Empty modular switchboard cabinet. Print one kit in an Electronics Printer " +
                "(10 Copper + 10 Iron + 10 Electrum). Place one kit on a wall to create the bare mounting frame, then use a Wrench " +
                "with 2 Plastic Sheets in the other hand to complete the shell and solid cover. " +
                "Fit the optional cover directly using Kit (Switchboard Cover); remove it with a Wrench to recover the kit. Remove the empty outer housing/frame with the Hand Drill. Paint changes the shell inside and out and both sides of the cover; the mounting plate stays dark grey with fixed fasteners; the DIN rails stay uniformly matte grey with slotted mounting holes. " +
                "Open the completed cabinet to install up to two DIN rails using their separate kits. Remove rails before dismantling the cabinet. Use the Switchboard Modules kit to install rated breakers and fuse holders. One external power input and two independent outputs are connected through your internal Cable Coil wiring. Wire Cutters remove wires.";
            return false;
        }

        private static void MigrateBreakerName(Thing __instance, ThingSaveData __0)
        {
            __0.CustomName=SwitchboardNames.Migrate(__instance.PrefabName,__0.CustomName);
            // Previously modules had fixed white casings, while the hidden native
            // color could come from the locker template. Migrate old saves once.
            if(__instance is DinBreaker && __0 is DinBreakerSaveData paintSave && paintSave.BodyPaintVersion<1)
                __0.CustomColorIndex=(int)Assets.Scripts.Objects.Motherboards.ColorType.White;

            if(__instance.PrefabName==CabinetName && (__0.CustomName=="Switchboard Cabinet" || __0.CustomName=="Switchboard")) __0.CustomName="Switchboard Small";
            if(DinModuleCatalog.Specs.TryGetValue(__instance.PrefabName,out var spec)&&(__0.CustomName=="DIN Breaker 1P"||__0.CustomName=="DIN Breaker")) __0.CustomName=spec.Title;
            // Migrate only the old default titles; preserve player custom names.
            if((__instance.PrefabName=="StructureDinBatteryBackup"&&__0.CustomName=="DIN Battery Backup (2 slots)")||
                (__instance.PrefabName=="StructureDinCableAnalyser"&&__0.CustomName=="DIN Cable Analyzer (3 slots)"))
                __0.CustomName=DinModuleCatalog.Specs[__instance.PrefabName].Title;
            if(__instance.PrefabName==BreakerKitName && (__0.CustomName=="Kit (DIN Breaker 1P)"||__0.CustomName=="Kit (DIN Breaker)")) __0.CustomName="Kit (Switchboard Modules)";
        }

        private static void MigrateCabinetSave(Structure __instance, ThingSaveData __0)
        {
            if (__instance.PrefabName == CabinetName && __0 is StructureSaveData save && save.CurrentBuildState > 1 && (save.CurrentBuildState>2 || !(__0 is SwitchboardCabinetSaveData coverSave) || coverSave.CoverSchema<1))
            {
                save.CurrentBuildState = 1;
                Debug.Log("[Modular Switchboards] Migrated legacy completed cabinet to simple completed shell.");
            }
        }

        // Validate on the authority before LibConstruct consumes the kit, including multiplayer messages.
        private static bool ValidateRailCreation(LibConstruct.CreateBoardStructureInstance __0)
        {
            if(__0.StructurePrefab is InnerCoverModule)
                return __0.Constructor!=null&&__0.Constructor.PrefabName==CoverKitName&&InnerCoverModule.CanPlace(__0.Board,__0.Position,__0.Rotation);
            if (__0.StructurePrefab is DinBreaker module)
                return __0.Constructor != null && __0.Constructor.PrefabName == BreakerKitName &&
                    DinBreaker.CanPlace(__0.Board, __0.Position, __0.Rotation,module.ModuleWidth);
            if (!(__0.StructurePrefab is DinRail)) return true;
            return __0.Constructor != null && __0.Constructor.PrefabName == RailKitName &&
                DinRail.CanPlace(__0.Board, __0.Position, __0.Rotation);
        }

        private static bool CacheCabinetBounds(Structure __instance)
        {
            if (__instance.PrefabName != CabinetName) return true;
            CabinetModel.SetBounds(__instance);
            return false;
        }

        // Register clones source prefabs. Cross-prefab references can still point to the source;
        // compare stable identity instead of Unity object identity.
        private static bool SamePrefab(Structure candidate, Structure registered)
        {
            return candidate != null && registered != null &&
                candidate.PrefabHash == registered.PrefabHash && candidate.PrefabName == registered.PrefabName;
        }

        private static void VerifyRegistration()
        {
            CableAnalyserDiagnostics.Capture();
            ConsoleKitDiagnostics.Capture();
            var coverKit=Prefab.Find<MultiConstructor>(CoverKitName);var cover=Prefab.Find<InnerCoverModule>(CoverName);
            if(coverKit==null||cover==null||coverKit.Constructables.Count!=1||!SamePrefab(coverKit.Constructables[0],cover)||cover.BuildStates.Count!=1)
                Debug.LogError("[Modular Switchboards] Inner cover kit registration verification FAILED.");
            var kit = Prefab.Find<MultiConstructor>(KitName);
            var cabinet = Prefab.Find<Structure>(CabinetName);
            if(cabinet==null||!(cabinet.BuildStates[1].Tool.ToolEntry2 is Assets.Scripts.Objects.Items.PlasticSheet)||cabinet.BuildStates[1].Tool.EntryQuantity2!=2)
                Debug.LogError("[Modular Switchboards] Cabinet shell material verification FAILED: expected 2 Plastic Sheets.");
            var railKit = Prefab.Find<MultiConstructor>(RailKitName);
            var rail = Prefab.Find<DinRail>(RailName);
            var breakerKit = Prefab.Find<MultiConstructor>(BreakerKitName);
            var breaker = Prefab.Find<DinBreaker>(BreakerName);
            if (breakerKit == null || breaker == null || breakerKit.Constructables.Count != DinModuleCatalog.Specs.Values.Count(s=>s.Selectable) || !breakerKit.Constructables.Any(p=>SamePrefab(p,breaker)))
                Debug.LogError("[Modular Switchboards] Breaker registration verification FAILED.");
            else Debug.Log("[Modular Switchboards] DIN Modules kit registered: "+breakerKit.Constructables.Count+" type/rating variants.");
            foreach(var spec in DinModuleCatalog.Specs.Values)
            {
                var module=Prefab.Find<DinBreaker>(spec.Name);
                if(module==null||module.RatedWatts!=spec.Watts||module.IsFuseHolder!=spec.Fuse||module.IsBatteryModule!=spec.Battery||module.IsAnalyserModule!=spec.Analyser||module.ModuleWidth!=spec.Width||module.BuildStates.Count!=1||module.BuildStates[0].Tool.EntryQuantity!=spec.Width||
                   (spec.Fuse&&(module.Slots.Count!=1||!module.AllowedFuseKits.SequenceEqual(spec.FuseKits))))
                    Debug.LogError("[Modular Switchboards] Module registration verification FAILED: "+spec.Name);
            }
            if (!(cabinet is SwitchboardCabinet) || railKit == null || rail == null ||
                railKit.Constructables.Count != 1 || !SamePrefab(railKit.Constructables[0], rail) || rail.BuildStates.Count != 1)
                Debug.LogError("[Modular Switchboards] DIN rail registration verification FAILED.");
            else Debug.Log("[Modular Switchboards] DIN rail kit + structure registered; two rows, 8 positions per row.");
            if(cabinet is SwitchboardCabinet host && host.OpenEnds!=null && host.OpenEnds.Count==3 &&
                host.InputConnection!=null && host.Output1Connection!=null && host.Output2Connection!=null &&
                host.OpenEnds.All(p=>p.Transform!=null && p.Collider!=null && p.Parent==host) && host.PortBodyGrids!=null &&
                host.OpenEnds.Select(p=>p.ConnectionRole).Distinct().Count()==3 &&
                host.OpenEnds.Select(p=>host.transform.InverseTransformPoint(p.Transform.position).ToGrid(SmallGrid.SmallGridSize,SmallGrid.SmallGridOffset)).Distinct().Count()==3)
                Debug.Log("[Modular Switchboards] Power registration verified: Input, left Output 1 and right Output 2; separate native cable cells, no internal bridge.");
            else if(cabinet is SwitchboardCabinet inputOnly && inputOnly.OpenEnds?.Count==1 && inputOnly.InputConnection!=null &&
                inputOnly.transform.Find(CabinetPowerOutputs.RootName)==null)
                Debug.LogWarning("[Modular Switchboards] Input remains available, but lower outputs were not installed; see earlier output setup error.");
            else Debug.LogError("[Modular Switchboards] External power port registration verification FAILED.");
            var terminals=cabinet==null?new CabinetTerminalBlock[0]:cabinet.GetComponentsInChildren<CabinetTerminalBlock>(true);
            if(terminals.Length==3 && terminals.Select(t=>t.TerminalId).Distinct().Count()==3 &&
                terminals.All(t=>t.Owner==cabinet && t.FrontContacts?.Length==1 && t.RearContacts?.Length==1 &&
                    t.TerminalCollider!=null && t.ExternalConnection!=null &&
                    t.ExternalRole==(t.TerminalId==CabinetTerminalId.Input?ConnectionRole.Input:t.TerminalId==CabinetTerminalId.Output1?ConnectionRole.Output:ConnectionRole.Output2)) &&
                terminals.Select(t=>t.ExternalConnection).Distinct().Count()==3)
                Debug.Log("[Modular Switchboards] Terminal blocks verified: Input, Output 1, Output 2; independent single front contacts.");
            else Debug.LogError("[Modular Switchboards] Terminal block registration verification FAILED.");
            if (kit == null || cabinet == null || cabinet.BuildStates.Count != 3 ||
                kit.Constructables.Count != 1 || kit.Constructables[0].PrefabHash != cabinet.PrefabHash)
                Debug.LogError("[Modular Switchboards] Registration verification FAILED.");
            else
                Debug.Log("[Modular Switchboards] Registration verified: kit + cabinet, 3 build states (frame/shell/inner cover).");
        }

        private static void VerifyRecipe()
        {
            var coverKit=Prefab.Find<MultiConstructor>(CoverKitName);
            var kit = Prefab.Find<MultiConstructor>(KitName);
            var railKit = Prefab.Find<MultiConstructor>(RailKitName);
            if(coverKit==null||!ElectronicsPrinter.RecipeComparable.AllRecipes.ContainsKey(coverKit)||!ElectronicsPrinter.RecipeComparable.DynamicThings.Contains(coverKit))
                Debug.LogError("[Modular Switchboards] Inner cover recipe verification FAILED.");
            if (railKit == null || !ElectronicsPrinter.RecipeComparable.AllRecipes.ContainsKey(railKit) ||
                !ElectronicsPrinter.RecipeComparable.DynamicThings.Contains(railKit))
                Debug.LogError("[Modular Switchboards] DIN rail Electronics Printer recipe verification FAILED.");
            else Debug.Log("[Modular Switchboards] DIN rail recipe verified: Electronics Printer, 1 Iron -> 1 kit.");
            if (kit == null || !ElectronicsPrinter.RecipeComparable.AllRecipes.ContainsKey(kit) ||
                !ElectronicsPrinter.RecipeComparable.DynamicThings.Contains(kit))
                Debug.LogError("[Modular Switchboards] Electronics Printer recipe verification FAILED.");
            else Debug.Log("[Modular Switchboards] Electronics Printer recipe verified.");
            var breakerKit = Prefab.Find<MultiConstructor>(BreakerKitName);
            if (breakerKit == null || !ElectronicsPrinter.RecipeComparable.AllRecipes.ContainsKey(breakerKit) ||
                !ElectronicsPrinter.RecipeComparable.DynamicThings.Contains(breakerKit))
                Debug.LogError("[Modular Switchboards] Breaker Electronics Printer recipe verification FAILED.");
            else Debug.Log("[Modular Switchboards] Breaker recipe verified: 2 Iron + 1 Copper -> 1 kit.");
        }
    }
}
