namespace ModularSwitchboards
{
    internal static class SwitchboardNames
    {
        internal static string Default(string prefab)
        {
            if(prefab==SwitchboardsMod.CoverKitName)return "Kit (Switchboard Cover)";
            if(prefab==SwitchboardsMod.RailKitName)return "Kit (Switchboard Rails)";
            if(prefab==SwitchboardsMod.BreakerKitName)return "Kit (Switchboard Modules)";
            if(prefab==SwitchboardsMod.CoverName)return "Switchboard Cover";
            if(prefab==SwitchboardsMod.RailName)return "Switchboard Rail";
            return null;
        }
        internal static string Migrate(string prefab,string saved)
        {
            bool old=(prefab==SwitchboardsMod.CoverKitName&&saved=="Kit (Inner Cover)")||
                (prefab==SwitchboardsMod.RailKitName&&saved=="Kit (DIN Rail)")||
                (prefab==SwitchboardsMod.BreakerKitName&&(saved=="Kit (DIN Modules)"||saved=="Kit (DIN Breaker)"||saved=="Kit (DIN Breaker 1P)"))||
                (prefab==SwitchboardsMod.CoverName&&saved=="Switchboard Inner Cover")||
                (prefab==SwitchboardsMod.RailName&&saved=="DIN Rail");
            return old?Default(prefab):saved;
        }
    }
}
