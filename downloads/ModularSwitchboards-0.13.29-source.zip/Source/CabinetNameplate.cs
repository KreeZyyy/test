using System;
using System.Globalization;
using System.Linq;
using UnityEngine;

namespace ModularSwitchboards
{
    internal static class NameplateText
    {
        internal static string Format(string name)
        {
            if(string.IsNullOrWhiteSpace(name) || name=="Switchboard Cabinet" || name=="Switchboard") return "Switchboard Small";
            name=name.Replace('\r',' ').Replace('\n',' ').Trim();
            var info=new StringInfo(name);
            return info.LengthInTextElements>28?info.SubstringByTextElements(0,27)+"…":name;
        }
    }

    public sealed class CabinetNameplate : MonoBehaviour
    {
        public SwitchboardCabinet Owner;
        public GameObject Plate;
        public TextMesh Text;
        private string previous;

        private void LateUpdate()
        {
            if(Owner==null||Plate==null||Text==null)return;
            bool visible=!Owner.IsCursor && Owner.CurrentBuildStateIndex>=1;
            if(Plate.activeSelf!=visible) Plate.SetActive(visible);
            // Native font shaders are two-sided and can show through an opaque door.
            // Cull only the text from the back; the physical plate stays on the outside.
            var camera=Camera.main;
            Text.GetComponent<MeshRenderer>().enabled=visible && (camera==null ||
                Vector3.Dot(Plate.transform.forward,camera.transform.position-Plate.transform.position)>0f);
            if(!visible)return;
            var name=NameplateText.Format(Owner.CustomName);
            if(previous!=name){Text.text=name;previous=name;}
            var bounds=Text.GetComponent<MeshRenderer>().localBounds.size;
            float scale=Mathf.Min(1f,Mathf.Min(.119f/Mathf.Max(.0001f,bounds.x),.023f/Mathf.Max(.0001f,bounds.y)));
            Text.transform.localScale=Vector3.one*scale;
        }

        internal static void Install(SwitchboardCabinet cabinet)
        {
            Font font=null;
            foreach(var name in new[]{"LegacyRuntime.ttf","Arial.ttf"})
            {
                try {font=Resources.GetBuiltinResource<Font>(name);}catch(Exception){}
                if(font!=null)break;
            }
            if(font==null)font=Resources.FindObjectsOfTypeAll<Font>().FirstOrDefault();
            if(font==null){Debug.LogWarning("[Modular Switchboards] Native nameplate font unavailable; cabinet remains usable.");return;}
            var hinge=cabinet.transform.Find("SwitchboardModel/CompletedShell/DoorHinge");
            var root=new GameObject("CabinetNameplate"){layer=cabinet.gameObject.layer};root.transform.SetParent(hinge,false);
            // Local negative cabinet X is the viewer's right on the closed door.
            root.transform.localPosition=new Vector3(.074f,.222f,.012f);
            Panel(root.transform,"CabinetLabelBorder",new Vector3(.132f,.04f,.001f),3,0);
            Panel(root.transform,"CabinetLabelPlate",new Vector3(.128f,.036f,.001f),1,.0006f);
            var textObject=new GameObject("CabinetLabelText"){layer=cabinet.gameObject.layer};textObject.transform.SetParent(root.transform,false);
            textObject.transform.localPosition=new Vector3(0,0,.0013f);
            textObject.transform.localRotation=Quaternion.Euler(0,180f,0);
            var text=textObject.AddComponent<TextMesh>();text.font=font;text.fontSize=64;text.characterSize=.012f;
            text.anchor=TextAnchor.MiddleCenter;text.alignment=TextAlignment.Center;text.richText=false;text.color=Color.black;
            text.text=NameplateText.Format(cabinet.CustomName);
            textObject.GetComponent<MeshRenderer>().sharedMaterial=font.material;
            var view=cabinet.gameObject.AddComponent<CabinetNameplate>();view.Owner=cabinet;view.Plate=root;view.Text=text;
        }
        private static void Panel(Transform parent,string name,Vector3 size,int role,float z)
        {
            var mesh=DinBreakerModel.ControlMesh(name,Vector3.zero,size);
            var triangles=mesh.GetTriangles(0);mesh.SetTriangles(new int[0],0);mesh.SetTriangles(triangles,role);
            var go=new GameObject(name){layer=parent.gameObject.layer};go.transform.SetParent(parent,false);
            go.transform.localPosition=new Vector3(0,0,z);go.AddComponent<MeshFilter>().sharedMesh=mesh;
            go.AddComponent<MeshRenderer>().sharedMaterials=CabinetGeometry.Materials;
        }
    }
}
