"""Check grounded contact chains on baked visible geometry, not only collision hulls."""
import json,sys,math
from pathlib import Path
from mathutils import Vector
from mathutils.bvhtree import BVHTree
args=sys.argv[sys.argv.index('--')+1:];source=Path(args[0]);out=Path(args[1]);data=json.loads(source.read_text());parts=data['parts'];tol=.005
shell=json.loads((source.parent/'source.json').read_text())['shell'];st=shell['triangles']['0'];crate_tree=BVHTree.FromPolygons(shell['vertices'],[st[i:i+3]for i in range(0,len(st),3)],all_triangles=True)
meshes=[];trees=[];samples=[];boxes=[]
for part in parts:
 d=part['mesh'];v=[Vector(p)for p in d['vertices']];tri=[tuple(t[i:i+3])for t in d['triangles'].values()for i in range(0,len(t),3)]
 assert min(p.y for p in v)>=.070,(part['name'],'fell below crate')
 assert max(max(abs(p.x),abs(p.z))for p in v)<.335,(part['name'],'left crate')
 # Collision walls have a half-mm margin; allow a small numeric tolerance.
 if data['kind']!='ModuleKit':assert all(abs(p.x)<.214 and abs(p.z)<.214 and abs(p.x)+abs(p.z)<.385 for p in v if p.y<.366),(part['name'],'wall clipping')
 else:assert not BVHTree.FromPolygons(v,tri,all_triangles=True).overlap(crate_tree),(part['name'],'crate triangle intersection')
 trees.append(BVHTree.FromPolygons(v,tri,all_triangles=True));meshes.append((v,tri));boxes.append([(min(p[k]for p in v),max(p[k]for p in v))for k in range(3)])
 pts={tuple(p)for p in v};edges={tuple(sorted((a,b)))for t in tri for a,b in [(t[0],t[1]),(t[1],t[2]),(t[2],t[0])]}
 for a,b in edges:
  count=max(1,math.ceil((v[a]-v[b]).length/.006))
  for step in range(1,count):pts.add(tuple(v[a].lerp(v[b],step/count)))
 for a,b,c in tri:pts.add(tuple((v[a]+v[b]+v[c])/3))
 samples.append([Vector(p)for p in pts])
links=[];connected={i for i,b in enumerate(boxes)if b[1][0]<=.072+tol};
for i,pts in enumerate(samples):
 if i in connected:continue
 for p in pts:
  hit=crate_tree.find_nearest(p,tol)
  if hit[0]is not None and hit[1].y>.2:connected.add(i);break
floor_contacts=sorted(connected)
for a in range(len(parts)):
 for b in range(a):
  if any(max(boxes[a][k][0],boxes[b][k][0])-min(boxes[a][k][1],boxes[b][k][1])>tol for k in range(3)):continue
  x,y=(a,b)if len(samples[a])<len(samples[b])else(b,a);nearest=1.0
  for p in samples[x]:
   hit=trees[y].find_nearest(p,tol)
   if hit[0]is not None:nearest=hit[3];break
  if nearest<=tol:links.append([a,b,nearest])
while True:
 previous=len(connected)
 for a,b,dist in links:
  if a in connected or b in connected:connected.update([a,b])
 if len(connected)==previous:break
report={'kind':data['kind'],'count':len(parts),'contact_tolerance_m':tol,'floor_contacts':floor_contacts,'visible_surface_contacts':links,'grounded_count':len(connected),'ungrounded':[parts[i]['name']for i in range(len(parts))if i not in connected],'max_height':max(b[1][1]for b in boxes),'wall_check':'actual crate triangle nonintersection for module kit; inset wall limits for rail kit','frames':data['frames']}
out.write_text(json.dumps(report,indent=2));print(json.dumps(report),flush=True)
assert not report['ungrounded'],'Unsupported visible geometry; review simulation before release'
