using System;
using System.Collections.Generic;
using System.Linq;
namespace ModularSwitchboards
{
    internal static class DoorModuleLayout
    {
        internal const int Channels=18;
        internal const float Pitch=.10f,Spacing=.024f;
        internal static bool Fits(int x,int y,int z,int rotation)=>x%10==0&&y%10==0&&Math.Abs(x)<=10&&Math.Abs(y)<=10&&z==0&&rotation==0;
        internal static WireRect HarnessWindow=>new WireRect(-.193f,-.164f,-.220f,.220f);
        internal static WireRect[] Reservations()=>Enumerable.Range(-1,3).SelectMany(x=>Enumerable.Range(-1,3).Select(y=>new WireRect(x*Pitch-.019f,x*Pitch+.019f,y*Pitch-.034f,y*Pitch+.034f))).ToArray();
        internal static float ChannelY(int channel)=>(channel-8.5f)*Spacing;
        // Alternate feed/return so each door position can use a nearby pair.
        internal static bool DoorSide(int contact)=>contact/2%2==0?contact%2==1:contact%2==0;
        internal static IEnumerable<CabinetWireSaveData> Through(IEnumerable<CabinetWireSaveData> wires,IEnumerable<long> bridges)
            =>WireCircuit.Through(wires,bridges,Channels);
        internal static class DoorFlexGeometry
        {
            internal static WirePoint[] Build(WirePoint a,WirePoint b,WirePoint c,WirePoint d)
            {
                var path=new WirePoint[25];
                for(int i=0;i<path.Length;i++){float t=i/(float)(path.Length-1),u=1-t;path[i]=a*(u*u*u)+b*(3*u*u*t)+c*(3*u*t*t)+d*(t*t*t);}
                return path;
            }
        }
        internal static bool Energized(long led,IEnumerable<CabinetWireSaveData> wires,IEnumerable<long> closed,bool inputLive,IEnumerable<long> liveBatteries)
        {
            var target=new CabinetWireEnd(led,0);var paths=wires.ToArray();var ids=closed.ToArray();
            return inputLive&&WireCircuit.Reachable(new CabinetWireEnd(0,0),target,paths,ids)||
                liveBatteries.Any(id=>WireCircuit.Reachable(new CabinetWireEnd(id,1),target,paths,ids));
        }
    }
}
