using System;
using System.Collections.Generic;
using System.Linq;
using Assets.Scripts;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Objects;
using Assets.Scripts.Localization2;
using Assets.Scripts.UI;
using LibConstruct;
using HarmonyLib;
using Rendering;
using UnityEngine;

namespace ModularSwitchboards
{
    public sealed class SwitchboardDoorBoard:PlacementBoard
    {
        public override float GridSize=>DoorModuleLayout.Pitch;
        public override IPlacementBoardStructure EquivalentStructure(Structure structure)
            =>structure is DinBreaker part&&part.IsDoorLed&&PrimaryHost is SwitchboardCabinet host&&host.IsStructureCompleted?part:null;
    }
    public sealed class SwitchboardBridgeBoard:PlacementBoard
    {
        public override float GridSize=>.018f;
        public override IPlacementBoardStructure EquivalentStructure(Structure structure)
            =>structure is DinBreaker part&&part.IsDoorBridge&&PrimaryHost is SwitchboardCabinet host&&host.CanFitRails?part:null;
    }
    internal static class DoorModules
    {
        internal const string FrameName="DoorWireFrame";
        internal static Transform Frame(SwitchboardCabinet host)=>host.transform.Find("SwitchboardModel/CompletedShell/DoorHinge/"+FrameName);
        internal static void InstallBoard(SwitchboardCabinet host)
        {
            var shell=host.transform.Find("SwitchboardModel/CompletedShell");var hinge=shell.Find("DoorHinge");
            var origin=new GameObject("DoorModuleBoard"){layer=host.gameObject.layer};origin.transform.SetParent(hinge,false);
            // Door sheet extends from -.002 to +.010 in hinge-local Z.
            origin.transform.localPosition=new Vector3(.2f,0,.0105f);host.DoorOrigin=origin.transform;
            host.DoorSurface=origin.AddComponent<BoxCollider>();host.DoorSurface.size=new Vector3(.29f,.29f,.0005f);
            host.BuildStates[1].Colliders.Add(host.DoorSurface);
            var frame=new GameObject(FrameName){layer=host.gameObject.layer};frame.transform.SetParent(hinge,false);
            frame.transform.localPosition=new Vector3(.2f,0,-.0025f);frame.transform.localRotation=Quaternion.Euler(0,180,0);
            var fixedOrigin=new GameObject("DoorBridgeBoard"){layer=host.gameObject.layer};fixedOrigin.transform.SetParent(shell,false);
            fixedOrigin.transform.localPosition=new Vector3(-.183f,0,.018f);host.BridgeOrigin=fixedOrigin.transform;
            host.BridgeSurface=fixedOrigin.AddComponent<BoxCollider>();host.BridgeSurface.center=new Vector3(0,0,.001f);host.BridgeSurface.size=new Vector3(.016f,.426f,.001f);host.BridgeSurface.enabled=false;
            host.BuildStates[1].Colliders.Add(host.BridgeSurface);
        }
        internal static bool CanPlace(PlacementBoard board,Grid3 p,int rotation,bool bridge=false)
        {
            if(!(board?.PrimaryHost is SwitchboardCabinet host)||!host.IsStructureCompleted)return false;
            if(bridge)return board is SwitchboardBridgeBoard&&host.CanFitRails&&p.x==0&&p.y==0&&p.z==0&&rotation==0&&board.Structures.Count==0;
            return board is SwitchboardDoorBoard&&DoorModuleLayout.Fits(p.x,p.y,p.z,rotation)&&!board.Structures.OfType<DinBreaker>().Any(m=>{var q=board.WorldToGrid(m.transform.position);return q.x==p.x&&q.y==p.y;});
        }
        internal static CanConstructInfo CanConstruct(DinBreaker part)
        {
            var board=part.Board;
            if(board==null||PlacementBoard.CursorBoard!=board)return CanConstructInfo.InvalidPlacement(part.IsDoorBridge?"Aim at the mounting plate beside the left hinge.":"Aim at the outside of the small cabinet door.");
            var p=board.WorldToGrid(part.transform.position);
            if(part.IsCursor){p=part.IsDoorBridge?new Grid3(0,0,0):new Grid3(Mathf.RoundToInt(p.x/10f)*10,Mathf.RoundToInt(p.y/10f)*10,0);part.transform.SetPositionAndRotation(board.GridToWorld(p),board.IndexToRotation(0));}
            return CanPlace(board,p,board.RotationToIndex(part.transform.rotation),part.IsDoorBridge)?CanConstructInfo.ValidPlacement:CanConstructInfo.InvalidPlacement("Choose a free door position; the terminal bridge fits only beside the hinge.");
        }
        internal static CanConstructInfo CanDeconstruct(DinBreaker part)
        {
            var host=CabinetWiring.CabinetOf(part);
            if(host==null||!host.CanAccessModules)return CanConstructInfo.InvalidPlacement("Open the cabinet first.");
            if(host.Wiring.HasWires(part.ReferenceId))return CanConstructInfo.InvalidPlacement("Remove connected wires first.");
            return CanConstructInfo.ValidPlacement;
        }
        private static Material black,grey,green;
        private static Material Material(string name,Color colour)
        {
            var shader=Shader.Find("Standard");if(shader==null||!shader.isSupported)shader=Shader.Find("StandardInstanced");
            if(shader==null||!shader.isSupported)throw new InvalidOperationException("Door module shader unavailable.");
            var m=new Material(shader){name=name,color=colour};m.SetFloat("_Glossiness",.27f);m.SetFloat("_Metallic",.1f);return m;
        }
        private static void Materials()
        {
            if(black!=null)return;
            black=Material("Switchboards.Door.Black",new Color(.025f,.029f,.028f));grey=Material("Switchboards.Door.Terminals",new Color(.5f,.53f,.51f));
            green=Material("Switchboards.Door.Green",new Color(.015f,.20f,.025f));green.EnableKeyword("_EMISSION");green.SetColor("_EmissionColor",Color.black);
        }
        private static Mesh Box(Vector3 center,Vector3 size)
        {
            var v=new List<Vector3>();var n=new List<Vector3>();var t=new List<int>();RoundedGeometry.Box(v,n,t,center,size,.001f);
            var mesh=new Mesh{name="Door module body"};mesh.SetVertices(v);mesh.SetNormals(n);mesh.SetTriangles(t,0);mesh.RecalculateBounds();return mesh;
        }
        private static Mesh Cylinder(float radius,float back,float front)
        {
            const int steps=32;var v=new List<Vector3>();var t=new List<int>();
            for(int i=0;i<steps;i++)
            {
                float a=i*2*Mathf.PI/steps,b=(i+1)*2*Mathf.PI/steps;int p=v.Count;
                v.AddRange(new[]{new Vector3(radius*Mathf.Cos(a),radius*Mathf.Sin(a),back),new Vector3(radius*Mathf.Cos(b),radius*Mathf.Sin(b),back),new Vector3(radius*Mathf.Cos(a),radius*Mathf.Sin(a),front),new Vector3(radius*Mathf.Cos(b),radius*Mathf.Sin(b),front),new Vector3(0,0,back),new Vector3(0,0,front)});
                t.AddRange(new[]{p,p+1,p+2,p+1,p+3,p+2,p+4,p+1,p,p+5,p+2,p+3});
            }
            var mesh=new Mesh{name="Door LED lens/bezel"};mesh.SetVertices(v);mesh.SetTriangles(t,0);mesh.RecalculateNormals();mesh.RecalculateBounds();return mesh;
        }
        private static MeshRenderer Part(Transform root,string name,Mesh mesh,Material material)
        {
            var go=new GameObject(name){layer=root.gameObject.layer};go.transform.SetParent(root,false);go.AddComponent<MeshFilter>().sharedMesh=mesh;
            var renderer=go.AddComponent<MeshRenderer>();renderer.sharedMaterial=material;return renderer;
        }
        private static void Text(Transform parent,string value,Vector3 position,bool rear=false)
        {
            Font font=null;foreach(var name in new[]{"LegacyRuntime.ttf","Arial.ttf"}){try{font=Resources.GetBuiltinResource<Font>(name);}catch(Exception){}if(font!=null)break;}
            if(font==null)font=Resources.FindObjectsOfTypeAll<Font>().FirstOrDefault();if(font==null)return;
            var go=new GameObject("DoorTerminalText"){layer=parent.gameObject.layer};go.transform.SetParent(parent,false);go.transform.localPosition=position;go.transform.localRotation=rear?Quaternion.identity:Quaternion.Euler(0,180,0);
            var text=go.AddComponent<TextMesh>();text.font=font;text.fontSize=32;text.characterSize=.0035f;text.anchor=TextAnchor.MiddleCenter;text.alignment=TextAlignment.Center;text.richText=false;text.color=Color.black;text.text=value;
            go.AddComponent<DoorTerminalTextView>().Text=text;DepthLabelText.Apply(text);
        }
        internal static void TerminalStrip(Transform root,float inward)
        {
            Materials();Part(root,"Terminal strip",Box(new Vector3(0,0,.010f),new Vector3(.016f,.426f,.02f)),black);
            for(int i=0;i<DoorModuleLayout.Channels;i++)
            {
                float y=DoorModuleLayout.ChannelY(i);
                Part(root,"Terminal "+(i+1),Box(new Vector3(0,y,.021f),new Vector3(.014f,.013f,.006f)),grey);
                Part(root,"Screw "+(i+1),Box(new Vector3(0,y,.0245f),new Vector3(.008f,.0015f,.001f)),black);
                Part(root,"Channel plate",Box(new Vector3(0,y+.009f,.023f),new Vector3(.014f,.005f,.001f)),grey);
                Text(root,(i+1).ToString()+(i%2==0?">":"<"),new Vector3(0,y+.009f,.0236f));
                // Contact mouth at the inner edge of each separate channel.
                Part(root,"Entry "+(i+1),Box(new Vector3(inward*.008f,y,.013f),new Vector3(.001f,.007f,.007f)),grey);
            }
        }
        internal static void Install(DinBreaker part,Transform storage)
        {
            foreach(var c in part.GetComponentsInChildren<Renderer>(true))UnityEngine.Object.DestroyImmediate(c);
            foreach(var c in part.GetComponentsInChildren<MeshFilter>(true))UnityEngine.Object.DestroyImmediate(c);
            foreach(var c in part.GetComponentsInChildren<Collider>(true))UnityEngine.Object.DestroyImmediate(c);
            foreach(var c in part.GetComponentsInChildren<Animator>(true))UnityEngine.Object.DestroyImmediate(c);
            Materials();part.BaseAnimator=null;part.Renderers=new List<ThingRenderer>();part.Interactables=new List<Interactable>();part.Slots=new List<Slot>();
            part._staticColliders=new List<Collider>();part._dynamicColliders=new List<Collider>();part._selfColliders=new List<Collider>();
            part.CustomNavMeshFilter=null;part.structureRenderMode=StructureRenderMode.Standard;part.ForceGridBounds.Clear();part.BrokenBuildStates=new List<BrokenBuildState>();part.StructureCollisionType=CollisionType.BlockCustom;
            part.SelectionDisplay=SelectionHighlightMethod.Bounds;part.UseCellPosition=false;part.PaintableMaterial=null;part.HasColorState=false;part.HasOnOffState=false;part.MPBRenderers.Clear();
            MeshRenderer body;var hit=part.gameObject.AddComponent<BoxCollider>();
            if(part.IsDoorLed)
            {
                body=Part(part.transform,"DoorLedBezel",Cylinder(.016f,-.002f,.004f),black);
                var lens=Part(part.transform,"DoorLedLens",Cylinder(.012f,.0038f,.009f),green);
                Part(part.transform,"DoorLedRear",Box(new Vector3(0,0,-.025f),new Vector3(.036f,.046f,.021f)),black);
                for(int pin=0;pin<2;pin++){float y=pin==0?.016f:-.016f;Part(part.transform,pin==0?"IN":"OUT",Box(new Vector3(0,y,-.0365f),new Vector3(.016f,.012f,.003f)),grey);Part(part.transform,"Screw",Box(new Vector3(0,y,-.0385f),new Vector3(.01f,.001f,.001f)),black);}
                hit.center=new Vector3(0,0,-.014f);hit.size=new Vector3(.038f,.048f,.048f);
                Text(part.transform,"IN",new Vector3(0,.016f,-.0387f),true);Text(part.transform,"OUT",new Vector3(0,-.016f,-.0387f),true);
                var view=part.gameObject.AddComponent<DoorLedView>();view.Owner=part;view.Lens=lens;
            }
            else
            {
                TerminalStrip(part.transform,1);
                body=part.GetComponentInChildren<MeshRenderer>();hit.center=new Vector3(0,0,.012f);hit.size=new Vector3(.018f,.426f,.026f);
                var view=part.gameObject.AddComponent<DoorBridgeView>();view.Owner=part;
            }
            part.Bounds=new Bounds(hit.center,hit.size);part.GridBounds=new GridBounds(part);part.SurfaceArea=.01f;part.Thumbnails=new Sprite[0];
            // Existing native item icon is temporary, like the requested Logic Kit model.
            part.Thumbnail=CabinetIcons.Get(part.IsDoorLed?"DoorLed":"DoorBridge");
            var state=part.BuildStates[0];state.Visualizer=body;state.StateMeshes=new List<Mesh>();state.RendererInstance=null;state.Colliders=new List<Collider>{hit};state.Interactables=new List<Interactable>();state.LinkedGameObjects=new List<GameObject>();state.RenderMode=BuildStateRenderMode.OnMyState;state.BlockAir=state.AlwaysBlockAir=state.BlockLight=state.BlockGravity=false;state.Thumbnail=part.Thumbnail;
            AccessTools.Field(typeof(BuildState),"initialDrawData").SetValue(state,new DrawData{mesh=null,materials=new Material[0]});
            var bp=new GameObject("DoorModuleBlueprint"){layer=part.gameObject.layer};bp.transform.SetParent(storage,false);
            var ghost=Box(hit.center,hit.size);var filter=bp.AddComponent<MeshFilter>();filter.sharedMesh=ghost;var renderer=bp.AddComponent<MeshRenderer>();renderer.sharedMaterial=grey;
            var wire=bp.AddComponent<Wireframe>();wire.BlueprintTransform=bp.transform;wire.BlueprintBounds=ghost.bounds;wire.BlueprintMeshFilter=filter;wire.BlueprintRenderer=renderer;bp.AddComponent<CabinetBlueprint>();part.Blueprint=bp;part.BlueprintOrientVector=Vector3.zero;
        }
    }
    public sealed class DoorTerminalTextView:MonoBehaviour
    {
        public TextMesh Text;private void LateUpdate(){if(Text!=null)DepthLabelText.Apply(Text);}
    }
    public sealed class DoorLedView:MonoBehaviour
    {
        public DinBreaker Owner;public MeshRenderer Lens;
        private void LateUpdate()
        {
            if(Owner==null||Lens==null)return;
            var block=new MaterialPropertyBlock();bool on=!Owner.IsCursor&&Owner.DoorLit;
            block.SetColor("_Color",on?new Color(.035f,.75f,.08f):new Color(.008f,.10f,.014f));
            block.SetColor("_EmissionColor",on?new Color(.04f,1.4f,.10f):Color.black);Lens.SetPropertyBlock(block);
            foreach(var c in Owner.GetComponentsInChildren<Collider>())Thing._colliderLookup[c]=Owner;
        }
    }
    // Mechanical harness is visual only; all18 electrical edges are independent graph connections.
    public sealed class DoorBridgeView:MonoBehaviour
    {
        public DinBreaker Owner;
        private GameObject moving;
        private readonly List<MeshFilter> cables=new List<MeshFilter>();
        private Quaternion last;private bool initialized;
        private void LateUpdate()
        {
            var host=Owner==null?null:CabinetWiring.CabinetOf(Owner);
            if(host==null||Owner.IsCursor)return;
            var frame=DoorModules.Frame(host);if(frame==null)return;
            if(moving==null)
            {
                moving=new GameObject("MovingDoorTerminals"){layer=Owner.gameObject.layer};moving.transform.SetParent(transform,false);
                DoorModules.TerminalStrip(moving.transform,-1);
                var hit=moving.AddComponent<BoxCollider>();hit.center=new Vector3(0,0,.012f);hit.size=new Vector3(.018f,.426f,.026f);Thing._colliderLookup[hit]=Owner;
                for(int i=0;i<DoorModuleLayout.Channels;i++){var go=new GameObject("DoorFlex "+(i+1)){layer=Owner.gameObject.layer};go.transform.SetParent(transform,false);var filter=go.AddComponent<MeshFilter>();cables.Add(filter);go.AddComponent<MeshRenderer>().sharedMaterial=CabinetGeometry.Materials[3];}
            }
            moving.transform.SetPositionAndRotation(frame.TransformPoint(new Vector3(.172f,0,0)),frame.rotation);
            if(initialized&&Quaternion.Angle(last,frame.rotation)<.05f)return;
            initialized=true;last=frame.rotation;
            for(int lane=0;lane<cables.Count;lane++)
            {
                float y=DoorModuleLayout.ChannelY(lane);
                var p0=new Vector3(.009f,y,.013f);
                var end=transform.InverseTransformPoint(moving.transform.TransformPoint(new Vector3(-.009f,y,.013f)));
                var p1=p0+new Vector3(-.010f,0,.07f);var p2=end+transform.InverseTransformDirection(frame.TransformDirection(new Vector3(.018f,0,.055f)));
                var path=DoorModuleLayout.DoorFlexGeometry.Build(CabinetWiring.Point(p0),CabinetWiring.Point(p1),CabinetWiring.Point(p2),CabinetWiring.Point(end));
                var mesh=WireMesh.Build(path);var old=cables[lane].sharedMesh;cables[lane].sharedMesh=mesh;if(old!=null)Destroy(old);
            }
        }
        private void OnDestroy()
        {
            foreach(var c in cables)if(c!=null&&c.sharedMesh!=null)Destroy(c.sharedMesh);
            if(moving!=null){foreach(var hit in moving.GetComponentsInChildren<Collider>())if(Thing._colliderLookup.TryGetValue(hit,out var owner)&&owner==Owner)Thing._colliderLookup.Remove(hit);foreach(var filter in moving.GetComponentsInChildren<MeshFilter>())if(filter.sharedMesh!=null)Destroy(filter.sharedMesh);}
        }
    }
}
