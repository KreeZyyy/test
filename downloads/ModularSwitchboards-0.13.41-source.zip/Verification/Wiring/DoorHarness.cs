using System;using System.Linq;using System.Collections.Generic;using ModularSwitchboards;using Assets.Scripts.Networks;
static class DoorHarness
{
 static int checks;static void Check(bool b,string m){checks++;if(!b)throw new Exception("Door: "+m);}
 static CabinetWireSaveData W(long a,int ap,long b,int bp)=>new(){From=new(a,ap),To=new(b,bp)};
 internal static void Run()
 {
  int count=0;for(int x=-20;x<=20;x+=10)for(int y=-20;y<=20;y+=10)if(DoorModuleLayout.Fits(x,y,0,0))count++;
  Check(count==9,"exactly nine positions");Check(!DoorModuleLayout.Fits(1,0,0,0)&&!DoorModuleLayout.Fits(0,0,1,0)&&!DoorModuleLayout.Fits(0,0,0,1),"invalid grid/rotation");
  for(int pin=0;pin<36;pin++)Check(DoorModuleLayout.DoorSide(pin)!=DoorModuleLayout.DoorSide(pin^1),"two ends on opposite sides");
  var paths=DoorModuleLayout.Through(Array.Empty<CabinetWireSaveData>(),new long[]{900}).ToArray();
  Check(paths.Length==18,"18 independent pathways");
  for(int a=0;a<18;a++)for(int b=0;b<18;b++)
  {
   Check(WireCircuit.Reachable(new(900,a*2),new(900,b*2+1),paths,Array.Empty<long>())==(a==b),"cross-channel isolation");
   Check(!WireCircuit.Reachable(new(900,a*2+1),new(900,b*2),paths,Array.Empty<long>()),"reverse feed rejected");
  }
  var wiring=new List<CabinetWireSaveData>{W(0,0,10,0),W(10,1,0,1),W(10,1,900,0),W(900,1,100,0)};
  var graph=DoorModuleLayout.Through(wiring,new long[]{900}).ToArray();
  Check(DoorModuleLayout.Energized(100,graph,new long[]{10,900,100},true,Array.Empty<long>()),"IN-only LED lights with no load or OUT");
  Check(!DoorModuleLayout.Energized(100,graph,new long[]{900,100},true,Array.Empty<long>()),"open protection darkens lamp");
  Check(!DoorModuleLayout.Energized(100,graph,new long[]{10,900,100},false,Array.Empty<long>()),"dead input darkens lamp");
  Check(DoorModuleLayout.Energized(100,graph,new long[]{10,900,100},false,new long[]{10}),"live downstream backup");
  Check(!DoorModuleLayout.Energized(100,graph,new long[]{10,900,100},false,new long[]{777}),"isolated backup cannot power LED");
  wiring.Add(W(100,1,900,2));wiring.Add(W(900,3,0,2));graph=DoorModuleLayout.Through(wiring,new long[]{900}).ToArray();
  Check(WireCircuit.Reachable(new(0,0),new(0,2),graph,new long[]{10,900,100}),"LED OUT optional return path conducts");
  var first=new List<CabinetWireSaveData>{W(10,1,0,1)};
  Check(WireCircuit.CanConnect(new(10,1),new(900,0),first,new long[]{10},out _),"second protection OUT branch");
  first.Add(W(10,1,900,0));Check(!WireCircuit.CanConnect(new(10,1),new(999,0),first,new long[]{10},out _),"third OUT branch rejected");
  Check(!WireCircuit.CanConnect(new(900,1),new(900,18),wiring,new long[]{10,100},out _,bridges:new long[]{900}),"same-bridge jumper cannot bypass loop checks");
  var input=new CableNetwork{PotentialLoad=10000};var one=new CableNetwork{RequiredLoad=1000};var two=new CableNetwork{RequiredLoad=500};
  var host=new SwitchboardCabinet();host.InputConnection.cable.CableNetwork=input;host.Output1Connection.cable.CableNetwork=one;host.Output2Connection.cable.CableNetwork=two;
  var breaker=new DinBreaker{ReferenceId=10,OnOff=true,RatedWatts=1000};var led=new DinBreaker{ReferenceId=100,IsDoorLed=true,RatedWatts=0};var bridge=new DinBreaker{ReferenceId=900,IsDoorBridge=true,RatedWatts=0};
  var power=new CabinetWiringPower();power.Refresh(host,wiring,new[]{breaker,led,bridge});
  Check(power.Generated(two)>0,"power path goes through bridge and LED");
  power.Use(one,600);power.Use(two,400);Check(power.DrainTrips().Length==0,"combined threshold; passive modules do not trip");
  power.Use(two,401);Check(power.DrainTrips().SequenceEqual(new long[]{10}),"two branches share protection rating");
  breaker.OnOff=false;power.Refresh(host,wiring,new[]{breaker,led,bridge});Check(power.Generated(one)==0&&power.Generated(two)==0,"trip isolates both paths");
  var fork=new WireRect(-.019f,.019f,-.01f,.03f);var shared=new List<WirePoint[]>{new[]{new WirePoint(0,.02f,.06f),new WirePoint(0,-.05f,.06f)}};
  Check(WireBranchJoint.Clear(new(0,.02f,.06f),new(.012f,.0f,.06f),shared,fork),"intentional same-terminal fork allowed");
  Check(!WireBranchJoint.Clear(new(0,-.02f,.06f),new(0,-.04f,.06f),shared,fork),"outside fork full clearance");
  // Same cubic flex centreline used by the moving hinge view.
  foreach(float angle in new[]{0f,-25f,-55f,-90f,-110f})
  {
   float r=angle*MathF.PI/180f;WirePoint Rotate(float x,float y,float z)=>new(x*MathF.Cos(r)+z*MathF.Sin(r),y,-x*MathF.Sin(r)+z*MathF.Cos(r));
   var lines=new List<WirePoint[]>();
   for(int i=0;i<18;i++)
   {
    float y=DoorModuleLayout.ChannelY(i);var a=new WirePoint(-.174f,y,.031f);var b=a+new WirePoint(-.010f,0,.07f);
    var d=Rotate(.037f,y,-.0155f)+new WirePoint(-.2f,0,.187f);var c=d+Rotate(-.018f,0,-.055f);
    var line=DoorModuleLayout.DoorFlexGeometry.Build(a,b,c,d);Check((line[0]-a).Squared<1e-12f&&(line[^1]-d).Squared<1e-12f,"moving harness stays attached");
    Check(line.All(p=>float.IsFinite(p.X)&&float.IsFinite(p.Y)&&float.IsFinite(p.Z)),"finite flex");TubeHarness.AssertSections(line);
    for(int j=1;j<line.Length;j++)
    {
     var p=line[j-1];var q=line[j];
     if((p.Z-.1015f)*(q.Z-.1015f)<=0&&MathF.Abs(q.Z-p.Z)>1e-7f){float t=(.1015f-p.Z)/(q.Z-p.Z);var cross=p+(q-p)*t;Check(cross.X-WireRouting.Radius>=DoorModuleLayout.HarnessWindow.Left&&cross.X+WireRouting.Radius<=DoorModuleLayout.HarnessWindow.Right&&MathF.Abs(cross.Y)+WireRouting.Radius<.220f,"flex clears fitted inner cover");}
     if(angle==0)Check(p.Z>.111f||p.X+WireRouting.Radius<-.16155f,"closed harness clears left DIN module bodies");
    }
    if(lines.Count>0)for(int j=1;j<line.Length;j++)for(int k=1;k<lines[^1].Length;k++)Check(WireRouting.SegmentDistanceSquared(line[j-1],line[j],lines[^1][k-1],lines[^1][k])>=WireRouting.Clearance*WireRouting.Clearance,"flex channels stay separate");
    lines.Add(line);
   }
  }
  Routes();FullDoor();
  Console.WriteLine("Door modules passed "+checks+" checks: 3x3, 18 isolated channels, LED supply, optional OUT, two-branch protection and actual routes.");
 }
 static void FullDoor()
 {
  var h=new RouteHarness();
  for(int pin=0;pin<36;pin++)if(DoorModuleLayout.DoorSide(pin))
  {
   var e=new CabinetWireEnd(900,pin);float y=DoorModuleLayout.ChannelY(pin/2);
   h.contacts[e]=new(){End=e,Door=true,Position=new(.163f,y,.013f),Exit=new(.153f,y,.043f),Bounds=new(.164f,.181f,-.214f,.214f)};
  }
  for(int n=0;n<9;n++)
  {
   float x=(n%3-1)*.1f,y=(n/3-1)*.1f;
   for(int pin=0;pin<2;pin++){var e=new CabinetWireEnd(100+n,pin);float sign=pin==0?1:-1;h.contacts[e]=new(){End=e,Door=true,Position=new(x,y+sign*.023f,.017f),Exit=new(x,y+sign*.043f,.043f),Bounds=new(x-.019f,x+.019f,y-.024f,y+.024f)};}
  }
  for(int n=0;n<9;n++)foreach(var pair in new[]{(new CabinetWireEnd(900,n*4+1),new CabinetWireEnd(100+n,0)),(new CabinetWireEnd(100+n,1),new CabinetWireEnd(900,n*4+2))})
  {
   var p=h.MakeRoute(pair.Item1,pair.Item2,out int slot,out string failure);Check(p!=null,"full9 LED "+n+" "+pair+": "+failure);Check(!WireRouting.SelfIntersects(p),"full9 self crossing");TubeHarness.AssertSections(p);
   h.wires.Add(new(){From=pair.Item1,To=pair.Item2,InputSlot=slot,Points=p.SelectMany(v=>new[]{v.X,v.Y,v.Z}).ToArray()});
  }
 }
 static void Routes()
 {
  var h=new RouteHarness();
  // Actual inner-door coordinates of middle LED and moving bridge strip.
  for(int pin=0;pin<36;pin++)if(DoorModuleLayout.DoorSide(pin))
  {
   var e=new CabinetWireEnd(900,pin);float y=DoorModuleLayout.ChannelY(pin/2);
   h.contacts[e]=new(){End=e,Door=true,Position=new(.163f,y,.013f),Exit=new(.153f,y,.043f),Bounds=new(.164f,.181f,-.214f,.214f)};
  }
  for(int pin=0;pin<2;pin++)
  {
   var e=new CabinetWireEnd(100,pin);float sign=pin==0?1:-1;
   h.contacts[e]=new(){End=e,Door=true,Position=new(0,sign*.023f,.017f),Exit=new(0,sign*.043f,.043f),Bounds=new(-.019f,.019f,-.024f,.024f)};
  }
  foreach(var pair in new[]{(new CabinetWireEnd(900,1),new CabinetWireEnd(100,0)),(new CabinetWireEnd(100,1),new CabinetWireEnd(900,2))})
  {
   var path=h.MakeRoute(pair.Item1,pair.Item2,out int slot,out string failure);
   Check(path!=null,"door route "+pair+" "+failure);Check(!WireRouting.SelfIntersects(path),"door self intersection");TubeHarness.AssertSections(path);
   h.wires.Add(new(){From=pair.Item1,To=pair.Item2,Points=path.SelectMany(p=>new[]{p.X,p.Y,p.Z}).ToArray(),InputSlot=slot});
  }
  var back=new RouteHarness();var from=new CabinetWireEnd(10,1);var output=new CabinetWireEnd(0,1);var target=new CabinetWireEnd(900,0);
  back.contacts[from]=new(){End=from,Position=new(-.10125f,.057375f,.06535f),Exit=new(-.10125f,.042f,.06535f),Bounds=new(-.12105f,-.08145f,.057375f,.158625f)};
  back.contacts[output]=new(){End=output,Position=new(.108f,-.196f,.033f),Exit=new(.108f,-.184f,.06535f),Bounds=new(.072f,.144f,-.227f,-.195f)};
  back.contacts[target]=new(){End=target,Position=new(-.174f,-.204f,.031f),Exit=new(-.164f,-.204f,.06535f),Bounds=new(-.192f,-.175f,-.214f,.214f)};
  foreach(var to in new[]{output,target})
  {
   var path=back.MakeRoute(from,to,out int slot,out string failure);Check(path!=null,"second real source branch "+failure);
   Check(!WireRouting.SelfIntersects(path),"fork route self intersection");TubeHarness.AssertSections(path);
   back.wires.Add(new(){From=from,To=to,Points=path.SelectMany(p=>new[]{p.X,p.Y,p.Z}).ToArray(),InputSlot=slot});
  }
 }
}
