#!/usr/bin/env python3
"""Process/IO regression fixture, NOT a neural voice implementation."""
import argparse, json, os, pathlib, struct, sys, time, wave
p=argparse.ArgumentParser()
p.add_argument('--model',required=True)
p.add_argument('--config',required=True)
p.add_argument('--output_file',required=True)
p.add_argument('--length_scale',required=True)
a=p.parse_args()
config=json.loads(pathlib.Path(a.config).read_text())
text=sys.stdin.buffer.read().decode('utf-8')
log=pathlib.Path(__file__).parent/'events.jsonl'
def record(kind):
    with log.open('a',encoding='utf-8') as f:
        f.write(json.dumps({'kind':kind,'pid':os.getpid(),'text':text,'model':a.model,
            'config':a.config,'output':a.output_file,'cwd':os.getcwd(),'scale':a.length_scale})+'\n')
record('start')
mode=config.get('mode','ok')
if mode=='fail':
    sys.stderr.write('SECRET_TEST_KEY '+text)
    sys.exit(37)
if mode=='slow': time.sleep(120)
if mode=='noisy':
    sys.stdout.write('x'*1048576); sys.stdout.flush()
    sys.stderr.write('y'*1048576); sys.stderr.flush()
if mode=='invalid': pathlib.Path(a.output_file).write_bytes(b'not a WAV')
elif mode=='large': pathlib.Path(a.output_file).write_bytes(b'x'*1048577)
else:
    time.sleep(.1)
    with wave.open(a.output_file,'wb') as wav:
        wav.setnchannels(1); wav.setsampwidth(2); wav.setframerate(22050)
        wav.writeframes(struct.pack('<h',42)*2205)
record('end')
