using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;
using ScriptedScreensLiteGeminiAI;

internal static class PiperTests
{
    private static int count;
    private static void Check(bool ok,string name)
    { if (!ok) throw new Exception("FAIL "+name); count++; Console.WriteLine("PASS "+name); }
    private static async Task Error(Func<Task> action,int status,string name)
    {
        try { await action(); throw new Exception("Expected failure "+name); }
        catch (AiException ex) { Check(ex.Status==status && !ex.Message.Contains("SECRET_TEST_KEY"),name); }
    }
    private sealed class GoogleStub : IAiProvider
    {
        public int Texts,Voices;
        public Task<string> TextAsync(AskRequest request,IReadOnlyList<Turn> context,CancellationToken cancellation)
        { Texts++; return Task.FromResult("Ahoj, mluvím česky."); }
        public Task<byte[]> SpeechAsync(string text,AskRequest request,CancellationToken cancellation)
        { Voices++; return Task.FromResult(WaveAudio.FromPcm16(new byte[]{0,0,1,0})); }
    }
    private static async Task<JObject> Finished(JobService jobs,string id)
    {
        for (int i=0;i<300;i++)
        {
            var job=jobs.Get(id);
            if ((string?)job["state"]=="done" || (string?)job["state"]=="error") return job;
            await Task.Delay(20);
        }
        throw new Exception("Job did not finish");
    }
    private static async Task Main()
    {
        if (OperatingSystem.IsWindows()) throw new Exception("This executable-fixture suite requires Linux + python3; use in-game Test Piperu on Windows.");
        string root=Path.Combine(Path.GetTempPath(),"piper tests & "+Guid.NewGuid().ToString("N"));
        string exeFolder=Path.Combine(root,"exe folder"),voiceFolder=Path.Combine(root,"voice files");
        Directory.CreateDirectory(exeFolder); Directory.CreateDirectory(voiceFolder);
        string exe=Path.Combine(exeFolder,"piper fixture"),model=Path.Combine(voiceFolder,"voice 'model'.onnx");
        string fixture=Path.Combine(Environment.CurrentDirectory,"tests","fake_piper.py");
        File.Copy(fixture,exe); File.SetUnixFileMode(exe,UnixFileMode.UserRead|UnixFileMode.UserWrite|UnixFileMode.UserExecute);
        File.WriteAllText(model,"fixture, not a neural model");
        void Mode(string mode) => File.WriteAllText(model+".json",new JObject{["mode"]=mode}.ToString());
        Mode("ok");
        var s=new Settings { DataDirectory=Path.Combine(root,"data"),SpeechProvider="Piper",PiperExecutable=exe,
            PiperModel=model,BridgeToken=new string('t',32),CooldownSeconds=0,MaxAudioFileMegabytes=1 };
        try
        {
            s.Validate(); Check(s.UsesPiper,"Piper settings validate with no Google key");
            var piper=new PiperClient(s);
            string text="Příliš žluťoučký kůň. Řekl \"ahoj\".\nDruhý řádek; $(touch never-run).";
            var wav=await piper.SpeechAsync(text,CancellationToken.None);
            var events=File.ReadAllLines(Path.Combine(exeFolder,"events.jsonl")).Select(JObject.Parse).ToArray();
            Check(WaveAudio.DurationSeconds(wav)==.1,"Piper process WAV preserves its native 22050 Hz rate");
            Check((string?)events[0]["text"]==text.Replace('\n',' ')+"\n","Czech accents/quotes travel through UTF-8 stdin without BOM, as one full reply");
            Check((string?)events[0]["model"]==model && (string?)events[0]["config"]==model+".json" &&
                (string?)events[0]["cwd"]==exeFolder && (string?)events[0]["scale"]=="1", "quoted model/config paths and executable working directory reach the CLI intact");
            Check(!File.Exists(Path.Combine(exeFolder,"never-run")) && Directory.GetFiles(Path.Combine(s.DataDirectory,"piper-work")).Length==0,
                "speech is never evaluated by a shell and temporary WAV is cleaned");
            Mode("noisy"); await piper.SpeechAsync("Ahoj",CancellationToken.None);
            Check(true,"large stdout/stderr are drained without deadlock or raw logging");
            Mode("fail"); await Error(()=>piper.SpeechAsync("Ahoj",CancellationToken.None),502,"nonzero exit returns a safe voice error");
            Mode("invalid"); await Error(()=>piper.SpeechAsync("Ahoj",CancellationToken.None),502,"invalid WAV is rejected");
            Mode("large"); await Error(()=>piper.SpeechAsync("Ahoj",CancellationToken.None),413,"oversized WAV is rejected");
            Mode("slow"); using (var cancelled=new CancellationTokenSource(200))
                await Error(()=>piper.SpeechAsync("Ahoj",cancelled.Token),504,"cancellation kills blocked Piper and retains text semantics");
            int pid=(int)JObject.Parse(File.ReadAllLines(Path.Combine(exeFolder,"events.jsonl")).Last())["pid"]!;
            bool alive; try { alive=!Process.GetProcessById(pid).HasExited; } catch (ArgumentException) { alive=false; }
            Check(!alive,"cancelled process is no longer running");
            s.PiperTimeoutSeconds=1;
            await Error(()=>piper.SpeechAsync("Ahoj",CancellationToken.None),504,"local timeout stops a stalled process");
            s.PiperTimeoutSeconds=60; Mode("ok");
            File.WriteAllText(Path.Combine(exeFolder,"events.jsonl"),"");
            await Task.WhenAll(piper.SpeechAsync("první",CancellationToken.None),piper.SpeechAsync("druhý",CancellationToken.None));
            events=File.ReadAllLines(Path.Combine(exeFolder,"events.jsonl")).Select(JObject.Parse).ToArray();
            Check(events.Select(e=>(string?)e["kind"]).SequenceEqual(new[]{"start","end","start","end"}),
                "concurrent jobs serialize model loads and worker survives cancellation/timeout");
            File.Move(model+".json",model+".backup");
            await Error(()=>piper.SpeechAsync("Ahoj",CancellationToken.None),503,"missing model config has a clear configuration error");
            File.Move(model+".backup",model+".json");
            var google=new GoogleStub(); var routed=new ConfiguredAiProvider(s,google,piper);
            var ask=new AskRequest { SourceRefId="123",Question="Ahoj" };
            await routed.TextAsync(ask,Array.Empty<Turn>(),CancellationToken.None);
            await routed.SpeechAsync("Ahoj",ask,CancellationToken.None);
            Check(google.Texts==1 && google.Voices==0,"Piper mode keeps Gemini text and never calls Gemini TTS");
            Mode("fail"); await Error(()=>routed.SpeechAsync("Ahoj",ask,CancellationToken.None),502,"local failure never falls back to Google TTS");
            Check(google.Voices==0,"failure still incurs no Gemini TTS call");
            using (var jobs=new JobService(s,routed,new ConversationStore(s),new AudioStore(s)))
            {
                var failed=await Finished(jobs,jobs.Submit(ask));
                Check((string?)failed["state"]=="done" && (string?)failed["text"]!=null &&
                    (string?)failed["voice_error"]!=null && (string?)failed["audio_url"]==null,
                    "failed local speech preserves completed text and memory");
                Mode("ok"); int texts=google.Texts;
                var test=await Finished(jobs,jobs.PiperTest(new AskRequest{SourceRefId="123"}));
                Check((string?)test["state"]=="done" && (string?)test["audio_url"]!=null && google.Texts==texts && google.Voices==0,
                    "Piper diagnostic creates playable guarded WAV with no Google text or TTS request");
            }
            s.SpeechProvider="Gemini";
            await routed.SpeechAsync("Ahoj",ask,CancellationToken.None);
            Check(google.Voices==1,"explicit Gemini mode remains available");
            s.PiperExecutable=Path.Combine(root,"missing");
            await Error(()=>piper.SpeechAsync("Ahoj",CancellationToken.None),503,"missing executable reports which setting to fix");
            Check(Directory.GetFiles(Path.Combine(s.DataDirectory,"piper-work")).Length==0,"success/error/cancel paths leave no temporary speech WAVs");
            Console.WriteLine($"\n{count} Piper process checks passed; Python CLI fixture, not real neural synthesis. No Google calls.");
        }
        finally { try { Directory.Delete(root,true); } catch { } }
    }
}
