using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using Newtonsoft.Json;

namespace ScriptedScreensLiteGeminiAI;

public static class TextLimits
{
    public static string Cut(string value, int max)
    {
        if (value.Length <= max) return value;
        int length = max;
        if (length > 0 && char.IsHighSurrogate(value[length - 1])) length--;
        return value.Substring(0, length);
    }
    public static List<Turn> Context(IEnumerable<Turn> turns, int byteBudget)
    {
        var result = new List<Turn>();
        foreach (var turn in turns.Reverse())
        {
            int size = Encoding.UTF8.GetByteCount(turn.Question) + Encoding.UTF8.GetByteCount(turn.Reply);
            if (size > byteBudget) break; // Send a contiguous recent history, never disconnected old turns.
            byteBudget -= size;
            result.Insert(0, new Turn { Question = turn.Question, Reply = turn.Reply });
        }
        return result;
    }
    internal static string Hash(string value)
    {
        using var sha = SHA256.Create();
        return string.Concat(sha.ComputeHash(Encoding.UTF8.GetBytes(value)).Select(b => b.ToString("x2")));
    }
}

public sealed class ConversationStore
{
    private sealed class Entry
    {
        internal Conversation Data = new Conversation();
        internal bool Busy;
    }
    private readonly object gate = new object();
    private readonly Dictionary<string, Entry> entries = new Dictionary<string, Entry>(StringComparer.Ordinal);
    private readonly Settings settings;
    private readonly string directory;

    public ConversationStore(Settings settings)
    {
        this.settings = settings;
        directory = Path.Combine(settings.DataDirectory, "worlds", TextLimits.Hash(settings.WorldId), "conversations");
        Directory.CreateDirectory(directory);
        // Recover a complete previous snapshot after an interrupted portable rename.
        foreach (string backup in Directory.GetFiles(directory, "*.json.bak"))
        {
            string destination = backup.Substring(0, backup.Length - 4);
            if (!File.Exists(destination))
            {
                try { File.Move(backup, destination); }
                catch { throw new AiException(500, "Conversation backup recovery failed. Check memory-folder permissions."); }
            }
        }
        var files = Directory.GetFiles(directory, "*.json");
        if (files.Length > settings.MaxConversations)
            throw new AiException(500, "Existing memory exceeds MaxConversations. Raise the limit before starting.");
        foreach (string file in files)
        {
            try
            {
                if (new FileInfo(file).Length > 2 * 1024 * 1024) throw new InvalidDataException();
                var conversation = JsonConvert.DeserializeObject<Conversation>(File.ReadAllText(file, Encoding.UTF8));
                if (conversation == null || conversation.Id == null ||
                    !Regex.IsMatch(conversation.Id, "^[a-zA-Z0-9][a-zA-Z0-9_.:-]{0,63}$") ||
                    conversation.Turns == null || conversation.Turns.Count > 50 ||
                    Path.GetFileNameWithoutExtension(file) != TextLimits.Hash(conversation.Id) ||
                    conversation.Turns.Any(t => t == null || t.Question == null || t.Reply == null ||
                                                t.Question.Length > 8000 || t.Reply.Length > 16000))
                    throw new InvalidDataException();
                conversation.Turns = conversation.Turns.Skip(Math.Max(0, conversation.Turns.Count - settings.HistoryTurns)).ToList();
                entries.Add(conversation.Id, new Entry { Data = conversation });
            }
            catch { throw new AiException(500, "A conversation file is invalid. Restore it from backup or move it out of the conversations folder."); }
        }
    }
    public Lease Reserve(string id)
    {
        lock (gate)
        {
            bool created = false;
            if (!entries.TryGetValue(id, out var entry))
            {
                if (entries.Count >= settings.MaxConversations)
                    throw new AiException(409, "Conversation memory is full. Delete a conversation or use remember=false.");
                entry = new Entry { Data = new Conversation { Id = id } };
                entries.Add(id, entry);
                created = true;
            }
            if (entry.Busy) throw new AiException(409, "This conversation already has a pending request.");
            entry.Busy = true;
            return new Lease(this, id, TextLimits.Context(entry.Data.Turns, settings.ContextUtf8Bytes), created);
        }
    }
    public object[] List()
    {
        lock (gate) return entries.Select(p => (object)new { id = p.Key, turns = p.Value.Data.Turns.Count, busy = p.Value.Busy }).ToArray();
    }
    public void TestDisk()
    {
        lock (gate)
        {
            // Same folder/hash-length/portable overwrite as a real conversation, not a chat file.
            string path=Path.Combine(directory, TextLimits.Hash(Guid.NewGuid().ToString("N")) + ".probe");
            try
            {
                PortableJsonFile.Write(path,"first");
                PortableJsonFile.Write(path,"second");
                if (File.ReadAllText(path,Encoding.UTF8)!="second") throw new AiException(500,"Memory disk verification failed.");
            }
            finally
            {
                try { File.Delete(path); } catch { }
                try { File.Delete(path+".bak"); } catch { }
            }
        }
    }
    public void Delete(string id)
    {
        lock (gate)
        {
            if (!entries.TryGetValue(id, out var entry)) return;
            if (entry.Busy) throw new AiException(409, "Cannot delete a conversation with a pending request.");
            try
            {
                string path = Path.Combine(directory, TextLimits.Hash(id) + ".json");
                File.Delete(path + ".bak");
                File.Delete(path);
            }
            catch { throw new AiException(500, "Conversation could not be deleted from disk."); }
            entries.Remove(id);
        }
    }
    private void Append(string id, string question, string reply)
    {
        lock (gate)
        {
            var entry = entries[id];
            var turns = entry.Data.Turns.Concat(new[] { new Turn { Question = question, Reply = reply } }).ToList();
            turns = turns.Skip(Math.Max(0, turns.Count - settings.HistoryTurns)).ToList();
            var updated = new Conversation { Id = id, Turns = turns };
            // Keep context usable in this session even if the disk becomes unwritable.
            entry.Data = updated;
            string path = Path.Combine(directory, TextLimits.Hash(id) + ".json");
            try { PortableJsonFile.Write(path, JsonConvert.SerializeObject(updated)); }
            catch (Exception ex)
            {
                if (ex is AiException) throw;
                string code = ex is PathTooLongException ? "memory_path_too_long" : ex is UnauthorizedAccessException ? "memory_access_denied" :
                    ex is IOException ? "memory_io_error" :
                    ex is NotSupportedException || ex is MissingMethodException ? "memory_runtime_not_supported" :
                    ex is JsonException ? "memory_json_error" : "memory_write_error";
                throw new AiException(500, "Text is ready; context is kept in RAM but could not be saved (" + code + ").");
            }
        }
    }
    public sealed class Lease : IDisposable
    {
        private ConversationStore? owner;
        private readonly string id;
        private readonly bool created;
        public IReadOnlyList<Turn> Context { get; }
        internal Lease(ConversationStore owner, string id, List<Turn> context, bool created)
        { this.owner = owner; this.id = id; this.created = created; Context = context; }
        public void Append(string question, string reply) => owner!.Append(id, question, reply);
        public void Dispose()
        {
            var store = owner;
            if (store == null) return;
            owner = null;
            lock (store.gate)
            {
                var entry = store.entries[id];
                entry.Busy = false;
                if (created && entry.Data.Turns.Count == 0) store.entries.Remove(id);
            }
        }
    }
}

/// <summary>Portable closed-stream rename; avoids Mono Flush(bool)/File.Replace differences.</summary>
public static class PortableJsonFile
{
    internal static string TemporaryPath(string path) => Path.Combine(Path.GetDirectoryName(path)!,
        "g" + Guid.NewGuid().ToString("N").Substring(0, 12) + ".tmp");
    public static void Write(string path, string json)
    {
        // The old <64-char hash>.json.<32-char GUID>.tmp can exceed MAX_PATH on Windows
        // even when the final JSON path is valid. Keep a unique, short sibling instead.
        string folder = Path.GetDirectoryName(path)!;
        string temporary = TemporaryPath(path);
        string backup = path + ".bak";
        string stage = "create_directory";
        try
        {
            Directory.CreateDirectory(folder);
            byte[] bytes = Encoding.UTF8.GetBytes(json);
            stage = "write_temporary";
            using (var stream = new FileStream(temporary, FileMode.CreateNew, FileAccess.Write, FileShare.None))
            {
                stream.Write(bytes, 0, bytes.Length);
                stream.Flush();
            }
            stage = "recover_backup";
            if (File.Exists(backup))
            {
                if (!File.Exists(path)) File.Move(backup, path);
                else File.Delete(backup);
            }
            stage = "backup_previous";
            if (File.Exists(path)) File.Move(path, backup);
            stage = "commit_snapshot";
            try { File.Move(temporary, path); }
            catch
            {
                if (!File.Exists(path) && File.Exists(backup)) File.Move(backup, path);
                throw;
            }
            // A failed backup deletion is harmless; startup prefers the newer complete JSON.
            try { File.Delete(backup); } catch { }
        }
        catch (Exception ex)
        {
            string code = ex is PathTooLongException ? "memory_path_too_long" :
                ex is UnauthorizedAccessException ? "memory_access_denied" :
                ex is IOException ? "memory_io_error" : "memory_write_error";
            // No exception message/path/chat is disclosed; numeric HRESULT helps diagnose Mono IO.
            throw new AiException(500, "Context is kept in RAM; disk save failed (" + code +
                ", stage=" + stage + ", hresult=" + ex.HResult.ToString("X8") +
                ", path_chars=" + path.Length + ").");
        }
        finally { try { File.Delete(temporary); } catch { } }
    }
}

public sealed class AudioFile
{
    public string Path { get; set; } = "";
    public string Url { get; set; } = "";
    public double DurationSeconds { get; set; }
    public DateTime ExpiresUtc { get; set; }
}
public sealed class AudioStore
{
    private sealed class ClipState
    {
        internal DateTime ProtectedUntil;
        internal int Downloads;
        internal double Duration;
        internal long Sequence;
    }
    private readonly object gate = new object();
    private readonly Settings settings;
    private readonly string directory;
    private readonly Func<DateTime> clock;
    private readonly Dictionary<string, ClipState> clips = new Dictionary<string, ClipState>();
    private long sequence;
    private int reservations;
    // Covers job polling / client loading. Active downloads extend this through clip duration.
    private const int DeliveryGraceSeconds = 15;
    public AudioStore(Settings settings, Func<DateTime>? clock = null)
    {
        this.settings = settings;
        this.clock = clock ?? (() => DateTime.UtcNow);
        directory = Path.Combine(settings.DataDirectory, "audio");
        Directory.CreateDirectory(directory);
        foreach (string file in Directory.GetFiles(directory, "*.wav").OrderBy(File.GetLastWriteTimeUtc))
        {
            string name = Path.GetFileName(file);
            if (!Regex.IsMatch(name, "^[a-f0-9]{32}\\.wav$")) continue;
            double duration = 0;
            try
            {
                if (new FileInfo(file).Length <= settings.MaxAudioFileMegabytes * 1024L * 1024)
                    duration = WaveAudio.DurationSeconds(File.ReadAllBytes(file));
            }
            catch { /* Old malformed files stay unavailable rather than crashing the bridge. */ }
            clips[name] = new ClipState { Duration = duration, Sequence = ++sequence };
        }
        Cleanup();
    }
    private bool Protected(ClipState clip) => clip.Downloads > 0 || clip.ProtectedUntil > clock();
    private bool Delete(string name)
    {
        try { File.Delete(Path.Combine(directory, name)); clips.Remove(name); return true; }
        catch { return false; }
    }
    private void Trim(int target)
    {
        foreach (string name in clips.OrderBy(p => p.Value.Sequence).Select(p => p.Key).ToArray())
        {
            if (clips.Count <= target) break;
            if (!Protected(clips[name])) Delete(name);
        }
    }
    public void Cleanup()
    {
        lock (gate)
        {
            foreach (string name in clips.Keys.ToArray())
            {
                string path = Path.Combine(directory, name);
                if (!File.Exists(path)) { clips.Remove(name); continue; }
                if (File.GetLastWriteTimeUtc(path).AddSeconds(settings.AudioTtlSeconds) <= clock() && !Protected(clips[name]))
                    Delete(name);
            }
            Trim(settings.MaxAudioFiles);
        }
    }
    public GenerationSlot? TryReserve()
    {
        lock (gate)
        {
            Cleanup();
            if (settings.MaxAudioFiles - clips.Values.Count(Protected) - reservations <= 0) return null;
            reservations++;
            return new GenerationSlot(this);
        }
    }
    public sealed class GenerationSlot : IDisposable
    {
        internal readonly AudioStore Owner;
        internal bool Released;
        internal GenerationSlot(AudioStore owner) { Owner=owner; }
        public void Dispose()
        {
            lock (Owner.gate)
            {
                if (Released) return;
                Released=true; Owner.reservations--;
            }
        }
    }
    public AudioFile Save(byte[] wav, GenerationSlot? reservation = null)
    {
        lock (gate)
        {
            double duration = WaveAudio.DurationSeconds(wav);
            if (reservation != null && (reservation.Owner != this || reservation.Released))
                throw new AiException(409,"Audio slot reservation is no longer valid.");
            Cleanup();
            if (wav.Length > settings.MaxAudioFileMegabytes * 1024L * 1024) throw new AiException(413, "Generated audio exceeds the file limit.");
            int otherReservations=reservations-(reservation != null ? 1 : 0);
            Trim(settings.MaxAudioFiles - otherReservations - 1);
            if (clips.Count >= settings.MaxAudioFiles - otherReservations)
                throw new AiException(507, "All retained audio files are still protected for playback; wait before generating another voice.");
            long used = clips.Keys.Sum(n => new FileInfo(Path.Combine(directory, n)).Length);
            if (used + wav.Length > settings.MaxAudioMegabytes * 1024L * 1024)
                throw new AiException(507, "Audio cache is full; text remains available.");
            string name = Guid.NewGuid().ToString("N") + ".wav";
            string path = Path.Combine(directory, name);
            try { File.WriteAllBytes(path, wav); }
            catch { try { File.Delete(path); } catch { } throw; }
            if (reservation != null) { reservation.Released=true; reservations--; }
            clips[name] = new ClipState { Duration = duration, Sequence = ++sequence,
                ProtectedUntil = clock().AddSeconds(DeliveryGraceSeconds) };
            DateTime expiry = File.GetLastWriteTimeUtc(path).AddSeconds(settings.AudioTtlSeconds);
            return new AudioFile { Path = path, Url = settings.PublicMediaBaseUrl.TrimEnd('/') + "/audio/" + name,
                ExpiresUtc = expiry, DurationSeconds = duration };
        }
    }
    public Stream Open(string name)
    {
        lock (gate)
        {
            if (!Regex.IsMatch(name, "^[a-f0-9]{32}\\.wav$") || !clips.TryGetValue(name, out var state))
                throw new AiException(404, "Audio not found.");
            string path = Path.Combine(directory, name);
            if (!File.Exists(path) || File.GetLastWriteTimeUtc(path).AddSeconds(settings.AudioTtlSeconds) <= clock() || state.Duration <= 0)
                throw new AiException(404, "Audio not found or expired.");
            var file = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read);
            state.Downloads++;
            state.ProtectedUntil = clock().AddSeconds(state.Duration + DeliveryGraceSeconds);
            return new DownloadStream(file, () => {
                lock (gate)
                {
                    state.Downloads--;
                    state.ProtectedUntil = clock().AddSeconds(state.Duration + DeliveryGraceSeconds);
                }
            });
        }
    }
    private sealed class DownloadStream : Stream
    {
        private readonly FileStream inner;
        private Action? release;
        internal DownloadStream(FileStream inner, Action release) { this.inner = inner; this.release = release; }
        public override bool CanRead => inner.CanRead;
        public override bool CanWrite => false;
        public override bool CanSeek => inner.CanSeek;
        public override long Length => inner.Length;
        public override long Position { get => inner.Position; set => inner.Position = value; }
        public override void Flush() => inner.Flush();
        public override int Read(byte[] buffer, int offset, int count) => inner.Read(buffer, offset, count);
        public override long Seek(long offset, SeekOrigin origin) => inner.Seek(offset, origin);
        public override void SetLength(long value) => throw new NotSupportedException();
        public override void Write(byte[] buffer, int offset, int count) => throw new NotSupportedException();
        protected override void Dispose(bool disposing)
        {
            if (disposing && release != null)
            {
                var done = release; release = null;
                try { inner.Dispose(); } finally { done(); }
            }
            base.Dispose(disposing);
        }
    }
}

public static class WaveAudio
{
    public const double GuardSilenceSeconds = 2;
    public static byte[] ThreeToneTest()
    {
        const int rate = 24000;
        var pcm = new byte[rate * 3 * 2];
        for (int i = 0; i < rate * 3; i++)
        {
            double second = i / (double)rate;
            double withinTone = second - Math.Floor(second);
            short sample = withinTone < 0.2 ? (short)(5000 * Math.Sin(2 * Math.PI * 660 * second)) : (short)0;
            pcm[i * 2] = (byte)(sample & 255); pcm[i * 2 + 1] = (byte)((sample >> 8) & 255);
        }
        return WithGuardSilence(FromPcm16(pcm, rate));
    }
    public static byte[] WithGuardSilence(byte[] wav)
    {
        ValidateWav(wav);
        int rate = 0, offset = 12;
        using var samples = new MemoryStream();
        while (offset <= wav.Length - 8)
        {
            string chunk = Encoding.ASCII.GetString(wav, offset, 4);
            int size = checked((int)BitConverter.ToUInt32(wav, offset + 4));
            if (chunk == "fmt ") rate = checked((int)BitConverter.ToUInt32(wav, offset + 12));
            if (chunk == "data") samples.Write(wav, offset + 8, size);
            offset += 8 + size + size % 2;
        }
        // Canonical PCM WAV strips any optional playback/loop metadata too.
        samples.Write(new byte[checked((int)(rate * 2 * GuardSilenceSeconds))], 0,
            checked((int)(rate * 2 * GuardSilenceSeconds)));
        return FromPcm16(samples.ToArray(), rate);
    }
    public static byte[] FromPcm16(byte[] pcm, int rate = 24000)
    {
        if (pcm.Length == 0 || pcm.Length % 2 != 0 || rate < 8000 || rate > 48000)
            throw new AiException(502, "TTS returned invalid PCM audio.");
        using var stream = new MemoryStream();
        using var writer = new BinaryWriter(stream, Encoding.ASCII, true);
        writer.Write(Encoding.ASCII.GetBytes("RIFF")); writer.Write(pcm.Length + 36);
        writer.Write(Encoding.ASCII.GetBytes("WAVEfmt ")); writer.Write(16);
        writer.Write((short)1); writer.Write((short)1); writer.Write(rate); writer.Write(rate * 2);
        writer.Write((short)2); writer.Write((short)16);
        writer.Write(Encoding.ASCII.GetBytes("data")); writer.Write(pcm.Length); writer.Write(pcm);
        return stream.ToArray();
    }
    public static double DurationSeconds(byte[] wav)
    {
        ValidateWav(wav);
        int offset = 12;
        uint rate = 0;
        long samples = 0;
        while (offset <= wav.Length - 8)
        {
            string chunk = Encoding.ASCII.GetString(wav, offset, 4);
            int size = checked((int)BitConverter.ToUInt32(wav, offset + 4));
            if (chunk == "fmt ") rate = BitConverter.ToUInt32(wav, offset + 12);
            if (chunk == "data") samples += size / 2;
            offset += 8 + size + (size % 2);
        }
        return samples / (double)rate;
    }
    public static byte[] ValidateWav(byte[] wav)
    {
        if (wav.Length < 44 || Encoding.ASCII.GetString(wav, 0, 4) != "RIFF" || Encoding.ASCII.GetString(wav, 8, 4) != "WAVE")
            throw new AiException(502, "TTS returned invalid WAV audio.");
        bool format = false, data = false;
        int offset = 12;
        while (offset <= wav.Length - 8)
        {
            string chunk = Encoding.ASCII.GetString(wav, offset, 4);
            uint size = BitConverter.ToUInt32(wav, offset + 4);
            if (size > wav.Length - offset - 8) throw new AiException(502, "TTS returned truncated WAV audio.");
            if (chunk == "fmt ")
            {
                if (size < 16 || BitConverter.ToUInt16(wav, offset + 8) != 1 ||
                    BitConverter.ToUInt16(wav, offset + 10) != 1 || BitConverter.ToUInt16(wav, offset + 22) != 16)
                    throw new AiException(502, "TTS must return mono PCM16 WAV.");
                uint rate = BitConverter.ToUInt32(wav, offset + 12);
                if (rate < 8000 || rate > 48000) throw new AiException(502, "Unsupported WAV sample rate.");
                format = true;
            }
            if (chunk == "data") data = size > 0 && size % 2 == 0;
            offset += 8 + (int)size + ((int)size % 2);
        }
        if (!format || !data) throw new AiException(502, "WAV format or samples missing.");
        return wav;
    }
}
