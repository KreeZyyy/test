using System;
using System.IO;
using BepInEx;
using BepInEx.Configuration;
using BepInEx.Logging;
using StationeersMods.Interface;

namespace ScriptedScreensLiteGeminiAI;

[StationeersMod(Guid, "ScriptedScreensLiteGeminiAI", Version)]
public sealed class Plugin : ModBehaviour
{
    public const string Guid = "oasis.stationeers.scriptedscreenslitegeminiai";
    public const string Version = "0.1.3";
    private static Plugin? active;
    private ManualLogSource? log;
    private ApiHost? host;
    private JobService? jobs;
    private GeminiClient? gemini;

    public override void OnLoaded(ContentHandler contentHandler)
    {
        base.OnLoaded(contentHandler);
        if (active != null) return;
        active = this;
        log = new ManualLogSource("ScriptedScreensLiteGeminiAI");
        try
        {
            Logger.Sources.Add(log);
            if (Config == null) throw new AiException(500, "LaunchPad did not provide a configuration.");
            if (!Bind(Config, "General", "Enabled", true, "Run the AI bridge on this machine. Install/enable on the session host or dedicated server.")) return;
            var settings = Load(Config);
            settings.Validate();
            Directory.CreateDirectory(settings.DataDirectory);
            var memory = new ConversationStore(settings);
            var audio = new AudioStore(settings);
            gemini = new GeminiClient(settings);
            jobs = new JobService(settings, new ConfiguredAiProvider(settings,gemini), memory, audio);
            host = new ApiHost(settings, jobs, audio);
            log.LogInfo("ScriptedScreensLiteGeminiAI 0.1.3 started. Configure Gemini.ApiKey and copy only Bridge.Token into Lua. Audio playback belongs to ScriptedScreens.");
            if (settings.WorldId == "default") log.LogInfo("Memory.WorldId is default. Choose a unique WorldId before using a different save.");
        }
        catch (Exception ex)
        {
            log.LogError(ex is AiException safe ? safe.Message : "AI bridge could not start. Check ports, data-folder permissions and the configuration. No credentials were logged.");
            Shutdown();
        }
    }
    private static T Bind<T>(ConfigFile config, string section, string key, T fallback, string description) => config.Bind(section, key, fallback, description).Value;
    private static Settings Load(ConfigFile c)
    {
        var s = new Settings();
        s.ApiKey = Bind(c, "Gemini", "ApiKey", "", "Your Google AI Studio API key. Never put it in Lua or share this config.");
        s.TextModel = Bind(c, "Gemini", "TextModel", s.TextModel, "Text model available to your key. Change config without rebuilding the DLL.");
        s.SystemPrompt = Bind(c, "Gemini", "SystemPrompt", s.SystemPrompt, "Default personality. Lua may supply system_prompt per request.");
        s.AllowLuaModelOverrides = Bind(c, "Gemini", "AllowLuaModelOverrides", false, "Allow scripts to select other Gemini text/TTS models. Off by default to limit costs.");
        s.EnableTts = Bind(c, "Speech", "Enabled", true, "Generate WAV with the selected provider when Lua requests speak=true. Playback belongs to ScriptedScreens.");
        s.SpeechProvider = Bind(c,"Speech","Provider","Gemini","Gemini (online TTS) or Piper (local external CLI). No automatic provider fallback.").Trim();
        string desktop=Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
        string piperFolder=desktop.Length>0 ? Path.Combine(desktop,"piper") : Path.Combine(Paths.ConfigPath,"..","piper");
        string piperName=Environment.OSVersion.Platform==PlatformID.Win32NT ? "piper.exe" : "piper";
        s.PiperExecutable=Bind(c,"Speech","PiperExecutable",Path.Combine(piperFolder,piperName),"Absolute path to trusted Piper CLI. Keep its DLLs/espeak-ng-data together. Only the host runs Piper.");
        s.PiperModel=Bind(c,"Speech","PiperModel",Path.Combine(piperFolder,"voices","cs_CZ-jirka-medium.onnx"),"Absolute ONNX model path. Matching .onnx.json must be beside it. Never supplied by Lua.");
        s.PiperTimeoutSeconds=Bind(c,"Speech","PiperTimeoutSeconds",60,"5..180 seconds for queued local speech/process execution. Timeout stops Piper and retains text.");
        s.PiperLengthScale=Bind(c,"Speech","PiperLengthScale",1.0,"Local speech speed: 0.5..2. Lower is faster. Piper voice/style are determined by this model, not Gemini voice preferences.");
        s.TtsModel = Bind(c, "Speech", "Model", s.TtsModel, "Gemini TTS model. Availability/quota/billing depend on your Google project.");
        s.TtsApi = Bind(c, "Speech", "Api", "interactions", "interactions for Gemini 3.8 TTS; generateContent for supported older TTS models.");
        s.Voice = Bind(c, "Speech", "Voice", s.Voice, "Default prebuilt voice, e.g. Kore, Charon, Puck.");
        s.SpeechStyle = Bind(c, "Speech", "Style", s.SpeechStyle, "Default speech style/language. Lua may override speech_style.");
        string allowed = Bind(c, "Speech", "AllowedVoices", string.Join(",", s.AllowedVoices), "Comma-separated voices scripts may request. Include the default Voice.");
        s.AllowedVoices.Clear();
        foreach (string voice in allowed.Split(',')) if (!string.IsNullOrWhiteSpace(voice)) s.AllowedVoices.Add(voice.Trim());
        s.BridgeToken = Bind(c, "Bridge", "Token", System.Guid.NewGuid().ToString("N") + System.Guid.NewGuid().ToString("N"), "LOCAL bridge authentication. Copy only this token into Lua; all holders share AI/memory permissions.");
        s.ApiPort = Bind(c, "Bridge", "Port", 18766, "Localhost-only control API. Match this in Lua. Restart after changes.");
        s.MediaPort = Bind(c, "Media", "Port", 18767, "Read-only audio HTTP port. In multiplayer expose only this port to players.");
        s.MediaBindAddress = Bind(c, "Media", "BindAddress", "127.0.0.1", "127.0.0.1 for singleplayer; 0.0.0.0 or a LAN interface for multiplayer.");
        s.PublicMediaBaseUrl = Bind(c, "Media", "PublicBaseUrl", "http://localhost:18767", "Base URL reachable by EVERY player. Multiplayer must use the host/server LAN or public address, not localhost. Optional HTTPS reverse proxy.");
        string defaultData = Path.GetFullPath(Path.Combine(Paths.ConfigPath, "..", "ScriptedScreensLiteGeminiAI-data"));
        s.DataDirectory = Path.GetFullPath(Bind(c, "Memory", "DataDirectory", defaultData, "Writable folder outside the mod installation. Holds plain-text chat histories and temporary audio."));
        s.WorldId = Bind(c, "Memory", "WorldId", "default", "Unique namespace for this save. Set it manually per world; v0.1 does not hook save-game changes. Restart after changes.");
        s.MaxConversations = Bind(c, "Limits", "MaxConversations", s.MaxConversations, "1..100 stored conversations in this WorldId; never silently evicts history.");
        s.HistoryTurns = Bind(c, "Limits", "HistoryTurns", s.HistoryTurns, "1..50 question/answer pairs saved per conversation.");
        s.ContextUtf8Bytes = Bind(c, "Limits", "ContextUtf8Bytes", s.ContextUtf8Bytes, "1000..64000 UTF-8 bytes of recent history sent with each request (not a token count).");
        s.MaxQuestionChars = Bind(c, "Limits", "MaxQuestionChars", s.MaxQuestionChars, "Maximum question length (UTF-16 characters).");
        s.MaxReplyChars = Bind(c, "Limits", "MaxReplyChars", s.MaxReplyChars, "Maximum stored/displayed reply length.");
        s.MaxInstructionChars = Bind(c, "Limits", "MaxInstructionChars", s.MaxInstructionChars, "Maximum Lua system_prompt length.");
        s.MaxOutputTokens = Bind(c, "Limits", "MaxOutputTokens", s.MaxOutputTokens, "Server maximum output token setting; Lua may only reduce it.");
        s.MaxSpeechChars = Bind(c, "Limits", "MaxSpeechChars", s.MaxSpeechChars, "Longer replies remain text-only, with voice_error. No silent truncation of spoken replies.");
        s.MaxConcurrent = Bind(c, "Limits", "MaxConcurrent", s.MaxConcurrent, "1..4 simultaneous AI jobs.");
        s.MaxPending = Bind(c, "Limits", "MaxPending", s.MaxPending, "Maximum queued plus running jobs.");
        s.MaxJobs = Bind(c, "Limits", "MaxJobs", s.MaxJobs, "Maximum retained job records, including completed results.");
        s.RequestsPerMinute = Bind(c, "Limits", "RequestsPerMinute", s.RequestsPerMinute, "Shared limit across scripts. A voiced job normally uses two Google requests.");
        s.CooldownSeconds = Bind(c, "Limits", "CooldownSeconds", s.CooldownSeconds, "Minimum seconds between accepted requests from the same source_ref_id.");
        s.JobTtlSeconds = Bind(c, "Limits", "JobTtlSeconds", s.JobTtlSeconds, "Completed job retention, 120..3600 seconds.");
        s.AudioTtlSeconds = Bind(c, "Limits", "AudioTtlSeconds", s.AudioTtlSeconds, "Audio expiry, 120..86400 seconds. Expired WAVs are periodically deleted.");
        s.MaxAudioMegabytes = Bind(c, "Limits", "MaxAudioMegabytes", s.MaxAudioMegabytes, "Maximum total audio cache in MiB.");
        s.MaxAudioFileMegabytes = Bind(c, "Limits", "MaxAudioFileMegabytes", s.MaxAudioFileMegabytes, "Maximum single audio file in MiB.");
        s.MaxAudioFiles = Bind(c, "Limits", "MaxAudioFiles", s.MaxAudioFiles, "Retain at most 5 WAV files by default (1..50). Delete oldest unprotected files. Text remains available when all slots are protected.");
        s.RequestTimeoutSeconds = Bind(c, "Limits", "RequestTimeoutSeconds", s.RequestTimeoutSeconds, "10..180 seconds per Google request. No automatic paid retries.");
        c.Save();
        return s;
    }
    private void Shutdown()
    {
        host?.Dispose(); host = null;
        jobs?.Dispose(); jobs = null;
        gemini?.Dispose(); gemini = null;
    }
    private void OnDestroy()
    {
        if (active != this) return;
        Shutdown(); active = null;
        if (log != null) { Logger.Sources.Remove(log); log.Dispose(); }
    }
}
