using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace ScriptedScreensLiteGeminiAI;

public sealed class HttpRequest
{
    public string Method { get; set; } = "";
    public string Path { get; set; } = "";
    public Dictionary<string, string> Headers { get; } = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
    public byte[] Body { get; set; } = Array.Empty<byte>();
    public T Json<T>() where T : class
    {
        try
        {
            var settings = new JsonSerializerSettings { MaxDepth = 12, TypeNameHandling = TypeNameHandling.None };
            return JsonConvert.DeserializeObject<T>(new UTF8Encoding(false, true).GetString(Body), settings) ?? throw new JsonException();
        }
        catch (Exception ex) when (ex is JsonException || ex is DecoderFallbackException)
        { throw new AiException(400, "Invalid JSON body."); }
    }
}
public sealed class HttpResponse : IDisposable
{
    public int Status = 200;
    public string ContentType = "application/json; charset=utf-8";
    public Dictionary<string, string> Headers = new Dictionary<string, string>();
    public byte[] Body = Array.Empty<byte>();
    public Stream? Stream;
    public long Offset;
    public long? Length;
    public static HttpResponse Json(object value, int status = 200) => new HttpResponse {
        Status = status, Body = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(value))
    };
    public void Dispose() => Stream?.Dispose();
}

/// <summary>Small HTTP/1.1 listener. One bounded request per connection; no Unity work on worker threads.</summary>
public sealed class HttpServer : IDisposable
{
    private readonly TcpListener listener;
    private readonly Func<HttpRequest, HttpResponse> handler;
    private readonly CancellationTokenSource stop = new CancellationTokenSource();
    private readonly SemaphoreSlim slots = new SemaphoreSlim(32);
    private readonly object gate = new object();
    private readonly HashSet<TcpClient> clients = new HashSet<TcpClient>();
    private Task? acceptTask;
    public int Port => ((IPEndPoint)listener.LocalEndpoint).Port;
    public HttpServer(IPAddress address, int port, Func<HttpRequest, HttpResponse> handler)
    { listener = new TcpListener(address, port); this.handler = handler; }
    public void Start()
    {
        listener.Start(32);
        acceptTask = Task.Run(Accept);
    }
    private async Task Accept()
    {
        while (!stop.IsCancellationRequested)
        {
            TcpClient client;
            try { client = await listener.AcceptTcpClientAsync().ConfigureAwait(false); }
            catch (Exception ex) when (ex is SocketException || ex is ObjectDisposedException) { break; }
            if (!slots.Wait(0)) { client.Dispose(); continue; }
            lock (gate) clients.Add(client);
            _ = Task.Run(async () => {
                try { await Serve(client).ConfigureAwait(false); }
                catch { /* Socket/parse failure is contained. Never log request bodies or tokens. */ }
                finally { lock (gate) clients.Remove(client); client.Dispose(); slots.Release(); }
            });
        }
    }
    private async Task Serve(TcpClient client)
    {
        using var timeout = CancellationTokenSource.CreateLinkedTokenSource(stop.Token);
        timeout.CancelAfter(TimeSpan.FromSeconds(20));
        client.NoDelay = true;
        using var stream = client.GetStream();
        HttpRequest? request = null;
        HttpResponse response;
        try { request = await Read(stream, timeout.Token).ConfigureAwait(false); response = handler(request); }
        catch (AiException ex) { response = HttpResponse.Json(new { error = ex.Message }, ex.Status); }
        catch (OperationCanceledException) { return; }
        catch { response = HttpResponse.Json(new { error = "Request failed." }, 500); }
        using (response)
        {
            long length = response.Length ?? response.Body.LongLength;
            string reason = response.Status switch { 200 => "OK", 202 => "Accepted", 206 => "Partial Content", 400 => "Bad Request", 401 => "Unauthorized",
                404 => "Not Found", 405 => "Method Not Allowed", 409 => "Conflict", 413 => "Payload Too Large", 416 => "Range Not Satisfiable",
                429 => "Too Many Requests", 502 => "Bad Gateway", 503 => "Service Unavailable", 507 => "Insufficient Storage", _ => "Internal Server Error" };
            var header = new StringBuilder($"HTTP/1.1 {response.Status} {reason}\r\nContent-Type: {response.ContentType}\r\nContent-Length: {length}\r\nConnection: close\r\nX-Content-Type-Options: nosniff\r\n");
            foreach (var pair in response.Headers) header.Append(pair.Key).Append(": ").Append(pair.Value).Append("\r\n");
            header.Append("\r\n");
            byte[] head = Encoding.ASCII.GetBytes(header.ToString());
            await stream.WriteAsync(head, 0, head.Length, timeout.Token).ConfigureAwait(false);
            if (request?.Method == "HEAD") return;
            if (response.Stream == null)
                await stream.WriteAsync(response.Body, 0, response.Body.Length, timeout.Token).ConfigureAwait(false);
            else
            {
                response.Stream.Position = response.Offset;
                var buffer = new byte[16384];
                long remaining = length;
                while (remaining > 0)
                {
                    int read = await response.Stream.ReadAsync(buffer, 0, (int)Math.Min(buffer.Length, remaining), timeout.Token).ConfigureAwait(false);
                    if (read == 0) break;
                    await stream.WriteAsync(buffer, 0, read, timeout.Token).ConfigureAwait(false);
                    remaining -= read;
                }
            }
        }
    }
    private static async Task<HttpRequest> Read(Stream stream, CancellationToken cancellation)
    {
        var header = new List<byte>();
        var one = new byte[1];
        while (true)
        {
            if (header.Count >= 8192) throw new AiException(413, "HTTP headers are too large.");
            if (await stream.ReadAsync(one, 0, 1, cancellation).ConfigureAwait(false) != 1) throw new AiException(400, "Incomplete HTTP request.");
            header.Add(one[0]);
            int n = header.Count;
            if (n >= 4 && header[n-4] == 13 && header[n-3] == 10 && header[n-2] == 13 && header[n-1] == 10) break;
        }
        string[] lines = Encoding.ASCII.GetString(header.ToArray()).Split(new[] { "\r\n" }, StringSplitOptions.None);
        string[] start = lines[0].Split(' ');
        if (start.Length != 3 || (start[2] != "HTTP/1.1" && start[2] != "HTTP/1.0") || !start[1].StartsWith("/", StringComparison.Ordinal) || start[1].Length > 2048)
            throw new AiException(400, "Invalid HTTP request line.");
        var request = new HttpRequest { Method = start[0], Path = start[1] };
        for (int i = 1; i < lines.Length && lines[i] != ""; i++)
        {
            int colon = lines[i].IndexOf(':');
            if (colon <= 0 || lines[i][0] == ' ' || lines[i][0] == '\t') throw new AiException(400, "Invalid HTTP header.");
            string key = lines[i].Substring(0, colon);
            string value = lines[i].Substring(colon + 1).Trim();
            if (!System.Text.RegularExpressions.Regex.IsMatch(key, "^[a-zA-Z0-9-]+$") || request.Headers.ContainsKey(key))
                throw new AiException(400, "Invalid or duplicate HTTP header.");
            request.Headers.Add(key, value);
        }
        if (request.Headers.ContainsKey("Transfer-Encoding")) throw new AiException(400, "Chunked request bodies are not supported.");
        int length = 0;
        if (request.Headers.TryGetValue("Content-Length", out var raw) && (!int.TryParse(raw, NumberStyles.None, CultureInfo.InvariantCulture, out length) || length < 0))
            throw new AiException(400, "Invalid Content-Length.");
        if (length > 16384) throw new AiException(413, "Request body exceeds 16 KiB.");
        request.Body = new byte[length];
        int offset = 0;
        while (offset < length)
        {
            int read = await stream.ReadAsync(request.Body, offset, length - offset, cancellation).ConfigureAwait(false);
            if (read == 0) throw new AiException(400, "Incomplete request body.");
            offset += read;
        }
        return request;
    }
    public void Dispose()
    {
        stop.Cancel(); listener.Stop();
        lock (gate) foreach (var client in clients) client.Dispose();
        try { acceptTask?.Wait(1000); } catch { }
    }
}

public sealed class ApiHost : IDisposable
{
    private readonly Settings settings;
    private readonly JobService jobs;
    private readonly AudioStore audio;
    private readonly HttpServer api;
    private readonly HttpServer media;
    private readonly Timer cleanup;
    public ApiHost(Settings settings, JobService jobs, AudioStore audio)
    {
        this.settings = settings; this.jobs = jobs; this.audio = audio;
        api = new HttpServer(IPAddress.Loopback, settings.ApiPort, Api);
        media = new HttpServer(IPAddress.Parse(settings.MediaBindAddress), settings.MediaPort, Media);
        try { api.Start(); media.Start(); }
        catch { api.Dispose(); media.Dispose(); throw; }
        cleanup = new Timer(_ => { try { jobs.Cleanup(); audio.Cleanup(); } catch { } }, null, 60000, 60000);
    }
    public HttpResponse Api(HttpRequest request)
    {
        if (!request.Headers.TryGetValue("X-Station-Token", out var token) || !TokenEquals(token, settings.BridgeToken))
            throw new AiException(401, "Invalid bridge token.");
        if (request.Method == "GET" && request.Path == "/health")
            return HttpResponse.Json(new { status = "ok", version = "0.1.3", gemini_configured = !string.IsNullOrWhiteSpace(settings.ApiKey), tts_enabled = settings.EnableTts, speech_provider=settings.SpeechProvider });
        if (request.Method == "POST" && request.Path == "/ask")
        {
            if (string.IsNullOrWhiteSpace(settings.ApiKey)) throw new AiException(503, "Set Gemini.ApiKey in the host configuration.");
            string id = jobs.Submit(request.Json<AskRequest>());
            return HttpResponse.Json(new { id }, 202);
        }
        if (request.Method == "GET" && request.Path.StartsWith("/jobs/", StringComparison.Ordinal)) return HttpResponse.Json(jobs.Get(request.Path.Substring(6)));
        if (request.Method == "GET" && request.Path == "/conversations") return HttpResponse.Json(new { conversations = jobs.ListConversations() });
        if (request.Method == "POST" && request.Path == "/audio/test")
            return HttpResponse.Json(jobs.AudioTest(request.Json<AskRequest>()));
        if (request.Method == "POST" && request.Path == "/speech/test")
            return HttpResponse.Json(new { id=jobs.PiperTest(request.Json<AskRequest>()) },202);
        if (request.Method == "POST" && request.Path == "/memory/test")
        { jobs.TestMemoryDisk(); return HttpResponse.Json(new { status="ok" }); }
        if (request.Method == "POST" && request.Path == "/memory/reset")
        { jobs.Reset(request.Json<AskRequest>()); return HttpResponse.Json(new { status = "ok" }); }
        throw new AiException(404, "Endpoint not found.");
    }
    public HttpResponse Media(HttpRequest request)
    {
        if (request.Method != "GET" && request.Method != "HEAD") throw new AiException(405, "Media is read-only.");
        if (!request.Path.StartsWith("/audio/", StringComparison.Ordinal)) throw new AiException(404, "Audio not found.");
        var file = audio.Open(request.Path.Substring(7));
        long start = 0, end = file.Length - 1;
        bool partial = false;
        if (request.Headers.TryGetValue("Range", out var range))
        {
            var match = System.Text.RegularExpressions.Regex.Match(range, @"^bytes=(\d*)-(\d*)$");
            bool valid = match.Success;
            if (valid && match.Groups[1].Value == "")
            {
                valid = long.TryParse(match.Groups[2].Value, out var suffix) && suffix > 0;
                if (valid) start = Math.Max(0, file.Length - suffix);
            }
            else if (valid)
            {
                valid = long.TryParse(match.Groups[1].Value, out start);
                if (valid && match.Groups[2].Value != "") valid = long.TryParse(match.Groups[2].Value, out end);
                end = Math.Min(end, file.Length - 1);
            }
            if (!valid || start < 0 || start >= file.Length || end < start)
            {
                long length = file.Length; file.Dispose();
                var bad = HttpResponse.Json(new { error = "Invalid audio byte range." }, 416);
                bad.Headers["Content-Range"] = "bytes */" + length;
                return bad;
            }
            partial = true;
        }
        var result = new HttpResponse { Status = partial ? 206 : 200, ContentType = "audio/wav", Stream = file, Offset = start, Length = end - start + 1 };
        result.Headers["Accept-Ranges"] = "bytes";
        result.Headers["Cache-Control"] = "private, no-store";
        if (partial) result.Headers["Content-Range"] = $"bytes {start}-{end}/{file.Length}";
        return result;
    }
    private static bool TokenEquals(string input, string expected)
    {
        int difference = input.Length ^ expected.Length;
        for (int i = 0; i < expected.Length; i++) difference |= expected[i] ^ (i < input.Length ? input[i] : 0);
        return difference == 0;
    }
    public void Dispose() { cleanup.Dispose(); api.Dispose(); media.Dispose(); }
}
