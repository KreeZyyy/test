using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ScriptedScreensLiteGeminiAI;

/// <summary>Text stays on Gemini; speech uses exactly the administrator-selected provider.</summary>
public sealed class ConfiguredAiProvider : IAiProvider
{
    private readonly Settings settings;
    private readonly IAiProvider gemini;
    private readonly PiperClient piper;
    public ConfiguredAiProvider(Settings settings, IAiProvider gemini, PiperClient? piper = null)
    { this.settings=settings; this.gemini=gemini; this.piper=piper ?? new PiperClient(settings); }
    public Task<string> TextAsync(AskRequest request,IReadOnlyList<Turn> context,CancellationToken cancellation) =>
        gemini.TextAsync(request,context,cancellation);
    public Task<byte[]> SpeechAsync(string text,AskRequest request,CancellationToken cancellation) =>
        settings.UsesPiper ? piper.SpeechAsync(text,cancellation) : gemini.SpeechAsync(text,request,cancellation);
}

/// <summary>External Piper CLI writes a bounded WAV. No shell or desktop audio playback.</summary>
public sealed class PiperClient
{
    private readonly Settings settings;
    // One model load/process at a time, even when text jobs run concurrently.
    private readonly SemaphoreSlim worker = new SemaphoreSlim(1);
    public PiperClient(Settings settings) { this.settings=settings; }

    // Standard argv quoting for Windows CRT and .NET's Unix Arguments parser. No shell is used.
    internal static string Quote(string value)
    {
        var result=new StringBuilder("\"");
        int slashes=0;
        foreach (char c in value)
        {
            if (c=='\\') { slashes++; continue; }
            if (c=='\"') result.Append('\\',slashes*2+1).Append(c);
            else result.Append('\\',slashes).Append(c);
            slashes=0;
        }
        return result.Append('\\',slashes*2).Append('"').ToString();
    }
    private static void Kill(Process process)
    {
        try { if (!process.HasExited) process.Kill(); } catch { }
    }
    private static async Task Drain(StreamReader reader)
    {
        var buffer=new char[1024];
        try { while (await reader.ReadAsync(buffer,0,buffer.Length).ConfigureAwait(false)>0) { } }
        catch { /* Diagnostics are discarded; process status and validated WAV are authoritative. */ }
    }
    public async Task<byte[]> SpeechAsync(string text,CancellationToken cancellation)
    {
        if (string.IsNullOrWhiteSpace(text) || text.Length>settings.MaxSpeechChars)
            throw new AiException(400,"Piper speech text is empty or exceeds the speech limit.");
        if (text.IndexOf('\0')>=0) throw new AiException(400,"Piper speech text contains an invalid character.");
        string executable,model;
        try
        {
            executable=Path.GetFullPath(Environment.ExpandEnvironmentVariables(settings.PiperExecutable));
            model=Path.GetFullPath(Environment.ExpandEnvironmentVariables(settings.PiperModel));
        }
        catch { throw new AiException(503,"Set Speech.PiperExecutable and Speech.PiperModel to valid paths."); }
        if (!File.Exists(executable)) throw new AiException(503,"Piper executable was not found. Check Speech.PiperExecutable.");
        if (!File.Exists(model) || !File.Exists(model+".json"))
            throw new AiException(503,"Piper model or matching .onnx.json was not found. Check Speech.PiperModel.");
        using var timeout=CancellationTokenSource.CreateLinkedTokenSource(cancellation);
        timeout.CancelAfter(TimeSpan.FromSeconds(settings.PiperTimeoutSeconds));
        bool acquired=false,started=false;
        string? output=null;
        using var process=new Process();
        try
        {
            await worker.WaitAsync(timeout.Token).ConfigureAwait(false); acquired=true;
            string folder=Path.Combine(settings.DataDirectory,"piper-work");
            Directory.CreateDirectory(folder);
            // Stale outputs from an interrupted game are transient speech, not persistent chat.
            foreach (string old in Directory.GetFiles(folder,"p*.wav"))
                if (System.Text.RegularExpressions.Regex.IsMatch(Path.GetFileName(old),"^p[a-f0-9]{16}\\.wav$") &&
                    File.GetLastWriteTimeUtc(old).AddMinutes(10)<DateTime.UtcNow)
                    try { File.Delete(old); } catch { }
            output=Path.Combine(folder,"p"+Guid.NewGuid().ToString("N").Substring(0,16)+".wav");
            process.StartInfo=new ProcessStartInfo {
                FileName=executable,
                Arguments="--model "+Quote(model)+" --config "+Quote(model+".json")+
                    " --output_file "+Quote(output)+" --length_scale "+settings.PiperLengthScale.ToString("G",CultureInfo.InvariantCulture),
                WorkingDirectory=Path.GetDirectoryName(executable)!, UseShellExecute=false,
                CreateNoWindow=true, RedirectStandardInput=true, RedirectStandardOutput=true, RedirectStandardError=true
            };
            try { started=process.Start(); }
            catch { throw new AiException(503,"Piper could not start. Check executable, bundled DLLs and permissions."); }
            if (!started) throw new AiException(503,"Piper could not start.");
            using var cancel=timeout.Token.Register(()=>Kill(process));
            Task stdout=Drain(process.StandardOutput), stderr=Drain(process.StandardError);
            // UTF-8 bytes without BOM, never text in argv. One CLI input item for the full reply.
            byte[] input=Encoding.UTF8.GetBytes(text.Replace("\r\n"," ").Replace('\r',' ').Replace('\n',' ')+"\n");
            await process.StandardInput.BaseStream.WriteAsync(input,0,input.Length,timeout.Token).ConfigureAwait(false);
            process.StandardInput.BaseStream.Close();
            long maximum=settings.MaxAudioFileMegabytes*1024L*1024;
            while (!process.HasExited)
            {
                timeout.Token.ThrowIfCancellationRequested();
                if (File.Exists(output) && new FileInfo(output).Length>maximum)
                    throw new AiException(413,"Piper output exceeds the audio file limit.");
                await Task.Delay(25,timeout.Token).ConfigureAwait(false);
            }
            timeout.Token.ThrowIfCancellationRequested();
            // Do not let inherited output pipes delay job completion indefinitely.
            await Task.WhenAny(Task.WhenAll(stdout,stderr),Task.Delay(250)).ConfigureAwait(false);
            if (process.ExitCode!=0)
                throw new AiException(502,"Piper failed (exit "+process.ExitCode+"). Check executable, DLLs and voice model/config.");
            if (!File.Exists(output)) throw new AiException(502,"Piper returned no WAV file.");
            if (new FileInfo(output).Length>maximum) throw new AiException(413,"Piper output exceeds the audio file limit.");
            return WaveAudio.ValidateWav(File.ReadAllBytes(output));
        }
        catch (Exception) when (timeout.IsCancellationRequested)
        { throw new AiException(504,cancellation.IsCancellationRequested ? "Piper speech was cancelled; text remains available." : "Piper timed out; text remains available."); }
        catch (AiException) { throw; }
        catch { throw new AiException(502,"Piper speech failed. Check paths, model files and data-folder permissions; text remains available."); }
        finally
        {
            if (started)
            {
                Kill(process);
                try { process.WaitForExit(1000); } catch { }
                try { process.StandardOutput.Dispose(); } catch { }
                try { process.StandardError.Dispose(); } catch { }
                try { process.StandardInput.Dispose(); } catch { }
            }
            if (output!=null) try { File.Delete(output); } catch { }
            if (acquired) worker.Release();
        }
    }
}
