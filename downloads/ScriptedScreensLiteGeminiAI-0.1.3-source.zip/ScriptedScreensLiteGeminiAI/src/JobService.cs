using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;

namespace ScriptedScreensLiteGeminiAI;

public sealed class JobService : IDisposable
{
    private readonly object gate = new object();
    private readonly Settings settings;
    private readonly IAiProvider provider;
    private readonly ConversationStore memory;
    private readonly AudioStore audio;
    private readonly Dictionary<string, JobResult> jobs = new Dictionary<string, JobResult>();
    private readonly Dictionary<string, DateTime> sourceTimes = new Dictionary<string, DateTime>();
    private readonly Queue<DateTime> requestTimes = new Queue<DateTime>();
    private readonly HashSet<Task> tasks = new HashSet<Task>();
    private readonly CancellationTokenSource stop = new CancellationTokenSource();
    private readonly SemaphoreSlim workers;
    private int pending;
    private bool disposed;

    public JobService(Settings settings, IAiProvider provider, ConversationStore memory, AudioStore audio)
    {
        this.settings = settings; this.provider = provider; this.memory = memory; this.audio = audio;
        workers = new SemaphoreSlim(settings.MaxConcurrent);
    }
    public string Submit(AskRequest request) => Submit(request,null);
    private string Submit(AskRequest request,string? localText)
    {
        request.Validate(settings);
        lock (gate)
        {
            if (disposed) throw new AiException(503, "AI service is stopping.");
            Cleanup();
            if (pending >= settings.MaxPending || jobs.Count >= settings.MaxJobs) throw new AiException(429, "AI queue is full. Retry later.");
            var now = DateTime.UtcNow;
            if (sourceTimes.TryGetValue(request.SourceRefId, out var last) && now.Subtract(last).TotalSeconds < settings.CooldownSeconds)
                throw new AiException(429, "Device cooldown is active.");
            while (requestTimes.Count > 0 && now.Subtract(requestTimes.Peek()).TotalSeconds >= 60) requestTimes.Dequeue();
            if (requestTimes.Count >= settings.RequestsPerMinute) throw new AiException(429, "Server request limit reached. Retry later.");
            ConversationStore.Lease? lease = request.Remember ? memory.Reserve(request.ConversationKey) : null;
            string id = Guid.NewGuid().ToString("N");
            var job = new JobResult { Id = id, SourceRefId = request.SourceRefId, ConversationId = request.ConversationKey };
            jobs.Add(id, job);
            pending++;
            sourceTimes[request.SourceRefId] = now;
            requestTimes.Enqueue(now);
            // Snapshot the request: callers cannot mutate its preferences after acceptance.
            var snapshot = JObject.FromObject(request).ToObject<AskRequest>()!;
            Task task = Task.Run(() => Run(snapshot, job, lease,localText));
            tasks.Add(task);
            _ = task.ContinueWith(t => { lock (gate) tasks.Remove(t); }, TaskScheduler.Default);
            return id;
        }
    }
    private async Task Run(AskRequest request, JobResult job, ConversationStore.Lease? lease,string? localText)
    {
        bool acquired = false;
        string finalState = "error";
        using var timeout = CancellationTokenSource.CreateLinkedTokenSource(stop.Token);
        timeout.CancelAfter(TimeSpan.FromSeconds(settings.RequestTimeoutSeconds +
            (settings.UsesPiper ? settings.PiperTimeoutSeconds : settings.RequestTimeoutSeconds) + 10));
        try
        {
            await workers.WaitAsync(timeout.Token).ConfigureAwait(false);
            acquired = true;
            lock (gate) job.State = "running";
            string full = localText ?? await provider.TextAsync(request, lease?.Context ?? Array.Empty<Turn>(), timeout.Token).ConfigureAwait(false);
            if (string.IsNullOrWhiteSpace(full)) throw new AiException(502, "AI returned no text.");
            string text = TextLimits.Cut(full, settings.MaxReplyChars);
            lock (gate) { job.Text = text; job.ReplyTruncated = full.Length > text.Length; }
            if (lease != null)
            {
                try { lease.Append(request.Question, text); }
                catch (AiException ex) { lock (gate) job.MemoryError = ex.Message; }
            }
            if (request.Speak && settings.EnableTts)
            {
                if (text.Length > settings.MaxSpeechChars)
                { lock (gate) job.VoiceError = "Reply is longer than the speech limit. Ask for a shorter reply."; }
                else
                {
                    using var reservation = audio.TryReserve();
                    if (reservation == null)
                    { lock (gate) job.VoiceError = "Audio cache is protecting active playback; wait before requesting another voice. Text is available."; }
                    else
                    try
                    {
                        byte[] wav = await provider.SpeechAsync(text, request, timeout.Token).ConfigureAwait(false);
                        WaveAudio.ValidateWav(wav);
                        var clip = audio.Save(WaveAudio.WithGuardSilence(wav), reservation);
                        lock (gate)
                        {
                            job.AudioUrl = clip.Url; job.AudioExpiresUtc = clip.ExpiresUtc;
                            job.AudioDurationSeconds = clip.DurationSeconds;
                            // Stop inside the silent tail, before the next loop can reach speech.
                            job.AudioStopAfterSeconds = clip.DurationSeconds - 1;
                        }
                    }
                    catch (Exception ex)
                    {
                        lock (gate) job.VoiceError = ex is AiException safe ? safe.Message : "TTS failed or timed out; text is available.";
                    }
                }
            }
            finalState = "done";
        }
        catch (Exception ex)
        {
            lock (gate) { job.Error = ex is AiException safe ? safe.Message : "AI request failed or timed out."; }
        }
        finally
        {
            lease?.Dispose();
            if (acquired) workers.Release();
            lock (gate) { pending--; job.FinishedUtc = DateTime.UtcNow; job.State = finalState; }
        }
    }
    public JObject Get(string id)
    {
        lock (gate)
        {
            Cleanup();
            if (!jobs.TryGetValue(id, out var job)) throw new AiException(404, "Job not found or expired.");
            return JObject.FromObject(job);
        }
    }
    public object ListConversations() => memory.List();
    public string PiperTest(AskRequest identity)
    {
        if (!settings.UsesPiper) throw new AiException(409,"Set Speech.Provider=Piper before testing local speech. No Gemini request was made.");
        if (!settings.EnableTts) throw new AiException(409,"Enable Speech.Enabled to test Piper.");
        const string text="Ahoj, jsem Oasis. Mluvím česky ze zařízení ve hře.";
        return Submit(new AskRequest { SourceRefId=identity.SourceRefId, Question=text, Speak=true, Remember=false },text);
    }
    public void TestMemoryDisk() => memory.TestDisk();
    public JobResult AudioTest(AskRequest identity)
    {
        identity.Question = "local audio diagnostic";
        identity.Validate(settings);
        var clip = audio.Save(WaveAudio.ThreeToneTest());
        return new JobResult {
            Id = Guid.NewGuid().ToString("N"), State = "done", SourceRefId = identity.SourceRefId,
            ConversationId = identity.ConversationKey, Text = "Three local tones; no Gemini request.",
            AudioUrl = clip.Url, AudioDurationSeconds = clip.DurationSeconds,
            AudioStopAfterSeconds = clip.DurationSeconds - 1, AudioExpiresUtc = clip.ExpiresUtc
        };
    }
    public void Reset(AskRequest identity)
    {
        identity.Question = "reset";
        identity.Validate(settings);
        memory.Delete(identity.ConversationKey);
    }
    public void Cleanup()
    {
        lock (gate)
        {
            DateTime now = DateTime.UtcNow;
            foreach (string id in jobs.Where(p => p.Value.FinishedUtc.HasValue && now.Subtract(p.Value.FinishedUtc.Value).TotalSeconds > settings.JobTtlSeconds)
                                       .Select(p => p.Key).ToArray()) jobs.Remove(id);
            foreach (string source in sourceTimes.Where(p => now.Subtract(p.Value).TotalSeconds > 60).Select(p => p.Key).ToArray()) sourceTimes.Remove(source);
        }
    }
    public void Dispose()
    {
        Task[] running;
        lock (gate) { if (disposed) return; disposed = true; stop.Cancel(); running = tasks.ToArray(); }
        try { Task.WaitAll(running, 3000); } catch { }
        // Semaphore/token are intentionally not disposed while a cancelled provider may still unwind.
    }
}
