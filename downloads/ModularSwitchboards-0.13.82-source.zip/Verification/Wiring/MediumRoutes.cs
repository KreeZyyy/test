using System;
using System.Linq;
using ModularSwitchboards;
partial class RouteHarness
{
 internal static void RunMedium()
 {
  var h=new RouteHarness{Owner=new(){PrefabName="medium"},routingHalfWidth=.366f,routingHalfHeight=.477f};
  h.moduleReservations=WireModuleSpace.Reservations(.65f,new[]{-.27f,0,.27f}).ToArray();
  foreach(float y in new[]{-.27f,0,.27f})h.railObstacles.Add(new(-.264f,.304f,y-.0175f,y+.0175f));
  var input=new CabinetWireEnd(0,0);h.contacts[input]=new(){End=input,Position=new(0,.425f,.033f),Exit=new(0,.413f,WireRouting.Plane),Bounds=new(-.036f,.036f,.424f,.456f)};
  for(int i=1;i<=3;i++){float x=i==1?.23f:i==2?-.23f:0;var end=new CabinetWireEnd(0,i);h.contacts[end]=new(){End=end,Position=new(x,-.425f,.033f),Exit=new(x,-.413f,WireRouting.Plane),Bounds=new(x-.036f,x+.036f,-.456f,-.424f)};}
  for(int i=0;i<3;i++){float y=.27f-i*.27f,x=-.243f;var box=new WireRect(x-.0198f,x+.0198f,y-.050625f,y+.050625f);for(int pin=0;pin<2;pin++){var end=new CabinetWireEnd(10+i,pin);h.contacts[end]=new(){End=end,Position=new(x,y+(pin==0?.050625f:-.050625f),.06535f),Exit=new(x,y+(pin==0?.066f:-.066f),WireRouting.Plane),Bounds=box};}}
  foreach(var pair in Enumerable.Range(0,3).SelectMany(i=>new[]{(input,new CabinetWireEnd(10+i,0)),(new CabinetWireEnd(10+i,1),new CabinetWireEnd(0,i+1))}))
  {
   var path=h.MakeRoute(pair.Item1,pair.Item2,out int slot,out string fail);if(path==null)throw new Exception("Medium plate route "+pair.Item1+" -> "+pair.Item2+": "+fail);h.VerifyFutureSpace(path,pair.Item1,pair.Item2);
   foreach(var rail in h.railObstacles)for(int i=1;i<path.Length;i++)if(WireRouting.SegmentHitsRect(path[i-1],path[i],rail,WireRouting.Radius+.001f))throw new Exception("Medium wire cuts rail");
   h.wires.Add(new(){From=pair.Item1,To=pair.Item2,InputSlot=slot,RouteVersion=6,CableUnits=1,Points=Flatten(path)});
  }
  var doors=new RouteHarness{Owner=new(){PrefabName="medium"},routingHalfHeight=.477f};
  for(int leaf=0;leaf<2;leaf++)for(int i=0;i<2;i++){float x=i==0?-.1f:.1f,y=.075f;var end=new CabinetWireEnd(100+leaf*100+i,i==0?1:0);doors.contacts[end]=new(){End=end,Door=true,Leaf=leaf,Position=new(x,y+(i==0?-.023f:.023f),.0275f),Exit=new(x,y+(i==0?-.043f:.043f),.043f),Bounds=new(x-.019f,x+.019f,y-.024f,y+.024f)};}
  if(doors.CanConnectContacts(new(100,1),new(201,0),out _))throw new Exception("Wire directly jumps between leaves");
  foreach(int leaf in new[]{0,1}){var from=new CabinetWireEnd(100+leaf*100,1);var to=new CabinetWireEnd(101+leaf*100,0);var path=doors.MakeRoute(from,to,out int slot,out string fail);if(path==null)throw new Exception("Leaf "+leaf+" route: "+fail);doors.wires.Add(new(){From=from,To=to,InputSlot=slot,Points=Flatten(path)});}
  Console.WriteLine("Medium routes: all3 rows/outputs, 42 reserved module spaces, independent overlapping leaf coordinates and cross-leaf authority guard passed.");
 }
}
