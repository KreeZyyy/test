using System;
using System.Collections.Generic;
using System.Linq;
using Assets.Scripts;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Objects;
using UnityEngine;

namespace ModularSwitchboards
{
    // Shared placement reference; CabinetPowerInput registers the logical port separately.
    public sealed class OvenInputPanelMetadata : MonoBehaviour
    {
        public Vector3 SocketPoint, SocketAxis, CableCell, BodyCell, PanelFaceAxis;
        public Vector3 VisualAnchorPoint, SocketToVisualOffset;
        public Vector3 NativeSocketPoint, NativeSocketAxis, NativeVisualAnchor;
        public bool FunctionalConnection;
    }

    internal static class OvenInputPanel
    {
        internal const string RootName="OvenInputPanel";
        private static Mesh cached;
        private static MeshRenderer source;
        private static Vector3 nativeAnchor,nativeAxis;
        private static Vector3 visualAnchor;

        internal static void Install(SwitchboardCabinet cabinet)
        {
            GameObject root=null;
            try
            {
                if(cached==null)Capture();
                var socket=NativeCableLayout.Read(CabinetLayout.InputCell(cabinet.PrefabName),CabinetLayout.InputOutward(cabinet.PrefabName));
                root=new GameObject(RootName){layer=cabinet.gameObject.layer};
                root.transform.SetParent(cabinet.transform.Find("SwitchboardModel/CompletedShell"),false);
                // Turn in the horizontal panel plane around the fixed socket origin.
                // Keep the future logical socket point and axis unchanged.
                root.transform.localRotation=Quaternion.Euler(0,0,CabinetLayout.Reversed(cabinet.PrefabName)?180f:0f)*Quaternion.Euler(-90f,0f,0f)*Quaternion.Euler(0f,0f,180f);
                root.AddComponent<MeshFilter>().sharedMesh=cached;
                var renderer=root.AddComponent<MeshRenderer>();NativePortSurface.Capture(source,renderer);
                renderer.lightProbeUsage=source.lightProbeUsage;renderer.reflectionProbeUsage=source.reflectionProbeUsage;
                renderer.shadowCastingMode=source.shadowCastingMode;renderer.receiveShadows=source.receiveShadows;
                var marker=root.AddComponent<OvenInputPanelMetadata>();
                marker.SocketPoint=socket.Point;marker.SocketAxis=socket.Forward;
                marker.PanelFaceAxis=root.transform.localRotation*Vector3.forward;
                marker.CableCell=socket.CableCell.ToVector3();marker.BodyCell=socket.BodyCell.ToVector3();
                marker.NativeSocketPoint=nativeAnchor;marker.NativeSocketAxis=nativeAxis;marker.NativeVisualAnchor=visualAnchor;
                marker.FunctionalConnection=false;
                var collider=root.AddComponent<MeshCollider>();collider.sharedMesh=cached;
                cabinet.BuildStates[1].Colliders.Add(collider);
                Align(cabinet);CabinetModel.SetBounds(cabinet);
                Debug.Log("[Modular Switchboards] IN front face only: original width and height; no lower body; socket="+socket.Point.ToString("F6")+
                    " axis="+socket.Forward+" cableCell="+marker.CableCell+" bodyCell="+marker.BodyCell+
                    "; native oven anchor="+nativeAnchor.ToString("F6")+"; power registration follows panel installation.");
            }
            catch(Exception ex)
            {
                if(root!=null)
                {
                    var collider=root.GetComponent<MeshCollider>();
                    if(collider!=null)cabinet.BuildStates[1].Colliders.Remove(collider);
                    UnityEngine.Object.DestroyImmediate(root);
                }
                Debug.LogError("[Modular Switchboards] Oven IN model unavailable; cabinet preserved: "+ex);
            }
        }

        private static void Capture()
        {
            var oven=WorldManager.Instance.SourcePrefabs.OfType<SmallGrid>().First(p=>p.GetType().Name=="AutomatedOven");
            source=oven.GetComponentsInChildren<MeshRenderer>(true).First(r=>r.GetComponent<MeshFilter>()?.sharedMesh?.name=="StructureAutomatedOven");
            var mesh=source.GetComponent<MeshFilter>().sharedMesh;
            CabinetGeometry.ReadNativeMesh(mesh,out var points,out var uv,out var groups);
            var frame=oven.transform.worldToLocalMatrix*source.transform.localToWorldMatrix;
            for(int i=0;i<points.Length;i++)points[i]=frame.MultiplyPoint3x4(points[i]);
            var expected=new Vector3(-.5f,0,.317412257f);
            var anchor=oven.OpenEnds.Where(p=>p?.Transform!=null)
                .OrderBy(p=>(oven.transform.InverseTransformPoint(p.Transform.position)-expected).sqrMagnitude).First();
            nativeAnchor=oven.transform.InverseTransformPoint(anchor.Transform.position);
            nativeAxis=oven.transform.InverseTransformDirection(anchor.Transform.forward);
            // Only the visible face sits on the cable grid; no deep oven body.
            visualAnchor=new Vector3(nativeAnchor.x,nativeAnchor.y,.25f);
            if((nativeAnchor-expected).sqrMagnitude>.0001f)throw new InvalidOperationException("Oven power anchor differs from reference");
            var vertices=new List<Vector3>();var texcoords=new List<Vector2>();var remap=new Dictionary<int,int>();
            var triangles=new List<int>[groups.Length];int count=0;
            for(int s=0;s<groups.Length;s++)
            {
                triangles[s]=new List<int>();
                for(int i=0;i<groups[s].Length;i+=3)
                {
                    int a=groups[s][i],b=groups[s][i+1],c=groups[s][i+2];
                    if(!InsideTriangle(points[a],points[b],points[c]))continue;
                    count++;
                    foreach(int id in new[]{a,b,c})
                    {
                        if(!remap.TryGetValue(id,out var n)){n=vertices.Count;remap.Add(id,n);vertices.Add(points[id]-visualAnchor);texcoords.Add(uv[id]);}
                        triangles[s].Add(n);
                    }
                }
            }
            if(count!=78)throw new InvalidOperationException("Oven panel selection differs from verified 78 panel-and-socket triangles: "+count);
            var panel=new Mesh{name="Switchboards.NativeOvenInputPanel"};panel.SetVertices(vertices);panel.SetUVs(0,texcoords);panel.subMeshCount=groups.Length;
            for(int s=0;s<groups.Length;s++)panel.SetTriangles(triangles[s],s);
            panel.RecalculateNormals();panel.RecalculateTangents();panel.RecalculateBounds();cached=panel;
        }

        private static bool InsideTriangle(Vector3 a,Vector3 b,Vector3 c)
        {
            return (Face(a)&&Face(b)&&Face(c)) || (Socket(a)&&Socket(b)&&Socket(c));
        }
        private static bool Face(Vector3 p)=>p.x>=-.549f && p.x<=-.448f && p.y>=-.053f && p.y<=.126f && p.z>=.24999f && p.z<=.256f;
        private static bool Socket(Vector3 p)=>Mathf.Abs(p.x+.5f)<.04f && Mathf.Abs(p.y)<.04f && p.z>=.22f && p.z<=.25001f;

        internal static void Align(Structure cabinet)
        {
            var root=cabinet.transform.Find("SwitchboardModel/CompletedShell/"+RootName);
            if(root==null)return;var data=root.GetComponent<OvenInputPanelMetadata>();
            if(data==null)return;
            // Cancel visual wall-fit translation so the original power anchor,
            // projected to the visible face at the mesh origin, remains on the cable-grid socket position.
            // The selected housing edge is y=+/-0.25 m. The face belongs on that surface,
            // while the proposed native cable endpoint remains separate metadata.
            var visual=data.SocketPoint;visual.y=(CabinetShape.Medium(cabinet.PrefabName)?.7505f:.2505f)*CabinetLayout.YSign(cabinet.PrefabName);
            data.VisualAnchorPoint=visual;
            data.SocketToVisualOffset=visual-data.SocketPoint;
            root.localPosition=root.parent.InverseTransformPoint(cabinet.transform.position)+visual;
            OvenInputSupport.Fit(cabinet);
        }

        internal static void IncludeBounds(Structure cabinet,ref Bounds bounds)
        {
            var root=cabinet.transform.Find("SwitchboardModel/CompletedShell/"+RootName);
            var mesh=root==null?null:root.GetComponent<MeshFilter>()?.sharedMesh;
            if(mesh!=null)bounds.Encapsulate(CabinetWallMount.TransformedBounds(mesh.bounds,
                cabinet.transform.worldToLocalMatrix*root.localToWorldMatrix));
        }
    }
}
