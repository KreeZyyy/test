using UnityEngine;
namespace ModularSwitchboards
{
    public sealed class SmartOutputView:MonoBehaviour
    {
        private DinBreaker owner;
        private MeshRenderer lens;
        private readonly MaterialPropertyBlock block=new MaterialPropertyBlock();
        private bool applied,previous;
        private float nextCheck;
        private static readonly int ColorId=Shader.PropertyToID("_Color"),EmissionId=Shader.PropertyToID("_EmissionColor");
        private void OnEnable()
        {
            // Resolve the actual instance after cloning; do not keep references to the source prefab.
            owner=GetComponent<DinBreaker>();lens=transform.Find("DinBreakerModel/SmartOutputLens")?.GetComponent<MeshRenderer>();
            applied=false;nextCheck=0f;Paint(false);
        }
        private void LateUpdate()
        {
            if(owner==null||lens==null||Time.unscaledTime<nextCheck)return;
            nextCheck=Time.unscaledTime+.15f;
            Paint(SmartOutputStatus.Connected(owner));
        }
        private void Paint(bool connected)
        {
            if(lens==null||(applied&&previous==connected))return;
            var color=connected?new Color(.08f,1f,.12f):new Color(1f,.38f,.015f);
            block.Clear();block.SetColor(ColorId,color);block.SetColor(EmissionId,color*2f);lens.SetPropertyBlock(block);
            previous=connected;applied=true;
        }
    }
}
