using System;using System.Linq;using System.Collections.Generic;using UnityEngine;using ModularSwitchboards;
namespace UnityEngine {
 public struct Vector2{public float x,y;public Vector2(float x,float y){this.x=x;this.y=y;}}
 public struct Vector3{public float x,y,z;public Vector3(float x,float y,float z){this.x=x;this.y=y;this.z=z;}public static Vector3 one=>new(1,1,1);public static Vector3 right=>new(1,0,0);public static Vector3 left=>new(-1,0,0);public static Vector3 up=>new(0,1,0);public static Vector3 down=>new(0,-1,0);public static Vector3 forward=>new(0,0,1);public static Vector3 back=>new(0,0,-1);public static Vector3 operator *(Vector3 a,float b)=>new(a.x*b,a.y*b,a.z*b);public static Vector3 operator +(Vector3 a,Vector3 b)=>new(a.x+b.x,a.y+b.y,a.z+b.z);public static Vector3 operator -(Vector3 a,Vector3 b)=>new(a.x-b.x,a.y-b.y,a.z-b.z);public Vector3 normalized{get{float d=MathF.Sqrt(x*x+y*y+z*z);return new(x/d,y/d,z/d);}}public static Vector3 Cross(Vector3 a,Vector3 b)=>new(a.y*b.z-a.z*b.y,a.z*b.x-a.x*b.z,a.x*b.y-a.y*b.x);}
 public static class Mathf{public const float PI=MathF.PI,Deg2Rad=MathF.PI/180;public static float Abs(float n)=>MathF.Abs(n);public static float Min(float a,float b)=>MathF.Min(a,b);public static float Clamp(float n,float a,float b)=>Math.Clamp(n,a,b);public static float Cos(float n)=>MathF.Cos(n);public static float Sin(float n)=>MathF.Sin(n);}
 public class Mesh{public string name;public List<Vector3> V,N;public List<Vector2> UV;public void SetUVs(int channel,List<Vector2> uv){UV=uv;}public int subMeshCount;public Dictionary<int,int[]> T=new();public void SetVertices(List<Vector3> v)=>V=v;public void SetNormals(List<Vector3> n)=>N=n;public void SetTriangles(List<int> t,int sub)=>T[sub]=t.ToArray();public Vector3[] vertices=>V.ToArray();public Vector3[] normals=>N.ToArray();public int[] GetTriangles(int sub)=>T[sub];public Vector2[] uv{get=>UV?.ToArray()??Array.Empty<Vector2>();set=>UV=value.ToList();}public void RecalculateBounds(){}}
 public class Material{public string name;public Material(){}public Material(Material source){}public Dictionary<string,float> Floats=new();public void SetFloat(int id,float value){}public void SetFloat(string name,float value){Floats[name]=value;}}public struct Color{public static Color black=>new();}public class MaterialPropertyBlock{public float Index;public void SetFloat(int id,float value){Index=value;}public void SetColor(int id,Color value){}}
 public class Renderer{public Material[] sharedMaterials=new Material[5];public Dictionary<int,float> Blocks=new();public void SetPropertyBlock(MaterialPropertyBlock b){if(b==null)Blocks.Remove(-1);else Blocks[-1]=b.Index;}public void SetPropertyBlock(MaterialPropertyBlock b,int role){if(b==null)Blocks.Remove(role);else Blocks[role]=b.Index;}}public class MeshRenderer:Renderer{}public class GameObject{public static int SetCalls;public bool activeSelf;public void SetActive(bool b){SetCalls++;activeSelf=b;}public T GetComponent<T>() where T:new()=>new();}public class MonoBehaviour{}
}
namespace Assets.Scripts.Objects {public class Thing{public const int DiffuseIndexPropertyID=1,EMISSION_COLOR=2;}}
namespace Assets.Scripts.Objects.Motherboards{public enum ColorType:byte{Blue,Gray,Green,Orange,Red,Yellow,White,Black,Brown,Khaki,Pink,Purple}}
namespace ModularSwitchboards {
 public class DinBreaker{public bool Conducting,Tripped;public float RatedWatts;}
 static class FuseSurfaces{public static Material[] White=>new Material[5];}
 static class FuseAppearanceDiagnostics{public static int Calls;public static void Capture(DinFuseView v){Calls++;}}
 static class DinModuleCatalog{public static string Colour(float w)=>"Green";}
 static partial class DinBreakerModel{public static Vector3 VisualScale=new(2.25f,1.35f,1.15f);}
 static class CabinetGeometry{public static Material[] Materials=new Material[5];public static int[] PaletteIndices=new int[5];public static void ApplyNativeUv(Mesh m){m.UV=Enumerable.Repeat(new Vector2(.5f,.5f),m.V.Count).ToList();}}

}
static class Program {
 static bool HitZ(Vector3 a,Vector3 b,Vector3 c,out float z){float d=(b.y-c.y)*(a.x-c.x)+(c.x-b.x)*(a.y-c.y);z=0;if(Math.Abs(d)<1e-10)return false;float u=((b.y-c.y)*(-c.x)+(c.x-b.x)*(-c.y))/d;float v=((c.y-a.y)*(-c.x)+(a.x-c.x)*(-c.y))/d;float w=1-u-v;if(u<0||v<0||w<0)return false;z=u*a.z+v*b.z+w*c.z;return true;}
 static void Main(){var originalBreaker=BreakerBaseline.Build();var sharedBreaker=DinBreakerModel.Build();
 if(originalBreaker.V.Count!=sharedBreaker.V.Count||originalBreaker.N.Count!=sharedBreaker.N.Count)throw new Exception("Original breaker geometry changed");
 for(int k=0;k<originalBreaker.V.Count;k++){var a=originalBreaker.V[k];var b=sharedBreaker.V[k];if(a.x!=b.x||a.y!=b.y||a.z!=b.z)throw new Exception("Original breaker vertex changed");}
 foreach(var pair in originalBreaker.T)if(!pair.Value.SequenceEqual(sharedBreaker.T[pair.Key]))throw new Exception("Original breaker indices changed");
 Console.WriteLine("Shared body builder preserves every original breaker vertex and triangle.");
 var cv=new List<Vector3>();var cn=new List<Vector3>();var ct=new List<int>();BatteryAperture.Box(cv,cn,ct,new Vector3(0,0,.029f),new Vector3(.036f,.075f,.056f),.0018f,.020f,.033f);
 foreach(var probe in new[]{new Vector3(.010f,.028f,0),new Vector3(-.010f,.028f,0),new Vector3(.014f,.0165f,0),new Vector3(.014f,-.0165f,0)}){
 float zmax=0;for(int i=0;i<ct.Count;i+=3)if(HitZ(cv[ct[i]]-probe,cv[ct[i+1]]-probe,cv[ct[i+2]]-probe,out float z))zmax=Math.Max(zmax,z);
 if(Math.Abs(zmax-.057f)>.0000001f)throw new Exception("Internal panel seam remains at aperture partition");
 }Console.WriteLine("Continuous casing: four former seam locations retain the original flat face.");var body=DinFuseModel.Housing();float front=0;foreach(var indices in body.T.Values)for(int i=0;i<indices.Length;i+=3)if(HitZ(body.V[indices[i]],body.V[indices[i+1]],body.V[indices[i+2]],out float z))front=Math.Max(front,z);if(front>.0321f||front<.0319f)throw new Exception("Holder centre is not recessed/hollow");
 // Seams formerly ran across the fuse body at y=+/-.0225. The shared
 // casing keeps the original rounded breaker shoulder across that location.
 var reference=BreakerBaseline.Build();foreach(float y in new[]{-.023f,-.0225f,.0225f,.023f}){
 float actual=0,expected=0;var shift=new Vector3(.007f,y,0);
 foreach(var pair in body.T)for(int i=0;i<pair.Value.Length;i+=3)if(HitZ(body.V[pair.Value[i]]-shift,body.V[pair.Value[i+1]]-shift,body.V[pair.Value[i+2]]-shift,out float z))actual=Math.Max(actual,z);
 foreach(var pair in reference.T)for(int i=0;i<pair.Value.Length;i+=3)if(HitZ(reference.V[pair.Value[i]]-shift,reference.V[pair.Value[i+1]]-shift,reference.V[pair.Value[i+2]]-shift,out float z))expected=Math.Max(expected,z);
 if(Math.Abs(actual-expected)>.000001f)throw new Exception("Fuse casing retains a seam unlike original breaker");
 }Console.WriteLine("Fuse casing matches original breaker surface across former divider locations.");
 // Looking downward inside the aperture must hit the lower inner wall,
 // not escape through the cut shell. Test the production grey material faces.
 float lowerWall=float.NegativeInfinity;
 var inner=body.T[3];for(int i=0;i<inner.Length;i+=3){var a=body.V[inner[i]];var b=body.V[inner[i+1]];var c=body.V[inner[i+2]];
 if(HitZ(new Vector3(a.x,a.z-.040f,a.y),new Vector3(b.x,b.z-.040f,b.y),new Vector3(c.x,c.z-.040f,c.y),out float y)&&y<0)lowerWall=Math.Max(lowerWall,y);}
 if(Math.Abs(lowerWall+.0212f)>.000001f)throw new Exception("Downward view still escapes through fuse aperture");
 Console.WriteLine("Downward aperture ray hits the grey lower inner wall at y=-21.2mm.");
 var bottomVertices=body.T[3].Select(i=>body.V[i]).Where(v=>Math.Abs(v.y+.0212f)<.0000001f).ToArray();
 if(bottomVertices.Length<4||bottomVertices.Min(v=>v.z)>.032001f||bottomVertices.Max(v=>v.z)<.063799f)throw new Exception("Fuse pocket liner does not reach closed rear and front");
 Console.WriteLine("Continuous fuse liner covers the full depth from rear .032 to front .0638.");
 var contacts=DinFuseModel.Contacts();
 foreach(float end in new[]{-1f,1f})foreach(float side in new[]{-1f,1f})foreach(float dx in new[]{-.0005f,0,.0005f})foreach(float dy in new[]{-.002f,0,.002f}){
 var probe=new Vector3(side*.0047f+dx,end*.014f+dy,0);float frontmost=0;string visible="";Vector3 faceNormal=new Vector3();
 foreach(var pair in new Dictionary<string,Mesh>{{"housing",body},{"contact",contacts},{"caps",DinFuseModel.Caps()},{"barrel",DinFuseModel.Cartridge(false)}})
 foreach(var indices in pair.Value.T.Values)for(int i=0;i<indices.Length;i+=3)
 if(HitZ(pair.Value.V[indices[i]]-probe,pair.Value.V[indices[i+1]]-probe,pair.Value.V[indices[i+2]]-probe,out float z)&&z>frontmost){frontmost=z;visible=pair.Key;faceNormal=pair.Value.N[indices[i]];}
 if(visible!="contact"||Math.Abs(frontmost-.0545f)>1e-6f||faceNormal.z<.999f)throw new Exception("Clamp face hidden by cap/housing or facing sideways");
 }
 if(contacts.V.Any(v=>Math.Abs(v.y)>.019301f||Math.Abs(v.x)>.005501f||v.z>.054501f||v.z<.031999f))throw new Exception("Clamp exceeds pocket bounds");
 float capRadius=.0082f/DinBreakerModel.VisualScale.x;
 // No jaw may pass through the cap; the backplate stays behind its rear envelope.
 if(.0047f-.0016f*.5f<=capRadius)throw new Exception("Jaw intersects native white cap");
 if(.034f+.004f*.5f>=.046f-.0082f/DinBreakerModel.VisualScale.z)throw new Exception("Rear support intersects cap");
 if(.0186f-.0014f*.5f<=.014f+.005f*.5f)throw new Exception("End stop intersects cap");
 float flatWidth=(.0016f-2*.00012f)*DinBreakerModel.VisualScale.x;
 if(flatWidth/(.0176f*DinBreakerModel.VisualScale.x)*40f<3f)throw new Exception("Front face too narrow at 40px module width");
 Console.WriteLine("36 front rays hit exposed +Z clamp faces ahead of housing/caps; broad faces exceed3px at40px module width. Cap/rear/end clearances passed.");
 // Rays in all five interior directions prove the tray closes the actual pocket.
 foreach(var axis in new[]{Vector3.right,Vector3.left,Vector3.up,Vector3.down,Vector3.back}) {
 var origin=new Vector3(0,0,.045f);float best=float.PositiveInfinity;
 foreach(var indices in body.T.Values)for(int i=0;i<indices.Length;i+=3){
 var a=body.V[indices[i]]-origin;var b=body.V[indices[i+1]]-origin;var c=body.V[indices[i+2]]-origin;
 Func<Vector3,Vector3> project=p=>Math.Abs(axis.x)>.5f?new Vector3(p.y,p.z,p.x*axis.x):Math.Abs(axis.y)>.5f?new Vector3(p.x,p.z,p.y*axis.y):new Vector3(p.x,p.y,-p.z);
 if(HitZ(project(a),project(b),project(c),out float distance)&&distance>0)best=Math.Min(best,distance);
 }
 float expected=Math.Abs(axis.x)>.5f?FusePocket.HalfX:Math.Abs(axis.y)>.5f?FusePocket.HalfY:.045f-FusePocket.Rear;
 if(Math.Abs(best-expected)>1e-6f)throw new Exception("Tray has missing or misplaced wall");
 }
 var trayV=new List<Vector3>();var trayN=new List<Vector3>();var trayT=new List<int>();FusePocket.Add(trayV,trayN,trayT);
 var edges=new Dictionary<string,int>();
 Func<Vector3,string> key=p=>Math.Round(p.x,7)+","+Math.Round(p.y,7)+","+Math.Round(p.z,7);
 for(int i=0;i<trayT.Count;i+=3)for(int j=0;j<3;j++){
 string a=key(trayV[trayT[i+j]]),b=key(trayV[trayT[i+(j+1)%3]]);string e=string.CompareOrdinal(a,b)<0?a+"/"+b:b+"/"+a;
 edges[e]=edges.GetValueOrDefault(e)+1;
 }
 if(edges.Values.Any(count=>count!=2))throw new Exception("Tray is not a closed volume");
 Console.WriteLine("New tray: rear, left, right, upper and lower walls verified; watertight closed volume.");
 var healthy=DinFuseModel.Cartridge(false);var burnt=DinFuseModel.Cartridge(true);
 if(healthy.T[0].Length==0||burnt.T[0].Length!=0||burnt.T[3].Length==0)throw new Exception("Healthy coloured barrel/burnt charred body absent");
 if(burnt.V.Any(v=>Math.Abs(v.y)<.0019f))throw new Exception("Burnt cartridge doesn't have a physical broken gap");
 var caps=DinFuseModel.Caps();if(caps.T[1].Length==0||caps.T.Where(p=>p.Key!=1).Any(p=>p.Value.Length!=0))throw new Exception("Caps not isolated to white role");if(Environment.GetEnvironmentVariable("FUSE_MESH_PREVIEW")=="1"){
 var meshes=new Dictionary<string,Mesh>{{"housing",body},{"contacts",contacts},{"cartridge",healthy},{"caps",caps}};
 System.IO.File.WriteAllText("/workspace/work/fuse79-meshes.json",System.Text.Json.JsonSerializer.Serialize(meshes.ToDictionary(p=>p.Key,p=>new {vertices=p.Value.V.Select(v=>new[]{v.x,v.y,v.z}),triangles=p.Value.T})));
 }
 var renderer=new MeshRenderer();DinFuseModel.PaintCaps(renderer);if(renderer.Blocks.Count!=0)throw new Exception("Palette blocks retained on plain caps");
 foreach(var m in new[]{body,contacts,healthy,burnt,caps}){if(m.V.Count!=m.N.Count||m.T.Values.Any(t=>t.Any(i=>i<0||i>=m.V.Count)))throw new Exception("Invalid production fuse mesh");foreach(var v in m.V)if(float.IsNaN(v.x+v.y+v.z)||Math.Abs(v.x)>.009f||Math.Abs(v.y)>.038f||v.z>.064f)throw new Exception("Fuse geometry exceeds body envelope");}
 var owner=new DinBreaker();var view=new DinFuseView{Owner=owner,Intact=new GameObject(),Burnt=new GameObject(),Caps=new GameObject()};var update=typeof(DinFuseView).GetMethod("LateUpdate",System.Reflection.BindingFlags.NonPublic|System.Reflection.BindingFlags.Instance);
 update.Invoke(view,null);if(view.Intact.activeSelf||view.Burnt.activeSelf||view.Caps.activeSelf)throw new Exception("Empty holder shows a cartridge");owner.Conducting=true;update.Invoke(view,null);if(!view.Intact.activeSelf||view.Burnt.activeSelf||!view.Caps.activeSelf)throw new Exception("Healthy holder model wrong");owner.Conducting=false;owner.Tripped=true;update.Invoke(view,null);if(view.Intact.activeSelf||!view.Burnt.activeSelf||!view.Caps.activeSelf)throw new Exception("Burnt cartridge model missing");owner.Tripped=false;update.Invoke(view,null);if(view.Intact.activeSelf||view.Burnt.activeSelf||view.Caps.activeSelf)throw new Exception("Removed burnt cartridge still visible");
 var cup=BatterySocketModel.Build();
 var shell=BatterySocketModel.Build(new Vector3(-.0968359262f,-.115021147f,.129955426f),ApcBatteryRegion.FitScale(new Vector3(ApcBatteryRegion.NativeSocketHeight,ApcBatteryRegion.NativeSocketHeight,0)),0);
 var pads=BatterySocketModel.Build(new Vector3(-.0968359262f,-.115021147f,.129955426f),ApcBatteryRegion.FitScale(new Vector3(ApcBatteryRegion.NativeSocketHeight,ApcBatteryRegion.NativeSocketHeight,0)),1);
 if(shell.T[1].Length!=0||pads.T[0].Length!=0||shell.V.Count+pads.V.Count!=cup.V.Count)throw new Exception("Cup surface separation wrong");
 var edgeCounts=new Dictionary<string,int>();
 Func<Vector3,string> vk=p=>Math.Round(p.x,7)+","+Math.Round(p.y,7)+","+Math.Round(p.z,7);
 var st=shell.T[0];for(int i=0;i<st.Length;i+=3)for(int j=0;j<3;j++){
 string a=vk(shell.V[st[i+j]]),b=vk(shell.V[st[i+(j+1)%3]]);string e=string.CompareOrdinal(a,b)<0?a+"/"+b:b+"/"+a;
 edgeCounts[e]=edgeCounts.GetValueOrDefault(e)+1;
 }
 if(edgeCounts.Values.Any(v=>v!=2))throw new Exception("Battery cup is not a closed manifold");
 float fit=ApcBatteryRegion.FitScale(new Vector3(ApcBatteryRegion.NativeSocketHeight,ApcBatteryRegion.NativeSocketHeight,0));
 var nativeCenter=new Vector3(-.0968359262f,-.115021147f,.129955426f);
 float floor=ApcBatteryRegion.Map(new Vector3(0,0,.1343413f),nativeCenter,0,fit).z;
 float middle=(floor+ApcBatteryRegion.RimPlane)*.5f;
 foreach(var axis in new[]{Vector3.right,Vector3.left,Vector3.up,Vector3.down,Vector3.back}){
 var origin=new Vector3(DinBatteryLayout.CenterX,0,middle);float best=float.PositiveInfinity;
 Func<Vector3,Vector3> project=p=>Math.Abs(axis.x)>.5f?new Vector3(p.y,p.z,p.x*axis.x):Math.Abs(axis.y)>.5f?new Vector3(p.x,p.z,p.y*axis.y):new Vector3(p.x,p.y,-p.z);
 for(int i=0;i<st.Length;i+=3)if(HitZ(project(shell.V[st[i]]-origin),project(shell.V[st[i+1]]-origin),project(shell.V[st[i+2]]-origin),out float distance)&&distance>0)best=Math.Min(best,distance);
 float expected=Math.Abs(axis.x)>.5f?ApcBatteryRegion.SocketHeight*.5f/DinBreakerModel.VisualScale.x:Math.Abs(axis.y)>.5f?ApcBatteryRegion.SocketHeight*.5f/DinBreakerModel.VisualScale.y:middle-floor;
 if(Math.Abs(best-expected)>1e-6f)throw new Exception("Cup inner wall/floor missing");
 }
 // Native contacts must be byte-for-byte source geometry/UVs after the same fit transform.
 if(pads.T[1].Length!=48*3||pads.V.Count!=144||pads.UV.Count!=144)throw new Exception("Not the six original APC contacts");
 using(var stream=typeof(BatterySocketModel).Assembly.GetManifestResourceStream("ModularSwitchboards.BatterySocket.meshbin"))
 using(var reader=new System.IO.BinaryReader(stream)){
 reader.ReadBytes(8);int vertex=0;
 for(int i=0;i<134;i++){
 int role=reader.ReadByte();for(int k=0;k<3;k++){
 var source=new Vector3(reader.ReadSingle(),reader.ReadSingle(),reader.ReadSingle());float u=reader.ReadSingle(),v=reader.ReadSingle();if(role!=1)continue;
 var expected=ApcBatteryRegion.Map(source,nativeCenter,0,fit);var actual=pads.V[vertex];var q=pads.UV[vertex++];
 if(Math.Abs(expected.x-actual.x)>1e-7f||Math.Abs(expected.y-actual.y)>1e-7f||Math.Abs(expected.z-actual.z)>1e-7f||q.x!=u||q.y!=v)throw new Exception("Original APC contact geometry/UV changed");
 }}if(vertex!=144)throw new Exception("Native contact count mismatch");}
 var battery=DinBatteryModel.Build();
 foreach(float sx in new[]{-1f,1f})foreach(float sy in new[]{-1f,1f}){
 var probe=new Vector3(DinBatteryLayout.CenterX+sx*(BatterySocketModel.OuterSize*.5f-.0006f)/DinBreakerModel.VisualScale.x,sy*(BatterySocketModel.OuterSize*.5f-.0006f)/DinBreakerModel.VisualScale.y,0);
 float top=float.NegativeInfinity;foreach(var part in cup.T)for(int i=0;i<part.Value.Length;i+=3)if(HitZ(cup.V[part.Value[i]]-probe,cup.V[part.Value[i+1]]-probe,cup.V[part.Value[i+2]]-probe,out float z))top=Math.Max(top,z);
 if(Math.Abs(top-ApcBatteryRegion.RimPlane)>1e-6f)throw new Exception("Battery cup corner is open");
 }
 for(int ix=-2;ix<=2;ix++)for(int iy=-2;iy<=2;iy++){
 var probe=new Vector3(DinBatteryLayout.CenterX+ix*.007f/DinBreakerModel.VisualScale.x,iy*.007f/DinBreakerModel.VisualScale.y,0);float top=float.NegativeInfinity;
 foreach(var part in battery.T)for(int i=0;i<part.Value.Length;i+=3)if(HitZ(battery.V[part.Value[i]]-probe,battery.V[part.Value[i+1]]-probe,battery.V[part.Value[i+2]]-probe,out float z))top=Math.Max(top,z);
 if(top*DinBreakerModel.VisualScale.z>=.00599f)throw new Exception("Battery housing clips native cell rear envelope");
 }
 var slot=ApcBatteryRegion.Map(new Vector3(-.0968359262f,-.115021147f,.129955426f),nativeCenter,0,fit);
 float rear=slot.z*DinBreakerModel.VisualScale.z-.164837509f*.5f*fit;
 if(rear<=-.001f*DinBreakerModel.VisualScale.z)throw new Exception("Large native cell hits back cover");
 if(ApcBatteryRegion.CellFront(fit)+.002f<=Math.Max(cup.V.Max(v=>v.z),battery.V.Max(v=>v.z)))throw new Exception("Battery interaction recessed behind cup");
 foreach(var mesh in new[]{cup,shell,pads,battery}){
 if(mesh.V.Count!=mesh.N.Count||mesh.T.Values.Any(t=>t.Any(i=>i<0||i>=mesh.V.Count)))throw new Exception("Invalid battery cup mesh");
 foreach(var part in mesh.T.Values)for(int i=0;i<part.Length;i+=3){var cross=Vector3.Cross(mesh.V[part[i+1]]-mesh.V[part[i]],mesh.V[part[i+2]]-mesh.V[part[i]]);var normal=mesh.N[part[i]];
 if(float.IsNaN(normal.x+normal.y+normal.z)||cross.x*normal.x+cross.y*normal.y+cross.z*normal.z<=0)throw new Exception("Degenerate or reversed cup triangle");}
 }
 if(Environment.GetEnvironmentVariable("SOCKET82_PREVIEW")=="1"){
 var meshes=new Dictionary<string,Mesh>{{"housing",battery},{"socket",shell},{"contacts",pads}};
 System.IO.File.WriteAllText("/workspace/work/socket82-meshes.json",System.Text.Json.JsonSerializer.Serialize(meshes.ToDictionary(p=>p.Key,p=>new {vertices=p.Value.V.Select(v=>new[]{v.x,v.y,v.z}),triangles=p.Value.T})));
 }
 Console.WriteLine("New battery cup passed: closed manifold, all5inner walls,144original APC contact positions/UVs,4closed corners,25cell rear rays, native rear/interaction clearance, valid normals/indices.");
 int stableCalls=GameObject.SetCalls;for(int i=0;i<240;i++)update.Invoke(view,null);if(GameObject.SetCalls!=stableCalls||FuseAppearanceDiagnostics.Calls!=0)throw new Exception("Idle fuse rewrites appearance or captures diagnostics");
 foreach(bool on in new[]{true,false}){var m=BreakerLettering.Build(on,.013f,on?.0014f:-.0014f);if(m.V.Count==0||m.V.Count!=m.N.Count)throw new Exception("Missing lettering");foreach(var v in m.V)if(Math.Abs(v.x)>.006f||v.y<.010f||v.y>.016f)throw new Exception("Letter outside flap");var t=m.T[0];for(int i=0;i<t.Length;i+=3){var normal=Vector3.Cross(m.V[t[i+1]]-m.V[t[i]],m.V[t[i+2]]-m.V[t[i]]);if(normal.z*(on?1:-1)<=0)throw new Exception("Letter winding wrong");}}
 Console.WriteLine("Production fuse meshes passed: real recessed empty centre, coloured intact barrel, broken charred gap, valid indices and unchanged module envelope. Actual production rounded geometry used; four front contact rays clear housing. Plain surface shader still requires Unity visual verification.");
 }
}
