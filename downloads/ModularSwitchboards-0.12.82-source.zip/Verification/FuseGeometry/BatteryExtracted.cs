using System;using System.Collections.Generic;using UnityEngine;namespace ModularSwitchboards {static class DinBatteryModel{
        internal static Mesh Build()
        {
            // Build the actual breaker casing at two-position width. The builder
            // omits spindle bearings and cuts only the native battery aperture.
            float opening=BatterySocketModel.OuterSize;
            return DinBreakerModel.Build(DinBatteryLayout.Width,DinBatteryLayout.CenterX,true,opening/DinBreakerModel.VisualScale.x,opening/DinBreakerModel.VisualScale.y,true);
        }

}
    internal static class ModuleLayout
    {
        internal static bool Fits(int x, int y, int z, int rotation, int width, int capacity)
            => x % 10 == 0 && y == 0 && z == 0 && rotation == 0 && width > 0 &&
                x >= 0 && x / 10 + width <= capacity;
        internal static bool Overlaps(int start, int width, int other, int otherWidth)
            => start < other + otherWidth && other < start + width;
    }

}