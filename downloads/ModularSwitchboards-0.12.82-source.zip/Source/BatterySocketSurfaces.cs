using System;
using UnityEngine;
using UnityEngine.Rendering;
namespace ModularSwitchboards
{
    // The new cup clones the APC surface; the six original contacts retain
    // their original shared material, native UVs and original property blocks.
    internal static class BatterySocketSurfaces
    {
        private static Material[] materials;
        private static MaterialPropertyBlock[] blocks;
        private static MaterialPropertyBlock global;
        private static bool receiveShadows;
        private static ShadowCastingMode shadows;
        private static LightProbeUsage lights;
        private static ReflectionProbeUsage reflections;
        internal static void Capture(MeshRenderer source)
        {
            if(materials!=null)return;
            if(source==null||source.sharedMaterials.Length!=1||source.sharedMaterials[0]==null)
                throw new InvalidOperationException("APC material unavailable for battery cup");
            var original=source.sharedMaterials[0];
            global=new MaterialPropertyBlock();source.GetPropertyBlock(global);
            if(!original.HasProperty("_Color"))throw new InvalidOperationException("APC shader lacks native color tint");
            materials=new[]{new Material(original){name="Switchboards.ApcBatteryCup.Gray"},original};
            blocks=new MaterialPropertyBlock[2];
            var gray=new Color(.50f,.54f,.55f,1f);materials[0].SetColor("_Color",gray);
            for(int i=0;i<2;i++)
            {
                var block=new MaterialPropertyBlock();source.GetPropertyBlock(block,0);if(block.isEmpty)source.GetPropertyBlock(block);
                if(i==0){block.SetColor("_Color",gray);block.SetColor(ThingEmission,Color.black);}
                blocks[i]=block;
            }
            receiveShadows=source.receiveShadows;shadows=source.shadowCastingMode;lights=source.lightProbeUsage;reflections=source.reflectionProbeUsage;
        }
        private const string ThingEmission="_EmissionColor";
        internal static void Apply(MeshRenderer renderer)
        {
            if(materials==null)throw new InvalidOperationException("APC surfaces not initialized");
            renderer.sharedMaterials=materials;renderer.SetPropertyBlock(global);
            for(int i=0;i<2;i++)renderer.SetPropertyBlock(blocks[i],i);
            bool contacts=renderer.name=="BatteryContactPads";
            renderer.receiveShadows=contacts?false:receiveShadows;renderer.shadowCastingMode=contacts?ShadowCastingMode.Off:shadows;
            renderer.lightProbeUsage=lights;renderer.reflectionProbeUsage=reflections;
        }
    }
}
