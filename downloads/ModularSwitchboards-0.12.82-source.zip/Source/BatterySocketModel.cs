using System;
using System.IO;
using System.Collections.Generic;
using UnityEngine;
namespace ModularSwitchboards
{
    // A new closed cup, rather than cropped fragments of the original APC mesh.
    internal static class BatterySocketModel
    {
        internal static float OuterSize=>ApcBatteryRegion.SocketHeight+.006f;
        internal static Mesh Build()=>Build(new Vector3(-.0968359262f,-.115021147f,.129955426f),ApcBatteryRegion.FitScale(new Vector3(ApcBatteryRegion.NativeSocketHeight,ApcBatteryRegion.NativeSocketHeight,0)));
        internal static Mesh Build(Vector3 sourceCenter,float scale,int surface=-1)
        {
            var v=new List<Vector3>();var n=new List<Vector3>();var t=new[]{new List<int>(),new List<int>()};
            if(surface<0||surface==0)
            {
                float outer=OuterSize*.5f,inner=ApcBatteryRegion.SocketHeight*.5f;
                var outside=Ring(outer,0);var inside=Ring(inner,.0008f);
                float floor=ApcBatteryRegion.Map(new Vector3(0,0,.1343413f),sourceCenter,0,scale).z;
                float rear=floor-.0015f,front=ApcBatteryRegion.RimPlane,cx=DinBatteryLayout.CenterX;
                for(int i=0;i<8;i++)
                {
                    int j=(i+1)%8;var a=At(outside[i],rear);var b=At(outside[j],rear);
                    var af=At(outside[i],front);var bf=At(outside[j],front);
                    var c=At(inside[i],floor);var d=At(inside[j],floor);
                    var cf=At(inside[i],front);var df=At(inside[j],front);
                    var outward=new Vector3((a.x+b.x)*.5f-cx,(a.y+b.y)*.5f,0);
                    var inward=new Vector3(cx-(c.x+d.x)*.5f,-(c.y+d.y)*.5f,0);
                    Quad(v,n,t[0],a,b,bf,af,outward);
                    Quad(v,n,t[0],c,cf,df,d,inward);
                    Quad(v,n,t[0],af,bf,df,cf,Vector3.forward);
                    Triangle(v,n,t[0],new Vector3(cx,0,floor),c,d,Vector3.forward);
                    Triangle(v,n,t[0],new Vector3(cx,0,rear),a,b,Vector3.back);
                }
            }
            var mesh=new Mesh{name="Switchboards.ClosedBatteryCup82"};mesh.SetVertices(v);mesh.SetNormals(n);mesh.subMeshCount=2;
            for(int i=0;i<2;i++)mesh.SetTriangles(t[i],i);
            var uv=new List<Vector2>();
            if(v.Count>0){CabinetGeometry.ApplyNativeUv(mesh);uv.AddRange(mesh.uv);}
            if(surface<0||surface==1)
            {
                using(var stream=typeof(BatterySocketModel).Assembly.GetManifestResourceStream("ModularSwitchboards.BatterySocket.meshbin"))
                using(var reader=new BinaryReader(stream??throw new InvalidOperationException("Original APC contacts missing")))
                {
                    if(new string(reader.ReadChars(4))!="BS02"||reader.ReadInt32()!=134)throw new InvalidDataException("Invalid native APC contact resource");
                    for(int i=0;i<134;i++)
                    {
                        int role=reader.ReadByte();var p=new Vector3[3];var q=new Vector2[3];
                        for(int k=0;k<3;k++){
                            p[k]=ApcBatteryRegion.Map(new Vector3(reader.ReadSingle(),reader.ReadSingle(),reader.ReadSingle()),sourceCenter,0,scale);
                            q[k]=new Vector2(reader.ReadSingle(),reader.ReadSingle());
                        }
                        if(role!=1)continue;
                        int start=v.Count;var normal=Vector3.Cross(p[1]-p[0],p[2]-p[0]).normalized;
                        v.AddRange(p);uv.AddRange(q);n.AddRange(new[]{normal,normal,normal});t[1].AddRange(new[]{start,start+1,start+2});
                    }
                }
            }
            mesh.SetVertices(v);mesh.SetNormals(n);mesh.SetUVs(0,uv);
            for(int i=0;i<2;i++)mesh.SetTriangles(t[i],i);mesh.RecalculateBounds();return mesh;
        }

        private static Vector3[] Ring(float half,float cut)
        {
            float x=half/DinBreakerModel.VisualScale.x,y=half/DinBreakerModel.VisualScale.y;
            float rx=cut/DinBreakerModel.VisualScale.x,ry=cut/DinBreakerModel.VisualScale.y,cx=DinBatteryLayout.CenterX;
            return new[]{new Vector3(cx-x+rx,-y,0),new Vector3(cx+x-rx,-y,0),new Vector3(cx+x,-y+ry,0),new Vector3(cx+x,y-ry,0),
                new Vector3(cx+x-rx,y,0),new Vector3(cx-x+rx,y,0),new Vector3(cx-x,y-ry,0),new Vector3(cx-x,-y+ry,0)};
        }
        private static Vector3 At(Vector3 p,float z)=>new Vector3(p.x,p.y,z);
        private static void Quad(List<Vector3> v,List<Vector3> n,List<int> t,Vector3 a,Vector3 b,Vector3 c,Vector3 d,Vector3 desired)
        {Triangle(v,n,t,a,b,c,desired);Triangle(v,n,t,a,c,d,desired);}
        private static void Triangle(List<Vector3> v,List<Vector3> n,List<int> t,Vector3 a,Vector3 b,Vector3 c,Vector3 desired)
        {
            var cross=Vector3.Cross(b-a,c-a);if(cross.x*cross.x+cross.y*cross.y+cross.z*cross.z<1e-20f)return;
            if(cross.x*desired.x+cross.y*desired.y+cross.z*desired.z<0){var swap=b;b=c;c=swap;cross=Vector3.Cross(b-a,c-a);}
            int start=v.Count;v.AddRange(new[]{a,b,c});var normal=cross.normalized;n.AddRange(new[]{normal,normal,normal});t.AddRange(new[]{start,start+1,start+2});
        }
    }
}
