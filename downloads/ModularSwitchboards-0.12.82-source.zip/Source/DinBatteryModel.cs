using System.Collections.Generic;
using System.Linq;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Items;
using UnityEngine;
using Rendering;
using Assets.Scripts.UI;

namespace ModularSwitchboards
{
    internal static class DinBatteryModel
    {
        internal static Mesh Build()
        {
            // Build the actual breaker casing at two-position width. The builder
            // omits spindle bearings and cuts only the native battery aperture.
            ApcBatteryGeometry.EnsureLoaded();
            float opening=BatterySocketModel.OuterSize;
            return DinBreakerModel.Build(DinBatteryLayout.Width,DinBatteryLayout.CenterX,true,opening/DinBreakerModel.VisualScale.x,opening/DinBreakerModel.VisualScale.y,true);
        }
        internal static void Install(DinBreaker module)
        {
            var oldView=module.GetComponent<BreakerSwitchView>();if(oldView!=null)Object.DestroyImmediate(oldView);
            var model=module.transform.Find("DinBreakerModel");
            foreach(string name in new[]{"BreakerLever","BreakerControl","BreakerIndicator"}){var child=model.Find(name);if(child!=null)Object.DestroyImmediate(child.gameObject);}
            var mesh=Build();model.GetComponent<MeshFilter>().sharedMesh=mesh;
            var bayMesh=ApcBatteryGeometry.Install(model);
            var body=model.GetComponent<BoxCollider>();body.center=mesh.bounds.center;body.size=mesh.bounds.size;
            var action=new GameObject("BatteryControl"){layer=module.gameObject.layer};action.transform.SetParent(model,false);
            var collider=action.AddComponent<BoxCollider>();collider.center=ApcBatteryGeometry.HitBounds.center;collider.size=ApcBatteryGeometry.HitBounds.size;
            var toggle=new Interactable{Parent=module,Action=InteractableType.Slot1,Collider=collider,JoinInProgressSync=true,CanKeyInteract=true,KeyMap="PrimaryAction"};
            module.Slots=new List<Slot>{ApcBatteryGeometry.CreateSlot(module,model,collider,toggle)};
            module.Interactables=new List<Interactable>{toggle};module.HasOnOffState=false;
            module.BuildStates[0].Interactables=module.Interactables;module.BuildStates[0].Colliders=new List<Collider>{body,collider};
            var bounds=mesh.bounds;bounds.Encapsulate(bayMesh.bounds);bounds.Encapsulate(new Bounds(collider.center,collider.size));
            module.Bounds=new Bounds(Vector3.Scale(bounds.center,model.localScale),Vector3.Scale(bounds.size,model.localScale));module.SurfaceArea=.016f*module.ModuleWidth;
            module.GridBounds=new GridBounds(module);
            var ghost=module.Blueprint.GetComponent<MeshFilter>().sharedMesh;ghost.Clear();
            var pieces=Enumerable.Range(0,5).Select(i=>new CombineInstance{mesh=mesh,subMeshIndex=i,transform=Matrix4x4.Scale(model.localScale)}).ToList();
            for(int i=0;i<bayMesh.subMeshCount;i++)pieces.Add(new CombineInstance{mesh=bayMesh,subMeshIndex=i,transform=Matrix4x4.Scale(model.localScale)});
            ghost.CombineMeshes(pieces.ToArray(),true,true);ghost.RecalculateBounds();
            module.Blueprint.GetComponent<Wireframe>().BlueprintBounds=ghost.bounds;
            var view=module.gameObject.AddComponent<DinBatteryView>();view.Owner=module;
        }
    }

    // The real cell stays in the native-style slot. Its own renderer/material
    // state machinery handles type, charge colours and critical blinking.
    public sealed class DinBatteryView:MonoBehaviour
    {
        public DinBreaker Owner;
        private BatteryCell previous;
        private bool previousVisible;
        private int diagnosticDelay;
        private void LateUpdate()
        {
            if(Owner==null)return;
            var cell=Owner.Battery;
            bool show=CabinetWiring.CabinetOf(Owner)?.IsOpen==true;
            if(Owner.Slots.Count==1)Owner.Slots[0].HidesOccupant=!show;
            if(diagnosticDelay>0&&--diagnosticDelay==0&&show)BatteryAppearanceDiagnostics.Capture(Owner);
            if(ReferenceEquals(cell,previous)&&show==previousVisible)return;
            if(show)diagnosticDelay=3;
            previous=cell;previousVisible=show;
            if(cell!=null)cell.SetVisibility(show);
        }
    }
}
