# Local1.0.102 — grey rear shell plus rounded skeleton (not uploaded)

User confirmed: first stage should retain the grey rear shell with our rounded frame instead of the protruding box; white panels/doors in the second stage.

CabinetRearShell.Install runs immediately after CabinetSkeleton.Install, after Medium geometry. Append copies only existing CompletedShell/Housing role1 (integrated rear) into the private Frame mesh, preserving exact vertex coordinates, normals, UVs and triangle material roles. Both native frame role4 and rear role1 remain separate. Restore rear renderer material/MPB using CabinetRearSurface.Restore and same matte processing as finished housing. The separate NativeApcRearBox is not sourced or moved; it remains under CompletedShell and is absent in stage0. Finished housing untouched.

Update ProfiledFrameCollider.sharedMesh to the exact combined Frame mesh. Existing state0 ownership, CabinetFrameSelection and CabinetPreview actual-frame path provide collision/selection/green-preview for grey rear+frame, no new broad invisible target. Destroy only the private skeleton mesh built immediately before append; shared housing and original assets untouched. Frame renderer remains only in stage0 so finished rear is not doubled. Recipes/costs unchanged.

Frame/MediumFrame icons rendered from actual C# combined geometry exports, native-grey-style icon material separated from frame; inspected. Accepted preview material helpers and skeleton profile builder unchanged.

Native-reference Release build:0 warnings/errors. 14818 production Append checks with stubs using actual embedded housing for Small/Medium: only role1 selected, exact native triangles/positions/normals/UV remapping, original skeleton channels/indices preserved, no white panels/forward casing, expected rear depth, source asset immutability. Previous1.0.101 skeleton shape checks apply to byte-unchanged skeleton code. Native actual material output/raycast/save/load/MP still need gameplay confirmation.
