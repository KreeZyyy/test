"""Offline gravity-directed surface placement against actual triangles, with no dynamic ejections.
Each candidate descends onto visible geometry/floor, then exact triangle overlap is rejected.
"""
import bpy,json,sys,random,math
from pathlib import Path
from mathutils import Vector,Matrix
from mathutils.bvhtree import BVHTree
args=sys.argv[sys.argv.index('--')+1:];source=Path(args[0]);target=Path(args[1]);data=json.loads(source.read_text());rng=random.Random(data.get('seed',1317))
parts=data['parts'];floor=.072;scene_v=[];scene_t=[];scene_tree=None;out=[]
# Keep the wide display visible near the top of the module pile.
if data['kind']=='ModuleKit':parts=sorted(parts,key=lambda p:p['metadata'].get('type')==3)
def triangles(d):return [tuple(t[i:i+3])for t in d['triangles'].values()for i in range(0,len(t),3)]
def fits(points):return all(abs(p.x)<=.207 and abs(p.z)<=.207 and abs(p.x)+abs(p.z)<=.375 for p in points)
def tree_of(v,t):return BVHTree.FromPolygons(v,t,all_triangles=True)
for index,part in enumerate(parts):
 d=part['mesh'];local=[Vector(p)for p in d['vertices']];tri=triangles(d);candidates=[]
 for attempt in range(1000 if data['kind']=='RailKit'else 240):
  yaw=rng.uniform(-math.pi,math.pi);rot=Matrix.Rotation(yaw,4,'Y');x,z=rng.uniform(-.14,.14),rng.uniform(-.14,.14)
  v=[rot@p+Vector((x,0,z))for p in local]
  if not fits(v):continue
  body=tree_of(v,tri);lo=[min(p[k]for p in v)for k in range(3)];hi=[max(p[k]for p in v)for k in range(3)]
  # Include regular surface samples plus every projected vertex. Narrow edge details
  # missed by the grid are handled by exact mesh-overlap rejection below.
  samples={(round(p.x,7),round(p.z,7))for p in v}
  nx=max(1,math.ceil((hi[0]-lo[0])/.006));nz=max(1,math.ceil((hi[2]-lo[2])/.006))
  samples.update((lo[0]+(hi[0]-lo[0])*i/nx,lo[2]+(hi[2]-lo[2])*j/nz)for i in range(nx+1)for j in range(nz+1))
  shift=floor-lo[1]
  for xx,zz in samples:
   rear=body.ray_cast(Vector((xx,lo[1]-.01,zz)),Vector((0,1,0)))
   if rear[0]is None:continue
   top=floor
   if scene_tree is not None:
    hit=scene_tree.ray_cast(Vector((xx,1.2,zz)),Vector((0,-1,0)))
    if hit[0]is not None:top=max(top,hit[0].y)
   shift=max(shift,top-rear[0].y)
  shift+=.001
  # Exact triangle test catches thin lips between samples. Accept only a nearby,
  # nonintersecting contact, never lift a piece far enough to create a visible gap.
  for correction in range(45 if data['kind']=='RailKit'else 7):
   world=[p+Vector((0,shift,0))for p in v];bt=tree_of(world,tri)
   if scene_tree is None or not bt.overlap(scene_tree):break
   shift+=.0005
  else:continue
  high=hi[1]+shift
  if high>(.510 if data['kind']=='ModuleKit'else .480):continue
  mat=Matrix.Translation((x,shift,z))@rot
  candidates.append((high,world,mat,bt,shift))
  if len(candidates)>=10:break
 assert candidates,('No supported nonintersecting pose',part['name'])
 candidates.sort(key=lambda c:c[0]);high,world,mat,bt,shift=candidates[0]
 offset=len(scene_v);scene_v.extend(world);scene_t.extend(tuple(offset+i for i in t)for t in tri);scene_tree=tree_of(scene_v,scene_t)
 out.append({'name':part['name'],'mesh':{'vertices':[list(p)for p in world],'triangles':d['triangles']},'matrix':[list(r)for r in mat],'metadata':part.get('metadata',{})})
 print('Supported',data['kind'],index+1,'/',len(parts),'height',round(high,3),flush=True)
target.write_text(json.dumps({'kind':data['kind'],'seed':data.get('seed',1317),'frames':0,'method':'gravity-directed visible surface placement; exact triangle nonintersection','parts':out}));print('Baked',target,flush=True)
