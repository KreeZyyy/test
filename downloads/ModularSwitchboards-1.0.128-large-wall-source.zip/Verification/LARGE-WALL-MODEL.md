# Modular Switchboards 1.0.128 — wall-mounted floor-height Large model

Separate model prototype. Dedicated-server candidate1.0.127 stays separate; this branch is not a replacement for that DS test.

Large uses vanilla Locker dimensions but our Medium-style body, twin doors and interior. It mounts on a wall like Small/Medium rather than using Locker floor placement. The lower grey base/front band is recessed35mm behind the housing front, inside the existing body envelope; no platform underneath. Doors stop above it. There are no external power sockets, electrical endpoints or fixed terminal blocks yet.

Placement: choose the wall grid point1metre above the intended floor. The model's bottom is1metre below its mounting point, independent of native Locker height. Its rear plane is shifted out by the authored rear extrusion depth so it clears the measured wall face. The native grid root stays fixed; the ghost uses the same wall offset. Actual floor skin, wall fit and appearance still require in-game testing; this is not automatic terrain/floor detection.

Four DIN rows/cover/door boards retained for layout testing. Original module sizes and pitch are unchanged. Prototype price remains6cabinetkits +10PlasticSheets, optional Large cover4kits. Thumbnail still Medium. Core access repair from126 is included to avoid regressing the slot while testing the model.

Validation: full native-reference build0warnings/errors;222Large layout/wall-anchor/base-envelope/cover-save checks across9dimension profiles. Small/Medium layouts and prices remain unchanged. Actual Unity appearance/collision/placement remains unverified. No Steam Workshop update.

