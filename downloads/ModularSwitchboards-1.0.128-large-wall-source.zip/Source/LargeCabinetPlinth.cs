using System.Collections.Generic;
using UnityEngine;
namespace ModularSwitchboards
{
    // The base is a lower part of the cabinet, inside the Locker envelope.
    // No separate plate/block is added underneath the enclosure.
    internal static class LargeCabinetPlinth
    {
        internal static void Install(SwitchboardCabinet host)
        {
            var model=host.transform.Find("SwitchboardModel");var shell=model.Find("CompletedShell");
            var housing=shell.Find("Housing").GetComponent<MeshFilter>();
            var bounds=LargeCabinetDimensions.LowerBodyBand(housing.sharedMesh.bounds);
            var points=new List<Vector3>();var normals=new List<Vector3>();var indices=new List<int>();
            RoundedGeometry.Box(points,normals,indices,bounds.center,bounds.size,.004f);
            var band=new Mesh{name="Switchboards.LargeIntegralBase"};band.SetVertices(points);band.SetNormals(normals);band.subMeshCount=CabinetGeometry.Materials.Length;
            for(int role=0;role<band.subMeshCount;role++)band.SetTriangles(role==CabinetRearSurface.Role?indices:new List<int>(),role);
            CabinetGeometry.ApplyNativeUv(band);CabinetRearSurface.ApplyUv(band);band.RecalculateBounds();
            var oldHousing=housing.sharedMesh;housing.sharedMesh=Append(oldHousing,band,CabinetRearSurface.Role);
            shell.Find("RoundedHousingCollider").GetComponent<MeshCollider>().sharedMesh=housing.sharedMesh;
            var frame=model.Find("Frame").GetComponent<MeshFilter>();var oldFrame=frame.sharedMesh;
            frame.sharedMesh=Append(oldFrame,band,CabinetRearSurface.Role);
            model.Find("ProfiledFrameCollider").GetComponent<MeshCollider>().sharedMesh=frame.sharedMesh;
            foreach(var hingeName in new[]{"DoorHinge","RightDoorHinge"})
            {
                var hinge=shell.Find(hingeName);var filter=hinge.Find("Door").GetComponent<MeshFilter>();
                var mesh=UnityEngine.Object.Instantiate(filter.sharedMesh);mesh.name="Large.DoorAboveIntegralBase";
                float bottom=mesh.bounds.min.y;var vertices=mesh.vertices;
                for(int i=0;i<vertices.Length;i++)vertices[i].y+=LargeCabinetDimensions.BaseHeight*Mathf.Clamp01((bottom+.14f-vertices[i].y)/.14f);
                mesh.vertices=vertices;mesh.RecalculateNormals();mesh.RecalculateTangents();mesh.RecalculateBounds();filter.sharedMesh=mesh;
                hinge.Find("DoorCollider").GetComponent<MeshCollider>().sharedMesh=mesh;
            }
            UnityEngine.Object.DestroyImmediate(oldHousing);UnityEngine.Object.DestroyImmediate(oldFrame);UnityEngine.Object.DestroyImmediate(band);
        }
        private static Mesh Append(Mesh original,Mesh band,int targetRole)
        {
            var points=new List<Vector3>(original.vertices);var normals=new List<Vector3>(original.normals);var uv=new List<Vector2>(original.uv);
            int start=points.Count;points.AddRange(band.vertices);normals.AddRange(band.normals);uv.AddRange(band.uv);
            var mesh=new Mesh{name="Switchboards.CabinetWithIntegralBase",indexFormat=UnityEngine.Rendering.IndexFormat.UInt32};
            mesh.SetVertices(points);mesh.SetNormals(normals);mesh.SetUVs(0,uv);mesh.subMeshCount=original.subMeshCount;
            for(int role=0;role<mesh.subMeshCount;role++)
            {
                var triangles=new List<int>(original.GetTriangles(role));
                if(role==targetRole)foreach(var index in band.GetTriangles(CabinetRearSurface.Role))triangles.Add(start+index);
                mesh.SetTriangles(triangles,role);
            }
            if(targetRole==0){CabinetGeometry.ApplyNativeUv(mesh);CabinetRearSurface.ApplyUv(mesh);}
            mesh.RecalculateBounds();return mesh;
        }
    }
}
