using System;
using System.Linq;
using Assets.Scripts.Objects;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class CabinetShape
    {
        internal static bool Large(string name)=>name=="StructureModularSwitchboardLarge";
        internal static bool Medium(string name)=>Large(name)||name==SwitchboardsMod.MediumCabinetName||name==SwitchboardsMod.MediumReverseCabinetName||name==SwitchboardsMod.MediumCombinerName||name==SwitchboardsMod.MediumCombinerReverseName;
        internal static int FrameKits(string name)=>Large(name)?6:Medium(name)?3:1;
        internal static int PlasticSheets(string name)=>Large(name)?10:Medium(name)?5:2;
        internal static float Width(string name)=>Large(name)?LargeCabinetDimensions.Width:Medium(name)?.8f:.4f;
        internal static float Height(string name)=>Large(name)?LargeCabinetDimensions.Height:Medium(name)?1f:.5f;
        internal static float OffsetY(string name)=>Large(name)?LargeCabinetDimensions.WallCenterY:0;
        internal static float RailWidth(string name)=>Large(name)?LargeCabinetDimensions.Width-.15f:Medium(name)?.65f:DinLayout.CabinetInnerWidth;
        internal static float DoorBridgeShift(string name)=>Medium(name)?.010f:0f;
        internal static float BridgeInset(string name)=>Medium(name)?.043f:.023f;
        internal static float InnerWidth(string name)=>Width(name)-.05f;
        internal static int[] Rows(string name)=>Large(name)?LargeCabinetDimensions.Rows:Medium(name)?new[]{-150,0,150}:new[]{-60,60};
        internal static int SnapRow(string name,int value)=>Rows(name).OrderBy(y=>Math.Abs(y-value)).First();
        internal static float HalfSpan(string name)=>(DinLayout.FullModuleCount(RailWidth(name))-1)*DinLayout.SlotPitch*.5f;
        // Physical socket count on the branched side (inputs on collectors).
        internal static int OutputCount(string name)=>Medium(name)?3:2;
        internal static ConnectionRole OutputRole(int index)=>index==0?ConnectionRole.Output:index==1?ConnectionRole.Output2:ConnectionRole.Waste;
        internal static int MinDoorY(string name)=>Large(name)?-(int)Math.Floor((Height(name)*.5f-.18f)/DoorModuleLayout.Pitch)*10:Medium(name)?-20:-10;
        internal static int MaxDoorY(string name)=>Large(name)?-MinDoorY(name):10;
        internal static int MinBridgeY(string name)=>Large(name)?-(int)Math.Floor((Height(name)*.5f-.10f)/DoorModuleLayout.Spacing)*10:Medium(name)?-190:-90;
        internal static int MaxBridgeY(string name)=>Large(name)?-MinBridgeY(name):Medium(name)?180:80;
        internal static float TerminalY(string name)=>Large(name)?Height(name)*.5f-.08f:Medium(name)?.44f:.211f;
        internal static Vector3 Terminal(string name,int index)
            =>Large(name)?new Vector3((index-1.5f)*(Width(name)-.20f)/3f,TerminalY(name),.014f):index==0?new Vector3(0,TerminalY(name),.014f):new Vector3(Medium(name)?(index==1?.23f:index==2?0:-.23f):(index==1?.108f:-.108f),-TerminalY(name),.014f);
    }
}
