using System;
using System.Linq;
using System.Collections.Generic;
using Assets.Scripts;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Electrical;
using Assets.Scripts.Objects.Motherboards;
using Assets.Scripts.UI;
using Assets.Scripts.Util;
using HarmonyLib;
using Rendering;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class DinTransformerModel
    {
        internal static void Install(DinTransformer owner,Transformer source,Transform storage)
        {
            // Only native settings/interaction semantics are reused. Every visible
            // surface is our own mesh; no native transformer model or switch remains.
            if(source.PrefabName!="StructureTransformerSmall")throw new InvalidOperationException("Small transformer reference required.");
            foreach(var a in owner.GetComponentsInChildren<Animator>(true))UnityEngine.Object.DestroyImmediate(a);
            foreach(var r in owner.GetComponentsInChildren<Renderer>(true))UnityEngine.Object.DestroyImmediate(r);
            foreach(var f in owner.GetComponentsInChildren<MeshFilter>(true))UnityEngine.Object.DestroyImmediate(f);
            foreach(var c in owner.GetComponentsInChildren<Collider>(true))UnityEngine.Object.DestroyImmediate(c);
            foreach(var child in owner.transform.Cast<Transform>().ToArray())UnityEngine.Object.DestroyImmediate(child.gameObject);
            owner.BaseAnimator=null;owner.Renderers=new List<ThingRenderer>();owner._staticColliders=new List<Collider>();owner._dynamicColliders=new List<Collider>();owner._selfColliders=new List<Collider>();owner.Slots=new List<Slot>();owner.OpenEnds=new List<Connection>();owner.InputConnection=null;owner.OutputConnection=null;owner.InputNetwork=null;owner.OutputNetwork=null;owner.CustomNavMeshFilter=null;owner.ForceGridBounds.Clear();owner.BrokenBuildStates=new List<BrokenBuildState>();owner.UseCellPosition=false;owner.StructureCollisionType=CollisionType.BlockCustom;owner.SelectionDisplay=SelectionHighlightMethod.Bounds;owner.HasColorState=false;owner.MPBRenderers.Clear();owner.UsedPower=0;
            foreach(string field in new[]{"switchOnOff","activateButton","leverAnimationComponent","MaterialChanger"})AccessTools.Field(typeof(Thing),field).SetValue(owner,null);
            owner.AnimComponents=new List<Effects.StateMaterialChanger>();
            owner.CustomColor=GameManager.GetColorSwatch((int)ColorType.White);owner.PaintableMaterial=owner.CustomColor.Normal;
            var root=new GameObject("DinBreakerModel"){layer=owner.gameObject.layer};root.transform.SetParent(owner.transform,false);root.transform.localScale=DinBreakerModel.VisualScale;
            var body=TransformerPanelLayout.Body();root.AddComponent<MeshFilter>().sharedMesh=body;var caseRenderer=root.AddComponent<MeshRenderer>();caseRenderer.sharedMaterials=CabinetGeometry.Materials;
            var caseHit=root.AddComponent<BoxCollider>();caseHit.center=body.bounds.center;caseHit.size=body.bounds.size;
            var face=Part(owner,"TransformerFront",TransformerFrontGeometry.Face());
            var dial=Part(owner,"TransformerDial",TransformerFrontGeometry.Knob());
            dial.transform.localPosition=TransformerFrontGeometry.KnobCenter;dial.transform.localRotation=Quaternion.Euler(-90,0,0);owner.Needle=dial.gameObject;
            owner.NeedleMinimum=source.NeedleMinimum;owner.NeedleMaximum=source.NeedleMaximum;
            owner.StepSmall=source.StepSmall;owner.StepNormal=source.StepNormal;
            owner.Interactables=new List<Interactable>();var hits=new List<Collider>{caseHit};
            foreach(var action in new[]{InteractableType.Button1,InteractableType.Button2})
            {
                var original=source.Interactables.Single(i=>i.Action==action);float radius=TransformerFrontGeometry.KnobRadius;
                var hitObject=new GameObject(action==InteractableType.Button1?"TransformerDecrease":"TransformerIncrease"){layer=owner.gameObject.layer};hitObject.transform.SetParent(owner.transform,false);
                var hit=hitObject.AddComponent<BoxCollider>();hit.center=TransformerFrontGeometry.KnobCenter+new Vector3(action==InteractableType.Button1?radius*.5f:-radius*.5f,0,.003f);hit.size=new Vector3(radius,radius*2,.009f);hits.Add(hit);
                owner.Interactables.Add(new Interactable{Parent=owner,Action=action,Collider=hit,CanKeyInteract=original.CanKeyInteract,KeyMap=original.KeyMap,JoinInProgressSync=true,AssociatedAudioEvents=new List<Assets.Scripts.Sound.GameAudioEvent>()});
            }
            foreach(var action in new[]{InteractableType.Powered,InteractableType.Error})owner.Interactables.Add(new Interactable{Parent=owner,Action=action,JoinInProgressSync=true});
            // Entry coordinates route cables; front screw coordinates select IN/OUT.
            float center=TransformerPanelLayout.CenterX/DinBreakerModel.VisualScale.x;
            owner.InternalInput=Vector3.Scale(new Vector3(center,WireContactLayout.BreakerEntryY,WireContactLayout.BreakerEntryZ),DinBreakerModel.VisualScale);
            owner.InternalOutput=Vector3.Scale(new Vector3(center,-WireContactLayout.BreakerEntryY,WireContactLayout.BreakerEntryZ),DinBreakerModel.VisualScale);
            owner.InternalInputAim=Vector3.Scale(new Vector3(center,WireContactLayout.BreakerScrewY,WireContactLayout.BreakerScrewZ),DinBreakerModel.VisualScale);
            owner.InternalOutputAim=Vector3.Scale(new Vector3(center,-WireContactLayout.BreakerScrewY,WireContactLayout.BreakerScrewZ),DinBreakerModel.VisualScale);
            var state=owner.BuildStates[0];state.Visualizer=caseRenderer;state.StateMeshes=new List<Mesh>();state.RendererInstance=null;state.Colliders=hits;state.Interactables=owner.Interactables;state.LinkedGameObjects=new List<GameObject>();state.RenderMode=BuildStateRenderMode.OnMyState;AccessTools.Field(typeof(BuildState),"initialDrawData").SetValue(state,new DrawData{mesh=null,materials=new Material[0]});
            owner.CacheStates(true);owner.Setting=source.Setting;DinBreakerModel.Refresh(owner);
            var all=ModelBlueprint.Build(owner.transform);owner.Bounds=all.bounds;owner.GridBounds=new GridBounds(owner);owner.SurfaceArea=.032f;
            owner.Thumbnail=CabinetIcons.Get("DinTransformer");owner.Thumbnails=new Sprite[0];state.Thumbnail=owner.Thumbnail;
            var bp=new GameObject("DinTransformerBlueprint"){layer=owner.gameObject.layer};bp.transform.SetParent(storage,false);var filter=bp.AddComponent<MeshFilter>();filter.sharedMesh=all;var renderer=bp.AddComponent<MeshRenderer>();renderer.sharedMaterial=CabinetGeometry.Materials[4];var wire=bp.AddComponent<Wireframe>();wire.BlueprintTransform=bp.transform;wire.BlueprintBounds=all.bounds;wire.BlueprintMeshFilter=filter;wire.BlueprintRenderer=renderer;bp.AddComponent<CabinetBlueprint>();owner.Blueprint=bp;owner.BlueprintOrientVector=Vector3.zero;
            Debug.Log("[Modular Switchboards] Own two-position transformer body/front installed; centered native-Setting dial, no ON/OFF control; maximum="+owner.OutputMaximum+" W.");
        }
        private static MeshRenderer Part(DinTransformer owner,string name,Mesh mesh)
        {
            var go=new GameObject(name){layer=owner.gameObject.layer};go.transform.SetParent(owner.transform,false);go.AddComponent<MeshFilter>().sharedMesh=mesh;var renderer=go.AddComponent<MeshRenderer>();renderer.sharedMaterials=TransformerFrontSurface.Materials;return renderer;
        }
    }
}
