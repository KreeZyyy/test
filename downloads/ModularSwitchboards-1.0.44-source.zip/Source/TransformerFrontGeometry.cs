using System;
using System.Collections.Generic;
using UnityEngine;
namespace ModularSwitchboards
{
    // Original geometry inspired by the measured small transformer reference.
    // All dimensions below are metres in uniform front coordinates, not body scale.
    internal static class TransformerFrontGeometry
    {
        internal const float KnobRadius=.0108f,KnobDepth=.0045f;
        internal static readonly Vector3 KnobCenter=new Vector3(TransformerPanelLayout.CenterX,.011f,.077f);
        internal static Mesh Face()
        {
            var v=new List<Vector3>();var n=new List<Vector3>();var t=Groups();
            Action<Vector3,Vector3,int,float> box=(p,s,r,b)=>RoundedGeometry.Box(v,n,t[r],p,s,b);
            float x=TransformerPanelLayout.CenterX;
            // One gray plate, a shallow dark coil seat, six copper winding ribs.
            box(new Vector3(x,0,.0745f),new Vector3(.071f,.055f,.0018f),0,.0013f);
            box(new Vector3(x,-.013f,.076f),new Vector3(.060f,.023f,.0012f),3,.001f);
            for(int i=0;i<6;i++)box(new Vector3(x,-.0038f-i*.0036f,.0774f),new Vector3(.055f,.0028f,.0032f),2,.001f);
            foreach(float side in new[]{-1f,1f})box(new Vector3(x,-.013f+side*.0118f,.078f),new Vector3(.061f,.0012f,.002f),1,.0003f);
            // Tick positions follow the native -160..+160 degree dial range.
            for(int i=0;i<=8;i++)
            {
                float angle=(-160+i*40)*Mathf.Deg2Rad;
                float radius=.014f;
                box(new Vector3(x+Mathf.Sin(angle)*radius,KnobCenter.y+Mathf.Cos(angle)*radius,.07605f),new Vector3(.0011f,.0011f,.0005f),4,.00015f);
            }
            return Finish("Switchboards.OwnTransformerFace",v,n,t);
        }
        internal static Mesh Knob()
        {
            var v=new List<Vector3>();var n=new List<Vector3>();var t=Groups();
            // Local -Y faces the player after the authored -90 degree X pose.
            // Native Transformer.SetKnob rotates around local Y without custom tick code.
            const int sides=20;
            for(int i=0;i<sides;i++)
            {
                float a=i*2*Mathf.PI/sides,b=(i+1)*2*Mathf.PI/sides;
                float ra=KnobRadius*(i%2==0?1f:.94f),rb=KnobRadius*((i+1)%2==0?1f:.94f);
                var p=new Vector3(Mathf.Sin(a)*ra,0,Mathf.Cos(a)*ra);var q=new Vector3(Mathf.Sin(b)*rb,0,Mathf.Cos(b)*rb);
                var f=p+Vector3.down*KnobDepth;var g=q+Vector3.down*KnobDepth;
                Tri(v,n,t[1],p,f,g);Tri(v,n,t[1],p,g,q);
                Tri(v,n,t[1],Vector3.down*KnobDepth,g,f);
                Tri(v,n,t[1],Vector3.zero,p,q);
            }
            RoundedGeometry.Box(v,n,t[4],new Vector3(0,-KnobDepth-.0003f,.0065f),new Vector3(.0016f,.0005f,.0046f),.0002f);
            return Finish("Switchboards.OwnTransformerDial",v,n,t);
        }
        private static List<int>[] Groups(){var t=new List<int>[5];for(int i=0;i<t.Length;i++)t[i]=new List<int>();return t;}
        private static void Tri(List<Vector3> v,List<Vector3> n,List<int> ids,Vector3 a,Vector3 b,Vector3 c)
        {
            int i=v.Count;var normal=Vector3.Cross(b-a,c-a).normalized;v.Add(a);v.Add(b);v.Add(c);n.Add(normal);n.Add(normal);n.Add(normal);ids.Add(i);ids.Add(i+1);ids.Add(i+2);
        }
        private static Mesh Finish(string name,List<Vector3> v,List<Vector3> n,List<int>[] t)
        {
            var mesh=new Mesh{name=name};mesh.SetVertices(v);mesh.SetNormals(n);mesh.subMeshCount=t.Length;
            for(int i=0;i<t.Length;i++)mesh.SetTriangles(t[i],i);
            mesh.RecalculateBounds();return mesh;
        }
    }
}
