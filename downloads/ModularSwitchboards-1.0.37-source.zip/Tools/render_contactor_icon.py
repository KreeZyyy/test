"""Production contactor body/APC crop; preview approximates the game's atlas colours."""
import bpy,json,math
from pathlib import Path
from mathutils import Vector
root=Path(__file__).resolve().parents[1]
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
def mat(name,rgb):
 m=bpy.data.materials.new(name);m.diffuse_color=(*rgb,1);m.use_nodes=True;n=m.node_tree.nodes.get('Principled BSDF');n.inputs['Base Color'].default_value=(*rgb,1);n.inputs['Roughness'].default_value=.85;return m
white=mat('White casing',(.78,.81,.8));dark=mat('Dark fascia',(.035,.035,.035));gray=mat('Gray plastic slider',(.42,.45,.45));red=mat('Native OFF atlas approximation',(.48,.035,.035));green=mat('Native ON atlas approximation',(.035,.32,.07));black=mat('Native dark window',(.015,.020,.020))
palette=[gray,white,gray,dark,gray]
def point(p):return(-p[0]*2.25,-p[2]*1.15,p[1]*1.35)
data=json.loads((root/'Art/ContactorGeometry.json').read_text());sliders=[];shift=.0058
for name,part in data.items():
 if name not in ['body','guide','nativeWindow','slider','onPanel','offPanel']:continue
 faces=[];roles=[]
 for role,ids in part['triangles'].items():
  for i in range(0,len(ids),3):faces.append(ids[i:i+3]);roles.append(int(role))
 m=bpy.data.meshes.new(name);m.from_pydata([point(p)for p in part['vertices']],[],faces);m.update();o=bpy.data.objects.new(name,m);bpy.context.collection.objects.link(o)
 for material in palette+[red,green,black]:m.materials.append(material)
 if name=='slider':o.location.z=shift*1.35;sliders.append(o)
 for poly,r in zip(m.polygons,roles):
  if name in ['body','guide','slider']:poly.material_index=r;continue
  if name=='onPanel':poly.material_index=6;continue
  if name=='offPanel':poly.material_index=5;continue
  # No game texture assets are distributed. Native geometry/UVs are exact;
  # neutral background/letter colours below illustrate the original atlas.
  p=[part['vertices'][i]for i in poly.vertices];cy=sum(v[1]for v in p)/3;cz=sum(v[2]for v in p)/3
  poly.material_index=7
  if cz<.060:poly.material_index=1
  else:poly.material_index=3
def box(name,p,size,m):
 bpy.ops.mesh.primitive_cube_add(size=1,location=point(p));o=bpy.context.object;o.name=name;o.dimensions=(size[0]*2.25,size[2]*1.15,size[1]*1.35);o.data.materials.append(m);return o
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=32;scene.cycles.use_denoising=False;scene.render.film_transparent=True;scene.view_settings.view_transform='Standard';scene.world.color=(.22,.22,.22)
center=Vector(point((0,0,.031)));bpy.ops.object.camera_add(location=center+Vector((.07,-.31,.07)));cam=bpy.context.object;cam.rotation_euler=(center-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=.135;scene.camera=cam
for pos,power in [((.15,-.22,.25),2.5),((-.20,-.08,.10),.8)]:
 bpy.ops.object.light_add(type='AREA',location=pos);o=bpy.context.object;o.data.energy=power;o.data.size=.35;o.rotation_euler=(center-o.location).to_track_quat('-Z','Y').to_euler()
scene.render.resolution_percentage=100
for size,path in [(256,root/'Assets/Icons/DinContactor.png'),(640,root.parent/'DinContactor-1.0.37-OFF-preview.png')]:
 scene.render.resolution_x=size;scene.render.resolution_y=size;scene.render.filepath=str(path);bpy.ops.render.render(write_still=True)
for o in sliders:o.location.z-=2*shift*1.35
scene.render.filepath=str(root.parent/'DinContactor-1.0.37-ON-preview.png');bpy.ops.render.render(write_still=True)
