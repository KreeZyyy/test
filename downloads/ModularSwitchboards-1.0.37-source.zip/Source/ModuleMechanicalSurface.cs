using Assets.Scripts.Objects;
using UnityEngine;
namespace ModularSwitchboards
{
    // One opaque, unpainted light-gray plastic finish for the guide, slider and
    // closed native bearings. It cannot sample white regions of the APC atlas.
    internal static class ModuleMechanicalSurface
    {
        private static Material material;
        internal static void Apply(MeshRenderer renderer)
        {
            if(renderer==null)return;
            if(material==null)
            {
                var shader=Shader.Find("Standard");
                if(shader==null||!shader.isSupported)
                {
                    var fallback=new MaterialPropertyBlock();fallback.SetFloat(Thing.DiffuseIndexPropertyID,CabinetGeometry.PaletteIndices[4]);fallback.SetColor(Thing.EMISSION_COLOR,Color.black);renderer.SetPropertyBlock(fallback,4);return;
                }
                material=new Material(shader){name="Switchboards.LightGrayMechanism",color=new Color(.42f,.45f,.45f,1f)};
                material.SetFloat("_Glossiness",.25f);material.SetFloat("_Metallic",0f);
            }
            var materials=renderer.sharedMaterials;if(materials.Length<5)return;materials[4]=material;renderer.sharedMaterials=materials;
            var block=new MaterialPropertyBlock();block.SetColor("_Color",new Color(.42f,.45f,.45f,1f));block.SetColor("_EmissionColor",Color.black);renderer.SetPropertyBlock(block,4);
        }
        internal static void Restore(Thing owner)
        {
            foreach(var renderer in owner.GetComponentsInChildren<MeshRenderer>(true))
                if(renderer.name=="ContactorGuide"||renderer.name=="ContactorMechanicalSlider")Apply(renderer);
        }
    }
}
