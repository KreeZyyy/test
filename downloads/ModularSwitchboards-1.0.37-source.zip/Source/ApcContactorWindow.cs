using System;
using System.Linq;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Electrical;
using UnityEngine;
namespace ModularSwitchboards
{
    // Original flat APC rim and ON/OFF letter faces, with their UVs/materials.
    // The backing is our uninterrupted shell, without APC hinges or steps.
    internal static class ApcContactorWindow
    {
        internal const float Scale=.17f;
        internal static readonly Bounds Region=new Bounds(new Vector3(.069f,0,.184f),new Vector3(.154f,.30f,.032f));
        internal static Vector3 Map(Vector3 p)=>new Vector3((p.x-.069f)*Scale/DinBreakerModel.VisualScale.x,p.y*Scale/DinBreakerModel.VisualScale.y,.064f+(p.z-.198f)*Scale/DinBreakerModel.VisualScale.z);
        internal static Vector3 MapLegend(Vector3 p)
        {
            bool on=p.y>0;float nativeCenter=on?.111295f:-.113985f;
            return new Vector3((p.x-.069f)*Scale/DinBreakerModel.VisualScale.x,(on?.0063f:-.0063f)+(p.y-nativeCenter)*Scale/DinBreakerModel.VisualScale.y,.0598f);
        }
        internal static bool IsLegend(Vector3 a,Vector3 b,Vector3 c)=>Mathf.Abs(a.z-.17091f)<.00002f&&Mathf.Abs(b.z-.17091f)<.00002f&&Mathf.Abs(c.z-.17091f)<.00002f;
        internal static bool IsFlatRim(Vector3 a,Vector3 b,Vector3 c)=>Mathf.Abs(a.z-.198f)<.00002f&&Mathf.Abs(b.z-.198f)<.00002f&&Mathf.Abs(c.z-.198f)<.00002f;
        private static Mesh mesh;
        private static MeshRenderer source;
        internal static Mesh Build(Mesh original,Matrix4x4 frame)
        {
            // Only the flat front rim and original letter faces survive. Axles,
            // hinge blocks, sloped walls and the stepped APC backing are excluded.
            var result=NativeMeshCrop.Read(original,frame,Region,"Contactor.FlatAPCFrameAndLegends",(a,b,c)=>IsLegend(a,b,c)||IsFlatRim(a,b,c));
            if(result==null)throw new InvalidOperationException("Original APC flat frame/legends not found.");
            var sourcePoints=result.vertices;var points=new Vector3[sourcePoints.Length];
            for(int i=0;i<points.Length;i++)
            {
                if(Mathf.Abs(sourcePoints[i].z-.17091f)<.00002f)points[i]=MapLegend(sourcePoints[i]);
                else{points[i]=Map(sourcePoints[i]);points[i].z=.0644f;}
            }
            result.vertices=points;
            result.RecalculateNormals();result.RecalculateTangents();result.RecalculateBounds();return result;
        }
        internal static NativePortSurface Install(Transform parent)
        {
            if(mesh==null)
            {
                var apc=WorldManager.Instance.SourcePrefabs.OfType<AreaPowerControl>().First(p=>p.PrefabName=="StructureAreaPowerControl");
                source=apc.GetComponent<MeshRenderer>();
                var frame=Matrix4x4.Rotate(CabinetModel.FrontSign<0?Quaternion.Euler(0,180,0):Quaternion.identity)*apc.transform.worldToLocalMatrix*source.transform.localToWorldMatrix;
                mesh=Build(source.GetComponent<MeshFilter>().sharedMesh,frame);
            }
            var go=new GameObject("ContactorAPCWindow"){layer=parent.gameObject.layer};go.transform.SetParent(parent,false);
            go.AddComponent<MeshFilter>().sharedMesh=mesh;var renderer=go.AddComponent<MeshRenderer>();NativePortSurface.Capture(source,renderer);
            return go.GetComponent<NativePortSurface>();
        }
    }
}
