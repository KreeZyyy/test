using System;using System.Linq;using System.Collections.Generic;using ModularSwitchboards;using Assets.Scripts.Networks;
static class SingleBridgeHarness
{
 static int checks;static void Check(bool b,string why){checks++;if(!b)throw new Exception("Single bridge: "+why);}
 static CabinetWireSaveData W(CabinetWireEnd a,CabinetWireEnd b){WireCircuit.Orient(a,b,out var from,out var to);return new(){From=from,To=to};}
 internal static void Run()
 {
  Check(Enumerable.Range(-100,201).Count(y=>DoorModuleLayout.BridgeFits(0,y,0,0))==18,"18 individual grid positions");
  Check(!DoorModuleLayout.BridgeFits(10,0,0,0)&&!DoorModuleLayout.BridgeFits(0,0,1,0)&&!DoorModuleLayout.BridgeFits(0,0,0,1),"hinge-only grid");
  for(int y=-250;y<=250;y++)
  {
   int slot=DoorModuleLayout.SnapSlot(y,-90,80);
   Check(DoorModuleLayout.BridgeFits(0,slot,0,0),"snap always selects one of18 bridge slots");
   Check(Enumerable.Range(-9,18).All(i=>Math.Abs(y-slot)<=Math.Abs(y-i*10)),"snap selects nearest position including occupied positions");
   int ledSlot=DoorModuleLayout.SnapSlot(y,-10,10);
   Check(ledSlot==-10||ledSlot==0||ledSlot==10,"door snap stays in3x3 grid");
  }
  var ids=Enumerable.Range(900,18).Select(i=>(long)i).ToArray();
  var internalEdges=DoorModuleLayout.Through(Array.Empty<CabinetWireSaveData>(),ids).ToArray();
  for(int i=0;i<18;i++)for(int j=0;j<18;j++)
  {
   Check(WireCircuit.Reachable(new(ids[i],2),new(ids[j],3),internalEdges,Array.Empty<long>())==(i==j),"forward independence");
   Check(WireCircuit.Reachable(new(ids[i],3),new(ids[j],2),internalEdges,Array.Empty<long>())==(i==j),"reverse independence");
  }
  foreach(bool reverse in new[]{false,true})
  {
   var input=new CabinetWireEnd(0,0);var output=new CabinetWireEnd(0,1);var a=new CabinetWireEnd(900,reverse?3:2);var b=new CabinetWireEnd(900,reverse?2:3);
   var wires=new List<CabinetWireSaveData>{W(input,a),W(b,output)};
   var graph=DoorModuleLayout.Through(wires,new long[]{900}).ToArray();
   Check(WireCircuit.Reachable(input,output,graph,Array.Empty<long>()),"either bridge side can receive supply");
   Check(!WireCircuit.Reachable(output,input,graph,Array.Empty<long>()),"neutral bridge does not invent external backfeed");
   Check(WireCircuit.CanConnect(input,a,new List<CabinetWireSaveData>(),Array.Empty<long>(),out _,passages:new long[]{900}),"normal source to either neutral end");
   Check(WireCircuit.CanConnect(b,output,new List<CabinetWireSaveData>(),Array.Empty<long>(),out _,passages:new long[]{900}),"either neutral end to load");
  }
  var joined=new List<CabinetWireSaveData>{W(new(900,3),new(901,3))};
  Check(WireCircuit.Reachable(new(900,2),new(901,2),DoorModuleLayout.Through(joined,new long[]{900,901}),Array.Empty<long>()),"joined neutrals forward");
  Check(WireCircuit.Reachable(new(901,2),new(900,2),DoorModuleLayout.Through(joined,new long[]{900,901}),Array.Empty<long>()),"joined neutrals reverse");
  Check(!WireCircuit.CanConnect(new(900,2),new(901,2),joined,Array.Empty<long>(),out _,passages:new long[]{900,901}),"neutral loop rejected");
  var used=new List<CabinetWireSaveData>{W(new(0,0),new(900,2))};Check(!WireCircuit.CanConnect(new(10,1),new(900,2),used,Array.Empty<long>(),out _,passages:new long[]{900}),"neutral terminal single-wire capacity");
  var wiring=new List<CabinetWireSaveData>{W(new(0,0),new(10,0)),W(new(10,1),new(0,1)),W(new(10,1),new(900,2)),W(new(900,3),new(100,0)),W(new(100,1),new(901,3)),W(new(901,2),new(0,2))};
  var host=new SwitchboardCabinet();var inputNet=new CableNetwork{PotentialLoad=10000};var one=new CableNetwork{RequiredLoad=500};var two=new CableNetwork{RequiredLoad=500};
  host.InputConnection.cable.CableNetwork=inputNet;host.Output1Connection.cable.CableNetwork=one;host.Output2Connection.cable.CableNetwork=two;
  var protection=new DinBreaker{ReferenceId=10,OnOff=true,RatedWatts=1000};var led=new DinBreaker{ReferenceId=100,IsDoorLed=true,RatedWatts=0};
  var forward=new DinBreaker{ReferenceId=900,IsDoorBridge=true};var backward=new DinBreaker{ReferenceId=901,IsDoorBridge=true};
  var modules=new[]{protection,led,forward,backward};var power=new CabinetWiringPower();power.Refresh(host,wiring,modules);
  Check(power.Generated(two)>0,"power through neutral feed and reverse return");
  power.Use(one,500);power.Use(two,500);Check(power.DrainTrips().Length==0,"same protection exact threshold");
  power.Use(two,501);Check(power.DrainTrips().SequenceEqual(new long[]{10}),"common protection summed branches");
  var circuit=DoorModuleLayout.Through(wiring,new long[]{900,901}).ToArray();
  Check(DoorModuleLayout.Energized(100,circuit,modules.Select(m=>m.ReferenceId),true,Array.Empty<long>()),"LED through neutral input");
  Check(DoorModuleLayout.Energized(100,DoorModuleLayout.Through(wiring.Take(4),new long[]{900}),modules.Select(m=>m.ReferenceId),true,Array.Empty<long>()),"IN-only LED lights without OUT");
  Check(!DoorModuleLayout.Energized(100,circuit,modules.Where(m=>m.ReferenceId!=10).Select(m=>m.ReferenceId),true,Array.Empty<long>()),"open protection darkens LED");
  Check(!DoorModuleLayout.Energized(100,circuit,modules.Select(m=>m.ReferenceId),false,Array.Empty<long>()),"dead source darkens LED");
  Check(DoorModuleLayout.Energized(100,circuit,modules.Select(m=>m.ReferenceId),false,new long[]{10}),"reachable battery backup lights LED");
  Check(Enumerable.Range(-20,41).Sum(x=>Enumerable.Range(-20,41).Count(y=>DoorModuleLayout.Fits(x,y,0,0)))==9,"3x3 LED positions");
  foreach(float angle in new[]{0f,-25f,-55f,-90f,-110f})
  {
   float r=angle*MathF.PI/180;WirePoint Rotate(float x,float y,float z)=>new(x*MathF.Cos(r)+z*MathF.Sin(r),y,-x*MathF.Sin(r)+z*MathF.Cos(r));
   for(int slot=-9;slot<=8;slot++)
   {
    float y=slot*.024f;var a=new WirePoint(-.1875f,y,.033f);var b=a+new WirePoint(-.003f,0,.060f);
    var d=Rotate(.0235f,y,-.0225f)+new WirePoint(-.2f,0,.187f);var c=d+Rotate(-.012f,0,-.040f);
    var line=DoorModuleLayout.DoorFlexGeometry.Build(a,b,c,d);Check((line[0]-a).Squared<1e-12f&&(line[^1]-d).Squared<1e-12f,"flex endpoints attach");TubeHarness.AssertSections(line);
    var hole=DoorModuleLayout.HarnessWindowAt(y);
    for(int i=1;i<line.Length;i++){var p=line[i-1];var q=line[i];if((p.Z-.1015f)*(q.Z-.1015f)<=0&&MathF.Abs(q.Z-p.Z)>1e-7f){var cross=p+(q-p)*((.1015f-p.Z)/(q.Z-p.Z));Check(cross.X-WireRouting.Radius>=hole.Left&&cross.X+WireRouting.Radius<=hole.Right&&cross.Y-WireRouting.Radius>=hole.Bottom&&cross.Y+WireRouting.Radius<=hole.Top,"individual cover hole clears flex");}}
   }
  }
  PlateBridges();
  FullDoor();
  Console.WriteLine("Individual bidirectional bridges passed "+checks+" checks including all18 independent passages and full9LED door routing.");
 }
 static void PlateBridges()
 {
  foreach(int row in new[]{-1,1})for(int slot=-9;slot<=8;slot++)foreach(bool reverse in new[]{false,true})
  {
   var h=new RouteHarness();float x=-.14175f,y=row*.108f,by=slot*.024f;
   h.railObstacles.Add(new(-.162f,.162f,.0905f,.1255f));h.railObstacles.Add(new(-.162f,.162f,-.1255f,-.0905f));
   var module=new CabinetWireEnd(10,reverse?0:1);var bridge=new CabinetWireEnd(900,2);
   h.contacts[module]=new(){End=module,Position=new(x,y+(reverse?.050625f:-.050625f),.06535f),Exit=new(x,y+(reverse?.066f:-.066f),WireRouting.Plane),Bounds=new(x-.0198f,x+.0198f,y-.050625f,y+.050625f)};
   h.contacts[bridge]=new(){End=bridge,Position=new(-.192f,by,.0244f),Exit=new(-.168f,by,WireRouting.Plane),Bounds=new(-.192f,-.175f,by-.011f,by+.011f)};
   var path=h.MakeRoute(reverse?bridge:module,reverse?module:bridge,out int fan,out string fail);
   Check(path!=null,"breaker/bridge plate route row="+row+" slot="+slot+" reverse="+reverse+": "+fail);
   TubeHarness.AssertSections(path);
  }
 }
 static void FullDoor()
 {
  var h=new RouteHarness();
  for(int i=0;i<18;i++)
  {
   float y=(-9+i)*.024f;var e=new CabinetWireEnd(900+i,3);
   h.contacts[e]=new(){End=e,Door=true,Position=new(.181f,y,.0114f),Exit=new(.153f,y,.043f),Bounds=new(.164f,.181f,y-.011f,y+.011f)};
  }
  for(int n=0;n<9;n++)
  {
   float x=(n%3-1)*.1f,y=(n/3-1)*.1f;
   for(int pin=0;pin<2;pin++){var e=new CabinetWireEnd(100+n,pin);float sign=pin==0?1:-1;h.contacts[e]=new(){End=e,Door=true,Position=new(x,y+sign*.023f,.017f),Exit=new(x,y+sign*.043f,.043f),Bounds=new(x-.019f,x+.019f,y-.024f,y+.024f)};}
  }
  for(int n=0;n<9;n++)foreach(var pair in new[]{(new CabinetWireEnd(900+n*2,3),new CabinetWireEnd(100+n,0)),(new CabinetWireEnd(100+n,1),new CabinetWireEnd(901+n*2,3))})
  {
   var path=h.MakeRoute(pair.Item1,pair.Item2,out int slot,out string fail);Check(path!=null,"18 individual door routes "+n+": "+fail);TubeHarness.AssertSections(path);
   h.wires.Add(new(){From=pair.Item1,To=pair.Item2,InputSlot=slot,Points=path.SelectMany(p=>new[]{p.X,p.Y,p.Z}).ToArray()});
  }
 }
}
