using Assets.Scripts.Objects;
namespace ModularSwitchboards
{
    internal static class PrefabAudioOwner
    {
        internal static void Rebind(Structure replacement)
        {
            // Unity remaps references when cloning a prefab, but replacing its
            // Thing component is our operation. Events must not retain that
            // soon-to-be-destroyed component as their state/audio owner.
            foreach(var audio in replacement.AudioEvents)
                if(audio!=null)audio.Parent=replacement;
            foreach(var interaction in replacement.Interactables)
                if(interaction!=null)
                    foreach(var audio in interaction.AssociatedAudioEvents)
                        if(audio!=null)audio.Parent=replacement;
            foreach(var state in replacement.BuildStates)
                foreach(var interaction in state.Interactables)
                    if(interaction!=null)
                        foreach(var audio in interaction.AssociatedAudioEvents)
                            if(audio!=null)audio.Parent=replacement;
        }
    }
}
