# Current build: 0.13.102

User reports native GameAudioEvent.IsValid -> Interactable.PlayInteractableSounds -> PlayScheduledSounds -> AudioManager.LateUpdate NRE on world load. Decompiled IsValid accesses Parent.IsState and Parent.AsStructure. ReplaceComponent rebinds interaction.Parent but left GameAudioEvent.Parent referencing removed source component. New PrefabAudioOwner.Rebind(Structure) called before original DestroyImmediate transfers global, interaction and build-state interaction event owners. No global audio patches or suppressed sounds; conditions/channels/materials/geometry/native state unchanged. Source clone isolation preserved. Native Thing.Awake still initializes AudioSources and private event lookup. 14 regression checks plus10 Smart lifecycle checks passed, Release build0errors/0warnings. In-game worldload/audio check pending.

## Previous version

# Current build: 0.13.101

Socket front now flush with casing fascia z.0736 instead of .0741. No rectangular .15mm perimeter gap. SmartSocketPocket fills four fascia corners and builds an octagonal floor/liner matching the original 2.607mm rim chamfers. Functional native slot follows the same original pose and shifted socket transform. LED/native logic untouched. Tests verify four corner continuity rays, flush rim, original UVs, open pocket and nondegenerate mesh triangles. In-game fit pending.

## Previous build 0.13.100

Visual-only Smart fascia revision, plus matching slot seating transform. AirChipSocketGeometry selects exactly166 complete original Air IC10 socket triangles in prefab bounds x[-.006,.126],y[.703,.846],z[.111,.158]. Full native UV/material groups kept; surrounding panels z>=.205 excluded. Socket fit46x49.5mm, centerX.009, front rimz.0741 over fasciaz.0736. SmartSocketPocket subtracts a pocket and adds closed floor/four lining walls before the native slot is added. Rear depth includes actual native IC10 source bounds. Native slot and original frame use identical uniform map/pose.

LED centerz.0743 (2.7mm closer to fascia), screen remains visible, frame maxz~.077386. LedBezelGeometry excludes10 separate original button pedestal triangles; native state/rendering/logic untouched. User screenshot confirms native text rendering and IC10 appearance in99. SmartPrefabState pre-Awake fix retained.

Verification/SmartGeometry uses actual external original Air/LED Diagnostics JSON and included own procedural CasingFixture, checks332 cases including UV and floor/wall ray clearance. Art/SmartGeometry.json is pocketed actual casing; native-face100.json remains outside source package and is used for the icon render. Source game models/decompiled reference excluded. In-game100 geometry/slot fit still pending.

## Previous lifecycle fix

Hotfix for the reported startup stack: SmartModuleModel.Install -> Interactable.State -> LogicDisplay.OnInteractableUpdated -> Thing.OnOff -> null InteractOnOff. SmartPrefabState seeds serialized _state before Awake without live callbacks and then CacheStates(true). Clone animators removed and ParentInteractableIndex reset so live states have their own native owner. Production SmartPrefabState regression reproduces pre-Awake failure, verifies silent authoring and preserved live callbacks. No native game/decompiled assets bundled.

## Feature state inherited from 0.13.98

DIN Smart Module is a native LogicDisplay + ICircuitHolder, four DIN positions/cost4, native LED glyph rendering and transplanted Air Conditioner IC10 socket. Single upper power/data IN only; no OUT or overload protection. SmartCircuit selects the Input or common feeder/output network, never joins separate data networks. Native device registration lets the selected branch computer IC motherboard discover DIN Smart Module. db addresses the display-owning module; ID/batch reads scoped to selected native network. No physical d0-d5 selectors yet.

Source models are read from native runtime SourcePrefabs. Original uploaded Diagnostics dumps/decompiled reference live outside this package. Native socket and occupant preserve original pose/materials and move together onto fascia. Body paint is separate from native LED color/materials. Standard breaker geometry unchanged.

SmartModuleSaveData extends native LogicBaseSaveData; native base owns settings and inventory. Mount/editor/error added, old prototype mount accepted. Old Smart OUT wires are refunded, IN preserved. Seven save data types registered. Authoritative placement validates4slots before kit consumption; detached/authoring targeting/cover window/label occupancy include Smart.

See README for wiring and test program. Production DLL build + fixture checks complete; actual Unity glyph draw, IC10 seating, motherboard dropdown, multiplayer and game save/load pending user testing.
