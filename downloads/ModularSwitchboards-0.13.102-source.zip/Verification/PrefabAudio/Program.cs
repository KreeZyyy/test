using System;using System.Collections.Generic;using ModularSwitchboards;using Assets.Scripts.Objects;using Assets.Scripts.Sound;
class Program
{
 static int n;static void Check(bool b,string s){n++;if(!b)throw new Exception(s);}
 static void Main(){
 var old=new Thing();var source=new Thing();var sourceEvent=new GameAudioEvent{Parent=source};source.AudioEvents.Add(sourceEvent);
 var shared=new GameAudioEvent{Parent=old};var interactionOnly=new GameAudioEvent{Parent=null};var buildOnly=new GameAudioEvent{Parent=old};
 var replacement=new Structure();replacement.AudioEvents.AddRange(new[]{shared,null});replacement.Interactables.Add(new Interactable{AssociatedAudioEvents=new(){shared,interactionOnly,null}});replacement.Interactables.Add(null);
 replacement.BuildStates.Add(new BuildState{Interactables=new(){new Interactable{AssociatedAudioEvents=new(){buildOnly}},replacement.Interactables[0],null}});
 old.Destroyed=true;bool reproduced=false;try{_=shared.IsValid;}catch(NullReferenceException){reproduced=true;}
 Check(reproduced,"native audio condition did not reproduce destroyed owner failure");
 PrefabAudioOwner.Rebind(replacement);
 foreach(var e in new[]{shared,interactionOnly,buildOnly}){Check(ReferenceEquals(e.Parent,replacement),"audio owner was not rebound");Check(!e.IsValid,"sound condition reads wrong instance state");}
 replacement.On=true;foreach(var e in new[]{shared,interactionOnly,buildOnly}){Check(e.IsValid,"live sound condition lost");e.Trigger();}
 Check(replacement.Played==3,"native sound triggering suppressed");Check(sourceEvent.Parent==source&&source.Played==0,"source prefab audio changed");
 Check(ReferenceEquals(shared,replacement.Interactables[0].AssociatedAudioEvents[0]),"shared event identity lost");
 PrefabAudioOwner.Rebind(replacement);Check(shared.IsValid,"rebinding is not idempotent");
 Console.WriteLine(n+" prefab audio owner checks passed: destroyed owner reproduced, global/interaction/build-only events rebound, live conditions and sound triggers retained, source isolated.");
 }
}
namespace Assets.Scripts.Sound {public class GameAudioEvent {public Thing Parent;public bool IsValid{get{if(Parent==null||Parent.Destroyed)throw new NullReferenceException();return Parent.On;}}public void Trigger(){if(IsValid)Parent.Played++;}}}
namespace Assets.Scripts.Objects {
 public class Thing {public bool Destroyed,On;public int Played;public List<GameAudioEvent> AudioEvents=new();public List<Interactable> Interactables=new();public List<BuildState> BuildStates=new();}
 public class Structure:Thing {}
 public class Interactable {public List<GameAudioEvent> AssociatedAudioEvents=new();}
 public class BuildState {public List<Interactable> Interactables=new();}
}
