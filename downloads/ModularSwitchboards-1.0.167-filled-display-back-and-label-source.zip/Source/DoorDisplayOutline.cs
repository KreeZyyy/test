using System.Collections.Generic;using UnityEngine;
namespace ModularSwitchboards {
 internal static class DoorDisplayOutline {
  internal static Mesh Build(bool label){
   var inner=DoorDisplayContour.Offset(label?.00025f:.0004f);var outer=DoorDisplayContour.Offset(label?.005f:.0024f);
   float back=label?-.0008f:-.0134f,front=label?.0012f:-.0152f;
   var v=new List<Vector3>();var border=new List<int>();var face=new List<int>();
   for(int i=0;i<inner.Length;i++){
    int j=(i+1)%inner.Length;var a=inner[i];var b=inner[j];var c=outer[j];var d=outer[i];
    a.z=b.z=c.z=d.z=front;Quad(v,border,a,b,c,d);
    var ar=a;var br=b;var cr=c;var dr=d;ar.z=br.z=cr.z=dr.z=back;
    Quad(v,border,dr,cr,br,ar);if(label)Quad(v,border,a,ar,br,b);Quad(v,border,d,c,cr,dr);
    if(!label){
     // Close both faces with the same grey surface as the perimeter.
     int p=v.Count;v.AddRange(new[]{new Vector3(.05f,0,front),b,a,new Vector3(.05f,0,back),ar,br});border.AddRange(new[]{p,p+1,p+2,p+3,p+4,p+5});
    }
    if(label&&outer[i].y>=-.000001f&&outer[j].y>=-.000001f){var t=d;var u=c;t.y=u.y=.035f;Quad(v,border,d,c,u,t);t.z=u.z=back;Quad(v,border,dr,t,u,cr);}
   }
   if(label){for(int i=0;i<border.Count;i+=3){int tmp=border[i+1];border[i+1]=border[i+2];border[i+2]=tmp;}DinRailModel.AddBox(v,border,new Vector3(.05f,.050f,0),new Vector3(.192f,.032f,.003f));DinRailModel.AddBox(v,face,new Vector3(.05f,.050f,.0018f),new Vector3(.180f,.027f,.001f));}
   var mesh=new Mesh{name=label?"Smart Display Label.NativeContour":"Smart Display.RearPanel.NativeContour"};mesh.SetVertices(v);mesh.subMeshCount=label?5:1;for(int i=0;i<mesh.subMeshCount;i++)mesh.SetTriangles(i==0?border.ToArray():i==1?face.ToArray():new int[0],i);mesh.RecalculateNormals();mesh.RecalculateBounds();return mesh;
  }
  private static void Quad(List<Vector3> v,List<int> t,Vector3 a,Vector3 b,Vector3 c,Vector3 d){int p=v.Count;v.AddRange(new[]{a,b,c,d});t.AddRange(new[]{p,p+1,p+2,p,p+2,p+3});}
 }
 internal static class DoorDisplayRearLayout {
  internal const float X=.05f,Y=0,WireZ=-.039f,ScrewZ=-.0385f;
 }
}
