using System;
using System.Collections.Generic;
using System.Linq;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Structures;
using Assets.Scripts.UI;
using HarmonyLib;
using Rendering;
using UnityEngine;
using Object = UnityEngine.Object;

namespace ModularSwitchboards
{
    internal static class CabinetModel
    {
        internal static void Install(Structure cabinet)
        {
            var oldRenderers = cabinet.GetComponentsInChildren<Renderer>(true);
            Material fallback = cabinet.PaintableMaterial;
            if (fallback == null || fallback.shader == null || !fallback.shader.isSupported)
                fallback = oldRenderers.SelectMany(r => r.sharedMaterials).FirstOrDefault(m =>
                    m != null && m.shader != null && m.shader.isSupported && m.shader.name != "Hidden/InternalErrorShader");
            CabinetGeometry.EnsureLoaded(fallback);
            // Keep the tested native object/save type, replace its visual and collision geometry.
            foreach (var r in oldRenderers) Object.DestroyImmediate(r);
            foreach (var m in cabinet.GetComponentsInChildren<MeshFilter>(true)) Object.DestroyImmediate(m);
            foreach (var c in cabinet.GetComponentsInChildren<Collider>(true)) Object.DestroyImmediate(c);
            foreach (var a in cabinet.GetComponentsInChildren<Animator>(true)) Object.DestroyImmediate(a);
            if (cabinet is Locker locker)
            {
                locker.DontUseOpen = false;
                AccessTools.Field(typeof(Locker), "lockerAnimComponent")?.SetValue(locker, null);
                AccessTools.Field(typeof(Locker), "shutterMaterialAnimComponent")?.SetValue(locker, null);
            }
            cabinet.BaseAnimator = null;
            cabinet.Renderers = new List<ThingRenderer>();
            cabinet._staticColliders = new List<Collider>();
            cabinet._dynamicColliders = new List<Collider>();
            cabinet._selfColliders = new List<Collider>();
            cabinet.CustomNavMeshFilter = null;
            cabinet.structureRenderMode = StructureRenderMode.Standard;
            cabinet.PlacementType = PlacementSnap.FaceMount;
            cabinet.AllowedRotations = AllowedRotations.Wall;
            cabinet.RotationAxis = RotationAxis.Z;
            cabinet.GridSize = .5f;
            cabinet.GridOffset = 0f;
            // Locker prefabs can override GridSize/GridOffset with private per-axis snapping.
            // FaceMount needs the cabinet origin on the wall plane, not the locker grid offset.
            var axisSnap = AccessTools.Field(typeof(Structure), "_useAxisIndependentGridSnapping");
            var requiresFrame = AccessTools.Field(typeof(SmallGrid), "requiresFrame");
            if (axisSnap == null || requiresFrame == null)
                throw new MissingFieldException("Native mount configuration changed.");
            axisSnap.SetValue(cabinet, false);
            requiresFrame.SetValue(cabinet, false);
            cabinet.BoundsGridShiftForward = cabinet.BoundsGridShiftSide = 0f;
            cabinet.BoundsGridAddHeight = cabinet.BoundsGridAddBottom = 0f;
            cabinet.BoundsGridExtraHeight = cabinet.BoundsGridExtraWidth = 0f;
            cabinet.BoundsGridExtraForward = cabinet.BoundsForward = 0f;
            if (cabinet is SmallGrid smallGrid) smallGrid.DualRegister = false;
            Debug.Log("[Modular Switchboards] Wall mount reset: uniform 0.5 m snap, zero offset, wall/frame support.");
            cabinet.SelectionDisplay = SelectionHighlightMethod.Bounds;
            cabinet.UseCellPosition = false;
            cabinet.ForceGridBounds.Clear();
            cabinet.PaintableMaterial = null;

            var open = cabinet.Interactables.FirstOrDefault(i => i.Action == InteractableType.Open);
            if (open == null) throw new InvalidOperationException("Native cabinet has no Open interaction.");
            open.Animator = null; open.FakeCollider = null;
            open.CanKeyInteract = true;
            cabinet.Interactables = new List<Interactable> { open };

            var model = Child(cabinet.transform, "SwitchboardModel", cabinet.gameObject.layer);
            var housing = Renderer(model, "Housing", CabinetGeometry.Meshes[0], CabinetGeometry.Materials);
            var mounting = Renderer(model, "Mounting", CabinetGeometry.Meshes[1], CabinetGeometry.Materials);
            var wiring = Renderer(model, "Wiring", CabinetGeometry.Meshes[2], CabinetGeometry.Materials);
            var hinge = Child(model, "DoorHinge", cabinet.gameObject.layer);
            hinge.localPosition = new Vector3(-.20f, 0f, .187f);
            Renderer(hinge, "Door", CabinetGeometry.Meshes[3], CabinetGeometry.Materials);
            var doorCollider = Box(hinge, "DoorCollider", new Vector3(.20f, 0f, .004f), new Vector3(.4f, .5f, .018f));
            open.Collider = doorCollider;
            var colliders = new List<Collider>
            {
                Box(model, "BackCollider", new Vector3(0f, 0f, .003f), new Vector3(.4f, .5f, .006f)),
                Box(model, "LeftCollider", new Vector3(-.197f, 0f, .09f), new Vector3(.006f, .5f, .18f)),
                Box(model, "RightCollider", new Vector3(.197f, 0f, .09f), new Vector3(.006f, .5f, .18f)),
                Box(model, "TopCollider", new Vector3(0f, .247f, .09f), new Vector3(.4f, .006f, .18f)),
                Box(model, "BottomCollider", new Vector3(0f, -.247f, .09f), new Vector3(.4f, .006f, .18f)),
                doorCollider
            };
            var renderers = new[] { housing, mounting, wiring };
            var drawField = AccessTools.Field(typeof(BuildState), "initialDrawData");
            if (drawField == null) throw new MissingFieldException("BuildState.initialDrawData");
            for (int i = 0; i < cabinet.BuildStates.Count; i++)
            {
                var state = cabinet.BuildStates[i];
                state.Visualizer = renderers[i];
                state.RendererInstance = null;
                state.RenderMode = BuildStateRenderMode.OnMineAndPreviousStates;
                state.StateMeshes = new List<Mesh>();
                state.LinkedGameObjects = new List<GameObject>();
                state.Colliders = new List<Collider>(colliders);
                state.Interactables = new List<Interactable> { open };
                state.BlockAir = false; state.AlwaysBlockAir = false;
                state.BlockGravity = false; state.BlockLight = false;
                drawField.SetValue(state, new DrawData { mesh = null, materials = new Material[0] });
            }
            // Damaged stock locker meshes would not match the replacement geometry.
            cabinet.BrokenBuildStates = new List<BrokenBuildState>();
            var door = cabinet.gameObject.AddComponent<CabinetDoor>();
            door.Owner = cabinet; door.Hinge = hinge;

            // Keep the preview external to the cabinet hierarchy. Native cursor setup destroys
            // the cabinet renderers before instantiating this independent blueprint.
            var blueprint = Child(cabinet.transform.parent, "SwitchboardBlueprint", cabinet.gameObject.layer);
            var combine = new List<CombineInstance>();
            foreach (int meshIndex in new[] { 0, 3 })
                for (int m = 0; m < CabinetGeometry.Meshes[meshIndex].subMeshCount; m++)
                    if (CabinetGeometry.Meshes[meshIndex].GetIndexCount(m) != 0)
                        combine.Add(new CombineInstance
                        {
                            mesh = CabinetGeometry.Meshes[meshIndex], subMeshIndex = m,
                            transform = meshIndex == 3 ? Matrix4x4.Translate(hinge.localPosition) : Matrix4x4.identity
                        });
            var ghostMesh = new Mesh { name = "Switchboards.ClosedBlueprint" };
            ghostMesh.CombineMeshes(combine.ToArray(), true, true);
            ghostMesh.RecalculateBounds();
            var ghostRenderer = blueprint.gameObject.AddComponent<MeshRenderer>();
            ghostRenderer.sharedMaterial = new Material(CabinetGeometry.Materials[0]);
            var ghostFilter = blueprint.gameObject.AddComponent<MeshFilter>(); ghostFilter.sharedMesh = ghostMesh;
            var wireframe = blueprint.gameObject.AddComponent<Wireframe>();
            wireframe.BlueprintTransform = blueprint;
            wireframe.BlueprintBounds = ghostMesh.bounds;
            wireframe.BlueprintMeshFilter = ghostFilter;
            wireframe.BlueprintRenderer = ghostRenderer;
            blueprint.gameObject.AddComponent<CabinetBlueprint>();
            cabinet.Blueprint = blueprint.gameObject;
            cabinet.BlueprintOrientVector = Vector3.zero;
            SetBounds(cabinet);
            Debug.Log("[Modular Switchboards] New wall cabinet mesh installed: 400x500x180 mm, two DIN rows.");
        }

        // Called from a narrowly scoped bounds prefix, including construction preview copies.
        internal static void SetBounds(Structure cabinet)
        {
            cabinet.ThingTransform = cabinet.transform;
            cabinet.Bounds = new Bounds(new Vector3(0f, 0f, .105f), new Vector3(.43f, .51f, .23f));
            cabinet.SurfaceArea = 2f * (.4f * .5f + .5f * .18f + .18f * .4f);
            cabinet.GridBounds = new GridBounds(cabinet);
        }

        private static Transform Child(Transform parent, string name, int layer)
        {
            var obj = new GameObject(name) { layer = layer };
            obj.transform.SetParent(parent, false);
            return obj.transform;
        }

        private static MeshRenderer Renderer(Transform parent, string name, Mesh mesh, Material[] materials)
        {
            var obj = Child(parent, name, parent.gameObject.layer).gameObject;
            obj.AddComponent<MeshFilter>().sharedMesh = mesh;
            var renderer = obj.AddComponent<MeshRenderer>(); renderer.sharedMaterials = materials;
            return renderer;
        }

        private static BoxCollider Box(Transform parent, string name, Vector3 center, Vector3 size)
        {
            var obj = Child(parent, name, parent.gameObject.layer).gameObject;
            var collider = obj.AddComponent<BoxCollider>(); collider.center = center; collider.size = size;
            return collider;
        }
    }
}
