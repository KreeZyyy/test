using System;using System.Collections.Generic;using ModularSwitchboards;using LibConstruct;using Assets.Scripts;using Assets.Scripts.Inventory;
namespace Assets.Scripts.GridSystem{public struct Grid3{public int x,y,z;public Grid3(int a,int b,int c){x=a;y=b;z=c;}}}
namespace Assets.Scripts.Objects{public class MultiConstructor{public string PrefabName;public List<object> Constructables=new();}}
namespace Assets.Scripts.Inventory{public class Panel{public bool IsVisible;public Assets.Scripts.Objects.MultiConstructor Parent;public int BuildIndex;}public class InventoryManager{public static InventoryManager Instance;public Panel ConstructionPanel;public static object ConstructionCursor;}}
namespace Assets.Scripts{public class HitCollider{public object Parent;public T GetComponentInParent<T>()where T:class=>Parent as T;}public struct Hit{public float distance;}public class CursorManager{public static CursorManager Instance;public HitCollider CursorTargetCollider;public static object CursorThing;public static Hit CursorHit;}}
namespace LibConstruct{public interface IPlacementBoardStructure{PlacementBoard Board{get;set;}}public class PlacementBoard{public static bool IsRelocating;public static PlacementBoard CursorBoard;public static Assets.Scripts.GridSystem.Grid3 CursorGrid;public static int CursorRotation;public object PrimaryHost;}}
namespace ModularSwitchboards{public static class SwitchboardsMod{public const string CoverKitName="coverkit";}public class InnerCoverModule:IPlacementBoardStructure{public PlacementBoard Board{get;set;}}public class SwitchboardCabinet{public bool CanFitRails=true;public PlacementBoard CoverBoard=new();}}
class Program{
 static int n;static void Check(bool ok,string m){n++;if(!ok)throw new Exception(m);}
 static void Main(){
 var host=new SwitchboardCabinet();host.CoverBoard.PrimaryHost=host;
 var panel=new Panel{IsVisible=true,Parent=new(){PrefabName="coverkit",Constructables=new(){new InnerCoverModule()}}};
 InventoryManager.Instance=new(){ConstructionPanel=panel};CursorManager.Instance=new(){CursorTargetCollider=new(){Parent=host}};CursorManager.CursorHit=new(){distance=1};
 InventoryManager.ConstructionCursor=null;Check(CoverPlacement.IsSelected,"Selected kit requires a pre-existing cursor");
 PlacementBoard.CursorBoard=new();PlacementBoard.CursorRotation=3;Check(!CoverPlacement.FindBoard()&&PlacementBoard.CursorBoard==host.CoverBoard&&PlacementBoard.CursorGrid.x==0&&PlacementBoard.CursorGrid.y==0&&PlacementBoard.CursorRotation==0,"Cover did not select its own board without a preview");
 var cursor=new InnerCoverModule();InventoryManager.ConstructionCursor=cursor;Check(!CoverPlacement.FindBoard()&&cursor.Board==host.CoverBoard,"Cursor board not attached");
 host.CanFitRails=false;Check(!CoverPlacement.FindBoard()&&cursor.Board==null&&PlacementBoard.CursorBoard==null,"Closed/covered cabinet retains stale target");host.CanFitRails=true;
 foreach(float distance in new[]{2f,-1f,float.NaN}){CursorManager.CursorHit=new(){distance=distance};Check(!CoverPlacement.FindBoard()&&cursor.Board==null,"Out-of-range target accepted");}
 CursorManager.CursorHit=new(){distance=1};CursorManager.Instance.CursorTargetCollider=null;CursorManager.CursorThing=new InnerCoverModule{Board=host.CoverBoard};Check(!CoverPlacement.FindBoard()&&cursor.Board==host.CoverBoard,"Nested structure fallback failed");
 CursorManager.CursorThing=null;Check(!CoverPlacement.FindBoard()&&cursor.Board==null,"Looking away retained prior board");
 panel.IsVisible=false;Check(CoverPlacement.FindBoard(),"Normal non-placement targeting intercepted");panel.IsVisible=true;
 panel.Parent.PrefabName="railkit";Check(CoverPlacement.FindBoard(),"DIN rail targeting intercepted");panel.Parent.PrefabName="coverkit";
 foreach(int index in new[]{-1,1}){panel.BuildIndex=index;Check(!CoverPlacement.IsSelected,"Invalid variant accepted");}panel.BuildIndex=0;
 PlacementBoard.IsRelocating=true;Check(CoverPlacement.FindBoard(),"Relocation intercepted");
 Console.WriteLine($"Production cover placement: {n} checks passed; selected survival kit without cursor, own board, stale-target clearing, range, nested target and unrelated tools.");
 }
}
