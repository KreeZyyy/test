using Assets.Scripts;
using Assets.Scripts.Inventory;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Objects;
using LibConstruct;
namespace ModularSwitchboards
{
    internal static class CoverPlacement
    {
        // Use the actual selected survival kit, before a board cursor exists.
        internal static bool IsSelected
        {
            get
            {
                var panel=InventoryManager.Instance?.ConstructionPanel;
                return panel!=null&&panel.IsVisible&&panel.Parent!=null&&panel.Parent.PrefabName==SwitchboardsMod.CoverKitName&&
                    panel.BuildIndex>=0&&panel.BuildIndex<panel.Parent.Constructables.Count&&
                    panel.Parent.Constructables[panel.BuildIndex] is InnerCoverModule;
            }
        }
        internal static bool CanTarget(bool selected,bool relocating,bool available,float distance)
            =>selected&&!relocating&&available&&distance>=0&&distance<=(float)System.Math.Sqrt(8)*.6f;
        // LibConstruct otherwise chooses the board belonging to the first collider
        // hit: a wire, a rail or a module can obscure the cover's mounting surface.
        internal static bool FindBoard()
        {
            if(!IsSelected||PlacementBoard.IsRelocating)return true;
            PlacementBoard.CursorBoard=null;
            var cursor=CursorManager.Instance;
            var hit=cursor==null?null:cursor.CursorTargetCollider;
            var host=hit==null?null:hit.GetComponentInParent<SwitchboardCabinet>();
            if(host==null&&CursorManager.CursorThing is IPlacementBoardStructure part)
                host=part.Board?.PrimaryHost as SwitchboardCabinet;
            if(CanTarget(true,false,host!=null&&host.CanFitRails&&host.CoverBoard!=null,CursorManager.CursorHit.distance))
            {
                PlacementBoard.CursorBoard=host.CoverBoard;
                PlacementBoard.CursorGrid=new Grid3(0,0,0);
                PlacementBoard.CursorRotation=0;
            }
            // Invalid targets clear the prior board too; never place into a
            // previously aimed-at cabinet after turning toward a closed/remote one.
            if(InventoryManager.ConstructionCursor is InnerCoverModule cover)cover.Board=PlacementBoard.CursorBoard;
            return false;
        }
    }
}
