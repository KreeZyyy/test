using System;
using System.Reflection;
using ModularSwitchboards;
using UnityEngine;
class Program
{
 static void Main()
 {
  foreach(string scenario in new[]{"standard","missing","unsupported","neither"})
  {
   typeof(CabinetKitSurface).GetField("materials",BindingFlags.NonPublic|BindingFlags.Static).SetValue(null,null);
   Shader.Mode=scenario;
   try
   {
    var mats=CabinetKitSurface.Materials;
    if(scenario=="neither")throw new Exception("Missing shaders accepted");
    if(mats.Length!=5||mats[0].shader.name!=(scenario=="standard"?"Standard":"StandardInstanced"))throw new Exception("Wrong shader");
    if(!ReferenceEquals(mats,CabinetKitSurface.Materials))throw new Exception("Material cache lost");
    var renderer=new MeshRenderer{sharedMaterials=mats};CabinetKitSurface.Refresh(renderer);
    if(renderer.ClearCount!=6)throw new Exception("Native property blocks not cleared");
   }
   catch(InvalidOperationException){if(scenario!="neither")throw;}
  }
  Console.WriteLine("Cabinet material checks passed: Standard present/missing/unsupported, fallback, neither supported, caching and block clearing.");
 }
}
namespace UnityEngine
{
 public struct Color{public Color(float r,float g,float b){}}
 public class Shader
 {
  public static string Mode;public string name;public bool isSupported;
  public static Shader Find(string n)=>Mode=="neither"||n=="Standard"&&Mode=="missing"?null:new Shader{name=n,isSupported=n!="Standard"||Mode!="unsupported"};
 }
 public class Material
 {
  public string name;public Color color;public Shader shader;
  public Material(Shader s){shader=s;} public void SetFloat(string n,float f){}
 }
 public class MeshRenderer
 {
  public Material[] sharedMaterials;public int ClearCount;
  public void SetPropertyBlock(object b){ClearCount++;}
  public void SetPropertyBlock(object b,int i){ClearCount++;}
 }
}
