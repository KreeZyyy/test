partial class SmartModule:NativeDisplay{        public override DelayedActionInstance AttackWith(Attack attack,bool doAction=true)
        {
            // Native LED colour state controls the glyphs, not the casing.
            // Keep it intact and delegate casing paint to the native sprayer.
            if(IsPaintable&&attack.SourceItem is ISprayer sprayer)return ISprayer.DoSpray(this,sprayer,doAction);
            return base.AttackWith(attack,doAction);
        }
}