using System;
class Program
{
 static int n;static void Check(bool b,string m){n++;if(!b)throw new Exception(m);}
 static void Main(){
 var spray=new Sprayer();var old=new NativeDisplay();Check(old.AttackWith(new(spray),false)==null,"native display fixture did not reproduce spray block");
 var smart=new SmartModule();var preview=smart.AttackWith(new(spray),false);Check(preview!=null&&!preview.Failed&&spray.Uses==0&&smart.BodyColor==0,"paint preview mutated state or remained blocked");
 var result=smart.AttackWith(new(spray),true);Check(!result.Failed&&smart.BodyColor==7&&spray.Uses==1,"Smart casing did not paint through native sprayer");
 Check(smart.HasColorState&&smart.GlyphColor==4&&smart.Setting==123,"body spray changed display colour or Setting");
 Check(smart.AttackWith(new(spray),true).Failed&&spray.Uses==1,"same colour consumed paint");spray.Color=8;spray.Empty=true;Check(smart.AttackWith(new(spray),true).Failed&&smart.BodyColor==7,"empty spray changed casing");
 spray.Empty=false;GameManager.Server=false;smart.AttackWith(new(spray),true);Check(smart.BodyColor==7&&spray.Uses==1,"client mutated paint");GameManager.Server=true;
 smart.AttackWith(new(new object()),true);Check(smart.OtherCalls==1,"non-spray interaction bypassed native behavior");
 Console.WriteLine(n+" Smart paint dispatch checks passed: native colour-state block reproduced, casing spray delegated, glyph colour/Setting retained, preview, empty/same-colour/client guards and other tools preserved.");
 }
}
static class GameManager{public static bool Server=true;}
class DelayedActionInstance{public bool Failed;}
record Attack(object SourceItem);
class NativeDisplay{public bool HasColorState=true,IsPaintable=true;public int BodyColor,GlyphColor=4,OtherCalls;public double Setting=123;public virtual DelayedActionInstance AttackWith(Attack attack,bool doAction=true){if(attack.SourceItem is ISprayer spray&&!HasColorState)return ISprayer.DoSpray(this,spray,doAction);if(attack.SourceItem is not ISprayer)OtherCalls++;return null;}}
interface ISprayer{
 int Color{get;}bool Empty{get;}void Consume();
 public static DelayedActionInstance DoSpray(NativeDisplay owner,ISprayer spray,bool doAction){if(spray.Empty||owner.BodyColor==spray.Color)return new(){Failed=true};if(doAction&&GameManager.Server){spray.Consume();owner.BodyColor=spray.Color;}return new();}
}
class Sprayer:ISprayer{public int Color{get;set;}=7;public bool Empty{get;set;}public int Uses;public void Consume(){Uses++;}}
