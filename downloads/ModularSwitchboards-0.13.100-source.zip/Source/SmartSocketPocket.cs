using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class SmartSocketPocket
    {
        internal static Mesh Cut(Mesh casing,Bounds pocket)
        {
            var mesh=NativeMeshCrop.Outside(casing,pocket,"Smart.CasingWithIC10Pocket");
            if(mesh==null)throw new InvalidOperationException("IC10 pocket removed the whole casing.");
            var vertices=mesh.vertices.ToList();var uv=mesh.uv.ToList();var groups=Enumerable.Range(0,mesh.subMeshCount).Select(i=>mesh.GetTriangles(i).ToList()).ToArray();
            var colourUv=groups[3].Count>0?uv[groups[3][0]]:default(Vector2);
            var lo=pocket.min;var hi=pocket.max;float back=lo.z,front=casing.bounds.max.z;
            Action<Vector3,Vector3,Vector3,Vector3,Vector3> quad=(a,b,c,d,normal)=>
            {
                int start=vertices.Count;vertices.AddRange(new[]{a,b,c,d});uv.AddRange(new[]{colourUv,colourUv,colourUv,colourUv});
                var cross=Vector3.Cross(b-a,c-a);bool forward=cross.x*normal.x+cross.y*normal.y+cross.z*normal.z>0;
                groups[3].AddRange(forward?new[]{start,start+1,start+2,start,start+2,start+3}:new[]{start,start+2,start+1,start,start+3,start+2});
            };
            quad(new Vector3(lo.x,lo.y,back),new Vector3(hi.x,lo.y,back),new Vector3(hi.x,hi.y,back),new Vector3(lo.x,hi.y,back),new Vector3(0,0,1));
            quad(new Vector3(lo.x,lo.y,back),new Vector3(lo.x,hi.y,back),new Vector3(lo.x,hi.y,front),new Vector3(lo.x,lo.y,front),new Vector3(1,0,0));
            quad(new Vector3(hi.x,lo.y,back),new Vector3(hi.x,hi.y,back),new Vector3(hi.x,hi.y,front),new Vector3(hi.x,lo.y,front),new Vector3(-1,0,0));
            quad(new Vector3(lo.x,lo.y,back),new Vector3(hi.x,lo.y,back),new Vector3(hi.x,lo.y,front),new Vector3(lo.x,lo.y,front),new Vector3(0,1,0));
            quad(new Vector3(lo.x,hi.y,back),new Vector3(hi.x,hi.y,back),new Vector3(hi.x,hi.y,front),new Vector3(lo.x,hi.y,front),new Vector3(0,-1,0));
            mesh.SetVertices(vertices);mesh.SetUVs(0,uv);for(int i=0;i<groups.Length;i++)mesh.SetTriangles(groups[i],i);
            mesh.RecalculateNormals();mesh.RecalculateTangents();mesh.RecalculateBounds();return mesh;
        }
    }
}
