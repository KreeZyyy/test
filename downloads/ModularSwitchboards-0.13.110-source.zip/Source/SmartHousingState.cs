using Assets.Scripts.Objects;
namespace ModularSwitchboards
{
    internal static class SmartHousingState
    {
        internal static void AfterCacheStates(Thing __instance)
        {
            // Keep the native cached Color interaction for LED lifecycle calls,
            // but this housing uses custom paint, not writable LED Color state.
            // OnServer.SetCustomColor rejects paints while HasColorState is true.
            if(__instance is SmartModule)__instance.HasColorState=false;
        }
    }
}
