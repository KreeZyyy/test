using System.IO;using System.Reflection.Metadata;using System.Reflection.PortableExecutable;using System.Linq;using System;using System.Reflection;using ModularSwitchboards;using Assets.Scripts.Objects.Electrical;using HarmonyLib;
class Program{
 static int n;static void Check(bool b,string m){n++;if(!b)throw new Exception(m);}
 static void Main(string[] args){
 var native=new ProgrammableChip{PrefabName="ItemIntegratedCircuit10"};var chip=new ProgrammableChip{PrefabName="ItemIntegratedCircuitLua",ReferenceId=42};
 SmartLuaRuntime.Configure(new Harmony());Check(!SmartLuaRuntime.Ready,"Lua became required or falsely available");Check(!SmartLuaRuntime.IsLua(native)&&SmartLuaRuntime.IsLua(chip),"chip language misidentified");
 SmartLuaRuntime.Tick(chip);Check(StationeersLua.LuaChipRuntimeManager.Ticks==0,"missing Lua executed something");Check(SmartLuaRuntime.Error(chip).Contains("unavailable"),"missing mod not explained");
 AccessTools.Available=true;Check(SmartLuaRuntime.Ready,"installed runtime not detected lazily");Check(Harmony.Patches==1,"Lua editor list hook missing");
 SmartLuaRuntime.SetActivity(chip,false);Check(!StationeersLua.LuaChipRuntimeManager.Inactive,"active state not passed");SmartLuaRuntime.Tick(chip);Check(StationeersLua.LuaChipRuntimeManager.Ticks==1&&StationeersLua.LuaChipRuntimeManager.Delta==.5,"wrong Lua cadence or double execution");Check(SmartLuaRuntime.Running(chip),"active VM not reported");
 StationeersLua.LuaChipRuntimeManager.Detail="runtime: test failure at line 3";Check(SmartLuaRuntime.Error(chip).Contains("line 3"),"Lua error detail lost");
 SmartLuaRuntime.SetActivity(chip,true);Check(StationeersLua.LuaChipRuntimeManager.Inactive,"power off does not notify runtime");
 StationeersLua.LuaChipRuntimeManager.SaveInProgress=true;SmartLuaRuntime.Tick(chip);Check(StationeersLua.LuaChipRuntimeManager.Ticks==1&&!SmartLuaRuntime.Running(chip),"save guard failed");
 StationeersLua.LuaChipRuntimeManager.SaveInProgress=false;SmartLuaRuntime.Detach(chip);Check(StationeersLua.LuaChipRuntimeManager.Snapshots==1,"chip removal did not snapshot runtime");
 SmartLuaRuntime.Detach(native);SmartLuaRuntime.SetActivity(native,true);Check(StationeersLua.LuaChipRuntimeManager.Snapshots==1,"ordinary IC10 touched Lua state");
 Check(Harmony.Patches==1,"Lua hook installed repeatedly");
 if(args.Length>0){
 using var pe=new PEReader(File.OpenRead(args[0]));var md=pe.GetMetadataReader();var type=md.TypeDefinitions.Select(h=>md.GetTypeDefinition(h)).Single(t=>md.GetString(t.Namespace)=="StationeersLua"&&md.GetString(t.Name)=="LuaChipRuntimeManager");
 foreach(var expected in new[]{("TickServerSide",2),("UpdateActivityState",2),("GetChipErrorTooltip",1),("HasActiveRuntime",1),("TrySnapshotAndDisposeRuntime",1)}){
 var methods=type.GetMethods().Select(h=>md.GetMethodDefinition(h));Check(methods.Any(m=>md.GetString(m.Name)==expected.Item1&&(m.Attributes&MethodAttributes.Static)!=0&&m.GetParameters().Count(h=>md.GetParameter(h).SequenceNumber>0)==expected.Item2),"uploaded Lua DLL lacks expected API: "+expected.Item1);
 }
 Check(type.GetFields().Select(h=>md.GetFieldDefinition(h)).Any(f=>md.GetString(f.Name)=="SaveInProgress"&&(f.Attributes&FieldAttributes.Static)!=0),"uploaded DLL save guard missing");
 var net=md.TypeDefinitions.Select(h=>md.GetTypeDefinition(h)).Single(t=>md.GetString(t.Namespace)=="StationeersLua.Net"&&md.GetString(t.Name)=="LuaNetManager");Check(net.GetMethods().Select(h=>md.GetMethodDefinition(h)).Any(m=>md.GetString(m.Name)=="SortCircuitHolderDisplayData"),"uploaded DLL editor hook missing");
 }
 if(args.Length>1){using var pe=new PEReader(File.OpenRead(args[1]));var md=pe.GetMetadataReader();Check(!md.AssemblyReferences.Select(h=>md.GetString(md.GetAssemblyReference(h).Name)).Any(n=>n.Contains("StationeersLua")||n=="Lua"),"production DLL has mandatory Lua dependency");}
 Console.WriteLine(n+" optional Lua adapter checks passed: absent/present, lazy load, editor hook, tick cadence, errors, power activity, save guard and snapshot.");
 }
}
namespace Assets.Scripts.Objects.Electrical{public class ProgrammableChip{public string PrefabName;public long ReferenceId;}}
namespace StationeersLua{internal static class LuaChipRuntimeManager{
 internal static bool SaveInProgress;public static int Ticks,Snapshots;public static double Delta;public static bool Inactive;public static string Detail="";
 internal static void TickServerSide(ProgrammableChip chip,double delta){Ticks++;Delta=delta;}
 public static void UpdateActivityState(long id,bool inactive){Inactive=inactive;}
 internal static string GetChipErrorTooltip(long id)=>Detail;
 internal static bool HasActiveRuntime(long id)=>!Inactive;
 internal static void TrySnapshotAndDisposeRuntime(long id){Snapshots++;}
}}
namespace StationeersLua.Net{internal static class LuaNetManager{internal static void SortCircuitHolderDisplayData(){}}}
namespace ModularSwitchboards{static class SmartComputerDevices{internal static void FilterLuaHolders(){}}}
namespace HarmonyLib{
 class Harmony{public static int Patches;public void Patch(MethodBase m,HarmonyMethod prefix){Patches++;}}
 class HarmonyMethod{public HarmonyMethod(Type type,string method){}}
 static class AccessTools{
 public static bool Available;public static Type TypeByName(string n)=>Available?typeof(Program).Assembly.GetType(n):null;
 public static MethodInfo Method(Type t,string n,Type[] args=null)=>args==null?t.GetMethod(n,BindingFlags.Static|BindingFlags.Public|BindingFlags.NonPublic):t.GetMethod(n,BindingFlags.Static|BindingFlags.Public|BindingFlags.NonPublic,null,args,null);
 public static FieldInfo Field(Type t,string n)=>t.GetField(n,BindingFlags.Static|BindingFlags.Public|BindingFlags.NonPublic);
 }}
namespace UnityEngine{static class Debug{public static void Log(string s){}public static void LogError(string s){throw new Exception(s);}}}
