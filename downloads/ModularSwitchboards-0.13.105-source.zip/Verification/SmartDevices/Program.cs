using Assets.Scripts.Objects.Electrical;using System;using System.Linq;using System.Collections.Generic;using Assets.Scripts.Objects.Pipes;using ModularSwitchboards;
int n=0;void Check(bool b,string m){n++;if(!b)throw new Exception(m);}
var smart=new SmartModule{ReferenceId=1,Name="DIN Smart Module"};var other=new SmartModule{ReferenceId=2,Name=smart.Name};var sameId=new SmartModule{ReferenceId=1,Name="Renamed copy"};var stock=new Stock();
var list=new List<ILogicable>{stock,smart,smart,other,sameId,stock,null};SmartComputerDevices.Filter(ref list);
Check(list.Count(x=>ReferenceEquals(x,smart))==1,"same module appears twice");Check(list.Contains(other),"different module with same name disappeared");Check(!list.Contains(sameId),"same network identity appears twice");Check(list.Count(x=>ReferenceEquals(x,stock))==2,"unrelated native devices modified");Check(list.Contains(null),"unrelated null entry modified");
var ghost=new SmartModule{ReferenceId=3,IsCursor=true};var dying=new SmartModule{ReferenceId=4,IsBeingDestroyed=true};var template=new SmartModule();list.AddRange(new[]{ghost,dying,template});SmartComputerDevices.Filter(ref list);Check(!list.Contains(ghost)&&!list.Contains(dying)&&!list.Contains(template),"cursor/deleted/template appears in editor");
smart.Name="Another name";SmartComputerDevices.Filter(ref list);Check(list.Contains(smart)&&list.Contains(other),"renaming changed identity");var previous=list.ToArray();SmartComputerDevices.Filter(ref list);Check(list.SequenceEqual(previous),"filter not idempotent or changed order");
List<ILogicable> empty=null;SmartComputerDevices.Filter(ref empty);Check(empty==null,"null result changed");
var holders=new List<ICircuitHolder>{smart,smart,other,sameId};var names=new List<string>{"A","duplicate A","B","same ID"};SmartComputerDevices.FilterLuaHolders(holders,names);Check(holders.Count==2&&ReferenceEquals(holders[0],smart)&&ReferenceEquals(holders[1],other),"Lua editor retained duplicate or removed distinct Smart");Check(names.SequenceEqual(new[]{"A","B"}),"Lua holder/name pairing broken");SmartComputerDevices.FilterLuaHolders(holders,names);Check(holders.Count==2,"Lua filtering not idempotent");names.Add("invalid");SmartComputerDevices.FilterLuaHolders(holders,names);Check(holders.Count==2&&names.Count==3,"mismatched foreign list changed");
Console.WriteLine(n+" Smart editor identity checks passed: repeated instance/ID collapsed, same-name different modules preserved, native entries untouched, invalid Smart entries excluded.");
class Stock:ILogicable{}
namespace Assets.Scripts.Objects.Pipes{public interface ILogicable{}}
namespace ModularSwitchboards{class SmartModule:ILogicable,ICircuitHolder{public long ReferenceId;public bool IsCursor,IsBeingDestroyed;public string Name;}}

namespace Assets.Scripts.Objects.Electrical{public interface ICircuitHolder{}}
