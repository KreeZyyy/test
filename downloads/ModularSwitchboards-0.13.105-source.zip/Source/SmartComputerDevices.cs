using System.Collections.Generic;
using Assets.Scripts.Objects.Pipes;
using Assets.Scripts.Objects.Electrical;
namespace ModularSwitchboards
{
    internal static class SmartComputerDevices
    {
        internal static void FilterLuaHolders(List<ICircuitHolder> holders,List<string> names)
        {
            if(holders==null||names==null||holders.Count!=names.Count)return;
            var instances=new HashSet<SmartModule>();var ids=new HashSet<long>();
            for(int i=0;i<holders.Count;i++)
                if(holders[i] is SmartModule smart&&(smart.IsCursor||smart.IsBeingDestroyed||smart.ReferenceId==0||SmartDeviceIdentity.Duplicate(smart,smart.ReferenceId,instances,ids)))
                {holders.RemoveAt(i);names.RemoveAt(i);i--;}
        }
        internal static void Filter(ref List<ILogicable> __result)
        {
            if(__result==null)return;
            var instances=new HashSet<SmartModule>();var ids=new HashSet<long>();
            __result.RemoveAll(item=>item is SmartModule smart&&(smart.IsCursor||smart.IsBeingDestroyed||smart.ReferenceId==0||SmartDeviceIdentity.Duplicate(smart,smart.ReferenceId,instances,ids)));
        }
    }
}
