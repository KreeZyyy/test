using System.Collections.Generic;
using Assets.Scripts;
using Assets.Scripts.Inventory;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Items;
using UnityEngine;
namespace ModularSwitchboards
{
    // Native RaycastHit.transform can be the cabinet's rigidbody transform even
    // when the ray hit a separately mounted child Thing. Resolve the hit collider.
    internal static class SwitchboardCursorTarget
    {
        internal static void BeforeRaycast()=>DoorLabelPlacementSurface.RefreshAll();
        internal static void AfterRaycast(CursorManager __instance)
        {
            var hit=__instance.CursorTargetCollider;
            if(hit==null)return;
            var target=hit.GetComponentInParent<Thing>();
            if(target is DoorLabel||target is SwitchboardLabel||target is DinBreaker part&&part.IsDoorPart)
            {
                if(!target.IsCursor&&target.GetComponentInParent<SwitchboardCabinet>()!=null)
                    __instance.FoundThing=target;
            }
        }
    }
    public sealed class DoorLabelPlacementSurface:MonoBehaviour
    {
        private static readonly HashSet<DoorLabelPlacementSurface> Live=new HashSet<DoorLabelPlacementSurface>();
        private void OnEnable()=>Live.Add(this);
        private void OnDisable()=>Live.Remove(this);
        internal static void RefreshAll()
        {
            bool placing=!GameManager.IsBatchMode&&InventoryManager.CurrentMode==InventoryManager.Mode.Placement&&InventoryManager.ActiveHandSlot?.Get() is MultiConstructor kit&&kit.PrefabName==SwitchboardsMod.LabelKitName&&InventoryManager.ConstructionCursor is DoorLabel;
            foreach(var view in Live)
            {
                if(view==null)continue;
                var host=view.GetComponent<SwitchboardCabinet>();if(host==null)continue;
                var surface=view.transform.Find("SwitchboardModel/CompletedShell/DoorHinge/DoorModuleBoard/DoorLabelSurface")?.GetComponent<BoxCollider>();
                if(surface!=null)surface.enabled=!host.IsCursor&&host.IsStructureCompleted&&placing;
            }
        }
    }
}
