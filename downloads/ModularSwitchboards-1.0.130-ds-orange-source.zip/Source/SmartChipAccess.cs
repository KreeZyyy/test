using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Assets.Scripts.Objects;
using HarmonyLib;
using UnityEngine;
namespace ModularSwitchboards
{
    // Native UpdateStateVisualizer can skip interaction-cache updates when a
    // stage renderer has no cached draw data. Slot usability must instead follow
    // completed construction, including a Core completed after its initial Awake.
    internal static class SmartChipAccess
    {
        private static readonly FieldInfo Slots=AccessTools.Field(typeof(Thing),"_slotLookup");
        private static readonly FieldInfo Actions=AccessTools.Field(typeof(Thing),"_interactableLookup");
        private static readonly FieldInfo Hits=AccessTools.Field(typeof(Thing),"_interactableColliderLookup");
        internal static void Refresh(SmartModule owner)
        {
            if(owner.IsCursor||owner.CurrentBuildStateIndex<0||owner.Slots.Count!=1)return;
            var slot=owner.Slots[0];var hit=slot.Collider;if(hit==null)return;
            bool complete=owner.IsStructureCompleted;
            slot.IsInteractable=complete;
            hit.gameObject.SetActive(complete);
            hit.enabled=complete&&owner.Cabinet!=null&&owner.Cabinet.CanAccessModules;
            var slots=Slots?.GetValue(owner) as Dictionary<Collider,Slot>;
            var actions=Actions?.GetValue(owner) as Dictionary<InteractableType,Interactable>;
            var hits=Hits?.GetValue(owner) as Dictionary<Collider,Interactable>;
            if(!complete)
            {
                slots?.Remove(hit);actions?.Remove(InteractableType.Slot1);hits?.Remove(hit);
                return;
            }
            var state=owner.BuildStates[owner.BuildStates.Count-1];
            var action=state.Interactables.FirstOrDefault(i=>i.Action==InteractableType.Slot1);
            if(action==null)return;
            bool changed=!ReferenceEquals(owner.Interactables,state.Interactables);
            if(changed){owner.Interactables=state.Interactables;owner.CacheStates(true);}
            bool needsBind=changed||slots==null||!slots.TryGetValue(hit,out var boundSlot)||!ReferenceEquals(boundSlot,slot)||
                actions==null||!actions.TryGetValue(InteractableType.Slot1,out var boundAction)||!ReferenceEquals(boundAction,action)||
                hits==null||!hits.TryGetValue(hit,out var boundHit)||!ReferenceEquals(boundHit,action);
            if(!needsBind)return;
            action.Parent=owner;action.Collider=hit;action.Initialize();action.CacheBounds();
            // Preserve the existing slot, chip and seating transform. Rebind only
            // native lookup tables used by cursor selection and item insertion.
            if(slots!=null)slots[hit]=slot;
            if(Actions!=null){if(actions==null){actions=new Dictionary<InteractableType,Interactable>();Actions.SetValue(owner,actions);}actions[InteractableType.Slot1]=action;}
            if(Hits!=null){if(hits==null){hits=new Dictionary<Collider,Interactable>();Hits.SetValue(owner,hits);}hits[hit]=action;}
            Thing._colliderLookup[hit]=owner;
            Debug.Log("[Modular Switchboards] Core IC10 access rebound: stage="+owner.CurrentBuildStateIndex+"; slot="+(slots!=null)+"; action="+(actions!=null)+"; collider="+hit.enabled);
        }
    }
}
