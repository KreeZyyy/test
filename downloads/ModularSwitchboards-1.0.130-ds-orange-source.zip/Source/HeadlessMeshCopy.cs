using System;
using System.Collections.Generic;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class HeadlessMeshCopy
    {
        internal static Mesh Selected(Mesh source,IEnumerable<int>[] groups,string name)
        {
            if(source==null||!source.isReadable)throw new InvalidOperationException("Headless mesh copy requires CPU-readable native vertex data.");
            var copy=UnityEngine.Object.Instantiate(source);copy.name=name;
            copy.subMeshCount=groups.Length;
            for(int role=0;role<groups.Length;role++)copy.SetTriangles(new List<int>(groups[role]),role,false);
            return copy;
        }
    }
}
