using Assets.Scripts.Objects;
using UnityEngine;

namespace ModularSwitchboards
{
    // The game's existing Open interaction is saved and synchronized by Thing.
    // This component only presents that state using the new door geometry.
    [DefaultExecutionOrder(-200)]
    public sealed class CabinetDoor : MonoBehaviour
    {
        public Structure Owner;
        public Transform Hinge,RightHinge;
        private bool initialized;
        private float angle;

        // Save/join restoration must place the physical door before the first
        // physics step, rather than leaving a closed prefab door until rendering.
        internal void RestorePose()
        {
            if(Owner==null||Hinge==null)return;
            angle=Owner.IsOpen?-110f:0f;
            initialized=true;
            ApplyPose();
        }
        private void FixedUpdate(){if(!initialized)RestorePose();}
        private void ApplyPose()
        {
            Hinge.localRotation=Quaternion.Euler(0f,angle,0f);
            if(RightHinge!=null)RightHinge.localRotation=Quaternion.Euler(0f,-angle,0f);
        }
        private void LateUpdate()
        {
            if (Owner == null || Hinge == null) return;
            float target = Owner.IsOpen ? -110f : 0f;
            angle = initialized ? Mathf.MoveTowards(angle, target, Time.deltaTime * 220f) : target;
            initialized = true;
            ApplyPose();
        }
    }
}
