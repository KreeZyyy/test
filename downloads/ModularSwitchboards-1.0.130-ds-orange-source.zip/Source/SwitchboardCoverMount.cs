using Assets.Scripts;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Objects;
using LibConstruct;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class SwitchboardCoverMount
    {
        internal static int KitCount(SwitchboardCabinet host)=>CabinetShape.Medium(host.PrefabName)?2:1;
        internal static string PrefabFor(SwitchboardCabinet host)=>CabinetShape.Medium(host.PrefabName)?SwitchboardsMod.MediumCoverName:SwitchboardsMod.CoverName;
        internal static bool IsKit(DynamicThing item)=>item is PortableCoverItem||item is MultiConstructor&&item.PrefabName==SwitchboardsMod.CoverKitName;
        internal static bool ShouldCommit(bool valid,bool doAction,bool authority,float completed)=>valid&&doAction&&authority&&completed>=1f;
        internal static bool TryAttack(SwitchboardCabinet host,Attack attack,bool doAction,out Thing.DelayedActionInstance result)
        {
            result=null;if(CoverTransfer.Mount(host,attack,doAction,out result))return true;if(!IsKit(attack.SourceItem))return false;
            var kit=(MultiConstructor)attack.SourceItem;
            result=new Thing.DelayedActionInstance{Duration=2f,ActionMessage="Fit Switchboard Cover",ActionSoundHash=kit.ConstructingSoundHash,ActionCompleteSoundHash=kit.FinishedConstructingSoundHash};
            if(attack.IsDestroy||attack.IsCopy){result.Fail("Hold left click to fit the cover.");return true;}
            if(host==null||host.IsCursor||host.IsBeingDestroyed||!host.IsStructureCompleted||!host.IsOpen){result.Fail("Open the completed switchboard first.");return true;}
            if(host.HasInnerCover){result.Fail("The switchboard already has a cover.");return true;}
            int required=KitCount(host);
            if(kit.Quantity<required){result.Fail(required+" Kit (Switchboard Cover) required.");return true;}
            var actor=kit.RootParentHuman;
            if(actor==null||(actor.Transform.position-host.Transform.position).sqrMagnitude>9f||!host.Wiring.ContainsInteractionPoint(attack.Position))
            {result.Fail("Aim inside a nearby open switchboard.");return true;}
            var prefab=Prefab.Find<InnerCoverModule>(PrefabFor(host));
            if(prefab==null||actor.OrganBrain==null||!InnerCoverModule.CanPlace(host.CoverBoard,new Grid3(0,0,0),0))
            {result.Fail("The cover mounting point is unavailable.");return true;}
            if(ShouldCommit(true,doAction,GameManager.RunSimulation,attack.CompletedRatio))
            {
                // Native LibConstruct consumes the size-specific prefab cost, creates/registers
                // the board structure and replicates it. Never use an authoring bypass.
                PlacementBoard.CreateBoardStructure(new CreateBoardStructureInstance(kit,prefab,host.CoverBoard,new Grid3(0,0,0),0,actor.OrganBrain.ClientId,false));
                if(!host.HasInnerCover)result.Fail("Could not fit the cover.");
            }
            return true;
        }
    }
}
