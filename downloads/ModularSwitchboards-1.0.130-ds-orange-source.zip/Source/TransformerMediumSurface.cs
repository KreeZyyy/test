using System;
using System.IO;
using System.Reflection;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class TransformerMediumSurface
    {
        private static Material material;
        internal static Material Material
        {
            get
            {
                if(material!=null)return material;
                var shader=ServerGraphics.FindShader("Standard");if(shader==null||!ServerGraphics.ShaderAvailable(shader))throw new InvalidOperationException("Transformer reference shader unavailable");
                using(var stream=Assembly.GetExecutingAssembly().GetManifestResourceStream("ModularSwitchboards.Transformer.MediumAtlas.png"))
                using(var bytes=new MemoryStream())
                {
                    if(stream==null)throw new InvalidDataException("Transformer atlas missing");stream.CopyTo(bytes);var texture=new Texture2D(2,2,TextureFormat.RGBA32,false){name="Switchboards.Transformer.ReferenceAtlas"};
                    if(!ImageConversion.LoadImage(texture,bytes.ToArray(),true))throw new InvalidDataException("Transformer atlas invalid");
                    material=new Material(shader){name="Switchboards.Transformer.ReferenceSurface",mainTexture=texture,color=Color.white};material.SetFloat("_Glossiness",.25f);material.SetFloat("_Metallic",0);return material;
                }
            }
        }
    }
}
