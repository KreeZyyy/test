using System.Collections.Generic;
using System.Linq;
using Assets.Scripts;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class FittedCoverIcons
    {
        private static readonly Dictionary<int,Sprite> cache=new Dictionary<int,Sprite>();
        internal static Sprite Create(CoverMemory state)
        {
            if(ServerGraphics.Headless)return null;
            const int size=128;var tint=(Color32)(GameManager.IsValidColor(state.Colour)?GameManager.GetColorSwatch(state.Colour).Color:Color.white);
            var holes=state.Retained.Select(h=>new CoverIconRect(h.Left,h.Right,h.Bottom,h.Top)).ToArray();
            var labels=state.Labels.Select(l=>{float x=-state.HalfSpan+l.X*.00045f+(l.Width-1)*DinLayout.SlotPitch*.5f,y=.0525f+l.Y*.00045f,w=l.Width*DinLayout.SlotPitch-.0068f;return new CoverIconRect(x-w*.5f,x+w*.5f,y-.0075f,y+.0075f);}).ToArray();
            var texture=new Texture2D(size,size,TextureFormat.RGBA32,false){name="Switchboards.FittedCover.ShapeIcon"};
            texture.SetPixels32(CoverIconRaster.Build(state.Width,state.Height,holes,labels,tint,size));texture.Apply(false,true);
            return Sprite.Create(texture,new Rect(0,0,size,size),new Vector2(.5f,.5f),100f);
        }
        internal static Sprite Get(int colour)
        {
            if(ServerGraphics.Headless)return null;
            if(cache.TryGetValue(colour,out var icon))return icon;
            var source=CabinetIcons.Get("InnerCover");
            if(!GameManager.IsValidColor(colour))return source;
            var swatch=GameManager.GetColorSwatch(colour);if(swatch==null)return source;
            var original=source.texture;
            var pixels=original.GetPixels32();var tint=(Color32)swatch.Color;
            for(int i=0;i<pixels.Length;i++)
            {
                var p=pixels[i];pixels[i]=new Color32((byte)(p.r*tint.r/255),(byte)(p.g*tint.g/255),(byte)(p.b*tint.b/255),p.a);
            }
            var texture=new Texture2D(original.width,original.height,TextureFormat.RGBA32,false){name="Switchboards.FittedCover.Icon."+colour};
            texture.SetPixels32(pixels);texture.Apply(false,true);
            icon=Sprite.Create(texture,new Rect(0,0,texture.width,texture.height),new Vector2(.5f,.5f),100f);icon.name=texture.name;
            cache[colour]=icon;return icon;
        }
    }
}
