using HarmonyLib;
using UnityEngine;
using UnityEngine.Rendering;
namespace ModularSwitchboards
{
    internal static class PlacementPreviewStyle
    {
        // Use the actual imported-blueprint prefab. Its material keeps the game's
        // shader, textures and animation parameters; no custom animation clock.
        internal static Material NativeFill()
        {
            var type=AccessTools.TypeByName("ThingImport.ThingImporter");
            if(type==null)return null;
            var instance=AccessTools.Field(type,"Instance")?.GetValue(null);
            if(instance==null)return null;
            var template=AccessTools.Field(type,"_blueprintTemplate")?.GetValue(instance) as Component;
            var filter=template==null?null:AccessTools.Field(template.GetType(),"_meshFilter")?.GetValue(template) as MeshFilter;
            var renderer=filter==null?null:filter.GetComponent<MeshRenderer>();
            if(renderer==null||renderer.sharedMaterial==null)return null;
            return new Material(renderer.sharedMaterial){name="Switchboards.NativeBlueprint"};
        }
        internal static Material Ink(float alpha,CullMode cull)
        {
            var shader=ServerGraphics.FindShader("Hidden/Internal-Colored");if(shader==null||!ServerGraphics.ShaderAvailable(shader))return null;
            var colour=Color.green;colour.a=alpha;var material=new Material(shader){name="Switchboards.PlacementEdges",color=colour};
            material.SetInt("_SrcBlend",(int)BlendMode.SrcAlpha);material.SetInt("_DstBlend",(int)BlendMode.OneMinusSrcAlpha);material.SetInt("_Cull",(int)cull);material.SetInt("_ZWrite",0);return material;
        }
        internal static void Surface(MeshRenderer renderer,Material[] materials){renderer.sharedMaterials=materials;renderer.shadowCastingMode=ShadowCastingMode.Off;renderer.receiveShadows=false;}
    }
    internal sealed class PlacementPreviewResources:MonoBehaviour
    {
        internal Mesh Fill,Edges;internal Material[] Materials;
        internal void FollowValidity(Color tint)
        {
            if(Materials==null||Materials.Length<2||Materials[1]==null)return;
            tint.a=Materials[1].color.a;Materials[1].color=tint;
        }
        private void OnDestroy(){if(Fill!=null)Destroy(Fill);if(Edges!=null)Destroy(Edges);if(Materials!=null)foreach(var material in Materials)if(material!=null)Destroy(material);}
    }
}
