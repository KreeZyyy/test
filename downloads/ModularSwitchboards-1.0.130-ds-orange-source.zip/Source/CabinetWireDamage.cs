using System;
using System.Collections.Generic;
using System.Linq;
using Assets.Scripts;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Objects.Electrical;
using Assets.Scripts.Sound;
using Assets.Scripts.Util;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class CabinetWireDamage
    {
        private static Material charred;
        private static Material conductor;
        internal static Mesh Build(WirePoint[] path,CabinetWireKind kind)=>WireRuptureMesh.Build(path,kind);
        internal static Mesh Body(WirePoint[] path,CabinetWireKind kind,out Mesh damage)
        {
            var full=Build(path,kind);int count=WireVisualProfiles.Get(kind).Materials;
            var body=WireRuptureMesh.Part(full,0,count);damage=WireRuptureMesh.Part(full,count,2);UnityEngine.Object.Destroy(full);return body;
        }
        internal static void Surface(MeshRenderer renderer)
        {
            WireVisualLighting.Apply(renderer);
            if(charred==null){charred=new Material(ServerGraphics.FindShader("Standard")){name="Switchboards.LocalScorch",color=new Color(.035f,.025f,.020f)};CabinetMatteSurface.Configure(charred);}
            if(conductor==null){conductor=new Material(ServerGraphics.FindShader("Standard")){name="Switchboards.ExposedConductors",color=new Color(.32f,.36f,.35f)};conductor.SetFloat("_Metallic",.75f);conductor.SetFloat("_Glossiness",.25f);}
            renderer.sharedMaterials=new[]{charred,conductor};
        }
        internal static void Play(Vector3 position)
        {
            if(GameManager.GameState!=GameState.Running||GameManager.IsBatchMode)return;
            var world=WorldManager.Instance;if(world!=null&&world.Sparker!=null)world.Sparker.Emit(new ParticleSystem.EmitParams{position=position},100);
            var audio=Singleton<AudioManager>.Instance;if(audio!=null)audio.PlayAudioClipsData(CableRuptured.CableSparkHash,position);
        }
    }
}
