using System.Linq;
using UnityEngine;
namespace ModularSwitchboards
{
    internal sealed class DoorLedColour
    {
        internal string Name,Title,Icon;
        internal Color Off,On,Emission,Light;
    }
    internal static class DoorLedColours
    {
        internal const string GreenName="StructureSwitchboardDoorLedGreen",BlueName="StructureSwitchboardDoorLedBlue",WhiteName="StructureSwitchboardDoorLedWhite",RedName="StructureSwitchboardDoorLedRed",OrangeName="StructureSwitchboardDoorLedOrange";
        internal static readonly DoorLedColour[] All={
            new DoorLedColour{Name=GreenName,Title="Door LED Green",Icon="DoorLed",Off=new Color(.06f,.32f,.035f),On=new Color(.035f,.75f,.08f),Emission=new Color(.04f,1.4f,.10f),Light=new Color(.04f,1f,.08f)},
            new DoorLedColour{Name=BlueName,Title="Door LED Blue",Icon="DoorLedBlue",Off=new Color(.025f,.06f,.28f),On=new Color(.035f,.20f,.95f),Emission=new Color(.07f,.30f,1.4f),Light=new Color(.08f,.30f,1f)},
            new DoorLedColour{Name=WhiteName,Title="Door LED White",Icon="DoorLedWhite",Off=new Color(.38f,.40f,.42f),On=new Color(.90f,.94f,1f),Emission=new Color(1.4f,1.4f,1.4f),Light=new Color(1f,1f,1f)},
            new DoorLedColour{Name=RedName,Title="Door LED Red",Icon="DoorLedRed",Off=new Color(.32f,.025f,.02f),On=new Color(.75f,.035f,.025f),Emission=new Color(1.4f,.04f,.03f),Light=new Color(1f,.04f,.03f)},
            new DoorLedColour{Name=OrangeName,Title="Door LED Orange",Icon="DoorLedOrange",Off=new Color(.38f,.12f,.015f),On=new Color(1f,.32f,.015f),Emission=new Color(1.4f,.45f,.025f),Light=new Color(1f,.32f,.02f)}
        };
        internal static DoorLedColour Find(string name)=>All.FirstOrDefault(c=>c.Name==name);
        internal static DoorLedColour For(string name)=>Find(name)??All[0];
    }
}
