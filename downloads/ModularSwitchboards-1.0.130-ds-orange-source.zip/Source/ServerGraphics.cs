using System.Linq;
using Assets.Scripts;
using Assets.Scripts.Objects.Electrical;
using UnityEngine;
using UnityEngine.Rendering;
namespace ModularSwitchboards
{
    internal static class ServerGraphics
    {
        internal static bool Headless=>GameManager.IsBatchMode||SystemInfo.graphicsDeviceType==GraphicsDeviceType.Null;
        internal static bool ShaderAvailable(Shader shader)=>shader!=null&&(Headless||shader.isSupported);
        internal static Material PaintTemplate()
        {
            var material=GameManager.GetTextureArrayColorMaterial();
            if(material!=null&&material.shader!=null)return material;
            if(!Headless)return material;
            // Native prefab materials can exist even when the renderer-wide
            // texture-array material is not initialized by a dedicated server.
            return WorldManager.Instance?.SourcePrefabs.OfType<AreaPowerControl>()
                .Select(apc=>apc.PaintableMaterial).FirstOrDefault(m=>m!=null&&m.shader!=null);
        }
        internal static Shader FindShader(string name)
        {
            var shader=Shader.Find(name);
            return shader!=null||!Headless?shader:PaintTemplate()?.shader;
        }
    }
}
