using UnityEngine;
namespace ModularSwitchboards
{
    internal static class TransformerFrontSurface
    {
        private static Material[] materials;
        internal static Material[] Materials
        {
            get
            {
                if(materials!=null)return materials;
                var shader=ServerGraphics.FindShader("Standard");
                if(shader==null||!ServerGraphics.ShaderAvailable(shader))throw new System.InvalidOperationException("Transformer front shader unavailable.");
                var colors=new[]{new Color(.25f,.28f,.28f),new Color(.045f,.05f,.05f),new Color(.43f,.19f,.085f),new Color(.075f,.08f,.075f),new Color(.67f,.69f,.66f)};
                materials=new Material[colors.Length];
                for(int i=0;i<colors.Length;i++){var m=new Material(shader){name="Switchboards.OwnTransformerSurface."+i,color=colors[i]};m.SetFloat("_Glossiness",i==2?.28f:.12f);m.SetFloat("_Metallic",i==2?.4f:0);materials[i]=m;}
                // Same native texture-array material and palette entry as breaker fascia.
                var fascia=new Material(CabinetGeometry.Materials[3]){name="Switchboards.Transformer.BreakerFascia"};
                fascia.SetFloat(Assets.Scripts.Objects.Thing.DiffuseIndexPropertyID,CabinetGeometry.PaletteIndices[3]);
                fascia.SetFloat(Assets.Scripts.Objects.Thing.SmoothnessIndexPropertyID,0f);
                fascia.SetColor(Assets.Scripts.Objects.Thing.EMISSION_COLOR,Color.black);materials[0]=fascia;
                return materials;
            }
        }
        internal static void Restore(DinTransformer owner)
        {
            var front=owner.transform.Find("TransformerFront");if(front==null)return;
            var renderer=front.GetComponent<MeshRenderer>();if(renderer==null)return;
            var block=new MaterialPropertyBlock();renderer.GetPropertyBlock(block,0);
            block.SetFloat(Assets.Scripts.Objects.Thing.DiffuseIndexPropertyID,CabinetGeometry.PaletteIndices[3]);
            block.SetFloat(Assets.Scripts.Objects.Thing.SmoothnessIndexPropertyID,0f);
            block.SetColor(Assets.Scripts.Objects.Thing.EMISSION_COLOR,Color.black);renderer.SetPropertyBlock(block,0);
        }
    }
}
