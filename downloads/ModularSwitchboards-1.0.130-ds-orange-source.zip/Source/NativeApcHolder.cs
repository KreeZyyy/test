using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using UnityEngine;
using UnityEngine.Rendering;
namespace ModularSwitchboards
{
    // One native renderer/mesh, preserving every source vertex stream, channel,
    // material slot and property block. Only the index list is restricted.
    internal static class NativeApcHolder
    {
        private static Mesh nativeMesh,preview;
        private static MeshRenderer original;
        private static Matrix4x4 toFrame;
        private static Vector3 slotCenter;
        private static float fit;
        internal static Mesh Capture(MeshRenderer source,Matrix4x4 sourceToFrame,Vector3 center,float scale)
        {
            if(nativeMesh!=null)return preview;
            original=source??throw new InvalidOperationException("APC holder renderer missing");
            var sourceMesh=source.GetComponent<MeshFilter>()?.sharedMesh??throw new InvalidOperationException("APC holder mesh missing");
            CabinetGeometry.ReadNativeMesh(sourceMesh,out var positions,out var uv,out var groups);
            var framePositions=positions.Select(p=>sourceToFrame.MultiplyPoint3x4(p)).ToArray();
            var selected=NativeHolderSelection.Select(framePositions,groups);
            int triangles=selected.Sum(t=>t.Count)/3;
            if(triangles<100||triangles>300)throw new InvalidOperationException("APC holder selection changed: "+triangles+" triangles");
            if(source.sharedMaterials.Length!=selected.Length)throw new InvalidOperationException("APC holder material slots mismatch");
            if(ServerGraphics.Headless)
            {
                nativeMesh=HeadlessMeshCopy.Selected(sourceMesh,selected,"Switchboards.OriginalAPCHolder.CPU");
            }
            else
            {
            nativeMesh=new Mesh{name="Switchboards.OriginalAPCHolder.AllVertexChannels",indexFormat=sourceMesh.indexFormat};
            nativeMesh.SetVertexBufferParams(sourceMesh.vertexCount,sourceMesh.GetVertexAttributes());
            foreach(var attribute in sourceMesh.GetVertexAttributes())
                if(nativeMesh.GetVertexAttributeOffset(attribute.attribute)!=sourceMesh.GetVertexAttributeOffset(attribute.attribute)||
                   nativeMesh.GetVertexAttributeStream(attribute.attribute)!=sourceMesh.GetVertexAttributeStream(attribute.attribute))
                    throw new InvalidOperationException("APC vertex attribute layout changed: "+attribute.attribute);
            var data=new List<uint[]>();
            for(int stream=0;stream<sourceMesh.vertexBufferCount;stream++)
            {
                if(nativeMesh.GetVertexBufferStride(stream)!=sourceMesh.GetVertexBufferStride(stream))throw new InvalidOperationException("APC vertex stride changed");
                using(var buffer=sourceMesh.GetVertexBuffer(stream))
                {
                    int bytes=buffer.count*buffer.stride;
                    if(bytes%4!=0)throw new InvalidOperationException("Unaligned APC vertex stream");
                    var raw=new uint[bytes/4];buffer.GetData(raw);data.Add(raw);
                    nativeMesh.SetVertexBufferData(raw,0,0,raw.Length,stream,MeshUpdateFlags.DontRecalculateBounds|MeshUpdateFlags.DontValidateIndices);
                }
            }
            nativeMesh.subMeshCount=selected.Length;
            for(int role=0;role<selected.Length;role++)nativeMesh.SetTriangles(selected[role],role,false);
            // Verify every byte after setting indices: colors, UV1..7, tangents,
            // compressed normals and unknown future attributes remain intact.
            for(int stream=0;stream<data.Count;stream++)using(var buffer=nativeMesh.GetVertexBuffer(stream))
            {
                var copied=new uint[data[stream].Length];buffer.GetData(copied);
                if(!copied.SequenceEqual(data[stream]))throw new InvalidOperationException("APC vertex stream copy differs from original");
            }
            }
            bool first=true;var bounds=new Bounds();
            foreach(var role in selected)foreach(int index in role){if(first){bounds=new Bounds(positions[index],Vector3.zero);first=false;}else bounds.Encapsulate(positions[index]);}
            nativeMesh.bounds=bounds;
            // A positional mesh is used only for bounds/blueprint, never as the visible holder.
            var v=new List<Vector3>();var t=new List<int>[selected.Length];
            for(int role=0;role<selected.Length;role++)
            {
                t[role]=new List<int>();foreach(int index in selected[role]){t[role].Add(v.Count);v.Add(ApcBatteryRegion.Map(framePositions[index],center,0,scale));}
            }
            preview=new Mesh{name="Switchboards.APCHolder.BlueprintOnly"};preview.SetVertices(v);preview.subMeshCount=t.Length;
            for(int i=0;i<t.Length;i++)preview.SetTriangles(t[i],i);preview.RecalculateNormals();preview.RecalculateBounds();
            toFrame=sourceToFrame;slotCenter=center;fit=scale;
            Debug.Log("[Modular Switchboards] Entire APC holder: "+triangles+" triangles; "+sourceMesh.vertexCount+" original vertex IDs, all "+sourceMesh.vertexBufferCount+" native vertex streams. Attributes: "+string.Join(",",sourceMesh.GetVertexAttributes().Select(a=>a.attribute+"/"+a.format+"x"+a.dimension+"@"+a.stream)));
            return preview;
        }
        internal static GameObject InstallUnfinishedFloor(Transform parent,Bounds aperture)
        {
            CabinetGeometry.ReadNativeMesh(nativeMesh,out var vertices,out _,out var groups);
            var mapped=vertices.Select(p=>ApcBatteryRegion.Map(toFrame.MultiplyPoint3x4(p),slotCenter,0,fit)).ToArray();
            var selected=NativeHolderSelection.Floor(mapped,groups);
            var ids=selected.SelectMany(g=>g).Distinct().ToArray();
            if(ids.Length<3)throw new InvalidOperationException("Native battery floor has no triangles.");
            var localBounds=new Bounds(vertices[ids[0]],Vector3.zero);var mappedBounds=new Bounds(mapped[ids[0]],Vector3.zero);
            foreach(int index in ids){localBounds.Encapsulate(vertices[index]);mappedBounds.Encapsulate(mapped[index]);}
            var floor=UnityEngine.Object.Instantiate(nativeMesh);floor.name="Switchboards.OriginalAPCFloor.AllVertexChannels";
            for(int role=0;role<selected.Length;role++)floor.SetTriangles(selected[role],role,false);
            floor.bounds=localBounds;
            var mount=new GameObject("BatteryUnfinishedBacking"){layer=parent.gameObject.layer};mount.transform.SetParent(parent,false);
            mount.transform.localPosition=ApcBatteryRegion.Map(toFrame.MultiplyPoint3x4(Vector3.zero),slotCenter,0,fit);
            var visual=DinBreakerModel.VisualScale;mount.transform.localScale=new Vector3(1f/visual.x,1f/visual.y,1f/visual.z);
            var go=new GameObject("NativeApcBatteryFloor"){layer=parent.gameObject.layer};go.transform.SetParent(mount.transform,false);
            go.transform.localRotation=toFrame.rotation;go.transform.localScale=toFrame.lossyScale*fit;
            go.AddComponent<MeshFilter>().sharedMesh=floor;
            var renderer=go.AddComponent<MeshRenderer>();NativePortSurface.Capture(original,renderer);
            // Overlap the unfinished aperture, keeping the exact original floor Z.
            var ratio=new Vector3((aperture.size.x+.002f)/mappedBounds.size.x,(aperture.size.y+.002f)/mappedBounds.size.y,1);
            mount.transform.localPosition=mappedBounds.center+Vector3.Scale(mount.transform.localPosition-mappedBounds.center,ratio)+new Vector3(aperture.center.x-mappedBounds.center.x,aperture.center.y-mappedBounds.center.y,0);
            mount.transform.localScale=Vector3.Scale(mount.transform.localScale,ratio);
            return mount;
        }
        internal static Mesh Install(Transform parent)
        {
            if(nativeMesh==null)throw new InvalidOperationException("APC holder not captured");
            var mount=new GameObject("OriginalAPCHolderMount"){layer=parent.gameObject.layer};mount.transform.SetParent(parent,false);
            mount.transform.localPosition=ApcBatteryRegion.Map(toFrame.MultiplyPoint3x4(Vector3.zero),slotCenter,0,fit);
            var visual=DinBreakerModel.VisualScale;
            mount.transform.localScale=new Vector3(1f/visual.x,1f/visual.y,1f/visual.z);
            var go=new GameObject("NativeApcBatteryBay"){layer=parent.gameObject.layer};go.transform.SetParent(mount.transform,false);
            go.transform.localRotation=toFrame.rotation;go.transform.localScale=toFrame.lossyScale*fit;
            go.AddComponent<MeshFilter>().sharedMesh=nativeMesh;
            var renderer=go.AddComponent<MeshRenderer>();renderer.sharedMaterials=original.sharedMaterials;
            var block=new MaterialPropertyBlock();original.GetPropertyBlock(block);renderer.SetPropertyBlock(block);
            for(int i=0;i<original.sharedMaterials.Length;i++){var local=new MaterialPropertyBlock();original.GetPropertyBlock(local,i);renderer.SetPropertyBlock(local.isEmpty?null:local,i);}
            renderer.shadowCastingMode=original.shadowCastingMode;renderer.receiveShadows=original.receiveShadows;
            renderer.lightProbeUsage=original.lightProbeUsage;renderer.reflectionProbeUsage=original.reflectionProbeUsage;
            return preview;
        }
    }
}
