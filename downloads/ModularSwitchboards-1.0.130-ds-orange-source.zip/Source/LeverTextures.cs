using System;
using System.Collections.Generic;
using UnityEngine;

namespace ModularSwitchboards
{
    internal static class LeverTextures
    {
        private static readonly Dictionary<string,Material[]> cache=new Dictionary<string,Material[]>();
        internal static Material[] For(Material[] originals,string colour)
        {
            if(ServerGraphics.Headless||colour=="Yellow")return originals;
            if(cache.TryGetValue(colour,out var found))return found;
            var result=new Material[originals.Length];
            for(int i=0;i<result.Length;i++)
            {
                var source=originals[i];result[i]=source;
                try
                {
                    var texture=source.mainTexture;if(texture==null)throw new InvalidOperationException("No native lever texture");
                    Texture2D copy=null;var previous=RenderTexture.active;
                    var target=RenderTexture.GetTemporary(texture.width,texture.height,0,RenderTextureFormat.ARGB32,RenderTextureReadWrite.sRGB);
                    try
                    {
                        Graphics.Blit(texture,target);RenderTexture.active=target;
                        copy=new Texture2D(texture.width,texture.height,TextureFormat.RGBA32,true,false);
                        copy.ReadPixels(new Rect(0,0,texture.width,texture.height),0,0);copy.Apply();
                    }
                    finally{RenderTexture.active=previous;RenderTexture.ReleaseTemporary(target);}
                    var pixels=copy.GetPixels();int changed=0;
                    for(int p=0;p<pixels.Length;p++)
                    {
                        var old=pixels[p];Color.RGBToHSV(old,out float h,out float s,out float v);
                        // Only the yellow/orange plastic; neutral ON/OFF ink and shading stay intact.
                        if(!IsPlastic(h,s))continue;
                        pixels[p]=Recolour(old,colour);changed++;
                    }
                    if(changed==0){UnityEngine.Object.Destroy(copy);throw new InvalidOperationException("No yellow/orange texels found");}
                    copy.name="Switchboards.Lever."+colour;copy.wrapMode=texture.wrapMode;copy.filterMode=texture.filterMode;copy.anisoLevel=texture.anisoLevel;
                    copy.SetPixels(pixels);copy.Apply(true,true);
                    var material=new Material(source){name="Switchboards.NativeLever."+colour};material.mainTexture=copy;result[i]=material;
                    Debug.Log("[Modular Switchboards] LEVER TEXTURE "+colour+": recoloured="+changed+"/"+pixels.Length+" source="+texture.name+" shader="+source.shader.name);
                }
                catch(Exception ex){Debug.LogWarning("[Modular Switchboards] Lever texture stays native: "+colour+": "+ex.Message);}
            }
            cache[colour]=result;return result;
        }
        internal static Color Recolour(Color old,string colour)
        {
            if(colour=="Yellow")return old;
            Color.RGBToHSV(old,out float h,out float s,out float v);
            if(!IsPlastic(h,s))return old;
            // Keep relative texture shading while bringing the plastic closer to the muted fuse palette.
            var result=Color.HSVToRGB(Hue(colour),s*SaturationScale(colour),v*BrightnessScale(colour));result.a=old.a;return result;
        }
        internal static float BrightnessScale(string colour)
        {
            switch(colour){case "Green":return .55f;case "Orange":return .85f;case "Red":return .70f;case "Purple":return .60f;case "Yellow":return 1f;default:throw new ArgumentOutOfRangeException(nameof(colour));}
        }
        internal static float SaturationScale(string colour)
        {
            switch(colour){case "Green":return .70f;case "Orange":case "Red":return .95f;case "Purple":return .80f;case "Yellow":return 1f;default:throw new ArgumentOutOfRangeException(nameof(colour));}
        }
        internal static bool IsPlastic(float hue,float saturation)=>hue>=0f&&hue<=.20f&&saturation>.25f;
        internal static float Hue(string colour)
        {
            switch(colour){case "Green":return 1f/3f;case "Orange":return .075f;case "Red":return 0f;case "Purple":return .75f;default:throw new ArgumentOutOfRangeException(nameof(colour));}
        }
    }
}
