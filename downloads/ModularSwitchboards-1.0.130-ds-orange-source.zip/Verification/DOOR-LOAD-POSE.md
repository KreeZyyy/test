# Door collider pose on load

CabinetDoor previously updated both visual and physical hinge transforms only in LateUpdate. A saved-open cabinet could retain its closed prefab pose until that first render update. This is a concrete initialization gap and a possible cause of reported player displacement near a cabinet; the displacement has not been reproduced in Unity here.

RestorePose now applies the native saved IsOpen immediately after DeserializeSave and DeserializeOnJoin, and before base registration/load completion. FixedUpdate initializes a newly created door before its first physics simulation if no restoration hook has run. Small and both Medium hinges use the same target angles as before. Ordinary opening/closing retains the 220 degree/second animation. No player position/save data is modified and physical door colliders remain intact.

Validation: 23 production CabinetDoor checks with Unity stubs cover Small/Medium, open/closed, resynchronization, first physics update, late binding and normal animation. Full native-reference build: 0 warnings/errors.

Required in-game regression: save standing close to an OPEN Small and Medium door, reload repeatedly and compare position; repeat closed and farther away; verify collision and normal animation. Root cause/player displacement remains unconfirmed until this test.
