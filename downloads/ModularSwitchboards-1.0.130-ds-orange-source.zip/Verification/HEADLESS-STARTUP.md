# Modular Switchboards 1.0.127 — dedicated-server startup candidate

Based on stable 1.0.126 (the Workshop-linked 1.0.122 line plus IC10 access fix). No Large cabinet prototype changes.

The reported first error, Native game paint material unavailable, comes from graphics validation during prefab preparation. Failed recipe checks follow the aborted prefab transaction. A non-rendering server must not require Shader.isSupported to be true.

- Centralized headless detection (batch mode or Null graphics device) and shader validation. Normal rendered clients still reject unsupported shaders. Missing server-wide paint templates/custom shaders can use an existing native APC material/shader; no null shader is accepted.
- Native CPU-readable meshes are copied with all native channels for the battery holder and analyzer, retaining selected triangles without GPU-buffer readback. Client GPU-copy/verification path is retained.
- Headless startup skips cosmetic warning texture readback, lever recolour blits and thumbnails. Shapes/ports/slots/recipes remain registered normally.
- Non-readable mesh data on a headless server fails with the exact mesh name before attempting GPU access. No fake geometry or placeholder colliders are supplied. Fully stripped native meshes require further matching CPU geometry support.
- Startup log reports headless status and graphics backend; paint failures report whether template/shader is missing.

Validation: native-reference build0warnings/errors;72headless shader/material policy checks;16CPU mesh selection/channel-preservation checks;97IC10 access checks passed. This is NOT a real dedicated-server or multiplayer test. The reporter must verify server startup and joining/constructing with matching clients. Use this same version on the DS and every client. If startup still fails, capture the FIRST complete prefab setup exception and stack trace, not only the later recipe failures. Steam Workshop has not been updated.

