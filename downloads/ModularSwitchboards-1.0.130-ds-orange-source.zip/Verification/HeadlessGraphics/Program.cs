using System;using System.Collections.Generic;using ModularSwitchboards;using UnityEngine;using UnityEngine.Rendering;using Assets.Scripts;using Assets.Scripts.Objects.Electrical;
namespace UnityEngine.Rendering{public enum GraphicsDeviceType{Null,Direct3D11}}
namespace UnityEngine{public class Shader{public bool Supported;public int Reads;public bool isSupported{get{Reads++;return Supported;}}public static Dictionary<string,Shader> Registry=new();public static Shader Find(string n)=>Registry.TryGetValue(n,out var s)?s:null;}public class Material{public Shader shader;}public static class SystemInfo{public static GraphicsDeviceType graphicsDeviceType;}}
namespace Assets.Scripts{public static class GameManager{public static bool IsBatchMode;public static Material Template;public static Material GetTextureArrayColorMaterial()=>Template;}}
namespace Assets.Scripts.Objects.Electrical{public class AreaPowerControl{public Material PaintableMaterial;}}
public class WorldManager{public static WorldManager Instance=new();public List<object> SourcePrefabs=new();}
class Program{static int n;static void Check(bool b,string why){n++;if(!b)throw new Exception(why);}static void Main(){
foreach(bool batch in new[]{false,true})foreach(bool nullDevice in new[]{false,true})foreach(bool supported in new[]{false,true}){
GameManager.IsBatchMode=batch;SystemInfo.graphicsDeviceType=nullDevice?GraphicsDeviceType.Null:GraphicsDeviceType.Direct3D11;var shader=new Shader{Supported=supported};Shader.Registry.Clear();GameManager.Template=new(){shader=shader};WorldManager.Instance=new();
Check(ServerGraphics.Headless==(batch||nullDevice),"wrong headless detection");Check(ServerGraphics.ShaderAvailable(shader)==(batch||nullDevice||supported),"unsupported client shader accepted or valid server shader rejected");Check(!ServerGraphics.ShaderAvailable(null),"null shader accepted");Check(shader.Reads==((batch||nullDevice)?0:1),"headless still queried shader support");Check(ServerGraphics.PaintTemplate()==GameManager.Template,"native template changed");
var fallback=new Material{shader=new Shader()};WorldManager.Instance.SourcePrefabs.Add(new AreaPowerControl{PaintableMaterial=fallback});GameManager.Template=null;
Check((ServerGraphics.PaintTemplate()==fallback)==(batch||nullDevice),"native-prefab material fallback leaked to client or failed server");
Check((ServerGraphics.FindShader("missing")==fallback.shader)==(batch||nullDevice),"missing custom shader did not use server prefab shader");
var found=new Shader{Supported=false};Shader.Registry["present"]=found;Check(ServerGraphics.FindShader("present")==found,"existing shader replaced");WorldManager.Instance=null;Check(ServerGraphics.PaintTemplate()==null,"missing WorldManager should fail clearly, not throw");
}
Console.WriteLine(n+" production headless material/shader policy checks passed; normal-client validation preserved.");}}
