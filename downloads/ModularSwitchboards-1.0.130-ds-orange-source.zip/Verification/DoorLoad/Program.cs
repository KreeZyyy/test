using System;using System.Reflection;using ModularSwitchboards;using UnityEngine;using Assets.Scripts.Objects;
namespace Assets.Scripts.Objects{public class Structure{public bool IsOpen;}}
namespace UnityEngine{public class MonoBehaviour{}public class DefaultExecutionOrder:Attribute{public DefaultExecutionOrder(int n){}}public class Transform{public Quaternion localRotation;}public struct Quaternion{public float y;public static Quaternion Euler(float x,float y,float z)=>new(){y=y};}public static class Time{public static float deltaTime=.1f;}public static class Mathf{public static float MoveTowards(float a,float b,float d)=>a<b?Math.Min(a+d,b):Math.Max(a-d,b);}}
class Program{static int n;static void Check(bool b){n++;if(!b)throw new Exception("check "+n);}static void Call(CabinetDoor d,string m)=>typeof(CabinetDoor).GetMethod(m,BindingFlags.NonPublic|BindingFlags.Instance).Invoke(d,null);static void Main(){
foreach(bool medium in new[]{false,true})foreach(bool open in new[]{false,true}){
var owner=new Structure{IsOpen=open};var d=new CabinetDoor{Owner=owner,Hinge=new(),RightHinge=medium?new():null};
d.RestorePose();Check(d.Hinge.localRotation.y==(open?-110:0));if(medium)Check(d.RightHinge.localRotation.y==(open?110:0));
Call(d,"FixedUpdate");Check(d.Hinge.localRotation.y==(open?-110:0));
owner.IsOpen=!open;Call(d,"LateUpdate");Check(d.Hinge.localRotation.y==(open?-88:-22));
d.RestorePose();Check(d.Hinge.localRotation.y==(open?0:-110));if(medium)Check(d.RightHinge.localRotation.y==(open?0:110));
}
var fresh=new CabinetDoor{Owner=new(){IsOpen=true},Hinge=new()};Call(fresh,"FixedUpdate");Check(fresh.Hinge.localRotation.y==-110);Call(fresh,"LateUpdate");Check(fresh.Hinge.localRotation.y==-110);
var pending=new CabinetDoor();Call(pending,"FixedUpdate");pending.Owner=new(){IsOpen=true};pending.Hinge=new();Call(pending,"FixedUpdate");Check(pending.Hinge.localRotation.y==-110);
Console.WriteLine(n+" door load/physics/animation checks passed.");}}
