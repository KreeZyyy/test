# Local 1.0.101 — profiled cabinet skeleton (not uploaded)

Last published is 1.0.99. 1.0.100 was a local rectangular-skeleton draft, explicitly not uploaded after user flagged mismatch with Small/Medium shapes. Current user instruction: dolad to.

CabinetSkeletonGeometry.Profile derives from native housing .4/.5/R.02 or .8/1/R.04; offset 6 mm Small /12 mm Medium skin plus fixed .5 mm clearance. Rounded inner radius subtracts rail section12/24 mm. Use native housing12-step quarter arc sampling. Rings at z=.0065-.0265 and .1595-.1795, same depth both sizes. Four8/16 mm corner rails sit diagonally in the rounded-ring section. Build mesh with outward winding and smooth radial normals, preserve native frame material role4 and native UV mapping.

CabinetSkeleton.Install after MediumGeometry replaces original Frame mesh (does not mutate shared source) and destroys/replaces the four square frame boxes with one exact static non-convex MeshCollider referencing the same skeleton mesh, registered only in BuildStates[0].Colliders. This uses the same collider type as native cabinet housing. No opening trigger or global raycast modification. Model parenting preserves wall/reverse orientation. Finished state geometry/recipes/costs are unchanged.

CabinetPreview, tight CabinetFrameSelection and stage icons use actual Frame mesh. Green material helpers remain byte-identical to accepted published1.0.99. Icons regenerated from actual C# Art/SkeletonSmall.json, SkeletonMedium.json exports and visually inspected.

Native-reference build:0 warnings/errors. 75737 production skeleton checks with Unity/native stubs passed: Small/Medium inner housing corner radii and fixed.5 mm clearance, all vertices clear panel skin, correct width/height/depth, original source mesh preserved, unit normals/outward nondegenerate triangle winding, native frame material group, exact visual/collision mesh reference, old square targets removed, open-centre/no square-corner ray hits, actual ring ray hits, stage0 transitions, same model parent for reverse variants. Runtime native raycast, save/load and MP still require game verification.
