using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Serialization;
using Assets.Scripts;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Inventory;
using Assets.Scripts.Localization2;
using Assets.Scripts.Networking;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Items;
using LibConstruct;
using UnityEngine;
namespace ModularSwitchboards
{
    public sealed class DoorLabelSaveData:StructureSaveData
    {
        [XmlElement] public PlacementBoardStructureSaveData Mount;
    }
    public sealed class DoorLabelBoard:PlacementBoard
    {
        public override float GridSize=>DoorModuleLayout.Pitch;
        public override IPlacementBoardStructure EquivalentStructure(Structure structure)
            =>structure is DoorLabel&&PrimaryHost is SwitchboardCabinet host&&host.IsStructureCompleted?structure as IPlacementBoardStructure:null;
    }
    public class DoorLabel:Structure,IPlacementBoardStructure
    {
        public PlacementBoard Board{get;set;}
        public PlacementBoard.BoardCell[] BoardCells{get;set;}
        internal SwitchboardCabinet Host=>Board?.PrimaryHost as SwitchboardCabinet;
        internal static DinBreaker Target(PlacementBoard board,Grid3 p,bool emergency=false)
        {
            var host=board?.PrimaryHost as SwitchboardCabinet;
            return host?.DoorBoardFor(board)?.Structures.OfType<DinBreaker>().FirstOrDefault(m=>!m.IsBeingDestroyed&&m.IsStructureCompleted&&!m.IsCursor&&(emergency?m.IsDoorStop:m.IsDoorLed||m.IsDoorRoundSwitch)&&Same(host.DoorBoardFor(board).WorldToGrid(m.transform.position),p));
        }
        internal static bool HasTarget(PlacementBoard board,Grid3 p,bool emergency=false,bool display=false)=>display?DoorDisplayLabel.TargetDisplay(board,p)!=null:Target(board,p,emergency)!=null;
        private static bool Same(Grid3 a,Grid3 b)=>a.x==b.x&&a.y==b.y&&a.z==b.z;
        internal static bool CanPlace(PlacementBoard board,Grid3 p,int rotation,bool emergency=false,bool display=false)
            =>board is DoorLabelBoard&&board.PrimaryHost is SwitchboardCabinet host&&host.IsStructureCompleted&&(p.x%10==0&&p.y%10==0&&System.Math.Abs(p.x)<=10&&p.y>=CabinetShape.MinDoorY(host.PrefabName)&&p.y<=10&&p.z==0&&rotation==0)&&HasTarget(board,p,emergency,display)&&DoorDisplayClearance.LabelFits(board,p,emergency,display)&&!board.Structures.OfType<DoorLabel>().Any(l=>Same(board.WorldToGrid(l.transform.position),p));
        internal static bool Attached(DinBreaker owner)
        {
            var host=CabinetWiring.CabinetOf(owner);var board=host?.DoorLabelsFor(owner.Board);
            if(board==null||!(owner.Board is SwitchboardDoorBoard))return false;
            var p=owner.Board.WorldToGrid(owner.transform.position);
            return board.Structures.OfType<DoorLabel>().Any(l=>!l.IsBeingDestroyed&&Same(board.WorldToGrid(l.transform.position),p));
        }
        public override void Awake(){base.Awake();BoardStructureHooks.Awake(this);}
        public override Grid3 GetLocalGrid()=>Board==null?default(Grid3):Board.WorldToGrid(Transform.position);
        public override CanConstructInfo CanConstruct()
        {
            if(!(Board is DoorLabelBoard)||(IsCursor&&PlacementBoard.CursorBoard!=Board))return CanConstructInfo.InvalidPlacement(this is DoorDisplayLabel?"Aim at a Smart Door Display.":this is EmergencyStopLabel?"Aim at a door TOTAL STOP.":"Aim at a door LED or round switch.");
            var p=Board.WorldToGrid(transform.position);
            if(IsCursor)
            {
                if(MountPlacement.TryLockedGrid(this,Board,out var locked))p=locked;
                else
                {
                    var candidates=Enumerable.Range(-1,3).SelectMany(x=>Enumerable.Range(CabinetShape.MinDoorY(Host.PrefabName)/10,2-CabinetShape.MinDoorY(Host.PrefabName)/10).Select(y=>new Grid3(x*10,y*10,0))).Where(g=>HasTarget(Board,g,this is EmergencyStopLabel,this is DoorDisplayLabel));
                    if(!MountSnap.TryNearest(p,candidates,out p))return CanConstructInfo.InvalidPlacement(this is DoorDisplayLabel?"Aim at a Smart Door Display.":this is EmergencyStopLabel?"Aim at an installed door TOTAL STOP.":"Aim at an installed door control.");
                }
                PlacementBoard.CursorGrid=p;PlacementBoard.CursorRotation=0;transform.SetPositionAndRotation(Board.GridToWorld(p),Board.IndexToRotation(0));
            }
            return CanPlace(Board,p,Board.RotationToIndex(transform.rotation),this is EmergencyStopLabel,this is DoorDisplayLabel)?CanConstructInfo.ValidPlacement:CanConstructInfo.InvalidPlacement(this is DoorDisplayLabel?"Choose a completed door display without a display label.":this is EmergencyStopLabel?"Choose a door TOTAL STOP without an emergency label.":"Choose a door LED or round switch without a label.");
        }
        protected override CanConstructInfo CanDeconstruct()=>Host!=null&&Host.IsStructureCompleted?CanConstructInfo.ValidPlacement:CanConstructInfo.InvalidPlacement("Install on a completed cabinet first.");
        public override DelayedActionInstance AttackWith(Attack attack,bool doAction=true)
        {
            if(Host==null||!Host.IsStructureCompleted)return new DelayedActionInstance{Duration=0}.Fail("Install on a completed cabinet first.");
            if(attack.SourceItem is Labeller&&this is EmergencyStopLabel)return null;
            if(attack.SourceItem is Labeller labeller)
            {
                var result=new DelayedActionInstance{Duration=0,ActionMessage=ActionStrings.Rename};
                if(!labeller.OnOff)return result.Fail(GameStrings.DeviceNotOn);
                if(!labeller.IsOperable)return result.Fail(GameStrings.DeviceNoPower);
                if(doAction)labeller.Rename(this);return result;
            }
            return base.AttackWith(attack,doAction);
        }
        public override void OnDeregistered(){base.OnDeregistered();if(Board!=null)BoardStructureHooks.OnDeregistered(this);}
        public override ThingSaveData SerializeSave(){ThingSaveData data=new DoorLabelSaveData();InitialiseSaveData(ref data);return data;}
        protected override void InitialiseSaveData(ref ThingSaveData data){base.InitialiseSaveData(ref data);if(data is DoorLabelSaveData save&&Board!=null)save.Mount=BoardStructureHooks.SerializeSave(this);}
        public override void DeserializeSave(ThingSaveData data){base.DeserializeSave(data);if(data is DoorLabelSaveData save&&save.Mount!=null)BoardStructureHooks.DeserializeSave(this,save.Mount);}
        public override void SerializeOnJoin(RocketBinaryWriter writer){base.SerializeOnJoin(writer);BoardStructureHooks.SerializeOnJoin(writer,this);}
        public override void DeserializeOnJoin(RocketBinaryReader reader){base.DeserializeOnJoin(reader);BoardStructureHooks.DeserializeOnJoin(reader,this);}
        internal static void SetBounds(DoorLabel label){label.ThingTransform=label.transform;label.Bounds=label is DoorDisplayLabel?new Bounds(new Vector3(.05f,.011f,.001f),new Vector3(.184f,.094f,.006f)):label is EmergencyStopLabel?new Bounds(new Vector3(0,0,.001f),new Vector3(.078f,.078f,.006f)):new Bounds(new Vector3(0,.015f,.001f),new Vector3(.044f,.072f,.006f));label.GridBounds=new GridBounds(label);}
    }
}
