"""Replay the preserved checked layout, without rerunning placement search.
First run prepare_smart_pile.py with Blender; then this script with Python.
"""
from pathlib import Path
import json
root=Path(__file__).resolve().parents[1];folder=root/'Art/SmartKit'
source=json.loads((folder/'pile-input.json').read_text());layout=json.loads((folder/'layout.json').read_text());parts={p['name']:p for p in source['parts']};out=[]
for placed in layout['parts']:
 part=parts[placed['name']];m=placed['matrix'];vertices=[[sum(m[i][j]*p[j]for j in range(3))+m[i][3]for i in range(3)]for p in part['mesh']['vertices']]
 out.append({**placed,'mesh':{'vertices':vertices,'triangles':part['mesh']['triangles']}})
(folder/'pile-settled.json').write_text(json.dumps({'kind':'ModuleKit','seed':layout['seed'],'frames':0,'method':'preserved checked layout replay','parts':out}))
print('Replayed',len(out),'Smart pieces from the preserved layout.')
