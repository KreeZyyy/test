# 1.0.81 preview artwork

New artwork generated with image_gen from the user's actual switchboard screenshots and orange LaunchPad banner reference. Original master retained unmodified at /workspace/generated_images/exec-64b8712a-37d2-44cd-bc5b-25351a302b12.png. Native About/Preview.png and thumb.png are the shipped authoritative assets; export_mod_preview.sh produces1600x900 and640x360 palette PNGs from the master. Original legacy render_mod_preview.py remains historical and does not recreate this illustrated design.

The banner indicates the actual BepInEx/StationeersLaunchPad dependency, not a new Workshop publication or official endorsement. Loader URL checked through GitHub. About.Description uses native readable bullets and a TMP orange heading; WORKSHOP-DESCRIPTION.txt is separately prepared Steam BBCode. Do not publish Workshop without explicit user instruction.

## 1.0.82 edit
Edited with image_gen using the1.0.81master asreference. Newunmodifiedmaster: /workspace/generated_images/exec-5ede8009-0121-48b4-8a6a-c69c438011fc.png. Filledtheemptyfuseholder and changedflatbreakers toprojectingtogglehandles; branding/banner/compositionpreserved. Bothmastersretained.

## 1.0.83 edit
image_genusedthe182posterandactual /workspace/work/DinBreaker-1.0.37-preview.png module reference to replaceoversizedbentleverswithcompactgame-stylehingedflaps. Newmasterretained at /workspace/generated_images/exec-8512a179-f586-47d6-b62f-efe3f45444c5.png. Priorartmastersretained.

## 1.0.84 model-mounted state edit
RenderedactualCatalogGeometry/ContactorGeometry/LeverIconGeometrymesheswithactual2.25/1.35/1.15scaleandnativeflappivot(0,0,.0675). BreakerSwitchPoseisON0/OFF180degreesaboutX. Reference /workspace/work/BreakerMount-1.0.84-reference.png, reproducibleTools/render_breaker_mount_reference.py. image_genreferencedthis3Dmodelrenderplus183master tofixcentralspindle/silvercaps/halfheightflaps. FirstgreenONup; fourremainingtopandbothmiddleredOFFdown. Newmasterretained /workspace/generated_images/exec-542bfc3b-dde0-4595-b127-5c3a25465a25.png. Priorartmastersretained.
