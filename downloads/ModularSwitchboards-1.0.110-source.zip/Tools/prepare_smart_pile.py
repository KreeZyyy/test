"""Reuse the module crate shell with the three existing Smart model designs.
Run with Blender; decorative pieces use the same atlas swatches and checked
surface-settling pipeline as ordinary modules. No new module variants.
"""
import bpy,json,math
from pathlib import Path
from mathutils import Vector
root=Path(__file__).resolve().parents[1];folder=root/'Art/SmartKit';folder.mkdir(exist_ok=True);(root/'Assets/SmartKit').mkdir(exist_ok=True)
shell=json.loads((root/'Art/ModuleKit/source.json').read_text())['shell'];smartPieces=[]
def clear():
 bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
def mat(name,color):
 m=bpy.data.materials.new(name);m.diffuse_color=(*color,1);return m
def mesh(name,vertices,groups,materials):
 faces=[];roles=[]
 for role,ids in groups.items():
  for i in range(0,len(ids),3):faces.append(ids[i:i+3]);roles.append(int(role))
 m=bpy.data.meshes.new(name);m.from_pydata(vertices,[],faces);m.update();ob=bpy.data.objects.new(name,m);bpy.context.collection.objects.link(ob)
 for material in materials:m.materials.append(material)
 for poly,role in zip(m.polygons,roles):poly.material_index=min(role,len(materials)-1)
def capture(name,mirrored=None):
 v=[];ts={}
 for ob in list(bpy.context.scene.objects):
  if ob.type not in ('MESH','CURVE','FONT') or ob.name=='Pane':continue
  # Match the low-poly decorative treatment used in the ordinary/door crates.
  for modifier in list(ob.modifiers):ob.modifiers.remove(modifier)
  deps=bpy.context.evaluated_depsgraph_get();evaluated=ob.evaluated_get(deps);m=evaluated.to_mesh();m.calc_loop_triangles();offset=len(v)
  for p in m.vertices:
   q=ob.matrix_world@p.co;v.append([-q.x*1.4,-q.y*1.4,q.z*1.4])
  for t in m.loop_triangles:
   color=m.materials[min(t.material_index,len(m.materials)-1)].diffuse_color[:3] if m.materials else (.5,.5,.5);r,g,b=color
   role=0 if max(color)<.16 else 10 if g>r*1.5 and g>b*1.5 else 13 if r>g*2 and r>b*2 else 6 if r>.25 and g>.18 and b<.1 else 1 if min(color)>.7 else 4
   ids=list(t.vertices)
   # Unity-to-Blender imports reflect X; undo their triangle winding only.
   # Authored Blender objects (Net, Output lettering/LEDs) are already outward.
   if mirrored is True or isinstance(mirrored,set) and ob.name in mirrored:ids.reverse()
   points=[v[offset+j]for j in ids];a,b,c=map(Vector,points)
   if (b-a).cross(c-a).length_squared>1e-20:ts.setdefault(str(role),[]).extend(offset+j for j in ids)
  evaluated.to_mesh_clear()
 low=[min(p[k]for p in v)for k in range(3)];hi=[max(p[k]for p in v)for k in range(3)];center=[(a+b)*.5 for a,b in zip(low,hi)]
 vertices=[[p[k]-center[k]for k in range(3)]for p in v]
 return {'vertices':vertices,'triangles':ts}
clear()
palette=[mat('Status',(.1,.4,.1)),mat('Body',(.8,.8,.8)),mat('Grey',(.1,.1,.1)),mat('Fascia',(.06,.06,.06)),mat('Contacts',(.48,.5,.46))]
d=json.loads((root/'Art/SmartGeometry.json').read_text())['smartBody'];mesh('Core body',[[-p[0]*2.25,-p[2]*1.15,p[1]*1.35]for p in d['vertices']],d['triangles'],palette)
for part in json.loads((root/'Art/CoreLED-reference.json').read_text()):
 vertices=[[-p[0],-p[2],p[1]]for p in part['vertices']];groups={str(i):t for i,t in enumerate(part['triangles'])};mesh(part['name'],vertices,groups,[palette[3] if part['name']in ('screen','socket')else palette[1]]*max(1,len(groups)))
core=capture('Core',True)
script=(root/'Tools/render_net_icon.py').read_text();exec(compile(script[:script.index('scene=bpy.context.scene;')],str(root/'Tools/render_net_icon.py'),'exec'));net=capture('Net')
script=(root/'Tools/render_smart_contactor_icon.py').read_text();exec(compile(script[:script.index('scene=bpy.context.scene;')],str(root/'Tools/render_smart_contactor_icon.py'),'exec'));output=capture('Output',{'body','screw'}|{p['name']for p in parts['nativePanel']})
# Several copies of the existing three designs; mixed loose fill, not a new kit recipe.
for kind,design,count in [('Core',core,2),('Net',net,4),('Output',output,4)]:
 for index in range(count):smartPieces.append({'name':kind+str(index),'mesh':design,'metadata':{'smartVariant':kind}})
(folder/'source.json').write_text(json.dumps({'shell':shell,'contents':{'vertices':[],'triangles':{}}}))
(folder/'pile-input.json').write_text(json.dumps({'kind':'ModuleKit','seed':165,'max_height':.36,'wall_inset':.008,'parts':smartPieces}))
print('Prepared Smart crate: same shell;',len(smartPieces),'pieces from Core, Net and Output.',flush=True)
