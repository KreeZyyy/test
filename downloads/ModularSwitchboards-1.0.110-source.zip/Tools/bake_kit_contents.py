"""Merge checked settled parts into the original crate and write the runtime mesh."""
from pathlib import Path
import json,sys,subprocess
root=Path(__file__).resolve().parents[1];kind=sys.argv[1];assert kind in ('ModuleKit','RailKit','LabelKit','DoorKit','SmartKit')
folder=root/'Art'/kind;settled=json.loads((folder/'pile-settled.json').read_text());audit=json.loads((folder/'support-audit.json').read_text())
assert audit['grounded_count']==len(settled['parts'])and not audit['ungrounded']
contents={'vertices':[],'triangles':{}}
for part in settled['parts']:
 d=part['mesh'];offset=len(contents['vertices']);contents['vertices'].extend(d['vertices'])
 for role,indices in d['triangles'].items():contents['triangles'].setdefault(role,[]).extend(offset+j for j in indices)
source=json.loads((folder/'source.json').read_text());source['contents']=contents;source['layout']=[{'name':p['name'],'matrix':p['matrix'],'metadata':p['metadata']}for p in settled['parts']];source['layoutPolicy']='Gravity-directed vertical settling on actual visible triangles; no geometry intersections, grounded contact chains validated within 5mm.'
source['supportAudit']=audit;source.pop('design',None);(folder/'source.json').write_text(json.dumps(source))
subprocess.run([sys.executable,str(root/'Tools/create_module_kit.py'),kind],check=True)
