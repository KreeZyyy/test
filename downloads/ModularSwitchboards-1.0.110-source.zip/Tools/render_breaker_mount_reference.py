import bpy,json,math
from pathlib import Path
from mathutils import Vector
root=Path(__file__).resolve().parents[1]
geo=json.loads((root/'Art/CatalogGeometry.json').read_text());updated=json.loads((root/'Art/ContactorGeometry.json').read_text());lever=json.loads((root/'Art/LeverIconGeometry.json').read_text())
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
def material(name,rgb):
 m=bpy.data.materials.new(name);m.diffuse_color=(*rgb,1);m.use_nodes=True;m.node_tree.nodes['Principled BSDF'].inputs['Base Color'].default_value=(*rgb,1);m.node_tree.nodes['Principled BSDF'].inputs['Roughness'].default_value=.65;return m
white=material('White',(.78,.81,.8));black=material('Black',(.018,.024,.025));silver=material('Native spindle supports',(.42,.45,.45));back=material('Background',(.055,.075,.09))
def part(name,data,x,colour,on=False):
 pts=[]
 for p in data['vertices']:
  a,b,c=p
  if name=='lever':
   # Exact BreakerSwitchPose.LeverAngle: ON=0, OFF=180 around native X spindle.
   if not on:b,c=-b,-c
   c+=.0675
  pts.append((-a*2.25+x,-c*1.15,b*1.35))
 faces=[];roles=[]
 for role,tri in data['triangles'].items():
  for i in range(0,len(tri),3):faces.append(tuple(reversed(tri[i:i+3])));roles.append(int(role))
 me=bpy.data.meshes.new(name);me.from_pydata(pts,[],faces);me.update();ob=bpy.data.objects.new(name,me);bpy.context.collection.objects.link(ob)
 for m in [colour,white,black,silver]:me.materials.append(m)
 for f,role in zip(me.polygons,roles):f.material_index=0 if name=='lever' else 3 if name.startswith('bearing') else {0:0,1:1,2:2,3:2,4:3}.get(role,2)
def text(body,x,z,size):
 bpy.ops.object.text_add(location=(x,-.085,z),rotation=(math.pi/2,0,0));t=bpy.context.object;t.data.body=body;t.data.align_x='CENTER';t.data.size=size;t.data.materials.append(white)
for x,on,rgb in [(-.065,True,(.06,.34,.10)),(0,False,(.85,.69,.015)),(.065,False,(.52,.055,.055))]:
 col=material('Rating'+str(x),rgb)
 for key in ['breakerBody','bearingLeft','bearingRight']:part(key,updated[key],x,col)
 part('lever',lever,x,col,on)
 # Fitted native central pivot is the same in both states; flap changes side.
 text('ON' if on else 'OFF',x,.013 if on else -.019,.006)
 text('ON - UP' if on else 'OFF - DOWN',x,-.071,.006)
scene=bpy.context.scene;scene.world.color=(.18,.18,.18);scene.render.engine='CYCLES';scene.cycles.samples=32;scene.cycles.use_denoising=False
bpy.ops.mesh.primitive_plane_add(size=2,location=(0,.025,0),rotation=(math.pi/2,0,0));bpy.context.object.data.materials.append(back)
bpy.ops.object.light_add(type='AREA',location=(.10,-.30,.28));bpy.context.object.data.energy=7;bpy.context.object.data.size=.3
bpy.ops.object.camera_add(location=(.10,-.55,.12));cam=bpy.context.object;target=Vector((0,-.02,-.005));cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=.24;scene.camera=cam
scene.render.resolution_x=1600;scene.render.resolution_y=1000;scene.render.resolution_percentage=100;scene.render.image_settings.file_format='PNG';scene.render.filepath=str(root.parent/'BreakerMount-1.0.84-reference.png');bpy.ops.render.render(write_still=True)
