"""Rebuild a deterministic supported kit pile. Requires Blender and Pillow."""
from pathlib import Path
import subprocess,sys
root=Path(__file__).resolve().parents[1];kind=sys.argv[1];assert kind in ('ModuleKit','RailKit','SmartKit');label={'ModuleKit':'module','RailKit':'rail','SmartKit':'smart'}[kind];folder=root/'Art'/kind
def blender(script,*args):subprocess.run(['blender','-b','-t','2','--python-exit-code','1','--python',str(root/'Tools'/script),'--',*map(str,args)],check=True)
if kind=='SmartKit':blender('prepare_smart_pile.py')
else:subprocess.run([sys.executable,str(root/f'Tools/prepare_{label}_pile.py')],check=True)
blender('settle_kit.py',folder/'pile-input.json',folder/'pile-settled.json')
blender('check_settled_support.py',folder/'pile-settled.json',folder/'support-audit.json')
subprocess.run([sys.executable,str(root/'Tools/bake_kit_contents.py'),kind],check=True)
blender(f'render_{label}_kit.py')
