#!/usr/bin/env bash
set -euo pipefail
# Export the generated master artwork to the two native mod-list assets.
# Supply the original master PNG as the first argument; keep it unmodified.
root="$(cd "$(dirname "$0")/.." && pwd)"
master="${1:?Usage: export_mod_preview.sh path/to/master.png}"
convert "$master" -resize '1600x900!' -strip -depth 8 -colors 256 -define png:compression-level=9 "PNG8:$root/ModularSwitchboards/About/Preview.png"
convert "$master" -resize '640x360!' -strip -depth 8 -colors 256 -define png:compression-level=9 "PNG8:$root/ModularSwitchboards/About/thumb.png"
