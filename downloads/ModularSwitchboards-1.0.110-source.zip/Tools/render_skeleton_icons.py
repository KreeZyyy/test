"""Render actual C# production skeleton exports from Verification/CabinetSkeleton."""
import bpy,json,os
from pathlib import Path
from mathutils import Vector
root=Path(__file__).resolve().parents[1]
for icon,source,zoom in [('Frame','SkeletonSmall',.69),('MediumFrame','SkeletonMedium',1.38)]:
 bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
 data=json.loads((root/'Art'/f'{source}.json').read_text())
 pts=[(-p[0],-p[2],p[1])for p in data['vertices']]
 faces=[];roles=[]
 for role,indices in data['triangles'].items():
  faces.extend(tuple(reversed(indices[i:i+3]))for i in range(0,len(indices),3));roles.extend([int(role)]*(len(indices)//3))
 mesh=bpy.data.meshes.new(source);mesh.from_pydata(pts,[],faces);mesh.update();ob=bpy.data.objects.new(source,mesh);bpy.context.collection.objects.link(ob)
 mat=bpy.data.materials.new('NativeFrameGrey');mat.use_nodes=True;node=mat.node_tree.nodes.get('Principled BSDF');node.inputs['Base Color'].default_value=(.43,.48,.49,1);node.inputs['Roughness'].default_value=.65;node.inputs['Metallic'].default_value=.45;mesh.materials.append(mat)
 grey=bpy.data.materials.new('NativeGreyRear');grey.use_nodes=True;node=grey.node_tree.nodes.get('Principled BSDF');node.inputs['Base Color'].default_value=(.16,.18,.17,1);node.inputs['Roughness'].default_value=.72;mesh.materials.append(grey)
 for poly,role in zip(mesh.polygons,roles):poly.material_index=1 if role==1 else 0
 scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=24;scene.cycles.use_denoising=False
 scene.render.resolution_x=384;scene.render.resolution_y=384;scene.render.resolution_percentage=100;scene.render.film_transparent=True;scene.world.color=(.35,.35,.35)
 for loc,power,size in [((-2,-3,4),400,3),((3,-1,2),200,3),((0,3,3),250,2)]:
  bpy.ops.object.light_add(type='AREA',location=loc);light=bpy.context.object;light.data.energy=power;light.data.shape='DISK';light.data.size=size;light.rotation_euler=(-light.location).to_track_quat('-Z','Y').to_euler()
 bpy.ops.object.camera_add(location=(-1.3,-2.5,1.2));cam=bpy.context.object;cam.rotation_euler=(Vector((0,-.09,0))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=zoom;scene.camera=cam
 scene.view_settings.view_transform='Standard';scene.render.image_settings.file_format='PNG';scene.render.image_settings.color_mode='RGBA'
 out=root/'Assets/Icons'/f'{icon}.png';temporary=out.with_name(icon+'.new.png');scene.render.filepath=str(temporary);bpy.ops.render.render(write_still=True);os.replace(temporary,out)
