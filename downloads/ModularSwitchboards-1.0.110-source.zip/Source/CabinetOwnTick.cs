using System;
using System.Collections.Generic;
using System.Linq;
namespace ModularSwitchboards
{
    // One pair of callbacks around the native electricity cycle, not render frames
    // or repeated GetUsedPower/GetGeneratedPower queries. Weak references do not
    // retain unloaded cabinets; Stop removes destroyed ones immediately.
    internal static class CabinetOwnTick
    {
        private static readonly object Gate=new object();
        private static readonly List<WeakReference<CabinetBatteryPower>> Live=new List<WeakReference<CabinetBatteryPower>>();
        internal static void Register(CabinetBatteryPower power){lock(Gate)Live.Add(new WeakReference<CabinetBatteryPower>(power));}
        internal static void Remove(CabinetBatteryPower power){lock(Gate)Live.RemoveAll(w=>!w.TryGetTarget(out var target)||ReferenceEquals(target,power));}
        private static CabinetBatteryPower[] Snapshot(){lock(Gate){Live.RemoveAll(w=>!w.TryGetTarget(out var target));return Live.Select(w=>{w.TryGetTarget(out var target);return target;}).Where(p=>p!=null).ToArray();}}
        internal static Action<Exception> Report;
        private static void Run(bool begin)
        {
            foreach(var power in Snapshot())
                try{if(begin)power.BeginOwnTick();else power.EndOwnTick();}
                catch(Exception ex){power.StopOwnPower();Report?.Invoke(ex);}
        }
        internal static void Begin(){Run(true);CabinetCombinerTick.Begin();}
        internal static void End(){Run(false);CabinetCombinerTick.End();}
    }
}
