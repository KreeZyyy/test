using System.Linq;
using System.Collections.Generic;
using Assets.Scripts.Objects;
using UnityEngine;
namespace ModularSwitchboards
{
    // Passive body picking follows actual model triangles. Dedicated controls,
    // slots and mounting-board surfaces retain their own colliders/actions.
    public sealed class FittedModelCollider:MonoBehaviour
    {
        [SerializeField] private MeshCollider hit;
        private Mesh owned;
        internal static void Install(Structure owner,Mesh mesh)
        {
            if(!OwnPreviewPolicy.FittedBody(owner)||owner.IsCursor)return;
            var component=owner.GetComponent<FittedModelCollider>()??owner.gameObject.AddComponent<FittedModelCollider>();
            component.Set(owner,mesh,false);
        }
        internal static void AfterCacheBounds(Structure __instance)
        {
            if(!OwnPreviewPolicy.FittedBody(__instance))return;
            var fitted=__instance.GetComponent<FittedModelCollider>();var mesh=fitted?.hit==null?null:fitted.hit.sharedMesh;
            if(mesh==null)return;
            __instance.Bounds=mesh.bounds;__instance.GridBounds=new GridBounds(__instance);
        }
        internal static void Rebuild(Structure owner)
        {
            if(owner.IsCursor||!OwnPreviewPolicy.FittedBody(owner))return;
            var component=owner.GetComponent<FittedModelCollider>();if(component==null)return;
            component.Set(owner,ModelBlueprint.Build(owner.transform,owner,includeDisabled:true),true);
        }
        private void Set(Structure owner,Mesh mesh,bool own)
        {
            if(hit==null)
            {
                var child=new GameObject("FittedModelHitbox"){layer=owner.gameObject.layer};child.transform.SetParent(owner.transform,false);
                hit=child.AddComponent<MeshCollider>();
                foreach(var box in owner.GetComponentsInChildren<BoxCollider>(true).Where(box=>
                    (box.transform.name=="DinBreakerModel"||box.transform.name=="DinRailModel"||owner is DinBreaker door&&door.IsDoorPart&&box.transform==owner.transform)&&
                    !owner.Interactables.Any(control=>control.Collider==box)).ToArray())
                {
                    foreach(var state in owner.BuildStates)state.Colliders.Remove(box);
                    Thing._colliderLookup.Remove(box);Object.DestroyImmediate(box);
                }
                owner.BuildStates[0].Colliders.Add(hit);
            }
            hit.sharedMesh=mesh;Thing._colliderLookup[hit]=owner;
            var previous=owned;owned=own?mesh:null;if(previous!=null&&previous!=mesh)Object.Destroy(previous);
            owner.Bounds=mesh.bounds;owner.GridBounds=new GridBounds(owner);
        }
        private void OnDestroy(){if(owned!=null)Object.Destroy(owned);}
    }
}
