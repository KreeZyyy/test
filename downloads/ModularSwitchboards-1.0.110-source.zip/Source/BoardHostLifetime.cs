using Assets.Scripts;
using Assets.Scripts.GridSystem;
using LibConstruct;
namespace ModularSwitchboards
{
    internal static class BoardHostLifetime
    {
        internal static void Release<T>(IPlacementBoardHost host,ref BoardRef<T> reference) where T:PlacementBoard,new()
        {
            if(reference==null)return;
            // During world teardown Unity may have destroyed child transforms.
            // RemoveHost is gameplay logic: it reparents or returns orphans as
            // kits. Neither operation belongs to scene teardown or prefab cleanup.
            if(GameManager.GameState==GameState.Running)BoardHostHooks.OnDestroyedBoard(host,reference);
            else reference.Board=null;
            reference=null;
        }
    }
}
