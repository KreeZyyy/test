using System;
using System.Collections.Generic;
namespace ModularSwitchboards
{
    internal static class WireRouteUpgrade
    {
        // Revision 9 only moved Medium transformer contacts. Revision 8 already
        // satisfies the same routing geometry; unchanged endpoints need no A*.
        internal static bool TryPromote(IList<CabinetWireSaveData> wires,Func<CabinetWireEnd,WirePoint?> position,int revision)
        {
            if(wires.Count==0||revision!=9)return false;
            bool old=false;
            foreach(var w in wires)
            {
                old|=w.RouteVersion==8;
                if(w.RouteVersion<8||w.RouteVersion>revision||w.Points==null||w.Points.Length<6)return false;
                var a=position(w.From);var b=position(w.To);if(!a.HasValue||!b.HasValue)return false;
                int n=w.Points.Length;
                if((a.Value-new WirePoint(w.Points[0],w.Points[1],w.Points[2])).Squared>.000001f||(b.Value-new WirePoint(w.Points[n-3],w.Points[n-2],w.Points[n-1])).Squared>.000001f)return false;
            }
            if(!old)return false;
            foreach(var w in wires)w.RouteVersion=revision;
            return true;
        }
    }
}
