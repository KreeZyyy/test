using Assets.Scripts.Objects;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class CabinetFrameSelection
    {
        internal static void AfterSelection(Thing __instance,ref SelectionInstance __result)
        {
            if(!(__instance is SwitchboardCabinet cabinet)||cabinet.IsCursor||cabinet.CurrentBuildStateIndex!=0)return;
            var frame=cabinet.transform.Find("SwitchboardModel/Frame")?.GetComponent<MeshFilter>();
            if(frame?.sharedMesh==null)return;
            // Change only the displayed selection, not the cabinet's full bounds
            // used for mounting, grid occupancy and future housing construction.
            // Recompute from the current transform so wall-fit movement is respected.
            var local=cabinet.transform.worldToLocalMatrix*frame.transform.localToWorldMatrix;
            __result.Bounds=CabinetWallMount.TransformedBounds(frame.sharedMesh.bounds,local);
        }
    }
}
