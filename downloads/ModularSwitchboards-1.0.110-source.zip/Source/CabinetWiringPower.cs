using System.Collections.Generic;
using System.Linq;
using Assets.Scripts.Networks;
using Assets.Scripts.Objects.Pipes;
namespace ModularSwitchboards
{
    internal sealed class CabinetWiringPower
    {
        private readonly CabinetCombinerPower power=new CabinetCombinerPower();
        internal bool TransformerPowered(long id)=>power.TransformerPowered(id);
        internal void RemoveOwnTransformer(long id)=>power.RemoveOwnTransformer(id);
        internal void StopOwnPower()=>power.StopOwnPower();
        internal void ObserveIdle(CableNetwork network)=>power.ObserveIdle(network);
        internal long[] DrainTrips()=>power.DrainTrips();
        internal void Refresh(SwitchboardCabinet owner,IList<CabinetWireSaveData> wires,IEnumerable<DinBreaker> breakers)=>RefreshNodes(owner,wires,breakers.Select(CabinetPowerNode.From));
        internal void RefreshNodes(SwitchboardCabinet owner,IList<CabinetWireSaveData> wires,IEnumerable<CabinetPowerNode> breakers)
        {
            var all=breakers.ToArray();
            power.RefreshNodes(owner,DoorModuleLayout.Through(wires,all.Where(m=>m.IsDoorBridge&&!m.IsBeingDestroyed).Select(m=>m.ReferenceId)).ToArray(),all);
        }
        internal float Generated(CableNetwork network)=>power.Generated(network);
        internal float Used(CableNetwork network)=>power.Used(network);
        internal void Use(CableNetwork network,float amount)=>power.Use(network,amount);
        internal void Receive(CableNetwork network,float amount)=>power.Receive(network,amount);
        internal bool AllowsPower(CableNetwork network)=>power.AllowsPower(network);
        internal bool IsProviderTo(Device self,Device other,ref List<long> visited)=>power.IsProviderTo(self,other,ref visited);
    }
}
