using System;
using System.Runtime.CompilerServices;
using System.Text;
using System.Collections.Generic;
using Assets.Scripts;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Items;
using Assets.Scripts.Objects.Pipes;
using Assets.Scripts.Objects.Motherboards;
namespace ModularSwitchboards
{
    // Passive switchboard parts deliberately remain Structures. The configuration
    // cartridge normally only accepts Device, so adapt this readout at the UI edge
    // without registering another powered device or a synthetic cable network.
    internal static class SwitchboardTablet
    {
        private sealed class Selection{internal long Id;}
        private static readonly ConditionalWeakTable<ConfigCartridge,Selection> Selections=new ConditionalWeakTable<ConfigCartridge,Selection>();
        internal static bool BeforeRead(ConfigCartridge __instance,ref string ____selectedText,ref string ____outputText,ref bool ____needTopScroll,
            ref Device ____scannedDevice,ref Device ____lastScannedDevice)
        {
            var selection=Selections.GetValue(__instance,_=>new Selection());
            if(!__instance.RootParent||!__instance.RootParent.HasAuthority||!(CursorManager.CursorThing is Thing module)||!Supported(module)||module.IsCursor||module.IsBeingDestroyed)
            {selection.Id=0;return true;}
            var text=Text(module);
            var sync=____outputText??string.Empty;
            lock(sync)
            {
                if(selection.Id!=module.ReferenceId)____needTopScroll=true;
                selection.Id=module.ReferenceId;
                ____scannedDevice=null;____lastScannedDevice=null;
                ____selectedText=module.DisplayName.ToUpper();____outputText=text;
            }
            return false;
        }
        internal static bool Supported(Thing thing)=>!(thing is Device)&&(thing is DinBreaker||thing is SwitchboardCabinet||thing is DinRail||thing is InnerCoverModule||thing is SwitchboardLabel||thing is DoorLabel||SwitchboardKitModel.IsKit(thing));
        internal static string Text(Thing thing)
        {
            var values=new Dictionary<LogicType,double>{[LogicType.PrefabHash]=thing.PrefabHash,[LogicType.ReferenceId]=thing.ReferenceId,[LogicType.NameHash]=thing.GetNameHash()};
            if(thing is SwitchboardCabinet cabinet)values[LogicType.Open]=cabinet.IsOpen?1:0;
            if(thing is DinBreaker module)
            {
                var wiring=CabinetWiring.CabinetOf(module)?.Wiring;
                if(module.IsAnalyserModule)
                {
                    var network=wiring?.AnalysedNetwork(module,out _,out _);
                    values[LogicType.PowerActual]=network?.CurrentLoad??0;
                    values[LogicType.PowerPotential]=network?.PotentialLoad??0;
                    values[LogicType.PowerRequired]=network?.RequiredLoad??0;
                }
                else if(module.IsSmartOutputModule)
                {
                    var core=SmartBus.Core(module);values[LogicType.Power]=core!=null&&core.Powered&&core.OnOff?1:0;
                }
                else
                {
                    values[LogicType.Power]=module.IsDoorLed?(module.DoorLit?1:0):module.IsContactor?(module.ContactorClosed?1:0):
                        (wiring?.TerminalLive(module.ReferenceId,0)==true||module.IsDoorBridge&&wiring?.TerminalLive(module.ReferenceId,2)==true?1:0);
                    if(module.IsBatteryModule)
                    {
                        var cell=module.Battery;values[LogicType.Charge]=cell?.PowerStored??0;
                        values[LogicType.Ratio]=cell?.PowerRatio??0;values[LogicType.Maximum]=cell?.PowerMaximum??0;
                    }
                    else if(module.IsContactor)values[LogicType.On]=module.ContactorClosed?1:0;
                    else if(!module.IsDoorLed&&!module.IsDoorBridge)
                    {
                        values[LogicType.On]=module.IsFuseHolder?(module.Conducting?1:0):(module.OnOff?1:0);
                        if(!module.IsDoorPart){values[LogicType.Error]=module.Tripped?1:0;values[LogicType.Maximum]=module.RatedWatts;}
                    }
                }
            }
            var text=new StringBuilder();
            text.Append("ReferenceId ... ");text.AppendFormat("<color=#20B2AA>${0}</color>",thing.ReferenceId.ToString("X"));
            // Follow the native enumeration order, including the numeric ID row.
            for(int i=0;i<EnumCollections.LogicTypes.Length;i++)
            {var type=EnumCollections.LogicTypes.Values[i];if(values.TryGetValue(type,out var value))Append(text,type,value);}
            return text.ToString();
        }
        private static void Append(StringBuilder text,LogicType type,double value)
        {
            text.Append('\n');text.Append(type);text.Append(" ... <color=green>");
            text.Append(Math.Round(value,3,MidpointRounding.AwayFromZero));text.Append("</color>");
        }
    }
}
