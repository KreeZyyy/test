using System.Collections.Generic;
using Assets.Scripts.Objects;
namespace ModularSwitchboards
{
    internal static class CabinetPorts
    {
        private static readonly int[] SingleInputs={0},SmallInputs={0,4},MediumInputs={0,4,6};
        internal static bool Combiner(string name)=>name==SwitchboardsMod.SmallCombinerName||name==SwitchboardsMod.SmallCombinerReverseName||name==SwitchboardsMod.MediumCombinerName||name==SwitchboardsMod.MediumCombinerReverseName;
        internal static int OutputCount(string name)=>Combiner(name)?1:CabinetShape.OutputCount(name);
        internal static int InputCount(string name)=>Combiner(name)?CabinetShape.OutputCount(name):1;
        internal static IEnumerable<int> InputContacts(string name)=>Combiner(name)?(CabinetShape.Medium(name)?MediumInputs:SmallInputs):SingleInputs;
        internal static ConnectionRole SingleRole(string name)=>Combiner(name)?ConnectionRole.Output:ConnectionRole.Input;
        internal static ConnectionRole BranchRole(string name,int index)=>Combiner(name)&&index==0?ConnectionRole.Input:CabinetShape.OutputRole(index);
        internal static ConnectionRole InputRole(int contact)=>contact==4?ConnectionRole.Output2:contact==6?ConnectionRole.Waste:ConnectionRole.Input;
        internal static bool IsInputRole(string name,ConnectionRole role)=>role==ConnectionRole.Input||Combiner(name)&&(role==ConnectionRole.Output2||role==ConnectionRole.Waste);
        internal static int SlotContact(string name,int slot)=>!Combiner(name)?slot:slot==0?1:slot==1?0:slot==2?4:6;
        internal static int ContactSlot(string name,int contact)=>!Combiner(name)?contact:contact==1?0:contact==0?1:contact==4?2:3;
        internal static string SlotLabel(string name,int slot)=>!Combiner(name)?(slot==0?"Input":"Output "+slot):slot==0?"Output":"Input "+slot;
        internal static string RoleLabel(string name,ConnectionRole role)=>!Combiner(name)?role.ToString():role==ConnectionRole.Output?"Output":role==ConnectionRole.Input?"Input 1":role==ConnectionRole.Output2?"Input 2":"Input 3";
        internal static string Title(string name)=>"Switchboard "+(CabinetShape.Medium(name)?"Medium":"Small")+" ("+InputCount(name)+" IN / 1 OUT"+(CabinetLayout.Reversed(name)?", Reverse":"")+")";
    }
}
