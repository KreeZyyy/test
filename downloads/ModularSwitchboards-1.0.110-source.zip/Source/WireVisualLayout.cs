using System;
using System.Collections.Generic;
namespace ModularSwitchboards
{
    internal struct WireMetalBand
    {
        internal float Start,End;internal WireMetalBand(float start,float end){Start=start;End=end;}
    }
    internal sealed class WireVisualLayout
    {
        internal WirePoint[] Points;internal float[] Distances;internal WireMetalBand[] Metal;
        internal bool MetalAt(float d){foreach(var band in Metal)if(d>=band.Start&&d<band.End)return true;return false;}
        internal float JointGap(float d)
        {
            float result=float.MaxValue;
            foreach(var band in Metal){float gap=d<band.Start?band.Start-d:d>band.End?d-band.End:-Math.Min(d-band.Start,band.End-d);result=Math.Min(result,gap);}return result;
        }
    }
    internal static class WireJointPlacement
    {
        internal const float BendClearance=.006f;
        internal static List<WireMetalBand> StraightRuns(WirePoint[] path,float[] distances)
        {
            var runs=new List<WireMetalBand>();int first=0;
            for(int i=1;i<path.Length-1;i++)
            {
                var a=path[i]-path[i-1];var b=path[i+1]-path[i];float dot=WirePoint.Dot(a,b)/(float)Math.Sqrt(a.Squared*b.Squared);
                if(dot<.99999f){runs.Add(new WireMetalBand(distances[first],distances[i]));first=i;}
            }
            runs.Add(new WireMetalBand(distances[first],distances[distances.Length-1]));return runs;
        }
        internal static WireMetalBand[] Place(WirePoint[] path,float[] distances,float collar,float pitch)
        {
            if(collar<=0)return new WireMetalBand[0];var runs=StraightRuns(path,distances);var bands=new List<WireMetalBand>();float length=distances[distances.Length-1];
            // End cuffs are omitted if a bend starts too close to the terminal.
            if(runs[0].End>=collar+.002f)bands.Add(new WireMetalBand(0,collar));
            if(length-runs[runs.Count-1].Start>=collar+.002f)bands.Add(new WireMetalBand(length-collar,length));
            for(int joint=1;joint*pitch<length-collar;joint++)
            {
                float nominal=joint*pitch,best=0,error=float.MaxValue;
                foreach(var run in runs)
                {
                    float start=run.Start+BendClearance+collar*.5f,end=run.End-BendClearance-collar*.5f;if(start>end)continue;
                    float candidate=Math.Max(start,Math.Min(end,nominal));bool close=false;foreach(var old in bands)if(Math.Abs(candidate-(old.Start+old.End)*.5f)<.02f){close=true;break;}
                    if(close)continue;float e=Math.Abs(candidate-nominal);if(e<error){error=e;best=candidate;}
                }
                if(error<=pitch*.4f)bands.Add(new WireMetalBand(best-collar*.5f,best+collar*.5f));
            }
            bands.Sort((a,b)=>a.Start.CompareTo(b.Start));return bands.ToArray();
        }
    }
}
