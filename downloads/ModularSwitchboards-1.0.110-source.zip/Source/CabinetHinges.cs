using System.Collections.Generic;
using System.Linq;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class CabinetHinges
    {
        // Small exported hinges are 10 x 24 x 16 mm. Medium stretches the
        // housing 2x in XY: retain the same hardware size and mirror it to the other leaf.
        internal static Vector3 MediumPoint(Vector3 p)
        {
            float y=p.y<0?-.34f:.34f;
            return new Vector3(-.403f+(p.x+.406f)*.5f,y+(p.y-y)*.5f,p.z);
        }
        internal static void ApplyMedium(Mesh mesh)
        {
            var vertices=mesh.vertices.ToList();var normals=mesh.normals.ToList();var uv=mesh.uv.ToList();
            var triangles=mesh.GetTriangles(4);var mapped=new Dictionary<int,int>();
            foreach(int index in triangles.Distinct())
            {
                var p=MediumPoint(vertices[index]);vertices[index]=p;
                mapped[index]=vertices.Count;vertices.Add(new Vector3(-p.x,p.y,p.z));
                var n=normals[index];n=new Vector3(n.x*2,n.y*2,n.z).normalized;normals[index]=n;normals.Add(new Vector3(-n.x,n.y,n.z));uv.Add(uv[index]);
            }
            var both=triangles.ToList();for(int i=0;i<triangles.Length;i+=3){both.Add(mapped[triangles[i]]);both.Add(mapped[triangles[i+2]]);both.Add(mapped[triangles[i+1]]);}
            mesh.vertices=vertices.ToArray();mesh.normals=normals.ToArray();mesh.uv=uv.ToArray();mesh.SetTriangles(both.ToArray(),4);
            mesh.RecalculateBounds();mesh.RecalculateTangents();
        }
    }
}
