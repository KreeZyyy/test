using System;
using System.Collections.Generic;
using UnityEngine;
namespace ModularSwitchboards
{
    internal readonly struct CoverIconRect
    {
        internal readonly float Left,Right,Bottom,Top;
        internal CoverIconRect(float left,float right,float bottom,float top){Left=left;Right=right;Bottom=bottom;Top=top;}
        internal bool Contains(float x,float y)=>x>=Left&&x<=Right&&y>=Bottom&&y<=Top;
    }
    internal static class CoverIconRaster
    {
        internal static Color32[] Build(float width,float height,IList<CoverIconRect> holes,IList<CoverIconRect> labels,Color32 tint,int size)
        {
            var pixels=new Color32[size*size];float scale=(size-12f)/Math.Max(width,height);
            for(int py=0;py<size;py++)for(int px=0;px<size;px++)
            {
                float x=(size*.5f-px-.5f)/scale,y=(py+.5f-size*.5f)/scale;
                if(Math.Abs(x)>width*.5f||Math.Abs(y)>height*.5f)continue;
                bool hole=false;foreach(var h in holes)if(h.Contains(x,y)){hole=true;break;}
                if(!hole)
                {
                    float shade=.82f+.16f*py/(size-1);
                    if(width*.5f-Math.Abs(x)<1/scale||height*.5f-Math.Abs(y)<1/scale)shade*=.65f;
                    pixels[py*size+px]=new Color32((byte)(tint.r*shade),(byte)(tint.g*shade),(byte)(tint.b*shade),255);
                }
                foreach(var label in labels)if(label.Contains(x,y)){pixels[py*size+px]=new Color32(230,232,226,255);break;}
            }
            return pixels;
        }
    }
}
