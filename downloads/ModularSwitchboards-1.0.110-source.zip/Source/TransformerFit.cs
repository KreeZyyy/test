using UnityEngine;
namespace ModularSwitchboards
{
    internal static class TransformerFit
    {
        // Match the ordinary breaker fascia. Keep all native parts proportional
        // and leave 1 mm clearance above and below the fitted assembly.
        internal const float FaceHeight=.045f*1.35f;
        internal const float Scale=(FaceHeight-.002f)/.068f;
        internal const float FaceFront=.0736f;
        internal static Vector3 Point(Vector3 p,int slots)
        {
            var pivot=new Vector3(TransformerPanelLayout.PortCenterX(slots),0,FaceFront);
            return pivot+(p-pivot)*Scale;
        }
        internal static Bounds Pocket(Bounds bounds,int slots)=>new Bounds(Point(bounds.center,slots),bounds.size*Scale);
    }
}
