using System;
using System.Collections.Generic;
using System.Linq;
namespace ModularSwitchboards
{
    // Give each physical wire its own passive node in the existing actual-load
    // solver. Negative IDs exist only in this snapshot, never on game Things.
    internal sealed class CabinetWirePower
    {
        private static long nextId;
        internal readonly Dictionary<long,CabinetWireSaveData> Wires=new Dictionary<long,CabinetWireSaveData>();
        internal readonly List<CabinetWireSaveData> Graph=new List<CabinetWireSaveData>();
        internal readonly List<CabinetPowerNode> Nodes=new List<CabinetPowerNode>();
        internal CabinetWirePower(IEnumerable<CabinetWireSaveData> graph,IList<CabinetWireSaveData> physical,Func<CabinetWireKind,float> rating)
        {
            foreach(var wire in graph.Where(w=>!w.Burnt))
            {
                int index=physical.IndexOf(wire);
                if(index<0){Graph.Add(wire);continue;}
                if(wire.PowerId==0)wire.PowerId=System.Threading.Interlocked.Decrement(ref nextId);
                long id=wire.PowerId;Wires[id]=wire;
                Nodes.Add(new CabinetPowerNode{ReferenceId=id,Conducting=true,RatedWatts=rating(wire.CableKind)});
                var input=new CabinetWireEnd(id,0);var output=new CabinetWireEnd(id,1);
                Graph.Add(new CabinetWireSaveData{From=wire.From,To=input});Graph.Add(new CabinetWireSaveData{From=output,To=wire.To});
                if(wire.From.IsNeutral&&wire.To.IsNeutral)
                {Graph.Add(new CabinetWireSaveData{From=wire.To,To=input});Graph.Add(new CabinetWireSaveData{From=output,To=wire.From});}
            }
        }
    }
}
