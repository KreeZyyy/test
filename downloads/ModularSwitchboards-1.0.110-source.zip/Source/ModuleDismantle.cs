using Assets.Scripts;
using Assets.Scripts.Objects;
namespace ModularSwitchboards
{
    internal static class ModuleDismantle
    {
        internal static bool CanRefund(DinBreaker module)
            =>CabinetWiring.CabinetOf(module)?.Wiring.CanRefundBreaker(module.ReferenceId)!=false;
        internal static bool CanRefund(SmartModule module)
            =>module.AttachedWiring?.CanRefundBreaker(module.ReferenceId)!=false;
        internal static void Unlink(SmartModule module)=>module.AttachedWiring?.RemoveBreaker(module.ReferenceId);
        // Native Structure calls this only after the actual deconstruction tool
        // succeeds. Hover/preview/cancel and damage do not refund any cables.
        internal static void Refund(Structure __instance,ConstructionEventInstance __0,bool __1)
        {
            if(!GameManager.RunSimulation||__1)return;
            if(__instance is DinTransformer transformer){transformer.Wiring?.RefundAndRemoveBreaker(transformer.ReferenceId,__0.Position,__0.OtherHandSlot);return;}
            if(__instance is SmartContactor contactor){contactor.Wiring?.RefundAndRemoveBreaker(contactor.ReferenceId,__0.Position,__0.OtherHandSlot);return;}
            if(__instance is SmartModule smart)
            {
                smart.AttachedWiring?.RefundAndRemoveBreaker(smart.ReferenceId,__0.Position,__0.OtherHandSlot);return;
            }
            if(!(__instance is DinBreaker module))return;
            CabinetWiring.CabinetOf(module)?.Wiring.RefundAndRemoveBreaker(module.ReferenceId,__0.Position,__0.OtherHandSlot);
        }
    }
}
