using System.Collections.Generic;
namespace ModularSwitchboards
{
    // Paths contain module IDs only; live demand, cell charge and budgets are not cached.
    internal sealed class WireCircuitPaths
    {
        private readonly WireCircuitGraph graph;
        private long[] eligible;
        private readonly Dictionary<CabinetWireEnd,Dictionary<CabinetWireEnd,long[]>> paths=new Dictionary<CabinetWireEnd,Dictionary<CabinetWireEnd,long[]>>();
        internal WireCircuitPaths(WireCircuitGraph graph){this.graph=graph;}
        internal void Update(IList<CabinetWireSaveData> wires,long[] closed,long[] modules)
        {
            bool changed=graph.Update(wires,closed)||eligible==null||eligible.Length!=modules.Length;
            if(!changed)for(int i=0;i<eligible.Length;i++)if(eligible[i]!=modules[i]){changed=true;break;}
            if(changed){eligible=(long[])modules.Clone();paths.Clear();}
        }
        internal long[] Path(CabinetWireEnd from,CabinetWireEnd to)
        {
            if(!paths.TryGetValue(from,out var targets))paths[new CabinetWireEnd(from.Owner,from.Contact)]=targets=new Dictionary<CabinetWireEnd,long[]>();
            if(targets.TryGetValue(to,out var result))return result;
            var found=new List<long>();foreach(long id in eligible)
                if(graph.Reachable(from,new CabinetWireEnd(id,0))&&graph.Reachable(new CabinetWireEnd(id,1),to))found.Add(id);
            result=found.ToArray();targets[new CabinetWireEnd(to.Owner,to.Contact)]=result;return result;
        }
    }
}
