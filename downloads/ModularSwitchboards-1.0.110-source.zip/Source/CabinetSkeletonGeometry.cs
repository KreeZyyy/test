using System;
using System.Collections.Generic;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class CabinetSkeletonGeometry
    {
        // Native housing: .400 x .500, R20; Medium doubles XY, R40.
        // Its wall is 6 mm (12 mm Medium). Keep an additional 0.5 mm
        // clearance so the frame follows the inside of the actual shell.
        internal const float Clearance=.0005f,Rear=.0065f,Front=.1795f,RingDepth=.020f;
        internal const int CornerSteps=12;
        internal readonly struct Profile
        {
            internal readonly float Width,Height,Radius,Rail,Scale;
            internal Profile(float scale)
            {
                Scale=scale;Width=.4f*scale-2*(.006f*scale+Clearance);Height=.5f*scale-2*(.006f*scale+Clearance);
                Radius=.02f*scale-(.006f*scale+Clearance);Rail=.012f*scale;
                if(Radius<=Rail)throw new ArgumentOutOfRangeException(nameof(scale));
            }
        }
        internal static Vector3[] Contour(Profile p,bool inner)
        {
            float radius=p.Radius-(inner?p.Rail:0),cx=p.Width*.5f-p.Radius,cy=p.Height*.5f-p.Radius;
            var points=new Vector3[4*(CornerSteps+1)];int n=0;
            for(int corner=0;corner<4;corner++)for(int step=0;step<=CornerSteps;step++)
            {
                float a=(corner*90f+step*90f/CornerSteps)*Mathf.Deg2Rad;
                points[n++]=new Vector3((corner==0||corner==3?cx:-cx)+radius*Mathf.Cos(a),(corner<2?cy:-cy)+radius*Mathf.Sin(a),0);
            }
            return points;
        }
        internal static Bounds[] DepthRails(Profile p)
        {
            float radius=p.Radius-p.Rail*.5f,diagonal=radius/(float)Math.Sqrt(2);
            float x=p.Width*.5f-p.Radius+diagonal,y=p.Height*.5f-p.Radius+diagonal;
            float back=Rear+RingDepth,front=Front-RingDepth;var rails=new Bounds[4];int n=0;
            foreach(int sx in new[]{-1,1})foreach(int sy in new[]{-1,1})rails[n++]=new Bounds(new Vector3(sx*x,sy*y,(back+front)*.5f),new Vector3(.008f*p.Scale,.008f*p.Scale,front-back));
            return rails;
        }
        internal static void Ring(List<Vector3> vertices,List<Vector3> normals,List<int> triangles,Profile p,float back,float front)
        {
            var outer=Contour(p,false);var inner=Contour(p,true);
            for(int i=0;i<outer.Length;i++)
            {
                int j=(i+1)%outer.Length;
                float a=((i/(CornerSteps+1))*90f+(i%(CornerSteps+1))*90f/CornerSteps)*Mathf.Deg2Rad;
                float b=((j/(CornerSteps+1))*90f+(j%(CornerSteps+1))*90f/CornerSteps)*Mathf.Deg2Rad;
                var na=new Vector3(Mathf.Cos(a),Mathf.Sin(a),0);var nb=new Vector3(Mathf.Cos(b),Mathf.Sin(b),0);
                var oa=outer[i]+Vector3.forward*back;var ob=outer[j]+Vector3.forward*back;var ia=inner[i]+Vector3.forward*back;var ib=inner[j]+Vector3.forward*back;var dz=Vector3.forward*(front-back);
                Quad(vertices,normals,triangles,oa,ob,ob+dz,oa+dz,na,nb,nb,na);
                Quad(vertices,normals,triangles,ia,ia+dz,ib+dz,ib,na*-1,na*-1,nb*-1,nb*-1);
                Quad(vertices,normals,triangles,oa,ia,ib,ob,Vector3.back,Vector3.back,Vector3.back,Vector3.back);
                Quad(vertices,normals,triangles,oa+dz,ob+dz,ib+dz,ia+dz,Vector3.forward,Vector3.forward,Vector3.forward,Vector3.forward);
            }
        }
        private static void Quad(List<Vector3> v,List<Vector3> n,List<int> t,Vector3 a,Vector3 b,Vector3 c,Vector3 d,Vector3 na,Vector3 nb,Vector3 nc,Vector3 nd)
        {int start=v.Count;v.AddRange(new[]{a,b,c,d});n.AddRange(new[]{na,nb,nc,nd});t.AddRange(new[]{start,start+1,start+2,start,start+2,start+3});}
    }
}
