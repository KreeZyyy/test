using System.Collections.Generic;
using System.Linq;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class CabinetCoverWindows
    {
        // These modules are separate native component types, not DinBreaker.
        // Use the module's full mounted width, not its IN/OUT terminal centre.
        internal static WireRect[] Additional(CabinetWiring wiring,Transform surface)
        {
            return wiring.Transformers.Where(t=>!t.IsCursor&&!t.IsBeingDestroyed)
                .Select(t=>Window(t.transform,surface,t.ModuleWidth))
                .Concat(wiring.Contactors.Where(t=>!t.IsCursor&&!t.IsBeingDestroyed)
                    .Select(t=>Window(t.transform,surface,t.ModuleWidth))).ToArray();
        }
        private static WireRect Window(Transform module,Transform surface,int slots)
        {
            var p=surface.InverseTransformPoint(module.TransformPoint(new Vector3((slots-1)*DinLayout.SlotPitch*.5f,0,0)));
            return InnerCoverLayout.Window(p.x,p.y,slots,false);
        }
        internal static string Signature(IEnumerable<WireRect> windows)=>string.Join(";",windows.Select(w=>string.Join(":",new[]{w.Left,w.Right,w.Bottom,w.Top}.Select(v=>v.ToString("F6",System.Globalization.CultureInfo.InvariantCulture)))));
    }
}
