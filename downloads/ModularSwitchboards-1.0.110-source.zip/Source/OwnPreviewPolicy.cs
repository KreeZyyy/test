using Assets.Scripts.Objects;
namespace ModularSwitchboards
{
    internal static class OwnPreviewPolicy
    {
        internal static bool Applies(Structure owner)=>owner is SwitchboardCabinet||owner is DinRail||owner is DinBreaker||owner is DinTransformer||owner is SmartModule||owner is SmartContactor||owner is InnerCoverModule||owner is SwitchboardLabel||owner is DoorLabel;
        internal static bool FittedBody(Structure owner)=>owner is DinRail||owner is DinBreaker||owner is DinTransformer||owner is SmartModule||owner is SmartContactor;
    }
}
