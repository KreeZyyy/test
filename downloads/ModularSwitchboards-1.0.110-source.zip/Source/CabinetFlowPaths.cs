using System.Collections.Generic;
using System.Linq;
namespace ModularSwitchboards
{
    // Enumerate actual directed paths for the collecting cabinet. A union of
    // all reachable module IDs would incorrectly charge parallel protectors
    // for the same entire load. Physical wires are already passive power nodes.
    internal sealed class CabinetFlowPaths
    {
        private sealed class Edge {internal CabinetWireEnd To;internal long Module;}
        private readonly Dictionary<CabinetWireEnd,List<Edge>> edges=new Dictionary<CabinetWireEnd,List<Edge>>();
        private readonly Dictionary<CabinetWireEnd,Dictionary<CabinetWireEnd,List<long[]>>> cache=new Dictionary<CabinetWireEnd,Dictionary<CabinetWireEnd,List<long[]>>>();
        private string signature="";
        internal void Update(IList<CabinetWireSaveData> wires,CabinetPowerNode[] nodes)
        {
            string key=string.Join(";",wires.Where(w=>!w.Burnt).Select(w=>w.From.Owner+"/"+w.From.Contact+">"+w.To.Owner+"/"+w.To.Contact))+":"+string.Join(",",nodes.Where(m=>m.Conducting).Select(m=>m.ReferenceId+"/"+m.IsBatteryModule));
            if(key==signature)return;signature=key;edges.Clear();cache.Clear();
            foreach(var m in nodes.Where(m=>m.Conducting))Add(new CabinetWireEnd(m.ReferenceId,0),new CabinetWireEnd(m.ReferenceId,1),m.IsBatteryModule?0:m.ReferenceId);
            foreach(var w in wires.Where(w=>!w.Burnt)){Add(w.From,w.To,0);if(w.From.IsNeutral&&w.To.IsNeutral)Add(w.To,w.From,0);}
        }
        private void Add(CabinetWireEnd from,CabinetWireEnd to,long module)
        {
            if(!edges.TryGetValue(from,out var list))edges[from]=list=new List<Edge>();
            if(!list.Any(e=>e.To.Equals(to)&&e.Module==module))list.Add(new Edge{To=to,Module=module});
        }
        internal List<long[]> Paths(CabinetWireEnd source,CabinetWireEnd target)
        {
            if(!cache.TryGetValue(source,out var destinations))cache[source]=destinations=new Dictionary<CabinetWireEnd,List<long[]>>();
            if(destinations.TryGetValue(target,out var saved))return saved;
            var result=new List<long[]>();var seen=new HashSet<CabinetWireEnd>();var modules=new List<long>();
            void Visit(CabinetWireEnd end)
            {
                // Bound adversarial fanout; omitted paths reduce available power,
                // never duplicate a source or bypass a protective device.
                if(result.Count>=256||!seen.Add(end))return;
                if(end.Equals(target))result.Add(modules.ToArray());
                else if(edges.TryGetValue(end,out var next))foreach(var edge in next)
                {
                    bool add=edge.Module!=0&&!modules.Contains(edge.Module);if(add)modules.Add(edge.Module);
                    Visit(edge.To);if(add)modules.RemoveAt(modules.Count-1);
                }
                seen.Remove(end);
            }
            Visit(source);destinations[target]=result;return result;
        }
    }
}
