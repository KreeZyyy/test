using Assets.Scripts.Objects;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class FittedControlSelection
    {
        internal static void AfterSelection(Interactable __instance,ref SelectionInstance __result)
        {
            if(!(__instance.Parent is Structure owner)||!OwnPreviewPolicy.Applies(owner)||!(__instance.Collider is BoxCollider box))return;
            var scale=box.transform.lossyScale;
            __result.Bounds=new Bounds(Vector3.Scale(box.center,scale),Vector3.Scale(box.size,new Vector3(Mathf.Abs(scale.x),Mathf.Abs(scale.y),Mathf.Abs(scale.z))));
        }
    }
}
