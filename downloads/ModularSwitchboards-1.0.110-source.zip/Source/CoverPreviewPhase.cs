using System;
namespace ModularSwitchboards
{
    internal static class CoverPreviewPhase
    {
        internal const int Count=16;
        internal static int Frame(float seconds)=>(int)((Math.Max(0,(double)seconds)*20)%Count);
        internal static float Offset(int frame)=>.025f*frame/Count;
    }
}
