namespace ModularSwitchboards
{
    internal static class PowerContactCapacity
    {
        internal static int Get(int contact,bool powerModule,bool bridge,bool contactor)
            =>bridge&&(contact==2||contact==3)?3:powerModule&&(contact==0||contact==1||contactor&&contact==ContactorCircuit.NcPin)?3:1;
    }
}
