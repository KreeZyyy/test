using System;
using System.Collections.Generic;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class TransformerFrontGeometry
    {
        internal const float KnobRadius=.010f,KnobDepth=.005284f;
        internal static readonly Vector3 KnobCenter=new Vector3(TransformerPanelLayout.CenterX,.0185f,.080683f);
        internal static readonly Bounds Pocket=new Bounds(new Vector3(TransformerPanelLayout.CenterX,-.0125f,.0818f),new Vector3(.057f,.0324f,.037f));
        internal static Mesh Body(int slots=DinTransformer.SlotCount,float contentOffset=0f)
        {
            var s=DinBreakerModel.VisualScale;
            var body=TransformerPanelLayout.Body(slots);
            // Replace the original dark fascia with one shared inset gray face.
            // Keep terminal slots; only the front fascia lies beyond local z .0629.
            var vertices=body.vertices;var dark=body.GetTriangles(3);var kept=new List<int>();
            for(int i=0;i<dark.Length;i+=3)
                if(!(vertices[dark[i]].z>.0629f&&vertices[dark[i+1]].z>.0629f&&vertices[dark[i+2]].z>.0629f))
                    kept.AddRange(new[]{dark[i],dark[i+1],dark[i+2]});
            body.SetTriangles(kept,3);
            var openings=slots==6?MediumTransformerGeometry.Pockets:new[]{new Bounds(Pocket.center+new Vector3(contentOffset,0,0),Pocket.size)};
            foreach(var original in openings){var opening=TransformerFit.Pocket(original,slots);var hole=new Bounds(Vector3.Scale(opening.center,new Vector3(1/s.x,1/s.y,1/s.z)),Vector3.Scale(opening.size,new Vector3(1/s.x,1/s.y,1/s.z)));body=TransformerCasePocket.Cut(body,hole);}
            return body;
        }
        internal static Mesh Face(int slots=DinTransformer.SlotCount,float contentOffset=0f)
        {
            var v=new List<Vector3>();var n=new List<Vector3>();var t=new List<int>();
            float width=TransformerPanelLayout.WidthFor(slots)*DinBreakerModel.VisualScale.x-.002f*DinBreakerModel.VisualScale.x;
            RoundedGeometry.Box(v,n,t,new Vector3(TransformerPanelLayout.PortCenterX(slots),0,.0727f),new Vector3(width,TransformerFit.FaceHeight,.0018f),.0004f);
            var original=slots==6?MediumTransformerGeometry.Pockets:new[]{new Bounds(Pocket.center+new Vector3(contentOffset,0,0),Pocket.size)};
            var pockets=new List<Bounds>();var mesh=Finish(v,n,t);
            foreach(var bounds in original){var p=TransformerFit.Pocket(bounds,slots);pockets.Add(p);mesh=TransformerCasePocket.Cut(mesh,p);}
            v=new List<Vector3>(mesh.vertices);n=new List<Vector3>(mesh.normals);t=new List<int>(mesh.GetTriangles(0));
            foreach(var p in pockets)
            {
                float back=p.min.z+.0002f,front=TransformerFit.FaceFront;
                RoundedGeometry.Box(v,n,t,new Vector3(p.center.x,p.center.y,back-.0005f),new Vector3(p.size.x+.001f,p.size.y+.001f,.001f),.0001f);
                foreach(float sign in new[]{-1f,1f})
                {
                    RoundedGeometry.Box(v,n,t,new Vector3(p.center.x+sign*(p.size.x*.5f-.00015f),p.center.y,(back+front)*.5f),new Vector3(.0003f,p.size.y,front-back),.00002f);
                    RoundedGeometry.Box(v,n,t,new Vector3(p.center.x,p.center.y+sign*(p.size.y*.5f-.00005f),(back+front)*.5f),new Vector3(p.size.x,.0001f,front-back),.00002f);
                }
            }
            var result=Finish(v,n,t);CabinetGeometry.ApplyNativeUv(result);return result;
        }
        private static Mesh Finish(List<Vector3> v,List<Vector3> n,List<int> t)
        {
            var mesh=new Mesh{name="Switchboards.TransformerMatchedBreakerFace"};mesh.SetVertices(v);mesh.SetNormals(n);mesh.subMeshCount=5;
            for(int i=0;i<5;i++)mesh.SetTriangles(i==0?t:new List<int>(),i);mesh.RecalculateBounds();return mesh;
        }
        internal static Mesh DialFrame()
        {
            var v=new List<Vector3>();var n=new List<Vector3>();var t=new List<int>();
            // One solid light-gray seat behind both the knob and native arc.
            RoundedGeometry.Box(v,n,t,new Vector3(KnobCenter.x,.021f,.0739f),new Vector3(.025f,.025f,.0006f),.0001f);
            var mesh=new Mesh{name="Switchboards.TransformerDialAndArcFrame"};mesh.SetVertices(v);mesh.SetNormals(n);mesh.subMeshCount=5;
            for(int i=0;i<5;i++)mesh.SetTriangles(i==4?t:new List<int>(),i);mesh.RecalculateBounds();return mesh;
        }
        internal static Mesh Knob()=>TransformerReferenceMesh.Load("Dial");
    }
}
