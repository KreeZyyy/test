using Assets.Scripts;
using Assets.Scripts.Objects;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class CabinetPaintSurface
    {
        internal static void Apply(MeshRenderer renderer,int colour)
        {
            // Keep the native textured paint atlas. Swatch.Normal is the legacy
            // solid-colour material and discards the surface/normal textures.
            var material=CabinetGeometry.Materials[0];if(material==null||renderer.sharedMaterial==material)return;
            CabinetMatteSurface.Restore(renderer);
            var materials=renderer.sharedMaterials;
            if(materials.Length>0&&materials[0]!=material){materials[0]=material;renderer.sharedMaterials=materials;}
        }
        // This is a texture-array layer index from the native prefab, not a
        // gloss value read from the legacy solid-colour swatch material.
        internal static float Smoothness(int colour,int fallback)=>fallback;
    }
}
