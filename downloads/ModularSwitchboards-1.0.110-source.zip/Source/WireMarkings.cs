using System;
using System.Collections.Generic;
namespace ModularSwitchboards
{
    internal static class WireMarkings
    {
        internal static WireVisualLayout Plan(WirePoint[] path,CabinetWireKind kind)
        {
            var original=new float[path.Length];for(int i=1;i<path.Length;i++)original[i]=original[i-1]+(float)Math.Sqrt((path[i]-path[i-1]).Squared);
            float length=original[original.Length-1];var profile=WireVisualProfiles.Get(kind);
            var metal=WireJointPlacement.Place(path,original,profile.CollarLength,profile.JointPitch);var cuts=new List<float>(original);
            foreach(var band in metal)foreach(float d in new[]{band.Start-.002f,band.Start,band.End,band.End+.002f})if(d>0&&d<length)cuts.Add(d);
            if(profile.TwistPitch>0){float step=profile.TwistPitch/32;for(int ring=1;ring*step<length;ring++)cuts.Add(ring*step);}
            cuts.Sort();var points=new List<WirePoint>();var arc=new List<float>();int segment=1;
            foreach(float d in cuts)
            {
                if(arc.Count>0&&d-arc[arc.Count-1]<.000001f)continue;
                while(segment<path.Length-1&&original[segment]<d)segment++;
                float span=original[segment]-original[segment-1];if(span<.0000001f)continue;
                float t=(d-original[segment-1])/span;points.Add(path[segment-1]+(path[segment]-path[segment-1])*t);arc.Add(d);
            }
            return new WireVisualLayout{Points=points.ToArray(),Distances=arc.ToArray(),Metal=metal};
        }
        internal static WirePoint[] Sample(WirePoint[] path,CabinetWireKind kind,out float[] distances){var plan=Plan(path,kind);distances=plan.Distances;return plan.Points;}
    }
}
