using System.Collections.Generic;
using Assets.Scripts.Objects;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class MediumGeometry
    {
        internal static Mesh Stretch(Mesh source,float x,float y,bool mirror=false)
        {
            var mesh=UnityEngine.Object.Instantiate(source);mesh.name="Medium."+source.name;
            var vertices=mesh.vertices;
            for(int i=0;i<vertices.Length;i++)vertices[i]=new Vector3(vertices[i].x*x*(mirror?-1:1),vertices[i].y*y,vertices[i].z);
            mesh.vertices=vertices;
            if(mirror)for(int s=0;s<mesh.subMeshCount;s++){var t=mesh.GetTriangles(s);for(int i=0;i<t.Length;i+=3){int n=t[i+1];t[i+1]=t[i+2];t[i+2]=n;}mesh.SetTriangles(t,s);}
            mesh.RecalculateNormals();mesh.RecalculateTangents();mesh.RecalculateBounds();return mesh;
        }
        // Match the housing's 40 mm XY corner while keeping the centre seam
        // at 400 mm and preserving its existing 20 mm inner corner/handle.
        internal static float DoorCornerX(float x)
            =>x<=.020f?x*2f:x>=.380f?x:.040f+(x-.020f)*(.340f/.360f);
        internal static Mesh Door(Mesh source,bool mirror=false)
        {
            var mesh=Stretch(source,1,2,mirror);var vertices=mesh.vertices;
            foreach(int i in System.Linq.Enumerable.Distinct(mesh.GetTriangles(0)))
                vertices[i].x=(mirror?-1:1)*DoorCornerX(System.Math.Abs(vertices[i].x));
            mesh.vertices=vertices;mesh.RecalculateNormals();mesh.RecalculateTangents();mesh.RecalculateBounds();return mesh;
        }
        internal static void Install(SwitchboardCabinet host)
        {
            var model=host.transform.Find("SwitchboardModel");model.localPosition+=Vector3.up*CabinetShape.OffsetY(host.PrefabName);
            var shell=model.Find("CompletedShell");
            foreach(var name in new[]{"Frame","CompletedShell/Housing","CompletedShell/Interior","CompletedShell/DoorReturnLip"})
            {
                var t=model.Find(name);if(t==null)continue;var filter=t.GetComponent<MeshFilter>();if(filter!=null){filter.sharedMesh=Stretch(filter.sharedMesh,2,2);if(name=="CompletedShell/Housing")CabinetHinges.ApplyMedium(filter.sharedMesh);}
            }
            foreach(var collider in model.GetComponentsInChildren<BoxCollider>(true))
            {
                if(collider.transform.IsChildOf(shell.Find("DoorHinge")))continue;
                collider.center=new Vector3(collider.center.x*2,collider.center.y*2,collider.center.z);
                collider.size=new Vector3(collider.size.x*2,collider.size.y*2,collider.size.z);
            }
            shell.Find("RoundedHousingCollider").GetComponent<MeshCollider>().sharedMesh=shell.Find("Housing").GetComponent<MeshFilter>().sharedMesh;
            var left=shell.Find("DoorHinge");left.localPosition=new Vector3(-.4f,0,.187f);
            var door=left.Find("Door").GetComponent<MeshFilter>();
            float smallDoorTop=door.sharedMesh.bounds.max.y;
            door.sharedMesh=Door(door.sharedMesh);
            float mediumDoorTop=door.sharedMesh.bounds.max.y;
            left.Find("DoorCollider").GetComponent<MeshCollider>().sharedMesh=door.sharedMesh;
            foreach(Transform t in left)if(t.name!="Door"&&t.name!="DoorCollider")
            {
                var v=t.localPosition;
                if(t.name=="NativeApcWarning")
                {
                    var warning=t.GetComponent<MeshFilter>()?.sharedMesh;
                    if(warning!=null)
                    {
                        var bounds=CabinetWallMount.TransformedBounds(warning.bounds,Matrix4x4.TRS(t.localPosition,t.localRotation,t.localScale));
                        float gap=smallDoorTop-bounds.max.y;
                        v.y=WarningTopPlacement.Y(v.y,smallDoorTop,mediumDoorTop);
                        Debug.Log("[Modular Switchboards] Medium warning: Small top-edge gap="+gap.ToString("F6")+" m; centre below top="+(smallDoorTop-bounds.center.y).ToString("F6")+" m; moved up "+(mediumDoorTop-smallDoorTop).ToString("F6")+" m on "+host.PrefabName);
                    }
                }
                else v.y*=2;
                t.localPosition=v;
                if(t.name=="DoorHandleInteraction"){var handleBox=t.GetComponent<BoxCollider>();handleBox.size=new Vector3(handleBox.size.x,handleBox.size.y*2,handleBox.size.z);}
            }
            var right=new GameObject("RightDoorHinge"){layer=host.gameObject.layer};right.transform.SetParent(shell,false);right.transform.localPosition=new Vector3(.4f,0,.187f);
            foreach(var name in new[]{"Door","DoorCollider"})
            {
                var t=new GameObject(name){layer=host.gameObject.layer};t.transform.SetParent(right.transform,false);
                if(name=="Door"){t.AddComponent<MeshFilter>().sharedMesh=Door(CabinetGeometry.Meshes[3],true);t.AddComponent<MeshRenderer>().sharedMaterials=left.Find("Door").GetComponent<MeshRenderer>().sharedMaterials;}
                else{var c=t.AddComponent<MeshCollider>();c.sharedMesh=right.transform.Find("Door").GetComponent<MeshFilter>().sharedMesh;host.BuildStates[1].Colliders.Add(c);}
            }
            // Native Open state operates both leaves; the handles remain at their centre seam.
            var handle=new GameObject("DoorHandleInteraction"){layer=host.gameObject.layer};handle.transform.SetParent(right.transform,false);handle.transform.localPosition=new Vector3(-.37f,-.12f,.026f);
            var hit=handle.AddComponent<BoxCollider>();hit.size=new Vector3(.025f,.146f,.036f);host.BuildStates[1].Colliders.Add(hit);
            CabinetDoorHandles.Install(host,left.Find("DoorHandleInteraction").GetComponent<BoxCollider>(),hit);
            host.GetComponent<CabinetDoor>().RightHinge=right.transform;
            host.Thumbnail=CabinetIcons.Get("MediumCabinet");
            for(int i=0;i<host.BuildStates.Count;i++)host.BuildStates[i].Thumbnail=CabinetIcons.Get(i==0?"MediumFrame":"MediumCabinet");
        }
    }
}
