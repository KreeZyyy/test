using System;
using System.Collections.Generic;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class PlacementOutlineGeometry
    {
        private sealed class Edge{internal int A,B,Count;internal Vector3 Normal;internal bool Crease;}
        internal static int[] Build(Vector3[] vertices,int[] triangles)
        {
            var weld=new Dictionary<Tuple<int,int,int>,int>();var canonical=new int[vertices.Length];
            for(int i=0;i<vertices.Length;i++)
            {
                var p=vertices[i];var key=Tuple.Create((int)Math.Round(p.x*1000000),(int)Math.Round(p.y*1000000),(int)Math.Round(p.z*1000000));
                if(!weld.TryGetValue(key,out int first))weld[key]=first=i;canonical[i]=first;
            }
            var edges=new Dictionary<Tuple<int,int>,Edge>();
            for(int i=0;i+2<triangles.Length;i+=3)
            {
                int a=canonical[triangles[i]],b=canonical[triangles[i+1]],c=canonical[triangles[i+2]];
                var normal=Vector3.Cross(vertices[b]-vertices[a],vertices[c]-vertices[a]);if(normal.sqrMagnitude<1e-18f)continue;normal=normal.normalized;
                Add(edges,a,b,normal);Add(edges,b,c,normal);Add(edges,c,a,normal);
            }
            var lines=new List<int>();foreach(var e in edges.Values)if(e.Count==1||e.Crease){lines.Add(e.A);lines.Add(e.B);}
            return lines.ToArray();
        }
        private static void Add(Dictionary<Tuple<int,int>,Edge> edges,int a,int b,Vector3 normal)
        {
            if(a>b){int t=a;a=b;b=t;}var key=Tuple.Create(a,b);
            if(!edges.TryGetValue(key,out var edge))edges[key]=edge=new Edge{A=a,B=b,Normal=normal};
            else if(Vector3.Dot(edge.Normal,normal)<.9995f)edge.Crease=true;
            edge.Count++;
        }
    }
}
