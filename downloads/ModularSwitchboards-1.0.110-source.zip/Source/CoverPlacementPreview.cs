using System;
using System.Linq;
using UnityEngine;
using UnityEngine.Rendering;
namespace ModularSwitchboards
{
    internal static class CoverPlacementPreview
    {
        internal static bool Apply(GameObject cursor,CoverMemory state)
        {
            var filter=cursor.GetComponent<MeshFilter>();var renderer=cursor.GetComponent<MeshRenderer>();if(filter==null||renderer==null)return false;
            var labels=state.Labels.Select(l=>{float x=-state.HalfSpan+l.X*.00045f+(l.Width-1)*DinLayout.SlotPitch*.5f,y=.0525f+l.Y*.00045f,w=l.Width*DinLayout.SlotPitch-.0068f;return new CoverIconRect(x-w*.5f,x+w*.5f,y-.0075f,y+.0075f);}).ToArray();
            var body=InnerCoverLayout.Cells(state.Retained,state.Profile);var fill=new Mesh{name="Switchboards.CoverPreview.Fill",indexFormat=IndexFormat.UInt32};
            var vertices=new System.Collections.Generic.List<Vector3>();var triangles=new System.Collections.Generic.List<int>();
            foreach(var cell in body){int n=vertices.Count;vertices.AddRange(new[]{new Vector3(cell.Left,cell.Bottom,0),new Vector3(cell.Right,cell.Bottom,0),new Vector3(cell.Right,cell.Top,0),new Vector3(cell.Left,cell.Top,0)});triangles.AddRange(new[]{n,n+1,n+2,n,n+2,n+3});}
            fill.SetVertices(vertices);fill.SetTriangles(triangles,0);fill.RecalculateNormals();fill.RecalculateBounds();
            var data=CoverPreviewGeometry.Build(body,Array.Empty<InnerCoverLayout.Cell>(),labels);var edges=new Mesh{name="Switchboards.CoverPreview.EdgesAndLabels",indexFormat=IndexFormat.UInt32};edges.SetVertices(data.Vertices);edges.subMeshCount=2;edges.SetTriangles(data.Triangles[1],0);edges.SetTriangles(data.Triangles[2],1);edges.RecalculateBounds();
            var fillInk=PlacementPreviewStyle.NativeFill();var edgeInk=PlacementPreviewStyle.Ink(.85f,CullMode.Off);var labelInk=PlacementPreviewStyle.Ink(.95f,CullMode.Off);
            if(fillInk==null||edgeInk==null||labelInk==null){UnityEngine.Object.Destroy(fill);UnityEngine.Object.Destroy(edges);return false;}
            filter.sharedMesh=fill;PlacementPreviewStyle.Surface(renderer,new[]{fillInk});
            var overlay=new GameObject("StaticEdgesAndLabels"){layer=cursor.layer};overlay.transform.SetParent(cursor.transform,false);overlay.AddComponent<MeshFilter>().sharedMesh=edges;var edgeRenderer=overlay.AddComponent<MeshRenderer>();PlacementPreviewStyle.Surface(edgeRenderer,new[]{edgeInk,labelInk});
            var owner=cursor.AddComponent<PlacementPreviewResources>();owner.Fill=fill;owner.Edges=edges;owner.Materials=new[]{fillInk,edgeInk,labelInk};
            foreach(var label in state.Labels){var root=new GameObject("PlacementLabel"){layer=cursor.layer};root.transform.SetParent(cursor.transform,false);root.transform.localPosition=new Vector3(-state.HalfSpan+label.X*.00045f,.0525f+label.Y*.00045f,.003f);PortableCoverVisual.Text(root.transform,label,true);}
            return true;
        }
    }
    internal static class PlacementLabelText
    {
        private static readonly System.Collections.Generic.Dictionary<Font,Material> materials=new System.Collections.Generic.Dictionary<Font,Material>();
        internal static Material For(Font font)
        {
            if(!materials.TryGetValue(font,out var material)){material=new Material(DepthLabelText.For(font)){name="Switchboards.PlacementLabel.Green",color=Color.green};material.EnableKeyword("_EMISSION");material.SetColor("_EmissionColor",Color.green);materials[font]=material;}
            material.mainTexture=font.material.mainTexture;return material;
        }
    }
}
