using System.Collections.Generic;
using System.Linq;
using Assets.Scripts.Objects;
using UnityEngine;
namespace ModularSwitchboards
{
    // Kept on the cabinet root: it must run even if a native state transition
    // temporarily disables CompletedShell while changing visualizers.
    public sealed class CabinetInnerCover:MonoBehaviour
    {
        public SwitchboardCabinet Owner;
        private GameObject panel;
        private Mesh mesh;
        private string signature;
        internal static void Install(SwitchboardCabinet owner,BuildState covered)
        {
            // CanManufacture marks a usable intermediate native structure state.
            // The open-backed cabinet must keep working without the optional cover.
            owner.BuildStates[1].CanManufacture=true;
            owner.BuildStates.Add(covered);
            var view=owner.gameObject.AddComponent<CabinetInnerCover>();view.Owner=owner;
            var go=new GameObject("InnerCover"){layer=owner.gameObject.layer};go.transform.SetParent(owner.transform.Find("SwitchboardModel/CompletedShell"),false);
            meshForPrefab(go,owner.CoverProfile);
            covered.Colliders.Add(go.GetComponent<MeshCollider>());
        }
        private static void meshForPrefab(GameObject go,InnerCoverLayout.Panel profile)
        {
            go.AddComponent<MeshFilter>().sharedMesh=Build(new WireRect[0],profile);
            var renderer=go.AddComponent<MeshRenderer>();renderer.sharedMaterials=CabinetGeometry.Materials;CabinetMatteSurface.Apply(renderer);
            go.AddComponent<MeshCollider>();go.SetActive(false);
        }
        private static WireRect MediumCoverWindow(Vector3 p)=>new WireRect(p.x-.016f,p.x+.013f,p.y-.006f,p.y+.006f);
        private void LateUpdate()
        {
            if(Owner==null||Owner.IsCursor)return;
            var shell=Owner.transform.Find("SwitchboardModel/CompletedShell");if(shell==null)return;
            if(Owner.CurrentBuildStateIndex>=1)
            {
                if(!shell.gameObject.activeSelf)shell.gameObject.SetActive(true);
                var housing=shell.Find("Housing")?.GetComponent<MeshRenderer>();if(housing!=null)housing.enabled=true;
                // Native intermediate states share shell colliders. Keep them
                // enabled in both operational states; the board has its own gate.
                foreach(var collider in Owner.BuildStates[1].Colliders)if(collider!=null&&collider!=Owner.RailSurface&&collider!=Owner.CoverSurface&&collider!=Owner.BridgeSurface&&collider!=Owner.DoorSurface)collider.enabled=true;
            }
            if(panel==null)panel=shell.Find("InnerCover")?.gameObject;
            if(panel==null)return;
            bool show=!Owner.IsCursor&&Owner.CurrentBuildStateIndex==2;
            panel.SetActive(show);panel.GetComponent<MeshCollider>().enabled=show;
            Thing._colliderLookup[panel.GetComponent<MeshCollider>()]=Owner;
            if(!show)return;
            var modules=Owner.Wiring.Breakers.Where(b=>!b.IsBeingDestroyed&&b.transform.Find("DinBreakerModel")!=null).OrderBy(b=>b.ReferenceId).ToArray();
            var centers=modules.Select(b=>shell.InverseTransformPoint(b.transform.Find("DinBreakerModel").TransformPoint(new Vector3(b.ContactOffsetX,0,0)))).ToArray();
            var bridges=Owner.Wiring.Breakers.Where(b=>b.IsDoorBridge&&!b.IsBeingDestroyed).ToArray();
            string next=Owner.CoverProfile.Signature+":"+string.Join(",",bridges.Select(b=>b.ReferenceId+":"+shell.InverseTransformPoint(b.transform.position).y.ToString("F5")))+";"+string.Join(";",modules.Select((b,i)=>b.ReferenceId+":"+b.ModuleWidth+":"+b.IsBatteryModule+":"+centers[i].ToString("F6")));
            var smart=Owner.Wiring.SmartModules.Where(m=>!m.IsBeingDestroyed).OrderBy(m=>m.ReferenceId).ToArray();
            next+="|smart:"+string.Join(";",smart.Select(m=>m.ReferenceId+":"+shell.InverseTransformPoint(m.transform.position).ToString("F6")));
            var additional=CabinetCoverWindows.Additional(Owner.Wiring,shell);
            next+="|additional:"+CabinetCoverWindows.Signature(additional);
            if(signature==next)return;
            var windows=modules.Select((b,i)=>InnerCoverLayout.Window(centers[i].x,centers[i].y,b.ModuleWidth,b.IsBatteryModule));
            windows=windows.Concat(smart.Select(m=>{var p=shell.InverseTransformPoint(m.transform.TransformPoint(new Vector3(DinSmartLayout.CenterX*DinBreakerModel.VisualScale.x,0,0)));return InnerCoverLayout.Window(p.x,p.y,4,false);}));
            windows=windows.Concat(bridges.Select(b=>MediumCoverWindow(shell.InverseTransformPoint(b.transform.position))));
            windows=windows.Concat(additional);
            var fresh=Build(windows,Owner.CoverProfile);var filter=panel.GetComponent<MeshFilter>();var old=filter.sharedMesh;
            filter.sharedMesh=fresh;panel.GetComponent<MeshCollider>().sharedMesh=fresh;
            var previousOwned=mesh;mesh=fresh;signature=next;
            if(old!=null&&old!=fresh&&old==previousOwned)Destroy(old);
            CabinetAppearance.RefreshPaint(Owner);
        }
        internal static Mesh Build(IEnumerable<WireRect> windows)=>Build(windows,InnerCoverLayout.Small);
        internal static Mesh Build(IEnumerable<WireRect> windows,InnerCoverLayout.Panel profile)
        {
            var v=new List<Vector3>();var normals=new List<Vector3>();var t=new List<int>();
            float front=profile.Depth+profile.Sheet*.5f,rear=profile.Depth-profile.Sheet*.5f;
            System.Action<Vector3,Vector3,Vector3,Vector3,Vector3> quad=(a,b,c,d,n)=>
            {
                int s=v.Count;v.AddRange(new[]{a,b,c,d});normals.AddRange(new[]{n,n,n,n});
                bool forward=Vector3.Dot(Vector3.Cross(b-a,c-a),n)>0;
                t.AddRange(forward?new[]{s,s+1,s+2,s,s+2,s+3}:new[]{s,s+2,s+1,s,s+3,s+2});
            };
            foreach(var cell in InnerCoverLayout.Cells(windows,profile))
            {
                float l=cell.Left,r=cell.Right,b=cell.Bottom,u=cell.Top;
                quad(new Vector3(l,b,front),new Vector3(r,b,front),new Vector3(r,u,front),new Vector3(l,u,front),Vector3.forward);
                quad(new Vector3(l,b,rear),new Vector3(r,b,rear),new Vector3(r,u,rear),new Vector3(l,u,rear),Vector3.back);
                if(cell.West)quad(new Vector3(l,b,rear),new Vector3(l,u,rear),new Vector3(l,u,front),new Vector3(l,b,front),Vector3.left);
                if(cell.East)quad(new Vector3(r,b,rear),new Vector3(r,u,rear),new Vector3(r,u,front),new Vector3(r,b,front),Vector3.right);
                if(cell.South)quad(new Vector3(l,b,rear),new Vector3(r,b,rear),new Vector3(r,b,front),new Vector3(l,b,front),Vector3.down);
                if(cell.North)quad(new Vector3(l,u,rear),new Vector3(r,u,rear),new Vector3(r,u,front),new Vector3(l,u,front),Vector3.up);
            }
            var result=new Mesh{name="Switchboards.InnerCover.DinWindows"};result.SetVertices(v);result.SetNormals(normals);result.subMeshCount=5;
            for(int i=0;i<5;i++)result.SetTriangles(i==0?t.ToArray():new int[0],i);
            CabinetGeometry.ApplyNativeUv(result);result.RecalculateBounds();return result;
        }
        private void OnDestroy()
        {
            if(panel!=null){var collider=panel.GetComponent<MeshCollider>();if(collider!=null&&Thing._colliderLookup.TryGetValue(collider,out var owner)&&owner==Owner)Thing._colliderLookup.Remove(collider);}
            if(mesh!=null)Destroy(mesh);
        }
    }
}
