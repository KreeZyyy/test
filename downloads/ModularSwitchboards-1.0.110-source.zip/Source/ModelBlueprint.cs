using System;
using System.Collections.Generic;
using Assets.Scripts.Objects;
using Assets.Scripts.UI;
using UnityEngine;
using UnityEngine.Rendering;
namespace ModularSwitchboards
{
    internal static class ModelBlueprint
    {
        // Position-only snapshot: native meshes can use incompatible vertex
        // channels/materials, but a construction ghost needs only their geometry.
        internal static Mesh Build(Transform root,Thing owner=null,bool includeDisabled=false)
        {
            var vertices=new List<Vector3>();var triangles=new List<int>();
            foreach(var renderer in root.GetComponentsInChildren<MeshRenderer>(true))
            {
                if(!includeDisabled&&!renderer.enabled||!Visible(renderer.transform,root)||owner!=null&&renderer.GetComponentInParent<Thing>()!=owner)continue;
                var filter=renderer.GetComponent<MeshFilter>();var mesh=filter==null?null:filter.sharedMesh;
                if(mesh==null)continue;
                CabinetGeometry.ReadNativeMesh(mesh,out var positions,out _,out var groups);
                var matrix=root.worldToLocalMatrix*renderer.transform.localToWorldMatrix;
                var indices=new Dictionary<int,int>();bool mirrored=matrix.determinant<0;
                foreach(var group in groups)for(int i=0;i<group.Length;i+=3)
                {
                    var face=new int[3];
                    for(int j=0;j<3;j++)
                    {
                        int index=group[i+j];if(!indices.TryGetValue(index,out int mapped)){mapped=vertices.Count;indices[index]=mapped;vertices.Add(matrix.MultiplyPoint3x4(positions[index]));}face[j]=mapped;
                    }
                    triangles.Add(face[0]);triangles.Add(face[mirrored?2:1]);triangles.Add(face[mirrored?1:2]);
                }
            }
            if(triangles.Count==0)throw new InvalidOperationException("Cannot build a preview without model geometry.");
            var ghost=new Mesh{name="Switchboards.ActualModelBlueprint",indexFormat=IndexFormat.UInt32};
            ghost.SetVertices(vertices);ghost.SetTriangles(triangles,0);ghost.RecalculateNormals();ghost.RecalculateBounds();return ghost;
        }
        private static bool Visible(Transform node,Transform root)
        {
            for(var current=node;current!=null&&current!=root;current=current.parent)if(!current.gameObject.activeSelf)return false;
            return true;
        }
        internal static void Refresh(Structure owner)
        {
            var wire=owner.Blueprint.GetComponent<Wireframe>();var old=wire.BlueprintMeshFilter.sharedMesh;
            var mesh=Build(owner.transform);wire.BlueprintMeshFilter.sharedMesh=mesh;wire.BlueprintBounds=mesh.bounds;
            FittedModelCollider.Install(owner,mesh);
            // Some original previews share the live rail mesh. Never destroy it.
            bool shared=false;foreach(var filter in owner.GetComponentsInChildren<MeshFilter>(true))if(filter.sharedMesh==old)shared=true;
            if(old!=null&&!shared)UnityEngine.Object.DestroyImmediate(old);
        }
    }
}
