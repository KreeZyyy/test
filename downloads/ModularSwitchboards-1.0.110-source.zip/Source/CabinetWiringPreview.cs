namespace ModularSwitchboards
{
    public sealed partial class CabinetWiring
    {
        private readonly WireRouteJob previewRouteJob=new WireRouteJob();
        private bool PollPreviewRoute(CabinetWireEnd from,CabinetWireEnd to,CabinetWireKind kind)
        {
            if(!previewRouteJob.Matches(revision,from,to,kind))previewRouteJob.Start(revision,from,to,kind,CaptureRoutePlanner());
            if(!previewRouteJob.TryRead(out var ready))return false;
            routeFrom=from;routeTo=to;routeKind=kind;routeRevision=revision;route=ready.Points;routeSlot=ready.Slot;routeFailure=ready.Failure;return true;
        }
    }
}
