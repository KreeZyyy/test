using Assets.Scripts;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Items;
using Assets.Scripts.Objects.Motherboards;
using UnityEngine;
namespace ModularSwitchboards
{
    public sealed partial class CabinetWiring
    {
        private void RefreshWireColours(int hover,CabinetWireSaveData paintedWire)
        {
            foreach(var pair in wireRenderers)if(pair.Value!=null)Color(pair.Value,(hover>=0&&ReferenceEquals(wires[hover],pair.Key))||ReferenceEquals(paintedWire,pair.Key)?(WireColor(pair.Key)==ColorType.Yellow?ColorType.White:ColorType.Yellow):WireColor(pair.Key));
        }
        private static ColorType WireColor(CabinetWireSaveData wire)
            =>GameManager.IsValidColor(wire.ColorIndex)?(ColorType)wire.ColorIndex:ColorType.Red;
        // Same nearest-segment radius as the wire cutters. UI, highlight and
        // authoritative paint action all resolve the same target from this point.
        internal CabinetWireSaveData PaintWireAt(Vector3 world)
        {
            if(!ContainsInteractionPoint(world))return null;
            int index=WireAt(world);if(index<0)return null;
            var wire=wires[index];return Owner.HasInnerCover&&!IsDoorWire(wire)?null:wire;
        }
        private bool TryPaintWire(Attack attack,ISprayer sprayer,bool doAction,out Thing.DelayedActionInstance result)
        {
            result=null;
            if(attack.DestinationThing!=Owner||!ContainsInteractionPoint(attack.Position))return false;
            var wire=PaintWireAt(attack.Position);if(wire==null)return false;
            if(wire.Burnt){result=new Thing.DelayedActionInstance{Duration=0};result.Fail("Burnt wire: remove with wire cutters and replace.");return true;}
            result=new Thing.DelayedActionInstance{Duration=sprayer.TimeToUse(),OverrideTitle="Internal wire",ActionMessage="Paint wire",ActionSoundHash=sprayer.ConstructingSoundHash,ActionCompleteSoundHash=attack.SourceItem is Item item?item.FinishedConstructingSoundHash:-1};
            if(Owner.IsCursor||!Owner.IsStructureCompleted||!Owner.IsOpen){result.Fail("Open the completed cabinet first.");return true;}
            var actor=attack.SourceItem.RootParentHuman;
            if(actor==null||(actor.Transform.position-Owner.Transform.position).sqrMagnitude>16f){result.Fail("Move closer to the cabinet.");return true;}
            if(attack.IsDestroy||attack.IsCopy){result.Fail("Use primary action to paint this wire.");return true;}
            if(attack.SourceItem is Tool tool&&!tool.OnOff){result.Fail("Turn the spray gun on first.");return true;}
            var material=sprayer.GetPaintMaterial();
            if(material==null||sprayer.IsEmpty){result.Fail("Not enough spray paint.");return true;}
            var swatch=GameManager.GetColorSwatch(material);
            if(swatch==null||!GameManager.IsValidColor(swatch.Index)){result.Fail("Unsupported paint color.");return true;}
            if((int)WireColor(wire)==swatch.Index){result.Fail("Wire already has this color.");return true;}
            if(doAction&&GameManager.RunSimulation)
            {
                if(!sprayer.OnUseItem(sprayer.GetUseAmount(),Owner)){result.Fail("Could not use spray paint.");return true;}
                wire.ColorIndex=swatch.Index;
                if(wireRenderers.TryGetValue(wire,out var renderer)&&renderer!=null)Color(renderer,WireColor(wire));
                Owner.NetworkUpdateFlags|=UpdateFlag;
            }
            return true;
        }
    }
}
