using System.Linq;
using System.Collections.Generic;
using Assets.Scripts.Objects;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class FittedKitBounds
    {
        internal static void Install(MultiConstructor kit,Bounds bounds)
        {
            // A single convex envelope suits a carried/stacked Rigidbody kit.
            // Fit the actual package, keeping identity, quantity and hand poses.
            var triggers=kit.GetComponentsInChildren<Collider>(true).Where(c=>c.isTrigger).ToList();
            foreach(var old in kit.GetComponentsInChildren<Collider>(true).Where(c=>!c.isTrigger))
            {Thing._colliderLookup.Remove(old);Object.DestroyImmediate(old);}
            var hit=kit.gameObject.AddComponent<BoxCollider>();hit.center=bounds.center;hit.size=bounds.size;
            triggers.Add(hit);kit.Bounds=bounds;kit._selfColliders=new List<Collider>(triggers);kit._dynamicColliders=new List<Collider>(triggers);kit._staticColliders=new List<Collider>();Thing._colliderLookup[hit]=kit;
        }
        internal static void AfterSelection(Thing __instance,ref SelectionInstance __result)
        {
            if(!SwitchboardKitModel.IsKit(__instance)||__instance.Blueprint==null)return;
            var mesh=__instance.Blueprint.GetComponent<MeshFilter>()?.sharedMesh;if(mesh==null)return;
            var scale=__instance.transform.lossyScale;var bounds=mesh.bounds;
            __result.Bounds=new Bounds(Vector3.Scale(bounds.center,scale),Vector3.Scale(bounds.size,new Vector3(Mathf.Abs(scale.x),Mathf.Abs(scale.y),Mathf.Abs(scale.z))));
        }
    }
}
