using Assets.Scripts.Objects;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class PaintEmission
    {
        // A cloned native prefab can retain emission when its existing paint
        // index matches the restored colour. Physical paint is non-emissive;
        // live door lamps/screens own separate materials and are excluded.
        internal static void Normalize(Thing owner)
        {
            if(owner is SwitchboardCabinet||owner is InnerCoverModule||owner is PortableCoverItem||owner is DinRail||owner is DinTransformer||owner is SmartModule||owner is SmartContactor||owner is SwitchboardLabel||owner is DoorLabel||owner is EmergencyStopLabel||owner is DinBreaker part&&!part.IsDoorPart||SwitchboardKitModel.IsKit(owner))
                owner.EmissionColor=Color.black;
        }
    }
}
