using System;
using System.Collections.Generic;
using System.Linq;
using Assets.Scripts.Networks;
using Assets.Scripts.Objects.Items;
using Assets.Scripts.Objects.Pipes;
namespace ModularSwitchboards
{
    // Source and physical-path reservations shared by collecting and distributing cabinets.
    internal sealed class CabinetCombinerPower
    {
        private sealed class Source {internal CableNetwork Network;internal BatteryCell Cell;internal CabinetWireEnd End;internal object Key=>(object)Cell??Network;internal float Available=>WireCircuit.Finite(Cell!=null?Cell.PowerStored:Network?.PotentialLoad??0);}
        private sealed class Part {internal Source Source;internal long[] Path;internal float Energy,Paid,RecordedPaid;}
        private sealed class Offer {internal readonly List<Part> Parts=new List<Part>();internal int Revision;internal CableNetwork Network;internal int Channel;internal bool Consumed;internal float Total=>(float)Math.Min(float.MaxValue/4,(double)Parts.Sum(p=>(double)p.Energy));}
        private sealed class Own {internal long Id;internal float Watts;internal Offer Offer;}
        private readonly object gate=new object();
        private readonly List<Source> sources=new List<Source>();
        private readonly Dictionary<object,float> spent=new Dictionary<object,float>();
        private readonly Dictionary<CableNetwork,float> debt=new Dictionary<CableNetwork,float>();
        private readonly Dictionary<CableNetwork,Offer> charges=new Dictionary<CableNetwork,Offer>();
        private readonly Dictionary<long,float> chargedThisTick=new Dictionary<long,float>();
        private readonly Dictionary<long,float[]> loads=new Dictionary<long,float[]>();
        private readonly HashSet<long> trips=new HashSet<long>(),ready=new HashSet<long>();
        private readonly WireCircuitGraph graph=new WireCircuitGraph();private WireCircuitPaths paths;private readonly CabinetFlowPaths flow=new CabinetFlowPaths();
        private Dictionary<long,float> limits=new Dictionary<long,float>(),transfer=new Dictionary<long,float>();
        private CabinetPowerNode[] nodes=new CabinetPowerNode[0];
        private Dictionary<CableNetwork,CabinetWireEnd[]> outputs=new Dictionary<CableNetwork,CabinetWireEnd[]>();private readonly Dictionary<CableNetwork,Offer> outputOffers=new Dictionary<CableNetwork,Offer>();private readonly List<Own> own=new List<Own>();
        private bool ticking,stopped;private int revision;private string topology="";
        internal CabinetCombinerPower(){CabinetCombinerTick.Register(this);}
        private IEnumerable<Offer> Offers=>own.Select(o=>o.Offer).Concat(charges.Values).Concat(outputOffers.Values);
        private IEnumerable<Part> Parts=>Offers.SelectMany(o=>o.Parts);
        private IEnumerable<Part> PendingParts=>Offers.Where(o=>!o.Consumed).SelectMany(o=>o.Parts);
        internal void RefreshNodes(SwitchboardCabinet owner,IList<CabinetWireSaveData> wires,CabinetPowerNode[] modules)
        {
            lock(gate)
            {
                nodes=modules;flow.Update(wires,modules);var nextSources=new List<Source>();var nextOutputs=new Dictionary<CableNetwork,CabinetWireEnd[]>();
                if(owner.IsStructureCompleted&&!owner.IsCursor&&owner.GridController!=null)
                {
                    foreach(int contact in owner.InputContacts){var network=owner.InputPort(contact)?.GetCable()?.CableNetwork;if(network!=null)nextSources.Add(new Source{Network=network,End=new CabinetWireEnd(0,contact)});}
                    foreach(var cell in modules.Where(m=>m.Conducting&&m.IsBatteryModule&&m.Battery!=null))nextSources.Add(new Source{Cell=cell.Battery,End=new CabinetWireEnd(cell.ReferenceId,1)});
                    var ports=new[]{owner.Output1Connection,owner.Output2Connection,owner.Output3Connection};
                    for(int i=0;i<ports.Length;i++)
                    {
                        var net=ports[i]?.GetCable()?.CableNetwork;
                        if(net==null||nextSources.Any(source=>ReferenceEquals(source.Network,net)))continue;
                        var ends=nextOutputs.TryGetValue(net,out var previous)?previous: new CabinetWireEnd[0];
                        nextOutputs[net]=ends.Concat(new[]{new CabinetWireEnd(0,i+1)}).ToArray();
                    }
                }
                if(paths==null)paths=new WireCircuitPaths(graph);
                var closed=modules.Where(m=>m.Conducting).ToArray();paths.Update(wires,closed.Select(m=>m.ReferenceId).ToArray(),closed.Where(m=>!m.IsBatteryModule).Select(m=>m.ReferenceId).ToArray());
                limits=modules.Where(m=>!m.IsContactor&&!m.IsTransformer&&!m.IsBatteryModule&&!m.IsAnalyserModule&&!m.IsDoorPart).ToDictionary(m=>m.ReferenceId,m=>WireCircuit.Finite(m.RatedWatts));
                transfer=modules.Where(m=>m.IsTransformer).ToDictionary(m=>m.ReferenceId,m=>WireCircuit.Finite(m.TransferLimit));
                string signature=string.Join(";",wires.Select(w=>w.From.Owner+"/"+w.From.Contact+">"+w.To.Owner+"/"+w.To.Contact))+":"+string.Join(",",closed.Select(m=>m.ReferenceId))+":"+string.Join(",",modules.Where(m=>m.IsTransformer).Select(m=>m.ReferenceId+"/"+m.TransferLimit+"/"+m.OwnWatts+"/"+m.ServiceEnabled));
                bool changed=signature!=topology||outputs.Count!=nextOutputs.Count||outputs.Any(pair=>!nextOutputs.TryGetValue(pair.Key,out var ends)||!pair.Value.SequenceEqual(ends))||sources.Count!=nextSources.Count||sources.Where((s,i)=>i<nextSources.Count&&(!ReferenceEquals(s.Key,nextSources[i].Key)||!s.End.Equals(nextSources[i].End))).Any();
                if(changed){revision++;topology=signature;loads.Clear();}
                sources.Clear();sources.AddRange(nextSources);outputs=nextOutputs;
                ready.RemoveWhere(id=>!modules.Any(m=>m.ReferenceId==id&&m.IsTransformer&&m.ServiceEnabled));
            }
        }
        private float Recorded(long id)=>loads.TryGetValue(id,out var v)?v.Sum():0;
        private float Reserved(object key,IEnumerable<Part> local)=>(spent.TryGetValue(key,out float paid)?paid:0)+Parts.Concat(local).Where(p=>ReferenceEquals(p.Source.Key,key)).Sum(p=>Math.Max(0,p.Energy-p.RecordedPaid));
        private void Spend(object key,float value){if(key==null||value<=0)return;spent.TryGetValue(key,out float previous);spent[key]=previous+value;}
        private float PathRemaining(long[] path,IEnumerable<Part> local)
        {
            float left=float.MaxValue/4;
            foreach(long id in path)if(transfer.TryGetValue(id,out float limit))left=Math.Min(left,Math.Max(0,limit-Recorded(id)-PendingParts.Concat(local).Where(p=>p.Path.Contains(id)).Sum(p=>Math.Max(0,p.Energy-p.RecordedPaid))));
            return left;
        }
        private bool PathReady(long[] path)=>path.All(id=>!nodes.Any(m=>m.ReferenceId==id&&m.IsTransformer&&m.OwnWatts>0)||ready.Contains(id)&&(!ticking||!own.Any(o=>o.Id==id&&o.Offer.Total+.00001f<o.Watts)));
        private Offer Plan(CabinetWireEnd target,float ceiling,CableNetwork only=null,bool externalOnly=false)
        {
            var offer=new Offer{Revision=revision};
            for(int phase=0;phase<(externalOnly?1:2);phase++)
            {
            var candidates=sources.Where(s=>(phase==0?s.Network!=null:s.Cell!=null)&&(only==null||ReferenceEquals(s.Network,only))&&graph.Reachable(s.End,target))
                .SelectMany(s=>flow.Paths(s.End,target).Select(path=>new Part{Source=s,Path=path})).Where(p=>PathReady(p.Path)).ToArray();
            // Progressive filling shares each real network once, even when wired
            // into multiple IN sockets, and each common transformer rating once.
            for(int pass=0;pass<=candidates.Length+transfer.Count+1;pass++)
            {
                var active=candidates.Where(p=>p.Source.Available-Reserved(p.Source.Key,offer.Parts)>.00001f&&PathRemaining(p.Path,offer.Parts)>.00001f).ToArray();
                if(active.Length==0||offer.Total>=ceiling-.00001f)break;
                float step=(ceiling-offer.Total)/active.Length;
                foreach(var p in active)step=Math.Min(step,(p.Source.Available-Reserved(p.Source.Key,offer.Parts))/active.Count(q=>ReferenceEquals(q.Source.Key,p.Source.Key)));
                foreach(var limit in transfer) {int count=active.Count(p=>p.Path.Contains(limit.Key));if(count>0)step=Math.Min(step,Math.Max(0,limit.Value-Recorded(limit.Key)-Parts.Concat(offer.Parts).Where(p=>p.Path.Contains(limit.Key)).Sum(p=>p.Energy))/count);}
                if(step<=.000001f)break;
                foreach(var p in active){var existing=offer.Parts.FirstOrDefault(q=>ReferenceEquals(q.Source,p.Source)&&ReferenceEquals(q.Path,p.Path));if(existing==null){existing=new Part{Source=p.Source,Path=p.Path};offer.Parts.Add(existing);}existing.Energy+=step;}
            }
            }
            return offer;
        }
        private void AddLoad(long[] path,int channel,float amount){foreach(long id in path){if(!loads.TryGetValue(id,out var v))loads[id]=v=new float[5];v[channel]+=amount;}}
        private void CheckTrips(){foreach(var p in loads)if(limits.TryGetValue(p.Key,out float max)&&p.Value.Sum()>max)trips.Add(p.Key);}
        private void AddDebt(CableNetwork network,float amount){if(network==null||amount<=0)return;debt.TryGetValue(network,out float old);debt[network]=Math.Min(float.MaxValue/4,old+amount);}
        private sealed class Route {internal Offer Offer;internal Part Part;internal float Weight;}
        private void PlanOutputs()
        {
            int channel=0;
            foreach(var net in outputs.Keys)outputOffers[net]=new Offer{Network=net,Revision=revision,Channel=channel++};
            // Demand first, then spare headroom. Each real source and transformer
            // is a shared resource across ALL output networks and parallel paths.
            for(int phase=0;phase<2;phase++)for(int demandPass=0;demandPass<2;demandPass++)
            {
                var routes=outputs.SelectMany(pair=>sources.Where(source=>phase==0?source.Network!=null:source.Cell!=null)
                    .SelectMany(source=>pair.Value.SelectMany(target=>flow.Paths(source.End,target))
                    .Where(PathReady).Select(path=>new Route{Offer=outputOffers[pair.Key],Part=new Part{Source=source,Path=path}}))).ToArray();
                for(int pass=0;pass<routes.Length+transfer.Count+outputs.Count+2;pass++)
                {
                    var active=routes.Where(route=>route.Part.Source.Available-Reserved(route.Part.Source.Key,Enumerable.Empty<Part>())>.00001f&&PathRemaining(route.Part.Path,Enumerable.Empty<Part>())>.00001f
                        &&(demandPass!=0||WireCircuit.Finite(route.Offer.Network.RequiredLoad)-route.Offer.Total>.00001f)).ToArray();
                    if(active.Length==0)break;
                    foreach(var route in active)route.Weight=(demandPass==0?Math.Max(0,WireCircuit.Finite(route.Offer.Network.RequiredLoad)-route.Offer.Total):1f)/active.Count(other=>ReferenceEquals(other.Offer,route.Offer));
                    float step=float.MaxValue/4;
                    foreach(var route in active)
                    {
                        var key=route.Part.Source.Key;
                        step=Math.Min(step,Math.Max(0,route.Part.Source.Available-Reserved(key,Enumerable.Empty<Part>()))/active.Where(other=>ReferenceEquals(other.Part.Source.Key,key)).Sum(other=>other.Weight));
                        if(demandPass==0)step=Math.Min(step,1f);
                    }
                    foreach(var limit in transfer)
                    {
                        float weight=active.Where(route=>route.Part.Path.Contains(limit.Key)).Sum(route=>route.Weight);
                        if(weight>0)step=Math.Min(step,Math.Max(0,limit.Value-Recorded(limit.Key)-PendingParts.Where(part=>part.Path.Contains(limit.Key)).Sum(part=>Math.Max(0,part.Energy-part.RecordedPaid)))/weight);
                    }
                    if(step<=.000001f)break;
                    foreach(var route in active)
                    {
                        var part=route.Offer.Parts.FirstOrDefault(p=>ReferenceEquals(p.Source,route.Part.Source)&&ReferenceEquals(p.Path,route.Part.Path));
                        if(part==null){part=route.Part;route.Offer.Parts.Add(part);}part.Energy+=step*route.Weight;
                    }
                }
            }
        }
        internal float Generated(CableNetwork network)
        {
            lock(gate)
            {
                if(stopped||network==null||!outputs.ContainsKey(network))return 0;
                if(outputOffers.Count==0)PlanOutputs();
                return outputOffers.TryGetValue(network,out var offer)&&!offer.Consumed&&offer.Revision==revision?offer.Total:0;
            }
        }
        internal void Use(CableNetwork network,float amount)
        {
            lock(gate)
            {
                if(network==null||!outputOffers.TryGetValue(network,out var offer)||offer.Consumed)return;
                amount=WireCircuit.Finite(amount);float total=offer.Total;
                float externalTotal=offer.Parts.Where(p=>p.Source.Network!=null).Sum(p=>p.Energy);
                float externalUse=Math.Min(amount,externalTotal),cellUse=Math.Max(0,amount-externalUse);
                float cellTotal=offer.Parts.Where(p=>p.Source.Cell!=null).Sum(p=>p.Energy);
                if(total>0)foreach(var part in offer.Parts)
                {
                    float used;
                    if(part.Source.Cell!=null){used=cellTotal>0?cellUse*(part.Energy/cellTotal):0;used=Math.Min(used,WireCircuit.Finite(part.Source.Cell.PowerStored));part.Source.Cell.PowerStored-=used;}
                    else{used=externalTotal>0?externalUse*(part.Energy/externalTotal):0;AddDebt(part.Source.Network,used);}
                    AddLoad(part.Path,offer.Channel,used);part.Energy=used;
                }
                offer.Consumed=true;CheckTrips();
            }
        }
        internal float Used(CableNetwork network)
        {
            lock(gate)
            {
                if(stopped||network==null)return 0;debt.TryGetValue(network,out float pending);
                float standby=own.SelectMany(o=>o.Offer.Parts).Where(p=>ReferenceEquals(p.Source.Network,network)).Sum(p=>Math.Max(0,p.Energy-p.Paid));
                if(!charges.TryGetValue(network,out var charge))
                {
                    charge=new Offer{Revision=revision};charges[network]=charge;
                    foreach(var cell in nodes.Where(m=>m.IsBatteryModule&&m.Conducting&&m.Battery!=null))
                    {
                        chargedThisTick.TryGetValue(cell.ReferenceId,out float charged);
                        float reserved=charged+charges.Values.SelectMany(o=>o.Parts).Where(p=>p.Source.End.Owner==cell.ReferenceId).Sum(p=>Math.Max(0,p.Energy-p.Paid));
                        var planned=Plan(new CabinetWireEnd(cell.ReferenceId,0),Math.Max(0,Math.Min(1000f,WireCircuit.Finite(cell.Battery.PowerDelta))-reserved),network,true);
                        foreach(var p in planned.Parts){p.Source=new Source{Network=p.Source.Network,Cell=null,End=new CabinetWireEnd(cell.ReferenceId,0)};charge.Parts.Add(p);}
                    }
                }
                return pending+standby+charge.Parts.Sum(p=>Math.Max(0,p.Energy-p.Paid));
            }
        }
        internal void Receive(CableNetwork network,float amount)
        {
            lock(gate)
            {
                if(network==null)return;amount=WireCircuit.Finite(amount);debt.TryGetValue(network,out float pending);float paid=Math.Min(amount,pending);debt[network]=pending-paid;amount-=paid;
                foreach(var p in own.SelectMany(o=>o.Offer.Parts).Where(p=>ReferenceEquals(p.Source.Network,network))){paid=Math.Min(amount,Math.Max(0,p.Energy-p.Paid));p.Paid+=paid;amount-=paid;}
                if(charges.TryGetValue(network,out var charge))foreach(var p in charge.Parts)
                {
                    var cell=nodes.FirstOrDefault(m=>m.ReferenceId==p.Source.End.Owner)?.Battery;if(cell==null)continue;
                    paid=Math.Min(amount,Math.Min(Math.Max(0,p.Energy-p.Paid),WireCircuit.Finite(cell.PowerDelta)));cell.PowerStored+=paid;p.Paid+=paid;amount-=paid;chargedThisTick.TryGetValue(p.Source.End.Owner,out float previousCharge);chargedThisTick[p.Source.End.Owner]=previousCharge+paid;AddLoad(p.Path,4,paid);p.RecordedPaid+=paid;Spend(network,paid);
                }
                if(charges.TryGetValue(network,out var pendingCharge)&&pendingCharge.Parts.All(part=>part.Paid+.00001f>=part.Energy))charges.Remove(network);CheckTrips();
            }
        }
        internal void BeginOwnTick()
        {
            lock(gate)
            {
                if(stopped||ticking)return;ticking=true;outputOffers.Clear();charges.Clear();own.Clear();loads.Clear();chargedThisTick.Clear();spent.Clear();
                var consumers=nodes.Where(m=>m.IsTransformer&&m.ServiceEnabled&&WireCircuit.Finite(m.OwnWatts)>0).OrderBy(m=>sources.Where(s=>graph.Reachable(s.End,new CabinetWireEnd(m.ReferenceId,0))).Select(s=>paths.Path(s.End,new CabinetWireEnd(m.ReferenceId,0)).Length).DefaultIfEmpty(int.MaxValue).Min()).ToArray();
                foreach(var m in consumers)own.Add(new Own{Id=m.ReferenceId,Watts=WireCircuit.Finite(m.OwnWatts),Offer=Plan(new CabinetWireEnd(m.ReferenceId,0),WireCircuit.Finite(m.OwnWatts))});
            }
        }
        internal void EndOwnTick()
        {
            lock(gate)
            {
                if(!ticking)return;ready.Clear();foreach(var load in own)
                {
                    float paid=0;foreach(var p in load.Offer.Parts)
                    {
                        float used=p.Paid;if(p.Source.Cell!=null){used=Math.Min(p.Energy,WireCircuit.Finite(p.Source.Cell.PowerStored));p.Source.Cell.PowerStored-=used;}
                        paid+=used;if(p.Source.Network!=null)Spend(p.Source.Key,used);AddLoad(p.Path,3,used);
                    }
                    if(paid+.00001f>=load.Watts)ready.Add(load.Id);
                }
                own.Clear();charges.Clear();ticking=false;CheckTrips();
            }
        }
        internal bool TransformerPowered(long id){lock(gate)return !stopped&&ready.Contains(id);}
        internal void RemoveOwnTransformer(long id){lock(gate){ready.Remove(id);foreach(var use in own.Where(o=>o.Id==id))foreach(var part in use.Offer.Parts){Spend(part.Source.Network,part.Paid);AddLoad(part.Path,3,part.Paid);}own.RemoveAll(o=>o.Id==id);nodes=nodes.Where(m=>m.ReferenceId!=id).ToArray();transfer[id]=0;revision++;CheckTrips();}}
        internal void StopOwnPower(){lock(gate){stopped=true;own.Clear();charges.Clear();outputOffers.Clear();ready.Clear();}CabinetCombinerTick.Remove(this);}
        internal void ObserveIdle(CableNetwork network){lock(gate){if(network!=null&&outputOffers.TryGetValue(network,out var idle)&&!idle.Consumed){idle.Consumed=true;idle.Parts.Clear();}if(network!=null)charges.Remove(network);}}
        internal long[] DrainTrips(){lock(gate){var result=trips.ToArray();trips.Clear();return result;}}
        internal bool AllowsPower(CableNetwork network){lock(gate)return network!=null&&(sources.Any(s=>ReferenceEquals(s.Network,network))||debt.TryGetValue(network,out float pending)&&pending>0);}
        internal bool IsProviderTo(Device self,Device other,ref List<long> visited)
        {
            CableNetwork[] nets;lock(gate)nets=sources.Where(s=>s.Network!=null).Select(s=>s.Network).Distinct().ToArray();
            if(other==null||visited.Contains(self.ReferenceId))return false;visited.Add(self.ReferenceId);
            foreach(var net in nets){var providers=net.PowerTick?.InputOutputDevices;if(providers==null)continue;if(providers.Any(p=>p?.Device==other))return true;foreach(var p in providers){if(p?.Device==null)continue;if(visited.Count>=Device.MaxProviderRecursionIterations)return false;if(p.Device.IsProviderToDevice(other,ref visited))return true;}}return false;
        }
    }
}
