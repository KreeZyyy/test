using System;
using System.Collections.Generic;
using UnityEngine;
using Assets.Scripts.Objects;
namespace ModularSwitchboards
{
    // Independent procedural geometry for each cable type; no native cable UV atlas.
    internal static class WireVisualGenerator
    {
        private static Material blackMaterial,sleeveMaterial;
        private static Material SleeveMaterial
        {
            get
            {
                if(sleeveMaterial!=null)return sleeveMaterial;
                var shader=Shader.Find("Standard")??Shader.Find("Unlit/Color");
                if(shader==null)throw new InvalidOperationException("Wire sleeve shader unavailable");
                sleeveMaterial=new Material(shader){name="Switchboards.WireSleeve.Silver",color=new Color(.48f,.50f,.52f,1)};
                if(sleeveMaterial.HasProperty("_Metallic"))sleeveMaterial.SetFloat("_Metallic",.65f);
                if(sleeveMaterial.HasProperty("_Glossiness"))sleeveMaterial.SetFloat("_Glossiness",.3f);
                return sleeveMaterial;
            }
        }
        private static Material BlackMaterial
        {
            get
            {
                if(blackMaterial!=null)return blackMaterial;
                var shader=Shader.Find("Standard")??Shader.Find("Unlit/Color");
                if(shader==null)throw new InvalidOperationException("Black wire marking shader unavailable");
                blackMaterial=new Material(shader){name="Switchboards.WireMarking.Black",color=Color.black};
                CabinetMatteSurface.Configure(blackMaterial);return blackMaterial;
            }
        }
        internal static void Surface(MeshRenderer renderer,CabinetWireKind kind)
        {
            WireVisualLighting.Apply(renderer);
            var material=CabinetGeometry.Materials[3];
            renderer.sharedMaterials=kind==CabinetWireKind.Normal?new[]{material}:new[]{material,BlackMaterial};
            CabinetMatteSurface.Apply(renderer);
            if(kind==CabinetWireKind.SuperHeavy){var surfaces=renderer.sharedMaterials;renderer.sharedMaterials=new[]{surfaces[0],surfaces[1],SleeveMaterial};}
            if(kind==CabinetWireKind.Normal)return;
            var black=new MaterialPropertyBlock();black.SetColor("_Color",UnityEngine.Color.black);black.SetColor(Thing.EMISSION_COLOR,UnityEngine.Color.black);
            renderer.SetPropertyBlock(black,1);
            if(kind==CabinetWireKind.SuperHeavy){var sleeve=new MaterialPropertyBlock();sleeve.SetColor("_Color",new Color(.48f,.50f,.52f,1));sleeve.SetColor(Thing.EMISSION_COLOR,Color.black);renderer.SetPropertyBlock(sleeve,2);}
        }
        internal static Mesh Build(WirePoint[] path,CabinetWireKind kind)
        {
            var profile=WireVisualProfiles.Get(kind);
            var layout=WireMarkings.Plan(WireTube.Supports(path),kind);path=layout.Points;var distances=layout.Distances;
            var v=new List<Vector3>();var normals=new List<Vector3>();int sides=profile.Sides;
            var groups=new List<int>[profile.Materials];for(int i=0;i<groups.Length;i++)groups[i]=new List<int>();
            var right=new WirePoint();var tangent=new WirePoint();
            for(int i=0;i<path.Length;i++)
            {
                var p=CabinetWiring.Vector(path[i]);var ring=WireTube.Ring(path,i,sides,ref right,ref tangent);
                for(int k=0;k<sides;k++){var n=CabinetWiring.Vector(WireVisualProfiles.Direction(kind,ring[k],tangent,distances[i]));v.Add(p+n*WireVisualProfiles.Radius(kind,k,distances[i],layout));normals.Add(n);}
                if(i>0)for(int k=0;k<sides;k++){var target=groups[WireVisualProfiles.Surface(kind,k,(distances[i-1]+distances[i])*.5f,layout)];int a=(i-1)*sides+k,b=(i-1)*sides+(k+1)%sides,c=i*sides+k,d=i*sides+(k+1)%sides;target.AddRange(new[]{a,b,c,b,d,c});}
            }
            // Small flat end caps are buried in their contacts.
            for(int k=1;k<sides-1;k++){groups[kind==CabinetWireKind.SuperHeavy?2:0].AddRange(new[]{0,k+1,k});int n=(path.Length-1)*sides;groups[kind==CabinetWireKind.SuperHeavy?2:0].AddRange(new[]{n,n+k,n+k+1});}
            var mesh=new Mesh{name="Switchboards.InternalWire"};if(v.Count>65535)mesh.indexFormat=UnityEngine.Rendering.IndexFormat.UInt32;mesh.SetVertices(v);mesh.SetNormals(normals);mesh.subMeshCount=groups.Length;for(int i=0;i<groups.Length;i++)mesh.SetTriangles(groups[i],i);CabinetGeometry.ApplyNativeUv(mesh);mesh.RecalculateBounds();return mesh;
        }
    }
}
