using System.Linq;
using Assets.Scripts.Inventory;
using Assets.Scripts.Objects;
using UnityEngine;
namespace ModularSwitchboards
{
    // Hide only copied real-world renderers, never their shared materials or
    // meshes. forceRenderingOff also survives status scripts toggling enabled.
    public sealed class CursorModelIsolation:MonoBehaviour
    {
        private Structure owner;
        private Renderer[] copied=new Renderer[0];
        internal static void AfterCursorCreated(Thing prefab)
        {
            var cursor=InventoryManager.GetStructureCursor(prefab.name);
            if(cursor==null||!cursor.IsCursor||!OwnPreviewPolicy.Applies(cursor)||cursor.Wireframe?.BlueprintRenderer==null)return;
            var guard=cursor.GetComponent<CursorModelIsolation>()??cursor.gameObject.AddComponent<CursorModelIsolation>();
            guard.owner=cursor;guard.Capture();guard.Hide();
        }
        private void Capture()
        {
            var ghost=owner.Wireframe?.transform;
            copied=owner.GetComponentsInChildren<Renderer>(true).Where(renderer=>
                (ghost==null||!renderer.transform.IsChildOf(ghost))&&
                !IsHelper(renderer.transform)).ToArray();
        }
        private bool IsHelper(Transform node)
        {
            for(var current=node;current!=null&&current!=owner.transform;current=current.parent)
                if(current.gameObject.CompareTag(InventoryManager.HelperTag))return true;
            return false;
        }
        private void Hide(){if(owner==null||!owner.IsCursor)return;foreach(var renderer in copied)if(renderer!=null)renderer.forceRenderingOff=true;}
        private void LateUpdate()=>Hide();
    }
}
