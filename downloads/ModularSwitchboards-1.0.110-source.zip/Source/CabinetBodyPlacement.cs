using System.Collections.Generic;
using Assets.Scripts.Objects;
using Assets.Scripts.Localization2;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class CabinetBodyPlacement
    {
        private static readonly HashSet<SwitchboardCabinet> Registered=new HashSet<SwitchboardCabinet>();
        internal static void Register(SwitchboardCabinet cabinet){if(cabinet!=null&&!cabinet.IsCursor)Registered.Add(cabinet);}
        internal static void Remove(SwitchboardCabinet cabinet)=>Registered.Remove(cabinet);
        private static CabinetVolume Volume(SwitchboardCabinet cabinet)
        {
            var housing=cabinet.transform.Find("SwitchboardModel/CompletedShell/Housing");
            var mesh=housing==null?null:housing.GetComponent<MeshFilter>()?.sharedMesh;
            if(mesh!=null)return new CabinetVolume(mesh.bounds,housing.localToWorldMatrix);
            // Missing/incomplete imported geometry must not allow interpenetration.
            return new CabinetVolume(cabinet.Bounds,cabinet.transform.localToWorldMatrix);
        }
        internal static CanConstructInfo Check(SwitchboardCabinet owner)
        {
            if(owner.GridController==null)return CanConstructInfo.ValidPlacement;
            var volume=Volume(owner);
            foreach(var other in Registered)
            {
                if(other==null||other==owner||other.IsCursor||other.IsBeingDestroyed||other.GridController!=owner.GridController)continue;
                if(volume.Overlaps(Volume(other)))
                    return CanConstructInfo.InvalidPlacement(GameStrings.PlacementBlockedBySmallGrid.AsString(other.DisplayName));
            }
            return CanConstructInfo.ValidPlacement;
        }
    }
}
