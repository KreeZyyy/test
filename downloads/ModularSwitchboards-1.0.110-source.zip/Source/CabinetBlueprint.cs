using Assets.Scripts.UI;
using UnityEngine;
namespace ModularSwitchboards
{
    // Marker is present only on our independent construction blueprints.
    public sealed class CabinetBlueprint:MonoBehaviour
    {
        private void Start()
        {
            var wireframe=GetComponent<Wireframe>();var renderer=wireframe?.BlueprintRenderer??GetComponent<MeshRenderer>();
            if(renderer==null||renderer.GetComponent<PlacementPreviewResources>()!=null)return;
            if(!PlacementOutline.Apply(renderer.gameObject))Debug.LogWarning("[Modular Switchboards] Construction preview style unavailable.");
        }
    }
}
