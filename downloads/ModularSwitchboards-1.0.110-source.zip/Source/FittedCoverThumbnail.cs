using Assets.Scripts.Objects;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class FittedCoverThumbnail
    {
        internal static bool BeforeInstance(Thing __instance,ref Sprite __result)
        {
            if(!(__instance is PortableCoverItem item)||item.State==null)return true;
            __result=item.GetSavedIcon();return false;
        }
        internal static bool BeforeStatic(Thing __0,int __1,ref Sprite __result)
        {
            if(!(__0 is PortableCoverItem item))return true;
            __result=item.State!=null?item.GetSavedIcon():FittedCoverIcons.Get(__1);return false;
        }
    }
}
