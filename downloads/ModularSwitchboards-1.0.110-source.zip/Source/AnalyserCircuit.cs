using System.Collections.Generic;
using System.Linq;
namespace ModularSwitchboards
{
    internal static class AnalyserCircuit
    {
        internal const int Input=4;
        // Classify position relative to protective devices using physical topology,
        // not their ON/OFF state. A trip must not silently change the measured side.
        internal static int Selection(long id,IEnumerable<CabinetWireSaveData> wires,IEnumerable<long> closed,IEnumerable<long> protective,IEnumerable<CabinetWireEnd> inputs=null)
        {
            var list=wires.ToArray();var conducting=closed.ToArray();var protection=protective.ToArray();
            var topology=conducting.Concat(protection).Distinct().ToArray();
            var input=new CabinetWireEnd(0,0);var sensorIn=new CabinetWireEnd(id,0);var sensorOut=new CabinetWireEnd(id,1);
            var feeds=(inputs??new[]{input}).ToArray();
            bool upstream=protection.Any(p=>feeds.Any(feed=>WireCircuit.Reachable(feed,new CabinetWireEnd(p,0),list,topology))&&WireCircuit.Reachable(new CabinetWireEnd(p,1),sensorIn,list,topology));
            bool fromInput=feeds.Any(feed=>WireCircuit.Reachable(feed,sensorIn,list,topology));
            bool outWired=list.Any(w=>w.From.Equals(sensorOut));
            if(!outWired)return fromInput&&!upstream?Input:0;
            bool downstream=protection.Any(p=>WireCircuit.Reachable(sensorOut,new CabinetWireEnd(p,0),list,topology)&&
                (WireCircuit.Reachable(new CabinetWireEnd(p,1),new CabinetWireEnd(0,1),list,topology)||WireCircuit.Reachable(new CabinetWireEnd(p,1),new CabinetWireEnd(0,2),list,topology)||WireCircuit.Reachable(new CabinetWireEnd(p,1),new CabinetWireEnd(0,3),list,topology)));
            if(fromInput&&!upstream&&downstream)return Input;
            // Direct IN -> analyzer -> OUT defaults to the output, as requested.
            return Output(id,list,conducting);
        }
        // Follow the actual downstream wiring, including closed protective devices.
        // A sensor is passive: opening an upstream breaker does not disconnect its
        // downstream cable network or invent a zero reading for that network.
        internal static int Output(long id,IEnumerable<CabinetWireSaveData> wires,IEnumerable<long> closed)
        {
            var start=new CabinetWireEnd(id,1);
            return (WireCircuit.Reachable(start,new CabinetWireEnd(0,1),wires,closed)?1:0)|
                (WireCircuit.Reachable(start,new CabinetWireEnd(0,2),wires,closed)?2:0)|(WireCircuit.Reachable(start,new CabinetWireEnd(0,3),wires,closed)?8:0);
        }
    }
}
