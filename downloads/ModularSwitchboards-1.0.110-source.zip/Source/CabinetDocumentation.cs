namespace ModularSwitchboards
{
    internal static class CabinetDocumentation
    {
        internal static bool Listed(string name)=>name==SwitchboardsMod.CabinetName||name==SwitchboardsMod.MediumCabinetName;
        internal static string Description(string name)
        {
            bool medium=CabinetShape.Medium(name);string size=medium?"Medium":"Small",branches=medium?"3":"2";
            return size+" switchboard family. This description applies to all four versions of this size.\n\n"+
                "Available I/O layouts: 1 IN / "+branches+" OUT, or "+branches+" IN / 1 OUT. Both are available as Basic and Reverse. Choose the actual version from the Switchboard Kit with right-click before construction.\n\n"+
                "Basic distributor: one Input above, Outputs on the opposite side. Basic collector: Inputs occupy those original Output sockets; one Output occupies the original Input socket. Reverse flips the two sides. Internal terminal labels identify every port.\n\n"+
                (medium?"3 DIN rows of 14 positions; double doors. Frame: 3 kits; shell: 5 Plastic Sheets.":"2 DIN rows of 7 positions. Frame: 1 kit; shell: 2 Plastic Sheets.")+" Finish the shell with a Wrench.\n\n"+
                "All versions use the same manual wiring, rails, modules, covers and controls for this size. No built-in connection, overload protection or automatic source transfer. Wire the desired circuits through suitable protection/analyzers/contactors. Collecting Output accepts "+branches+" branch wires; power-module IN and OUT accept three wires each. A1, DATA and Smart Core POWER IN accept one. A branch analyzer can read the whole common Output network.";
        }
    }
}
