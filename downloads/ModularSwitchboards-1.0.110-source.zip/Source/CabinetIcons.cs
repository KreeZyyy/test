using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

namespace ModularSwitchboards
{
    internal static class CabinetIcons
    {
        private static readonly Dictionary<string, Sprite> Cache = new Dictionary<string, Sprite>();
        internal static Sprite Get(string name)
        {
            if (Cache.TryGetValue(name, out var sprite)) return sprite;
            using (var stream = typeof(CabinetIcons).Assembly.GetManifestResourceStream("ModularSwitchboards.Icons." + name + ".png"))
            {
                if (stream == null) throw new InvalidOperationException("Missing custom icon " + name);
                using (var bytes = new MemoryStream())
                {
                    stream.CopyTo(bytes);
                    var texture = new Texture2D(2,2,TextureFormat.RGBA32,false) { name = "Switchboards.Icon."+name };
                    if (!ImageConversion.LoadImage(texture, bytes.ToArray(), name!="InnerCover")) throw new InvalidDataException("Invalid icon " + name);
                    sprite=Sprite.Create(texture,new Rect(0,0,texture.width,texture.height),new Vector2(.5f,.5f),100f);
                    sprite.name="Switchboards."+name;
                    Cache.Add(name,sprite);return sprite;
                }
            }
        }
    }
}
