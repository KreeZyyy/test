using System;
using System.Collections.Generic;
using System.Linq;
using Assets.Scripts.Networks;
namespace ModularSwitchboards
{
    internal sealed partial class CabinetBatteryPower
    {
        private sealed class OwnLoad{internal long Id;internal float Watts;internal bool External;internal long[] Path;}
        private sealed class OwnUse{internal OwnLoad Load;internal Offer Offer;internal float Paid;}
        private readonly List<OwnUse> ownUses=new List<OwnUse>();
        private readonly HashSet<long> ownReady=new HashSet<long>();
        private bool ownTick,ownStopped;
        private CableNetwork ownInput;
        private float ownExternalReserve;
        private IEnumerable<Offer> AllOffers=>offers.Values.Concat(ownUses.Select(u=>u.Offer));
        internal bool TransformerPowered(long id){lock(gate)return !ownStopped&&ownReady.Contains(id);}
        internal void StopOwnPower(){lock(gate){ownStopped=true;ownTick=false;ownUses.Clear();ownReady.Clear();ownExternalReserve=0;RebudgetOwn();}CabinetOwnTick.Remove(this);}
        internal void RemoveOwnTransformer(long id)
        {
            lock(gate)
            {
                ownReady.Remove(id);state.Own=state.Own.Where(l=>l.Id!=id).ToArray();
                foreach(var use in ownUses.Where(u=>u.Load.Id==id).ToArray()){AddLoad(use.Offer.Path,4,use.Paid);ownUses.Remove(use);}
                if(state.TransferLimits.ContainsKey(id))state.TransferLimits[id]=0;
                CheckTrips();RebudgetOwn();
            }
        }
        private bool OwnPathReady(long[] path)
        {
            foreach(long id in path??new long[0])if(state.Own.Any(l=>l.Id==id))
            {
                if(!ownReady.Contains(id))return false;
                var planned=ownUses.FirstOrDefault(u=>u.Load.Id==id);
                if(planned!=null&&planned.Offer.Total+.00001f<planned.Load.Watts)return false;
            }
            return true;
        }
        // Called once before ALL native CableNetwork ticks. Query methods never
        // drain cells or create their own repeated standby charges.
        internal void BeginOwnTick()
        {
            lock(gate)
            {
                if(ownStopped||ownTick||state.Own.Length==0)return;
                ownTick=true;ownInput=state.Input;ownUses.Clear();ownExternalReserve=0;
                // A previous native cycle has already applied or released every
                // provider. Drop speculative UI queries, not in-flight native offers.
                offers.Clear();for(int i=0;i<5;i++)ClearLoad(i);
                int depth(OwnLoad l){var paths=state.Cells.Where(c=>c.OwnPaths.ContainsKey(l.Id)).Select(c=>c.OwnPaths[l.Id].Length).ToList();if(l.External)paths.Add(l.Path.Length);return paths.Count==0?int.MaxValue:paths.Min();}
                foreach(var load in state.Own.OrderBy(depth).ThenBy(l=>l.Id))
                {
                    var offer=new Offer{Branch=4,Revision=revision,Path=load.Path??new long[0]};
                    if(load.External&&OwnPathReady(load.Path))
                    {
                        float available=Math.Max(0,WireCircuit.Finite(state.Input?.PotentialLoad??0)-AllOffers.Sum(o=>o.External));
                        offer.External=Math.Min(load.Watts,Math.Min(available,TransferRemaining(load.Path)));
                    }
                    foreach(var cell in state.Cells)
                    {
                        float need=Math.Max(0,load.Watts-offer.Total);if(need<=0)break;
                        if(!cell.OwnPaths.TryGetValue(load.Id,out var path)||!OwnPathReady(path))continue;
                        float reserved=AllOffers.Sum(o=>o.Cells.Where(c=>ReferenceEquals(c.Source.Cell,cell.Cell)).Sum(c=>c.Energy))+offer.Cells.Where(c=>ReferenceEquals(c.Source.Cell,cell.Cell)).Sum(c=>c.Energy);
                        float available=Math.Max(0,WireCircuit.Finite(cell.Cell.PowerStored)-reserved);
                        float amount=Math.Min(need,Math.Min(available,TransferRemaining(path,offer)));
                        if(amount>0)offer.Cells.Add(new Reservation{Source=cell,Energy=amount,Path=path});
                    }
                    ownUses.Add(new OwnUse{Load=load,Offer=offer});ownExternalReserve+=offer.External;
                }
                RebudgetOwn();
            }
        }
        private float OwnPending(CableNetwork network)=>ownTick&&ReferenceEquals(network,ownInput)?ownUses.Sum(u=>Math.Max(0,u.Offer.External-u.Paid)):0;
        private float PayOwn(CableNetwork network,float amount)
        {
            if(!ownTick||!ReferenceEquals(network,ownInput))return amount;
            foreach(var use in ownUses){float paid=Math.Min(amount,Math.Max(0,use.Offer.External-use.Paid));use.Paid+=paid;amount-=paid;if(amount<=0)break;}return amount;
        }
        // Native input ReceivePower paid the external portion. Finish only the
        // reserved battery portion, once per native cycle, and record protection.
        internal void EndOwnTick()
        {
            lock(gate)
            {
                if(!ownTick)return;ownReady.Clear();
                foreach(var use in ownUses)
                {
                    float paid=use.Paid;AddLoad(use.Offer.Path,4,use.Paid);
                    foreach(var c in use.Offer.Cells)
                    {
                        float amount=Math.Min(c.Energy,WireCircuit.Finite(c.Source.Cell.PowerStored));
                        c.Source.Cell.PowerStored-=amount;paid+=amount;AddLoad(c.Path,4,amount);
                    }
                    if(paid+.00001f>=use.Load.Watts)ownReady.Add(use.Load.Id);
                }
                ownUses.Clear();ownTick=false;CheckTrips();RebudgetOwn();
            }
        }
        private Dictionary<long,float> OwnAdjustedLimits()
        {
            var limits=new Dictionary<long,float>(state.TransferLimits);
            foreach(long id in limits.Keys.ToArray())
            {
                if(state.Own.Any(l=>l.Id==id)&&(!ownReady.Contains(id)||ownTick&&ownUses.Any(u=>u.Load.Id==id&&u.Offer.Total+.00001f<u.Load.Watts))){limits[id]=0;continue;}
                float reserved=ownUses.Sum(u=>(u.Offer.Path.Contains(id)?u.Offer.External:0)+u.Offer.Cells.Where(c=>c.Path.Contains(id)).Sum(c=>c.Energy));
                if(loads.TryGetValue(id,out var actual))reserved+=actual[4];
                limits[id]=Math.Max(0,limits[id]-reserved);
            }
            return limits;
        }
        private void RebudgetOwn()
        {
            if(state.Own.Length==0){ownReady.Clear();ownExternalReserve=0;return;}
            ownReady.RemoveWhere(id=>!state.Own.Any(l=>l.Id==id));
            var allocation=TransformerBudget.Allocate(Math.Max(0,WireCircuit.Finite(state.Input?.PotentialLoad??0)-ownExternalReserve),state.Output.Select(n=>n?.RequiredLoad??0).ToArray(),Enumerable.Range(0,3).Select(i=>state.ExternalReachable[i]&&state.Output[i]!=null).ToArray(),state.ExternalPaths,OwnAdjustedLimits());
            for(int i=0;i<3;i++)state.External[i]=allocation[i];
        }
    }
}
