using System;
using System.Collections.Generic;
namespace ModularSwitchboards
{
    // Main-thread topology cache. Never caches supply, demand, charge or energy offers.
    internal sealed class WireCircuitGraph
    {
        private struct Edge
        {
            internal long From,To;internal int FromPin,ToPin;internal bool Burnt;
            internal Edge(CabinetWireSaveData w){From=w.From.Owner;FromPin=w.From.Contact;To=w.To.Owner;ToPin=w.To.Contact;Burnt=w.Burnt;}
            internal bool Matches(CabinetWireSaveData w)=>From==w.From.Owner&&FromPin==w.From.Contact&&To==w.To.Owner&&ToPin==w.To.Contact&&Burnt==w.Burnt;
        }
        private Edge[] saved;
        private long[] closed;
        private readonly Dictionary<CabinetWireEnd,List<CabinetWireEnd>> edges=new Dictionary<CabinetWireEnd,List<CabinetWireEnd>>();
        private readonly Dictionary<CabinetWireEnd,HashSet<CabinetWireEnd>> reachable=new Dictionary<CabinetWireEnd,HashSet<CabinetWireEnd>>();
        internal int Builds{get;private set;}internal int Searches{get;private set;}
        internal bool Update(IList<CabinetWireSaveData> wires,long[] conducting)
        {
            bool same=saved!=null&&saved.Length==wires.Count&&closed.Length==conducting.Length;
            if(same)for(int i=0;i<wires.Count;i++)if(!saved[i].Matches(wires[i])){same=false;break;}
            if(same)for(int i=0;i<closed.Length;i++)if(closed[i]!=conducting[i]){same=false;break;}
            if(same)return false;
            saved=new Edge[wires.Count];closed=(long[])conducting.Clone();edges.Clear();reachable.Clear();Builds++;
            foreach(var id in closed)Add(new CabinetWireEnd(id,0),new CabinetWireEnd(id,1));
            for(int i=0;i<wires.Count;i++)
            {
                var w=wires[i];saved[i]=new Edge(w);if(w.Burnt)continue;
                var a=new CabinetWireEnd(w.From.Owner,w.From.Contact);var b=new CabinetWireEnd(w.To.Owner,w.To.Contact);
                Add(a,b);if(a.IsNeutral&&b.IsNeutral)Add(b,a);
            }
            return true;
        }
        private void Add(CabinetWireEnd from,CabinetWireEnd to)
        {if(!edges.TryGetValue(from,out var list))edges[from]=list=new List<CabinetWireEnd>();list.Add(to);}
        internal bool Reachable(CabinetWireEnd from,CabinetWireEnd to)
        {
            if(!reachable.TryGetValue(from,out var seen))
            {
                Searches++;seen=new HashSet<CabinetWireEnd>();var queue=new Queue<CabinetWireEnd>();queue.Enqueue(from);
                while(queue.Count>0){var n=queue.Dequeue();if(!seen.Add(n))continue;if(edges.TryGetValue(n,out var list))foreach(var next in list)queue.Enqueue(next);}
                reachable[new CabinetWireEnd(from.Owner,from.Contact)]=seen;
            }
            return seen.Contains(to);
        }
    }
}
