using System;
using System.Collections.Generic;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class WireRuptureMesh
    {
        internal const float ScorchLength=.006f;
        internal static Mesh Build(WirePoint[] path,CabinetWireKind kind)
        {
            var profile=WireVisualProfiles.Get(kind);int burn=profile.Materials,metal=burn+1;
            var vertices=new List<Vector3>();var normals=new List<Vector3>();var groups=new List<int>[metal+1];for(int i=0;i<groups.Length;i++)groups[i]=new List<int>();
            var halves=WireDamageShape.Split(path);
            for(int half=0;half<halves.Length;half++)
            {
                var points=halves[half];bool atEnd=half==0;var end=points[atEnd?points.Length-1:0];
                var adjacent=points[atEnd?points.Length-2:1];var delta=end-adjacent;var outward=delta*(1f/(float)Math.Sqrt(delta.Squared));
                var mesh=WireVisualGenerator.Build(points,kind);int offset=vertices.Count;var v=mesh.vertices;
                for(int k=0;k<v.Length;k++){var local=new WirePoint(v[k].x,v[k].y,v[k].z)-end;float axial=WirePoint.Dot(local,outward);if(axial>=-.003f&&axial<=.00001f){float taper=1f-.22f*Math.Max(0,Math.Min(1,(axial+.003f)/.003f));var p=end+outward*axial+(local-outward*axial)*taper;v[k]=new Vector3(p.X,p.Y,p.Z);}}
                vertices.AddRange(v);normals.AddRange(mesh.normals);
                for(int role=0;role<mesh.subMeshCount;role++)
                {
                    var triangles=mesh.GetTriangles(role);
                    for(int i=0;i<triangles.Length;i+=3)
                    {
                        var a=v[triangles[i]];var b=v[triangles[i+1]];var c=v[triangles[i+2]];
                        var centre=new WirePoint((a.x+b.x+c.x)/3,(a.y+b.y+c.y)/3,(a.z+b.z+c.z)/3);
                        var local=centre-end;float axial=WirePoint.Dot(local,outward);float radial=(local-outward*axial).Squared;
                        int target=axial>=-ScorchLength&&axial<=.00001f&&radial<profile.Radius*profile.Radius*4?burn:role;
                        groups[target].Add(offset+triangles[i]);groups[target].Add(offset+triangles[i+1]);groups[target].Add(offset+triangles[i+2]);
                    }
                }
                UnityEngine.Object.Destroy(mesh);
                // Three separately bent exposed conductors; opposite ends remain apart.
                var axis=Math.Abs(outward.Z)<.9f?new WirePoint(0,0,1):new WirePoint(0,1,0);
                var right=Cross(outward,axis);right=right*(1f/(float)Math.Sqrt(right.Squared));var up=Cross(outward,right);
                for(int strand=0;strand<3;strand++)
                {
                    float angle=(float)(strand*Math.PI*2/3);var radial=right*(float)Math.Cos(angle)+up*(float)Math.Sin(angle);
                    float length=.003f+strand*.0007f;float radius=profile.Radius*.13f;int start=vertices.Count;
                    for(int ring=0;ring<3;ring++)for(int side=0;side<8;side++)
                    {
                        float t=ring*.5f,theta=(float)(side*Math.PI*2/8);var n=right*(float)Math.Cos(theta)+up*(float)Math.Sin(theta);
                        var p=end+radial*(profile.Radius*(.35f+.16f*t*t))+outward*(length*t)+n*radius;
                        vertices.Add(new Vector3(p.X,p.Y,p.Z));normals.Add(new Vector3(n.X,n.Y,n.Z));
                    }
                    for(int ring=0;ring<2;ring++)for(int side=0;side<8;side++){int a=start+ring*8+side,b=start+ring*8+(side+1)%8,c=a+8,d=b+8;groups[metal].AddRange(new[]{a,b,c,b,d,c});}
                    for(int side=1;side<7;side++)groups[metal].AddRange(new[]{start+16,start+16+side,start+17+side});
                }
            }
            var result=new Mesh{name="Switchboards.LocalRupture"};result.indexFormat=UnityEngine.Rendering.IndexFormat.UInt32;result.SetVertices(vertices);result.SetNormals(normals);result.subMeshCount=groups.Length;for(int i=0;i<groups.Length;i++)result.SetTriangles(groups[i],i);CabinetGeometry.ApplyNativeUv(result);result.RecalculateBounds();return result;
        }
        internal static Mesh Part(Mesh source,int first,int count)
        {
            var vertices=new List<Vector3>();var normals=new List<Vector3>();var mapping=new Dictionary<int,int>();var groups=new List<int>[count];var sourceVertices=source.vertices;var sourceNormals=source.normals;
            for(int role=0;role<count;role++)
            {
                groups[role]=new List<int>();foreach(int index in source.GetTriangles(first+role))
                {
                    if(!mapping.TryGetValue(index,out int mapped)){mapped=vertices.Count;mapping[index]=mapped;vertices.Add(sourceVertices[index]);normals.Add(sourceNormals[index]);}
                    groups[role].Add(mapped);
                }
            }
            var result=new Mesh{name=first==0?"Switchboards.RupturedInsulation":"Switchboards.ScorchAndConductors"};result.indexFormat=UnityEngine.Rendering.IndexFormat.UInt32;result.SetVertices(vertices);result.SetNormals(normals);result.subMeshCount=count;
            for(int i=0;i<count;i++)result.SetTriangles(groups[i],i);
            CabinetGeometry.ApplyNativeUv(result);result.RecalculateBounds();return result;
        }
        private static WirePoint Cross(WirePoint a,WirePoint b)=>new WirePoint(a.Y*b.Z-a.Z*b.Y,a.Z*b.X-a.X*b.Z,a.X*b.Y-a.Y*b.X);
    }
}
