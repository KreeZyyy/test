using Assets.Scripts;
using Assets.Scripts.Inventory;
using Assets.Scripts.Objects;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class ModelPreviewCursor
    {
        internal static void AfterPlacement()
        {
            var cursor=InventoryManager.ConstructionCursor;
            if(cursor==null||!OwnPreviewPolicy.Applies(cursor))return;
            var renderer=cursor.Wireframe?.BlueprintRenderer;
            if(renderer!=null)renderer.GetComponent<PlacementPreviewResources>()?.FollowValidity(renderer.sharedMaterial.color);
            if(cursor is SwitchboardCabinet)return; // Accepted cabinet bounds/port helpers.
            if(!(InventoryManager.ActiveHandSlot?.Get() is MultiConstructor)&&!InventoryManager.IsAuthoringMode)return;
            var selection=CursorManager.CursorSelectionTransform;if(selection==null)return;
            var bounds=cursor.Wireframe==null?cursor.Bounds:cursor.Wireframe.BlueprintBounds;var scale=cursor.transform.lossyScale;
            selection.position=cursor.transform.TransformPoint(bounds.center);
            selection.rotation=cursor.transform.rotation;
            selection.localScale=Vector3.Scale(bounds.size,new Vector3(Mathf.Abs(scale.x),Mathf.Abs(scale.y),Mathf.Abs(scale.z)));
        }
    }
}
