using System.Collections.Generic;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class MediumTransformerGeometry
    {
        internal const float KnobShift=.025f;
        internal static readonly float[] WindingCenters={.013f,.064f};
        internal static readonly float[] RibCenters={.1145f,.138f};
        internal static readonly Bounds[] Pockets={new Bounds(new Vector3(.013f,0,.0821f),new Vector3(.04874201f,.065f,.0358f)),new Bounds(new Vector3(.064f,0,.0821f),new Vector3(.04874201f,.065f,.0358f))};
        internal static Mesh Face()=>TransformerFrontGeometry.Face(6,.081f);
    }
}
