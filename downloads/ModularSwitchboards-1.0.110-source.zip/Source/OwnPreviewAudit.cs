using Assets.Scripts.Objects;
using Assets.Scripts.UI;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class OwnPreviewAudit
    {
        internal static void Verify()
        {
            int count=0;
            foreach(var thing in Prefab.AllPrefabs)
            {
                if(thing==null||!(thing is Structure structure&&OwnPreviewPolicy.Applies(structure))&&!SwitchboardKitModel.IsKit(thing))continue;
                count++;
                var filter=thing.Blueprint==null?null:thing.Blueprint.GetComponent<MeshFilter>();
                var mesh=filter?.sharedMesh;var wire=thing.Blueprint==null?null:thing.Blueprint.GetComponent<Wireframe>();
                if(mesh==null||mesh.vertexCount==0||wire==null||wire.BlueprintRenderer==null)
                    Debug.LogError("[Modular Switchboards] Preview audit missing model/renderer: "+thing.PrefabName);
                if(thing is Structure body&&OwnPreviewPolicy.FittedBody(body)&&body.GetComponent<FittedModelCollider>()==null)
                    Debug.LogError("[Modular Switchboards] Preview audit missing fitted body hitbox: "+thing.PrefabName);
            }
            Debug.Log("[Modular Switchboards] Preview/hitbox audit checked "+count+" own prefabs (cabinets, DIN, Smart, door parts, covers, labels and kits).");
        }
    }
}
