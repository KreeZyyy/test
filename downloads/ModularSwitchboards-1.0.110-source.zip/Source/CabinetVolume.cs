using UnityEngine;
namespace ModularSwitchboards
{
    // Future housing volume, independent of frame selection colliders and native
    // half-metre occupancy. SAT also handles rolled and opposing wall mounts.
    internal struct CabinetVolume
    {
        internal Vector3 Center,X,Y,Z,Half;
        internal CabinetVolume(Bounds bounds,Matrix4x4 matrix)
        {
            Center=matrix.MultiplyPoint3x4(bounds.center);
            var x=matrix.MultiplyVector(Vector3.right);var y=matrix.MultiplyVector(Vector3.up);var z=matrix.MultiplyVector(Vector3.forward);
            X=x.normalized;Y=y.normalized;Z=z.normalized;Half=Vector3.Scale(bounds.extents,new Vector3(x.magnitude,y.magnitude,z.magnitude));
        }
        private float Radius(Vector3 axis)=>Mathf.Abs(Vector3.Dot(X,axis))*Half.x+Mathf.Abs(Vector3.Dot(Y,axis))*Half.y+Mathf.Abs(Vector3.Dot(Z,axis))*Half.z;
        private bool Apart(CabinetVolume other,Vector3 axis)
        {
            if(axis.sqrMagnitude<1e-10f)return false;
            axis.Normalize();
            return Mathf.Abs(Vector3.Dot(other.Center-Center,axis))>=Radius(axis)+other.Radius(axis)-.0001f;
        }
        internal bool Overlaps(CabinetVolume other)
        {
            // Fast broad phase before the 15 separating axes.
            float reach=Half.magnitude+other.Half.magnitude;
            if((Center-other.Center).sqrMagnitude>reach*reach)return false;
            return !Apart(other,X)&&!Apart(other,Y)&&!Apart(other,Z)&&!Apart(other,other.X)&&!Apart(other,other.Y)&&!Apart(other,other.Z)&&
                !Apart(other,Vector3.Cross(X,other.X))&&!Apart(other,Vector3.Cross(X,other.Y))&&!Apart(other,Vector3.Cross(X,other.Z))&&
                !Apart(other,Vector3.Cross(Y,other.X))&&!Apart(other,Vector3.Cross(Y,other.Y))&&!Apart(other,Vector3.Cross(Y,other.Z))&&
                !Apart(other,Vector3.Cross(Z,other.X))&&!Apart(other,Vector3.Cross(Z,other.Y))&&!Apart(other,Vector3.Cross(Z,other.Z));
        }
    }
}
