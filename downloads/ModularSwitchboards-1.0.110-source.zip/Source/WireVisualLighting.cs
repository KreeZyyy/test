using UnityEngine;
using UnityEngine.Rendering;
namespace ModularSwitchboards
{
    internal static class WireVisualLighting
    {
        internal static void Apply(MeshRenderer renderer)
        {
            // Millimetre cables create unstable, enlarged shadow-map streaks.
            // Retain lighting/received shadows and all insulation/material data.
            renderer.shadowCastingMode=ShadowCastingMode.Off;
            renderer.receiveShadows=true;
        }
    }
}
