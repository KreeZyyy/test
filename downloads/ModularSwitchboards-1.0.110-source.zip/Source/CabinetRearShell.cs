using System;
using System.Collections.Generic;
using UnityEngine;
using Assets.Scripts.Objects;
namespace ModularSwitchboards
{
    internal static class CabinetRearShell
    {
        // Role 1 in Housing is exclusively the integrated native-grey rear body.
        // The protruding APC box is a separate CompletedShell child, not included.
        internal static Mesh Append(Mesh frame,Mesh housing)
        {
            var vertices=new List<Vector3>(frame.vertices);var normals=new List<Vector3>(frame.normals);var uv=new List<Vector2>(frame.uv);
            var groups=new List<int>[frame.subMeshCount];for(int s=0;s<groups.Length;s++)groups[s]=new List<int>(frame.GetTriangles(s));
            var points=housing.vertices;var sourceNormals=housing.normals;var sourceUv=housing.uv;
            var indices=housing.GetTriangles(CabinetRearSurface.Role);
            if(indices.Length==0)throw new InvalidOperationException("Cabinet grey rear shell is empty.");
            var remap=new Dictionary<int,int>();
            foreach(int old in indices)
            {
                if(!remap.TryGetValue(old,out int index))
                {
                    index=vertices.Count;remap.Add(old,index);vertices.Add(points[old]);normals.Add(sourceNormals[old]);uv.Add(sourceUv[old]);
                }
                groups[CabinetRearSurface.Role].Add(index);
            }
            var mesh=new Mesh{name="Switchboards.SkeletonWithGreyRear",indexFormat=UnityEngine.Rendering.IndexFormat.UInt32};mesh.SetVertices(vertices);mesh.SetNormals(normals);mesh.SetUVs(0,uv);mesh.subMeshCount=groups.Length;
            for(int i=0;i<groups.Length;i++)mesh.SetTriangles(groups[i],i);
            mesh.RecalculateTangents();mesh.RecalculateBounds();return mesh;
        }
        internal static void Install(Structure cabinet)
        {
            var model=cabinet.transform.Find("SwitchboardModel");var filter=model.Find("Frame").GetComponent<MeshFilter>();
            var housing=model.Find("CompletedShell/Housing").GetComponent<MeshFilter>().sharedMesh;
            var old=filter.sharedMesh;var mesh=Append(old,housing);filter.sharedMesh=mesh;
            model.Find("ProfiledFrameCollider").GetComponent<MeshCollider>().sharedMesh=mesh;
            var renderer=filter.GetComponent<MeshRenderer>();CabinetRearSurface.Restore(renderer);CabinetMatteSurface.Apply(renderer);
            // The skeleton mesh was built privately immediately before this step.
            // Preview generation runs afterwards and receives the combined mesh.
            UnityEngine.Object.DestroyImmediate(old);
        }
    }
}
