using System.Linq;
using Assets.Scripts;
using Assets.Scripts.GridSystem;
namespace ModularSwitchboards
{
    public sealed partial class CabinetWiring
    {
        private void PlayWireRupture(CabinetWireSaveData wire)
        {
            var frame=WireFrame(wire);var path=Expand(wire.Points);if(frame==null||path.Length<2)return;
            var split=WireDamageShape.Split(path);var position=frame.TransformPoint(Vector(split[0][split[0].Length-1]));
            if(Assets.Scripts.GameManager.RunSimulation&&Owner.GridController!=null)
                WorldManager.Spark(position,20,Owner.GridController.RoomController.GetRoom(Owner.WorldGrid)!=null);
            CabinetWireDamage.Play(position);
        }
        private bool receivedWireState;
        private static string WireIdentity(CabinetWireSaveData wire)=>wire.From.Owner+"/"+wire.From.Contact+">"+wire.To.Owner+"/"+wire.To.Contact;
        private CabinetWirePower wirePower;
        private void RefreshWirePower(DinBreaker[] modules)
        {
            wirePower=new CabinetWirePower(CircuitWires,wires,CabinetCableCoils.Rating);
            Power.RefreshNodes(Owner,wirePower.Graph,modules.Select(CabinetPowerNode.From).Concat(Transformers.Select(t=>t.PowerNode())).Concat(wirePower.Nodes));
        }
        private void ApplyWireTrips(DinBreaker[] modules,long[] ids)
        {
            foreach(long id in ids.Where(id=>id>=0))modules.FirstOrDefault(b=>b.ReferenceId==id)?.Trip();
            if(wirePower==null)return;
            // Like native PowerTick, rupture one overloaded cable per application.
            // Recompute the graph before another cable can fail on the next tick.
            var candidates=ids.Where(id=>id<0&&wirePower.Wires.ContainsKey(id)).Select(id=>wirePower.Wires[id]).Where(w=>wires.Contains(w)&&!w.Burnt).Distinct().ToArray();
            if(candidates.Length==0)return;
            var wire=candidates[UnityEngine.Random.Range(0,candidates.Length)];wire.Burnt=true;
            PlayWireRupture(wire);revision++;routeRevision=-1;rebuild=true;Owner.NetworkUpdateFlags|=UpdateFlag;
        }
    }
}
