using System;
using System.Threading;
using System.Threading.Tasks;
namespace ModularSwitchboards
{
    internal sealed class WireRouteJob:IDisposable
    {
        internal sealed class Result {internal WirePoint[] Points;internal int Slot;internal string Failure;}
        private Task<Result> task;
        private CancellationTokenSource cancellation;
        private int revision;
        private CabinetWireEnd from,to;
        private CabinetWireKind kind;
        internal bool Matches(int version,CabinetWireEnd a,CabinetWireEnd b,CabinetWireKind type)
            =>task!=null&&version==revision&&a.Equals(from)&&b.Equals(to)&&kind==type;
        internal void Start(int version,CabinetWireEnd a,CabinetWireEnd b,CabinetWireKind type,WireRoutePlanner planner)
        {
            Cancel();revision=version;from=new CabinetWireEnd(a.Owner,a.Contact);to=new CabinetWireEnd(b.Owner,b.Contact);kind=type;
            var source=new CancellationTokenSource();cancellation=source;planner.cancellation=source.Token;
            var start=from;var finish=to;
            task=Task.Run(()=>{source.Token.ThrowIfCancellationRequested();var path=planner.MakeRoute(start,finish,out int slot,out string failure,type);return new Result{Points=path,Slot=slot,Failure=failure};},source.Token);
            // Dispose only once the worker has stopped reading its token.
            task.ContinueWith(done=>{if(done.IsFaulted){var observed=done.Exception;}source.Dispose();},TaskScheduler.Default);
        }
        internal bool TryRead(out Result result)
        {
            result=null;if(task==null||!task.IsCompleted)return false;
            if(task.IsCanceled){result=new Result{Failure="Route calculation cancelled."};return true;}
            if(task.IsFaulted){var observed=task.Exception;result=new Result{Failure="Route calculation failed. Select the contacts again."};return true;}
            result=task.Result;return true;
        }
        internal void Cancel()
        {
            try{cancellation?.Cancel();}catch(ObjectDisposedException){}
            cancellation=null;task=null;
        }
        public void Dispose()=>Cancel();
    }
}
