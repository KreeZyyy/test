using System;
namespace ModularSwitchboards
{
    internal sealed class WireVisualProfile
    {
        internal readonly float Radius,CollarLength,TwistPitch;
        internal float JointPitch=>CollarLength>0?.10f:0;
internal readonly int Sides,Materials;
        internal WireVisualProfile(float radius,int sides,int materials,float collar,float twist=0){Radius=radius;Sides=sides;Materials=materials;CollarLength=collar;TwistPitch=twist;}
    }
    internal static class WireVisualProfiles
    {
        private static readonly WireVisualProfile Basic=new WireVisualProfile(.0012f,8,1,0);
        private static readonly WireVisualProfile Heavy=new WireVisualProfile(.0022f,16,2,0,.08f);
        private static readonly WireVisualProfile SuperHeavy=new WireVisualProfile(.0040f,12,3,.004f);
        internal static WireVisualProfile Get(CabinetWireKind kind)=>kind==CabinetWireKind.SuperHeavy?SuperHeavy:kind==CabinetWireKind.Heavy?Heavy:Basic;
        internal static WirePoint Direction(CabinetWireKind kind,WirePoint normal,WirePoint tangent,float distance)
        {
            float pitch=Get(kind).TwistPitch;if(pitch<=0)return normal;
            float angle=(float)(distance/pitch*Math.PI*2);var quarter=new WirePoint(tangent.Y*normal.Z-tangent.Z*normal.Y,tangent.Z*normal.X-tangent.X*normal.Z,tangent.X*normal.Y-tangent.Y*normal.X);
            return normal*(float)Math.Cos(angle)+quarter*(float)Math.Sin(angle);
        }
        internal static int Surface(CabinetWireKind kind,int side,float distance,WireVisualLayout layout)
        {
            if(kind==CabinetWireKind.Normal)return 0;
            if(kind==CabinetWireKind.SuperHeavy&&layout.MetalAt(distance))return 2;
            // Narrow opposite tracks wrap with Heavy geometry; Super channels stay longitudinal.
            return kind==CabinetWireKind.Heavy?(side==3||side==4||side==11||side==12?1:0):(side==2||side==3||side==8||side==9?1:0);
        }
        internal static float Radius(CabinetWireKind kind,int vertex,float distance,WireVisualLayout layout)
        {
            var profile=Get(kind);if(kind!=CabinetWireKind.SuperHeavy)return profile.Radius;
            float blend=Math.Max(0,Math.Min(1,layout.JointGap(distance)/.002f));
            // Native-inspired broad red shoulders and recessed black longitudinal channels.
            float angle=(float)(vertex*Math.PI*2/profile.Sides);
            float channel=.85f+.15f*(float)Math.Cos(angle*2);
            return profile.Radius*(1-blend+blend*channel);
        }
    }
}
