using System;
using System.Linq;
namespace ModularSwitchboards
{
    internal static class WireDamageShape
    {
        internal static WirePoint[][] Split(WirePoint[] path)
        {
            int segment=1;float longest=0;
            for(int i=1;i<path.Length;i++){float length=(path[i]-path[i-1]).Squared;if(length>longest){longest=length;segment=i;}}
            if(longest<1e-12f)return new[]{path};
            float gap=Math.Min(.012f,(float)Math.Sqrt(longest)*.3f);
            var a=path[segment-1];var b=path[segment];var middle=(a+b)*.5f;var direction=(b-a)*(1f/(float)Math.Sqrt(longest));
            return new[]{path.Take(segment).Concat(new[]{middle-direction*(gap*.5f)}).ToArray(),new[]{middle+direction*(gap*.5f)}.Concat(path.Skip(segment)).ToArray()};
        }
    }
}
