using Assets.Scripts;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Items;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class CoverPaint
    {
        internal static Thing.DelayedActionInstance Spray(Thing target,ISprayer sprayer,Attack attack,bool doAction)
            =>SprayCore(target,sprayer,attack.SourceItem,attack.IsDestroy,attack.IsCopy,doAction);
        private static Thing.DelayedActionInstance SprayCore(Thing target,ISprayer sprayer,DynamicThing source,bool destroy,bool copy,bool doAction)
        {
            var result=new Thing.DelayedActionInstance{Duration=sprayer.TimeToUse(),OverrideTitle="Switchboard cover",ActionMessage="Paint cover",ActionSoundHash=sprayer.ConstructingSoundHash,ActionCompleteSoundHash=source is Item item?item.FinishedConstructingSoundHash:-1};
            var mounted=target as InnerCoverModule;var loose=target as PortableCoverItem;
            var state=mounted!=null?mounted.CaptureMemory():loose?.State;
            if(target.IsCursor||target.IsBeingDestroyed||state==null){result.Fail("Cover is not ready.");return result;}
            if(mounted!=null&&(mounted.Host==null||!mounted.Host.CanAccessModules)){result.Fail("Open the cabinet first.");return result;}
            var actor=source?.RootParentHuman;
            if(actor==null||(actor.Transform.position-target.Transform.position).sqrMagnitude>16){result.Fail("Move closer to the cover.");return result;}
            if(destroy||copy){result.Fail("Use primary action to paint the cover.");return result;}
            if(source is Tool tool&&!tool.OnOff){result.Fail("Turn the spray gun on first.");return result;}
            var material=sprayer.GetPaintMaterial();if(material==null||sprayer.IsEmpty){result.Fail("Not enough spray paint.");return result;}
            var colour=GameManager.GetColorSwatch(material);if(colour==null||!GameManager.IsValidColor(colour.Index)){result.Fail("Unsupported paint color.");return result;}
            if(state.Colour==colour.Index){result.Fail("Cover already has this color.");return result;}
            if(doAction&&GameManager.RunSimulation)
            {
                if(!sprayer.OnUseItem(sprayer.GetUseAmount(),target)){result.Fail("Could not use spray paint.");return result;}
                state.Colour=colour.Index;state.FixedColour=true;
                OnServer.SetCustomColor(target,colour.Index);
                if(mounted!=null)mounted.MarkMemoryChanged();else loose.NetworkUpdateFlags|=PortableCoverItem.ColourUpdate;
            }
            return result;
        }
    }
}
