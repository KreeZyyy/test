# Modular Switchboards 1.0.110 — transformer prefab initialization fix

Fix the 1.0.109 startup failure: do not invoke native stage visualization on an unplaced transformer prefab at state -1, and do not rebuild its fitted hitbox while the native state has all children inactive. Explicitly restore shared body, terminals and controls in both placed construction stages. Completed-stage winding visibility and the 1.0.109 recipes/counts remain.

# Modular Switchboards 1.0.109 — cabinet economy and transformer construction

Cabinet kit: 60 Iron + 30 Copper, Electronics Printer only. Small uses 1 kit + 2 Plastic Sheets; Medium uses 3 kits + 5 Plastic Sheets, including reverse/collector variants.

DIN rail kit: 5 Iron. One kit per Small or Medium rail. DIN module kit: 5 Iron + 20 Copper. Other kit recipes remain unchanged; all custom kits remain exclusive to the Electronics Printer.

DIN transformers now have two construction stages. Small: 5 module kits for the body, then 3 normal Cable Coil units. Medium: 8 module kits, then 5 normal Cable Coil units. The unfinished body keeps the gray pocket backing without windings. Its terminals can be wired, but it transfers no power until finished. Aim the coil at the body to finish construction; terminal targets retain wiring priority. Native construction handles material consumption and stage dismantling. Existing completed transformers migrate to the completed stage when loading older saves.

Validation: native-reference build succeeds without warnings/errors; 28 save/XML/join-order checks, 12 winding-versus-terminal routing checks, and 4,791 power-engine regression checks pass. Actual Unity stage rendering, construction interaction and multiplayer still need in-game testing.

# Local 1.0.108 — ready, not uploaded

Last published107 commit8688521e121ef4c556852977f47de52219a5a586 tree41dacb5bcce8ddd0bd8ca329481908c54793b087. User authorized auditing all own previews/hitboxes, explicitly including door and Smart and opaque normal-model parts leaking through preview. No upload until nahraj; never Workshop publish.

See Verification/PREVIEW-HITBOX-AUDIT-1.0.108.md for complete family matrix and validation limits. New sources: OwnPreviewPolicy, CursorModelIsolation, FittedModelCollider, FittedControlSelection, FittedKitBounds, OwnPreviewAudit. Native HandleStructurePrefab only destroys registered ThingRenderer entries; unregistered added copper/native parts survived. A Priority.Last postfix now prepares a cursor-only isolation component; cached non-ghost/non-BlueprintHelper-descendant Renderer.forceRenderingOff flags are enforced in LateUpdate. No shared material mutation. Actual world renderers untouched.

Common selection now fits actual Wireframe.BlueprintBounds, transformed/scaled; fallback actual Thing.Bounds when no wireframe. Cabinet accepted box remains; native visibility/validity preserved and all own outlines get native tint. Active constructor or authoring guard preserved. All own structure families including DinTransformer and SmartContactor covered. Precise BoxCollider interaction selection applies to own controls, preserving IDs/pose.

ModelBlueprint.Build optionally filters to nearest owning Thing and includes disabled own renderers for physical-body rebuilds. Defaults keep preview behaviour. Final ModelBlueprint.Refresh installs fitted passive bodies for DinRail/DinBreaker(includingdoor)/SmartModule/SmartContactor; transformer and door constructors have explicit final install. Known passive body boxes are removed from build-state lists/lookup; dedicated controls and board surfaces retained. MeshCollider uses actual snapshot triangles. Serialized hit reference preserves prefab clone mapping. Borrowed initial mesh vs owned runtime rebuild mesh lifetimes separated. DinTransformer.ApplyWidth now tolerates removed bodyBox and uses Rebuild instead of leaking an unretained mesh for bounds. SmartContactor.ApplyWidth and DinRail.ApplySized rebuild fitted bodies. Native Structure.CachePrefabBounds retains its normal code then postfix restores fitted bounds/grid cache. Rebuild excludes mounted Things and includes temporarily disabled own renderers, but respects inactive alternate geometry.

SwitchboardKitModel.InstallBlueprint fits each custom kit Rigidbody's convex box and Bounds to combined geometry; trigger colliders retained in lookup and self/dynamic lists. Native quantities, identity, mass/hand/stack metadata not modified. Installed covers/labels already have shape/cutout-aware mesh colliders. Portable cover payload/visual/12mm carry-envelope code unchanged; dynamic selection fits preview mesh bounds.

Prefab.OnPrefabsLoaded VerifyRegistration calls OwnPreviewAudit.Verify for blueprint mesh/renderer and fitted-body presence diagnostics. Native API Release0warnings/errors. ModelBlueprint154 own-audit +29 general checks; supporting kit38/transformer-layout10006/Output-upgrade11/rail39/doorgeometry9395/doorplacement73/cover100/nativehelpers213/placement1414/casing2367 regressions passed. Stub tests do not prove real Unity/PhysX/Mono/MP/save/load/runtime visual behaviour.107sourceZIP1055entries still byte-match107snapshot. Power, wire protocol, accepted cabinet preview, casing collision, native connection detection, portable cover payload source files verified unchanged.

All modifications atomically replace hardlinked snapshot files. Source artifacts retained. SDK8.0.426 under/tmp/switchboard-dotnet; standardtask DOTNET_CLI_HOME/XDG_DATA_HOME/XDG_CONFIG_HOME/NUGET_PACKAGES. Native references work/build-deps, LibConstructPath needs /LibConstruct/LibConstruct.dll. Packaging work/archive1108.py, manifestwork/release1108-artifacts.json authoritative whencomplete.
