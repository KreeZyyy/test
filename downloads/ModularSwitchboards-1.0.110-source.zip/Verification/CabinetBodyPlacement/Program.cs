using System;using UnityEngine;using ModularSwitchboards;
class Program {
 static int checks;static void Check(bool b,string m){checks++;if(!b)throw new Exception(m);}
 static Bounds Body(bool medium)=>new(new(0,0,.09f),new(medium?.8f:.4f,medium?1f:.5f,.18f));
 static CabinetVolume V(bool medium,Vector3 at,float roll=0,float yaw=0)=>new(Body(medium),Matrix4x4.Pose(at,roll,yaw));
 static SwitchboardCabinet Host(object grid,bool medium,Vector3 at,float roll=0,float yaw=0){var h=new SwitchboardCabinet{GridController=grid,Bounds=Body(medium)};h.transform.localToWorldMatrix=Matrix4x4.Pose(at,roll,yaw);h.transform.Housing=new(){localToWorldMatrix=h.transform.localToWorldMatrix,Filter=new(){sharedMesh=new(){bounds=h.Bounds}}};return h;}
 static Bounds AssetHousing(bool medium)
 {
  using var reader=new System.IO.BinaryReader(System.IO.File.OpenRead(System.IO.Path.Combine(AppContext.BaseDirectory,"Cabinet.meshbin")));Check(new string(reader.ReadChars(4))=="SBMS"&&reader.ReadInt32()==1,"housing source header");int materials=reader.ReadInt32();reader.ReadInt32();reader.ReadBytes(materials*24);
  Bounds bounds=new();for(int mesh=0;mesh<2;mesh++){int count=reader.ReadInt32();var min=new Vector3(float.MaxValue,float.MaxValue,float.MaxValue);var max=new Vector3(float.MinValue,float.MinValue,float.MinValue);for(int i=0;i<count;i++){float x=reader.ReadSingle(),y=reader.ReadSingle(),z=reader.ReadSingle();reader.ReadBytes(12);if(medium){x*=2;y*=2;}min=new(MathF.Min(min.x,x),MathF.Min(min.y,y),MathF.Min(min.z,z));max=new(MathF.Max(max.x,x),MathF.Max(max.y,y),MathF.Max(max.z,z));}bounds=new((min+max)*.5f,max-min);for(int role=0;role<materials;role++)reader.ReadBytes(reader.ReadInt32()*4);}return bounds;
 }
 static void Main(){
 var assetSmall=AssetHousing(false);var assetMedium=AssetHousing(true);foreach(bool reverseA in new[]{false,true})foreach(bool reverseB in new[]{false,true})foreach(bool collectorA in new[]{false,true})foreach(bool collectorB in new[]{false,true})foreach(int roll in new[]{0,1,2,3}){
  var angle=roll*MathF.PI/2;var one=new CabinetVolume(assetSmall,Matrix4x4.Pose(new(-.5f,0,0),angle));var two=new CabinetVolume(assetMedium,Matrix4x4.Pose(new(0,0,0),angle));Check(one.Overlaps(two)&&two.Overlaps(one),"actual SBMS Small/Medium housing mesh overlap missed");Check(!one.Overlaps(new CabinetVolume(assetMedium,Matrix4x4.Pose(new(1,0,0),angle))),"actual meshes with proper space blocked");
 }

 foreach(bool a in new[]{false,true})foreach(bool b in new[]{false,true})foreach(int roll in new[]{0,1,2,3})foreach(float plane in new[]{0f,2f}){
  float angle=roll*MathF.PI/2;var origin=new Vector3(0,0,plane);var one=V(a,origin,angle);var two=V(b,new(.5f,0,plane),angle);
  float halfA=roll%2==0?(a?.4f:.2f):(a?.5f:.25f);float halfB=roll%2==0?(b?.4f:.2f):(b?.5f:.25f);
  Check(one.Overlaps(two)==(halfA+halfB>.5001f),"mixed-size 0.5m grid overlap");Check(one.Overlaps(two)==two.Overlaps(one),"asymmetric overlap");
  Check(!one.Overlaps(V(b,new(1f,0,plane),angle)),"separated grid placement rejected");
  Check(!one.Overlaps(V(b,new(halfA+halfB,0,plane),angle)),"touching casings must not overlap");
  Check(one.Overlaps(V(b,new(halfA+halfB-.001f,0,plane),angle)),"positive casing penetration ignored");
  Check(!one.Overlaps(V(b,new(0,0,plane+.3f),angle)),"separate parallel wall depths rejected");
  Check(!one.Overlaps(V(b,origin,angle,MathF.PI)),"opposite-facing housings only touch at wall");
 }
 // Screenshot case: Small and Medium centres on adjacent half-metre cells,
 // resulting in 100mm physical penetration despite distinct cell occupancy.
 var grid=new object();var small=Host(grid,false,new(-.5f,0,0));var medium=Host(grid,true,new(0,0,0));CabinetBodyPlacement.Register(small);Check(!CabinetBodyPlacement.Check(medium).CanConstruct,"screenshot Medium-over-Small accepted");Check(CabinetBodyPlacement.Check(medium).ErrorMessage.Contains("Switchboard"),"native obstacle message missing");CabinetBodyPlacement.Register(small);CabinetBodyPlacement.Remove(small);Check(CabinetBodyPlacement.Check(medium).CanConstruct,"duplicate registration/deregister left ghost obstacle");
 CabinetBodyPlacement.Register(medium);Check(!CabinetBodyPlacement.Check(small).CanConstruct,"Small-over-Medium accepted");Check(CabinetBodyPlacement.Check(medium).CanConstruct,"self blocked placement");medium.IsBeingDestroyed=true;Check(CabinetBodyPlacement.Check(small).CanConstruct,"destroying object blocks placement");medium.IsBeingDestroyed=false;medium.IsCursor=true;Check(CabinetBodyPlacement.Check(small).CanConstruct,"cursor blocks placement");medium.IsCursor=false;small.GridController=new();Check(CabinetBodyPlacement.Check(small).CanConstruct,"different world/grid blocked placement");small.GridController=grid;CabinetBodyPlacement.Remove(medium);CabinetBodyPlacement.Remove(medium);Check(CabinetBodyPlacement.Check(small).CanConstruct,"destroy/deregister double remove unsafe");
 var cursor=Host(grid,true,new(0,0,0));cursor.IsCursor=true;CabinetBodyPlacement.Register(cursor);cursor.IsCursor=false;Check(CabinetBodyPlacement.Check(small).CanConstruct,"cursor entered registry");
 // Actual transformed mesh bounds win over a deliberately incorrect inherited Bounds.
 medium=Host(grid,true,new(0,0,0));medium.Bounds=new(new(20,20,20),new(.01f,.01f,.01f));CabinetBodyPlacement.Register(medium);Check(!CabinetBodyPlacement.Check(small).CanConstruct,"wrong cached bounds used instead of housing mesh");CabinetBodyPlacement.Remove(medium);
 medium=Host(grid,true,new(0,0,0));medium.transform.Housing=null;CabinetBodyPlacement.Register(medium);Check(!CabinetBodyPlacement.Check(small).CanConstruct,"missing mesh fallback allowed penetration");CabinetBodyPlacement.Remove(medium);
 var random=new Random(107);for(int i=0;i<2000;i++){bool a=random.Next(2)==0,b=random.Next(2)==0;float x=(float)random.NextDouble()*2-1,y=(float)random.NextDouble()*2-1,z=(float)random.NextDouble()*.8f-.4f;bool expected=MathF.Abs(x)<(a?.4f:.2f)+(b?.4f:.2f)-.0001f&&MathF.Abs(y)<(a?.5f:.25f)+(b?.5f:.25f)-.0001f&&MathF.Abs(z)<.18f-.0001f;Check(V(a,new(0,0,0)).Overlaps(V(b,new(x,y,z)))==expected,"random axis-aligned volume differs from strict AABB result");}
 // A diagonal thin OBB can have overlapping AABBs with no body intersection.
 var thin=new Bounds(new(0,0,0),new(1,.1f,.1f));var first=new CabinetVolume(thin,Matrix4x4.Pose(new(0,0,0),MathF.PI/4));var second=new CabinetVolume(thin,Matrix4x4.Pose(new(-.15f,.15f,0),MathF.PI/4));Check(!first.Overlaps(second),"oriented boxes reduced to coarse world AABB");
 Console.WriteLine(checks+" casing-volume checks passed: screenshot 100mm mixed-size overlap in both orders, rotations/wall planes, touch/clearance/depth, transformed mesh vs cached bounds, lifecycle/self/cursor/world isolation and randomized volumes.");
 }
}
