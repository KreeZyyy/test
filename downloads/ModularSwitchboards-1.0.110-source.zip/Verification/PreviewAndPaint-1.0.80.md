# 1.0.80 verification and limits

- Actual WireRoutePlanner and WireRouteJob plus production CabinetWiringPreview polling are compiled into Wiring tests. Verify firstpoll returns before awaiting A*, snapshot survives live geometry edits, async/sync paths agree, one capture for100cached polls, revision/type replaces oldjobs, cancellation/fault handling and thread budgets.
- Existing fullWiring geometry/circuit/protection/battery/transformer/persistence tests pass through the production planner on captured snapshots. Search buffer reuse and sharededgecaches preserve results. No routing-clearance reductions or save-format migration.
- Actual RefreshWireColours and Color methods are extracted into mesh tests. Simulated repeated black propertyblock writes on a Burnt=true/redwire are reset to savedred by eachmaintenancecall; legitimate savedblack remainsblack. Rupturebodymesh retains base materialroles while compact damage meshcontains onlylocalendvertices. Actual native Unity rendering/order cannot be tested by these stubs.
- Game assembly build0warnings/errors. Authoritative cold commit and legacyreroute still run synchronously. Mesh creation/native renderer setup remain on mainthread. No promise of eliminating every possible frame hitch.
- Test on a worldcopy with matchinghost/client80, especially actual UI refresh whilecalculating, cancellations, scene unload, coilconsumptiononcommit, longpaintedburntwires and repeatednative paint updates. Source/code checks are not in-game confirmation.

The separate WireRuptureEnds renderer is explicitly excluded from cabinet-wide paint/material replacement; the production classifier is exercised alongside the colour-maintenance tests.
