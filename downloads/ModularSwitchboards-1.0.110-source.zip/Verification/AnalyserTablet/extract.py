from pathlib import Path
out=Path(__file__).parent
s=(out/'NativeConfig-reference.txt').read_text();a=s.index('\tprivate void ReadLogicText()');b=s.index('\n\tpublic override void OnScreenUpdate()',a)
(out/'Extracted.cs').write_text('using System;using System.Text;using Assets.Scripts;using Assets.Scripts.Objects;using Assets.Scripts.Objects.Pipes;using Assets.Scripts.Objects.Motherboards;namespace Assets.Scripts.Objects.Items{partial class ConfigCartridge{'+s[a:b]+'}}')
