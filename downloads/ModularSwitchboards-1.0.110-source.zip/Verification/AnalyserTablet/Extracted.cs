using System;using System.Text;using Assets.Scripts;using Assets.Scripts.Objects;using Assets.Scripts.Objects.Pipes;using Assets.Scripts.Objects.Motherboards;namespace Assets.Scripts.Objects.Items{partial class ConfigCartridge{	private void ReadLogicText()
	{
		_scannedDevice = ScannedDevice;
		lock (_outputText)
		{
			if (_scannedDevice != null)
			{
				if (_lastScannedDevice != _scannedDevice)
				{
					_needTopScroll = true;
				}
				_lastScannedDevice = _scannedDevice;
				_selectedText = _scannedDevice.DisplayName.ToUpper();
				StringBuilder stringBuilder = new StringBuilder();
				stringBuilder.Append("ReferenceId");
				stringBuilder.Append(" ... ");
				stringBuilder.AppendFormat("<color=#20B2AA>${0}</color>", _scannedDevice.ReferenceId.ToString("X"));
				for (int i = 0; i < EnumCollections.LogicTypes.Length; i++)
				{
					LogicType logicType = EnumCollections.LogicTypes.Values[i];
					if (_scannedDevice.CanLogicRead(logicType))
					{
						stringBuilder.Append("\n");
						stringBuilder.Append(EnumCollections.LogicTypes.Names[i]);
						stringBuilder.Append(" ... ");
						stringBuilder.Append(_scannedDevice.CanLogicWrite(logicType) ? "<color=grey>" : "<color=green>");
						stringBuilder.Append(Math.Round(_scannedDevice.GetLogicValue(logicType), 3, MidpointRounding.AwayFromZero));
						stringBuilder.Append("</color>");
					}
				}
				_outputText = stringBuilder.ToString();
			}
			else
			{
				_selectedText = _notApplicableString;
				_outputText = string.Empty;
			}
		}
	}
}}