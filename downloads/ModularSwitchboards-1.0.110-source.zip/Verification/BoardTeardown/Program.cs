using System;using LibConstruct;using Assets.Scripts;using Assets.Scripts.GridSystem;using ModularSwitchboards;
namespace Assets.Scripts.GridSystem {public enum GameState {Menu,Loading,Running,Unloading}}
namespace Assets.Scripts {public static class GameManager {public static GameState GameState;}}
namespace LibConstruct
{
 public interface IPlacementBoardHost {}
 public class PlacementBoard {public bool HasDestroyedChild;}
 public class BoardRef<T> where T:PlacementBoard,new(){public T Board;}
 public static class BoardHostHooks
 {
  public static int Calls;
  public static void OnDestroyedBoard<T>(IPlacementBoardHost host,BoardRef<T> reference)where T:PlacementBoard,new(){Calls++;if(reference.Board?.HasDestroyedChild==true)throw new NullReferenceException("SetParent on already-destroyed child");reference.Board=null;}
 }
}
class Host:IPlacementBoardHost {}class RailBoard:PlacementBoard{}class ModuleBoard:PlacementBoard{}class LabelBoard:PlacementBoard{}
class Program
{
 static int checks;static void Check(bool b,string why){checks++;if(!b)throw new Exception(why);}
 static void Verify<T>()where T:PlacementBoard,new()
 {
  var host=new Host();foreach(var state in new[]{GameState.Menu,GameState.Loading,GameState.Unloading})
  {
   GameManager.GameState=state;var reference=new BoardRef<T>{Board=new T{HasDestroyedChild=true}};var alias=reference;int before=BoardHostHooks.Calls;
   BoardHostLifetime.Release(host,ref reference);Check(reference==null&&alias.Board==null,"dead board references retained on world teardown");Check(BoardHostHooks.Calls==before,"gameplay orphan/deconstruct path entered during unload");BoardHostLifetime.Release(host,ref reference);Check(BoardHostHooks.Calls==before,"repeat teardown did not stay idempotent");
  }
  GameManager.GameState=GameState.Running;var normal=new BoardRef<T>{Board=new T()};int calls=BoardHostHooks.Calls;BoardHostLifetime.Release(host,ref normal);Check(normal==null&&BoardHostHooks.Calls==calls+1,"real in-world removal skipped native cleanup");BoardHostLifetime.Release(host,ref normal);Check(BoardHostHooks.Calls==calls+1,"normal cleanup repeated");
  var empty=new BoardRef<T>();BoardHostLifetime.Release(host,ref empty);Check(empty==null,"empty board handle retained");
 }
 static void Main(){Verify<RailBoard>();Verify<ModuleBoard>();Verify<LabelBoard>();Console.WriteLine($"{checks} board host lifecycle checks passed: destroyed children during unload/load/menu, repeat cleanup, native running-world cleanup and reference release.");}
}
