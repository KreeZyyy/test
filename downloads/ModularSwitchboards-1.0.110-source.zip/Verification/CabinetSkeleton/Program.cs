using System;using System.IO;using System.Linq;using System.Collections.Generic;using System.Text.Json;using UnityEngine;using Assets.Scripts.Objects;using ModularSwitchboards;
class Program
{
 static int checks;static void Check(bool b,string why){checks++;if(!b)throw new Exception(why);}static void Near(float a,float b,string why)=>Check(Math.Abs(a-b)<.00001f,why);
 static Mesh Read(float scale)
 {
  using var r=new BinaryReader(File.OpenRead(Path.Combine(AppContext.BaseDirectory,"Cabinet.meshbin")));Check(new string(r.ReadChars(4))=="SBMS","source header");r.ReadInt32();int materials=r.ReadInt32();r.ReadInt32();r.ReadBytes(materials*24);int n=r.ReadInt32();var mesh=new Mesh{subMeshCount=materials};var v=new List<Vector3>();var norms=new List<Vector3>();
  for(int i=0;i<n;i++){v.Add(new Vector3(r.ReadSingle()*scale,r.ReadSingle()*scale,r.ReadSingle()));norms.Add(new Vector3(r.ReadSingle(),r.ReadSingle(),r.ReadSingle()));}
  mesh.SetVertices(v);mesh.SetNormals(norms);for(int s=0;s<materials;s++){n=r.ReadInt32();var t=new List<int>();for(int i=0;i<n;i++)t.Add(r.ReadInt32());mesh.SetTriangles(t,s);}mesh.RecalculateBounds();return mesh;
 }
 static BoxCollider Edge(Structure c,Transform model,string name,Vector3 center,Vector3 size){var go=new GameObject(name);go.transform.SetParent(model,false);var b=go.AddComponent<BoxCollider>();b.center=center;b.size=size;c.BuildStates[0].Colliders.Add(b);return b;}
 static float Dot(Vector3 a,Vector3 b)=>a.x*b.x+a.y*b.y+a.z*b.z;
 static bool RayHit(Mesh mesh,float x,float y)
 {
  var origin=new Vector3(x,y,-1);var direction=Vector3.forward;
  foreach(int s in Enumerable.Range(0,mesh.subMeshCount)){var t=mesh.GetTriangles(s);for(int i=0;i<t.Length;i+=3){var a=mesh.vertices[t[i]];var e1=mesh.vertices[t[i+1]]-a;var e2=mesh.vertices[t[i+2]]-a;var h=Vector3.Cross(direction,e2);float det=Dot(e1,h);if(Math.Abs(det)<1e-9f)continue;float inv=1/det;var d=origin-a;float u=Dot(d,h)*inv;if(u<0||u>1)continue;var q=Vector3.Cross(d,e1);float v=Dot(direction,q)*inv;if(v<0||u+v>1)continue;if(Dot(e2,q)*inv>0)return true;}}
  return false;
 }
 static void Main(string[] args)
 {
  foreach(float k in new[]{1f,2f})foreach(bool reverse in new[]{false,true})
  {
   var source=Read(k);var before=source.vertices.ToArray();var cabinet=new Structure{PrefabName=(k==2?"Medium":"Small")+(reverse?"Reverse":"")};cabinet.gameObject.layer=7;var model=new GameObject("SwitchboardModel");model.transform.SetParent(cabinet.transform,false);var frame=new GameObject("Frame");frame.transform.SetParent(model.transform,false);var filter=frame.AddComponent<MeshFilter>();filter.sharedMesh=source;
   var old=new[]{Edge(cabinet,model.transform,"FrameLeft",new(-.185f*k,0,.015f),new(.02f*k,.48f*k,.03f)),Edge(cabinet,model.transform,"FrameRight",new(.185f*k,0,.015f),new(.02f*k,.48f*k,.03f)),Edge(cabinet,model.transform,"FrameTop",new(0,.23f*k,.015f),new(.35f*k,.02f*k,.03f)),Edge(cabinet,model.transform,"FrameBottom",new(0,-.23f*k,.015f),new(.35f*k,.02f*k,.03f))};
   CabinetSkeleton.Install(cabinet);var mesh=filter.sharedMesh;var profile=new CabinetSkeletonGeometry.Profile(k);Check(mesh!=source,"borrowed frame modified");Near(mesh.bounds.size.x,.388f*k-.001f,"width inside housing skin");Near(mesh.bounds.size.y,.488f*k-.001f,"height inside housing skin");Near(mesh.bounds.min.z,.0065f,"behind back panel");Near(mesh.bounds.max.z,.1795f,"front ring inside housing");Check(mesh.bounds.max.z<.185f,"door clearance");Check(mesh.normals.Length==mesh.vertices.Length,"normal count");
   Check(cabinet.BuildStates[0].Colliders.Count==1,"precise rounded skeleton collider");var hit=(MeshCollider)cabinet.BuildStates[0].Colliders[0];Check(hit.sharedMesh==mesh,"visual/collision mismatch");Check(!hit.isTrigger&&!hit.enabled,"native stage0 collider initialization");Check(hit.transform.parent==model.transform,"wall/reverse parent");Check(old.All(c=>!c.gameObject.components.Contains(c)),"old square colliders retained");Check(cabinet.BuildStates[1].Colliders.Count==0&&cabinet.BuildStates[2].Colliders.Count==0,"finished geometry changed");
   for(int i=0;i<before.Length;i++){Near(source.vertices[i].x,before[i].x,"source x changed");Near(source.vertices[i].z,before[i].z,"source z changed");}
   for(int s=0;s<mesh.subMeshCount;s++){var t=mesh.GetTriangles(s);Check(t.Length%3==0,"triangle grouping");Check(s==4?t.Length>0:t.Length==0,"frame material role lost");for(int i=0;i<t.Length;i+=3){int a=t[i],b=t[i+1],c=t[i+2];Check(a>=0&&c<mesh.vertices.Length&&b>=0,"invalid index");var normal=Vector3.Cross(mesh.vertices[b]-mesh.vertices[a],mesh.vertices[c]-mesh.vertices[a]);Check(Dot(normal,mesh.normals[a])>1e-11f,"backface or degenerate triangle");}}
   // Independent native housing inner profile: centre + R14 (R28 Medium).
   // Every frame/rail vertex must clear its skin by at least .49 mm.
   foreach(var v in mesh.vertices){float dx=Math.Max(0,Math.Abs(v.x)-.18f*k),dy=Math.Max(0,Math.Abs(v.y)-.23f*k);float distance=(float)Math.Sqrt(dx*dx+dy*dy);Check(distance<=.014f*k-.00049f,"skeleton protrudes into housing panels");Check(float.IsFinite(v.x)&&float.IsFinite(v.y)&&float.IsFinite(v.z),"nonfinite vertex");Near(Dot(mesh.normals[Array.IndexOf(mesh.vertices,v)],mesh.normals[Array.IndexOf(mesh.vertices,v)]),1,"nonunit normal");}
   var outer=CabinetSkeletonGeometry.Contour(profile,false);Check(outer.Length==52,"native profile sampling");for(int corner=0;corner<4;corner++)for(int step=0;step<=12;step++){var v=outer[corner*13+step];float cx=(corner==0||corner==3?.18f:-.18f)*k,cy=(corner<2?.23f:-.23f)*k;Near((float)Math.Sqrt((v.x-cx)*(v.x-cx)+(v.y-cy)*(v.y-cy)),.014f*k-.0005f,"Small/Medium corner radius does not follow native housing");}
   Check(!RayHit(mesh,0,0),"central opening blocked");Check(!RayHit(mesh,.19f*k,.24f*k),"square corner outside rounded profile still catches aim");Check(RayHit(mesh,0,profile.Height*.5f-profile.Rail*.5f),"top ring cannot be targeted");Check(RayHit(mesh,profile.Width*.5f-profile.Rail*.5f,0),"side ring cannot be targeted");
   foreach(int state in new[]{0,1,2,1,0}){for(int i=0;i<3;i++)foreach(var c in cabinet.BuildStates[i].Colliders)c.enabled=i==state;Check(hit.enabled==(state==0),"stage0 lifetime");}
   if(args.Length>0&&!reverse){Directory.CreateDirectory(args[0]);string file=Path.Combine(args[0],k==1?"SkeletonSmall.json":"SkeletonMedium.json");string json=JsonSerializer.Serialize(new{vertices=mesh.vertices.Select(v=>new[]{v.x,v.y,v.z}),triangles=Enumerable.Range(0,mesh.subMeshCount).ToDictionary(i=>i.ToString(),i=>mesh.GetTriangles(i))});File.WriteAllText(file+".new",json);File.Move(file+".new",file,true);}
  }
  Check(CabinetGeometry.UvApplications==4,"native painted UV mapping not applied");Console.WriteLine($"{checks} profiled skeleton checks passed: actual Small/Medium housing curvature, panel clearance, outward winding, open centre, precise collision mesh, stage transitions and original mesh preservation.");
 }
}
