from pathlib import Path
import json,struct
p=Path(__file__).resolve().parents[2]/'Art/NativeCableReference';r=json.loads((p/'Cables-reference.json').read_text());out=[]
for index,c in enumerate(r['cables']):
 if not c['straight']:continue
 part=c['parts'][0];normal=next(a for a in part['attributes'] if a['attribute']=='Normal');stream=part['streams'][normal['stream']];raw=(p/stream['file']).read_bytes()
 out.append(dict(kind=c['kind'],vertices=[[v[a] for a in ['x','y','z']] for v in part['vertices']],uv=[[v[a] for a in ['x','y']] for v in part['uv']],normals=[struct.unpack_from('<fff',raw,i*stream['stride']+normal['offset']) for i in range(len(part['vertices']))],groups=[s['triangles'] for s in part['surfaces']]))
Path(__file__).with_name('profiles.json').write_text(json.dumps(out,separators=(',',':')))
