using System;using System.IO;using System.Linq;using System.Text.Json;using System.Collections.Generic;using ModularSwitchboards;
class P{
 static int checks;static void Check(bool b,string s){checks++;if(!b)throw new Exception(s);}
 static WirePoint Vec(JsonElement a)=>new(a[0].GetSingle(),a[1].GetSingle(),a[2].GetSingle());
 static void Main(){var file=Path.GetFullPath(Path.Combine(AppContext.BaseDirectory,"../../../profiles.json"));using var doc=JsonDocument.Parse(File.ReadAllText(file));var export=new List<object>();int caseId=0;
 foreach(var source in doc.RootElement.EnumerateArray()){
 var vertices=source.GetProperty("vertices").EnumerateArray().Select(Vec).ToArray();var normals=source.GetProperty("normals").EnumerateArray().Select(Vec).ToArray();var uv=source.GetProperty("uv").EnumerateArray().Select(v=>new WireUv(v[0].GetSingle(),v[1].GetSingle())).ToArray();var groups=source.GetProperty("groups").EnumerateArray().Select(g=>g.EnumerateArray().Select(n=>n.GetInt32()).ToArray()).ToArray();
 string kind=source.GetProperty("kind").GetString();float radius=kind=="normal"?.0016f:kind=="heavy"?.002f:.0024f;
 var profile=new NativeWireShape.Profile{Vertices=vertices,Normals=normals,Uv=uv,Groups=groups,Start=vertices.Min(v=>v.Z),End=vertices.Max(v=>v.Z),Scale=radius/(float)Math.Sqrt(vertices.Max(v=>v.X*v.X+v.Y*v.Y))};
 var paths=new[]{new[]{new WirePoint(0,0,0),new WirePoint(.20f,0,0)},new[]{new WirePoint(0,0,0),new WirePoint(.003f,0,0)},WireTube.Round(new[]{new WirePoint(0,0,0),new WirePoint(.10f,0,0),new WirePoint(.10f,.08f,0),new WirePoint(.20f,.08f,.02f)},.02f),new[]{new WirePoint(0,0,0),new WirePoint(0,0,.15f)},WireTube.Round(new[]{new WirePoint(0,0,0),new WirePoint(0,.06f,0),new WirePoint(-.06f,.06f,.04f)},.015f)};
 foreach(var path in paths){var result=NativeWireShape.Build(profile,path);Check(result.Vertices.Count>0&&result.Vertices.Count==result.Normals.Count&&result.Vertices.Count==result.Uv.Count,kind+": empty/mismatched result");
 for(int i=0;i<result.Vertices.Count;i++){
  var p=result.Vertices[i];var n=result.Normals[i];var u=result.Uv[i];Check(float.IsFinite(p.X)&&float.IsFinite(p.Y)&&float.IsFinite(p.Z)&&Math.Abs(n.Squared-1)<1e-4f,kind+": invalid vertex or normal");Check(u.U>=uv.Min(v=>v.U)-1e-5&&u.U<=uv.Max(v=>v.U)+1e-5&&u.V>=uv.Min(v=>v.V)-1e-5&&u.V<=uv.Max(v=>v.V)+1e-5,kind+": native UV range changed");
 float closest=float.MaxValue;for(int s=1;s<path.Length;s++){var a=path[s-1];var delta=path[s]-a;float t=Math.Max(0,Math.Min(1,WirePoint.Dot(p-a,delta)/delta.Squared));closest=Math.Min(closest,(p-(a+delta*t)).Squared);}Check(closest<=(radius+.000002f)*(radius+.000002f),kind+": exceeds reserved route radius");
 }
 var firstAxis=path[1]-path[0];firstAxis=firstAxis*(1f/(float)Math.Sqrt(firstAxis.Squared));var lastAxis=path[^1]-path[^2];lastAxis=lastAxis*(1f/(float)Math.Sqrt(lastAxis.Squared));Check(result.Normals.Any(n=>WirePoint.Dot(n,firstAxis)<-.99f)&&result.Normals.Any(n=>WirePoint.Dot(n,lastAxis)>.99f),kind+": terminal end cap lost to floating-point clipping");
 foreach(var list in result.Groups){Check(list.Count%3==0,"invalid triangles");Check(list.All(i=>i>=0&&i<result.Vertices.Count),"invalid indices");}
 Check(vertices.SequenceEqual(profile.Vertices)&&normals.SequenceEqual(profile.Normals),"native source modified");
 if(caseId==2||caseId==7||caseId==12)export.Add(new{kind,vertices=result.Vertices.Select(v=>new[]{v.X,v.Y,v.Z}).ToArray(),normals=result.Normals.Select(v=>new[]{v.X,v.Y,v.Z}).ToArray(),uv=result.Uv.Select(v=>new[]{v.U,v.V}).ToArray(),groups=result.Groups});caseId++;
 }
 }
 File.WriteAllText(Path.Combine(Path.GetTempPath(),"native-wire173-meshes.json"),JsonSerializer.Serialize(export));Console.WriteLine(checks+" actual native-wire deformation checks passed on uploaded Normal/Heavy/Super Heavy meshes: straight, very short, rounded and 3D routes, native UV ranges, finite unit normals, unchanged profiles and routing radius.");}
}
