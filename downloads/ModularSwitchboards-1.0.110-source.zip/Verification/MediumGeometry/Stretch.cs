using System.Collections.Generic;
using Assets.Scripts.Objects;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class MediumGeometry
    {
        internal static Mesh Stretch(Mesh source,float x,float y,bool mirror=false)
        {
            var mesh=UnityEngine.Object.Instantiate(source);mesh.name="Medium."+source.name;
            var vertices=mesh.vertices;
            for(int i=0;i<vertices.Length;i++)vertices[i]=new Vector3(vertices[i].x*x*(mirror?-1:1),vertices[i].y*y,vertices[i].z);
            mesh.vertices=vertices;
            if(mirror)for(int s=0;s<mesh.subMeshCount;s++){var t=mesh.GetTriangles(s);for(int i=0;i<t.Length;i+=3){int n=t[i+1];t[i+1]=t[i+2];t[i+2]=n;}mesh.SetTriangles(t,s);}
            mesh.RecalculateNormals();mesh.RecalculateTangents();mesh.RecalculateBounds();return mesh;
        }
        // Match the housing's 40 mm XY corner while keeping the centre seam
        // at 400 mm and preserving its existing 20 mm inner corner/handle.
        internal static float DoorCornerX(float x)
            =>x<=.020f?x*2f:x>=.380f?x:.040f+(x-.020f)*(.340f/.360f);
        internal static Mesh Door(Mesh source,bool mirror=false)
        {
            var mesh=Stretch(source,1,2,mirror);var vertices=mesh.vertices;
            foreach(int i in System.Linq.Enumerable.Distinct(mesh.GetTriangles(0)))
                vertices[i].x=(mirror?-1:1)*DoorCornerX(System.Math.Abs(vertices[i].x));
            mesh.vertices=vertices;mesh.RecalculateNormals();mesh.RecalculateTangents();mesh.RecalculateBounds();return mesh;
        }
}}