using System;using System.Collections.Generic;using System.Linq;
namespace UnityEngine.Rendering {public enum IndexFormat {UInt16,UInt32}}
namespace UnityEngine
{
 public struct Vector2 {public float x,y;public Vector2(float x,float y){this.x=x;this.y=y;}}
 public struct Vector3
 {
  public float x,y,z;public Vector3(float x,float y,float z){this.x=x;this.y=y;this.z=z;}
  public static Vector3 one=>new(1,1,1);public static Vector3 forward=>new(0,0,1);public static Vector3 back=>new(0,0,-1);public static Vector3 up=>new(0,1,0);public static Vector3 down=>new(0,-1,0);public static Vector3 right=>new(1,0,0);public static Vector3 left=>new(-1,0,0);
  public static Vector3 operator +(Vector3 a,Vector3 b)=>new(a.x+b.x,a.y+b.y,a.z+b.z);public static Vector3 operator -(Vector3 a,Vector3 b)=>new(a.x-b.x,a.y-b.y,a.z-b.z);public static Vector3 operator *(Vector3 a,float b)=>new(a.x*b,a.y*b,a.z*b);public static Vector3 operator /(Vector3 a,float b)=>a*(1/b);
  public Vector3 normalized=>this/(float)Math.Sqrt(x*x+y*y+z*z);public static Vector3 Cross(Vector3 a,Vector3 b)=>new(a.y*b.z-a.z*b.y,a.z*b.x-a.x*b.z,a.x*b.y-a.y*b.x);
 }
 public static class Mathf {public const float PI=(float)Math.PI,Deg2Rad=PI/180;public static float Min(float a,float b)=>Math.Min(a,b);public static float Abs(float a)=>Math.Abs(a);public static float Clamp(float x,float a,float b)=>Math.Clamp(x,a,b);public static float Cos(float x)=>(float)Math.Cos(x);public static float Sin(float x)=>(float)Math.Sin(x);}
 public struct Bounds
 {
  public Vector3 center,size;public Bounds(Vector3 c,Vector3 s){center=c;size=s;}public Vector3 min=>center-size*.5f;public Vector3 max=>center+size*.5f;
  public bool Contains(Vector3 v)=>v.x>=min.x&&v.x<=max.x&&v.y>=min.y&&v.y<=max.y&&v.z>=min.z&&v.z<=max.z;
 }
 public class Component {public GameObject gameObject;public Transform transform=>gameObject.transform;public T GetComponent<T>()where T:Component=>gameObject.GetComponent<T>();}
 public class Transform:Component
 {
  public Transform parent;public List<Transform> children=new();public void SetParent(Transform p,bool world){parent=p;p.children.Add(this);}public Transform Find(string name)=>children.Find(c=>c.gameObject.name==name);
 }
 public class GameObject
 {
  public string name;public int layer;public Transform transform;public List<Component> components=new();public GameObject(string name){this.name=name;transform=new Transform{gameObject=this};}
  public T AddComponent<T>()where T:Component,new(){var c=new T{gameObject=this};components.Add(c);return c;}public T GetComponent<T>()where T:Component=>(T)components.Find(c=>c is T);
 }
 public static class Object {public static void DestroyImmediate(object obj){if(obj is Component c)c.gameObject.components.Remove(c);}}
 public class MeshCollider:Collider {public Mesh sharedMesh;}
 public class Collider:Component {public bool enabled=true,isTrigger;}
 public class BoxCollider:Collider {public Vector3 center,size;}
 public class MeshRenderer:Component {}
 public class MeshFilter:Component {public Mesh sharedMesh;}
 public class Mesh
 {
  public Vector2[] uv=Array.Empty<Vector2>();public void SetUVs(int slot,List<Vector2> values){uv=values.ToArray();}public void RecalculateTangents(){}
  public string name;public Rendering.IndexFormat indexFormat;public Vector3[] vertices=Array.Empty<Vector3>(),normals=Array.Empty<Vector3>();public Bounds bounds;private int[][] tri=Array.Empty<int[]>();
  public int subMeshCount {get=>tri.Length;set=>Array.Resize(ref tri,value);}public int[] GetTriangles(int i)=>tri[i];public void SetTriangles(List<int> t,int i)=>tri[i]=t.ToArray();public void SetVertices(List<Vector3> v)=>vertices=v.ToArray();public void SetNormals(List<Vector3> v)=>normals=v.ToArray();
  public void RecalculateBounds(){var min=new Vector3(vertices.Min(v=>v.x),vertices.Min(v=>v.y),vertices.Min(v=>v.z));var max=new Vector3(vertices.Max(v=>v.x),vertices.Max(v=>v.y),vertices.Max(v=>v.z));bounds=new Bounds((min+max)*.5f,max-min);}
 }
}
namespace Assets.Scripts.Objects {public class BuildState {public List<UnityEngine.Collider> Colliders=new();}public class Structure:UnityEngine.Component {public string PrefabName;public List<BuildState> BuildStates=new(){new(),new(),new()};public Structure(){gameObject=new UnityEngine.GameObject("Cabinet");}}}
namespace ModularSwitchboards {public static class CabinetShape {public static bool Medium(string name)=>name.StartsWith("Medium");}public static class CabinetGeometry {public static int UvApplications;public static void ApplyNativeUv(UnityEngine.Mesh m){UvApplications++;}}}

namespace ModularSwitchboards {public static class CabinetRearSurface {public const int Role=1;public static void Restore(UnityEngine.MeshRenderer renderer){}}public static class CabinetMatteSurface {public static void Apply(UnityEngine.MeshRenderer renderer){}}}
