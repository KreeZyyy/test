using System;using System.IO;using System.Linq;using System.Text.Json;using System.Collections.Generic;using UnityEngine;using ModularSwitchboards;
class Program
{
 static int checks;static void Check(bool b,string why){checks++;if(!b)throw new Exception(why);}static void Near(float a,float b,string why)=>Check(Math.Abs(a-b)<1e-6f,why);
 static Mesh ReadHousing(float k)
 {
  using var r=new BinaryReader(File.OpenRead(Path.Combine(AppContext.BaseDirectory,"Cabinet.meshbin")));r.ReadBytes(4);r.ReadInt32();int count=r.ReadInt32();r.ReadInt32();r.ReadBytes(count*24);
  for(int part=0;;part++) {var mesh=new Mesh{subMeshCount=count};int n=r.ReadInt32();mesh.vertices=new Vector3[n];mesh.normals=new Vector3[n];mesh.uv=new Vector2[n];for(int i=0;i<n;i++){mesh.vertices[i]=new(r.ReadSingle()*k,r.ReadSingle()*k,r.ReadSingle());mesh.normals[i]=new(r.ReadSingle(),r.ReadSingle(),r.ReadSingle());mesh.uv[i]=new(i*.0001f,.35f+i*.00001f);}for(int s=0;s<count;s++){n=r.ReadInt32();var t=new List<int>();for(int i=0;i<n;i++)t.Add(r.ReadInt32());mesh.SetTriangles(t,s);}mesh.RecalculateBounds();if(part==1)return mesh;}
 }
 static void Main(string[] args)
 {
  foreach(float scale in new[]{1f,2f})
  {
   var housing=ReadHousing(scale);var sourceIndices=housing.GetTriangles(1);var sourceUnique=sourceIndices.Distinct().ToArray();var p=housing.vertices.ToArray();var frame=new Mesh{subMeshCount=5,vertices=new[]{new Vector3(-.1f,0,.1795f),new Vector3(.1f,0,.1795f),new Vector3(0,.1f,.1795f)},normals=new[]{Vector3.forward,Vector3.forward,Vector3.forward},uv=new[]{new Vector2(.1f,.2f),new Vector2(.3f,.4f),new Vector2(.5f,.6f)}};for(int s=0;s<5;s++)frame.SetTriangles(s==4?new List<int>{0,1,2}:new List<int>(),s);
   var result=CabinetRearShell.Append(frame,housing);Check(result.vertices.Length==3+sourceUnique.Length,"must copy only grey rear vertices");Check(result.GetTriangles(1).Length==sourceIndices.Length,"grey body topology lost");Check(result.GetTriangles(4).SequenceEqual(new[]{0,1,2}),"skeleton topology changed");foreach(int s in new[]{0,2,3})Check(result.GetTriangles(s).Length==0,"white panels/interior/hardware incorrectly added");Check(result.vertices.Length==result.normals.Length&&result.uv.Length==result.vertices.Length,"native vertex channels lost");Near(result.bounds.min.z,-.086239442f,"rear depth");Near(result.bounds.max.z,.1795f,"no extra box in combined frame");
   for(int i=0;i<3;i++){Near(result.vertices[i].z,frame.vertices[i].z,"frame moved");Near(result.uv[i].x,frame.uv[i].x,"frame UV changed");}
   var remap=new Dictionary<int,int>();int next=3;for(int i=0;i<sourceIndices.Length;i++){int old=sourceIndices[i];if(!remap.TryGetValue(old,out int n))remap[old]=n=next++;int dest=result.GetTriangles(1)[i];Check(dest==n,"rear triangle remapping");Near(result.vertices[dest].x,p[old].x,"grey X");Near(result.vertices[dest].y,p[old].y,"grey Y");Near(result.vertices[dest].z,p[old].z,"grey Z");Near(result.normals[dest].x,housing.normals[old].x,"normal preserved");Near(result.uv[dest].x,housing.uv[old].x,"native grey UV X preserved");Near(result.uv[dest].y,housing.uv[old].y,"native grey UV Y preserved");Check(result.vertices[dest].z<=.000001f,"forward white casing included");}
   Check(housing.vertices.SequenceEqual(p),"shared housing mesh mutated");Check(sourceIndices.SequenceEqual(housing.GetTriangles(1)),"shared housing topology mutated");
   if(args.Length>0)
   {
    var file=Path.Combine(args[0],scale==1?"SkeletonSmall.json":"SkeletonMedium.json");using var doc=JsonDocument.Parse(File.ReadAllText(file));var data=doc.RootElement;var actual=new Mesh{subMeshCount=5};actual.vertices=data.GetProperty("vertices").EnumerateArray().Select(v=>new Vector3(v[0].GetSingle(),v[1].GetSingle(),v[2].GetSingle())).ToArray();actual.normals=actual.vertices.Select(v=>Vector3.forward).ToArray();actual.uv=actual.vertices.Select(v=>new Vector2()).ToArray();for(int s=0;s<5;s++)actual.SetTriangles(data.GetProperty("triangles").GetProperty(s.ToString()).EnumerateArray().Select(x=>x.GetInt32()).ToList(),s);
    // Repeat exports safely: the skeleton input has no rear role initially.
    if(actual.GetTriangles(1).Length==0)actual=CabinetRearShell.Append(actual,housing);
    var json=JsonSerializer.Serialize(new{vertices=actual.vertices.Select(v=>new[]{v.x,v.y,v.z}),triangles=Enumerable.Range(0,5).ToDictionary(s=>s.ToString(),s=>actual.GetTriangles(s))});File.WriteAllText(file+".new",json);File.Move(file+".new",file,true);
   }
  }
  Console.WriteLine($"{checks} grey rear shell checks passed: only native grey housing body, exact topology/UV/normals, preserved skeleton and source assets, no white panels or protruding box.");
 }
}
