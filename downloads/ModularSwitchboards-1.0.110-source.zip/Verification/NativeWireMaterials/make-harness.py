from pathlib import Path
p=Path(__file__).resolve();s=(p.parents[1]/'NativeWireReferenceSource/NativeWireVisual.cs.txt').read_text();a=s.index('        private static bool IsPaintSlot(');b=s.rfind('    }');(p.parent/'Extracted.cs').write_text('using System.Linq;using UnityEngine;namespace ModularSwitchboards{static partial class NativeWireVisual{'+s[a:b]+'}}')
