using System.Linq;using UnityEngine;namespace ModularSwitchboards{static partial class NativeWireVisual{        private static bool IsPaintSlot(Material material,Template template)=>material!=null&&(material==template.Paintable||material.mainTexture is Texture2DArray);
        private static Material Copy(Material source)
        {
            if(source==null)return null;
            if(!Materials.TryGetValue(source,out var copy)){copy=new Material(source){name="Switchboards.NativeWire."+source.name};Materials[source]=copy;}return copy;
        }
        internal static bool Paint(MeshRenderer renderer,ColorType colour)
        {
            var marker=renderer.GetComponent<NativeWireRenderer>();if(marker==null||!marker.Active)return false;
            if(marker.LastColor==(int)colour)return true;var template=Get(marker.Kind);if(template==null)return false;
            // Native CustomColorMapping replaces paintable prefab materials with
            // this texture-array material during initialization. Swatch.Normal is
            // a legacy solid-colour material and loses the cable's atlas detail.
            var paint=GameManager.GetTextureArrayColorMaterial();
            if(paint==null)return false;
            renderer.sharedMaterials=template.Materials.Select(m=>Copy(IsPaintSlot(m,template)?paint:m)).ToArray();
            // Match native cable initialization: unchanged UVs + array atlas + palette index.
            for(int i=0;i<template.Materials.Length;i++){if(!IsPaintSlot(template.Materials[i],template)){renderer.SetPropertyBlock(null,i);continue;}var block=new MaterialPropertyBlock();block.SetFloat(Thing.DiffuseIndexPropertyID,(int)colour);block.SetFloat(Thing.SmoothnessIndexPropertyID,template.Smoothness);block.SetColor(Thing.EMISSION_COLOR,Color.black);renderer.SetPropertyBlock(block,i);}
            marker.LastColor=(int)colour;return true;
        }
}}