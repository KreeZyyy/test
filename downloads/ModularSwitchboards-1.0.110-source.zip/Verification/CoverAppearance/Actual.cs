using System;class PortableCoverItem{public bool IsCursor;public CoverMemory State;private CoverMemory rendered,iconState;private int iconColour=-1;public Sprite Thumbnail;private Sprite ownedIcon;private object owned;private int generation;public static int Destroyed;private static void Destroy(object thing){Destroyed++;}public void Tick()=>LateUpdate();        internal Sprite GetSavedIcon(){RefreshIcon();return Thumbnail;}
        private void RefreshIcon()
        {
            if(IsCursor||State==null||ReferenceEquals(State,iconState)&&iconColour==State.Colour)return;
            var previous=ownedIcon;ownedIcon=FittedCoverIcons.Create(State);Thumbnail=ownedIcon;iconState=State;iconColour=State.Colour;
            if(previous!=null){Destroy(previous.texture);Destroy(previous);}
        }
        internal void RefreshNow(){RefreshIcon();if(State!=null&&!ReferenceEquals(State,rendered)){PortableCoverVisual.Build(this,State,ref owned);rendered=State;generation++;}}
        private void LateUpdate(){if(IsCursor)return;RefreshNow();if(State!=null)PortableCoverVisual.Restore(this,State);}}