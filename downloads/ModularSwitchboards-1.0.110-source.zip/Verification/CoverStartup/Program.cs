using System;using System.IO;using System.Linq;using System.Reflection.Metadata;using System.Reflection.Metadata.Ecma335;using System.Reflection.PortableExecutable;
var root=Path.GetFullPath(args[0]);var path=Path.Combine(root,"ModularSwitchboards/Assemblies/ModularSwitchboards.dll");
using var pe=new PEReader(File.OpenRead(path));var md=pe.GetMetadataReader();
var types=md.TypeDefinitions.Where(h=>new[]{"CoverPaint","InnerCoverModule","PortableCoverItem"}.Contains(md.GetString(md.GetTypeDefinition(h).Name))).ToDictionary(h=>md.GetString(md.GetTypeDefinition(h).Name));
var paint=md.GetTypeDefinition(types["CoverPaint"]);var spray=paint.GetMethods().Single(h=>md.GetString(md.GetMethodDefinition(h).Name)=="Spray");
if(paint.GetMethods().Any(h=>md.GetString(md.GetMethodDefinition(h).Name)=="BeforeNativeSpray"))throw new Exception("Interface hook remains");
int checks=1;
foreach(var name in new[]{"InnerCoverModule","PortableCoverItem"}){
 var t=md.GetTypeDefinition(types[name]);var h=t.GetMethods().Single(h=>md.GetString(md.GetMethodDefinition(h).Name)=="AttackWith");
 var method=md.GetMethodDefinition(h);var il=pe.GetMethodBody(method.RelativeVirtualAddress).GetILBytes();var token=BitConverter.GetBytes(MetadataTokens.GetToken(spray));
 if(!Enumerable.Range(0,il.Length-4).Any(i=>il[i]==0x28&&il.Skip(i+1).Take(4).SequenceEqual(token)))throw new Exception(name+" no direct paint dispatch");checks++;
}
var source=File.ReadAllText(Path.Combine(root,"Source/SwitchboardsMod.cs"));if(source.Contains("typeof(ISprayer)")||source.Contains("BeforeNativeSpray"))throw new Exception("Unsupported interface patch registered");checks++;
Console.WriteLine(checks+" production assembly/startup regression checks passed: no interface hook, both compiled cover interactions call CoverPaint.Spray directly.");
