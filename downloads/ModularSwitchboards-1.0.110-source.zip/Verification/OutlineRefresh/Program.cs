using System;using System.Collections.Generic;using UnityEngine;using ModularSwitchboards;
namespace UnityEngine
{
 public class Object {public bool Destroyed;public static void Destroy(Object obj){obj.Destroyed=true;}}
 public struct Vector3 {public float x,y,z;public Vector3(float x,float y,float z){this.x=x;this.y=y;this.z=z;}}
 public enum MeshTopology {Lines}
 public class Mesh:Object {public string name;public int indexFormat;public Vector3[] vertices;public int[] triangles;public int[] Lines;public void SetIndices(int[] i,MeshTopology t,int slot){Lines=i;}public void RecalculateBounds(){}}
 public class Component {public GameObject gameObject;public T GetComponent<T>()where T:Component=>gameObject.GetComponent<T>();}
 public class GameObject
 {
  public Transform transform;public Dictionary<Type,Component> Components=new();public GameObject(){transform=new Transform();}
  public T GetComponent<T>()where T:Component=>Components.TryGetValue(typeof(T),out var c)?(T)c:null;
  public T Add<T>()where T:Component,new(){var c=new T{gameObject=this};Components[typeof(T)]=c;return c;}
 }
 public class Transform {public GameObject Child;public Transform Find(string name)=>name=="StaticItemEdges"?Child?.transform:null;public GameObject Self;public T GetComponent<T>()where T:Component=>Self.GetComponent<T>();}
 public class MeshFilter:Component {public Mesh sharedMesh;}
}
namespace ModularSwitchboards
{
 class PlacementPreviewResources:Component {public Mesh Edges;public object Materials;}
 static class PlacementOutlineGeometry {public static int[] Build(Vector3[] v,int[] t)=>new[]{0,1};}
}
class Program
{
 static int checks;static void Check(bool b,string why){checks++;if(!b)throw new Exception(why);}
 static Mesh Source(float width)=>new Mesh{vertices=new[]{new Vector3(-width*.5f,0,0),new Vector3(width*.5f,0,0),new Vector3(0,.03f,0)},triangles=new[]{0,1,2},indexFormat=32};
 static void Main()
 {
  var root=new GameObject();root.transform.Self=root;var first=Source(.25f);PlacementOutline.Refresh(root,first);Check(root.Components.Count==0,"refresh before Start should not add duplicate style");
  var owner=root.Add<PlacementPreviewResources>();owner.Materials=new object();var material=owner.Materials;var child=new GameObject();child.transform.Self=child;root.transform.Child=child;var filter=child.Add<MeshFilter>();var previous=Source(.1f);owner.Edges=previous;filter.sharedMesh=previous;
  foreach(float width in new[]{.567f,.243f,.567f})
  {
   var source=Source(width);PlacementOutline.Refresh(root,source);var edges=filter.sharedMesh;
   Check(edges!=previous&&owner.Edges==edges,"edge ownership not replaced");Check(previous.Destroyed,"old outline mesh leaked");Check(!source.Destroyed,"source mesh destroyed");Check(Math.Abs(edges.vertices[1].x-edges.vertices[0].x-width)<1e-6f,"outline keeps old Small/Medium width");Check(edges.indexFormat==source.indexFormat&&edges.Lines.Length==2,"line topology mismatch");Check(owner.Materials==material,"green materials changed during resize");Check(root.Components.Count==1&&child.Components.Count==1,"extra style components accumulated");previous=edges;
  }
  Console.WriteLine($"{checks} actual outline refresh checks passed: source width, mesh replacement/ownership, cleanup, startup deferral and retained materials.");
 }
}
