using UnityEngine;namespace ModularSwitchboards {internal static class PlacementOutline {        internal static void Refresh(GameObject cursor,Mesh source)
        {
            var owner=cursor.GetComponent<PlacementPreviewResources>();
            var child=cursor.transform.Find("StaticItemEdges")?.GetComponent<MeshFilter>();
            if(owner==null||child==null)return; // Start will style the resized mesh.
            var edges=new Mesh{name="Switchboards.ItemPreview.Edges",indexFormat=source.indexFormat};
            var vertices=source.vertices;edges.vertices=vertices;edges.SetIndices(PlacementOutlineGeometry.Build(vertices,source.triangles),MeshTopology.Lines,0);edges.RecalculateBounds();
            var previous=owner.Edges;child.sharedMesh=edges;owner.Edges=edges;
            if(previous!=null)Object.Destroy(previous);
        }
}}