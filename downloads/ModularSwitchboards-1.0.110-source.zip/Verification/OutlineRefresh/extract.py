from pathlib import Path
p=Path(__file__).resolve().parents[2]
s=(p/'Source/PlacementOutline.cs').read_text();a=s.index('        internal static void Refresh');b=s.index('        internal static bool Apply',a)
f=Path(__file__).parent/'Actual.cs';t=f.with_suffix('.new');t.write_text('using UnityEngine;namespace ModularSwitchboards {internal static class PlacementOutline {'+s[a:b]+'}}');t.replace(f)
