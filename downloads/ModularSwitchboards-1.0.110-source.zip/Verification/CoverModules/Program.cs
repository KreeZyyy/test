using System;using System.Linq;using System.Collections.Generic;using UnityEngine;using ModularSwitchboards;
namespace UnityEngine{
public struct Vector3{public float x,y,z;public Vector3(float a,float b,float c){x=a;y=b;z=c;}}
public class Transform{public float X,Y;public Vector3 TransformPoint(Vector3 p)=>new(p.x+X,p.y+Y,p.z);public Vector3 InverseTransformPoint(Vector3 p)=>new(p.x-X,p.y-Y,p.z);}
}
namespace ModularSwitchboards{
struct WireRect{public float Left,Right,Bottom,Top;public WireRect(float l,float r,float b,float t){Left=l;Right=r;Bottom=b;Top=t;}}
static class DinLayout{public const float SlotPitch=.0405f,ModuleHalfWidth=.0198f;}
class Part{public bool IsCursor,IsBeingDestroyed;public int ModuleWidth;public Transform transform=new();}
class CabinetWiring{public List<Part> Transformers=new(),Contactors=new();}
}
class Program{
static int count;static void Check(bool b,string m){count++;if(!b)throw new Exception(m);}
static void Main(){
foreach(float offset in new[]{-.3f,0,.2f})foreach(int slots in new[]{1,2,4,6}){
var t=new Part{ModuleWidth=slots,transform=new(){X=offset,Y=.12f}};var w=new CabinetWiring();if(slots>=4)w.Transformers.Add(t);else w.Contactors.Add(t);
var surface=new Transform{X=.03f,Y=.01f};var holes=CabinetCoverWindows.Additional(w,surface);Check(holes.Length==1,"separate component omitted");var h=holes[0];var expected=InnerCoverLayout.Window(offset-.03f+(slots-1)*DinLayout.SlotPitch*.5f,.11f,slots,false);
Check(Math.Abs(h.Left-expected.Left)<1e-7&&Math.Abs(h.Right-expected.Right)<1e-7,"width/centre uses wrong slot count or terminal offset");Check(h.Top>.11f+.034f&&h.Bottom<.11f-.034f,"fascia obstructed");Check(h.Top<.11f+.04f&&h.Bottom>.11f-.04f,"terminal exposure");
var signature=CabinetCoverWindows.Signature(holes);t.transform.X+=.01f;Check(signature!=CabinetCoverWindows.Signature(CabinetCoverWindows.Additional(w,surface)),"move did not invalidate cover");t.ModuleWidth++;Check(signature!=CabinetCoverWindows.Signature(CabinetCoverWindows.Additional(w,surface)),"width did not invalidate cover");t.IsBeingDestroyed=true;Check(CabinetCoverWindows.Additional(w,surface).Length==0,"removed part leaves opening");t.IsBeingDestroyed=false;t.IsCursor=true;Check(CabinetCoverWindows.Additional(w,surface).Length==0,"cursor cuts cover");}
var mixed=new CabinetWiring{Transformers=new(){new(){ModuleWidth=4},new(){ModuleWidth=6,transform=new(){X=.17f}}},Contactors=new(){new(){ModuleWidth=2,transform=new(){Y=-.12f}}}};
var all=CabinetCoverWindows.Additional(mixed,new());Check(all.Length==3,"mixed transformers/output missing");foreach(var h in all){var cells=InnerCoverLayout.Cells(all);float x=(h.Left+h.Right)*.5f,y=(h.Bottom+h.Top)*.5f;Check(!cells.Any(c=>x>c.Left&&x<c.Right&&y>c.Bottom&&y<c.Top),"cover fills module window");}
Console.WriteLine(count+" actual cover-module provider checks passed: Small/Medium/Output/legacy widths, shifted surfaces, fascia/terminal clearance, move/resize/removal/cursor and mixed openings.");}}
