using System;using System.Linq;using UnityEngine;using Assets.Scripts;using LibConstruct;namespace ModularSwitchboards{public partial class InnerCoverModule{string memoryInputs;private CoverLabelMemory[] LiveLabels()=>Memory.Labels;public void TickMemoryForTest()=>RefreshMemory(Array.Empty<WireRect>());        private void RefreshMemory(WireRect[] windows)
        {
            if(Memory==null)Memory=CoverMemory.Fresh(Host.CoverProfile,Host.CustomColor==null?(int)ColorType.White:Host.CustomColor.Index);
            if(!GameManager.RunSimulation||PlacementBoard.Loading||Labels==null)return;
            if(!Memory.FixedColour){Memory.FixedColour=true;MarkMemoryChanged();}
            var live=LiveLabels();var input=CabinetCoverWindows.Signature(windows)+"|"+live.Length+"|"+string.Join(";",live.OrderBy(l=>l.Y).ThenBy(l=>l.X).Select(l=>l.Key+":"+l.OwnerId+":"+(l.Text?.Length??0)+":"+l.Text));
            if(input==memoryInputs)return;
            var next=Memory.Reconcile(live,windows);next.Validate();
            if(next.Pack()!=Memory.Pack()){Memory=next;MarkMemoryChanged();}
            memoryInputs=input;
        }
 }static class CabinetCoverWindows{public static string Signature(WireRect[] windows)=>string.Join(";",windows.Select(w=>w.Left+","+w.Right));}}