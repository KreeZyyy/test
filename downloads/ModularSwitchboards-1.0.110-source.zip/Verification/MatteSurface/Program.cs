using System;using System.Collections.Generic;using ModularSwitchboards;using UnityEngine;
namespace UnityEngine{
 public class Material{public string name;public object Texture,Colour;public static int Copies;public Dictionary<string,float> Values=new();public HashSet<string> Keywords=new();public Material(){}public Material(Material m){Copies++;name=m.name;Texture=m.Texture;Colour=m.Colour;Values=new(m.Values);Keywords=new(m.Keywords);}public bool HasProperty(int p)=>Values.ContainsKey("id"+p);public float GetFloat(int p)=>Values["id"+p];public bool HasProperty(string p)=>Values.ContainsKey(p);public void SetFloat(string p,float v)=>Values[p]=v;public void EnableKeyword(string k)=>Keywords.Add(k);}
 public class TextMesh{}
 public class MaterialPropertyBlock{public Dictionary<int,float> Values=new();public void SetFloat(int p,float v)=>Values[p]=v;public void Clear()=>Values.Clear();}
 public class MeshRenderer{public string name="Renderer";public Material[] sharedMaterials;public Material sharedMaterial=>sharedMaterials.Length>0?sharedMaterials[0]:null;public Assets.Scripts.Objects.Thing Owner;public TextMesh Text;public Dictionary<int,float> Global=new();public Dictionary<int,Dictionary<int,float>> Slots=new();
 public T GetComponentInParent<T>() where T:class=>Owner as T;public T GetComponent<T>() where T:class=>Text as T;
 public void GetPropertyBlock(MaterialPropertyBlock b){b.Values=new(Global);}public void SetPropertyBlock(MaterialPropertyBlock b){Global=new(b.Values);}
 public void GetPropertyBlock(MaterialPropertyBlock b,int i){b.Values=Slots.ContainsKey(i)?new(Slots[i]):new();}public void SetPropertyBlock(MaterialPropertyBlock b,int i){Slots[i]=new(b.Values);}}

}
namespace Assets.Scripts.Objects{public class Thing{public const int SmoothnessIndexPropertyID=9;public UnityEngine.MeshRenderer[] Renderers=Array.Empty<UnityEngine.MeshRenderer>();public T[] GetComponentsInChildren<T>(bool all)=>Renderers as T[];}}
namespace ModularSwitchboards{public static class CabinetGeometry{public static UnityEngine.Material[] Materials;}public class SwitchboardCabinet:Assets.Scripts.Objects.Thing{}public class DinRail:Assets.Scripts.Objects.Thing{}public class DinBreaker:Assets.Scripts.Objects.Thing{public bool IsDoorPart,IsSmartOutputModule,IsContactor;}}
namespace Assets.Scripts{public static class GameManager{public class Swatch{public UnityEngine.Material Normal;}public static Dictionary<int,Swatch> Swatches=new();public static Swatch GetColorSwatch(int i)=>Swatches.TryGetValue(i,out var s)?s:null;}}
class Program{
 static int checks;static void Check(bool ok,string m){checks++;if(!ok)throw new Exception(m);}
 static void Main(){
 Check(CabinetMatteSurface.IsPanel("Door")&&CabinetMatteSurface.IsPanel("Housing")&&CabinetMatteSurface.IsPanel("Frame"),"Exterior panels not matte");Check(!CabinetMatteSurface.IsPanel("DoorLedLens")&&!CabinetMatteSurface.IsPanel("DoorStopMushroom")&&!CabinetMatteSurface.IsPanel("InternalWire"),"Module/wire gloss changed");
 var source=new Material{name="Original",Texture=new object(),Colour=new object()};
 foreach(string p in new[]{"_Glossiness","_Smoothness","_GlossMapScale","_Metallic","_SpecularHighlights","_GlossyReflections"})source.Values[p]=.7f;
 source.Values["_EmissionColor"]=4;source.Keywords.Add("_EMISSION");source.Values["_DiffuseIndex"]=6;var outside=new MeshRenderer{sharedMaterials=new[]{source}};var inside=new MeshRenderer{sharedMaterials=new[]{source,null,source}};
 CabinetMatteSurface.Apply(inside);var matte=inside.sharedMaterials[0];Check(matte!=source,"Source borrowed instead of cloned");Check(outside.sharedMaterials[0]==source,"Exterior changed");Check(matte.Texture==source.Texture&&matte.Colour==source.Colour,"Paint texture/colour lost");Check(inside.sharedMaterials[1]==null,"Null slot altered");Check(inside.sharedMaterials[2]==matte,"Duplicate source not cached");
 foreach(string p in new[]{"_Glossiness","_Smoothness","_GlossMapScale","_Metallic","_SpecularHighlights","_GlossyReflections"}){Check(source.Values[p]==.7f,"Original material mutated");Check(matte.Values[p]==0,"Reflection preset not applied");}
 Check(matte.Values["_EmissionColor"]==4&&matte.Keywords.Contains("_EMISSION"),"LED emission changed");Check(matte.Values["_DiffuseIndex"]==6,"Paint index changed");Check(source.Keywords.SetEquals(new[]{"_EMISSION"}),"Original keywords mutated");Check(matte.Keywords.Contains("_SPECULARHIGHLIGHTS_OFF")&&matte.Keywords.Contains("_GLOSSYREFLECTIONS_OFF"),"Shader keywords missing");
 CabinetMatteSurface.Apply(inside);Check(Material.Copies==1&&inside.sharedMaterials[0]==matte,"Repeated application re-cloned");var second=new MeshRenderer{sharedMaterials=new[]{source}};CabinetMatteSurface.Apply(second);Check(second.sharedMaterials[0]==matte&&Material.Copies==1,"Second renderer didn't use private cache");
 var unsupported=new Material{name="NoGlossProperties"};var special=new MeshRenderer{sharedMaterials=new[]{unsupported}};CabinetMatteSurface.Apply(special);Check(special.sharedMaterials[0].Values.Count==0,"Unsupported shader properties added");

 var metallic=new Material{name="NativeMetallic",Texture=new object()};metallic.Values["_Metallic"]=1;metallic.Values["id9"]=4;
 var atlas=new Material{name="NativePaintTextureArray",Texture=new object()};atlas.Values["_Metallic"]=.7f;CabinetGeometry.Materials=new[]{atlas};
 Assets.Scripts.GameManager.Swatches[10]=new(){Normal=metallic};var painted=new MeshRenderer{sharedMaterials=new[]{matte,matte}};
 CabinetPaintSurface.Apply(painted,10);Check(ReferenceEquals(painted.sharedMaterials[0],atlas),"Textured paint atlas replaced by solid swatch");Check(ReferenceEquals(painted.sharedMaterials[1],source),"Fixed hardware not restored");Check(metallic.Values["_Metallic"]==1&&!metallic.Keywords.Contains("_SPECULARHIGHLIGHTS_OFF"),"Native metallic settings modified");Check(CabinetPaintSurface.Smoothness(10,2)==2,"Native surface array index replaced with legacy gloss");Check(CabinetPaintSurface.Smoothness(99,2)==2,"Native fallback changed");
 var normal=new Material{name="NativeNormal"};Assets.Scripts.GameManager.Swatches[11]=new(){Normal=normal};CabinetPaintSurface.Apply(painted,11);Check(ReferenceEquals(painted.sharedMaterials[0],atlas),"Repaint lost native surface textures");
 var owner=new SwitchboardCabinet();var child=new Assets.Scripts.Objects.Thing();
 var panel=new MeshRenderer{Owner=owner,sharedMaterials=new[]{source}};panel.Global[2]=8;panel.Global[9]=5;panel.Slots[0]=new(){{3,7},{9,5}};
 var battery=new MeshRenderer{Owner=child,sharedMaterials=new[]{source}};var text=new MeshRenderer{Owner=owner,Text=new TextMesh(),sharedMaterials=new[]{source}};
 owner.Renderers=new[]{panel,battery,text};SwitchboardFinish.Refresh(owner);
 Check(panel.sharedMaterials[0]==source,"Cabinet native paint finish overwritten");Check(battery.sharedMaterials[0]==source,"Inserted native battery changed");Check(text.sharedMaterials[0]==source,"Text shader changed");
 Check(panel.Global[9]==5&&panel.Slots[0][9]==5,"Native cabinet smoothness overwritten");Check(panel.Global[2]==8&&panel.Slots[0][3]==7,"Property block color/emission lost");
 foreach(var assembly in new Assets.Scripts.Objects.Thing[]{new DinRail(),new DinBreaker()}){var r=new MeshRenderer{Owner=assembly,sharedMaterials=new[]{source}};assembly.Renderers=new[]{r};SwitchboardFinish.Refresh(assembly);Check(r.sharedMaterials[0]==matte,"Mounted assembly skipped");}
 var door=new DinBreaker{IsDoorPart=true};var lens=new MeshRenderer{Owner=door,sharedMaterials=new[]{source}};door.Renderers=new[]{lens};SwitchboardFinish.Refresh(door);Check(lens.sharedMaterials[0]==source,"Live LED material identity replaced");
 var output=new DinBreaker{IsSmartOutputModule=true};var outputLens=new MeshRenderer{name="SmartOutputLens",Owner=output,sharedMaterials=new[]{source}};var outputBody=new MeshRenderer{name="DinBreakerModel",Owner=output,sharedMaterials=new[]{source}};output.Renderers=new[]{outputLens,outputBody};SwitchboardFinish.Refresh(output);
 Check(ReferenceEquals(outputLens.sharedMaterials[0],source),"Smart Output live material replaced by a matte copy");Check(ReferenceEquals(outputBody.sharedMaterials[0],matte),"Output body lost its matte finish");
 SwitchboardFinish.Refresh(child);Check(battery.sharedMaterials[0]==source,"Unrelated native Thing changed");
 var smart=new SmartModule();var smartBody=new MeshRenderer{name="DinBreakerModel",Owner=smart,sharedMaterials=new[]{source}};var nativeLed=new MeshRenderer{name="Screen",Owner=smart,sharedMaterials=new[]{source}};var nativeSocket=new MeshRenderer{name="OriginalSocketFrame",Owner=smart,sharedMaterials=new[]{source}};smart.Renderers=new[]{smartBody,nativeLed,nativeSocket};SwitchboardFinish.Refresh(smart);Check(smartBody.sharedMaterials[0]==matte,"Smart casing not matte");Check(nativeLed.sharedMaterials[0]==source&&nativeSocket.sharedMaterials[0]==source,"Smart native LED/socket material changed");
 var plc=new SmartContactor();var plcBody=new MeshRenderer{name="DinBreakerModel",Owner=plc,sharedMaterials=new[]{source}};var plcLens=new MeshRenderer{name="OutputStatusLED",Owner=plc,sharedMaterials=new[]{source}};var plcDigits=new MeshRenderer{name="AddressGlyph",Owner=plc,sharedMaterials=new[]{source}};plc.Renderers=new[]{plcBody,plcLens,plcDigits};SwitchboardFinish.Refresh(plc);
 Check(plcBody.sharedMaterials[0]==matte,"PLC Output body not matte");Check(plcLens.sharedMaterials[0]==source&&plcDigits.sharedMaterials[0]==source,"PLC live LED/glyph material replaced by cached matte clone");
 var copiedCoreRim=new MeshRenderer{name="NativeLEDBezel",Owner=plc,sharedMaterials=new[]{source}};var copiedCoreGrid=new MeshRenderer{name="Screen",Owner=plc,sharedMaterials=new[]{source}};var copiedHousingScrew=new MeshRenderer{name="OutputAddressScrew",Owner=plc,sharedMaterials=new[]{source}};plc.Renderers=new[]{copiedCoreRim,copiedCoreGrid,copiedHousingScrew};SwitchboardFinish.Refresh(plc);Check(copiedCoreRim.sharedMaterials[0]==matte&&copiedCoreGrid.sharedMaterials[0]==source&&copiedHousingScrew.sharedMaterials[0]==source,"copied Core/housing surfaces lost material isolation");
 Console.WriteLine($"Production matte material isolation: {checks} checks passed; source/exterior unchanged, paint retained, supported properties only, stable private cache.");
 }
}

namespace ModularSwitchboards{public class SmartModule:Assets.Scripts.Objects.Thing{}}

namespace ModularSwitchboards{public class SmartContactor:Assets.Scripts.Objects.Thing{}}

namespace ModularSwitchboards{public class DinTransformer:Assets.Scripts.Objects.Thing{}}
