using System;using System.Collections.Generic;using Assets.Scripts.Objects.Electrical;using UnityEngine;namespace ModularSwitchboards{internal static class NativeCableReference{        [Serializable] public sealed class Report
        {
            public string version=SwitchboardsMod.Version,gameAssembly=typeof(Cable).Assembly.FullName;
            public bool graphicsUvStartsAtTop=SystemInfo.graphicsUVStartsAtTop;public string graphicsDevice=SystemInfo.graphicsDeviceType.ToString();
            public string coordinates="Vertices in native prefab-local metres; UVs and submesh indices unchanged.";
            public List<CableData> cables=new List<CableData>();public List<TextureData> textures=new List<TextureData>();public List<string> errors=new List<string>();
        }
        [Serializable] public sealed class CableData
        {
            public string prefab,kind,paintMaterial;public float maxVoltage,diffuseIndex,smoothnessIndex;public bool straight;
            public List<string> coils=new List<string>();public List<Part> parts=new List<Part>();
        }
        [Serializable] public sealed class Part
        {
            public string path,mesh;public List<Attribute> attributes=new List<Attribute>();public List<Stream> streams=new List<Stream>();public Vector3[] vertices;public Vector2[] uv;public Matrix4x4 meshToPrefab;
            public List<Property> globalBlock=new List<Property>();public List<Surface> surfaces=new List<Surface>();
        }
        [Serializable] public sealed class Attribute{public string attribute,format;public int dimension,stream,offset;}
        [Serializable] public sealed class Stream{public int stream,stride,bytes;public string file,error;}
        [Serializable] public sealed class Surface
        {
            public int submesh;public int[] triangles;public string material,shader;public bool paintable;
            public List<Property> properties=new List<Property>();
        }
        [Serializable] public sealed class Property
        {
            public string name,type,texture,blockTexture;public int textureId,blockTextureId;public bool blockHasProperty;
            public float value,blockFloat;public Color color,blockColor;public Vector4 vector,blockVector;public Vector2 scale,offset;
        }
        [Serializable] public sealed class TextureData
        {
            public int id,width,height,slice;public string name,dimension,format,file,error;
        }
        internal static void AddSlice(HashSet<int> slices,float value){if(!float.IsNaN(value)&&!float.IsInfinity(value)&&value>=0&&value<2048&&Math.Abs(value-Math.Round(value))<.001f)slices.Add((int)Math.Round(value));}
}}