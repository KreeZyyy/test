using System;using System.Linq;using System.Collections.Generic;using Assets.Scripts;using Assets.Scripts.Objects;using UnityEngine;namespace ModularSwitchboards{partial class CabinetWiring{        private static bool CanRefundWires(IEnumerable<CabinetWireSaveData> batch)=>batch.All(w=>CabinetCableCoils.RefundPrefab(w.CableKind)!=null);
        internal bool CanRefundBreaker(long id)=>CanRefundWires(wires.Where(w=>w.From.Owner==id||w.To.Owner==id));
        private static void RefundWires(IEnumerable<CabinetWireSaveData> batch,Vector3 position,Slot destination)
        {
            foreach(var group in batch.GroupBy(w=>w.CableKind))
                OnServer.CreateOrStack(CabinetCableCoils.RefundPrefab(group.Key),group.Sum(w=>w.CableUnits),position,Quaternion.identity,destination);
        }
        internal void RefundAndRemoveBreaker(long id,Vector3 position,Slot destination)
        {
            if(!GameManager.RunSimulation)return;
            var batch=wires.Where(w=>w.From.Owner==id||w.To.Owner==id).ToArray();
            if(!CanRefundWires(batch))throw new InvalidOperationException("Cable coil prefab unavailable during module demolition");
            RefundWires(batch,position,destination);RemoveBreaker(id);
        }
        internal void RemoveBreaker(long id)
        {
            if(wires.RemoveAll(w=>w.From.Owner==id||w.To.Owner==id)>0)Changed();
            foreach(var actor in pending.Where(p=>p.Value.Owner==id).Select(p=>p.Key).ToArray()){pending.Remove(actor);pendingUntil.Remove(actor);Owner.NetworkUpdateFlags|=UpdateFlag;}
            topology=null;
        }
}}