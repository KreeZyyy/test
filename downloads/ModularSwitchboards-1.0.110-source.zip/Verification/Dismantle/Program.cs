using System;
using System.Linq;
using System.Collections.Generic;
using Assets.Scripts;
using Assets.Scripts.Objects;
using UnityEngine;
using ModularSwitchboards;
namespace UnityEngine{public struct Vector3{public float x,y,z;}public struct Quaternion{public static Quaternion identity=>new();}}
namespace Assets.Scripts{static class GameManager{public static bool RunSimulation=true;}static class Prefab{public static bool Available=true;public static T Find<T>(string name)where T:new()=>Available?new T():default;}}
namespace Assets.Scripts.Objects{class Structure{}class Item{}class Slot{}class ConstructionEventInstance{public Vector3 Position;public Slot OtherHandSlot;}}
static class OnServer{public static int Units,Calls;public static Slot Hand;public static void CreateOrStack(Item item,int units,Vector3 p,Quaternion q,Slot slot){Units+=units;Calls++;Hand=slot;}}
namespace ModularSwitchboards{
 class DinTransformer:Structure{public long ReferenceId;public CabinetWiring Wiring;}
 class SmartContactor:Structure{public long ReferenceId;public CabinetWiring Wiring;}
 static class CabinetCableCoils{internal static Item RefundPrefab(CabinetWireKind kind)=>Prefab.Find<Item>("ItemCableCoil");}
 class SmartModule:Structure{public long ReferenceId;public CabinetWiring AttachedWiring;}
 class DinBreaker:Structure{public long ReferenceId;public Cabinet Host;}
 class Cabinet{public CabinetWiring Wiring;public ushort NetworkUpdateFlags;}
 partial class CabinetWiring{
  internal readonly List<CabinetWireSaveData> wires=new();internal readonly Dictionary<long,CabinetWireEnd> pending=new();internal readonly Dictionary<long,float> pendingUntil=new();internal string topology;internal int changes;internal const ushort UpdateFlag=32768;
  internal Cabinet Owner;internal static Cabinet CabinetOf(DinBreaker m)=>m.Host;internal bool HasWires(long id)=>wires.Any(w=>w.From.Owner==id||w.To.Owner==id);private void Changed(){changes++;Owner.NetworkUpdateFlags|=UpdateFlag;}
 }
}
class Program{
 static CabinetWireSaveData W(long a,int ap,long b,int bp)=>new(){From=new(a,ap),To=new(b,bp),CableUnits=1};
 static int checks;static void Check(bool b,string m){checks++;if(!b)throw new Exception(m);}
 static void Main(){
 var cabinet=new Cabinet();var wiring=new CabinetWiring{Owner=cabinet};cabinet.Wiring=wiring;
 var module=new DinBreaker{ReferenceId=10,Host=cabinet};var hand=new Slot();var action=new ConstructionEventInstance{OtherHandSlot=hand};
 wiring.wires.AddRange(new[]{W(0,0,10,0),W(10,1,0,1),W(0,0,20,0),W(20,1,0,2)});wiring.pending[99]=new(10,0);wiring.pendingUntil[99]=10;
 Check(ModuleDismantle.CanRefund(module),"Available cable prefab blocks demolition");Prefab.Available=false;Check(!ModuleDismantle.CanRefund(module),"Missing refund prefab accepted");Prefab.Available=true;
 GameManager.RunSimulation=false;ModuleDismantle.Refund(module,action,false);Check(OnServer.Calls==0&&wiring.wires.Count==4,"Client spawned/deleted wire");GameManager.RunSimulation=true;
 ModuleDismantle.Refund(module,action,true);Check(OnServer.Calls==0&&wiring.wires.Count==4,"Damage refunded wire");
 ModuleDismantle.Refund(new Structure(),action,false);Check(OnServer.Calls==0,"Non-module refunded wire");
 ModuleDismantle.Refund(module,action,false);
 Check(OnServer.Units==2&&OnServer.Calls==1&&OnServer.Hand==hand,"Wrong cable refund or destination");
 Check(wiring.wires.Count==2&&wiring.wires.All(w=>w.From.Owner!=10&&w.To.Owner!=10),"Connected wires remain");
 Check(!wiring.pending.ContainsKey(99)&&!wiring.pendingUntil.ContainsKey(99)&&wiring.changes==1,"Pending selection or topology update missing");
 Check(WireCircuit.Reachable(new(0,0),new(0,2),wiring.wires,new long[]{20}),"Other output damaged");
 ModuleDismantle.Refund(module,action,false);wiring.RemoveBreaker(10);Check(OnServer.Units==2&&OnServer.Calls==1,"Duplicate destruction/deregistration refunded twice");
 // Removing a Smart module must release the feeder breaker's branch capacity.
 wiring.wires.Add(W(20,1,42,0)); // Native feeder capacity is three branches.
 var smart=new SmartModule{ReferenceId=40,AttachedWiring=wiring};wiring.wires.Add(W(20,1,40,0));wiring.pending[77]=new(40,0);wiring.pendingUntil[77]=4;
 Check(wiring.wires.Count(w=>w.From.Owner==20&&w.From.Contact==1)==3,"fixture missing feeder branches");
 Check(!WireCircuit.CanConnect(new(20,1),new(41,0),wiring.wires,new long[]{20},out _),"full feeder wrongly accepts another cable");
 Prefab.Available=false;Check(!ModuleDismantle.CanRefund(smart),"Smart refund missing-prefab guard lost");Prefab.Available=true;
 int oldUnits=OnServer.Units;ModuleDismantle.Refund(smart,action,false);
 Check(OnServer.Units==oldUnits+1&&!wiring.HasWires(40),"Smart cable not refunded/removed");Check(wiring.wires.Count(w=>w.From.Owner==20&&w.From.Contact==1)==2,"feeder branch not released");
 Check(!wiring.pending.ContainsKey(77)&&!wiring.pendingUntil.ContainsKey(77),"Smart pending target survived");ModuleDismantle.Unlink(smart);ModuleDismantle.Unlink(smart);Check(OnServer.Units==oldUnits+1,"Smart deregistration refunded twice");
 Check(WireCircuit.CanConnect(new(20,1),new(41,0),wiring.wires,new long[]{20},out _),"removed Smart still blocks feeder contact");wiring.wires.Add(W(20,1,41,0));
 var forced=new SmartModule{ReferenceId=41,AttachedWiring=wiring};ModuleDismantle.Unlink(forced);Check(!wiring.HasWires(41)&&wiring.wires.Count(w=>w.From.Owner==20&&w.From.Contact==1)==2,"forced Smart removal leaves occupied feeder slot");
 Check(WireCircuit.Reachable(new(0,0),new(0,2),wiring.wires,new long[]{20}),"Smart cleanup damaged another branch");
 Console.WriteLine(checks+" dismantle checks passed including Smart cable refund, freed feeder branch, forced removal and idempotent cleanup.");
 Console.WriteLine("Production demolition hook/cleanup passed: authority only, damage skipped, two cable units refunded once to other hand, only attached wires removed, pending selection cleared, other output intact, repeated cleanup idempotent.");
 }
}
