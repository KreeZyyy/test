using Assets.Scripts.Objects;
namespace ModularSwitchboards {partial class SwitchboardCabinet{        public override CanConstructInfo CanConstruct()
        {
            var result=base.CanConstruct();
            return result.CanConstruct?CabinetPlacement.Check(this):result;
        }
}class PlacementPreviewResources{internal Material[] Materials;        internal void FollowValidity(Color tint)
        {
            if(Materials==null||Materials.Length<2||Materials[1]==null)return;
            tint.a=Materials[1].color.a;Materials[1].color=tint;
        }
}struct Color{public float r,g,b,a;}class Material{internal Color color;}}