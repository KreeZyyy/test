using System;using System.Linq;using System.Collections.Generic;
namespace Assets.Scripts.GridSystem {public record struct Grid3(int x,int y,int z){public static bool operator ==(Grid3 a,int b)=>false;public static bool operator !=(Grid3 a,int b)=>true;}}
namespace Assets.Scripts.Objects {
 using Assets.Scripts.GridSystem;
 [Flags]public enum NetworkType{None=0,Power=1,Data=2}
 public enum ConnectionRole{Input,Output,Output2,Waste}
 public record struct Vec(float x,float y,float z){public static Vec operator +(Vec a,Vec b)=>new(a.x+b.x,a.y+b.y,a.z+b.z);public static Vec operator *(Vec a,float b)=>new(a.x*b,a.y*b,a.z*b);}
 public class Transform{public Vec position,forward;}
 public class Grid {public readonly Dictionary<Grid3,Cell> Cells=new();public Grid3 WorldToLocalGrid(Vec p,float size,float offset)=>new((int)MathF.Round(p.x/size),(int)MathF.Round(p.y/size),(int)MathF.Round(p.z/size));public Cell GetSmallCell(Grid3 p)=>Cells.GetValueOrDefault(p);}
 public class Cell{public Assets.Scripts.Objects.Pipes.Device Device;public Cable Cable;}
 public class SmallGrid {public const float SmallGridSize=.5f,SmallGridOffset=.25f;public bool IsCursor;public Grid GridController=new();public long ReferenceId;public List<Connection> OpenEnds=new();public bool BaseValid=true;public virtual CanConstructInfo CanConstruct()=>BaseValid?CanConstructInfo.ValidPlacement:CanConstructInfo.InvalidPlacement("base collision");public virtual bool IsConnected(Connection end)=>OpenEnds.Any(p=>(p.ConnectionType&end.ConnectionType)!=0&&p.GetLocalGrid()==end.GetFacingGrid());}
 public class Connection {public SmallGrid Parent;public Transform Transform;public NetworkType ConnectionType;public ConnectionRole ConnectionRole;public Connection(SmallGrid p){Parent=p;}public Grid3 GetLocalGrid()=>Parent.GridController.WorldToLocalGrid(Transform.position,.5f,.25f);public Grid3 GetFacingGrid()=>Parent.GridController.WorldToLocalGrid(Transform.position+Transform.forward*.5f,.5f,.25f);}
 public class Cable:SmallGrid {}
 public readonly struct CanConstructInfo {public readonly bool CanConstruct;public readonly string ErrorMessage;public CanConstructInfo(bool b,string m){CanConstruct=b;ErrorMessage=m;}public static CanConstructInfo ValidPlacement=>new(true,"");public static CanConstructInfo InvalidPlacement(string s)=>new(false,s);}
}
namespace Assets.Scripts.Objects.Pipes {public class Device:Assets.Scripts.Objects.SmallGrid{public string DisplayName="Area Power Control";}}
namespace Assets.Scripts.Localization2 {public class Text{public string AsString(string s)=>"Cannot place adjacent to "+s;}public static class GameStrings{public static readonly Text PlacementBlockedByAdjacentDevice=new();}}
namespace ModularSwitchboards {using Assets.Scripts.Objects;partial class SwitchboardCabinet:Assets.Scripts.Objects.Pipes.Device {public bool IsStructureCompleted;public override bool IsConnected(Connection end)=>IsStructureCompleted&&base.IsConnected(end);}}

namespace Assets.Scripts.Objects.Pipes {public class PipeDevice:Device,Assets.Scripts.Networks.INetworkedPipe{public bool Prohibit;public bool ProhibitConnection(Device device)=>Prohibit;}}

namespace Assets.Scripts.Networks {public interface INetworkedPipe{bool ProhibitConnection(Assets.Scripts.Objects.Pipes.Device device);}}

namespace ModularSwitchboards{static class CabinetBodyPlacement{public static bool Block;public static Assets.Scripts.Objects.CanConstructInfo Check(SwitchboardCabinet h)=>Block?Assets.Scripts.Objects.CanConstructInfo.InvalidPlacement("casing overlap"):Assets.Scripts.Objects.CanConstructInfo.ValidPlacement;}}
