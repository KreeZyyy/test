# Preview and hitbox audit — 1.0.108

This is a source/native-contract audit with executable stub tests. It is not an in-game visual or PhysX certification.

| Family | Preview/selection result | Body and control result |
|---|---|---|
| Eight Small/Medium cabinet variants | Existing frame/arrow native preview kept; copied real renderers isolated; native helpers and validity colours retained | Existing exact frame/housing colliders and 107 oriented-volume placement rejection retained |
| DIN breakers, all ratings, including legacy | Actual assembled geometry; no opaque switch/rating-part leak; unpadded blueprint box | Passive model triangle body; dedicated switch target retained; control selection padding removed |
| DIN fuse holders, all discovered ratings | Actual housing/contacts; no opaque overlay | Passive housing triangles; cartridge slot and matching fuse actions retained |
| DIN battery and analyzer | Native fitted bay/bezel included in model snapshot; copied opaque parts hidden | Passive assembled model; battery slot and analyzer behaviour retained |
| DIN transformer Small/Medium, legacy widths | Both classes covered by common fitted box and cursor isolation; no normal-colour winding/front overlay | Triangle body; separate decrease/increase targets; fitted bounds restored after native cache and legacy width changes |
| Smart Core / Net / Output | Core display, Net status and Output panel covered; actual assembled model and fitted box | Triangle passive body; chip slot and address/control screw preserved; width/load migration rebuilds fitted body |
| Door LEDs (four colours), rotary switches, main switch, TOTAL STOP, individual bridges | Same isolated native blueprint and model-sized selection; no copied status/body renderer leak | Model triangles around body/guard; real front controls and bridge targets remain separate; precise control selection bounds |
| DIN rail Small/Medium | Existing size-aware ghost/outline retained; fitted selection follows sized mesh | Triangle rail body rebuilt on size change; separate module mounting surface retained; mounted modules excluded from rail body rebuild |
| Installed/perforated covers | Existing size/cutout/label-aware preview; fitted model selection | Existing real mesh collider follows openings; broad placement-only label boards remain purpose-specific surfaces |
| DIN labels (1/2/3/4/6), door label, emergency ring | Actual plate/ring mesh preview; selection uses blueprint envelope | Existing plate/ring mesh colliders retained; control/ring geometry not replaced by a filled rectangle |
| Cabinet/modules/Smart/door/rail/cover/label kits | Existing combined package geometry and native T placement retained | One convex package box fitted to actual model bounds; triggers, lookup/lists, identity, quantity and hand poses retained |
| Carried labelled cover | Existing saved size/paint/cutouts/labels preview and per-instance cursor retained | Existing thin Rigidbody-safe carry envelope retained; selection uses model bounds; payload/serialization unchanged |

Implementation checks

- CursorModelIsolation runs after native HandleStructurePrefab for own classes only. It hides copied Renderer instances with forceRenderingOff, never shared materials, meshes or the placed object's renderer. The Wireframe subtree and every descendant of native BlueprintHelper are excluded. Cached flags are enforced in LateUpdate so enabled/status changes cannot reveal copper, screens or other source parts.
- ModelPreviewCursor reads actual Wireframe.BlueprintBounds (fallback Thing.Bounds), transforms centre and absolute lossy scale, and leaves native visibility/colour alone. Cabinet bounds remain accepted; authoring mode and non-constructor isolation are retained.
- FittedModelCollider replaces only passive body boxes at known body roots. Dedicated Interactable colliders and mounting surfaces survive. Body is a triangle MeshCollider referencing the baked model. The collider reference is serialized so Unity prefab cloning reuses the cloned collider rather than adding stale duplicates on width restore. Rebuilds use only renderers owned by that Thing and include temporarily disabled renderers, excluding inactive alternate parts and mounted child Things. Borrowed prefab meshes are never freed by an instance; private rebuilt meshes are released. A bounds-cache postfix restores actual fitted dimensions after native caches.
- FittedControlSelection strips only bounds padding for our BoxCollider controls, preserving native selection position, rotation, owner and interactable IDs. Existing special switch/fuse/dial/screw rules remain compatible.
- Custom kits use a convex box rather than non-convex triangle physics on a moving Rigidbody. Trigger colliders remain in lookup and self/dynamic lists. Installed covers/labels already have real perforated/ring mesh colliders, so those were preserved.
- OwnPreviewAudit runs after prefab registration and logs missing blueprint mesh/renderer or missing fitted body components, with the total checked own prefab count. It does not suppress source errors or add menu items.

Validation

Native-reference Release build0warnings/errors. ModelBlueprint project:154 new own-family checks plus29 model/mesh/ownership/selection checks. New checks compile production isolation, policies, body fitting, selection, kit and startup-audit sources against stubs: nine construction classes, native helper descendants, opacity/material isolation, scaled bounds, slot/mount/control preservation, body triangle identity, width rebuild while hidden, nested-child exclusion, duplicate prevention, serialized hit reference, owned/borrowed mesh lifetime, seven kit classes and trigger preservation, startup diagnostics and bounds-cache restoration.

Supporting production/extracted regressions:38 kit T cursors;10006 transformer expansion-layout checks;11 Output load-upgrade checks;39 rail resize checks;9395 door geometry checks;73 door placement checks;100 cover-module/cutout checks;213 native port-helper checks;1414 network-colour/placement checks;2367 casing-volume checks. The Output load-upgrade fixture's stale DinTransformer stub was updated; production migration logic was unchanged.

Native inventory source was inspected to confirm the leak: HandleStructurePrefab destroys only registered ThingRenderers when a Blueprint exists, leaving added unregistered renderers visible. Native structure bounds caching and selection contracts were also inspected. Decompiled game sources are not added to the package.

Pending in-game validation: native Mono/Harmony scheduling, opaque part visibility and outline colour, actual pick priority at controls/slots, MeshCollider cooking/load cost, animated control targets, kit drop/carry/stack physics, cover interaction, native save/load and host/client play. Bounding boxes are fitted envelopes; they are not claims of per-pixel precision. Controls intentionally retain usable physical targets.
