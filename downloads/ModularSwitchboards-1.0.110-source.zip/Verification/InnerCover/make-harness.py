from pathlib import Path
p=Path(__file__).resolve().parents[2];q=Path(__file__).parent
s=(p/'Source/CabinetInnerCover.cs').read_text();a=s.index('        internal static Mesh Build');b=s.index('        private void OnDestroy',a)
target=q/'Extracted.cs';old=target.read_text();x=old.index('        internal static Mesh Build');y=old.index('public sealed class SwitchboardCabinetSaveData',x)
# End of the extracted geometry class is immediately before the save DTO.
end=old.rfind('}',x,y)
target.write_text(old[:x]+s[a:b]+old[end:])
