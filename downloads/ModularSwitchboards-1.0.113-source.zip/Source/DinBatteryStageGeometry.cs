using System.Collections.Generic;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class DinBatteryStageGeometry
    {
        internal static Mesh Bare(Bounds bounds)
        {
            var v=new List<Vector3>();var n=new List<Vector3>();var t=new List<int>();
            foreach(float sign in new[]{-1f,1f})
                RoundedGeometry.Box(v,n,t,new Vector3(bounds.center.x+sign*bounds.size.x*.38f,bounds.center.y,.057f),new Vector3(bounds.size.x*.07f,bounds.size.y*.65f,.003f),.0004f);
            RoundedGeometry.Box(v,n,t,new Vector3(bounds.center.x,bounds.center.y-bounds.size.y*.35f,.057f),new Vector3(bounds.size.x*.82f,bounds.size.y*.07f,.003f),.0004f);
            return Finish(v,n,t,"Battery.UnfinishedGraySupports");
        }
        internal static Mesh Contacts(Bounds bounds)
        {
            var v=new List<Vector3>();var n=new List<Vector3>();var t=new List<int>();
            foreach(float sign in new[]{-1f,1f})
                RoundedGeometry.Box(v,n,t,new Vector3(bounds.center.x+sign*bounds.size.x*.30f,bounds.center.y-bounds.size.y*.30f,ApcBatteryRegion.DinFace+.0015f),new Vector3(bounds.size.x*.15f,bounds.size.y*.13f,.0015f),.0002f);
            return Finish(v,n,t,"Battery.CompletedGoldContacts");
        }
        private static Mesh Finish(List<Vector3> v,List<Vector3> n,List<int> t,string name)
        {
            var mesh=new Mesh{name=name};mesh.SetVertices(v);mesh.SetNormals(n);mesh.SetTriangles(t,0);mesh.RecalculateBounds();return mesh;
        }
    }
}
