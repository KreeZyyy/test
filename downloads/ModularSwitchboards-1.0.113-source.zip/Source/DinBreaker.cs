using System.Xml.Serialization;
using Assets.Scripts;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Networking;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Electrical;
using Assets.Scripts.Localization2;
using Assets.Scripts.UI;
using LibConstruct;
using UnityEngine;

namespace ModularSwitchboards
{
    public sealed class DinBreakerSaveData : StructureSaveData
    {
        [XmlElement] public PlacementBoardStructureSaveData RailBoard;
        [XmlElement] public bool Tripped;
        [XmlElement] public int BodyPaintVersion;
        [XmlElement] public int BatteryConstructionVersion;
    }

    public sealed class DinBreaker : Structure, IPlacementBoardStructure
    {
        public float RatedWatts=1000f;
        public bool IsContactor;
        public bool HasNormallyClosedContact;
        public bool ContactorClosed;
        public bool IsFuseHolder;
        public bool IsBatteryModule;
        public bool IsAnalyserModule;
        public bool IsSmartModule;
        public bool IsSmartOutputModule;
        public bool IsDoorLed;
        public bool IsDoorStop;
        public bool IsDoorIsolator;
        public bool IsDoorRoundSwitch;
        public bool DoorLit;
        public bool IsDoorBridge;
        internal bool IsDoorPart=>IsDoorLed||IsDoorStop||IsDoorIsolator||IsDoorBridge;
        public Assets.Scripts.Objects.Items.BatteryCell Battery=>IsBatteryModule&&IsStructureCompleted&&Slots.Count==1?Slots[0].Get() as Assets.Scripts.Objects.Items.BatteryCell:null;
        public int[] AllowedFuseKits=new int[0];
        public bool Tripped;
        private const ushort ModuleUpdate=32768;
        // Transient event sequence; join establishes a silent baseline. Never saved.
        private int fuseBurnSequence;
        public bool Conducting=>!IsBeingDestroyed&&(!IsBatteryModule||IsStructureCompleted)&&!IsSmartOutputModule&&(IsContactor?ContactorClosed:(IsDoorStop?!OnOff:(IsDoorBridge||IsDoorLed||IsBatteryModule||IsAnalyserModule|| (IsFuseHolder?!Tripped&&Slots.Count==1&&Slots[0].Get() is MultiConstructor kit&&kit.Quantity==1&&System.Array.IndexOf(AllowedFuseKits,kit.PrefabHash)>=0:OnOff))));
        internal void Trip()
        {
            if(!GameManager.RunSimulation||IsContactor||IsDoorBridge||IsDoorLed||IsDoorStop||IsDoorIsolator||IsBatteryModule||IsAnalyserModule||!Conducting)return;
            if(IsFuseHolder){var kit=Slots[0].Get() as MultiConstructor;if(kit!=null)kit.RemoveQuantity(1);}
            else {OnOff=false;}
            Tripped=true;NetworkUpdateFlags|=ModuleUpdate;
            if(IsFuseHolder){fuseBurnSequence=unchecked(fuseBurnSequence+1);DinFuseAudio.Play(this);}
        }
        public PlacementBoard Board { get; set; }
        public PlacementBoard.BoardCell[] BoardCells { get; set; }
        public override void Awake()
        {
            base.Awake();
            BoardStructureHooks.Awake(this);
            DinBreakerModel.Refresh(this);
            if(IsFuseHolder&&Slots.Count==1)Slots[0].OnEnter+=()=>{if(GameManager.RunSimulation){Tripped=false;NetworkUpdateFlags|=ModuleUpdate;}};
        }
        public override void UpdateStateVisualizer(bool visualOnly=false)
        {
            base.UpdateStateVisualizer(visualOnly);
            if(IsBatteryModule&&CurrentBuildStateIndex>=0&&!IsCursor&&transform.Find("DinBreakerModel")!=null)
                FittedModelCollider.Rebuild(this);
        }
        public override Grid3 GetLocalGrid() => Board == null ? default(Grid3) : Board.WorldToGrid(Transform.position);

        public int ModuleWidth => IsSmartModule?DinSmartLayout.Slots:IsAnalyserModule?3:IsBatteryModule?DinBatteryLayout.Slots:1;
        internal float ContactOffsetX=>IsSmartModule?DinSmartLayout.CenterX:IsAnalyserModule?DinAnalyserLayout.CenterX:IsBatteryModule?DinBatteryLayout.CenterX:0f;
        internal static bool CanPlace(PlacementBoard board, Grid3 position, int rotation,int width=1)
            => board is DinModuleBoard modules && modules.CanPlace(position, rotation, width);
        public override PassiveTooltip GetPassiveTooltip(Collider hitCollider)
        {
            if(IsContactor){var tip=base.GetPassiveTooltip(hitCollider);tip.Extended=(HasNormallyClosedContact?(ContactorClosed?"Coil energized — IN connected to NO; NC open.":"Coil released — IN connected to NC; NO open."):(ContactorClosed?"Coil energized — IN connected to OUT.":"Coil released — circuit open."))+" A1 controls the coil only. No overload protection.";return tip;}
            if(IsSmartOutputModule){var tip=base.GetPassiveTooltip(hitCollider);var core=SmartBus.Core(this);tip.Extended=core==null?"Disconnected Smart bus. Attach on the left of a Core or its extensions.":"Side bus: "+core.DisplayName+". "+(SmartOutputStatus.Light(this)==SmartOutputLight.Off?"LED off: Core is off or unpowered.":SmartOutputStatus.Connected(this)?"Green: data network connected.":"Orange: no data network selected; check DATA wiring and the external cable.")+" No power transfer.";return tip;}
            if(IsDoorIsolator){var tip=base.GetPassiveTooltip(hitCollider);tip.Extended=OnOff?"I — ON. IN connected to OUT. No overload protection.":"0 — OFF. Circuit open.";return tip;}
            if(IsDoorStop){var stopTip=base.GetPassiveTooltip(hitCollider);stopTip.Extended=OnOff?"STOP — circuit open. Hold to twist and reset.":"Ready — IN connected to OUT. Press to stop.";return stopTip;}
            if(IsDoorLed){var tip=base.GetPassiveTooltip(hitCollider);tip.Extended=(DoorLit?"Powered":"No power")+" — IN supplies the lamp; OUT is optional.";return tip;}
            if(IsAnalyserModule)return DinAnalyserModel.Tooltip(this,base.GetPassiveTooltip(hitCollider));
            if(IsBatteryModule&&hitCollider!=null)return base.GetPassiveTooltip(hitCollider);
            var tooltip=base.GetPassiveTooltip(hitCollider);
            if(IsBatteryModule)
            {
                tooltip.Title=DisplayName;
                tooltip.Extended=(Battery==null?"No battery installed.":"Battery: "+(Battery.PowerRatio*100f).ToString("0")+"%")+"\nCharges up to 1 kW from IN; automatic backup to OUT.";
            }
            return tooltip;
        }
        public override string GetContextualName(Interactable interactable)
        {
            if(IsDoorIsolator&&interactable.Action==InteractableType.OnOff)return DoorIsolatorControl.ActionName(OnOff);
            if(IsDoorStop&&interactable.Action==InteractableType.OnOff)return DoorStopControl.ActionName(OnOff);
            if(IsBatteryModule)return base.GetContextualName(interactable);
            if(IsFuseHolder&&interactable.Action==InteractableType.Slot1)return (Tripped?"Remove blown fuse":Conducting?"Remove fuse":"Insert fuse")+" — "+DinModuleCatalog.Rating(RatedWatts);
            if(!IsFuseHolder&&interactable.Action==InteractableType.OnOff)return (Tripped?"Reset":OnOff?"Switch OFF":"Switch ON")+" — "+DinModuleCatalog.Rating(RatedWatts);
            return base.GetContextualName(interactable);
        }
        public override DelayedActionInstance HandleSwitch(Interaction interaction,int slot,DelayedActionInstance result,bool doAction=true,bool force=false)
        {
            if(IsBatteryModule&&!IsStructureCompleted)return result.Fail("Complete the battery holder with 1 g Gold first.");
            if(IsBatteryModule&&(!(Board?.PrimaryHost is DinRail batteryRail)||!batteryRail.CanAccessModules))return result.Fail("Open the cabinet first.");
            if(!IsFuseHolder||slot!=0)return base.HandleSwitch(interaction,slot,result,doAction,force);
            if(!(Board?.PrimaryHost is DinRail rail)||!rail.CanAccessModules)return result.Fail("Open the cabinet first.");
            var source=interaction.SourceSlot;var destination=Slots[0];
            if(Tripped)
            {
                result.ActionMessage="Remove blown fuse";
                if(doAction&&GameManager.RunSimulation)
                {
                    // The cartridge was already consumed on blowing. Its broken
                    // model remains until this explicit removal, with no usable refund.
                    if(destination.Get()!=null)return result.Fail("Remove the remaining cartridge first.");
                    Tripped=false;NetworkUpdateFlags|=ModuleUpdate;
                }
                return result.Succeed();
            }
            if(destination.Get()!=null)
            {
                if(source?.Get()==null)return base.HandleSwitch(interaction,slot,result,doAction,force);
                if(!(source.Get() is MultiConstructor held)||!(destination.Get() is MultiConstructor installed)||
                    installed.Quantity!=1||held==installed||!held.CanStack(installed))
                    return result.Fail("Use an empty hand or hold the same Cable Fuse kit to remove the fuse.");
                if(held.Quantity>=held.MaxQuantity)return result.Fail("The fuse stack in your hand is full.");
                result.ActionMessage="Take fuse into stack";
                if(doAction&&GameManager.RunSimulation)
                {
                    // Native merge handles quantity replication, slot exit and destruction
                    // of the consumed one-unit stack. Never manufacture a refund item.
                    int before=held.Quantity;held.Merge(installed);
                    if(held.Quantity!=before+1)return result.Fail("Could not merge the fuse into your stack.");
                }
                return result.Succeed();
            }
            if(!(source?.Get() is MultiConstructor kit)||kit.Quantity<1||System.Array.IndexOf(AllowedFuseKits,kit.PrefabHash)<0)
                return result.Fail("Hold the matching Cable Fuse kit; one unit will be inserted.");
            result.ActionMessage="Insert one fuse";
            if(doAction&&GameManager.RunSimulation)
            {
                if(kit.Quantity==1){OnServer.MoveToSlot(kit,destination);if(destination.Get()!=kit)return result.Fail("Fuse slot is unavailable.");}
                else
                {
                    var one=kit.SplitStack(1,destination);
                    if(one==null){kit.AddQuantity(1);return result.Fail("Could not create the fuse cartridge.");}
                    if(destination.Get()!=one)OnServer.MoveToSlot(one,destination);
                    if(destination.Get()!=one){kit.AddQuantity(1);OnServer.Destroy(one);return result.Fail("Fuse slot is unavailable.");}
                }
            }
            return result.Succeed();
        }
        public override CanConstructInfo CanConstruct()
        {
            if(IsDoorPart)return DoorModules.CanConstruct(this);
            if ((IsCursor && PlacementBoard.CursorBoard != Board) || !(Board is DinModuleBoard modules)) return CanConstructInfo.InvalidPlacement("Aim at an installed DIN rail inside an open cabinet.");
            var position = Board.WorldToGrid(Transform.position);
            if (IsCursor)
            {
                position = new Grid3(DoorModuleLayout.SnapSlot(position.x, DinLayout.FirstModuleSlot*10, (DinLayout.FirstModuleSlot+((DinRail)modules.PrimaryHost).ModuleCapacity - ModuleWidth) * 10), 0, 0);
                if(IsSmartOutputModule)
                {
                    var target=CursorManager.Instance?.CursorTargetCollider?.GetComponentInParent<Thing>()??CursorManager.Instance?.FoundThing;
                    var preferred=target as SmartModule;
                    if(target is DinBreaker attached&&attached.IsSmartOutputModule)
                    {
                        preferred=SmartBus.Core(attached);
                        if(preferred==null)return CanConstructInfo.InvalidPlacement("This extension has no Core. Repair the bus from the connected side first.");
                    }
                    var next=SmartBus.NextPosition(modules,position,preferred);
                    if(next==null)return CanConstructInfo.InvalidPlacement("No free position directly left of a Smart Core or its extensions.");
                    position=next.Value;
                }
                PlacementBoard.CursorGrid = position;
                PlacementBoard.CursorRotation = 0;
                Transform.SetPositionAndRotation(Board.GridToWorld(position), Board.IndexToRotation(0));
            }
            if(IsSmartOutputModule)return SmartBus.CanPlace(modules,position,Board.RotationToIndex(Transform.rotation))?CanConstructInfo.ValidPlacement:CanConstructInfo.InvalidPlacement("Attach directly left of a Smart Core or its continuous extension row.");
            return CanPlace(Board, position, Board.RotationToIndex(Transform.rotation),ModuleWidth)
                ? CanConstructInfo.ValidPlacement : CanConstructInfo.InvalidPlacement("Choose a free module position on an installed rail.");
        }
        protected override CanConstructInfo CanDeconstruct()
            => IsSmartOutputModule&&SmartBus.HasLeftNeighbour(this,ModuleWidth)?CanConstructInfo.InvalidPlacement("Remove Smart extensions from the left end first."):IsDoorPart?DoorModules.CanDeconstruct(this):(IsFuseHolder||IsBatteryModule)&&HasOccupiedSlot?CanConstructInfo.InvalidPlacement("Remove the battery or fuse first."):!ModuleDismantle.CanRefund(this)?CanConstructInfo.InvalidPlacement("Cable coil prefab unavailable."):Board?.PrimaryHost is DinRail host && host.CanFitModules
                ? CanConstructInfo.ValidPlacement : CanConstructInfo.InvalidPlacement("Open the cabinet first.");
        public override DelayedActionInstance AttackWith(Attack attack, bool doAction = true)
        {
            var cabinet=CabinetWiring.CabinetOf(this);
            if(cabinet!=null&&cabinet.Wiring.TryAttack(attack,doAction,out var wireAction))return wireAction;
            if(IsDoorPart)return cabinet!=null&&cabinet.CanAccessModules?base.AttackWith(attack,doAction):null;
            if (!(Board?.PrimaryHost is DinRail host) || !host.CanFitModules) return null;
            return base.AttackWith(attack, doAction);
        }
        public override bool PreventInteraction(out DelayedActionInstance failResult, Interactable interactable, Interaction interaction)
        {
            if(IsDoorIsolator&&interactable.Action==InteractableType.OnOff)
            {
                if(!DoorIsolatorControl.CanUse(this)){failResult=new DelayedActionInstance{Duration=0}.Fail("Install the switch on a completed door first.");return true;}
                return base.PreventInteraction(out failResult,interactable,interaction);
            }
            if(IsDoorStop&&interactable.Action==InteractableType.OnOff)
            {
                if(!DoorStopControl.CanUse(this)){failResult=new DelayedActionInstance{Duration=0}.Fail("Install the TOTAL STOP on a completed door first.");return true;}
                return base.PreventInteraction(out failResult,interactable,interaction);
            }
            if ((interactable.Action == InteractableType.OnOff || interactable.Action == InteractableType.Slot1) &&
                (!(Board?.PrimaryHost is DinRail rail) || !rail.CanAccessModules))
            {
                failResult = new DelayedActionInstance { Duration=0f, ActionMessage="Open the cabinet first." }.Fail();
                return true;
            }
            return base.PreventInteraction(out failResult, interactable, interaction);
        }
        public override DelayedActionInstance InteractWith(Interactable interactable, Interaction interaction, bool doAction=true)
        {
            if(IsDoorIsolator&&interactable.Action==InteractableType.OnOff)return DoorIsolatorControl.Interact(this,interactable,doAction);
            if(IsDoorStop&&interactable.Action==InteractableType.OnOff)return DoorStopControl.Interact(this,interactable,doAction);
            if ((interactable.Action==InteractableType.OnOff || interactable.Action==InteractableType.Slot1) &&
                (!(Board?.PrimaryHost is DinRail rail) || !rail.CanAccessModules))
                return new DelayedActionInstance { Duration=0f, ActionMessage="Open the cabinet first." }.Fail();
            var result=base.InteractWith(interactable, interaction, doAction);
            if(doAction&&GameManager.RunSimulation&&interactable.Action==InteractableType.OnOff&&OnOff){Tripped=false;NetworkUpdateFlags|=ModuleUpdate;}
            return result;
        }
        public override void BuildUpdate(RocketBinaryWriter writer,ushort flags){base.BuildUpdate(writer,flags);if(Thing.IsNetworkUpdateRequired(ModuleUpdate,flags)){writer.WriteBoolean(Tripped);writer.WriteBoolean(IsDoorLed?DoorLit:IsContactor?ContactorClosed:!IsFuseHolder&&OnOff);writer.WriteInt32(fuseBurnSequence);}}
        public override void ProcessUpdate(RocketBinaryReader reader,ushort flags)
        {
            base.ProcessUpdate(reader,flags);
            if(Thing.IsNetworkUpdateRequired(ModuleUpdate,flags))
            {
                Tripped=reader.ReadBoolean();bool on=reader.ReadBoolean();if(IsDoorLed)DoorLit=on;else if(IsContactor)ContactorClosed=on;else if(!IsFuseHolder)OnOff=on;
                int incoming=reader.ReadInt32();
                uint advance=unchecked((uint)(incoming-fuseBurnSequence));
                // Duplicate/older updates must not replay a burn. This also notices
                // a new cartridge burning when both snapshots already say Tripped.
                if(advance!=0&&advance<0x80000000u)
                {
                    fuseBurnSequence=incoming;
                    if(!GameManager.RunSimulation)DinFuseAudio.Play(this);
                }
            }
        }
        public override void OnDeregistered()
        {
            CabinetWiring.CabinetOf(this)?.Wiring.RemoveBreaker(ReferenceId);
            base.OnDeregistered();
            if (Board != null) BoardStructureHooks.OnDeregistered(this);
        }
        public override ThingSaveData SerializeSave()
        {
            ThingSaveData data = new DinBreakerSaveData();
            InitialiseSaveData(ref data);
            return data;
        }
        protected override void InitialiseSaveData(ref ThingSaveData data)
        {
            base.InitialiseSaveData(ref data);
            if (data is DinBreakerSaveData save){save.Tripped=Tripped;save.BodyPaintVersion=1;if(IsBatteryModule)save.BatteryConstructionVersion=1;if(Board!=null)save.RailBoard=BoardStructureHooks.SerializeSave(this);}
        }
        public override void DeserializeSave(ThingSaveData data)
        {
            if(IsBatteryModule&&data is DinBreakerSaveData old&&old.BatteryConstructionVersion<1&&old.CurrentBuildState==0)old.CurrentBuildState=1;
            base.DeserializeSave(data);
            if(IsContactor)ContactorClosed=false;
            if (data is DinBreakerSaveData save){Tripped=save.Tripped;if(save.RailBoard!=null)BoardStructureHooks.DeserializeSave(this,save.RailBoard);}
        }
        public override void SerializeOnJoin(RocketBinaryWriter writer)
        {
            base.SerializeOnJoin(writer);
            BoardStructureHooks.SerializeOnJoin(writer, this);writer.WriteBoolean(Tripped);writer.WriteInt32(fuseBurnSequence);writer.WriteBoolean(IsDoorLed&&DoorLit);if(IsContactor)writer.WriteBoolean(ContactorClosed);
        }
        public override void DeserializeOnJoin(RocketBinaryReader reader)
        {
            base.DeserializeOnJoin(reader);
            BoardStructureHooks.DeserializeOnJoin(reader, this);Tripped=reader.ReadBoolean();fuseBurnSequence=reader.ReadInt32();bool led=reader.ReadBoolean();if(IsDoorLed)DoorLit=led;if(IsContactor)ContactorClosed=reader.ReadBoolean();
        }
    }
}
