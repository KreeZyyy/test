using System.Collections.Generic;
using System.Linq;
using Assets.Scripts.Objects;
using HarmonyLib;
using Rendering;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class DinBatteryConstruction
    {
        private static Material bareMaterial,goldMaterial;
        private static Material BareMaterial=>bareMaterial??(bareMaterial=Surface("Switchboards.Battery.BareGray",new Color(.38f,.40f,.40f),.15f));
        private static Material GoldMaterial=>goldMaterial??(goldMaterial=Surface("Switchboards.Battery.GoldContacts",new Color(.95f,.64f,.12f),.85f));
        private static Material Surface(string name,Color color,float metal)
        {
            var material=new Material(Shader.Find("Standard")){name=name,color=color};material.SetFloat("_Metallic",metal);material.SetFloat("_Glossiness",.35f);return material;
        }
        private static MeshRenderer Part(DinBreaker owner,Transform model,string name,Mesh mesh,Material material)
        {
            var go=new GameObject(name){layer=owner.gameObject.layer};go.transform.SetParent(model,false);
            go.AddComponent<MeshFilter>().sharedMesh=mesh;var renderer=go.AddComponent<MeshRenderer>();renderer.sharedMaterial=material;return renderer;
        }
        internal static void Install(DinBreaker owner)
        {
            var model=owner.transform.Find("DinBreakerModel");
            var holder=model.Find("OriginalAPCHolderMount");
            var control=model.Find("BatteryControl");
            var bay=holder.GetComponentInChildren<MeshRenderer>(true);
            var bare=Part(owner,model,"BatteryBareMounts",DinBatteryStageGeometry.Bare(ApcBatteryGeometry.HitBounds),BareMaterial);
            var contacts=Part(owner,model,"BatteryGoldContacts",DinBatteryStageGeometry.Contacts(ApcBatteryGeometry.HitBounds),GoldMaterial);
            var frame=owner.BuildStates[0];var finished=owner.BuildStates[1];
            frame.RenderMode=BuildStateRenderMode.OnMineAndPreviousStates;
            frame.Interactables=new List<Interactable>();
            frame.Colliders=frame.Colliders.Where(c=>c!=control.GetComponent<Collider>()).ToList();
            frame.LinkedGameObjects=new List<GameObject>{model.gameObject,bare.gameObject};
            foreach(var hit in frame.Colliders)if(hit!=null&&!frame.LinkedGameObjects.Contains(hit.gameObject))frame.LinkedGameObjects.Add(hit.gameObject);
            finished.Visualizer=bay;finished.RendererInstance=null;finished.StateMeshes=new List<Mesh>();
            finished.RenderMode=BuildStateRenderMode.OnMyState;
            finished.LinkedGameObjects=frame.LinkedGameObjects.Where(g=>g!=bare.gameObject).Concat(new[]{holder.gameObject,control.gameObject,contacts.gameObject}).ToList();
            finished.Colliders=new List<Collider>(frame.Colliders){control.GetComponent<Collider>()};
            finished.Interactables=owner.Interactables;
            owner.Thumbnail=CabinetIcons.Get("DinBatteryFinished");frame.Thumbnail=CabinetIcons.Get("DinBatteryUnfinished");finished.Thumbnail=owner.Thumbnail;
            AccessTools.Field(typeof(BuildState),"initialDrawData").SetValue(finished,new DrawData{mesh=null,materials=new Material[0]});
            bare.gameObject.SetActive(false);
            ModelBlueprint.Refresh(owner);
            bare.gameObject.SetActive(true);
            owner.CacheStates(true);
            // Prefabs are state -1: do not invoke native stage visualization here.
        }
    }
}
