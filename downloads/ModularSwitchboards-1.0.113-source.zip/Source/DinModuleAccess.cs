using System.Linq;
using Assets.Scripts.Objects;
using UnityEngine;
using Rendering;
using Assets.Scripts.UI;

namespace ModularSwitchboards
{
    internal static class DinModuleAccess
    {
        internal static bool SlotName(Slot slot,ref string __result)
        {
            if(!(slot?.Parent is DinBreaker module)||!module.IsFuseHolder)return true;
            __result="Cable Fuse";return false;
        }
        internal static bool CanEnter(Thing __instance,Slot destinationSlot,ref CanEnterResult __result)
        {
            if(destinationSlot?.Parent is SmartModule smart&&!LibConstruct.PlacementBoard.Loading&&smart.Cabinet?.CanAccessModules!=true)
            {__result=CanEnterResult.Fail("Open the cabinet and remove the cover first.");return false;}
            if(destinationSlot?.Parent is DinBreaker battery&&battery.IsBatteryModule&&!LibConstruct.PlacementBoard.Loading&&
                (!battery.IsStructureCompleted||!(battery.Board?.PrimaryHost is DinRail batteryRail)||!batteryRail.CanAccessModules))
            {__result=CanEnterResult.Fail("Complete the battery holder and open the cabinet before inserting a cell.");return false;}
            if(!(destinationSlot?.Parent is DinBreaker module)||!module.IsFuseHolder)return true;
            if((!LibConstruct.PlacementBoard.Loading&&(module.Tripped||!(module.Board?.PrimaryHost is DinRail rail)||!rail.CanAccessModules))||!(__instance is MultiConstructor kit)||kit.Quantity!=1||!module.AllowedFuseKits.Contains(kit.PrefabHash))
            {__result=CanEnterResult.Fail("Open the cabinet and insert one unit of the matching Cable Fuse kit.");return false;}
            return true;
        }
        internal static void Install(DinBreaker module)
        {
            var model=module.transform.Find("DinBreakerModel");
            if(module.IsFuseHolder)
            {
                var view=module.GetComponent<BreakerSwitchView>();if(view!=null)Object.DestroyImmediate(view);
                var lever=model.Find("BreakerLever");if(lever!=null)Object.DestroyImmediate(lever.gameObject);
                var control=model.Find("BreakerControl");var hit=control.GetComponent<BoxCollider>();
                var indicator=model.Find("BreakerIndicator");if(indicator!=null)Object.DestroyImmediate(indicator.gameObject);
                var housing=DinFuseModel.Housing();
                model.GetComponent<MeshFilter>().sharedMesh=housing;
                // The initial breaker box includes its spindle bearings. Refit
                // it after replacing the mesh so it cannot hide the fuse target.
                var housingCollider=model.GetComponent<BoxCollider>();
                housingCollider.center=housing.bounds.center;housingCollider.size=housing.bounds.size;
                var contacts=new GameObject("FuseContacts"){layer=module.gameObject.layer};contacts.transform.SetParent(model,false);
                contacts.AddComponent<MeshFilter>().sharedMesh=DinFuseModel.Contacts();
                var contactRenderer=contacts.AddComponent<MeshRenderer>();contactRenderer.sharedMaterials=CabinetGeometry.Materials;
                contactRenderer.receiveShadows=false;
                contactRenderer.lightProbeUsage=UnityEngine.Rendering.LightProbeUsage.BlendProbes;
                contactRenderer.reflectionProbeUsage=UnityEngine.Rendering.ReflectionProbeUsage.BlendProbes;
                var intact=new GameObject("IntactFuse"){layer=module.gameObject.layer};intact.transform.SetParent(model,false);
                intact.AddComponent<MeshFilter>().sharedMesh=DinFuseModel.Cartridge(false);intact.AddComponent<MeshRenderer>().sharedMaterials=CabinetGeometry.Materials;intact.SetActive(false);
                var burnt=new GameObject("BurntFuse"){layer=module.gameObject.layer};burnt.transform.SetParent(model,false);
                burnt.AddComponent<MeshFilter>().sharedMesh=DinFuseModel.Cartridge(true);burnt.AddComponent<MeshRenderer>().sharedMaterials=CabinetGeometry.Materials;burnt.SetActive(false);
                var caps=new GameObject("FuseCaps"){layer=module.gameObject.layer};caps.transform.SetParent(model,false);
                caps.AddComponent<MeshFilter>().sharedMesh=DinFuseModel.Caps();caps.AddComponent<MeshRenderer>().sharedMaterials=DinFuseModel.CapMaterials();caps.SetActive(false);
                var fuseView=module.gameObject.AddComponent<DinFuseView>();fuseView.Owner=module;fuseView.Intact=intact;fuseView.Burnt=burnt;fuseView.Caps=caps;
                var ghost=module.Blueprint.GetComponent<MeshFilter>().sharedMesh;
                var pieces=new System.Collections.Generic.List<CombineInstance>();var body=model.GetComponent<MeshFilter>().sharedMesh;
                foreach(int role in new[]{1,3,4})pieces.Add(new CombineInstance{mesh=body,subMeshIndex=role,transform=Matrix4x4.Scale(model.localScale)});
                pieces.Add(new CombineInstance{mesh=contacts.GetComponent<MeshFilter>().sharedMesh,subMeshIndex=4,transform=Matrix4x4.Scale(model.localScale)});
                ghost.Clear();ghost.CombineMeshes(pieces.ToArray(),true,true);ghost.RecalculateBounds();
                var wire=module.Blueprint.GetComponent<Wireframe>();wire.BlueprintBounds=ghost.bounds;
                var toggle=new Interactable{Parent=module,Action=InteractableType.Slot1,Collider=hit,JoinInProgressSync=true,CanKeyInteract=true,KeyMap="PrimaryAction"};
                toggle.CacheBounds();
                var location=new GameObject("FuseContents").transform;location.SetParent(model,false);location.localPosition=new Vector3(0,0,.07f);
                module.Slots=new System.Collections.Generic.List<Slot>{new Slot{Parent=module,StringKey="Cable Fuse",Type=Slot.Class.None,SpecificTypePrefabHashes=module.AllowedFuseKits,
                    Location=location,HidesOccupant=true,IsSwappable=false,Action=InteractableType.Slot1,Collider=hit,Interactable=toggle}};
                module.Interactables=new System.Collections.Generic.List<Interactable>{toggle};module.HasOnOffState=false;
                module.BuildStates[0].Interactables=new System.Collections.Generic.List<Interactable>{toggle};
            }
        }
    }
}
