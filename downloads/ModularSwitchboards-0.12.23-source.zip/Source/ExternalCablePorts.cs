using System;
using System.Collections.Generic;
using System.Linq;
using Assets.Scripts;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Electrical;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Util;
using UnityEngine;
using UnityEngine.Rendering;

namespace ModularSwitchboards
{
    internal static class ExternalPortLayout
    {
        internal static readonly Vector3[] Positions={new Vector3(0,.5f,-CabinetModel.MountOffset),new Vector3(-.5f,-.5f,-CabinetModel.MountOffset),new Vector3(.5f,-.5f,-CabinetModel.MountOffset)};
        internal static readonly Vector3[] Directions={Vector3.up,Vector3.left,Vector3.right};
        internal static readonly ConnectionRole[] Roles={ConnectionRole.Input,ConnectionRole.Output,ConnectionRole.Output2};
    }

    public sealed class NativePortSurface : MonoBehaviour
    {
        public int TemplateIndex;
        private sealed class Surface {internal Material[] Materials;internal MaterialPropertyBlock[] Blocks;}
        private static readonly List<Surface> Templates=new List<Surface>();
        internal static void Capture(Renderer source,MeshRenderer destination)
        {
            var materials=source.sharedMaterials;var blocks=new MaterialPropertyBlock[materials.Length];
            var global=new MaterialPropertyBlock();source.GetPropertyBlock(global);
            for(int i=0;i<blocks.Length;i++){var block=new MaterialPropertyBlock();source.GetPropertyBlock(block,i);blocks[i]=block.isEmpty?global:block;}
            var marker=destination.gameObject.AddComponent<NativePortSurface>();marker.TemplateIndex=Templates.Count;
            Templates.Add(new Surface{Materials=materials,Blocks=blocks});marker.Restore();
        }
        internal void Restore()
        {
            if(TemplateIndex<0||TemplateIndex>=Templates.Count)return;
            var renderer=GetComponent<MeshRenderer>();var surface=Templates[TemplateIndex];renderer.sharedMaterials=surface.Materials;
            for(int i=0;i<surface.Blocks.Length;i++)renderer.SetPropertyBlock(surface.Blocks[i],i);
        }
    }

    internal static class ExternalCablePorts
    {
        private sealed class Part {internal Mesh Mesh;internal MeshRenderer Source;}
        private sealed class Template {internal Connection Source;internal bool ForwardInward;internal Matrix4x4 SourceFrame;internal Vector3 GridRemainder;internal Bounds Region;internal List<Part> Parts=new List<Part>();}
        private static readonly Dictionary<Connection,Template> NativeTemplates=new Dictionary<Connection,Template>();
        private static Template Read(AreaPowerControl apc,Connection connection)
        {
            if(connection?.Transform==null)throw new InvalidOperationException("APC cable connection transform unavailable");
            if(NativeTemplates.TryGetValue(connection,out var cached))return cached;
            var center=apc.transform.TransformPoint(apc.Bounds.center);
            var result=new Template{Source=connection,ForwardInward=Vector3.Dot(connection.Transform.forward,center-connection.Transform.position)>0f};
            var frame=Matrix4x4.TRS(connection.Transform.position,connection.Transform.rotation,Vector3.one).inverse;
            var view=frame.MultiplyVector(apc.transform.forward*CabinetModel.FrontSign);view.z=0f;
            if(view.sqrMagnitude>.001f)frame=Matrix4x4.Rotate(Quaternion.Inverse(Quaternion.LookRotation(Vector3.forward,view.normalized)))*frame;
            result.SourceFrame=frame;
            var sourcePosition=apc.transform.InverseTransformPoint(connection.Transform.position);
            var sourceGrid=sourcePosition.ToGrid(SmallGrid.SmallGridSize,SmallGrid.SmallGridOffset).ToVector3();
            result.GridRemainder=frame.MultiplyVector(apc.transform.TransformVector(sourcePosition-sourceGrid));
            // Include the whole native lug from the electrical hitbox back to the body edge.
            Bounds? region=null;
            if(connection.Collider is BoxCollider sourceBox)
            {
                var nativeBounds=CabinetWallMount.TransformedBounds(new Bounds(sourceBox.center,sourceBox.size),frame*sourceBox.transform.localToWorldMatrix);
                nativeBounds.Expand(.025f);region=nativeBounds;
            }
            var crop=region??new Bounds(Vector3.zero,new Vector3(.15f,.15f,.3f));
            var door=apc.GetComponentsInChildren<MeshRenderer>(true).FirstOrDefault(r=>r.name=="Door");
            if(door!=null && door.GetComponent<MeshFilter>()?.sharedMesh!=null)
            {
                var doorBounds=CabinetWallMount.TransformedBounds(door.GetComponent<MeshFilter>().sharedMesh.bounds,frame*door.transform.localToWorldMatrix);
                var lo=crop.min;var hi=crop.max;
                if(result.ForwardInward)hi.z=Math.Max(hi.z,doorBounds.min.z+.003f);
                else lo.z=Math.Min(lo.z,doorBounds.max.z-.003f);
                crop.SetMinMax(lo,hi);
            }
            if(crop.size.z>.65f || crop.size.x>.3f || crop.size.y>.4f)throw new InvalidOperationException("Native APC connector crop unexpectedly includes body: "+crop);
            result.Region=crop;
            var renderers=apc.GetComponentsInChildren<MeshRenderer>(true)
                .Where(r=>r!=connection.HelperRenderer && r.name!="Door" && r.name!="MasterLever" && r.name.IndexOf("Destroyed",StringComparison.OrdinalIgnoreCase)<0).ToArray();
            foreach(var renderer in renderers)
            {
                var original=renderer.GetComponent<MeshFilter>()?.sharedMesh;if(original==null)continue;
                var mesh=NativeMeshCrop.Read(original,frame*renderer.transform.localToWorldMatrix,crop,"Switchboards.NativeAPCPort."+renderer.name);
                if(mesh!=null)result.Parts.Add(new Part{Mesh=mesh,Source=renderer});
            }
            if(result.Parts.Count==0 && connection.HelperRenderer is MeshRenderer helper)
            {
                var original=helper.GetComponent<MeshFilter>()?.sharedMesh;
                if(original!=null)
                {
                    CabinetGeometry.ReadNativeMesh(original,out var points,out var uv,out var triangles);
                    var matrix=frame*helper.transform.localToWorldMatrix;
                    for(int i=0;i<points.Length;i++)points[i]=matrix.MultiplyPoint3x4(points[i]);
                    var mesh=new Mesh{name="Switchboards.NativeCableConnectorHelper"};mesh.vertices=points;mesh.uv=uv;mesh.subMeshCount=triangles.Length;
                    for(int i=0;i<triangles.Length;i++)mesh.SetTriangles(triangles[i],i);
                    mesh.RecalculateNormals();mesh.RecalculateTangents();mesh.RecalculateBounds();
                    result.Parts.Add(new Part{Mesh=mesh,Source=helper});
                    Debug.LogWarning("[Modular Switchboards] APC port uses native helper geometry; inspect external connector appearance.");
                }
            }
            if(result.Parts.Count==0)throw new InvalidOperationException("No native APC cable connector geometry found");
            Debug.Log("[Modular Switchboards] Native APC connector captured: "+connection.ConnectionRole+"; parts="+result.Parts.Count+"; crop="+crop+"; native local position="+sourcePosition+"; native local grid="+sourceGrid+"; native axis="+connection.Transform.forward+"; forward inward="+result.ForwardInward);
            NativeTemplates[connection]=result;return result;
        }

        // The redesign exposes only the new top IN. Old output lugs stay disabled.
        internal static bool TryInstall(SwitchboardCabinet cabinet)
        {
            CabinetPowerInput.Install(cabinet);
            return true;
        }
        private static void Install(SwitchboardCabinet cabinet)
        {
            var apc=WorldManager.Instance.SourcePrefabs.OfType<AreaPowerControl>().FirstOrDefault(p=>p.PrefabName=="StructureAreaPowerControl")
                ?? WorldManager.Instance.SourcePrefabs.OfType<AreaPowerControl>().FirstOrDefault();
            if(apc==null)throw new InvalidOperationException("Native APC unavailable for external cable ports");
            var output=Read(apc,apc.OutputConnection);
            // Match APC cable coexistence instead of inheriting the locker's blocking flags.
            cabinet.SmallCollisionType=apc.SmallCollisionType;
            if(cabinet.PortBodyGrids==null)cabinet.PortBodyGrids=new[]{Vector3.zero.ToGrid(SmallGrid.SmallGridSize,SmallGrid.SmallGridOffset)};
            Debug.Log("[Modular Switchboards] Native APC collision mask reused: "+apc.SmallCollisionType);
            var shell=cabinet.transform.Find("SwitchboardModel/CompletedShell");
            var root=new GameObject("ExternalCablePorts"){layer=cabinet.gameObject.layer};root.transform.SetParent(shell,false);
            cabinet.OpenEnds=new List<Connection>();cabinet.UsedPower=0f;
            for(int i=0;i<3;i++)
            {
                var template=output; // Same complete native power lug, including the orange bolt, for all roles.
                var socket=NativeCableLayout.Read(ExternalPortLayout.Positions[i]+Vector3.forward*CabinetModel.MountOffset,ExternalPortLayout.Directions[i]);
                var go=new GameObject("NativeCablePort_"+ExternalPortLayout.Roles[i]){layer=cabinet.gameObject.layer};go.transform.SetParent(root.transform,false);
                go.transform.localRotation=Quaternion.LookRotation(socket.Forward,Vector3.forward);
                go.transform.localPosition=socket.Point-Vector3.forward*CabinetModel.MountOffset;
                // Logical nodes stay at native grid centres. Only the visible lug retains its
                // original subcell offset; mesh positioning must not change electrical matching.
                var visualFrame=new GameObject("NativeCableLug"){layer=cabinet.gameObject.layer};visualFrame.transform.SetParent(go.transform,false);
                visualFrame.transform.localPosition=template.GridRemainder;
                Debug.Log("[Modular Switchboards] Reciprocal cable socket "+ExternalPortLayout.Roles[i]+"; cable cell="+socket.CableCell+"; device cell="+socket.BodyCell+"; axis="+socket.Forward);
                Renderer helper=null;
                foreach(var part in template.Parts)
                {
                    var visual=new GameObject("NativeCablePortSurface"){layer=cabinet.gameObject.layer};visual.transform.SetParent(visualFrame.transform,false);
                    visual.AddComponent<MeshFilter>().sharedMesh=part.Mesh;
                    var renderer=visual.AddComponent<MeshRenderer>();NativePortSurface.Capture(part.Source,renderer);
                    renderer.lightProbeUsage=LightProbeUsage.BlendProbes;renderer.reflectionProbeUsage=ReflectionProbeUsage.BlendProbes;
                    renderer.shadowCastingMode=ShadowCastingMode.On;renderer.receiveShadows=true;
                    if(part.Source==template.Source.HelperRenderer)helper=renderer;
                }
                var hit=visualFrame.AddComponent<BoxCollider>();
                if(template.Source.Collider is BoxCollider box)
                {
                    var matrix=template.SourceFrame*box.transform.localToWorldMatrix;
                    var bounds=CabinetWallMount.TransformedBounds(new Bounds(box.center,box.size),matrix);hit.center=bounds.center;hit.size=bounds.size;
                }
                else {hit.center=new Vector3(0,0,-.02f);hit.size=new Vector3(.07f,.07f,.08f);}
                cabinet.OpenEnds.Add(new Connection(cabinet){Transform=go.transform,Collider=hit,HelperRenderer=helper,ConnectionType=cabinet.IsStructureCompleted?NetworkType.Power:NetworkType.None,ConnectionRole=ExternalPortLayout.Roles[i]});
                cabinet.BuildStates[1].Colliders.Add(hit);
            }
            AlignToGrid(cabinet);CabinetModel.SetBounds(cabinet);
            Debug.Log("[Modular Switchboards] External ports installed: top Input; lower Output/Output2; independent cells, no internal power bridge.");
        }
        internal static Bounds VisualBounds(int index)
        {
            var apc=WorldManager.Instance.SourcePrefabs.OfType<AreaPowerControl>().First(p=>p.PrefabName=="StructureAreaPowerControl");
            var template=Read(apc,apc.OutputConnection);
            var socket=NativeCableLayout.Read(ExternalPortLayout.Positions[index]+Vector3.forward*CabinetModel.MountOffset,ExternalPortLayout.Directions[index]);
            var q=Quaternion.LookRotation(socket.Forward,Vector3.forward);
            var pose=Matrix4x4.TRS(socket.Point-Vector3.forward*CabinetModel.MountOffset+q*template.GridRemainder,q,Vector3.one);
            var bounds=CabinetWallMount.TransformedBounds(template.Parts[0].Mesh.bounds,pose);
            foreach(var part in template.Parts)bounds.Encapsulate(CabinetWallMount.TransformedBounds(part.Mesh.bounds,pose));
            return bounds;
        }
        // Rear casing deliberately disabled for the redesign.
        internal static void InstallRearBody(SwitchboardCabinet cabinet) { }
        internal static void AlignToGrid(Structure cabinet)
        {
            foreach(var name in new[]{"ExternalCablePorts","RearCableCasing"})
            {
                var root=cabinet.transform.Find("SwitchboardModel/CompletedShell/"+name);if(root==null)continue;
                var offset=root.parent.InverseTransformPoint(cabinet.transform.position)+Vector3.forward*CabinetModel.MountOffset;
                root.localPosition=offset;
                var neck=root.Find("WallNeck");
                if(neck!=null)
                {
                    float depth=Mathf.Max(.001f,CabinetModel.MountOffset-offset.z);
                    neck.localScale=new Vector3(1,1,depth/CabinetModel.MountOffset);
                    neck.localPosition=new Vector3(0,0,depth-CabinetModel.MountOffset);
                }
            }
            if(cabinet is SmallGrid grid && grid.GridController!=null)
                foreach(var port in grid.OpenEnds){port.Parent=grid;port.Validate();port.SetGrids();}
        }
        internal static void IncludeBounds(Structure cabinet,ref Bounds bounds)
        {
            foreach(var name in new[]{"ExternalCablePorts","RearCableCasing"})
            {
            var root=cabinet.transform.Find("SwitchboardModel/CompletedShell/"+name);if(root==null)continue;
            foreach(var filter in root.GetComponentsInChildren<MeshFilter>(true))
                if(filter.sharedMesh!=null)bounds.Encapsulate(CabinetWallMount.TransformedBounds(filter.sharedMesh.bounds,cabinet.transform.worldToLocalMatrix*filter.transform.localToWorldMatrix));
            }
        }
    }
}
