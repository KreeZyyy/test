using System;using System.Linq;using System.Collections.Generic;using UnityEngine;
namespace ModularSwitchboards {
 internal static class DoorDisplayContour {
  // Captured native LED silhouette for offline authoring; prefab setup replaces
  // it with the currently installed game's actual transformed bezel contour.
  private static Vector3[] ring=new[]{new Vector3(-0.03417195f,-0.01178264f,0),new Vector3(-0.03118700f,-0.01893825f,0),new Vector3(-0.02589996f,-0.02418809f,0),new Vector3(-0.01869367f,-0.02715205f,0),new Vector3(0.11869367f,-0.02715205f,0),new Vector3(0.12589995f,-0.02418809f,0),new Vector3(0.12714003f,-0.02295676f,0),new Vector3(0.13118699f,-0.01893825f,0),new Vector3(0.13417194f,-0.01178264f,0),new Vector3(0.13417197f,0.00590176f,0),new Vector3(0.13417197f,0.01132057f,0),new Vector3(0.13118703f,0.01847620f,0),new Vector3(0.12589997f,0.02372605f,0),new Vector3(0.11869368f,0.02669002f,0),new Vector3(-0.01869368f,0.02669002f,0),new Vector3(-0.02589998f,0.02372605f,0),new Vector3(-0.03118701f,0.01847620f,0),new Vector3(-0.03417195f,0.01132058f,0)};
  private static Vector3[] led=new[]{new Vector3(-0.02500000f,0.01584313f,0),new Vector3(-0.02500000f,-0.01630517f,0),new Vector3(-0.02230174f,-0.01898446f,0),new Vector3(0.12230174f,-0.01898446f,0),new Vector3(0.12500000f,-0.01630516f,0),new Vector3(0.12500000f,0.01584313f,0),new Vector3(0.12183632f,0.01898446f,0),new Vector3(-0.02183632f,0.01898446f,0)};
  internal const float LabelFront=.0012f;
  internal static void SetLed(Vector3[] actual,float bezelFront){if(actual==null||actual.Length<3)throw new InvalidOperationException("LED contour missing.");led=(Vector3[])actual.Clone();}
  internal static Vector3[] LedOpening()=>Offset(led,0);
  internal static Vector3[] LedSurface()=>Offset(led,0);
  internal static void LabelRings(out Vector3[] inner,out Vector3[] outer){
   var opening=Offset(.00025f);
   // Fill the upper shoulders all the way to the caption sides. Its bottom
   // stays at the established door position; only the top and sides grow.
   var rim=Hull(Offset(.003f).Where(p=>p.y<0).Concat(new[]{new Vector3(.142f,0,0),new Vector3(.142f,.034f,0),new Vector3(-.042f,.034f,0),new Vector3(-.042f,0,0)}));var center=new Vector3(.05f,0,0);
   // Use every corner direction from both polygons so the ring reproduces both
   // outlines exactly even when the LED and bezel have different vertex counts.
   var angles=opening.Concat(rim).Select(p=>Math.Atan2(p.y-center.y,p.x-center.x)).GroupBy(a=>Math.Round(a,10)).Select(g=>g.First()).OrderBy(a=>a).ToArray();
   inner=angles.Select(a=>Intersect(opening,center,a)).ToArray();outer=angles.Select(a=>Intersect(rim,center,a)).ToArray();
  }
  private static Vector3[] Hull(IEnumerable<Vector3> vertices){
   var points=vertices.OrderBy(p=>p.x).ThenBy(p=>p.y).ToArray();var lower=new List<Vector3>();var upper=new List<Vector3>();
   Func<Vector3,Vector3,Vector3,double> turn=(a,b,c)=>(b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x);
   foreach(var p in points){while(lower.Count>1&&turn(lower[lower.Count-2],lower[lower.Count-1],p)<=1e-10)lower.RemoveAt(lower.Count-1);lower.Add(p);}
   foreach(var p in points.Reverse()){while(upper.Count>1&&turn(upper[upper.Count-2],upper[upper.Count-1],p)<=1e-10)upper.RemoveAt(upper.Count-1);upper.Add(p);}
   lower.RemoveAt(lower.Count-1);upper.RemoveAt(upper.Count-1);lower.AddRange(upper);return lower.ToArray();
  }
  private static Vector3 Intersect(Vector3[] polygon,Vector3 center,double angle){
   double dx=Math.Cos(angle),dy=Math.Sin(angle),nearest=double.PositiveInfinity;
   for(int i=0;i<polygon.Length;i++){
    var a=polygon[i];var b=polygon[(i+1)%polygon.Length];double ex=b.x-a.x,ey=b.y-a.y,ax=a.x-center.x,ay=a.y-center.y,den=dx*ey-dy*ex;if(Math.Abs(den)<1e-14)continue;
    double t=(ax*ey-ay*ex)/den,u=(ax*dy-ay*dx)/den;if(t>=0&&u>=-.000001&&u<=1.000001)nearest=Math.Min(nearest,t);
   }
   if(double.IsInfinity(nearest))throw new InvalidOperationException("Display outline ray missing.");return new Vector3(center.x+(float)(dx*nearest),center.y+(float)(dy*nearest),0);
  }
  internal static void Set(Vector3[] actual){if(actual==null||actual.Length<3)throw new InvalidOperationException("Door display contour missing.");ring=(Vector3[])actual.Clone();}
  internal static Vector3[] Offset(float distance)=>Offset(ring,distance);
  private static Vector3[] Offset(Vector3[] ring,float distance){
   var result=new Vector3[ring.Length];
   for(int i=0;i<ring.Length;i++){
    var a=ring[(i+ring.Length-1)%ring.Length];var b=ring[i];var c=ring[(i+1)%ring.Length];
    double ux=b.x-a.x,uy=b.y-a.y,vx=c.x-b.x,vy=c.y-b.y;
    double u=Math.Sqrt(ux*ux+uy*uy),v=Math.Sqrt(vx*vx+vy*vy);
    double nx=uy/u,ny=-ux/u,mx=vy/v,my=-vx/v,den=1+nx*mx+ny*my;
    if(den<.00001)throw new InvalidOperationException("Invalid display contour corner.");
    result[i]=new Vector3(b.x+(float)((nx+mx)*distance/den),b.y+(float)((ny+my)*distance/den),0);
   }
   return result;
  }
 }
}
