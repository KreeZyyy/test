using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Assets.Scripts.Objects;
using HarmonyLib;
using LaunchPadBooster;
using UnityEngine;
using Object = UnityEngine.Object;

namespace ModularSwitchboards
{
    public sealed class SwitchboardsMod : MonoBehaviour
    {
        public const string Version = "0.1.0";
        public const string KitName = "ItemKitModularSwitchboard";
        public static readonly Mod Mod = new Mod("ModularSwitchboards", Version);
        private static bool loaded;
        private static GameObject storage;

        // LaunchPad default entrypoint. No reference to LaunchPad internals.
        public void OnLoaded(List<GameObject> prefabs)
        {
            if (loaded) return;
            var harmony = new Harmony("modularswitchboards.prototype");
            harmony.Patch(AccessTools.Method(typeof(Prefab), "LoadAll"),
                prefix: new HarmonyMethod(typeof(SwitchboardsMod), nameof(PrepareKit)));
            foreach (var method in typeof(MultiConstructor).GetMethods()
                .Where(m => m.Name == "Construct" || m.Name == "CanBuild"))
                harmony.Patch(method, prefix: new HarmonyMethod(typeof(SwitchboardsMod),
                    method.ReturnType == typeof(bool) ? nameof(BlockCanBuild) : nameof(BlockConstruction)));
            Mod.Networking.Required = true;
            Prefab.OnPrefabsLoaded += VerifyRegistration;
            loaded = true;
            Debug.Log("[Modular Switchboards] 0.1.0 loaded; waiting for prefab registration.");
        }

        // LoadAll's async body reads SourcePrefabs after this prefix.
        // Runtime clones cannot be supplied as an asset bundle at OnLoaded.
        private static void PrepareKit()
        {
            if (WorldManager.Instance == null)
            {
                Debug.LogError("[Modular Switchboards] WorldManager is unavailable; kit not registered.");
                return;
            }
            var sources = WorldManager.Instance.SourcePrefabs;
            if (sources.Any(p => p != null && p.PrefabName == KitName)) return;
            // Prefer a known vanilla kit, with an explicit diagnostic if absent.
            var source = sources.OfType<MultiConstructor>().FirstOrDefault(p =>
                p.PrefabName == "ItemKitLogicSwitch" || p.name == "ItemKitLogicSwitch");
            if (source == null)
            {
                Debug.LogError("[Modular Switchboards] Vanilla ItemKitLogicSwitch was not found; kit not registered.");
                return;
            }
            if (sources.Any(p => p != null && p.PrefabHash == Animator.StringToHash(KitName)))
            {
                Debug.LogError("[Modular Switchboards] Prefab hash collision; kit not registered.");
                return;
            }

            if (storage == null)
            {
                storage = new GameObject("ModularSwitchboards.SourcePrefabs");
                storage.SetActive(false);
                Object.DontDestroyOnLoad(storage);
            }
            var kit = Object.Instantiate(source, storage.transform);
            kit.name = KitName;
            kit.PrefabName = KitName;
            kit.PrefabHash = Animator.StringToHash(KitName);
            kit.CustomName = "Kit (Switchboard)";
            // Unity copies serialized lists; replace explicitly to avoid touching vanilla data.
            kit.Constructables = new List<Structure>();
            kit.LastSelectedIndex = 0;
            sources.Add(kit);
            Debug.Log("[Modular Switchboards] Prepared " + KitName +
                " / hash " + kit.PrefabHash + "; spawn-only prototype, vanilla visuals.");
        }

        private static void VerifyRegistration()
        {
            var kit = Prefab.Find<MultiConstructor>(KitName);
            if (kit == null || kit.PrefabHash != Animator.StringToHash(KitName))
                Debug.LogError("[Modular Switchboards] Registration verification FAILED.");
            else
                Debug.Log("[Modular Switchboards] Registration verified: " + KitName);
        }

        private static bool BlockConstruction(MultiConstructor __instance)
        {
            return __instance.PrefabName != KitName;
        }

        private static bool BlockCanBuild(MultiConstructor __instance, ref bool __result)
        {
            if (__instance.PrefabName != KitName) return true;
            __result = false;
            return false;
        }
    }
}
