-- Requires optional StationeersLua and an Integrated Circuit (Lua).
-- The base unit is this module, including its own native LED display.
local LT = ic.enums.LogicType
local db = ic.const.BASE_UNIT_INDEX
local count = 0
ic.write(db, LT.Mode, 0) -- Numeric display
function tick()
    count = count + 1
    ic.write(db, LT.Setting, count)
end
-- Only the data branch connected to this module's IN is visible.
-- Use ic.read_id / ic.write_id or batch calls for other devices on it.
