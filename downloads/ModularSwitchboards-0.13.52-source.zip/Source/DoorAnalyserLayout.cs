using System;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class DoorAnalyserLayout
    {
        internal const float Width=.072f,Height=.060f,FrontCenter=.004f;
        internal static Vector3 Fit(Vector3 size)
        {
            if(size.x<=0||size.y<=0||float.IsNaN(size.x)||float.IsNaN(size.y))throw new InvalidOperationException("Invalid native analyzer panel bounds.");
            return new Vector3(Width/size.x,Height/size.y,1);
        }
        internal static Vector3 Position(Vector3 center,Vector3 fit)=>new Vector3(-center.x*fit.x,-center.y*fit.y,FrontCenter-center.z);
    }
}
