from pathlib import Path
p=Path(__file__).resolve().parents[2]/'Source'
s=(p/'CabinetWiring.cs').read_text();a=s.index('        internal Assets.Scripts.Networks.CableNetwork AnalysedNetwork(');b=s.index('        internal bool HasAnyWires',a)
net=s[a:b]
s=(p/'DinAnalyserModel.cs').read_text();a=s.index('        internal static PassiveTooltip Tooltip(');b=s.index('\n    }',a);tooltip=s[a:b]
out='''using System;using System.Linq;using System.Collections.Generic;using Assets.Scripts;using Assets.Scripts.UI;using Assets.Scripts.UI.HelperHints.Extensions;using Assets.Scripts.Localization2;using Assets.Scripts.Objects;
namespace ModularSwitchboards {
 public class CabinetWiring{public SwitchboardCabinet Owner;public List<DinBreaker> modules=new();public IEnumerable<DinBreaker> Breakers=>modules;public List<CabinetWireSaveData> wires=new();public IEnumerable<CabinetWireSaveData> CircuitWires=>WireCircuit.Through(wires,modules.Where(m=>m.IsDoorBridge).Select(m=>m.ReferenceId));public static SwitchboardCabinet CabinetOf(DinBreaker m)=>m.Cabinet;
'''+net+'''}
 internal static class DinAnalyserModel{
'''+tooltip+'''}}
'''
(Path(__file__).resolve().parent/'ProductionExtracted.cs').write_text(out)
