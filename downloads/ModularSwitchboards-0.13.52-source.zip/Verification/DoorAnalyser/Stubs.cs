using System.Text;
namespace UnityEngine{public struct Vector3{public float x,y,z;public Vector3(float x,float y,float z){this.x=x;this.y=y;this.z=z;}public static Vector3 Scale(Vector3 a,Vector3 b)=>new(a.x*b.x,a.y*b.y,a.z*b.z);}}
namespace Assets.Scripts{}
namespace Assets.Scripts.Objects{}
namespace Assets.Scripts.Networks{public class CableNetwork{public float CurrentLoad,RequiredLoad,PotentialLoad;}}
namespace Assets.Scripts.UI{public struct PassiveTooltip{public string Title,Extended;}}
namespace Assets.Scripts.UI.Tooltip{public static class ToolTipStringBuilder{public static StringBuilder Text=new();public static void Clear()=>Text.Clear();public static void Append(string s)=>Text.Append(s);public static void AppendLine()=>Text.AppendLine();public static new string ToString()=>Text.ToString();}}
namespace Assets.Scripts.Localization2{public class Entry{public string Label;public string AsString(string v)=>Label+": "+v;}public static class GameStrings{public static Entry CableAnalyserActual=new(){Label="Actual"},CableAnalyserRequired=new(){Label="Required"},CableAnalyserPotential=new(){Label="Potential"};}}
namespace Assets.Scripts.UI.HelperHints.Extensions{public static class Formatting{public static string ToStringPrefix(this float v,string unit,string color)=>v+" "+unit;}}
namespace ModularSwitchboards{
 public class Cable{public Assets.Scripts.Networks.CableNetwork CableNetwork;}
 public class Connection{public Cable cable=new();public Cable GetCable()=>cable;}
 public class SwitchboardCabinet{public bool IsCursor,IsStructureCompleted=true;public object GridController=new();public Connection InputConnection=new(),Output1Connection=new(),Output2Connection=new();public CabinetWiring Wiring;public SwitchboardCabinet(){Wiring=new(){Owner=this};}}
 public class DinBreaker{public long ReferenceId;public bool Conducting=true,IsAnalyserModule=true,IsBatteryModule,IsDoorAnalyser,IsDoorBridge,IsDoorPart;public string DisplayName="Cable Analyzer";public SwitchboardCabinet Cabinet;}
}
