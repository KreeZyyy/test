using System;using System.Linq;using System.Collections.Generic;using Assets.Scripts;using Assets.Scripts.UI;using Assets.Scripts.UI.HelperHints.Extensions;using Assets.Scripts.Localization2;using Assets.Scripts.Objects;
namespace ModularSwitchboards {
 public class CabinetWiring{public SwitchboardCabinet Owner;public List<DinBreaker> modules=new();public IEnumerable<DinBreaker> Breakers=>modules;public List<CabinetWireSaveData> wires=new();public IEnumerable<CabinetWireSaveData> CircuitWires=>WireCircuit.Through(wires,modules.Where(m=>m.IsDoorBridge).Select(m=>m.ReferenceId));public static SwitchboardCabinet CabinetOf(DinBreaker m)=>m.Cabinet;
        internal Assets.Scripts.Networks.CableNetwork AnalysedNetwork(DinBreaker analyser,out string reason,out string source)
        {
            reason=null;source=null;
            if(Owner==null||Owner.IsCursor||!Owner.IsStructureCompleted||Owner.GridController==null){reason="No cable network found.";return null;}
            var modules=Breakers.ToArray();
            int output=AnalyserCircuit.Selection(analyser.ReferenceId,CircuitWires,modules.Where(b=>b.Conducting).Select(b=>b.ReferenceId),modules.Where(b=>!b.IsAnalyserModule&&!b.IsBatteryModule&&!b.IsDoorPart).Select(b=>b.ReferenceId));
            if(output==AnalyserCircuit.Input){source="Input";var supply=Owner.InputConnection?.GetCable()?.CableNetwork;if(supply==null)reason="No cable network found on Input.";return supply;}
            if(output==0){reason=wires.Any(w=>w.From.Equals(new CabinetWireEnd(analyser.ReferenceId,1)))?"No conducting path from analyser OUT to an output.":"Place the analyzer before protection to read Input, or connect its OUT to the measured output.";return null;}
            source=output==3?"Output 1 / Output 2":"Output "+output;
            var first=Owner.Output1Connection?.GetCable()?.CableNetwork;
            var second=Owner.Output2Connection?.GetCable()?.CableNetwork;
            if(output==3&&!ReferenceEquals(first,second)){reason="Analyser leads to two different networks.";return null;}
            var network=output==2?second:first;
            if(network==null)reason="No cable network found on Output "+(output==2?"2":"1")+".";
            return network;
        }
}
 internal static class DinAnalyserModel{
        internal static PassiveTooltip Tooltip(DinBreaker module,PassiveTooltip tooltip)
        {
            tooltip.Title=module.DisplayName;
            var cabinet=CabinetWiring.CabinetOf(module);
            if(cabinet==null){tooltip.Extended=module.IsDoorAnalyser?"Install on the cabinet door and wire through hinge bridges.":"Install on a DIN rail and wire to an output.";return tooltip;}
            var network=cabinet.Wiring.AnalysedNetwork(module,out var reason,out var source);
            if(source!=null)tooltip.Title+=" — "+source;
            if(network==null){tooltip.Extended=reason;return tooltip;}
            // Same three native CableAnalyser getters and localized tooltip strings.
            Assets.Scripts.UI.Tooltip.ToolTipStringBuilder.Clear();
            Assets.Scripts.UI.Tooltip.ToolTipStringBuilder.Append(GameStrings.CableAnalyserActual.AsString(network.CurrentLoad.ToStringPrefix("W","yellow")));
            Assets.Scripts.UI.Tooltip.ToolTipStringBuilder.AppendLine();
            Assets.Scripts.UI.Tooltip.ToolTipStringBuilder.Append(GameStrings.CableAnalyserRequired.AsString(network.RequiredLoad.ToStringPrefix("W","yellow")));
            Assets.Scripts.UI.Tooltip.ToolTipStringBuilder.AppendLine();
            Assets.Scripts.UI.Tooltip.ToolTipStringBuilder.Append(GameStrings.CableAnalyserPotential.AsString(network.PotentialLoad.ToStringPrefix("W","yellow")));
            tooltip.Extended=Assets.Scripts.UI.Tooltip.ToolTipStringBuilder.ToString();return tooltip;
        }}}
