using System;using System.IO;using System.Linq;using System.Text.Json;using System.Collections.Generic;using ModularSwitchboards;using UnityEngine;using Assets.Scripts.Networks;
class Program{
 static int checks;static void Check(bool b,string m){checks++;if(!b)throw new Exception(m);}
 static CabinetWireSaveData W(long a,int x,long b,int y)=>new(){From=new(a,x),To=new(b,y)};
 static void Main(){
  using var fixture=JsonDocument.Parse(File.ReadAllText(Path.Combine(AppContext.BaseDirectory,"AnalyserFixture.json")));
  var source=fixture.RootElement.GetProperty("vertices").EnumerateArray().Select(v=>new Vector3(v.GetProperty("x").GetSingle(),v.GetProperty("y").GetSingle(),v.GetProperty("z").GetSingle())).ToArray();
  var groups=fixture.RootElement.GetProperty("groups").EnumerateArray().Select(g=>g.EnumerateArray().Select(i=>i.GetInt32()).ToArray()).ToArray();
  var selected=AnalyserFrontSelection.Select(source,groups);Check(selected[0].Length==204&&selected[1].Length==0&&selected[2].Length==18,"Native bezel, lightning or pane lost");
  var original=source.Select(v=>new Vector3((v.z+.000874f)*.398f,(v.x-.002003f)*.398f,(v.y-.1674507f)*.398f)).ToArray();var points=selected.SelectMany(x=>x).Select(i=>original[i]).ToArray();
  var min=new Vector3(points.Min(v=>v.x),points.Min(v=>v.y),points.Min(v=>v.z));var max=new Vector3(points.Max(v=>v.x),points.Max(v=>v.y),points.Max(v=>v.z));
  var size=new Vector3(max.x-min.x,max.y-min.y,max.z-min.z);var center=new Vector3((max.x+min.x)*.5f,(max.y+min.y)*.5f,(max.z+min.z)*.5f);
  var fit=DoorAnalyserLayout.Fit(size);var pos=DoorAnalyserLayout.Position(center,fit);var mapped=original.Select(v=>{var p=Vector3.Scale(v,fit);return new Vector3(p.x+pos.x,p.y+pos.y,p.z+pos.z);}).ToArray();var face=selected.SelectMany(x=>x).Select(i=>mapped[i]).ToArray();
  Check(Math.Abs(face.Max(v=>v.x)-face.Min(v=>v.x)-.072f)<1e-6&&Math.Abs(face.Max(v=>v.y)-face.Min(v=>v.y)-.060f)<1e-6,"Door panel not compact72x60mm");
  Check(Math.Abs(face.Max(v=>v.x)+face.Min(v=>v.x))<1e-6&&Math.Abs(face.Max(v=>v.y)+face.Min(v=>v.y))<1e-6,"Front not centered");
  Check(Math.Abs((face.Max(v=>v.z)+face.Min(v=>v.z))*.5f-.004f)<1e-6&&fit.z==1,"Native panel depth changed");
  foreach(var v in face)Check(Math.Abs(v.x)<=.036001&&Math.Abs(v.y)<=.030001&&v.z>=-.001&&v.z<.0105,"Face exceeds mounting bounds");
  foreach(var i in selected.SelectMany(x=>x))Check(Math.Abs(mapped[i].z-original[i].z-pos.z)<1e-6,"Nonuniform XY fit changed native front relief");
  var pane=selected[2].Select(i=>mapped[i]).ToArray();Check(Math.Abs((pane.Max(v=>v.x)-pane.Min(v=>v.x))-(pane.Max(v=>v.y)-pane.Min(v=>v.y)))<.002f,"Green pane should be nearly square");
  var destination=Environment.GetCommandLineArgs().Skip(1).FirstOrDefault();if(destination!=null)File.WriteAllText(destination,JsonSerializer.Serialize(new{vertices=mapped.Select(v=>new[]{v.x,v.y,v.z}),groups=selected}));
  var host=new SwitchboardCabinet();var wiring=host.Wiring;var sensor=new DinBreaker{ReferenceId=10,IsDoorAnalyser=true,IsDoorPart=true,Cabinet=host,DisplayName="Door Cable Analyzer"};
  var a=new DinBreaker{ReferenceId=900,IsAnalyserModule=false,IsDoorBridge=true,IsDoorPart=true};var b=new DinBreaker{ReferenceId=901,IsAnalyserModule=false,IsDoorBridge=true,IsDoorPart=true};var breaker=new DinBreaker{ReferenceId=20,IsAnalyserModule=false};wiring.modules.AddRange(new[]{sensor,a,b,breaker});
  var input=new CableNetwork{CurrentLoad=1234,RequiredLoad=2345,PotentialLoad=9999};var one=new CableNetwork{CurrentLoad=111,RequiredLoad=222,PotentialLoad=333};var two=new CableNetwork{CurrentLoad=444,RequiredLoad=555,PotentialLoad=666};
  host.InputConnection.cable.CableNetwork=input;host.Output1Connection.cable.CableNetwork=one;host.Output2Connection.cable.CableNetwork=two;
  void Expect(CableNetwork expected,string label){var actual=wiring.AnalysedNetwork(sensor,out var reason,out var name);Check(ReferenceEquals(actual,expected)&&name==label,"Wrong network: "+reason);var tip=DinAnalyserModel.Tooltip(sensor,default);Check(tip.Title.Contains(label)&&tip.Extended.Contains("Actual: "+expected.CurrentLoad)&&tip.Extended.Contains("Required: "+expected.RequiredLoad)&&tip.Extended.Contains("Potential: "+expected.PotentialLoad),"Door tooltip values differ from measured native network");sensor.IsDoorAnalyser=sensor.IsDoorPart=false;var din=DinAnalyserModel.Tooltip(sensor,default);Check(din.Title==tip.Title&&din.Extended==tip.Extended,"Door and DIN behavior differ");sensor.IsDoorAnalyser=sensor.IsDoorPart=true;}
  wiring.wires=new(){W(0,0,900,2),W(900,3,10,0),W(10,1,901,3),W(901,2,20,0),W(20,1,0,1)};Expect(input,"Input");breaker.Conducting=false;Expect(input,"Input");breaker.Conducting=true;
  wiring.wires=new(){W(0,0,20,0),W(20,1,900,2),W(900,3,10,0),W(10,1,901,3),W(901,2,0,2)};Expect(two,"Output 2");breaker.Conducting=false;Expect(two,"Output 2");breaker.Conducting=true;
  wiring.wires=new(){W(0,0,900,2),W(900,3,10,0),W(10,1,901,3),W(901,2,0,1)};Expect(one,"Output 1");
  wiring.wires.Clear();Check(wiring.AnalysedNetwork(sensor,out var failure,out _)==null&&failure!=null,"Unwired analyzer invents network");
  wiring.wires=new(){W(0,0,10,0),W(10,1,0,1),W(10,1,0,2)};Check(wiring.AnalysedNetwork(sensor,out failure,out _)==null&&failure.Contains("two different"),"Ambiguous networks silently summed");
  host.Output2Connection.cable.CableNetwork=one;Expect(one,"Output 1 / Output 2");host.GridController=null;Check(wiring.AnalysedNetwork(sensor,out _,out _)==null,"Unregistered cabinet read stale network");
  sensor.Cabinet=null;Check(DinAnalyserModel.Tooltip(sensor,default).Extended.Contains("door"),"Door install hint still asks for DIN rail");
  Console.WriteLine($"Door analyzer: {checks} production geometry/network/tooltip checks passed; complete74-triangle native front, compact fit, bridges, automatic Input/Output, open breakers, ambiguity and exact DIN parity.");
 }
}
