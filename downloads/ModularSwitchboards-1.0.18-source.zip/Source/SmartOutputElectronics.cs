using System;
using System.Collections.Generic;
using System.Linq;
using Assets.Scripts;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Structures;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class SmartOutputElectronics
    {
        // Original geometry. The vending machine is a visual reference only.
        internal static void Install(Transform model,int layer)
        {
            var v=new List<Vector3>();var nrm=new List<Vector3>();var groups=new List<int>[5];for(int i=0;i<5;i++)groups[i]=new List<int>();
            Action<int,Vector3,Vector3,float> box=(role,c,s,r)=>RoundedGeometry.Box(v,nrm,groups[role],c,s,r);
            box(0,new Vector3(0,-.004f,.0622f),new Vector3(.012f,.034f,.0007f),.00035f);
            box(1,new Vector3(0,.006f,.0632f),new Vector3(.0093f,.011f,.0009f),.0003f);
            for(int i=0;i<7;i++)foreach(float side in new[]{-1f,1f})
                box(2,new Vector3(-.004f+i*.0013f,.006f+side*.0064f,.0631f),new Vector3(.00065f,.0018f,.0005f),.00008f);
            box(1,new Vector3(.002f,-.012f,.0631f),new Vector3(.0044f,.0054f,.0008f),.00015f);
            for(int i=0;i<4;i++)foreach(float side in new[]{-1f,1f})
                box(2,new Vector3(.002f+side*.0026f,-.0138f+i*.0012f,.0630f),new Vector3(.001f,.0006f,.0004f),.00007f);
            foreach(float y in new[]{-.010f,-.014f})box(2,new Vector3(-.0035f,y,.0631f),new Vector3(.0018f,.0021f,.001f),.00025f);
            // Thin copper traces and a second controller make a visible board,
            // rather than a blank slab; every piece is authored for this module.
            for(int line=0;line<5;line++)
            {
                float x=-.0045f+line*.0022f;
                box(3,new Vector3(x,-.0038f,.06265f),new Vector3(.00018f,.0045f,.00008f),.00002f);
                box(3,new Vector3(x*.5f,-.0058f-line*.0004f,.06265f),new Vector3(Mathf.Abs(x)+.0002f,.00015f,.00008f),.00002f);
            }
            foreach(float x in new[]{-.0035f,-.0012f})
                box(4,new Vector3(x,-.018f,.0631f),new Vector3(.0013f,.002f,.0012f),.00035f);
            var mesh2=new Mesh{name="Smart.Output.ElectronicsInsert"};mesh2.SetVertices(v);mesh2.SetNormals(nrm);mesh2.subMeshCount=5;
            for(int i=0;i<5;i++)mesh2.SetTriangles(groups[i],i);mesh2.RecalculateBounds();
            var root=new GameObject("SmartOutputElectronics"){layer=layer};root.transform.SetParent(model,false);root.transform.localScale=new Vector3(.85f,.85f,1f);root.transform.localPosition=new Vector3(0,-.003f,0);root.AddComponent<MeshFilter>().sharedMesh=mesh2;
            root.AddComponent<MeshRenderer>().sharedMaterials=new[]{Material("PCB",new Color(.075f,.19f,.085f)),Material("Chip",new Color(.025f,.029f,.028f)),Material("Contacts",new Color(.48f,.5f,.46f)),Material("Traces",new Color(.19f,.31f,.11f)),Material("Capacitors",new Color(.35f,.025f,.018f))};
            // Real recess in our own casing, with a shallow protective window.
            var casing=model.GetComponent<MeshFilter>();var old=casing.sharedMesh;
            casing.sharedMesh=SmartSocketPocket.Cut(old,new Bounds(new Vector3(0,-.0064f,.0645f),new Vector3(.0125f,.0325f,.007f)));
            UnityEngine.Object.DestroyImmediate(old);
            var glassV=new List<Vector3>();var glassN=new List<Vector3>();var glassT=new List<int>();
            RoundedGeometry.Box(glassV,glassN,glassT,new Vector3(0,-.0064f,.0648f),new Vector3(.0122f,.032f,.00035f),.0003f);
            var glassMesh=new Mesh{name="NET.AuthoredProtectiveGlass"};glassMesh.SetVertices(glassV);glassMesh.SetNormals(glassN);glassMesh.SetTriangles(glassT,0);glassMesh.RecalculateBounds();
            var glass=new GameObject("SmartOutputGlass"){layer=layer};glass.transform.SetParent(model,false);glass.AddComponent<MeshFilter>().sharedMesh=glassMesh;
            var window=Material("ProtectiveGlass",new Color(.34f,.45f,.42f,.10f));
            window.SetFloat("_Mode",3f);window.SetOverrideTag("RenderType","Transparent");window.SetInt("_SrcBlend",(int)UnityEngine.Rendering.BlendMode.SrcAlpha);window.SetInt("_DstBlend",(int)UnityEngine.Rendering.BlendMode.OneMinusSrcAlpha);window.SetInt("_ZWrite",0);
            window.EnableKeyword("_ALPHABLEND_ON");window.renderQueue=(int)UnityEngine.Rendering.RenderQueue.Transparent;
            var surface=glass.AddComponent<MeshRenderer>();surface.sharedMaterial=window;surface.shadowCastingMode=UnityEngine.Rendering.ShadowCastingMode.Off;surface.receiveShadows=false;

        }
        internal static Material Material(string name,Color color)
        {
            var shader=Shader.Find("Standard");if(shader==null||!shader.isSupported)throw new InvalidOperationException("NET panel shader unavailable");
            var m=new Material(shader){name="Switchboards.NET."+name,color=color};CabinetMatteSurface.Configure(m);return m;
        }
    }
}
