using System;
namespace ModularSwitchboards
{
    internal sealed class WireVisualProfile
    {
        internal readonly float Radius,CollarLength;
        internal float JointPitch=>CollarLength>0?.10f:0;internal readonly int Sides,Materials;
        internal WireVisualProfile(float radius,int sides,int materials,float collar){Radius=radius;Sides=sides;Materials=materials;CollarLength=collar;}
    }
    internal static class WireVisualProfiles
    {
        private static readonly WireVisualProfile Basic=new WireVisualProfile(.0012f,8,1,0);
        private static readonly WireVisualProfile Heavy=new WireVisualProfile(.0022f,8,2,0);
        private static readonly WireVisualProfile SuperHeavy=new WireVisualProfile(.0030f,12,3,.004f);
        internal static WireVisualProfile Get(CabinetWireKind kind)=>kind==CabinetWireKind.SuperHeavy?SuperHeavy:kind==CabinetWireKind.Heavy?Heavy:Basic;
        internal static int Surface(CabinetWireKind kind,int side,float distance,float length)
        {
            if(kind==CabinetWireKind.Normal)return 0;
            if(kind==CabinetWireKind.SuperHeavy&&JointGap(distance,length)<0)return 2;
            // Two continuous dark faces towards the viewer, and the opposite side.
            return kind==CabinetWireKind.Heavy?(side==1||side==2||side==5||side==6?1:0):(side==2||side==3||side==8||side==9?1:0);
        }
        internal static float JointGap(float distance,float length)
        {
            float cuff=SuperHeavy.CollarLength,pitch=SuperHeavy.JointPitch;
            float gap=Math.Min(distance-cuff,length-distance-cuff);
            int index=(int)Math.Round(distance/pitch);float center=index*pitch;
            if(index>0&&center<length-cuff)gap=Math.Min(gap,Math.Abs(distance-center)-cuff*.5f);
            return gap;
        }
        internal static float Radius(CabinetWireKind kind,int vertex,float distance,float length)
        {
            var profile=Get(kind);if(kind!=CabinetWireKind.SuperHeavy)return profile.Radius;
            float blend=Math.Max(0,Math.Min(1,JointGap(distance,length)/.002f));
            // Native-inspired broad red shoulders and recessed black longitudinal channels.
            float angle=(float)(vertex*Math.PI*2/profile.Sides);
            float channel=.85f+.15f*(float)Math.Cos(angle*2);
            return profile.Radius*(1-blend+blend*channel);
        }
    }
}
