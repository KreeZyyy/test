using System;
using System.Collections.Generic;
namespace ModularSwitchboards
{
    internal static class WireMarkings
    {
        // Added rings bound the metal end collars and periodic joints; channels stay longitudinal.
        internal static WirePoint[] Sample(WirePoint[] path,CabinetWireKind kind,out float[] distances)
        {
            var original=new float[path.Length];for(int i=1;i<path.Length;i++)original[i]=original[i-1]+(float)Math.Sqrt((path[i]-path[i-1]).Squared);
            float length=original[original.Length-1];var cuts=new List<float>(original);float collar=WireVisualProfiles.Get(kind).CollarLength;
            if(collar>0)foreach(float boundary in new[]{collar,collar+.002f,length-collar,length-collar-.002f})if(boundary>0&&boundary<length)cuts.Add(boundary);
            if(collar>0)
            {
                float pitch=WireVisualProfiles.Get(kind).JointPitch;
                for(int joint=1;joint*pitch<length-collar;joint++)
                    foreach(float boundary in new[]{joint*pitch-collar*.5f-.002f,joint*pitch-collar*.5f,joint*pitch+collar*.5f,joint*pitch+collar*.5f+.002f})if(boundary>0&&boundary<length)cuts.Add(boundary);
            }
            cuts.Sort();var points=new List<WirePoint>();var arc=new List<float>();int segment=1;
            foreach(float d in cuts)
            {
                if(arc.Count>0&&d-arc[arc.Count-1]<.000001f)continue;
                while(segment<path.Length-1&&original[segment]<d)segment++;
                float span=original[segment]-original[segment-1];if(span<.0000001f)continue;
                float t=(d-original[segment-1])/span;points.Add(path[segment-1]+(path[segment]-path[segment-1])*t);arc.Add(d);
            }
            distances=arc.ToArray();return points.ToArray();
        }
    }
}
