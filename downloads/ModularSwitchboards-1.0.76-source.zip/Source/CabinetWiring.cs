using System;
using System.Collections.Generic;
using System.Linq;
using Assets.Scripts;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Inventory;
using Assets.Scripts.Networking;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Entities;
using Assets.Scripts.Objects.Items;
using Assets.Scripts.Objects.Motherboards;
using LibConstruct;
using UnityEngine;

namespace ModularSwitchboards
{
    public sealed class CabinetWirePaintTarget : MonoBehaviour { public CabinetWireSaveData Wire; }

    public sealed class CabinetWireTarget : MonoBehaviour { public CabinetWireEnd End; }

    public sealed partial class CabinetWiring : MonoBehaviour
    {
        internal const ushort UpdateFlag=32768;
        internal const int CurrentRouteVersion=6;
        public SwitchboardCabinet Owner;
        private readonly List<CabinetWireSaveData> wires=new List<CabinetWireSaveData>();
        private readonly Dictionary<long,CabinetWireEnd> pending=new Dictionary<long,CabinetWireEnd>();
        private readonly Dictionary<long,float> pendingUntil=new Dictionary<long,float>();
        private readonly Dictionary<CabinetWireEnd,Contact> contacts=new Dictionary<CabinetWireEnd,Contact>();
        private readonly List<GameObject> visuals=new List<GameObject>();
        private readonly List<Collider> colliders=new List<Collider>();
        internal readonly CabinetWiringPower Power=new CabinetWiringPower();
        private Transform shell,visualRoot,doorVisualRoot,rightDoorVisualRoot;
        private readonly List<WireRect> railObstacles=new List<WireRect>();
        private WireRect[] moduleReservations=WireModuleSpace.Reservations().ToArray();
        private readonly Dictionary<CabinetWireSaveData,MeshRenderer> wireRenderers=new Dictionary<CabinetWireSaveData,MeshRenderer>();
        private GameObject preview;
        private WirePoint[] previewPath;
        private int previewFrame=-1;
        private CabinetWireKind previewKind;
        private bool needsReroute,cleanupOnLoad;
        private string migrationFailure;
        private float nextRefresh,topologyReadyAt,nextLedRefresh;
        private string topology;
        private float routingHalfWidth=WireRouting.HalfWidth,routingHalfHeight=WireRouting.HalfHeight;
        private bool shapeReady;
        private bool rebuild=true;
        private int revision,routeRevision=-1;
        private CabinetWireEnd routeFrom,routeTo;
        private WirePoint[] route;
        private string routeFailure;
        private int routeSlot;
        private sealed class Contact {internal CabinetWireEnd End;internal Vector3 Position,Aim,Exit;internal WireRect Bounds;internal GameObject Marker;internal bool Door;internal int Leaf;internal float LeadSide;}
        internal static SwitchboardCabinet CabinetOf(DinBreaker breaker)=>breaker.IsDoorPart?breaker.Board?.PrimaryHost as SwitchboardCabinet:(breaker.Board?.PrimaryHost as DinRail)?.Board?.PrimaryHost as SwitchboardCabinet;
        internal IEnumerable<DinBreaker> Breakers=>(Owner.RailBoard==null?Enumerable.Empty<DinBreaker>():Owner.RailBoard.Structures.OfType<DinRail>().Where(r=>r.Modules!=null).SelectMany(r=>r.Modules.Structures.OfType<DinBreaker>())).Concat(Owner.DoorBoards.SelectMany(b=>b.Structures.OfType<DinBreaker>()));
        internal IEnumerable<DinTransformer> Transformers=>Owner.RailBoard==null?Enumerable.Empty<DinTransformer>():Owner.RailBoard.Structures.OfType<DinRail>().Where(r=>r.Modules!=null).SelectMany(r=>r.Modules.Structures.OfType<DinTransformer>()).Where(t=>!t.IsBeingDestroyed);
        private IEnumerable<long> PowerConducting=>Breakers.Where(b=>b.Conducting).Select(b=>b.ReferenceId).Concat(Transformers.Where(t=>t.Conducting).Select(t=>t.ReferenceId));
        internal IEnumerable<SmartModule> SmartModules=>Owner.RailBoard==null?Enumerable.Empty<SmartModule>():Owner.RailBoard.Structures.OfType<DinRail>().Where(r=>r.Modules!=null).SelectMany(r=>r.Modules.Structures.OfType<SmartModule>());
        internal IEnumerable<SmartContactor> Contactors=>Owner.RailBoard==null?Enumerable.Empty<SmartContactor>():Owner.RailBoard.Structures.OfType<DinRail>().Where(r=>r.Modules!=null).SelectMany(r=>r.Modules.Structures.OfType<SmartContactor>()).Where(c=>!c.IsBeingDestroyed);
        internal bool SmartOutputConnected(long output)=>SmartControlIndicator.Connected(output,wires,
            Breakers.Where(c=>c.IsContactor&&!c.IsBeingDestroyed).Select(c=>c.ReferenceId));
        internal bool TerminalLive(long id,int pin=0)
        {
            if(Owner==null||Owner.IsCursor||!Owner.IsStructureCompleted||Owner.GridController==null)return false;
            var graph=CircuitWires.ToArray();var closed=PowerConducting.ToArray();var target=new CabinetWireEnd(id,pin);
            return (Owner.InputConnection?.GetCable()?.CableNetwork?.PotentialLoad??0)>0&&WireCircuit.Reachable(new CabinetWireEnd(0,0),target,graph,closed)||Breakers.Any(m=>!m.IsBeingDestroyed&&m.IsBatteryModule&&m.Battery!=null&&m.Battery.PowerStored>0&&WireCircuit.Reachable(new CabinetWireEnd(m.ReferenceId,1),target,graph,closed));
        }
        internal IEnumerable<long> SmartIds=>SmartModules.Where(m=>!m.IsBeingDestroyed).Select(m=>m.ReferenceId);
        internal Assets.Scripts.Objects.Electrical.Cable SmartPowerCable(SmartModule module)
        {
            if(Owner==null||Owner.IsCursor||!Owner.IsStructureCompleted||Owner.GridController==null)return null;
            // Power follows the live internal circuit, independently of any external data/output cable.
            var graph=CircuitWires.ToArray();var closed=PowerConducting.ToArray();var input=new CabinetWireEnd(0,0);var tap=new CabinetWireEnd(module.ReferenceId,0);
            if(!WireCircuit.Reachable(input,tap,graph,closed))return null;
            // A consumer after a transformer belongs to the downstream real cable
            // network, so its native consumption is charged to the capped output.
            if(Transformers.Any(t=>WireCircuit.Reachable(input,new CabinetWireEnd(t.ReferenceId,0),graph,closed)&&WireCircuit.Reachable(new CabinetWireEnd(t.ReferenceId,1),tap,graph,closed)))return SmartCable(module.ReferenceId);
            return Owner.InputConnection?.GetCable();
        }
        internal Assets.Scripts.Objects.Electrical.Cable SmartCable(SmartModule module)
        {
            return SmartCable(module.ReferenceId);
        }
        internal Assets.Scripts.Objects.Electrical.Cable SmartCable(long id,int tapContact=0)
        {
            if(Owner==null||Owner.IsCursor||!Owner.IsStructureCompleted||Owner.GridController==null)return null;
            var modules=Breakers.ToArray();
            int selection=SmartCircuit.Selection(id,CircuitWires,
                modules.Where(b=>b.Conducting).Select(b=>b.ReferenceId),
                modules.Where(b=>!b.IsAnalyserModule&&!b.IsBatteryModule&&!b.IsSmartOutputModule&&!b.IsDoorPart).Select(b=>b.ReferenceId).Concat(Contactors.Select(c=>c.ReferenceId)),tapContact);
            if(selection==AnalyserCircuit.Input)return Owner.InputConnection?.GetCable();
            if(selection==0)return null;
            var cables=new[]{Owner.Output1Connection,Owner.Output2Connection,Owner.Output3Connection}
                .Select((port,i)=>new{port,bit=i==2?8:1<<i}).Where(p=>(selection&p.bit)!=0)
                .Select(p=>p.port?.GetCable()).ToArray();
            // Register the real device on exactly one native network. Never bridge
            // unrelated output data networks through the internal module.
            if(cables.Select(c=>c?.CableNetwork).Distinct().Count()!=1)return null;
            return cables.FirstOrDefault(c=>c!=null&&c.CableNetwork!=null);
        }

        private IEnumerable<CabinetWireSaveData> CircuitWires=>ContactorCircuit.WithNormallyClosed(BaseCircuitWires,Breakers.Where(m=>m.HasNormallyClosedContact&&!m.IsBeingDestroyed).Select(m=>m.ReferenceId),Breakers.Where(m=>m.ContactorClosed).Select(m=>m.ReferenceId));
        private IEnumerable<CabinetWireSaveData> BaseCircuitWires=>DoorModuleLayout.Through(SmartContactorCircuit.ValidWires(wires,Contactors.Select(c=>c.ReferenceId),Breakers.Where(c=>c.IsContactor).Select(c=>c.ReferenceId)),Breakers.Where(m=>m.IsDoorBridge&&!m.IsBeingDestroyed).Select(m=>m.ReferenceId));
        private Transform DoorFrame=>DoorModules.Frame(Owner);
        private Transform Frame(Contact c)=>c.Door?DoorModules.Frame(Owner,c.Leaf==1):Shell;
        private Transform WireFrame(CabinetWireSaveData wire)=>contacts.TryGetValue(wire.From,out var c)?Frame(c):Shell;
        private static int Surface(Contact c)=>c.Door?c.Leaf+1:0;
        private int WireSurface(CabinetWireSaveData wire)=>contacts.TryGetValue(wire.From,out var c)?Surface(c):0;
        private bool IsDoorWire(CabinetWireSaveData w)=>contacts.TryGetValue(w.From,out var c)&&c.Door;
        private bool CanConnectContacts(CabinetWireEnd a,CabinetWireEnd b,out string reason)
        {
            reason=null;
            if(!contacts.TryGetValue(a,out var ca)||!contacts.TryGetValue(b,out var cb)){reason="Contact unavailable.";return false;}
            if(Surface(ca)!=Surface(cb)){reason="Wire the plate and door separately through the Door Terminal Bridge.";return false;}
            if(!SmartContactorCircuit.Allowed(a,b,Contactors.Select(c=>c.ReferenceId),Breakers.Where(c=>c.IsContactor).Select(c=>c.ReferenceId)))
            {reason="Smart Output OUT connects only to a classic contactor A1.";return false;}
            foreach(var end in new[]{a,b})if(end.Contact==2&&Breakers.Any(c=>c.ReferenceId==end.Owner&&c.IsContactor))
            {
                var other=end.Equals(a)?b:a;
                if(!other.IsSource&&!Breakers.Any(m=>m.ReferenceId==other.Owner&&m.IsDoorBridge))
                {reason="Connect A1 to a supply contact or a door terminal bridge; the coil is not a power output.";return false;}
            }
            return WireCircuit.CanConnect(a,b,wires,Breakers.Select(m=>m.ReferenceId).Concat(Transformers.Select(t=>t.ReferenceId)).Concat(SmartIds).Concat(Contactors.Select(c=>c.ReferenceId)),out reason,capacity:Capacity,passages:Breakers.Where(m=>m.IsDoorBridge).Select(m=>m.ReferenceId),normallyClosed:Breakers.Where(m=>m.HasNormallyClosedContact).Select(m=>m.ReferenceId));
        }
        private Transform Shell=>shell!=null?shell:(shell=Owner.transform.Find("SwitchboardModel/CompletedShell"));
        internal static WirePoint Point(Vector3 p)=>new WirePoint(p.x,p.y,p.z);
        internal static Vector3 Vector(WirePoint p)=>new Vector3(p.X,p.Y,p.Z);
        internal bool HasWires(long breaker)=>wires.Any(w=>w.From.Owner==breaker||w.To.Owner==breaker);
        internal Assets.Scripts.Networks.CableNetwork AnalysedNetwork(DinBreaker analyser,out string reason,out string source)
        {
            reason=null;source=null;
            if(Owner==null||Owner.IsCursor||!Owner.IsStructureCompleted||Owner.GridController==null){reason="No cable network found.";return null;}
            var modules=Breakers.ToArray();
            int output=AnalyserCircuit.Selection(analyser.ReferenceId,CircuitWires,PowerConducting,modules.Where(b=>!b.IsAnalyserModule&&!b.IsBatteryModule&&!b.IsSmartOutputModule&&!b.IsDoorPart).Select(b=>b.ReferenceId));
            if(output==AnalyserCircuit.Input){source="Input";var supply=Owner.InputConnection?.GetCable()?.CableNetwork;if(supply==null)reason="No cable network found on Input.";return supply;}
            if(output==0){reason=wires.Any(w=>w.From.Equals(new CabinetWireEnd(analyser.ReferenceId,1)))?"No conducting path from analyser OUT to an output.":"Place the analyzer before protection to read Input, or connect its OUT to the measured output.";return null;}
            var chosen=new[]{Owner.Output1Connection,Owner.Output2Connection,Owner.Output3Connection}.Select((port,i)=>new{port,index=i+1,bit=i==2?8:1<<i}).Where(p=>(output&p.bit)!=0).ToArray();
            source=string.Join(" / ",chosen.Select(p=>"Output "+p.index));var networks=chosen.Select(p=>p.port?.GetCable()?.CableNetwork).ToArray();
            if(networks.Distinct().Count()>1){reason="Analyser leads to different networks.";return null;}
            var network=networks.FirstOrDefault();if(network==null)reason="No cable network found on "+source+".";return network;
        }
        internal bool HasAnyWires=>wires.Count!=0;
        internal static bool IsCoil(DynamicThing item)=>CabinetCableCoils.TryKind(item,out _);
        private static bool LocalTools()=>!GameManager.IsBatchMode&&IsCoil(InventoryManager.ActiveHandSlot?.Get());
        internal string ContactName(CabinetWireEnd e)
        {if(Contactors.Any(c=>c.ReferenceId==e.Owner))return "Smart Output OUT — contactor A1 only (Core powered)";if(SmartIds.Contains(e.Owner))return SwitchboardNames.SmartCoreTitle+" POWER IN";if(Transformers.Any(t=>t.ReferenceId==e.Owner))return "Transformer "+(e.Contact==0?"IN":"OUT (limited)");var m=Breakers.FirstOrDefault(b=>b.ReferenceId==e.Owner);if(m!=null&&m.IsContactor)return e.Contact==2?"Contactor A1 (top right)":e.Contact==0?"Contactor IN (top left)":m.HasNormallyClosedContact?(e.Contact==ContactorCircuit.NcPin?"Contactor NC (bottom right)":"Contactor NO (bottom left)"):"Contactor OUT (bottom)";if(m!=null&&m.IsSmartOutputModule)return "Smart Output DATA";return m!=null&&m.IsDoorBridge?"Bridge "+(e.Contact==2?"plate":"door")+" (through)":m!=null&&m.IsDoorLed?"LED "+(e.IsSource?"OUT":"IN"):e.ToString();}
        private int Capacity(CabinetWireEnd e)=>e.Owner==0?e.Capacity:Transformers.Any(t=>t.ReferenceId==e.Owner)?(e.Contact==1?3:1):(e.Contact==1||e.Contact==ContactorCircuit.NcPin)&&Breakers.FirstOrDefault(b=>b.ReferenceId==e.Owner&&!b.IsBatteryModule&&!b.IsAnalyserModule&&!b.IsDoorPart&&!b.IsSmartOutputModule) is DinBreaker module?(module.IsFuseHolder?2:3):1;
        private int Occupied(CabinetWireEnd e)=>wires.Count(w=>w.From.Equals(e)||w.To.Equals(e));
        private void Changed(){HidePreview();revision++;routeRevision=-1;rebuild=true;Owner.NetworkUpdateFlags|=UpdateFlag;RefreshPower();}
        private void RefreshPower()
        {
            var modules=Breakers.ToArray();
            if(GameManager.RunSimulation)foreach(var id in Power.DrainTrips())modules.FirstOrDefault(b=>b.ReferenceId==id)?.Trip();
            if(GameManager.RunSimulation)
            {
                bool live=!Owner.IsCursor&&Owner.IsStructureCompleted&&Owner.GridController!=null&&(Owner.InputConnection?.GetCable()?.CableNetwork?.PotentialLoad??0)>0;
                var cells=modules.Where(m=>!m.IsBeingDestroyed&&m.IsBatteryModule&&m.Battery!=null&&m.Battery.PowerStored>0).Select(m=>m.ReferenceId);
                var energized=ContactorCircuit.Resolve(BaseCircuitWires,modules.Where(m=>!m.IsContactor&&m.Conducting).Select(m=>m.ReferenceId).Concat(Transformers.Where(t=>t.Conducting).Select(t=>t.ReferenceId)),modules.Where(m=>m.IsContactor&&!m.IsBeingDestroyed).Select(m=>m.ReferenceId),modules.Where(m=>m.IsContactor&&m.Conducting).Select(m=>m.ReferenceId),live,cells,Contactors.Where(c=>c.Conducting).Select(c=>new CabinetWireEnd(c.ReferenceId,SmartContactorCircuit.OutputPin)),modules.Where(m=>m.HasNormallyClosedContact&&!m.IsBeingDestroyed).Select(m=>m.ReferenceId));
                foreach(var contactor in modules.Where(m=>m.IsContactor))if(contactor.ContactorClosed!=energized.Contains(contactor.ReferenceId))
                {contactor.ContactorClosed=energized.Contains(contactor.ReferenceId);contactor.NetworkUpdateFlags|=32768;}
            }
            Power.RefreshNodes(Owner,CircuitWires.ToArray(),modules.Select(CabinetPowerNode.From).Concat(Transformers.Select(t=>t.PowerNode())));
            if(GameManager.RunSimulation&&Time.unscaledTime>=nextLedRefresh)
            {
                nextLedRefresh=Time.unscaledTime+.1f;
                var graph=CircuitWires.ToArray();var closed=PowerConducting.ToArray();
                bool inputLive=(Owner.InputConnection?.GetCable()?.CableNetwork?.PotentialLoad??0)>0;
                var cells=modules.Where(m=>m.IsBatteryModule&&m.Battery!=null&&m.Battery.PowerStored>0).Select(m=>m.ReferenceId).ToArray();
                foreach(var led in modules.Where(m=>m.IsDoorLed)){bool on=DoorModuleLayout.Energized(led.ReferenceId,graph,closed,inputLive,cells);if(led.DoorLit!=on){led.DoorLit=on;led.NetworkUpdateFlags|=32768;}}
            }
        }
        internal void Tick()
        {
            if(Owner==null||Owner.IsCursor||!Owner.IsStructureCompleted)return;
            if(Time.unscaledTime>=nextRefresh)
            {
                nextRefresh=Time.unscaledTime+.15f;RefreshContacts();
                if(GameManager.RunSimulation)
                    foreach(var actor in pendingUntil.Where(p=>p.Value<Time.unscaledTime).Select(p=>p.Key).ToArray())
                    {pending.Remove(actor);pendingUntil.Remove(actor);Owner.NetworkUpdateFlags|=UpdateFlag;}
            }
            if(!Owner.IsOpen&&GameManager.RunSimulation&&pending.Count>0){pending.Clear();pendingUntil.Clear();Owner.NetworkUpdateFlags|=UpdateFlag;}
            if(needsReroute&&GameManager.RunSimulation&&!PlacementBoard.Loading&&Owner.RailBoard!=null&&Time.unscaledTime>=topologyReadyAt&&wires.All(w=>contacts.ContainsKey(w.From)&&contacts.ContainsKey(w.To)))RerouteLegacy();
            if(cleanupOnLoad&&GameManager.RunSimulation&&!PlacementBoard.Loading&&Owner.RailBoard!=null&&Owner.DoorBoard!=null&&Owner.BridgeBoard!=null&&Time.unscaledTime>=topologyReadyAt+5f)
            {
                // A removed prefab has no live board owner after loading completes.
                // Drop only orphaned connections, never a still-loading module.
                var smartIds=new HashSet<long>(SmartIds);
                var outputs=new HashSet<long>(Contactors.Select(c=>c.ReferenceId));
                var obsolete=wires.Where(w=>smartIds.Contains(w.From.Owner)||(smartIds.Contains(w.To.Owner)&&w.To.Contact!=0)||!SmartContactorCircuit.Allowed(w.From,w.To,outputs,Breakers.Where(c=>c.IsContactor).Select(c=>c.ReferenceId))).ToArray();
                if(obsolete.Length>0)
                {
                    if(!CanRefundWires(obsolete))return; // Keep saved wires until every kind can be refunded.
                    RefundWires(obsolete,Owner.transform.position,null);
                    foreach(var wire in obsolete)wires.Remove(wire);
                    Changed();
                }
                var live=new HashSet<long>(Breakers.Select(m=>m.ReferenceId).Concat(Transformers.Select(t=>t.ReferenceId)).Concat(SmartIds).Concat(Contactors.Select(c=>c.ReferenceId)));
                int removed=wires.RemoveAll(w=>(w.From.Owner!=0&&!live.Contains(w.From.Owner))||(w.To.Owner!=0&&!live.Contains(w.To.Owner)));
                cleanupOnLoad=false;
                if(removed>0){Debug.Log("[Modular Switchboards] Removed "+removed+" orphaned wires after obsolete modules were discarded.");Changed();}
            }
            RefreshPower();
            if(rebuild){RebuildVisuals();rebuild=false;}
            bool show=Owner.IsOpen&&!Owner.HasInnerCover,tools=show&&LocalTools();
            if(visualRoot!=null)visualRoot.gameObject.SetActive(show);
            if(doorVisualRoot!=null)doorVisualRoot.gameObject.SetActive(Owner.IsOpen);if(rightDoorVisualRoot!=null)rightDoorVisualRoot.gameObject.SetActive(Owner.IsOpen);
            var human=GameManager.IsBatchMode?null:Human.LocalHuman;pending.TryGetValue(human!=null?human.ReferenceId:0,out var selected);
            foreach(var c in contacts.Values)
            {
                if(c.Marker==null)continue;
                bool available=Occupied(c.End)<Capacity(c.End)&&(selected==null||selected.Equals(c.End)||
                    CanConnectContacts(selected,c.End,out _));
                c.Marker.SetActive(tools&&available);
                var renderer=c.Marker.GetComponent<MeshRenderer>();
                if(renderer!=null)Color(renderer,c.End.Equals(selected)?ColorType.Yellow:c.End.IsNeutral?ColorType.Blue:c.End.IsSource?ColorType.Green:ColorType.Orange);
            }
            bool cutting=!GameManager.IsBatchMode&&InventoryManager.ActiveHandSlot?.Get() is WireCutter&&show;
            int hover=cutting&&CursorManager.Instance!=null?WireAt(CursorManager.CursorHit.point):-1;
            var paintedWire=!GameManager.IsBatchMode&&Owner.IsOpen&&InventoryManager.ActiveHandSlot?.Get() is ISprayer&&CursorManager.Instance!=null&&CursorManager.CursorThing==Owner
                ?PaintWireAt(CursorManager.CursorHit.point):null;
            foreach(var pair in wireRenderers)if(pair.Value!=null)Color(pair.Value,(hover>=0&&ReferenceEquals(wires[hover],pair.Key))||ReferenceEquals(paintedWire,pair.Key)?(WireColor(pair.Key)==ColorType.Yellow?ColorType.White:ColorType.Yellow):WireColor(pair.Key));
            if(!tools||!show||previewFrame!=Time.frameCount)HidePreview();
        }
        private void RefreshContacts()
        {
            if(!shapeReady&&Owner!=null){shapeReady=true;routingHalfWidth=(float)System.Math.Floor((CabinetShape.Width(Owner.PrefabName)*.5f-.032f+.000001f)/WireRouting.Step)*WireRouting.Step;routingHalfHeight=(float)System.Math.Floor((CabinetShape.Height(Owner.PrefabName)*.5f-.022f+.000001f)/WireRouting.Step)*WireRouting.Step;moduleReservations=WireModuleSpace.Reservations(CabinetShape.RailWidth(Owner.PrefabName),CabinetShape.Rows(Owner.PrefabName).Select(y=>y*.0018f)).ToArray();}

            if(Shell==null)return;
            var breakers=Breakers.Where(b=>!b.IsBeingDestroyed).ToArray();
            var transformers=Transformers.ToArray();
            var smart=SmartModules.Where(m=>!m.IsBeingDestroyed).ToArray();
            var contactors=Contactors.ToArray();
            var rails=Owner.RailBoard==null?new DinRail[0]:Owner.RailBoard.Structures.OfType<DinRail>().ToArray();
            var signature=string.Join(";",breakers.Select(b=>b.ReferenceId+":"+b.ModuleWidth+":"+(b.IsDoorPart?b.GetLocalGrid().ToString():Shell.InverseTransformPoint(b.Transform.position).ToString("F5"))).OrderBy(x=>x))+"|"+string.Join(";",rails.Select(r=>r.ReferenceId+":"+Shell.InverseTransformPoint(r.Transform.position).ToString("F5")).OrderBy(x=>x));
            signature+="|smart:"+string.Join(";",smart.Select(m=>m.ReferenceId+":"+Shell.InverseTransformPoint(m.transform.position).ToString("F5")));
            signature+="|transformers:"+string.Join(";",transformers.Select(t=>t.ReferenceId+":"+Shell.InverseTransformPoint(t.Transform.position).ToString("F5")));
            signature+="|contactors:"+string.Join(";",contactors.Select(c=>c.ReferenceId+":"+Shell.InverseTransformPoint(c.Transform.position).ToString("F5")));
            if(topology==signature&&contacts.Count>0)return;
            topology=signature;topologyReadyAt=Time.unscaledTime+.5f;ClearVisuals();contacts.Clear();railObstacles.Clear();
            foreach(var rail in rails)
            {
                var model=rail.transform.Find("DinRailModel");var mesh=model?.GetComponent<MeshFilter>()?.sharedMesh;
                if(model==null||mesh==null)continue;
                var bounds=mesh.bounds;var min=Vector3.one*float.MaxValue;var max=Vector3.one*float.MinValue;
                foreach(float x in new[]{bounds.min.x,bounds.max.x})foreach(float y in new[]{bounds.min.y,bounds.max.y})foreach(float z in new[]{bounds.min.z,bounds.max.z})
                {var p=Shell.InverseTransformPoint(model.TransformPoint(new Vector3(x,y,z)));min=Vector3.Min(min,p);max=Vector3.Max(max,p);}
                railObstacles.Add(new WireRect(min.x,max.x,min.y,max.y));
            }
            foreach(var terminal in Owner.GetComponentsInChildren<CabinetTerminalBlock>(true))
            {
                var p=Shell.InverseTransformPoint(terminal.FrontContactWorld(0));
                var center=Shell.InverseTransformPoint(terminal.transform.position);
                int index=(int)terminal.TerminalId;
                // Upper reverse outputs need a longer straight entry before the
                // route turns upward; keep the turn clear of its own fixed lead.
                float exitOffset=CabinetLayout.Reversed(Owner.PrefabName)&&index>0?.033f:.027f;
                AddContact(new CabinetWireEnd(0,index),p,Shell.InverseTransformPoint(terminal.transform.TransformPoint(terminal.SelectionPoint)),new Vector3(center.x,center.y+(center.y>0?-exitOffset:exitOffset),WireRouting.Plane),
                    new WireRect(center.x-.036f,center.x+.036f,center.y-.016f,center.y+.016f));
            }
            foreach(var breaker in breakers)
            {
                if(breaker.IsDoorPart){AddDoorContacts(breaker);continue;}
                var model=breaker.transform.Find("DinBreakerModel");if(model==null)continue;
                var center=Shell.InverseTransformPoint(model.position);
                var p0=Shell.InverseTransformPoint(model.TransformPoint(new Vector3(-.0088f,-.0375f,0)));
                var p1=Shell.InverseTransformPoint(model.TransformPoint(new Vector3(.0088f+(breaker.ModuleWidth-1)*DinLayout.SlotPitch/DinBreakerModel.VisualScale.x,.0375f,0)));
                var bounds=new WireRect(Mathf.Min(p0.x,p1.x),Mathf.Max(p0.x,p1.x),Mathf.Min(p0.y,p1.y),Mathf.Max(p0.y,p1.y));
                foreach(int pin in breaker.HasNormallyClosedContact?new[]{0,1,2,ContactorCircuit.NcPin}:breaker.IsContactor?new[]{0,1,2}:breaker.IsSmartOutputModule?new[]{0}:new[]{0,1})
                {
                    // Keep logical contact 0 for saved wires; only its physical entry moves down.
                    int physicalPin=breaker.IsSmartOutputModule?1:pin==2?0:pin==ContactorCircuit.NcPin?1:pin;
                    float contactX=breaker.ContactOffsetX+(breaker.IsContactor?(pin==0?.004f:pin==2?-.004f:breaker.HasNormallyClosedContact?(pin==1?.004f:-.004f):0):0);
                    var p=Shell.InverseTransformPoint(model.TransformPoint(Vector(WireContactLayout.BreakerEntry(physicalPin))+Vector3.right*contactX));
                    var exit=new Vector3(p.x,physicalPin==0?bounds.Top+.015375f:bounds.Bottom-.015375f,WireRouting.Plane);
                    AddContact(new CabinetWireEnd(breaker.ReferenceId,pin),p,Shell.InverseTransformPoint(model.TransformPoint(Vector(WireContactLayout.BreakerAim(physicalPin))+Vector3.right*contactX)),exit,bounds);
                }
            }
            foreach(var transformer in transformers)
            {
                var bounds3=CabinetWallMount.TransformedBounds(transformer.Bounds,Shell.worldToLocalMatrix*transformer.transform.localToWorldMatrix);
                var bounds=new WireRect(bounds3.min.x,bounds3.max.x,bounds3.min.y,bounds3.max.y);
                foreach(int pin in new[]{0,1})
                {
                    var p=Shell.InverseTransformPoint(transformer.transform.TransformPoint(pin==0?transformer.InternalInput:transformer.InternalOutput));
                    float rx=(p.x-(bounds.Left+bounds.Right)*.5f)/Mathf.Max(.001f,(bounds.Right-bounds.Left)*.5f),ry=(p.y-(bounds.Bottom+bounds.Top)*.5f)/Mathf.Max(.001f,(bounds.Top-bounds.Bottom)*.5f);
                    bool lateral=Mathf.Abs(rx)>Mathf.Abs(ry);float side=lateral?(rx<0?-1:1):0;
                    var exit=lateral?new Vector3(side<0?bounds.Left-.015375f:bounds.Right+.015375f,p.y,WireRouting.Plane):new Vector3(p.x,ry<0?bounds.Bottom-.015375f:bounds.Top+.015375f,WireRouting.Plane);
                    var end=new CabinetWireEnd(transformer.ReferenceId,pin);AddContact(end,p,Shell.InverseTransformPoint(transformer.transform.TransformPoint(pin==0?transformer.InternalInputAim:transformer.InternalOutputAim)),exit,bounds);contacts[end].LeadSide=side;
                }
            }
            foreach(var contactor in contactors)
            {
                var model=contactor.transform.Find("DinBreakerModel");if(model==null)continue;
                var p0=Shell.InverseTransformPoint(model.TransformPoint(new Vector3(-.0088f,-.0375f,0)));var p1=Shell.InverseTransformPoint(model.TransformPoint(new Vector3(.0088f+(SmartContactor.SlotCount-1)*DinLayout.SlotPitch/DinBreakerModel.VisualScale.x,.0375f,0)));
                var bounds=new WireRect(Mathf.Min(p0.x,p1.x),Mathf.Max(p0.x,p1.x),Mathf.Min(p0.y,p1.y),Mathf.Max(p0.y,p1.y));
                for(int pin=SmartContactorCircuit.OutputPin;pin<=SmartContactorCircuit.OutputPin;pin++)
                {
                    int physical=1;float x=SmartContactor.CenterX;
                    var entry=Shell.InverseTransformPoint(model.TransformPoint(Vector(WireContactLayout.BreakerEntry(physical))+Vector3.right*x));
                    var aim=Shell.InverseTransformPoint(model.TransformPoint(Vector(WireContactLayout.BreakerAim(physical))+Vector3.right*x));
                    AddContact(new CabinetWireEnd(contactor.ReferenceId,pin),entry,aim,new Vector3(entry.x,physical==0?bounds.Top+.015375f:bounds.Bottom-.015375f,WireRouting.Plane),bounds);
                }
            }
            foreach(var module in smart)
            {
                var model=module.transform.Find("DinBreakerModel");if(model==null)continue;
                var p0=Shell.InverseTransformPoint(model.TransformPoint(new Vector3(-.0088f,-.0375f,0)));
                var p1=Shell.InverseTransformPoint(model.TransformPoint(new Vector3(.0088f+3*DinLayout.SlotPitch/DinBreakerModel.VisualScale.x,.0375f,0)));
                var bounds=new WireRect(Mathf.Min(p0.x,p1.x),Mathf.Max(p0.x,p1.x),Mathf.Min(p0.y,p1.y),Mathf.Max(p0.y,p1.y));
                for(int pin=0;pin<1;pin++)
                {
                    var p=Shell.InverseTransformPoint(model.TransformPoint(Vector(WireContactLayout.BreakerEntry(pin))+Vector3.right*DinSmartLayout.CenterX));
                    var exit=new Vector3(p.x,pin==0?bounds.Top+.015375f:bounds.Bottom-.015375f,WireRouting.Plane);
                    AddContact(new CabinetWireEnd(module.ReferenceId,pin),p,Shell.InverseTransformPoint(model.TransformPoint(Vector(WireContactLayout.BreakerAim(pin))+Vector3.right*DinSmartLayout.CenterX)),exit,bounds);
                }
            }
            if(GameManager.RunSimulation)
            {
                var batteryIds=new HashSet<long>(breakers.Where(b=>b.IsBatteryModule||b.IsDoorPart||b.IsSmartOutputModule).Select(b=>b.ReferenceId).Concat(smart.Select(m=>m.ReferenceId)).Concat(contactors.Select(m=>m.ReferenceId)).Concat(transformers.Select(t=>t.ReferenceId)));
                foreach(var wire in wires)
                {
                    var points=Expand(wire.Points);
                    if((wire.From.Owner==0||batteryIds.Contains(wire.From.Owner))&&contacts.TryGetValue(wire.From,out var from)&&(points[0]-Point(from.Position)).Squared>.000001f)needsReroute=true;
                    if((wire.To.Owner==0||batteryIds.Contains(wire.To.Owner))&&contacts.TryGetValue(wire.To,out var to)&&(points[points.Length-1]-Point(to.Position)).Squared>.000001f)needsReroute=true;
                }
            }
            // References may not be loaded yet: do not prune saved wires until a real deconstruction event.
            revision++;routeRevision=-1;rebuild=true;

        }
        private void AddDoorContacts(DinBreaker module)
        {
            bool right=Owner.IsRightBoard(module.Board);var frame=DoorModules.Frame(Owner,right);if(frame==null)return;
            if(module.IsDoorBridge)
            {
                float y=Shell.InverseTransformPoint(module.transform.position).y;
                float x=Shell.InverseTransformPoint(module.transform.position).x,side=right?-1:1;
                float doorShift=CabinetShape.DoorBridgeShift(Owner.PrefabName);
                for(int pin=2;pin<4;pin++)
                {
                    bool door=pin==3;var end=new CabinetWireEnd(module.ReferenceId,pin);
                    var pos=new Vector3(door?side*(.163f-doorShift):x+side*.009f,y,door?.0114f:.0244f);
                    var aim=new Vector3(door?side*(.1678f-doorShift):x+side*.0042f,y,door?.01956f:.03256f);
                    var exit=new Vector3(door?side*(.153f-doorShift):x+side*.024f,y,door?.043f:WireRouting.Plane);
                    var body=door?new WireRect(right?-.181f+doorShift:.164f-doorShift,right?-.164f+doorShift:.181f-doorShift,y-.011f,y+.011f):new WireRect(x-.009f,x+.008f,y-.011f,y+.011f);
                    AddContact(end,pos,aim,exit,body);contacts[end].Door=door;contacts[end].Leaf=right?1:0;contacts[end].LeadSide=door?-side:side;
                }
                return;
            }
            var center=frame.InverseTransformPoint(module.transform.position);var box=new WireRect(center.x-.019f,center.x+.019f,center.y-.024f,center.y+.024f);
            for(int pin=0;pin<2;pin++)
            {
                float sign=pin==0?1:-1;var entry=frame.InverseTransformPoint(module.transform.TransformPoint(new Vector3(0,sign*.023f,-.030f)));
                var aim=frame.InverseTransformPoint(module.transform.TransformPoint(new Vector3(0,sign*.016f,-.0385f)));
                var end=new CabinetWireEnd(module.ReferenceId,pin);AddContact(end,entry,aim,new Vector3(entry.x,center.y+sign*.043f,.043f),box);contacts[end].Door=true;contacts[end].Leaf=right?1:0;
            }
        }
        private void AddContact(CabinetWireEnd end,Vector3 position,Vector3 aim,Vector3 exit,WireRect bounds)
        {contacts[end]=new Contact{End=end,Position=position,Aim=aim,Exit=exit,Bounds=bounds};}
        private bool TryContact(Attack attack,out Contact contact)
        {
            contact=null;if(Shell==null)return false;
            var p=attack.Position;float best=.016f*.016f;
            foreach(var c in contacts.Values){float distance=(p-Frame(c).TransformPoint(c.Aim)).sqrMagnitude;if(distance<best){best=distance;contact=c;}}
            return contact!=null;
        }
        internal bool ContainsInteractionPoint(Vector3 world)
        {
            if(Shell==null)return false;var p=Shell.InverseTransformPoint(world);
            if(Mathf.Abs(p.x)<CabinetShape.Width(Owner.PrefabName)*.5f-.01f&&Mathf.Abs(p.y)<CabinetShape.Height(Owner.PrefabName)*.5f-.01f&&p.z>=0&&p.z<.16f)return true;
            foreach(var frame in new[]{DoorFrame,DoorModules.Frame(Owner,true)})if(frame!=null){var q=frame.InverseTransformPoint(world);if(Mathf.Abs(q.x)<.19f&&Mathf.Abs(q.y)<CabinetShape.Height(Owner.PrefabName)*.5f-.02f&&q.z>=-.003f&&q.z<.09f)return true;}return false;
        }
        internal bool TryAttack(Attack attack,bool doAction,out Thing.DelayedActionInstance result)
        {
            result=null;
            if(attack.SourceItem is ISprayer sprayer&&TryPaintWire(attack,sprayer,doAction,out result))return true;
            bool cutting=attack.SourceItem is WireCutter;
            var coil=IsCoil(attack.SourceItem)?attack.SourceItem as Stackable:null;
            if(!cutting&&coil==null)return false;
            if(Owner.HasInnerCover){result=new Thing.DelayedActionInstance{Duration=0};result.Fail("Remove the inner cover with a wrench first.");return true;}
            HidePreview();
            result=new Thing.DelayedActionInstance{Duration=0};
            if(Owner.IsCursor||!Owner.IsStructureCompleted||!Owner.IsOpen){result.Fail("Open the completed cabinet first.");return true;}
            var actor=attack.SourceItem.RootParentHuman;
            if(actor==null){result.Fail("Hold a cable coil to connect, or wire cutters to remove a wire.");return true;}
            if((actor.Transform.position-Owner.Transform.position).sqrMagnitude>16f){result.Fail("Move closer to the cabinet.");return true;}
            RefreshContacts();
            if(migrationFailure!=null)result.AppendStateMessage(migrationFailure);
            long actorId=actor.ReferenceId;
            if(!cutting&&attack.IsDestroy)
            {
                result.ActionMessage="Cancel wire selection";
                if(doAction&&GameManager.RunSimulation){pending.Remove(actorId);pendingUntil.Remove(actorId);Owner.NetworkUpdateFlags|=UpdateFlag;}
                return true;
            }
            if(cutting)
            {
                result.ActionMessage="Cut internal wire";
                int index=WireAt(attack.Position);
                if(index<0){result.Fail("Aim at an internal wire to cut it.");return true;}
                result.ActionMessage="Cut "+CabinetWireKinds.Title(wires[index].CableKind)+" internal wire";
                var refund=CabinetCableCoils.RefundPrefab(wires[index].CableKind);
                if(refund==null){result.Fail("Cable coil prefab unavailable.");return true;}
                if(doAction&&GameManager.RunSimulation)
                {
                    int units=wires[index].CableUnits;
                    OnServer.CreateOrStack(refund,units,attack.Position,Quaternion.identity,attack.OtherHand);
                    wires.RemoveAt(index);pending.Remove(actorId);pendingUntil.Remove(actorId);Changed();
                }
                return true;
            }
            if(!TryContact(attack,out var target)){result.Fail("Choose a highlighted contact. Right click cancels; wire cutters remove a wire.");return true;}
            if(Occupied(target.End)>=Capacity(target.End)){result.Fail("Contact occupied.");return true;}
            if(!pending.TryGetValue(actorId,out var selected))
            {
                result.ActionMessage="Select "+ContactName(target.End);
                if(doAction&&GameManager.RunSimulation){pending[actorId]=target.End;pendingUntil[actorId]=Time.unscaledTime+60;Owner.NetworkUpdateFlags|=UpdateFlag;}
                return true;
            }
            if(selected.Equals(target.End))
            {
                result.ActionMessage="Cancel wire selection";
                if(doAction&&GameManager.RunSimulation){pending.Remove(actorId);pendingUntil.Remove(actorId);Owner.NetworkUpdateFlags|=UpdateFlag;}
                return true;
            }
            if(!contacts.ContainsKey(selected)){result.Fail("Selected contact no longer exists. Select it again.");if(doAction&&GameManager.RunSimulation){pending.Remove(actorId);Owner.NetworkUpdateFlags|=UpdateFlag;}return true;}
            if(!CanConnectContacts(selected,target.End,out var reason)){result.Fail(reason);return true;}
            if(wires.Count>=64){result.Fail("Cabinet wire capacity reached.");return true;}
            if(coil.Quantity<1){result.Fail("One cable coil unit is required.");return true;}
            WireCircuit.Orient(selected,target.End,out var from,out var to);
            if(routeRevision!=revision||!from.Equals(routeFrom)||!to.Equals(routeTo))
            {routeFrom=from;routeTo=to;routeRevision=revision;route=MakeRoute(from,to,out routeSlot,out routeFailure);}
            CabinetCableCoils.TryKind(coil,out var cableKind);
            result.ActionMessage="Wire ("+CabinetWireKinds.Title(cableKind)+") "+ContactName(from)+" -> "+ContactName(to);
            if(route==null){result.Fail(routeFailure??"No clear route. Move a wire or a breaker first.");return true;}
            if(!doAction)ShowPreview(route,cableKind);
            if(doAction&&GameManager.RunSimulation)
            {
                if(coil.RemoveQuantity(1)!=1){result.Fail("Cable coil is empty.");return true;}
                wires.Add(new CabinetWireSaveData{From=from,To=to,InputSlot=routeSlot,RouteVersion=CurrentRouteVersion,CableUnits=1,CableKind=cableKind,Points=Flatten(route)});
                pending.Remove(actorId);pendingUntil.Remove(actorId);Changed();
            }
            return true;
        }
        private int WireAt(Vector3 world,float radius=.012f)
        {
            float best=radius*radius;int found=-1;
            for(int i=0;i<wires.Count;i++){var frame=WireFrame(wires[i]);if(frame==null)continue;var p=Point(frame.InverseTransformPoint(world));var path=Expand(wires[i].Points);for(int j=1;j<path.Length;j++){float distance=WireRouting.SegmentDistanceSquared(p,p,path[j-1],path[j]);if(distance<best){best=distance;found=i;}}}return found;
        }
        private WirePoint[] MakeRoute(CabinetWireEnd from,CabinetWireEnd to,out int slot,out string failure)
        {
            var used=new HashSet<int>(wires.Where(w=>w.From.Equals(from)).Select(w=>w.InputSlot));
            var candidates=Enumerable.Range(0,16).Where(i=>!used.Contains(i)).OrderBy(i=>i==0?0:((contacts[to].Exit.x<=0)==(i%2==0)?i:100+i));
            if(from.Owner!=0)candidates=Enumerable.Range(0,Capacity(from)).Where(i=>!used.Contains(i)).OrderBy(i=>i);
            failure=null;slot=0;
            if(contacts[from].Door)
            {
                WirePoint[] best=null;float score=float.PositiveInfinity;
                // Compare cheap, simple lanes across depths before launching any
                // lattice search. Do not accept the first cramped depth blindly.
                foreach(float depth in new[]{.027f,.035f,.043f,.051f,.059f})
                foreach(int candidate in candidates)
                {
                    var simple=MakeRouteSlot(from,to,candidate,depth,out _,true);
                    if(simple==null)continue;
                    float value=WireLaneRoutes.Score(simple);
                    if(value<score){best=simple;score=value;slot=candidate;}
                }
                if(best!=null)return best;
            }
            foreach(var plane in contacts[from].Door?new[]{.027f,.035f,.043f,.051f,.059f}:new[]{WireRouting.Plane,.08135f,.09735f,.11335f})
            foreach(var candidate in candidates)
            {
                var found=MakeRouteSlot(from,to,candidate,plane,out failure);
                if(found!=null){slot=candidate;return found;}
            }
            return null;
        }
        private WirePoint[] MakeRouteSlot(CabinetWireEnd from,CabinetWireEnd to,int slot,float plane,out string failure,bool simpleOnly=false)
        {
            failure=null;var a=contacts[from];var b=contacts[to];
            bool joint=from.Owner==0&&from.Contact==0;bool door=a.Door;
            bool branch=from.Owner!=0&&Capacity(from)>1;
            float fan=slot==0?0:((slot+1)/2)*.008f*(slot%2==1?1:-1);
            var start=new WirePoint(a.Exit.x+(joint?fan:branch?(a.Exit.x>0?-1f:1f)*fan*1.5f:0),a.Exit.y,plane);var end=new WirePoint(b.Exit.x,b.Exit.y,plane);
            var reservations=door?DoorModuleLayout.Reservations(Owner.PrefabName):moduleReservations;
            var rails=door?Enumerable.Empty<WireRect>():railObstacles;
            var blocks=contacts.Values.Where(c=>Surface(c)==Surface(a)).Select(c=>c.Bounds).Concat(rails).Concat(reservations).Distinct().ToList();
            var same=wires.Where(w=>WireSurface(w)==Surface(a)).ToArray();
            var shared=branch?same.Where(w=>w.From.Equals(from)).Select(w=>Expand(w.Points)).ToList():new List<WirePoint[]>();
            var other=same.Where(w=>!branch||!w.From.Equals(from)).Select(w=>Expand(w.Points)).ToList();
            var fork=new WireRect(a.Position.x-.019f,a.Position.x+.019f,Math.Min(a.Position.y,a.Exit.y)-.009f,Math.Max(a.Position.y,a.Exit.y)+.009f);
            // Protect unused door terminals too: a first wire must not occupy
            // the depth-change pocket needed to connect the next channel.
            if(door)other.AddRange(contacts.Values.Where(c=>Surface(c)==Surface(a)&&!c.End.Equals(from)&&!c.End.Equals(to)).Select(c=>WireContactLayout.EntryLead(Point(c.Position),new WirePoint(c.Exit.x,c.Exit.y,.063f),c.LeadSide)));
            var occupied=other.Concat(shared.SelectMany(w=>WireBranchJoint.Outside(w,fork))).ToList();
            var sourceLead=WireContactLayout.EntryLead(Point(a.Position),start,a.LeadSide);
            var targetLead=WireContactLayout.EntryLead(Point(b.Position),end,b.LeadSide);
            // The central route must avoid its own fixed leads, just like other cables.
            // Leave only a small join pocket around each anchor.
            occupied.AddRange(WireBranchJoint.Outside(sourceLead,new WireRect(start.X-.009f,start.X+.009f,start.Y-.009f,start.Y+.009f)));
            occupied.AddRange(WireBranchJoint.Outside(targetLead,new WireRect(end.X-.009f,end.X+.009f,end.Y-.009f,end.Y+.009f)));
            int departure=WireContactLayout.ExitDirection(sourceLead),arrival=WireContactLayout.ExitDirection(targetLead);
            if(arrival>=0)arrival=(arrival+2)%4;
            var middle=simpleOnly?WireLaneRoutes.Find(start,end,blocks,occupied,arrival,departure,door?WireRouting.HalfWidth:routingHalfWidth,routingHalfHeight):WireRouting.Find(start,end,blocks,occupied,joint,arrival,departure,door?WireRouting.HalfWidth:routingHalfWidth,routingHalfHeight);
            if(middle==null){failure="No clear route around devices and installed wires.";return null;}
            var path=new List<WirePoint>(sourceLead);
            path.AddRange(middle.Skip(1));path.AddRange(targetLead.Reverse().Skip(1));
            // Check contact leads too; the router only controls the central part.
            var leadReservations=WireModuleSpace.ForLead(reservations,from.Owner==0?(WireRect?)null:a.Bounds,to.Owner==0?(WireRect?)null:b.Bounds);
            var exceptOwn=contacts.Values.Where(c=>Surface(c)==Surface(a)&&!c.End.Equals(from)&&!c.End.Equals(to)&&
                    !(c.End.Owner!=0&&(c.End.Owner==from.Owner||c.End.Owner==to.Owner))).Select(c=>c.Bounds).Concat(rails).Concat(leadReservations).Distinct().ToList();
            Func<WirePoint,WirePoint,bool> clear=(p,q)=>WireRouting.Clear(p,q,exceptOwn,other,joint)&&
                WireBranchJoint.Clear(p,q,shared,fork);
            for(int i=1;i<path.Count;i++)
            {
                if(!clear(path[i-1],path[i])){failure="A contact lead is blocked by another wire or device.";return null;}
            }
            var result=path.Where((p,i)=>i==0||(p-path[i-1]).Squared>1e-12f).ToArray();
            result=WireTube.Clean(result,clear);
            if(result.Length>512){failure="The route is too complex. Move a wire or device first.";return null;}
            if(WireRouting.SelfIntersects(result)){failure="The route would intersect its own contact lead.";return null;}
            // Store the rounded centreline itself: preview, hit testing, saves and
            // subsequent wire clearance all use exactly the rendered route.
            foreach(float cut in new[]{.008f,.006f,.004f})
            {
                var rounded=WireTube.Round(result,cut);
                if(rounded.Length>512||WireRouting.SelfIntersects(rounded))continue;
                bool roundedClear=true;
                for(int i=1;i<rounded.Length;i++)if(!clear(rounded[i-1],rounded[i])){roundedClear=false;break;}
                if(roundedClear)return rounded;
            }
            // A quick lane must not trade smooth bends for a square dogleg.
            // Let the lattice fallback find more room if no fillet fits.
            return simpleOnly?null:result;
        }
        internal bool WouldBlockModule(PlacementBoard board,Grid3 position,int width=1)
        {
            if(Shell==null)return false;
            var c=Shell.InverseTransformPoint(board.GridToWorld(position));
            var first=WireModuleSpace.At(c.x,c.y);var last=WireModuleSpace.At(c.x+(width-1)*DinLayout.SlotPitch,c.y);
            var r=new WireRect(first.Left,last.Right,first.Bottom,first.Top);
            return wires.Where(w=>!IsDoorWire(w)).Any(w=>{var p=Expand(w.Points);for(int i=1;i<p.Length;i++)if(WireRouting.SegmentHitsRect(p[i-1],p[i],r,WireRouting.Radius+.001f))return true;return false;});
        }
        internal bool WouldBlockRail(PlacementBoard board,Grid3 position)
        {
            if(Shell==null)return false;
            var center=Shell.InverseTransformPoint(board.GridToWorld(position));
            var bounds=new WireRect(center.x-.162f,center.x+.162f,center.y-.0175f,center.y+.0175f);
            return wires.Where(w=>!IsDoorWire(w)).Any(w=>{var path=Expand(w.Points);for(int i=1;i<path.Length;i++)if(WireRouting.SegmentHitsRect(path[i-1],path[i],bounds,WireRouting.Radius+.001f))return true;return false;});
        }
        private void RerouteLegacy()
        {
            needsReroute=false;var backup=wires.ToArray();wires.Clear();
            foreach(var old in backup.OrderBy(w=>w.From.Owner==0?0:1))
            {
                var path=MakeRoute(old.From,old.To,out var slot,out var failure);
                if(path==null)
                {
                    wires.Clear();wires.AddRange(backup);migrationFailure="Existing route needs manual rewiring: "+failure;
                    Debug.LogWarning("[Modular Switchboards] "+migrationFailure+" Connections and coil quantities preserved.");return;
                }
                wires.Add(new CabinetWireSaveData{From=old.From,To=old.To,InputSlot=slot,RouteVersion=CurrentRouteVersion,CableUnits=old.CableUnits,CableKind=old.CableKind,ColorIndex=old.ColorIndex,Points=Flatten(path)});
            }
            migrationFailure=null;Changed();
            Debug.Log("[Modular Switchboards] Existing wiring rerouted around reserved future module spaces without changing connections or coil quantities.");
        }
        private void HidePreview(){if(preview!=null)preview.SetActive(false);}
        private void ShowPreview(WirePoint[] path,CabinetWireKind kind)
        {
            if(GameManager.IsBatchMode||Shell==null)return;
            if(preview==null)
            {
                preview=new GameObject("WireRoutePreview"){layer=Owner.gameObject.layer};preview.transform.SetParent(Shell,false);
                preview.AddComponent<MeshFilter>();var renderer=preview.AddComponent<MeshRenderer>();renderer.sharedMaterial=CabinetGeometry.Materials[3];Color(renderer,ColorType.Yellow);
            }
            if(!ReferenceEquals(previewPath,path)||previewKind!=kind)
            {
                var filter=preview.GetComponent<MeshFilter>();if(filter.sharedMesh!=null)Destroy(filter.sharedMesh);
                filter.sharedMesh=WireMesh.Build(path,kind);
                var renderer=preview.GetComponent<MeshRenderer>();WireVisualGenerator.Surface(renderer,kind);Color(renderer,ColorType.Yellow);previewPath=path;previewKind=kind;
            }
            preview.transform.SetParent(contacts.TryGetValue(routeFrom,out var c)?Frame(c):Shell,false);
            previewFrame=Time.frameCount;preview.SetActive(Owner.IsOpen);
        }
        private static bool CanRefundWires(IEnumerable<CabinetWireSaveData> batch)=>batch.All(w=>CabinetCableCoils.RefundPrefab(w.CableKind)!=null);
        internal bool CanRefundBreaker(long id)=>CanRefundWires(wires.Where(w=>w.From.Owner==id||w.To.Owner==id));
        private static void RefundWires(IEnumerable<CabinetWireSaveData> batch,Vector3 position,Slot destination)
        {
            foreach(var group in batch.GroupBy(w=>w.CableKind))
                OnServer.CreateOrStack(CabinetCableCoils.RefundPrefab(group.Key),group.Sum(w=>w.CableUnits),position,Quaternion.identity,destination);
        }
        internal void RefundAndRemoveBreaker(long id,Vector3 position,Slot destination)
        {
            if(!GameManager.RunSimulation)return;
            var batch=wires.Where(w=>w.From.Owner==id||w.To.Owner==id).ToArray();
            if(!CanRefundWires(batch))throw new InvalidOperationException("Cable coil prefab unavailable during module demolition");
            RefundWires(batch,position,destination);RemoveBreaker(id);
        }
        internal void RemoveBreaker(long id)
        {
            if(wires.RemoveAll(w=>w.From.Owner==id||w.To.Owner==id)>0)Changed();
            foreach(var actor in pending.Where(p=>p.Value.Owner==id).Select(p=>p.Key).ToArray()){pending.Remove(actor);pendingUntil.Remove(actor);Owner.NetworkUpdateFlags|=UpdateFlag;}
            topology=null;
        }
        internal static float[] Flatten(IList<WirePoint> points){var result=new float[points.Count*3];for(int i=0;i<points.Count;i++){result[i*3]=points[i].X;result[i*3+1]=points[i].Y;result[i*3+2]=points[i].Z;}return result;}
        internal static WirePoint[] Expand(float[] values)
        {if(values==null||values.Length%3!=0)return new WirePoint[0];var result=new WirePoint[values.Length/3];for(int i=0;i<result.Length;i++)result[i]=new WirePoint(values[i*3],values[i*3+1],values[i*3+2]);return result;}
        internal CabinetWireSaveData[] Save()=>wires.ToArray();
        internal void Load(IEnumerable<CabinetWireSaveData> saved)
        {
            wires.Clear();pending.Clear();pendingUntil.Clear();cleanupOnLoad=GameManager.RunSimulation;
            if(saved!=null)foreach(var w in saved.Take(64))
                if(Valid(w)&&WireCircuit.CanConnect(w.From,w.To,wires,wires.SelectMany(x=>new[]{x.From.Owner,x.To.Owner}).Concat(new[]{w.From.Owner,w.To.Owner}).Where(id=>id!=0).Distinct(),out _,allowLegacyBypass:true))wires.Add(w);
            needsReroute=GameManager.RunSimulation&&wires.Any(w=>w.RouteVersion<CurrentRouteVersion);
            topology=null;revision++;routeRevision=-1;rebuild=true;
        }
        private bool Valid(CabinetWireSaveData w)=>w!=null&&ValidEnd(w.From)&&ValidEnd(w.To)&&(w.From.IsSource||w.From.IsNeutral)&&(!w.To.IsSource||w.To.IsNeutral)&&w.Points!=null&&w.Points.Length>=6&&w.Points.Length<=1536&&w.Points.Length%3==0&&w.CableUnits==1&&CabinetWireKinds.Valid(w.CableKind)&&w.RouteVersion>=0&&w.RouteVersion<=CurrentRouteVersion&&w.InputSlot>=0&&w.InputSlot<16&&
            Expand(w.Points).All(p=>!float.IsNaN(p.X)&&!float.IsInfinity(p.X)&&!float.IsNaN(p.Y)&&!float.IsInfinity(p.Y)&&!float.IsNaN(p.Z)&&!float.IsInfinity(p.Z)&&Math.Abs(p.X)<=CabinetShape.Width(Owner?.PrefabName)*.5f-((w.From.IsNeutral||w.To.IsNeutral)?0f:.02f)&&Math.Abs(p.Y)<=CabinetShape.Height(Owner?.PrefabName)*.5f-.01f&&p.Z>=0&&p.Z<=.15f);
        private static bool ValidEnd(CabinetWireEnd e)=>e!=null&&e.Owner>=0&&e.Contact>=0&&(e.Contact<4||e.Owner!=0&&e.Contact==ContactorCircuit.NcPin);
        internal void Write(RocketBinaryWriter writer)
        {
            writer.WriteInt32(-3);writer.WriteInt32(wires.Count);foreach(var w in wires){WriteEnd(writer,w.From);WriteEnd(writer,w.To);writer.WriteInt32(w.InputSlot);writer.WriteInt32(w.RouteVersion);writer.WriteInt32(w.ColorIndex);writer.WriteInt32((int)w.CableKind);writer.WriteInt32(w.Points.Length);foreach(var p in w.Points)writer.WriteSingle(p);}
            writer.WriteInt32(pending.Count);foreach(var p in pending){writer.WriteInt64(p.Key);WriteEnd(writer,p.Value);}
        }
        internal void Read(RocketBinaryReader reader)
        {
            int header=reader.ReadInt32();bool typed=header==-3;bool colored=typed||header==-2;int count=colored?reader.ReadInt32():header;if(count<0||count>64)throw new InvalidOperationException("Invalid cabinet wire count.");var loaded=new List<CabinetWireSaveData>();
            for(int i=0;i<count;i++){var w=new CabinetWireSaveData{From=ReadEnd(reader),To=ReadEnd(reader),InputSlot=reader.ReadInt32(),RouteVersion=reader.ReadInt32()};if(colored)w.ColorIndex=reader.ReadInt32();if(typed){w.CableKind=(CabinetWireKind)reader.ReadInt32();if(!CabinetWireKinds.Valid(w.CableKind))throw new InvalidOperationException("Invalid cabinet wire kind.");}int n=reader.ReadInt32();if(n<6||n>1536||n%3!=0)throw new InvalidOperationException("Invalid cabinet wire path.");w.Points=new float[n];for(int j=0;j<n;j++)w.Points[j]=reader.ReadSingle();loaded.Add(w);}Load(loaded);
            count=reader.ReadInt32();if(count<0||count>128)throw new InvalidOperationException("Invalid cabinet wire selection count.");for(int i=0;i<count;i++){long actor=reader.ReadInt64();var end=ReadEnd(reader);if(ValidEnd(end))pending[actor]=end;}
        }
        private static void WriteEnd(RocketBinaryWriter writer,CabinetWireEnd end){writer.WriteInt64(end.Owner);writer.WriteInt32(end.Contact);}
        private static CabinetWireEnd ReadEnd(RocketBinaryReader reader)=>new CabinetWireEnd(reader.ReadInt64(),reader.ReadInt32());
        internal static bool IsWireVisual(string name)=>name=="InternalWire"||name=="WireContact"||name=="WireRoutePreview";
        private void Color(MeshRenderer renderer,ColorType color)
        {
            // Per-material blocks override renderer-wide blocks. Write at slot 0,
            // so a stale cabinet color can never mask this wire's own color.
            var block=new MaterialPropertyBlock();renderer.GetPropertyBlock(block,0);
            block.SetFloat(Thing.DiffuseIndexPropertyID,(int)color);block.SetColor(Thing.EMISSION_COLOR,UnityEngine.Color.black);
            renderer.SetPropertyBlock(block,0);
        }
        private void Register(Collider c){colliders.Add(c);Thing._colliderLookup[c]=Owner;}
        private void ClearVisuals()
        {
            if(preview!=null){preview.SetActive(false);var mesh=preview.GetComponent<MeshFilter>()?.sharedMesh;if(mesh!=null)Destroy(mesh);Destroy(preview);preview=null;previewPath=null;}
            wireRenderers.Clear();
            foreach(var c in colliders)if(c!=null&&Thing._colliderLookup.TryGetValue(c,out var thing)&&thing==Owner)Thing._colliderLookup.Remove(c);colliders.Clear();
            foreach(var go in visuals)if(go!=null){go.SetActive(false);var filter=go.GetComponent<MeshFilter>();if(filter!=null&&go.name=="InternalWire")Destroy(filter.sharedMesh);Destroy(go);}visuals.Clear();
            if(visualRoot!=null){visualRoot.gameObject.SetActive(false);Destroy(visualRoot.gameObject);visualRoot=null;}
            if(doorVisualRoot!=null){doorVisualRoot.gameObject.SetActive(false);Destroy(doorVisualRoot.gameObject);doorVisualRoot=null;}
            if(rightDoorVisualRoot!=null){rightDoorVisualRoot.gameObject.SetActive(false);Destroy(rightDoorVisualRoot.gameObject);rightDoorVisualRoot=null;}
            foreach(var c in contacts.Values)c.Marker=null;
        }
        private void RebuildVisuals()
        {
            ClearVisuals();if(Shell==null||GameManager.IsBatchMode)return;
            visualRoot=new GameObject("InternalWiring").transform;visualRoot.SetParent(Shell,false);
            doorVisualRoot=new GameObject("DoorInternalWiring").transform;doorVisualRoot.SetParent(DoorFrame,false);
            var rightFrame=DoorModules.Frame(Owner,true);if(rightFrame!=null){rightDoorVisualRoot=new GameObject("RightDoorInternalWiring").transform;rightDoorVisualRoot.SetParent(rightFrame,false);}
            foreach(var wire in wires)
            {
                if(!contacts.ContainsKey(wire.From)||!contacts.ContainsKey(wire.To))continue;
                var path=Expand(wire.Points);if(path.Length<2)continue;
                var go=new GameObject("InternalWire"){layer=Owner.gameObject.layer};go.transform.SetParent(IsDoorWire(wire)?(contacts[wire.From].Leaf==1?rightDoorVisualRoot:doorVisualRoot):visualRoot,false);visuals.Add(go);
                go.AddComponent<MeshFilter>().sharedMesh=WireMesh.Build(path,wire.CableKind);
                var renderer=go.AddComponent<MeshRenderer>();renderer.sharedMaterial=CabinetGeometry.Materials[3];WireVisualGenerator.Surface(renderer,wire.CableKind);Color(renderer,WireColor(wire));wireRenderers[wire]=renderer;
                for(int i=1;i<path.Length;i++)
                {
                    var a=Vector(path[i-1]);var b=Vector(path[i]);var delta=b-a;if(delta.sqrMagnitude<1e-10f)continue;
                    var hit=new GameObject("WireHit"){layer=Owner.gameObject.layer};hit.transform.SetParent(go.transform,false);hit.transform.localPosition=(a+b)*.5f;hit.transform.localRotation=Quaternion.LookRotation(delta);
                    var box=hit.AddComponent<BoxCollider>();box.size=new Vector3(.006f,.006f,delta.magnitude);Register(box);hit.AddComponent<CabinetWirePaintTarget>().Wire=wire;
                }
            }
            foreach(var c in contacts.Values)
            {
                var go=new GameObject("WireContact"){layer=Owner.gameObject.layer};go.transform.SetParent(Frame(c),false);go.transform.localPosition=c.Aim+Vector3.forward*.004f;
                go.AddComponent<MeshFilter>().sharedMesh=WireMesh.Contact;
                go.AddComponent<MeshRenderer>().sharedMaterial=CabinetGeometry.Materials[3];var target=go.AddComponent<CabinetWireTarget>();target.End=c.End;
                var hit=go.AddComponent<SphereCollider>();hit.radius=.0075f;Register(hit);visuals.Add(go);c.Marker=go;go.SetActive(false);
            }
        }
        private void OnDestroy()=>ClearVisuals();
    }
    internal static class WireMesh
    {
        private static Mesh contact;
        internal static Mesh Contact
        {
            get
            {
                if(contact!=null)return contact;
                var v=new[]{Vector3.right,Vector3.left,Vector3.up,Vector3.down,Vector3.forward,Vector3.back};
                contact=new Mesh{name="Switchboards.WireContact"};contact.vertices=v.Select(p=>p*.0045f).ToArray();
                contact.triangles=new[]{4,0,2,4,2,1,4,1,3,4,3,0,5,2,0,5,1,2,5,3,1,5,0,3};contact.RecalculateNormals();CabinetGeometry.ApplyNativeUv(contact);contact.RecalculateBounds();return contact;
            }
        }
        internal static Mesh Build(WirePoint[] path,CabinetWireKind kind=CabinetWireKind.Normal)=>WireVisualGenerator.Build(path,kind);
    }
}
