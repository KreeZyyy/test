# ModularSwitchboards — 2026-10-18

Latest published: 0.12.35, GitHub KreeZyyy/test main 4880634.
Prepared locally: 0.12.36, fixes from user screenshot; see README.md and Verification/Wiring-0.12.36.json.

36 changes: active standard Cable Coil alone connects with single clicks, filters compatible free contacts and previews full route. Active Wire Cutters alone cut with a primary click, hover highlights wire, native CreateOrStack refunds coil to offhand/world. Scoped InventoryManager NormalMode/PlacementMode hooks suppress native kit preview only inside open completed cabinet, restore it outside. Authority still handles mutations via OnServer.AttackWith.

Wires now 4.8mm diameter (50% thicker), centre clearance6.4mm. Routing includes actual DIN rail bounds at every depth, uses side corridors. Terminal front hole/screw positions reversed toward interior wiring; short direct contact leads remove hooks. Output labels beside terminals. Saved old routes migrate after board loading and topology settle, retain endpoints/coil cost; complete rollback if any route fails. New direct IN->Output bypass disallowed; legacy direct bypass preserved and may need user rewiring through breaker. New rails cannot overlap wires.

RouteVersion XML/binary field introduced (2 for current geometry); server and clients must all use36. No changes to native electricity accounting/independent branches from35. No neutral; overcurrent trip not yet implemented.

Build passed zero errors/warnings; 10044 circuit/routing/serde checks, full production routing/migration fixtures, 17 production input-hook checks passed against stubs. Real game control/rendering/network transfer needs user validation.

Source /workspace/work/switchboard-redesign. Distribution repo /workspace/test. SDK /workspace/work/dotnet/dotnet. Dependencies under build-reference/rocketstation_Data/Managed. Preserve downloads/ModularSwitchboards-0.12.7-BASE-BACKUP.zip.

Publication of36 not yet authorized explicitly. Earlier automatic approval reviews required user consent for each specific new release; approvals for34 and35 did not cover later payloads. Prepare both archives and ask before publishing36 to KreeZyyy/test/downloads. User prefers concise Czech updates and action.
