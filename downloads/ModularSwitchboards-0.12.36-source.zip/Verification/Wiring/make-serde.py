from pathlib import Path
s=(Path(__file__).resolve().parents[2]/'Source/CabinetWiring.cs').read_text();a=s.index('        internal static float[] Flatten');b=s.index('        private void Color',a)
out='''using System;using System.Linq;using System.Collections.Generic;using System.IO;using ModularSwitchboards;
class RocketBinaryWriter{readonly BinaryWriter w;public RocketBinaryWriter(Stream s){w=new(s);}public void WriteInt32(int i)=>w.Write(i);public void WriteInt64(long i)=>w.Write(i);public void WriteSingle(float f)=>w.Write(f);}
class RocketBinaryReader{readonly BinaryReader r;public RocketBinaryReader(Stream s){r=new(s);}public int ReadInt32()=>r.ReadInt32();public long ReadInt64()=>r.ReadInt64();public float ReadSingle()=>r.ReadSingle();}
static class GameManager{public static bool RunSimulation=false;}
class SerdeHarness{readonly List<CabinetWireSaveData> wires=new();readonly Dictionary<long,CabinetWireEnd> pending=new();readonly Dictionary<long,float> pendingUntil=new();string topology;int revision,routeRevision;bool rebuild,needsReroute;
'''+s[a:b]+'''
 internal static void Run(){var h=new SerdeHarness();var a=new CabinetWireEnd(0,0);var b=new CabinetWireEnd(51,0);var wire=new CabinetWireSaveData{From=a,To=b,InputSlot=3,RouteVersion=2,Points=new[]{0f,.217f,.0463f,.012f,.171f,.108f}};h.Load(new[]{wire});h.pending[123]=a;using var stream=new MemoryStream();h.Write(new(stream));stream.Position=0;var restored=new SerdeHarness();restored.Read(new(stream));if(restored.wires.Count!=1||restored.wires[0].InputSlot!=3||restored.wires[0].RouteVersion!=2||!restored.wires[0].To.Equals(b)||!restored.wires[0].Points.SequenceEqual(wire.Points)||!restored.pending[123].Equals(a))throw new Exception("Wire network roundtrip failed");
 GameManager.RunSimulation=true;var old=new CabinetWireSaveData{From=new(0,0),To=new(0,2),RouteVersion=0,Points=new[]{0f,.205f,.0463f,.1f,-.205f,.0463f}};restored.Load(new[]{old});if(restored.wires.Count!=1||!restored.needsReroute)throw new Exception("Legacy bypass or migration request lost");GameManager.RunSimulation=false;
 wire.Points[0]=float.NaN;restored.Load(new[]{wire});if(restored.wires.Count!=0)throw new Exception("Invalid path accepted");using var bad=new MemoryStream();new RocketBinaryWriter(bad).WriteInt32(65);bad.Position=0;bool rejected=false;try{restored.Read(new(bad));}catch(InvalidOperationException){rejected=true;}if(!rejected)throw new Exception("Invalid network count accepted");Console.WriteLine("Production wire save/network serialization passed: endpoints, exact path, fan slot, player selection and malformed data guards.");}
}
'''
(Path(__file__).resolve().parent/'SerdeHarness.cs').write_text(out)
