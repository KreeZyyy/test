using System;
using System.Collections.Generic;
using System.Linq;

namespace ModularSwitchboards
{
    // Pure geometry, also exercised without Unity. All coordinates are cabinet-local metres.
    public struct WirePoint
    {
        public float X,Y,Z;
        public WirePoint(float x,float y,float z){X=x;Y=y;Z=z;}
        public static WirePoint operator +(WirePoint a,WirePoint b)=>new WirePoint(a.X+b.X,a.Y+b.Y,a.Z+b.Z);
        public static WirePoint operator -(WirePoint a,WirePoint b)=>new WirePoint(a.X-b.X,a.Y-b.Y,a.Z-b.Z);
        public static WirePoint operator *(WirePoint a,float n)=>new WirePoint(a.X*n,a.Y*n,a.Z*n);
        public float Squared=>X*X+Y*Y+Z*Z;
        public static float Dot(WirePoint a,WirePoint b)=>a.X*b.X+a.Y*b.Y+a.Z*b.Z;
    }
    public struct WireRect
    {
        public float Left,Right,Bottom,Top;
        public WireRect(float l,float r,float b,float t){Left=l;Right=r;Bottom=b;Top=t;}
        public bool Contains(WirePoint p,float margin=0)=>p.X>=Left-margin&&p.X<=Right+margin&&p.Y>=Bottom-margin&&p.Y<=Top+margin;
    }
    internal static class WireRouting
    {
        internal const float Radius=.0024f,Clearance=.0064f,Step=.003f,Plane=.108f;
        internal const float HalfWidth=.168f,HalfHeight=.228f;
        // Fan-out at IN is one deliberate electrical joint, not an accidental crossing.
        internal static bool InInputJoint(WirePoint p)=>Math.Abs(p.X)<.032f&&p.Y>.188f;
        internal static float SegmentDistanceSquared(WirePoint a,WirePoint b,WirePoint c,WirePoint d)
        {
            var u=b-a;var v=d-c;var w=a-c;float aa=u.Squared,bb=WirePoint.Dot(u,v),cc=v.Squared,dd=WirePoint.Dot(u,w),ee=WirePoint.Dot(v,w);
            if(aa<1e-12f&&cc<1e-12f)return w.Squared;
            float s=aa<1e-12f?0:Math.Max(0,Math.Min(1,(bb*ee-cc*dd)/Math.Max(1e-12f,aa*cc-bb*bb)));
            float t=cc<1e-12f?0:Math.Max(0,Math.Min(1,(bb*s+ee)/cc));
            s=aa<1e-12f?0:Math.Max(0,Math.Min(1,(bb*t-dd)/aa));
            t=cc<1e-12f?0:Math.Max(0,Math.Min(1,(bb*s+ee)/cc));
            return (a+u*s-c-v*t).Squared;
        }
        internal static bool SegmentHitsRect(WirePoint a,WirePoint b,WireRect r,float margin)
        {
            float lo=0,hi=1;
            return ClipAxis(a.X,b.X-a.X,r.Left-margin,r.Right+margin,ref lo,ref hi)&&
                ClipAxis(a.Y,b.Y-a.Y,r.Bottom-margin,r.Top+margin,ref lo,ref hi);
        }
        private static bool ClipAxis(float start,float delta,float min,float max,ref float lo,ref float hi)
        {
            if(Math.Abs(delta)<1e-9f)return start>=min&&start<=max;
            float p=(min-start)/delta,q=(max-start)/delta;if(p>q){float t=p;p=q;q=t;}lo=Math.Max(lo,p);hi=Math.Min(hi,q);return lo<=hi;
        }
        private static float BoundsDistanceSquared(WirePoint a,WirePoint b,WirePoint c,WirePoint d)
        {
            float x=Math.Max(0,Math.Max(Math.Min(a.X,b.X)-Math.Max(c.X,d.X),Math.Min(c.X,d.X)-Math.Max(a.X,b.X)));
            float y=Math.Max(0,Math.Max(Math.Min(a.Y,b.Y)-Math.Max(c.Y,d.Y),Math.Min(c.Y,d.Y)-Math.Max(a.Y,b.Y)));
            float z=Math.Max(0,Math.Max(Math.Min(a.Z,b.Z)-Math.Max(c.Z,d.Z),Math.Min(c.Z,d.Z)-Math.Max(a.Z,b.Z)));
            return x*x+y*y+z*z;
        }
        internal static bool Clear(WirePoint a,WirePoint b,IList<WireRect> blocks,IList<WirePoint[]> wires,bool inputJoint)
        {
            foreach(var r in blocks)if(SegmentHitsRect(a,b,r,Radius+.001f))return false;
            foreach(var wire in wires)for(int i=1;i<wire.Length;i++)
            {
                if(BoundsDistanceSquared(a,b,wire[i-1],wire[i])>=Clearance*Clearance)continue;
                // Shared IN wires may meet in the physical terminal joint, but their
                // portions outside that joint still require full 3D clearance.
                if(inputJoint&&wire.Length>0&&InInputJoint(wire[0]))
                {
                    var first=OutsideInputJoint(a,b);var second=OutsideInputJoint(wire[i-1],wire[i]);
                    for(int x=0;x<first.Length;x+=2)for(int y=0;y<second.Length;y+=2)
                        if(SegmentDistanceSquared(first[x],first[x+1],second[y],second[y+1])<Clearance*Clearance)return false;
                    continue;
                }
                if(SegmentDistanceSquared(a,b,wire[i-1],wire[i])<Clearance*Clearance)return false;
            }
            return true;
        }
        private static WirePoint[] OutsideInputJoint(WirePoint a,WirePoint b)
        {
            float enter=0,exit=1;float[] start={a.X,a.Y},delta={b.X-a.X,b.Y-a.Y},min={-.032f,.188f},max={.032f,.24f};
            for(int axis=0;axis<2;axis++)
            {
                if(Math.Abs(delta[axis])<1e-9f){if(start[axis]<min[axis]||start[axis]>max[axis])return new[]{a,b};}
                else
                {
                    float u=(min[axis]-start[axis])/delta[axis],v=(max[axis]-start[axis])/delta[axis];if(u>v){float t=u;u=v;v=t;}
                    enter=Math.Max(enter,u);exit=Math.Min(exit,v);if(enter>exit)return new[]{a,b};
                }
            }
            var outside=new List<WirePoint>();if(enter>0){outside.Add(a);outside.Add(a+(b-a)*enter);}if(exit<1){outside.Add(a+(b-a)*exit);outside.Add(b);}return outside.ToArray();
        }
        internal static bool SelfIntersects(IList<WirePoint> path)
        {
            for(int i=1;i<path.Count;i++)
            {
                float gap=0;
                for(int j=i+1;j<path.Count;j++)
                {
                    if(j>i+1)gap+=(float)Math.Sqrt((path[j-1]-path[j-2]).Squared);
                    if(gap<Radius*2)continue;
                    if(SegmentDistanceSquared(path[i-1],path[i],path[j-1],path[j])<Radius*Radius*4)return true;
                }
            }
            return false;
        }
        private struct Entry {internal int Node;internal float Score;internal Entry(int n,float s){Node=n;Score=s;}}
        private sealed class Heap
        {
            readonly List<Entry> list=new List<Entry>();
            internal int Count=>list.Count;
            internal void Push(int node,float score){var e=new Entry(node,score);int i=list.Count;list.Add(e);while(i>0){int p=(i-1)/2;if(list[p].Score<=score)break;list[i]=list[p];i=p;}list[i]=e;}
            internal Entry Pop(){var result=list[0];var last=list[list.Count-1];list.RemoveAt(list.Count-1);if(list.Count==0)return result;int i=0;while(i*2+1<list.Count){int c=i*2+1;if(c+1<list.Count&&list[c+1].Score<list[c].Score)c++;if(list[c].Score>=last.Score)break;list[i]=list[c];i=c;}list[i]=last;return result;}
        }
        internal static WirePoint[] Find(WirePoint start,WirePoint end,IList<WireRect> blocks,IList<WirePoint[]> wires,bool inputJoint,int goalDirection=-1)
        {
            const int nx=113,ny=153; // 3 mm lattice, including the usable border.
            Func<int,int,WirePoint> point=(x,y)=>new WirePoint(-HalfWidth+x*Step,-HalfHeight+y*Step,start.Z);
            int sx=(int)Math.Round((start.X+HalfWidth)/Step),sy=(int)Math.Round((start.Y+HalfHeight)/Step);
            int ex=(int)Math.Round((end.X+HalfWidth)/Step),ey=(int)Math.Round((end.Y+HalfHeight)/Step);
            if(sx<0||sx>=nx||ex<0||ex>=nx||sy<0||sy>=ny||ey<0||ey>=ny)return null;
            if(!Clear(start,point(sx,sy),blocks,wires,inputJoint)||!Clear(point(ex,ey),end,blocks,wires,inputJoint))return null;
            var usable=new sbyte[nx*ny];
            int count=nx*ny*4;var cost=new float[count];var parent=new int[count];var closed=new bool[count];
            for(int i=0;i<count;i++){cost[i]=float.PositiveInfinity;parent[i]=-1;}
            var heap=new Heap();for(int dir=0;dir<4;dir++){int node=(sy*nx+sx)*4+dir;cost[node]=0;heap.Push(node,0);}
            int[] dx={1,0,-1,0},dy={0,1,0,-1};int goal=-1;
            while(heap.Count>0)
            {
                int n=heap.Pop().Node;if(closed[n])continue;closed[n]=true;
                int cell=n/4,x=cell%nx,y=cell/nx,old=n%4;if(x==ex&&y==ey&&(goalDirection<0||old==goalDirection)){goal=n;break;}
                for(int dir=0;dir<4;dir++)
                {
                    if(dir==(old+2)%4)continue;int xx=x+dx[dir],yy=y+dy[dir];if(xx<0||xx>=nx||yy<0||yy>=ny)continue;
                    int nextCell=yy*nx+xx;int next=nextCell*4+dir;if(closed[next])continue;
                    if(usable[nextCell]==0)usable[nextCell]=(sbyte)(Clear(point(xx,yy),point(xx,yy),blocks,wires,inputJoint)?1:-1);
                    if(usable[nextCell]<0)continue;
                    if(!Clear(point(x,y),point(xx,yy),blocks,wires,inputJoint))continue;
                    float laneCost=(dir%2==0)?Math.Max(0,Math.Max(start.Y,end.Y)-point(x,y).Y)*.08f:0;
                    float candidate=cost[n]+Step+laneCost+(dir==old?0:.012f);if(candidate>=cost[next])continue;
                    cost[next]=candidate;parent[next]=n;heap.Push(next,candidate+(Math.Abs(xx-ex)+Math.Abs(yy-ey))*Step);
                }
            }
            if(goal<0)return null;
            var result=new List<WirePoint>{end};for(int n=goal;n>=0;n=parent[n]){int cell=n/4;result.Add(point(cell%nx,cell/nx));}result.Add(start);result.Reverse();
            // Remove only exactly collinear vertices; never shortcut across a corner.
            var simple=new List<WirePoint>();foreach(var p in result){if(simple.Count>0&&(p-simple[simple.Count-1]).Squared<1e-12f)continue;while(simple.Count>=2){var a=simple[simple.Count-1]-simple[simple.Count-2];var b=p-simple[simple.Count-1];float cross=a.X*b.Y-a.Y*b.X;if(Math.Abs(cross)>1e-10f||WirePoint.Dot(a,b)<0)break;simple.RemoveAt(simple.Count-1);}simple.Add(p);}return simple.ToArray();
        }
    }
}
