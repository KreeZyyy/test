using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Serialization;

namespace ModularSwitchboards
{
    public sealed class CabinetWireEnd : IEquatable<CabinetWireEnd>
    {
        [XmlAttribute] public long Owner;
        [XmlAttribute] public int Contact;
        public CabinetWireEnd(){}
        public CabinetWireEnd(long owner,int contact){Owner=owner;Contact=contact;}
        public bool Equals(CabinetWireEnd other)=>other!=null&&Owner==other.Owner&&Contact==other.Contact;
        public override bool Equals(object obj)=>Equals(obj as CabinetWireEnd);
        public override int GetHashCode()=>Owner.GetHashCode()*397^Contact;
        public bool IsSource=>Owner==0?Contact==0:Contact==1;
        public int Capacity=>Owner==0&&Contact==0?16:1;
        public override string ToString()=>Owner==0?new[]{"Input","Output 1","Output 2"}[Contact]:"Breaker "+(Contact==0?"IN (top)":"OUT (bottom)");
    }
    public sealed class CabinetWireSaveData
    {
        [XmlElement] public CabinetWireEnd From,To;
        [XmlAttribute] public int InputSlot;
        [XmlAttribute] public int RouteVersion;
        [XmlAttribute] public int CableUnits=1;
        [XmlArray] public float[] Points;
    }
    internal static class WireCircuit
    {
        internal static bool Reachable(CabinetWireEnd from,CabinetWireEnd to,IEnumerable<CabinetWireSaveData> wires,IEnumerable<long> closedBreakers)
        {
            var edges=new Dictionary<CabinetWireEnd,List<CabinetWireEnd>>();
            Action<CabinetWireEnd,CabinetWireEnd> add=(a,b)=>{if(!edges.TryGetValue(a,out var list))edges[a]=list=new List<CabinetWireEnd>();list.Add(b);};
            foreach(var wire in wires)add(wire.From,wire.To);
            foreach(var breaker in closedBreakers)add(new CabinetWireEnd(breaker,0),new CabinetWireEnd(breaker,1));
            var seen=new HashSet<CabinetWireEnd>();var queue=new Queue<CabinetWireEnd>();queue.Enqueue(from);
            while(queue.Count>0){var n=queue.Dequeue();if(!seen.Add(n))continue;if(n.Equals(to))return true;if(edges.TryGetValue(n,out var list))foreach(var next in list)queue.Enqueue(next);}return false;
        }
        internal static bool CanConnect(CabinetWireEnd a,CabinetWireEnd b,IList<CabinetWireSaveData> wires,IEnumerable<long> breakers,out string reason,bool allowLegacyBypass=false)
        {
            reason=null;
            if(a==null||b==null||a.Equals(b)){reason="Choose two different contacts.";return false;}
            if(a.IsSource==b.IsSource){reason="Connect a supply contact to an input contact.";return false;}
            var from=a.IsSource?a:b;var to=a.IsSource?b:a;
            if(!allowLegacyBypass&&from.Owner==0&&to.Owner==0){reason="Connect Input to a breaker's top contact first.";return false;}
            if(from.Owner!=0&&from.Owner==to.Owner){reason="Cannot wire a breaker back into itself.";return false;}
            foreach(var e in new[]{a,b})if(wires.Count(w=>w.From.Equals(e)||w.To.Equals(e))>=e.Capacity){reason="Contact occupied.";return false;}
            if(Reachable(to,from,wires,breakers)){reason="This connection would create a loop.";return false;}
            return true;
        }
        // Share one native input budget. A second output must not advertise it a second time.
        internal static float[] Allocate(float available,float firstDemand,float secondDemand,bool first,bool second)
        {
            available=Finite(available);firstDemand=Finite(firstDemand);secondDemand=Finite(secondDemand);
            if(!first&&!second)return new float[2];if(!first)return new[]{0f,available};if(!second)return new[]{available,0f};
            float total=firstDemand+secondDemand;if(total<=0)return new[]{available*.5f,available*.5f};
            float one=available*(firstDemand/total);return new[]{one,available-one};
        }
        internal static float Finite(float value)=>float.IsNaN(value)||float.IsInfinity(value)?0:Math.Max(0,value);
    }
}
