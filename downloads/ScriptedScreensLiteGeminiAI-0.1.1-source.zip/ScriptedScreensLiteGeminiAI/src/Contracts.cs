using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using Newtonsoft.Json;

namespace ScriptedScreensLiteGeminiAI;

public sealed class AiException : Exception
{
    public int Status { get; }
    public AiException(int status, string message) : base(message) { Status = status; }
}

public sealed class Settings
{
    public string ApiKey = "";
    public string TextModel = "gemini-3.1-flash-lite";
    public string TtsModel = "gemini-3.8-flash-lite-tts";
    public string TtsApi = "interactions";
    public string Voice = "Kore";
    public string SystemPrompt = "Odpovídej přirozeně česky a stručně. Neopakuj představování. Neuváděj, že vidíš senzory nebo ovládáš zařízení, pokud ti skript tyto informace neposkytl.";
    public string SpeechStyle = "Speak naturally in Czech, calm and friendly.";
    public string BridgeToken = "";
    public int ApiPort = 18766;
    public int MediaPort = 18767;
    public string MediaBindAddress = "127.0.0.1";
    public string PublicMediaBaseUrl = "http://localhost:18767";
    public string WorldId = "default";
    public string DataDirectory = "";
    public int MaxConversations = 25;
    public int HistoryTurns = 20;
    public int ContextUtf8Bytes = 12000;
    public int MaxQuestionChars = 2000;
    public int MaxReplyChars = 4000;
    public int MaxInstructionChars = 2000;
    public int MaxOutputTokens = 800;
    public int MaxSpeechChars = 2000;
    public int MaxConcurrent = 2;
    public int MaxPending = 8;
    public int MaxJobs = 128;
    public int RequestsPerMinute = 12;
    public int CooldownSeconds = 3;
    public int JobTtlSeconds = 600;
    public int AudioTtlSeconds = 1800;
    public int MaxAudioMegabytes = 64;
    public int MaxAudioFileMegabytes = 8;
    public int RequestTimeoutSeconds = 90;
    public bool EnableTts = true;
    public bool AllowLuaModelOverrides = false;
    public HashSet<string> AllowedVoices = new HashSet<string>(StringComparer.Ordinal) {
        "Kore", "Puck", "Charon", "Fenrir", "Aoede", "Zephyr", "Orus", "Leda", "Sulafat" };

    public void Validate()
    {
        if (BridgeToken.Length < 24 || BridgeToken.Length > 256 || BridgeToken.Contains("\r") || BridgeToken.Contains("\n"))
            throw new AiException(500, "Bridge Token must contain 24..256 characters.");
        if (ApiPort < 1024 || ApiPort > 65535 || MediaPort < 1024 || MediaPort > 65535 || ApiPort == MediaPort)
            throw new AiException(500, "Choose two different ports in 1024..65535.");
        if (!System.Net.IPAddress.TryParse(MediaBindAddress, out var bind) || bind.AddressFamily != System.Net.Sockets.AddressFamily.InterNetwork)
            throw new AiException(500, "MediaBindAddress must be an IPv4 address, e.g. 127.0.0.1 or 0.0.0.0.");
        if (!Uri.TryCreate(PublicMediaBaseUrl, UriKind.Absolute, out var uri) ||
            (uri.Scheme != "http" && uri.Scheme != "https") || uri.UserInfo != "" || uri.Query != "" || uri.Fragment != "")
            throw new AiException(500, "PublicMediaBaseUrl must be a plain HTTP(S) base URL.");
        if (WorldId.Length < 1 || WorldId.Length > 100 || DataDirectory.Length == 0)
            throw new AiException(500, "Set WorldId and DataDirectory.");
        if (TtsApi != "interactions" && TtsApi != "generateContent")
            throw new AiException(500, "TtsApi must be interactions or generateContent.");
        if (!Name(TextModel) || !Name(TtsModel) || !AllowedVoices.Contains(Voice))
            throw new AiException(500, "Invalid model or default voice.");
        if (SystemPrompt.Length > 10000 || SpeechStyle.Length > 2000)
            throw new AiException(500, "Default instructions are too long.");
        if (MaxConversations < 1 || MaxConversations > 100 || HistoryTurns < 1 || HistoryTurns > 50 ||
            ContextUtf8Bytes < 1000 || ContextUtf8Bytes > 64000 || MaxQuestionChars < 1 || MaxQuestionChars > 8000 ||
            MaxReplyChars < 1 || MaxReplyChars > 16000 || MaxInstructionChars < 1 || MaxInstructionChars > 4000 ||
            MaxOutputTokens < 32 || MaxOutputTokens > 4096 || MaxSpeechChars < 1 || MaxSpeechChars > 4000 ||
            MaxConcurrent < 1 || MaxConcurrent > 4 || MaxPending < MaxConcurrent || MaxPending > 32 ||
            MaxJobs < MaxPending || MaxJobs > 512 || RequestsPerMinute < 1 || RequestsPerMinute > 120 ||
            CooldownSeconds < 0 || CooldownSeconds > 60 || JobTtlSeconds < 120 || JobTtlSeconds > 3600 ||
            AudioTtlSeconds < 120 || AudioTtlSeconds > 86400 || MaxAudioMegabytes < 8 || MaxAudioMegabytes > 512 ||
            MaxAudioFileMegabytes < 1 || MaxAudioFileMegabytes > 16 || MaxAudioFileMegabytes > MaxAudioMegabytes ||
            RequestTimeoutSeconds < 10 || RequestTimeoutSeconds > 180)
            throw new AiException(500, "One of the Lite limits is outside its supported range.");
    }
    internal static bool Name(string value) => Regex.IsMatch(value, "^[a-zA-Z0-9][a-zA-Z0-9_.-]{0,99}$");
}

public sealed class AskRequest
{
    [JsonProperty("question")] public string Question { get; set; } = "";
    [JsonProperty("source_ref_id")] public string SourceRefId { get; set; } = "";
    [JsonProperty("conversation_id")] public string? ConversationId { get; set; }
    [JsonProperty("remember")] public bool Remember { get; set; } = true;
    [JsonProperty("speak")] public bool Speak { get; set; } = true;
    [JsonProperty("system_prompt")] public string? SystemPrompt { get; set; }
    [JsonProperty("speech_style")] public string? SpeechStyle { get; set; }
    [JsonProperty("voice")] public string? Voice { get; set; }
    [JsonProperty("model")] public string? Model { get; set; }
    [JsonProperty("tts_model")] public string? TtsModel { get; set; }
    [JsonProperty("max_output_tokens")] public int? MaxOutputTokens { get; set; }
    [JsonProperty("temperature")] public double Temperature { get; set; } = 0.7;

    public void Validate(Settings s)
    {
        if (Question == null || string.IsNullOrWhiteSpace(Question) || Question.Length > s.MaxQuestionChars)
            throw new AiException(400, "question is empty or too long.");
        if (SourceRefId == null || !Regex.IsMatch(SourceRefId, "^[0-9]{1,19}$") || !long.TryParse(SourceRefId, out long id) || id <= 0)
            throw new AiException(400, "source_ref_id must be the positive host ReferenceId as a string.");
        if (ConversationId != null && !Regex.IsMatch(ConversationId, "^[a-zA-Z0-9][a-zA-Z0-9_.:-]{0,63}$"))
            throw new AiException(400, "Invalid conversation_id.");
        if ((SystemPrompt?.Length ?? 0) > s.MaxInstructionChars || (SpeechStyle?.Length ?? 0) > 500)
            throw new AiException(400, "Lua instructions are too long.");
        if (Voice != null && !s.AllowedVoices.Contains(Voice)) throw new AiException(400, "Voice is not allowed by the server.");
        if (Model != null || TtsModel != null)
        {
            if (!s.AllowLuaModelOverrides) throw new AiException(400, "Model overrides are disabled by the server.");
            if ((Model != null && !Settings.Name(Model)) || (TtsModel != null && !Settings.Name(TtsModel)))
                throw new AiException(400, "Invalid model name.");
        }
        if (double.IsNaN(Temperature) || double.IsInfinity(Temperature) || Temperature < 0 || Temperature > 2)
            throw new AiException(400, "temperature must be between 0 and 2.");
        if (MaxOutputTokens.HasValue && (MaxOutputTokens < 1 || MaxOutputTokens > s.MaxOutputTokens))
            throw new AiException(400, "max_output_tokens exceeds the server limit.");
    }
    public string ConversationKey => ConversationId ?? "device:" + SourceRefId;
}

public sealed class Turn
{
    [JsonProperty("question")] public string Question { get; set; } = "";
    [JsonProperty("reply")] public string Reply { get; set; } = "";
}
public sealed class Conversation
{
    [JsonProperty("id")] public string Id { get; set; } = "";
    [JsonProperty("turns")] public List<Turn> Turns { get; set; } = new List<Turn>();
}
public sealed class JobResult
{
    [JsonProperty("id")] public string Id { get; set; } = "";
    [JsonProperty("state")] public string State { get; set; } = "queued";
    [JsonProperty("source_ref_id")] public string SourceRefId { get; set; } = "";
    [JsonProperty("conversation_id")] public string ConversationId { get; set; } = "";
    [JsonProperty("text")] public string? Text { get; set; }
    [JsonProperty("audio_url")] public string? AudioUrl { get; set; }
    [JsonProperty("audio_duration_seconds")] public double? AudioDurationSeconds { get; set; }
    [JsonProperty("audio_expires_utc")] public DateTime? AudioExpiresUtc { get; set; }
    [JsonProperty("voice_error")] public string? VoiceError { get; set; }
    [JsonProperty("memory_error")] public string? MemoryError { get; set; }
    [JsonProperty("reply_truncated")] public bool ReplyTruncated { get; set; }
    [JsonProperty("error")] public string? Error { get; set; }
    [JsonIgnore] public DateTime CreatedUtc { get; set; } = DateTime.UtcNow;
    [JsonIgnore] public DateTime? FinishedUtc { get; set; }
}
