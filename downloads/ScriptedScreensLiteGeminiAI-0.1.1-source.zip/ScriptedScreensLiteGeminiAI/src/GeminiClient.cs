using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace ScriptedScreensLiteGeminiAI;

public interface IAiProvider
{
    Task<string> TextAsync(AskRequest request, IReadOnlyList<Turn> context, CancellationToken cancellation);
    Task<byte[]> SpeechAsync(string text, AskRequest request, CancellationToken cancellation);
}

public sealed class GeminiClient : IAiProvider, IDisposable
{
    private readonly Settings settings;
    private readonly HttpClient client;
    private readonly bool ownsClient;
    public GeminiClient(Settings settings, HttpClient? client = null)
    {
        this.settings = settings;
        this.client = client ?? new HttpClient();
        ownsClient = client == null;
        if (ownsClient) this.client.Timeout = TimeSpan.FromSeconds(settings.RequestTimeoutSeconds);
    }
    private async Task<JObject> Send(string path, JObject payload, CancellationToken cancellation)
    {
        using var requestTimeout = CancellationTokenSource.CreateLinkedTokenSource(cancellation);
        requestTimeout.CancelAfter(TimeSpan.FromSeconds(settings.RequestTimeoutSeconds));
        cancellation = requestTimeout.Token;
        if (string.IsNullOrWhiteSpace(settings.ApiKey)) throw new AiException(503, "Set Gemini.ApiKey in the host configuration.");
        using var message = new HttpRequestMessage(HttpMethod.Post, "https://generativelanguage.googleapis.com/v1beta/" + path);
        message.Headers.Add("x-goog-api-key", settings.ApiKey);
        message.Content = new StringContent(payload.ToString(Formatting.None), Encoding.UTF8, "application/json");
        using var response = await client.SendAsync(message, HttpCompletionOption.ResponseHeadersRead, cancellation).ConfigureAwait(false);
        if (!response.IsSuccessStatusCode)
        {
            int code = (int)response.StatusCode;
            string reason = code == 429 ? "Gemini quota exceeded. Wait and retry manually." :
                code == 401 || code == 403 ? "Gemini key or model access was rejected." :
                code == 404 ? "Gemini model is unavailable. Change the configured model." :
                "Gemini rejected the request (HTTP " + code + ").";
            throw new AiException(502, reason); // Never expose Google's raw body or retry billed requests automatically.
        }
        int maximum = settings.MaxAudioFileMegabytes * 1024 * 1024 * 2 + 1024 * 1024;
        if (response.Content.Headers.ContentLength > maximum) throw new AiException(502, "Gemini response is too large.");
        using var stream = await response.Content.ReadAsStreamAsync().ConfigureAwait(false);
        using var buffer = new System.IO.MemoryStream();
        var bytes = new byte[16384];
        int count;
        while ((count = await stream.ReadAsync(bytes, 0, bytes.Length, cancellation).ConfigureAwait(false)) > 0)
        {
            if (buffer.Length + count > maximum) throw new AiException(502, "Gemini response is too large.");
            buffer.Write(bytes, 0, count);
        }
        try { return JObject.Parse(Encoding.UTF8.GetString(buffer.ToArray())); }
        catch (JsonException) { throw new AiException(502, "Gemini returned invalid JSON."); }
    }
    public static JObject TextPayload(Settings settings, AskRequest request, IReadOnlyList<Turn> context)
    {
        var contents = new JArray();
        foreach (var turn in context)
        {
            contents.Add(new JObject { ["role"] = "user", ["parts"] = new JArray(new JObject { ["text"] = turn.Question }) });
            contents.Add(new JObject { ["role"] = "model", ["parts"] = new JArray(new JObject { ["text"] = turn.Reply }) });
        }
        contents.Add(new JObject { ["role"] = "user", ["parts"] = new JArray(new JObject { ["text"] = request.Question }) });
        return new JObject {
            ["systemInstruction"] = new JObject { ["parts"] = new JArray(new JObject { ["text"] = request.SystemPrompt ?? settings.SystemPrompt }) },
            ["contents"] = contents,
            ["generationConfig"] = new JObject { ["maxOutputTokens"] = request.MaxOutputTokens ?? settings.MaxOutputTokens, ["temperature"] = request.Temperature }
        };
    }
    public async Task<string> TextAsync(AskRequest request, IReadOnlyList<Turn> context, CancellationToken cancellation)
    {
        string model = request.Model ?? settings.TextModel;
        var json = await Send("models/" + Uri.EscapeDataString(model) + ":generateContent", TextPayload(settings, request, context), cancellation).ConfigureAwait(false);
        var parts = json["candidates"]?[0]?["content"]?["parts"] as JArray;
        string result = parts == null ? "" : string.Concat(parts.OfType<JObject>().Where(p => p["thought"]?.Value<bool>() != true)
            .Select(p => p["text"]?.Type == JTokenType.String ? p["text"]!.Value<string>() : ""));
        if (string.IsNullOrWhiteSpace(result)) throw new AiException(502, "Gemini returned no text (possibly safety-blocked).");
        return result.Trim();
    }
    public static JObject SpeechPayload(Settings settings, string text, AskRequest request)
    {
        string voice = request.Voice ?? settings.Voice;
        string style = request.SpeechStyle ?? settings.SpeechStyle;
        if (settings.TtsApi == "interactions") return new JObject {
            ["model"] = request.TtsModel ?? settings.TtsModel,
            ["store"] = false,
            ["input"] = new JArray(new JObject {
                ["type"] = "user_input", ["content"] = new JArray(new JObject {
                    ["type"] = "text", ["text"] = text,
                    ["annotations"] = new JArray(new JObject { ["type"] = "speech_metadata", ["style"] = style })
                })
            }),
            ["response_format"] = new JObject { ["type"] = "audio", ["mime_type"] = "audio/wav", ["sample_rate"] = 24000 },
            ["generation_config"] = new JObject { ["speech_config"] = new JArray(new JObject { ["voice"] = voice }) }
        };
        return new JObject {
            ["contents"] = new JArray(new JObject { ["parts"] = new JArray(new JObject { ["text"] = style + "\nRead only the following text verbatim:\n" + text }) }),
            ["generationConfig"] = new JObject {
                ["responseModalities"] = new JArray("AUDIO"),
                ["speechConfig"] = new JObject { ["voiceConfig"] = new JObject { ["prebuiltVoiceConfig"] = new JObject { ["voiceName"] = voice } } }
            }
        };
    }
    public async Task<byte[]> SpeechAsync(string text, AskRequest request, CancellationToken cancellation)
    {
        string model = request.TtsModel ?? settings.TtsModel;
        var json = await Send(settings.TtsApi == "interactions" ? "interactions" : "models/" + Uri.EscapeDataString(model) + ":generateContent",
            SpeechPayload(settings, text, request), cancellation).ConfigureAwait(false);
        string? encoded = null, mime = null;
        if (settings.TtsApi == "interactions")
        {
            foreach (var step in (json["steps"] as JArray ?? new JArray()).OfType<JObject>().Where(s => (string?)s["type"] == "model_output"))
                foreach (var part in (step["content"] as JArray ?? new JArray()).OfType<JObject>().Where(p => (string?)p["type"] == "audio"))
                { encoded = (string?)part["data"]; mime = (string?)part["mime_type"] ?? "audio/wav"; }
        }
        else
        {
            foreach (var part in (json["candidates"]?[0]?["content"]?["parts"] as JArray ?? new JArray()).OfType<JObject>())
                if (part["inlineData"] is JObject data) { encoded = (string?)data["data"]; mime = (string?)data["mimeType"]; }
        }
        if (string.IsNullOrEmpty(encoded)) throw new AiException(502, "Gemini TTS returned no audio.");
        byte[] bytes;
        try { bytes = Convert.FromBase64String(encoded); }
        catch (FormatException) { throw new AiException(502, "Gemini TTS returned invalid audio encoding."); }
        if (bytes.Length > settings.MaxAudioFileMegabytes * 1024 * 1024) throw new AiException(413, "TTS audio exceeds the file limit.");
        if (mime != null && (mime.StartsWith("audio/wav", StringComparison.OrdinalIgnoreCase) || mime.StartsWith("audio/x-wav", StringComparison.OrdinalIgnoreCase)))
            return WaveAudio.ValidateWav(bytes);
        if (mime != null && (mime.StartsWith("audio/L16", StringComparison.OrdinalIgnoreCase) || mime.StartsWith("audio/pcm", StringComparison.OrdinalIgnoreCase)))
        {
            int rate = 24000;
            var match = System.Text.RegularExpressions.Regex.Match(mime, @"rate=(\d+)", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            if (match.Success && !int.TryParse(match.Groups[1].Value, out rate)) throw new AiException(502, "Invalid TTS sample rate.");
            return WaveAudio.FromPcm16(bytes, rate); // Google's generated PCM is signed little-endian.
        }
        throw new AiException(502, "Unsupported TTS audio format.");
    }
    public void Dispose() { if (ownsClient) client.Dispose(); }
}
