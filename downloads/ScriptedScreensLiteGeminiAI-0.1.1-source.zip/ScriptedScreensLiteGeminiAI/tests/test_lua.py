"""Lua 5.2 integration checks with game-API substitutes, no live game/API key."""
from pathlib import Path
import sys
try:
    from lupa.lua52 import LuaRuntime
except ImportError:
    if Path('/workspace/tooling/python').exists():
        sys.path.insert(0, '/workspace/tooling/python')
        from lupa.lua52 import LuaRuntime
    else:
        raise SystemExit('Install test dependency: python -m pip install lupa==2.6')
ROOT = Path(__file__).resolve().parents[1]
HARNESS = r'''
posted, fetched, completions, elements, sounds, stopped, persistence = {}, {}, {}, {}, {}, {}, {}
next_request, next_json = 0, 0
json_objects = {}
util = {json={}}
function util.json.encode(value)
    next_json=next_json+1
    local key='json:'..next_json
    json_objects[key]=value
    return key
end
function util.json.decode(value)
    if not json_objects[value] then error('invalid JSON') end
    return json_objects[value]
end
function push_completion(id, data, status, success)
    completions[#completions+1]={id,success~=false,status or 200,util.json.encode(data),''}
end
function raw_completion(id,body,status,success)
    completions[#completions+1]={id,success~=false,status or 200,body,''}
end
ic = {
    host_info=function() return {ref_id=123,type='motherboard'} end,
    persist={
        get=function(key) return persistence[key] end,
        set=function(key,value) persistence[key]=value end,
        delete=function(key) persistence[key]=nil end,
    },
    http={
        post=function(url,body,kind,headers,timeout)
            next_request=next_request+1
            posted[#posted+1]={url=url,payload=util.json.decode(body),headers=headers,id=next_request}
            return next_request
        end,
        get=function(url,headers,timeout)
            next_request=next_request+1
            fetched[#fetched+1]={url=url,id=next_request}
            return next_request
        end,
        poll=function()
            if #completions==0 then return nil end
            return table.unpack(table.remove(completions,1))
        end,
    },
}
local function elem(def,prefix)
    local id=(prefix or '')..def.id
    local item={props=def.props or {},id=id,on_click=def.on_click,on_change=def.on_change}
    function item:set_props(props) for k,v in pairs(props) do self.props[k]=v end end
    function item:element(child) return elem(child,id..'/') end
    elements[id]=item
    return item
end
surface={}
function surface:set_resolution(w,h) end
function surface:size() return {w=800,h=600} end
function surface:clear() elements={} end
function surface:commit() end
function surface:element(def) return elem(def) end
function surface:remove(id) elements[id]=nil end
function surface:measure_text(text,width,font,wrap) return {h=28} end
ss={
    ui={surface=function() return surface end, activate=function() end},
    play_sound=function(url,opts)
        sounds[#sounds+1]={url=url,id=opts.id,volume=opts.volume,loop=opts.loop}
        return opts.id
    end,
    stop_sound=function(id) stopped[#stopped+1]=id end,
}
'''
count = 0

def check(value, description):
    global count
    assert value, description
    count += 1
    print('PASS', description)

def runtime():
    lua = LuaRuntime(unpack_returned_tuples=True)
    lua.execute(HARNESS)
    return lua

sdk = (ROOT / 'examples/geminiai.lua').read_text('utf-8')
check(sdk.startswith('--@module geminiai'), 'library-chip annotation present')
for file in (ROOT/'examples').glob('*.lua'):
    lua=runtime()
    ok, err=lua.eval('function(s) local f,e=load(s,"test","t"); return f~=nil,e end')(file.read_text('utf-8'))
    check(ok, 'Lua 5.2 compiles '+file.name)
lua=runtime(); lua.globals().GeminiAI=lua.execute(sdk)
lua.execute("ai=GeminiAI.new({}); ok,error=ai:ask('hello',{},function() end)")
check(lua.eval('ok==nil and #posted==0'), 'placeholder token cannot send paid requests')
lua.execute("ai=GeminiAI.new({token=string.rep('t',32)}); result=nil; failure=nil; callback=function(r,e) result=r;failure=e end")
lua.execute("ok,error=ai:ask('hello',{voice='Charon',remember=false,speak=false},callback)")
check(lua.eval("ok==true and posted[1].payload.source_ref_id=='123' and posted[1].payload.speak==false and posted[1].payload.remember==false and posted[1].payload.voice=='Charon'"), 'origin and Lua preferences included')
lua.execute("duplicate,duplicate_error=ai:ask('again',{},callback)")
check(lua.eval('duplicate==nil and #posted==1'), 'duplicate send blocked')
lua.execute("push_completion(posted[1].id,{id=string.rep('a',32)}); ai:tick(1)")
check(lua.eval('#fetched==1 and ai:busy()'), 'ack starts job polling')
lua.execute("push_completion(fetched[1].id,{state='running'}); ai:tick(0.1)")
check(lua.eval('#fetched==1'), 'polling is throttled')
lua.execute("ai:tick(1);push_completion(fetched[2].id,{state='done',source_ref_id='123',text='Ahoj',audio_url='http://server/audio/test.wav',audio_duration_seconds=2,id=string.rep('a',32)});ai:tick(0.1)")
check(lua.eval("result.text=='Ahoj' and failure==nil and not ai:busy()"), 'text and audio delivered through callback')
lua.execute('sound,play_error=ai:play_audio(result)')
check(lua.eval("#sounds==1 and sounds[1].id=='geminiai_'..string.rep('a',32) and sounds[1].loop==nil"), 'playback delegated to ScriptedScreens')
lua.execute('ai:play_audio(result)')
check(lua.eval('#sounds==1'), 'same job audio cannot be started twice')
lua.execute('before_auto_stop=#stopped;ai:tick(0.25)')
check(lua.eval('#stopped==before_auto_stop'), 'valid-duration playback is not immediately stopped')
lua.execute('ai:tick(2.1)')
check(lua.eval('#stopped==before_auto_stop+1 and ai.audio_elapsed==nil'), 'playback automatically stops after WAV duration plus grace')
lua.execute('ai:tick(2)')
check(lua.eval('#stopped==before_auto_stop+1'), 'automatic stop is sent once, not every tick')
lua.execute("missing_duration={source_ref_id='123',audio_url='http://server/no-duration.wav'};sound,play_error=ai:play_audio(missing_duration)")
check(lua.eval('sound==nil and #sounds==1'), 'missing-duration audio cannot loop without a deadline')
lua.execute("wrong={source_ref_id='456',audio_url='http://server/audio/other.wav'};sound,play_error=ai:play_audio(wrong)")
check(lua.eval('sound==nil and #sounds==1'), 'other-origin audio never played by helper')
lua.execute('ai:stop_audio()')
check(lua.eval("stopped[#stopped]=='geminiai_'..string.rep('a',32)"), 'voice can be stopped')
lua.execute("ai:ask('hello',{},callback);push_completion(posted[#posted].id,{error='Memory full'},409,false);ai:tick(0.1)")
check(lua.eval("failure=='Memory full' and not ai:busy()"), 'memory/full HTTP failure reported')
lua.execute("ai:ask('hello',{},callback);raw_completion(posted[#posted].id,'bad-json');ai:tick(0.1)")
check(lua.eval('failure~=nil and not ai:busy()'), 'invalid JSON releases busy state')
lua.execute("ai:ask('hello',{},callback);push_completion(posted[#posted].id,{id=string.rep('b',32)});ai:tick(1);push_completion(fetched[#fetched].id,{state='done',source_ref_id='456',text='wrong'});ai:tick(0.1)")
check(lua.eval('result==nil and failure~=nil'), 'wrong-origin result rejected')
lua.execute("timeout_ai=GeminiAI.new({token=string.rep('t',32),timeout=2});timeout_ai:ask('old',{},callback);old_id=posted[#posted].id;timeout_ai:tick(3)")
check(lua.eval('not timeout_ai:busy() and failure~=nil'), 'UI timeout clears pending state')
lua.execute("timeout_ai:ask('new',{},callback);new_id=posted[#posted].id;push_completion(old_id,{id=string.rep('c',32)});push_completion(new_id,{id=string.rep('d',32)});timeout_ai:tick(1)")
check(lua.eval("timeout_ai.job==string.rep('d',32)"), 'late completion cannot poison next request')
lua=runtime()
oasis=(ROOT/'examples/OASIS.lua').read_text('utf-8')
check('--@module' not in oasis, 'standalone OASIS cannot be mistaken for a library chip')
oasis=oasis.replace('local TOKEN = "PASTE_LOCAL_BRIDGE_TOKEN_HERE"', 'local TOKEN = "'+'t'*32+'"')
lua.execute(oasis)
check(lua.eval('elements.question~=nil and elements.send~=nil'), 'OASIS controls constructed')
lua.execute('elements.send.on_click()')
check(lua.eval('#posted==0'), 'blank OASIS input makes no HTTP request')
lua.execute("elements.question.on_change('Ahoj');elements.send.on_click();elements.send.on_click()")
check(lua.eval("#posted==1 and posted[1].payload.question=='Ahoj' and posted[1].payload.system_prompt~=nil"), 'OASIS uses one raw question, personality and server context')
lua.execute("push_completion(posted[1].id,{id=string.rep('a',32)});tick(1);push_completion(fetched[1].id,{state='done',source_ref_id='123',text='Česká odpověď',audio_url='http://server/audio/hello.wav',audio_duration_seconds=2,id=string.rep('a',32)});tick(0.1)")
check(lua.eval("#sounds==1 and elements['chat/turn_1_oasis_text'].props.text=='Česká odpověď'"), 'OASIS displays reply and delegates spatial speech')
lua.execute('elements.voice.on_click()')
check(lua.eval("stopped[#stopped]=='geminiai_'..string.rep('a',32)"), 'voice toggle stops playing audio')
lua.execute("elements.question.on_change('Druhý dotaz');elements.send.on_click();push_completion(posted[#posted].id,{id=string.rep('b',32)});tick(1);push_completion(fetched[#fetched].id,{state='done',source_ref_id='123',text='Bez hlasu'});tick(0.1)")
check(lua.eval('#sounds==1 and posted[#posted].payload.speak==false'), 'disabled voice sends speak=false and never plays')
lua.execute('before_reset=#posted;elements.clear_history.on_click()')
check(lua.eval('#posted==before_reset'), 'history reset requires confirmation')
lua.execute('elements.clear_history.on_click()')
check(lua.eval("posted[#posted].url:match('/memory/reset$')~=nil and posted[#posted].payload.source_ref_id=='123'"), 'confirmed reset addresses server memory')
lua.execute("push_completion(posted[#posted].id,{status='ok'});tick(0.1)")
check(lua.eval("elements['chat/turn_1_you_text']==nil and elements['chat/welcome_text']~=nil"), 'successful reset clears displayed history')
print(f'\n{count} Lua checks passed; no live game or Google requests.')
