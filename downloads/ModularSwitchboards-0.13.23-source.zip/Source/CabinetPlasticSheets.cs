using System;
using System.Collections.Generic;
using System.Linq;
using Assets.Scripts.Objects;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class CabinetPlasticSheets
    {
        internal static void Append(ref Mesh package,ref Material[] surfaces,Thing plastic)
        {
            // Copy the actual vanilla Plastic Sheet render geometry into our own
            // readable mesh. No source prefab, material or mesh is modified.
            var candidates=plastic.GetComponentsInChildren<MeshFilter>(true)
                .Where(f=>f.sharedMesh!=null&&f.GetComponent<MeshRenderer>()!=null&&f.GetComponent<MeshRenderer>().enabled).ToArray();
            if(candidates.Length==0)throw new InvalidOperationException("Plastic Sheet has no render geometry");
            var source=candidates.OrderByDescending(f=>f.sharedMesh.vertexCount).First();
            CabinetGeometry.ReadNativeMesh(source.sharedMesh,out var vertices,out var uv,out var triangles);
            var local=plastic.transform.worldToLocalMatrix*source.transform.localToWorldMatrix;
            for(int i=0;i<vertices.Length;i++)vertices[i]=local.MultiplyPoint3x4(vertices[i]);
            var bounds=new Bounds(vertices[0],Vector3.zero);
            foreach(var p in vertices)bounds.Encapsulate(p);
            // Put the thinnest axis vertically while preserving native proportions.
            var size=bounds.size;
            var rotation=size.x<size.y&&size.x<size.z?Quaternion.Euler(0,0,90):
                size.z<size.y?Quaternion.Euler(90,0,0):Quaternion.identity;
            for(int i=0;i<vertices.Length;i++)vertices[i]=rotation*(vertices[i]-bounds.center);
            bounds=new Bounds(vertices[0],Vector3.zero);foreach(var p in vertices)bounds.Encapsulate(p);
            float scale=.62f/Mathf.Max(bounds.size.x,bounds.size.z);
            var sheet=new Mesh{name="Switchboards.CopiedPlasticSheet",indexFormat=vertices.Length>65535?UnityEngine.Rendering.IndexFormat.UInt32:UnityEngine.Rendering.IndexFormat.UInt16};
            sheet.vertices=vertices;sheet.uv=uv;sheet.subMeshCount=triangles.Length;
            for(int i=0;i<triangles.Length;i++)sheet.SetTriangles(triangles[i],i);
            sheet.RecalculateNormals();sheet.RecalculateBounds();
            var parts=new List<CombineInstance>();var materials=new List<Material>();
            for(int i=0;i<package.subMeshCount;i++)
            {
                parts.Add(new CombineInstance{mesh=package,subMeshIndex=i,transform=Matrix4x4.identity});
                materials.Add(surfaces[i]);
            }
            var copied=source.GetComponent<MeshRenderer>().sharedMaterials.Select(m=>new Material(m){name="Switchboards.CopiedPlasticSheet.Material"}).ToArray();
            float verticalScale=Mathf.Min(scale,.006f/Mathf.Max(bounds.size.y,.00001f));
            float thickness=bounds.size.y*verticalScale;
            for(int layer=0;layer<3;layer++)for(int sub=0;sub<sheet.subMeshCount;sub++)
            {
                float y=-.105f-thickness*.5f-(2-layer)*(thickness+.001f);
                var transform=Matrix4x4.TRS(new Vector3((layer-1)*.002f,y,-.107f),Quaternion.identity,new Vector3(scale,verticalScale,scale));
                parts.Add(new CombineInstance{mesh=sheet,subMeshIndex=sub,transform=transform});
                materials.Add(copied[Math.Min(sub,copied.Length-1)]);
            }
            var combined=new Mesh{name=package.name,indexFormat=UnityEngine.Rendering.IndexFormat.UInt32};
            combined.CombineMeshes(parts.ToArray(),false,true);combined.RecalculateBounds();
            package=combined;surfaces=materials.ToArray();
        }
    }
}
