using UnityEngine;
namespace ModularSwitchboards
{
    // Actual casing materials/textures, with native palette blocks applied by
    // the same ThingRenderer/Refresh path used for the module and fuse clamps.
    internal static class BatterySocketSurfaces
    {
        private static Material[] materials;
        internal static Material[] Materials=>materials??(materials=new[]{CabinetGeometry.Materials[3],CabinetGeometry.Materials[4]});
    }
}
