using System.Collections.Generic;
using UnityEngine;
namespace ModularSwitchboards
{
    // Six original APC pad envelopes, measured from the supplied reference.
    // Front depth and native slot relationship are preserved; wedge faces are
    // replaced by complete, forward-facing pads within those same envelopes.
    internal static class BatteryContactGeometry
    {
        internal static readonly Vector3[] SourceCenters={
            new Vector3(-.11193050f,-.14000170f,.13621495f),new Vector3(-.09683585f,-.14000170f,.13621495f),new Vector3(-.08174030f,-.14000170f,.13621495f),
            new Vector3(-.11193145f,-.09004370f,.13621495f),new Vector3(-.09683585f,-.09004370f,.13621495f),new Vector3(-.08174030f,-.09004370f,.13621495f)};
        private static readonly float[] Widths={.0086382f,.0114703f,.0086364f,.0086365f,.0114703f,.0086364f};
        internal static void Add(List<Vector3> vertices,List<Vector3> normals,List<int> triangles,Vector3 sourceCenter,float scale)
        {
            for(int i=0;i<SourceCenters.Length;i++)
            {
                var center=ApcBatteryRegion.Map(SourceCenters[i],sourceCenter,0,scale);
                var size=new Vector3(Widths[i]*scale/DinBreakerModel.VisualScale.x,
                    (i<3?.0122554f:.0122516f)*scale/DinBreakerModel.VisualScale.y,
                    .0050003f*scale/DinBreakerModel.VisualScale.z);
                RoundedGeometry.Box(vertices,normals,triangles,center,size,.0001f);
            }
        }
    }
}
