# Battery socket contacts in 0.12.80

Measured against the user-supplied ModularSwitchboards-APC-reference.json, version0.12.2, prefab StructureAreaPowerControl. Coordinates are APC local with positiveZ facing outward. Reference SHA256:9fbc7208f82984751f879ee86ab237a6480d1734bf2b125c7cda74a1634288ac.

All original pad vertices in BatterySocket.meshbin match reference root mesh vertices rounded to7decimal places. Six connected pad components supply SourceCenters and widths in BatteryContactGeometry.cs. New pads fill those same rectangular envelopes with shallow rounded edges and a complete +Z front face. Original pad frontZ=.1387151 and slot-relative placement are retained. The original86triangles of the socket casing are unchanged. The old48pad wedge triangles remain in the provenance resource but are skipped when constructing visible meshes.

Materials now come from CabinetGeometry.Materials[3]/[4], with native UV mapping and the regular renderer registration/Refresh lifecycle. Socket uses native Black palette; contacts native Gray, as on the fuse clamps. No new plain white/gold shader or copied Unity asset is distributed. The supplied full JSON is not included in this release.
