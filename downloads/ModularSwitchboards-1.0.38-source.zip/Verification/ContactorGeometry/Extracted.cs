using System;using System.Linq;using System.Collections.Generic;using UnityEngine;namespace ModularSwitchboards{static class DinBreakerModel{internal static Vector3 VisualScale=new(2.25f,1.35f,1.15f);internal static Mesh Build(float width=.0176f,float centerX=0f,bool battery=false,float openingX=0f,float openingY=0f,bool plain=false,bool inputOnly=false,bool bottomOnly=false,bool contactor=false,bool wideFace=false)
        {
            var vertices=new List<Vector3>();var normals=new List<Vector3>();var triangles=new List<int>[5];
            for(int i=0;i<5;i++)triangles[i]=new List<int>();
            System.Action<Vector3,Vector3,int,float> shape=(center,size,role,radius)=>
            {
                center.x+=centerX;
                if(contactor&&center.z>.058f)
                {
                    BatteryAperture.Box(vertices,normals,triangles[role],center,size,radius,ContactorWindowLayout.OpeningWidth,ContactorWindowLayout.OpeningHeight);return;
                }
                if(!battery){RoundedGeometry.Box(vertices,normals,triangles[role],center,size,radius);return;}
                // Same breaker surfaces, with only the seated battery aperture cut out.
                float holeX=openingX>0?openingX:ApcBatteryRegion.SocketHeight/VisualScale.x;
                float holeY=openingY>0?openingY:ApcBatteryRegion.SocketHeight/VisualScale.y;
                BatteryAperture.Box(vertices,normals,triangles[role],center,size,radius,holeX,holeY,openingX>0?0:holeX*.1f,openingX>0?0:holeY*.1f);

            };
            shape(new Vector3(0,0,.029f),new Vector3(width,.075f,.056f),1,.0018f);
            shape(new Vector3(0,0,.059f),new Vector3(width,.052f,.008f),1,.0015f);
            shape(new Vector3(0,0,.0635f),new Vector3(width-(wideFace?.002f:.0046f),.045f,.001f),3,.0004f);
            if(battery)
            {
                // The slightly larger native cell extends just behind the former
                // rear plane. Recess only its rear cover; fuse rear walls stay put.
                float rear=openingX>0?.003f:-.0018f,depth=openingX>0?.002f:.0016f;
                // One continuous liner from the closed rear to the actual front.
                // The former three overlapping wall sets are deliberately absent.
                float holeX=openingX>0?openingX:ApcBatteryRegion.SocketHeight/VisualScale.x;
                float holeY=openingY>0?openingY:ApcBatteryRegion.SocketHeight/VisualScale.y;
                float rearFace=rear+depth*.5f;
                BatteryAperture.Walls(vertices,normals,triangles[3],new Vector3(centerX,0,(rearFace+.064f)*.5f),
                    new Vector3(width,.075f,.064f-rearFace),holeX,holeY,openingX>0?0:holeX*.1f,openingX>0?0:holeY*.1f);
                RoundedGeometry.Box(vertices,normals,triangles[3],new Vector3(centerX,0,rear),new Vector3(width,.075f,depth),.0007f);
            }
            foreach(float side in bottomOnly?new[]{-1f}:inputOnly?new[]{1f}:new[]{-1f,1f})
            {
                foreach(float terminalX in contactor&&side>0?new[]{-.004f,.004f}:new[]{0f})
                {
                    float tw=contactor&&side>0?.0057f:.009f,sw=contactor&&side>0?.0035f:.006f;
                    RoundedGeometry.Box(vertices,normals,triangles[4],new Vector3(centerX+terminalX,side*.03f,.0577f),new Vector3(tw,.009f,.0015f),.0005f);
                    RoundedGeometry.Box(vertices,normals,triangles[3],new Vector3(centerX+terminalX,side*.03f,.0586f),new Vector3(sw,.001f,.0005f),.00015f);
                }
            }
            foreach(float side in bottomOnly?new[]{-1f}:inputOnly?new[]{1f}:new[]{-1f,1f})
            {
                foreach(float terminalX in contactor&&side>0?new[]{-.004f,.004f}:new[]{0f})
                {
                    EndDisk(vertices,normals,triangles[4],new Vector3(centerX+terminalX,side*(WireContactLayout.BreakerEntryY+.0001f),WireContactLayout.BreakerEntryZ),.0042f,side);
                    EndDisk(vertices,normals,triangles[3],new Vector3(centerX+terminalX,side*(WireContactLayout.BreakerEntryY+.0002f),WireContactLayout.BreakerEntryZ),.0032f,side);
                }
            }
            // Two fixed spindle bearings straddle the flap, matching the APC's mounting.
            // Their inner edges clear the 12 mm plate while enclosing its axle ends.
            if(!battery&&!plain)foreach(float side in bottomOnly?new[]{-1f}:inputOnly?new[]{1f}:new[]{-1f,1f})
                RoundedGeometry.Box(vertices,normals,triangles[4],new Vector3(centerX+side*.0073f,0,.0667f),
                    new Vector3(.0022f,.0042f,.0048f),.0007f);
            var mesh=new Mesh{name="Switchboards.RoundedBreaker"};mesh.SetVertices(vertices);mesh.SetNormals(normals);mesh.subMeshCount=5;
            for(int i=0;i<5;i++)mesh.SetTriangles(triangles[i],i);
            CabinetGeometry.ApplyNativeUv(mesh);mesh.RecalculateBounds();return mesh;
        }private static void EndDisk(List<Vector3> vertices,List<Vector3> normals,List<int> triangles,Vector3 center,float worldRadius,float side)
        {
            for(int i=0;i<16;i++)
            {
                float a=i*Mathf.PI/8,b=(i+1)*Mathf.PI/8;
                var p=center+new Vector3(Mathf.Cos(a)*worldRadius/VisualScale.x,0,Mathf.Sin(a)*worldRadius/VisualScale.z);
                var q=center+new Vector3(Mathf.Cos(b)*worldRadius/VisualScale.x,0,Mathf.Sin(b)*worldRadius/VisualScale.z);
                int start=vertices.Count;vertices.AddRange(side>0?new[]{center,q,p}:new[]{center,p,q});normals.AddRange(new[]{Vector3.up*side,Vector3.up*side,Vector3.up*side});triangles.AddRange(new[]{start,start+1,start+2});
            }
        }}static class DinContactorModel{internal static Mesh Build(){return DinBreakerModel.Build(plain:true,contactor:true,wideFace:true);}internal static Mesh BuildSlider()
        {
            var vertices=new List<Vector3>();var normals=new List<Vector3>();var groups=new List<int>[5];for(int i=0;i<5;i++)groups[i]=new List<int>();
            RoundedGeometry.Box(vertices,normals,groups[4],new Vector3(0,0,.0609f),new Vector3(.0114f,.011f,.0012f),.0005f);
            RoundedGeometry.Box(vertices,normals,groups[4],new Vector3(0,0,.0621f),new Vector3(.0068f,.002f,.0015f),.0004f);
            var moving=new Mesh{name="Contactor.CompactSlider"};moving.SetVertices(vertices);moving.SetNormals(normals);moving.subMeshCount=5;for(int i=0;i<5;i++)moving.SetTriangles(groups[i],i);CabinetGeometry.ApplyNativeUv(moving);moving.RecalculateBounds();return ScaleSurface(moving);
        }internal static Mesh BuildPanel(bool on)
        {
            var v=new List<Vector3>();var n=new List<Vector3>();var g=new List<int>[5];for(int i=0;i<5;i++)g[i]=new List<int>();
            RoundedGeometry.Box(v,n,g[0],new Vector3(0,on?.0063f:-.0063f,.05945f),new Vector3(.0088f,.0078f,.0003f),.0001f);
            var mesh=new Mesh{name="Contactor.FlatStatePanel"};mesh.SetVertices(v);mesh.SetNormals(n);mesh.subMeshCount=5;for(int i=0;i<5;i++)mesh.SetTriangles(g[i],i);CabinetGeometry.ApplyNativeUv(mesh);mesh.RecalculateBounds();return ScaleSurface(mesh);
        }internal static Mesh BuildGuide()
        {
            var v=new List<Vector3>();var n=new List<Vector3>();var g=new List<int>[5];for(int i=0;i<5;i++)g[i]=new List<int>();
            // One dark floor, four matching dark walls. No borrowed hinge/axle shapes.
            RoundedGeometry.Box(v,n,g[4],new Vector3(0,0,.0585f),new Vector3(.0122f,.0252f,.001f),.00015f);
            BatteryAperture.Walls(v,n,g[4],new Vector3(0,0,.0616f),new Vector3(.0122f,.0252f,.0062f),.0118f,.0246f);
            // The rim uses exactly the same dark finish as the well and guides.
            BatteryAperture.Box(v,n,g[4],new Vector3(0,0,.0642f),new Vector3(.0132f,.026f,.0005f),.00015f,.0118f,.0246f);
            // A real C-shaped guide each side: back wall, rear rail and front lip.
            // Slider edges lie between z .0603 and .0615; clearances are positive.
            foreach(float side in new[]{-1f,1f})
            {
                RoundedGeometry.Box(v,n,g[4],new Vector3(side*.00595f,0,.0609f),new Vector3(.0003f,.024f,.0022f),.00004f);
                RoundedGeometry.Box(v,n,g[4],new Vector3(side*.00555f,0,.0600f),new Vector3(.0011f,.024f,.0003f),.00004f);
                RoundedGeometry.Box(v,n,g[4],new Vector3(side*.00555f,0,.0618f),new Vector3(.0011f,.024f,.0003f),.00004f);
            }
            var mesh=new Mesh{name="Contactor.RecessedDarkGuide"};mesh.SetVertices(v);mesh.SetNormals(n);mesh.subMeshCount=5;for(int i=0;i<5;i++)mesh.SetTriangles(g[i],i);CabinetGeometry.ApplyNativeUv(mesh);mesh.RecalculateBounds();return ScaleSurface(mesh);
        }internal static Mesh ScaleSurface(Mesh mesh)
        {
            var points=mesh.vertices;var normals=mesh.normals;
            for(int i=0;i<points.Length;i++)
            {
                points[i].x*=ContactorWindowLayout.ScaleX;points[i].y*=ContactorWindowLayout.ScaleY;
                normals[i]=new Vector3(normals[i].x/ContactorWindowLayout.ScaleX,normals[i].y/ContactorWindowLayout.ScaleY,normals[i].z).normalized;
            }
            mesh.vertices=points;mesh.SetNormals(new List<Vector3>(normals));mesh.RecalculateBounds();return mesh;
        }}static class WireContactLayout{internal const float BreakerEntryY=.0375f,BreakerEntryZ=.029f;}}namespace ModularSwitchboards{static class ApcContactorWindow{internal const float Scale=.17f;internal static readonly Bounds Region=new(new Vector3(.069f,0,.184f),new Vector3(.154f,.30f,.032f));internal static Vector3 Map(Vector3 p)=>new Vector3((p.x-.069f)*Scale/DinBreakerModel.VisualScale.x,p.y*Scale/DinBreakerModel.VisualScale.y,.064f+(p.z-.198f)*Scale/DinBreakerModel.VisualScale.z);internal static Vector3 MapLegend(Vector3 p)
        {
            bool on=p.y>0;float nativeCenter=on?.111295f:-.113985f;
            return new Vector3((p.x-.069f)*Scale*ContactorWindowLayout.ScaleX/DinBreakerModel.VisualScale.x,(on?.0063f:-.0063f)*ContactorWindowLayout.ScaleY+(p.y-nativeCenter)*Scale*ContactorWindowLayout.ScaleX/DinBreakerModel.VisualScale.y,.0598f);
        }internal static bool IsLegend(Vector3 a,Vector3 b,Vector3 c)=>Mathf.Abs(a.z-.17091f)<.00002f&&Mathf.Abs(b.z-.17091f)<.00002f&&Mathf.Abs(c.z-.17091f)<.00002f;internal static bool IsFlatRim(Vector3 a,Vector3 b,Vector3 c)=>Mathf.Abs(a.z-.198f)<.00002f&&Mathf.Abs(b.z-.198f)<.00002f&&Mathf.Abs(c.z-.198f)<.00002f;internal static Mesh Build(Mesh original,Matrix4x4 frame)
        {
            // Only the flat front rim and original letter faces survive. Axles,
            // hinge blocks, sloped walls and the stepped APC backing are excluded.
            var result=NativeMeshCrop.Read(original,frame,Region,"Contactor.FlatAPCFrameAndLegends",(a,b,c)=>IsLegend(a,b,c));
            if(result==null)throw new InvalidOperationException("Original APC flat frame/legends not found.");
            var sourcePoints=result.vertices;var points=new Vector3[sourcePoints.Length];
            for(int i=0;i<points.Length;i++)
            {
                if(Mathf.Abs(sourcePoints[i].z-.17091f)<.00002f)points[i]=MapLegend(sourcePoints[i]);
                else{points[i]=Map(sourcePoints[i]);points[i].x*=ContactorWindowLayout.ScaleX;points[i].y*=ContactorWindowLayout.ScaleY*ContactorWindowLayout.FrameHeightRatio;points[i].z=.0644f;}
            }
            result.vertices=points;
            result.RecalculateNormals();result.RecalculateTangents();result.RecalculateBounds();return result;
        }}}namespace ModularSwitchboards{static class ApcBreakerBearings{internal static Bounds Region(bool left)=>new Bounds(new Vector3(left?.004657f:.132583f,0,.182116f),new Vector3(.0099f,.0224f,.0261f));internal static Vector3 Map(Vector3 p,float leverWidth)
        {
            float fit=.012f*DinBreakerModel.VisualScale.x/leverWidth;
            return new Vector3((p.x-.069f)*fit/DinBreakerModel.VisualScale.x,p.y*fit/DinBreakerModel.VisualScale.y,.0675f+(p.z-.18f)*fit/DinBreakerModel.VisualScale.z);
        }internal static Mesh Build(Mesh original,Matrix4x4 frame,bool left,float leverWidth)
        {
            var region=Region(left);
            var result=NativeMeshCrop.Read(original,frame,region,"Breaker.OriginalAPCBearing",(a,b,c)=>region.Contains(a)&&region.Contains(b)&&region.Contains(c));
            if(result==null)throw new InvalidOperationException("Original APC spindle bearing missing.");
            var v=result.vertices;for(int i=0;i<v.Length;i++)v[i]=Map(v[i],leverWidth);result.vertices=v;result.RecalculateNormals();result.RecalculateBounds();return Close(result,left);
        }internal static Mesh Close(Mesh mesh,bool left)
        {
            var v=mesh.vertices.ToList();var n=mesh.normals.ToList();var triangles=new System.Collections.Generic.List<int>();
            for(int sub=0;sub<mesh.subMeshCount;sub++)triangles.AddRange(mesh.GetTriangles(sub));
            var bounds=mesh.bounds;float outer=left?bounds.min.x:bounds.max.x;var rim=new System.Collections.Generic.List<Vector3>();
            foreach(var p in mesh.vertices)
                if(Mathf.Abs(p.x-outer)<.000001f&&!rim.Any(q=>(p-q).sqrMagnitude<1e-14f))rim.Add(p);
            if(rim.Count<3)throw new InvalidOperationException("Native bearing side boundary missing.");
            var center=Vector3.zero;foreach(var p in rim)center+=p;center*=1f/rim.Count;
            rim=rim.OrderBy(p=>Math.Atan2(p.z-center.z,p.y-center.y)).ToList();var normal=left?Vector3.left:Vector3.right;
            Action<Vector3,Vector3,Vector3,Vector3> face=(a,b,c,outward)=>
            {
                int start=v.Count;v.AddRange(new[]{a,b,c});n.AddRange(new[]{outward,outward,outward});var cross=Vector3.Cross(b-a,c-a);
                bool reverse=cross.x*outward.x+cross.y*outward.y+cross.z*outward.z<0;
                triangles.AddRange(reverse?new[]{start,start+2,start+1}:new[]{start,start+1,start+2});
            };
            for(int i=0;i<rim.Count;i++)face(center,rim[i],rim[(i+1)%rim.Count],normal);
            // Close the native underside as well, joining the side cap to the shell.
            var a0=new Vector3(bounds.min.x,bounds.min.y,bounds.min.z);var b0=new Vector3(bounds.max.x,bounds.min.y,bounds.min.z);
            var c0=new Vector3(bounds.max.x,bounds.max.y,bounds.min.z);var d0=new Vector3(bounds.min.x,bounds.max.y,bounds.min.z);
            face(a0,b0,c0,Vector3.back);face(a0,c0,d0,Vector3.back);
            mesh.SetVertices(v);mesh.SetNormals(n);mesh.subMeshCount=5;
            for(int sub=0;sub<5;sub++)mesh.SetTriangles(sub==4?triangles:new System.Collections.Generic.List<int>(),sub);
            CabinetGeometry.ApplyNativeUv(mesh);mesh.RecalculateBounds();return mesh;
        }}}namespace ModularSwitchboards{static class PreviousBody{internal static Vector3 VisualScale=new(2.25f,1.35f,1.15f);internal static Mesh Build(float width=.0176f,float centerX=0f,bool battery=false,float openingX=0f,float openingY=0f,bool plain=false,bool inputOnly=false,bool bottomOnly=false)
        {
            var vertices=new List<Vector3>();var normals=new List<Vector3>();var triangles=new List<int>[5];
            for(int i=0;i<5;i++)triangles[i]=new List<int>();
            System.Action<Vector3,Vector3,int,float> shape=(center,size,role,radius)=>
            {
                center.x+=centerX;
                if(!battery){RoundedGeometry.Box(vertices,normals,triangles[role],center,size,radius);return;}
                // Same breaker surfaces, with only the seated battery aperture cut out.
                float holeX=openingX>0?openingX:ApcBatteryRegion.SocketHeight/VisualScale.x;
                float holeY=openingY>0?openingY:ApcBatteryRegion.SocketHeight/VisualScale.y;
                BatteryAperture.Box(vertices,normals,triangles[role],center,size,radius,holeX,holeY,openingX>0?0:holeX*.1f,openingX>0?0:holeY*.1f);

            };
            shape(new Vector3(0,0,.029f),new Vector3(width,.075f,.056f),1,.0018f);
            shape(new Vector3(0,0,.059f),new Vector3(width,.052f,.008f),1,.0015f);
            shape(new Vector3(0,0,.0635f),new Vector3(width-.0046f,.045f,.001f),3,.0004f);
            if(battery)
            {
                // The slightly larger native cell extends just behind the former
                // rear plane. Recess only its rear cover; fuse rear walls stay put.
                float rear=openingX>0?.003f:-.0018f,depth=openingX>0?.002f:.0016f;
                // One continuous liner from the closed rear to the actual front.
                // The former three overlapping wall sets are deliberately absent.
                float holeX=openingX>0?openingX:ApcBatteryRegion.SocketHeight/VisualScale.x;
                float holeY=openingY>0?openingY:ApcBatteryRegion.SocketHeight/VisualScale.y;
                float rearFace=rear+depth*.5f;
                BatteryAperture.Walls(vertices,normals,triangles[3],new Vector3(centerX,0,(rearFace+.064f)*.5f),
                    new Vector3(width,.075f,.064f-rearFace),holeX,holeY,openingX>0?0:holeX*.1f,openingX>0?0:holeY*.1f);
                RoundedGeometry.Box(vertices,normals,triangles[3],new Vector3(centerX,0,rear),new Vector3(width,.075f,depth),.0007f);
            }
            foreach(float side in bottomOnly?new[]{-1f}:inputOnly?new[]{1f}:new[]{-1f,1f})
            {
                RoundedGeometry.Box(vertices,normals,triangles[4],new Vector3(centerX,side*.03f,.0577f),new Vector3(.009f,.009f,.0015f),.0005f);
                RoundedGeometry.Box(vertices,normals,triangles[3],new Vector3(centerX,side*.03f,.0586f),new Vector3(.006f,.001f,.0005f),.00015f);
            }
            foreach(float side in bottomOnly?new[]{-1f}:inputOnly?new[]{1f}:new[]{-1f,1f})
            {
                EndDisk(vertices,normals,triangles[4],new Vector3(centerX,side*(WireContactLayout.BreakerEntryY+.0001f),WireContactLayout.BreakerEntryZ),.0042f,side);
                EndDisk(vertices,normals,triangles[3],new Vector3(centerX,side*(WireContactLayout.BreakerEntryY+.0002f),WireContactLayout.BreakerEntryZ),.0032f,side);
            }
            // Two fixed spindle bearings straddle the flap, matching the APC's mounting.
            // Their inner edges clear the 12 mm plate while enclosing its axle ends.
            if(!battery&&!plain)foreach(float side in bottomOnly?new[]{-1f}:inputOnly?new[]{1f}:new[]{-1f,1f})
                RoundedGeometry.Box(vertices,normals,triangles[4],new Vector3(centerX+side*.0073f,0,.0667f),
                    new Vector3(.0022f,.0042f,.0048f),.0007f);
            var mesh=new Mesh{name="Switchboards.RoundedBreaker"};mesh.SetVertices(vertices);mesh.SetNormals(normals);mesh.subMeshCount=5;
            for(int i=0;i<5;i++)mesh.SetTriangles(triangles[i],i);
            CabinetGeometry.ApplyNativeUv(mesh);mesh.RecalculateBounds();return mesh;
        }private static void EndDisk(List<Vector3> vertices,List<Vector3> normals,List<int> triangles,Vector3 center,float worldRadius,float side)
        {
            for(int i=0;i<16;i++)
            {
                float a=i*Mathf.PI/8,b=(i+1)*Mathf.PI/8;
                var p=center+new Vector3(Mathf.Cos(a)*worldRadius/VisualScale.x,0,Mathf.Sin(a)*worldRadius/VisualScale.z);
                var q=center+new Vector3(Mathf.Cos(b)*worldRadius/VisualScale.x,0,Mathf.Sin(b)*worldRadius/VisualScale.z);
                int start=vertices.Count;vertices.AddRange(side>0?new[]{center,q,p}:new[]{center,p,q});normals.AddRange(new[]{Vector3.up*side,Vector3.up*side,Vector3.up*side});triangles.AddRange(new[]{start,start+1,start+2});
            }
        }}}