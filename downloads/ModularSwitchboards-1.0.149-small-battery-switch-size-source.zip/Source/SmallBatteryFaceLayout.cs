using UnityEngine;
namespace ModularSwitchboards
{
    internal static class SmallBatteryFaceLayout
    {
        internal static float Center=>StationBatteryPanelLayout.Center(4);
        internal static float SwitchX=>Center+StationBatteryPanelLayout.Width(4)*.5f-.021f;
        // Cabinet front view reverses local X: the switch is visually left.
        internal static float GaugeX=>Center-.021f;
        internal static readonly Bounds GaugeTarget=new Bounds(new Vector3(GaugeX,0,.078f),new Vector3(.101f,.040f,.026f));
        internal static readonly Bounds SwitchTarget=new Bounds(new Vector3(SwitchX,0,.080f),new Vector3(.038f,.042f,.035f));
        internal static Bounds GaugeCrop(Bounds native)
        {
            // Include the original raised meter surround and its recessed slots,
            // while keeping the external cabinet shell/back outside the crop.
            float px=native.size.x*.18f,py=Mathf.Max(native.size.y*.8f,native.size.x*.04f);
            var b=new Bounds();b.SetMinMax(new Vector3(native.min.x-px,native.min.y-py,native.min.z-Mathf.Max(native.size.y,native.size.z)),new Vector3(native.max.x+px,native.max.y+py,native.max.z+Mathf.Max(native.size.y*.35f,native.size.z)));return b;
        }
        internal static Bounds SwitchCrop(Bounds native)
        {
            var b=native;b.Expand(new Vector3(native.size.x*.65f,native.size.y*.45f,Mathf.Max(native.size.z,native.size.y*.6f)));return b;
        }
        internal static int[][] Select(Vector3[] points,int[][] groups,Bounds region)
        {
            var selected=new int[groups.Length][];
            for(int g=0;g<groups.Length;g++)
            {
                var keep=new System.Collections.Generic.List<int>();var ids=groups[g];
                for(int i=0;i<ids.Length;i+=3)
                    if(region.Contains(points[ids[i]])&&region.Contains(points[ids[i+1]])&&region.Contains(points[ids[i+2]]))
                    {keep.Add(ids[i]);keep.Add(ids[i+1]);keep.Add(ids[i+2]);}
                selected[g]=keep.ToArray();
            }
            return selected;
        }
    }
}
