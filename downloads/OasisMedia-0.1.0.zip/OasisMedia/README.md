# Oasis Media 0.1.0

Independent LaunchPad prototype for YouTube video and audio on a ScriptedScreens panel. See [INSTALACE.txt](INSTALACE.txt) for Czech installation steps.

Requires official external Windows x64 `yt-dlp.exe` and `deno.exe` together in a local directory. Configure `Player.YtDlpPath`. No API account, cookies, login, auto-installation or helper executable is included. Uses port 18766 and its own configuration token.

The bridge normalizes one YouTube URL, runs yt-dlp without shell/config/plugins, downloads a progressive H.264/AAC MP4 (up to 720p, 128 MB, 3 minutes) to an isolated temporary directory, and serves it over loopback with a random per-video capability. Range and HEAD are supported for Unity video seeking. Old media capabilities expire when a new video is ready. Temporary files are cleaned up on replacement and disposal. ScriptedScreens experimental media and StationeersLua loopback HTTP must be enabled.

This deliberately limited prototype does not merge adaptive audio/video, handle live broadcasts, playlists or authenticated videos. Many videos will have no matching progressive format. Single-player/session-host only. Actual extraction and native Unity playback have not been tested in the cloud; UI ready status is not decoder success.

Build from repository root with the existing local `Stationeers.User.props`:

```sh
dotnet build media/OasisMedia.csproj -c Release
dotnet run --project media/tests/MediaTests.csproj -c Release
PYTHONPATH=/workspace/tooling/python python media/tests/test_ui.py
```

Backend checks use a fake downloader and exercise authentication, URL validation, job completion and media range responses. Lua checks exercise the actual chip script with documented API doubles at five screen aspect ratios.
