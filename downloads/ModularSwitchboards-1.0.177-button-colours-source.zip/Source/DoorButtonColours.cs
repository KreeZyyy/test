using System.Linq;
using UnityEngine;
namespace ModularSwitchboards
{
    internal sealed class DoorButtonColour
    {
        internal string Name,Title,Icon,Terms;
        internal Color Face;
    }
    internal static class DoorButtonColours
    {
        // Keep the first button's prefab ID so existing saves become Green Button.
        internal const string GreenName="StructureSwitchboardDoorButton";
        internal static readonly DoorButtonColour[] All={
            new DoorButtonColour{Name=GreenName,Title="Green Button",Icon="DoorButton",Terms="green light green zelena svetle zelena",Face=new Color(.14f,.58f,.22f)},
            new DoorButtonColour{Name="StructureSwitchboardDoorButtonLightBlue",Title="Light Blue Button",Icon="DoorButtonLightBlue",Terms="light blue blue svetle modra modra",Face=new Color(.28f,.62f,.88f)},
            new DoorButtonColour{Name="StructureSwitchboardDoorButtonRed",Title="Red Button",Icon="DoorButtonRed",Terms="red cervena",Face=new Color(.68f,.045f,.035f)},
            new DoorButtonColour{Name="StructureSwitchboardDoorButtonBlack",Title="Black Button",Icon="DoorButtonBlack",Terms="black cerna",Face=new Color(.025f,.029f,.028f)},
            new DoorButtonColour{Name="StructureSwitchboardDoorButtonLightYellow",Title="Light Yellow Button",Icon="DoorButtonLightYellow",Terms="light yellow yellow svetle zluta zluta",Face=new Color(.90f,.78f,.28f)}
        };
        internal static DoorButtonColour Find(string name)=>All.FirstOrDefault(c=>c.Name==name);
        internal static DoorButtonColour For(string name)=>Find(name)??All[0];
    }
}
