using System;using System.Linq;using System.Collections.Generic;using System.IO;using System.Text.Json;using ModularSwitchboards;using UnityEngine;
class Program{
 static int checks;static void Check(bool ok,string message){checks++;if(!ok)throw new Exception(message);}
 static void Main(){
 var exports=new Dictionary<string,object>();var signatures=new HashSet<string>();
 foreach(SwitchboardKitKind kind in Enum.GetValues<SwitchboardKitKind>()){
 var mesh=SwitchboardKitGeometry.Build(kind);Check(mesh.V.Count>100&&mesh.N.Count==mesh.V.Count&&mesh.T.Count==5,"Incomplete kit geometry");
 var min=new Vector3(mesh.V.Min(p=>p.x),mesh.V.Min(p=>p.y),mesh.V.Min(p=>p.z));var max=new Vector3(mesh.V.Max(p=>p.x),mesh.V.Max(p=>p.y),mesh.V.Max(p=>p.z));var size=max-min;var center=(max+min)*.5f;
 foreach(var triangles in mesh.T.Values)for(int i=0;i<triangles.Length;i+=3){int a=triangles[i],b=triangles[i+1],c=triangles[i+2];Check(a>=0&&b<mesh.V.Count&&c<mesh.V.Count,"Invalid index");var cross=Vector3.Cross(mesh.V[b]-mesh.V[a],mesh.V[c]-mesh.V[a]);float dot=cross.x*mesh.N[a].x+cross.y*mesh.N[a].y+cross.z*mesh.N[a].z;Check(dot>0,"Inverted or degenerate kit face");}
 foreach(var envelope in new[]{new Vector3(.3f,.2f,.2f),new Vector3(.1f,.3f,.2f),new Vector3(.4f,.12f,.18f)}){
 float fit=SwitchboardKitGeometry.Fit(envelope,size);
 foreach(var v in mesh.V){var point=(v-center)*fit;Check(Math.Abs(point.x)<=envelope.x*.461f&&Math.Abs(point.y)<=envelope.y*.461f&&Math.Abs(point.z)<=envelope.z*.461f,"Kit visual exceeds original collision envelope");}
 }
 string signature=size.x+":"+size.y+":"+size.z+":"+mesh.V.Count;Check(signatures.Add(signature),"Kit kinds not visually distinct");Check(mesh.T[0].Length>0&&mesh.T[1].Length>0,"Neutral label/symbol absent");
 exports[kind.ToString()]=new{vertices=mesh.V.Select(v=>new[]{v.x,v.y,v.z}),triangles=mesh.T};
 }
 if(Environment.GetEnvironmentVariable("KIT_GEOMETRY_EXPORT") is string path)File.WriteAllText(path,JsonSerializer.Serialize(exports));
 Console.WriteLine($"Production kit geometry: {checks} checks passed; four distinct meshes, normals/indices, neutral labels and fitting within native collision envelopes.");
 }
}
