from pathlib import Path
import json,struct,math
from PIL import Image
root=Path(__file__).resolve().parents[2];data=json.loads((root/'Art/ModuleKit/model.json').read_text());raw=(root/'Assets/ModuleKit/Model.meshbin').read_bytes();checks=0
assert raw[:4]==b'MKIT';count,length=struct.unpack_from('<ii',raw,4);assert count==len(data['vertices']) and length==len(data['triangles']['0']);assert count<65536;off=12
for p,n,uv in zip(data['vertices'],data['normals'],data['uv']):
 assert all(math.isfinite(x)for x in p+n+uv);assert .98<sum(x*x for x in n)<1.02;assert raw[off:off+32]==struct.pack('<8f',*p,*n,*uv);off+=32;checks+=1
indices=list(struct.unpack_from('<'+'i'*length,raw,off));off+=length*4;assert off==len(raw);assert indices==data['triangles']['0'];assert all(0<=i<count for i in indices)
for envelope in [(0.3,.2,.2),(.1,.3,.2),(.4,.12,.18)]:
 lo=[min(p[k]for p in data['vertices'])for k in range(3)];hi=[max(p[k]for p in data['vertices'])for k in range(3)];scale=min(envelope[k]/(hi[k]-lo[k])for k in range(3))*.92
 for p in data['vertices']:
  assert all(abs((p[k]-(hi[k]+lo[k])*.5)*scale)<=envelope[k]*.461 for k in range(3));checks+=1
Image.open(root/'Assets/ModuleKit/Surface.png').verify();Image.open(root/'Assets/Icons/KitModules.png').verify()
print(f'Only module kit: {checks} checks passed; finite normals/UV/vertices, 16-bit capacity, exact embedded data/indices and fit inside native collision envelope; valid atlas/icon.')
