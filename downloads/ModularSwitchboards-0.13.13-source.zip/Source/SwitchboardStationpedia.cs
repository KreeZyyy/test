using System.Linq;
using Assets.Scripts;
using Assets.Scripts.Objects;
using Assets.Scripts.UI;
namespace ModularSwitchboards
{
    internal static class SwitchboardStationpedia
    {
        internal static void PopulateLists()
        {
            var data=Stationpedia.DataHandler;
            // Remove only our records before adding them once under Electronics.
            // Regeneration/language changes must not duplicate entries.
            foreach(var page in data._listDictionary.Values)
                foreach(var entries in page.Values)
                    entries.RemoveAll(e=>e.PageLink!=null&&e.PageLink.StartsWith("Thing",System.StringComparison.Ordinal)&&
                        StationpediaCatalog.Kind(e.PageLink.Substring(5))!=null);
            foreach(var thing in Prefab.AllPrefabs.Where(t=>t!=null&&!t.HideInStationpedia&&StationpediaCatalog.Kind(t.PrefabName)!=null).OrderBy(t=>t.PrefabName))
                data.AddNewListItem("Electronics","Modular Switchboards",new StationCategoryInsert{
                    PageLink="Thing"+thing.PrefabName,NameOfThing=thing.DisplayName,PrefabHash=thing.PrefabHash,InsertImage=thing.Thumbnail});
        }
        internal static void FormatSlots(Thing prefab,ref StationpediaPage page)
        {
            if(page==null||!DinModuleCatalog.Specs.TryGetValue(prefab.PrefabName,out var spec)||!spec.Fuse)return;
            foreach(var slot in page.SlotInserts)
                if(slot.SlotIndex=="0"){slot.SlotName="Cable Fuse ";slot.SlotType="Cable Fuse";}
        }
        internal static void ExpandQuery(ref string searchText)=>searchText=StationpediaCatalog.ExpandQuery(searchText);
        internal static bool CreativeSearch(ICreativeSpawnable thing,string text,string pattern,ref bool __result)
        {
            if(!(thing is Thing item)||!StationpediaCatalog.Matches(item.PrefabName,pattern))return true;
            __result=true;return false;
        }
        internal static bool Search(StationpediaPage __instance,string text,string pattern,ref bool __result)
        {
            if(!StationpediaCatalog.Matches(__instance.PrefabName,pattern))return true;
            __result=true;return false;
        }
    }
}
