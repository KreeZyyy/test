from pathlib import Path
p=Path(__file__).resolve();s=(p.parents[2]/'Source/NativeWireVisual.cs').read_text();a=s.index('        private static Material Copy(');b=s.rfind('    }');(p.parent/'Extracted.cs').write_text('using System.Linq;using UnityEngine;namespace ModularSwitchboards{static partial class NativeWireVisual{'+s[a:b]+'}}')
