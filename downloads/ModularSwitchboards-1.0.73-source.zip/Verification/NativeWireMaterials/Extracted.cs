using System.Linq;using UnityEngine;namespace ModularSwitchboards{static partial class NativeWireVisual{        private static Material Copy(Material source)
        {
            if(source==null)return null;
            if(!Materials.TryGetValue(source,out var copy)){copy=new Material(source){name="Switchboards.NativeWire."+source.name};Materials[source]=copy;}return copy;
        }
        internal static bool Paint(MeshRenderer renderer,ColorType colour)
        {
            var marker=renderer.GetComponent<NativeWireRenderer>();if(marker==null||!marker.Active)return false;
            if(marker.LastColor==(int)colour)return true;var template=Get(marker.Kind);if(template==null)return false;
            var swatch=GameManager.GetColorSwatch((int)colour);var paint=swatch?.Normal??template.Paintable;
            renderer.sharedMaterials=template.Materials.Select(m=>Copy(m==template.Paintable?paint:m)).ToArray();
            // Keep native shader/atlas and original UVs. No cabinet material or new stripe texture.
            for(int i=0;i<template.Materials.Length;i++){if(template.Materials[i]!=template.Paintable){renderer.SetPropertyBlock(null,i);continue;}var block=new MaterialPropertyBlock();block.SetFloat(Thing.DiffuseIndexPropertyID,(int)colour);renderer.SetPropertyBlock(block,i);}
            marker.LastColor=(int)colour;return true;
        }
}}