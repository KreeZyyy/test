using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Assets.Scripts;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Electrical;
using Assets.Scripts.Objects.Structures;
using Assets.Scripts.Util;
using HarmonyLib;
using LaunchPadBooster;
using Reagents;
using UnityEngine;
using Object = UnityEngine.Object;

namespace ModularSwitchboards
{
    public sealed class SwitchboardsMod : MonoBehaviour
    {
        public const string Version = "0.12.9";
        // Keep the 0.1.0 identity so saved kits continue to work.
        public const string KitName = "ItemKitModularSwitchboard";
        public const string CabinetName = "StructureModularSwitchboard";
        public const string RailKitName = "ItemKitDinRail";
        public const string RailName = "StructureSwitchboardDinRail";
        public const string BreakerKitName = "ItemKitDinBreaker1P";
        public const string BreakerName = "StructureDinBreaker1P";
        public static readonly Mod Mod = new Mod("ModularSwitchboards", Version);
        private static bool loaded;
        private static GameObject storage;
        private static readonly MethodInfo CloneMethod = AccessTools.Method(typeof(object), "MemberwiseClone");

        public void OnLoaded(List<GameObject> prefabs)
        {
            if (loaded) return;
            LibConstructDependency.Validate();
            Mod.AddSaveDataType<SwitchboardCabinetSaveData>();
            Mod.AddSaveDataType<DinRailSaveData>();
            Mod.AddSaveDataType<DinBreakerSaveData>();
            var harmony = new Harmony("modularswitchboards.prototype");
            harmony.Patch(AccessTools.Method(typeof(Assets.Scripts.Objects.Pipes.Device), "OnDestroy"),
                prefix: new HarmonyMethod(typeof(SwitchboardPrefabs), nameof(SwitchboardPrefabs.AllowNativeDestroy)));
            harmony.Patch(AccessTools.Method(typeof(Thing), "OnDestroy"),
                prefix: new HarmonyMethod(typeof(SwitchboardPrefabs), nameof(SwitchboardPrefabs.AllowNativeDestroy)));
            harmony.Patch(AccessTools.Method(typeof(LibConstruct.PlacementBoard), "CreateBoardStructure"),
                prefix: new HarmonyMethod(typeof(SwitchboardsMod), nameof(ValidateRailCreation)));
            harmony.Patch(AccessTools.Method(typeof(Prefab), "LoadAll"),
                prefix: new HarmonyMethod(typeof(SwitchboardsMod), nameof(PreparePrefabs)));
            harmony.Patch(AccessTools.Method(typeof(DynamicThingRecipeComparable), "GenerateRecipieList"),
                prefix: new HarmonyMethod(typeof(SwitchboardsMod), nameof(PrepareRecipe)));
            harmony.Patch(AccessTools.Method(typeof(Localization), "GetThingName"),
                prefix: new HarmonyMethod(typeof(SwitchboardsMod), nameof(LocalizeName)));
            harmony.Patch(AccessTools.Method(typeof(Localization), "GetThingDescription"),
                prefix: new HarmonyMethod(typeof(SwitchboardsMod), nameof(LocalizeDescription)));
            harmony.Patch(AccessTools.Method(typeof(Structure), "CachePrefabBounds"),
                prefix: new HarmonyMethod(typeof(SwitchboardsMod), nameof(CacheCabinetBounds)));
            harmony.Patch(AccessTools.Method(typeof(Thing), "CanCacheRenderer"),
                prefix: new HarmonyMethod(typeof(CabinetAppearance), nameof(CabinetAppearance.CanCacheRenderer)));
            harmony.Patch(AccessTools.Method(typeof(Thing), "Awake"),
                postfix: new HarmonyMethod(typeof(CabinetAppearance), nameof(CabinetAppearance.RegisterRenderers)));
            harmony.Patch(AccessTools.Method(typeof(Thing), "DeserializeSave"),
                prefix: new HarmonyMethod(typeof(SwitchboardsMod), nameof(MigrateBreakerName)));
            harmony.Patch(AccessTools.Method(typeof(Structure), "DeserializeSave"),
                prefix: new HarmonyMethod(typeof(SwitchboardsMod), nameof(MigrateCabinetSave)));
            harmony.Patch(AccessTools.Method(typeof(Thing), "SetCustomColor", new[] { typeof(int), typeof(bool) }),
                postfix: new HarmonyMethod(typeof(CabinetAppearance), nameof(CabinetAppearance.RefreshPaint)));
            harmony.Patch(AccessTools.Method(typeof(Thing), "SetCustomColor", new[] { typeof(bool) }),
                postfix: new HarmonyMethod(typeof(CabinetAppearance), nameof(CabinetAppearance.RefreshPaint)));
            harmony.Patch(AccessTools.Method(typeof(Structure), "UpdateAllMaterialPropertyBlocks"),
                postfix: new HarmonyMethod(typeof(CabinetAppearance), nameof(CabinetAppearance.RefreshPaint)));
            harmony.Patch(AccessTools.Method(typeof(Structure), "AttackWith"),
                prefix: new HarmonyMethod(typeof(CabinetAppearance), nameof(CabinetAppearance.BeginBuildColor)),
                postfix: new HarmonyMethod(typeof(CabinetAppearance), nameof(CabinetAppearance.ApplyCompletedWhite)));
            Mod.Networking.Required = true;
            Prefab.OnPrefabsLoaded += VerifyRegistration;
            WorldManager.OnGameDataLoaded += VerifyRecipe;
            loaded = true;
            Debug.Log("[Modular Switchboards] " + Version + " loaded.");
        }

        private static T Source<T>(IEnumerable<Thing> sources, string name) where T : Thing
        {
            var result = sources.OfType<T>().FirstOrDefault(p => p.PrefabName == name || p.name == name);
            if (result == null) throw new InvalidOperationException("Missing source prefab: " + name);
            return result;
        }

        private static void Identify(Thing thing, string name, string title)
        {
            thing.name = name;
            thing.PrefabName = name;
            thing.PrefabHash = Animator.StringToHash(name);
            thing.CustomName = title;
        }

        // Called before LoadAll reads SourcePrefabs. Build complete clones before publishing them.
        private static void PreparePrefabs()
        {
            if (WorldManager.Instance == null)
            {
                Debug.LogError("[Modular Switchboards] WorldManager unavailable.");
                return;
            }
            var sources = WorldManager.Instance.SourcePrefabs;
            if (sources.Any(p => p != null && p.PrefabName == KitName)) return;
            MultiConstructor kit = null;
            Structure cabinet = null;
            MultiConstructor railKit = null;
            DinRail rail = null;
            MultiConstructor breakerKit = null;
            DinBreaker breaker = null;
            try
            {
                LibConstructDependency.RequireInitialized();
                foreach (var name in new[] { KitName, CabinetName, RailKitName, RailName, BreakerKitName, BreakerName })
                    if (sources.Any(p => p != null && p.PrefabHash == Animator.StringToHash(name)))
                        throw new InvalidOperationException("Prefab identity collision: " + name);
                var kitSource = Source<MultiConstructor>(sources, "ItemKitLogicSwitch");
                var locker = sources.OfType<Locker>().FirstOrDefault(p => p.PrefabName == "StructureLockerSmall")
                    ?? sources.OfType<Locker>().FirstOrDefault(p => p.PrefabName == "StructureLocker")
                    ?? sources.OfType<Locker>().Where(p => p.GetType() == typeof(Locker) &&
                        p.BuildStates != null && p.BuildStates.Count > 0)
                        .OrderBy(p => p.PrefabName, StringComparer.Ordinal).FirstOrDefault();
                if (locker == null) throw new InvalidOperationException("No vanilla Locker prefab with build states found.");
                var wrench = Source<Item>(sources, "ItemWrench");
                var drill = Source<Item>(sources, "ItemDrill");
                var sheets = Source<Item>(sources, "ItemIronSheets");

                if (storage == null)
                {
                    storage = new GameObject("ModularSwitchboards.SourcePrefabs");
                    storage.SetActive(false);
                    Object.DontDestroyOnLoad(storage);
                }
                kit = Object.Instantiate(kitSource, storage.transform);
                Identify(kit, KitName, "Kit (Switchboard)");
                kit.SetQuantity(1);
                // Do not transfer the temporary vanilla kit's legacy colour to the new shell.
                // Painting is supported on the assembled cabinet itself.
                kit.PaintableMaterial = null;
                kit.RecipeTier = MachineTier.TierOne;
                cabinet = SwitchboardPrefabs.ReplaceComponent<SwitchboardCabinet>(Object.Instantiate<Structure>(locker, storage.transform));
                Identify(cabinet, CabinetName, "Switchboard Small");
                if (cabinet.BuildStates == null || cabinet.BuildStates.Count == 0)
                    throw new InvalidOperationException("Locker has no build state visuals.");

                // Copy from the cloned prefab: its renderer/collider references already point to the clone.
                var visual = cabinet.BuildStates[cabinet.BuildStates.Count - 1];
                cabinet.BuildStates = new List<BuildState>
                {
                    MakeState(visual, kit, 1, null, 0, drill),
                    MakeState(visual, wrench, 0, sheets, 2, wrench)
                };
                cabinet.UpgradePrefab = null;
                // This is a cabinet shell, not a general-purpose storage locker.
                cabinet.Slots = new List<Slot>();
                cabinet.Interactables = cabinet.Interactables.Where(i => i != null && i.Slot == null).ToList();
                CabinetModel.Install(cabinet);
                NativeRearBox.Install((SwitchboardCabinet)cabinet);
                OvenInputPanel.Install((SwitchboardCabinet)cabinet);
                ((SwitchboardCabinet)cabinet).PortBodyGrids=(Assets.Scripts.GridSystem.Grid3[])cabinet.GetLocalSmallGridBounds();
                ExternalCablePorts.InstallRearBody((SwitchboardCabinet)cabinet);
                ExternalCablePorts.TryInstall((SwitchboardCabinet)cabinet);
                CabinetNameplate.Install((SwitchboardCabinet)cabinet);
                var host = (SwitchboardCabinet)cabinet;
                var origin = new GameObject("DinRailBoard") { layer = cabinet.gameObject.layer };
                origin.transform.SetParent(cabinet.transform.Find("SwitchboardModel/CompletedShell"), false);
                origin.transform.localPosition = new Vector3(0f, 0f, .014f);
                host.RailOrigin = origin.transform;
                host.RailSurface = origin.AddComponent<BoxCollider>();
                host.RailSurface.size = new Vector3(DinLayout.CabinetInnerWidth, .43f, .002f);
                cabinet.BuildStates[1].Colliders.Add(host.RailSurface);

                railKit = Object.Instantiate(kitSource, storage.transform);
                Identify(railKit, RailKitName, "Kit (DIN Rail)");
                railKit.SetQuantity(1); railKit.PaintableMaterial = null; railKit.RecipeTier = MachineTier.TierOne;
                rail = SwitchboardPrefabs.ReplaceComponent<DinRail>(Object.Instantiate<Structure>(locker, storage.transform));
                Identify(rail, RailName, "DIN Rail");
                rail.BuildStates = new List<BuildState> { MakeState(rail.BuildStates.Last(), railKit, 1, null, 0, drill) };
                rail.UpgradePrefab = null;
                DinRailModel.Install(rail, storage.transform);
                railKit.Constructables = new List<Structure> { rail }; railKit.LastSelectedIndex = 0;
                railKit.Thumbnail = kitSource.Thumbnail; railKit.Thumbnails = kitSource.Thumbnails;
                breakerKit = Object.Instantiate(kitSource, storage.transform);
                Identify(breakerKit, BreakerKitName, "Kit (DIN Breaker)");
                breakerKit.SetQuantity(1); breakerKit.PaintableMaterial = null; breakerKit.RecipeTier = MachineTier.TierOne;
                breaker = SwitchboardPrefabs.ReplaceComponent<DinBreaker>(Object.Instantiate<Structure>(locker, storage.transform));
                Identify(breaker, BreakerName, "DIN Breaker");
                breaker.BuildStates = new List<BuildState> { MakeState(breaker.BuildStates.Last(), breakerKit, 1, null, 0, drill) };
                breaker.UpgradePrefab = null;
                DinBreakerModel.Install(breaker, storage.transform);
                breakerKit.Constructables = new List<Structure> { breaker }; breakerKit.LastSelectedIndex = 0;
                breakerKit.Thumbnail = kitSource.Thumbnail; breakerKit.Thumbnails = kitSource.Thumbnails;
                kit.Constructables = new List<Structure> { cabinet };
                kit.LastSelectedIndex = 0;
                kit.Thumbnail = kitSource.Thumbnail;
                kit.Thumbnails = kitSource.Thumbnails;
                sources.Add(kit);
                sources.Add(cabinet);
                sources.Add(railKit);
                sources.Add(rail);
                sources.Add(breakerKit);
                sources.Add(breaker);
                Debug.Log("[Modular Switchboards] Prepared kit + 2-stage empty cabinet with Blender geometry; native base: " + locker.PrefabName);
            }
            catch (Exception ex)
            {
                // Never publish a partially configured prefab pair.
                if (kit != null) { sources.Remove(kit); Object.Destroy(kit.gameObject); }
                if (cabinet != null) { sources.Remove(cabinet); Object.Destroy(cabinet.gameObject); }
                if (railKit != null) { sources.Remove(railKit); Object.Destroy(railKit.gameObject); }
                if (rail != null) { sources.Remove(rail); Object.Destroy(rail.gameObject); }
                if (breakerKit != null) { sources.Remove(breakerKit); Object.Destroy(breakerKit.gameObject); }
                if (breaker != null) { sources.Remove(breaker); Object.Destroy(breaker.gameObject); }
                Debug.LogError("[Modular Switchboards] Prefab setup failed: " + ex);
            }
        }

        private static BuildState MakeState(BuildState visual, Item entry, int quantity,
            Item entry2, int quantity2, Item exit)
        {
            // Preserve private batched drawing data, but give each stage its own mutable collections/tool.
            var state = (BuildState)CloneMethod.Invoke(visual, null);
            state.StateMeshes = new List<Mesh>(visual.StateMeshes);
            state.Colliders = new List<Collider>(visual.Colliders);
            state.LinkedGameObjects = new List<GameObject>(visual.LinkedGameObjects);
            state.Interactables = visual.Interactables == null ? new List<Interactable>() :
                visual.Interactables.Where(i => i != null && i.Slot == null).ToList();
            state.RendererInstance = null;
            state.RenderMode = BuildStateRenderMode.OnMyState;
            state.CanManufacture = false;
            state.Tool = new ToolUse
            {
                ToolEntry = entry, EntryQuantity = quantity,
                ToolEntry2 = entry2, EntryQuantity2 = quantity2,
                ToolExit = exit, ExitQuantity = 0, EntryTime = 2f, ExitTime = 2f
            };
            return state;
        }

        // Runs after game/mod recipe files have loaded and before tier lists and recipe hashes are generated.
        private static void PrepareRecipe(DynamicThingRecipeComparable __instance)
        {
            if (!ReferenceEquals(__instance, ElectronicsPrinter.RecipeComparable)) return;
            var kit = Prefab.Find<MultiConstructor>(KitName);
            var railKit = Prefab.Find<MultiConstructor>(RailKitName);
            if (railKit != null && !__instance.AllRecipes.ContainsKey(railKit))
                __instance.AddRecipe(new WorldManager.RecipeData {
                    PrefabName = RailKitName, RecipeTier = MachineTier.TierOne, Output = 1f,
                    Recipe = new Recipe { Iron = 1, Time = 2f, Energy = 200f }
                }, null);
            var breakerKit = Prefab.Find<MultiConstructor>(BreakerKitName);
            if (breakerKit != null && !__instance.AllRecipes.ContainsKey(breakerKit))
                __instance.AddRecipe(new WorldManager.RecipeData {
                    PrefabName = BreakerKitName, RecipeTier = MachineTier.TierOne, Output = 1f,
                    Recipe = new Recipe { Iron = 2, Copper = 1, Time = 3f, Energy = 400f }
                }, null);
            if (kit == null || __instance.AllRecipes.ContainsKey(kit)) return;
            var recipe = new WorldManager.RecipeData
            {
                PrefabName = KitName, RecipeTier = MachineTier.TierOne, Output = 1f,
                Recipe = new Recipe { Iron = 10, Copper = 10, Electrum = 10, Time = 5f, Energy = 1000f }
            };
            if (__instance.AddRecipe(recipe, null))
                Debug.Log("[Modular Switchboards] Electronics Printer recipe added: 10 Copper + 10 Iron + 10 Electrum -> 1 kit.");
        }

        private static bool LocalizeName(string __0, ref string __result)
        {
            if (__0 == KitName) __result = "Kit (Switchboard)";
            else if (__0 == RailKitName) __result = "Kit (DIN Rail)";
            else if (__0 == RailName) __result = "DIN Rail";
            else if (__0 == BreakerKitName) __result = "Kit (DIN Breaker)";
            else if (__0 == BreakerName) __result = "DIN Breaker";
            else if (__0 == CabinetName) __result = "Switchboard Small";
            else return true;
            return false;
        }

        private static bool LocalizeDescription(string __0, ref string __result)
        {
            if (__0 == BreakerKitName || __0 == BreakerName)
            {
                __result = "One-module DIN breaker mounting prototype (40.5 mm). Electronics Printer: 2 Iron + 1 Copper -> 1 kit. " +
                    "Open the completed cabinet and aim at an installed DIN rail. Choose a free position; Drill returns the kit. " +
                    "Click the lever inside the open cabinet: OFF (red) / ON (green). New breakers start OFF. The switch state is saved and synchronized. No electrical connections, current sensing or trip protection yet.";
                return false;
            }
            if (__0 == RailKitName || __0 == RailName)
            {
                __result = "DIN mounting rail. Electronics Printer: 1 Iron -> 1 kit. Open a completed Switchboard Cabinet, " +
                    "right-click with the kit and aim at the upper or lower half of the mounting plate. One kit per row. " +
                    "Drill removes the rail and returns its kit. 8 module positions per row. Install DIN Breaker mounting prototypes; remove them before dismantling the rail. External native APC cable connectors: one top power input and two lower outputs. No internal bridge yet. Electrical circuits and internal wiring follow later.";
                return false;
            }
            if (__0 != KitName && __0 != CabinetName) return true;
            __result = "Empty modular switchboard cabinet. Print one kit in an Electronics Printer " +
                "(10 Copper + 10 Iron + 10 Electrum). Place one kit on a wall to create the bare mounting frame, then use a Wrench " +
                "with 2 Iron Sheets in the other hand to complete the shell and solid cover. " +
                "Dismantle with Wrench, then Drill. Paint changes the shell inside and out and both sides of the cover; the mounting plate stays dark grey with fixed fasteners; the DIN rails stay uniformly matte grey with slotted mounting holes. " +
                "Open the completed cabinet to install up to two DIN rails using their separate kits. Remove rails before dismantling the cabinet. DIN Breaker mounting prototypes can be installed on the rails. External native APC cable connectors: one top power input and two lower outputs. No internal bridge yet. Electrical circuits and internal wiring follow later.";
            return false;
        }

        private static void MigrateBreakerName(Thing __instance, ThingSaveData __0)
        {
            if(__instance.PrefabName==CabinetName && (__0.CustomName=="Switchboard Cabinet" || __0.CustomName=="Switchboard")) __0.CustomName="Switchboard Small";
            if(__instance.PrefabName==BreakerName && __0.CustomName=="DIN Breaker 1P") __0.CustomName="DIN Breaker";
            if(__instance.PrefabName==BreakerKitName && __0.CustomName=="Kit (DIN Breaker 1P)") __0.CustomName="Kit (DIN Breaker)";
        }

        private static void MigrateCabinetSave(Structure __instance, ThingSaveData __0)
        {
            if (__instance.PrefabName == CabinetName && __0 is StructureSaveData save && save.CurrentBuildState > 1)
            {
                save.CurrentBuildState = 1;
                Debug.Log("[Modular Switchboards] Migrated legacy completed cabinet to simple completed shell.");
            }
        }

        // Validate on the authority before LibConstruct consumes the kit, including multiplayer messages.
        private static bool ValidateRailCreation(LibConstruct.CreateBoardStructureInstance __0)
        {
            if (__0.StructurePrefab is DinBreaker)
                return __0.Constructor != null && __0.Constructor.PrefabName == BreakerKitName &&
                    DinBreaker.CanPlace(__0.Board, __0.Position, __0.Rotation);
            if (!(__0.StructurePrefab is DinRail)) return true;
            return __0.Constructor != null && __0.Constructor.PrefabName == RailKitName &&
                DinRail.CanPlace(__0.Board, __0.Position, __0.Rotation);
        }

        private static bool CacheCabinetBounds(Structure __instance)
        {
            if (__instance.PrefabName != CabinetName) return true;
            CabinetModel.SetBounds(__instance);
            return false;
        }

        // Register clones source prefabs. Cross-prefab references can still point to the source;
        // compare stable identity instead of Unity object identity.
        private static bool SamePrefab(Structure candidate, Structure registered)
        {
            return candidate != null && registered != null &&
                candidate.PrefabHash == registered.PrefabHash && candidate.PrefabName == registered.PrefabName;
        }

        private static void VerifyRegistration()
        {
            var kit = Prefab.Find<MultiConstructor>(KitName);
            var cabinet = Prefab.Find<Structure>(CabinetName);
            var railKit = Prefab.Find<MultiConstructor>(RailKitName);
            var rail = Prefab.Find<DinRail>(RailName);
            var breakerKit = Prefab.Find<MultiConstructor>(BreakerKitName);
            var breaker = Prefab.Find<DinBreaker>(BreakerName);
            if (breakerKit == null || breaker == null || breakerKit.Constructables.Count != 1 || !SamePrefab(breakerKit.Constructables[0], breaker))
                Debug.LogError("[Modular Switchboards] Breaker registration verification FAILED.");
            else Debug.Log("[Modular Switchboards] Breaker registered: one module, nested rail host.");
            if (!(cabinet is SwitchboardCabinet) || railKit == null || rail == null ||
                railKit.Constructables.Count != 1 || !SamePrefab(railKit.Constructables[0], rail) || rail.BuildStates.Count != 1)
                Debug.LogError("[Modular Switchboards] DIN rail registration verification FAILED.");
            else Debug.Log("[Modular Switchboards] DIN rail kit + structure registered; two rows, 8 positions per row.");
            if(cabinet is SwitchboardCabinet host &&
                (host.OpenEnds == null || host.OpenEnds.Count == 0) &&
                host.transform.Find("SwitchboardModel/CompletedShell/ExternalCablePorts") == null)
                Debug.Log("[Modular Switchboards] External connectors intentionally disabled for rear-shell redesign; no ports registered.");
            else Debug.LogError("[Modular Switchboards] Unexpected external connectors in rear-shell-only build.");
            if (kit == null || cabinet == null || cabinet.BuildStates.Count != 2 ||
                kit.Constructables.Count != 1 || kit.Constructables[0].PrefabHash != cabinet.PrefabHash)
                Debug.LogError("[Modular Switchboards] Registration verification FAILED.");
            else
                Debug.Log("[Modular Switchboards] Registration verified: kit + cabinet, 2 build states.");
        }

        private static void VerifyRecipe()
        {
            var kit = Prefab.Find<MultiConstructor>(KitName);
            var railKit = Prefab.Find<MultiConstructor>(RailKitName);
            if (railKit == null || !ElectronicsPrinter.RecipeComparable.AllRecipes.ContainsKey(railKit) ||
                !ElectronicsPrinter.RecipeComparable.DynamicThings.Contains(railKit))
                Debug.LogError("[Modular Switchboards] DIN rail Electronics Printer recipe verification FAILED.");
            else Debug.Log("[Modular Switchboards] DIN rail recipe verified: Electronics Printer, 1 Iron -> 1 kit.");
            if (kit == null || !ElectronicsPrinter.RecipeComparable.AllRecipes.ContainsKey(kit) ||
                !ElectronicsPrinter.RecipeComparable.DynamicThings.Contains(kit))
                Debug.LogError("[Modular Switchboards] Electronics Printer recipe verification FAILED.");
            else Debug.Log("[Modular Switchboards] Electronics Printer recipe verified.");
            var breakerKit = Prefab.Find<MultiConstructor>(BreakerKitName);
            if (breakerKit == null || !ElectronicsPrinter.RecipeComparable.AllRecipes.ContainsKey(breakerKit) ||
                !ElectronicsPrinter.RecipeComparable.DynamicThings.Contains(breakerKit))
                Debug.LogError("[Modular Switchboards] Breaker Electronics Printer recipe verification FAILED.");
            else Debug.Log("[Modular Switchboards] Breaker recipe verified: 2 Iron + 1 Copper -> 1 kit.");
        }
    }
}
