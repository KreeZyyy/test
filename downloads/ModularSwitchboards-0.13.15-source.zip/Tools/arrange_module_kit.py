"""Six loose, face-up modules; rigid body bounds fit inside walls without overlap."""
from pathlib import Path
import json,subprocess,sys,random
from kit_layout import rotate,add,bounds,obb,separate,inside
root=Path(__file__).resolve().parents[1];f=root/'Art/ModuleKit/source.json';data=json.loads(f.read_text())
packed=json.loads((root/'Art/ModuleKit/packed-contents.json').read_text());pv=packed['vertices']
def group(x):return 0 if x<-.106 else 1 if x<.005 else 2
# Four breakers, one empty fuse holder, one empty backup. Each lies on its rear.
# Pack face-up rigid boxes with varying yaw and position, rather than a row/grid.
parts={}
for groupid in range(3):
 ids=[i for i,p in enumerate(pv)if group(p[0])==groupid]
 center=[sum(pair)*.5 for pair in bounds([pv[i]for i in ids])]
 parts[groupid]=[[q*.66 for q in rotate([pv[i][k]-center[k]for k in range(3)],[-75,0,0])]for i in ids]
rng=random.Random(1315);layout=[]
for restart in range(40):
 layout=[];packed_boxes=[]
 for groupid in [2,1,0,0,0,0]:
  for attempt in range(1200):
   x,z=rng.uniform(-.145,.145),rng.uniform(-.145,.145);yaw=rng.uniform(-80,80);floor=rng.uniform(.077,.089)
   rotated=[rotate(p,[0,yaw,0])for p in parts[groupid]];low=min(p[1]for p in rotated)
   body=obb(parts[groupid],[0,yaw,0],[x,floor-low,z])
   if not inside(body['corners'])or not all(separate(body,other)for other in packed_boxes):continue
   packed_boxes.append(body);layout.append((groupid,[x,z],yaw,floor));break
  else:break
 if len(layout)==6:break
assert len(layout)==6,'Could not pack six modules safely'
contents={'vertices':[],'triangles':{k:[]for k in packed['triangles']}};placed=[];description=[]
for groupid,(x,z),yaw,floor in layout:
 ids=[i for i,p in enumerate(pv)if group(p[0])==groupid];index={old:i for i,old in enumerate(ids)}
 center=[sum(pair)*.5 for pair in bounds([pv[i]for i in ids])]
 # Packed modules already lean -15 degrees around X. -75 more turns the front upward.
 points=[[q*.66 for q in rotate([pv[i][k]-center[k]for k in range(3)],[-75,0,0])]for i in ids]
 angles=[0,yaw,0];rotated=[rotate(p,angles)for p in points];low=min(p[1]for p in rotated);shift=[x,floor-low,z]
 world=[add(p,shift)for p in rotated];body=obb(points,angles,shift)
 assert inside(body['corners']),('module wall',groupid,bounds(world))
 assert all(separate(body,other)for other in placed),('module overlap',groupid,x,z)
 placed.append(body);offset=len(contents['vertices']);contents['vertices'].extend(world)
 for role,ts in packed['triangles'].items():
  for i in range(0,len(ts),3):
   triangle=ts[i:i+3]
   if group(pv[triangle[0]][0])!=groupid:continue
   assert all(group(pv[j][0])==groupid for j in triangle)
   contents['triangles'][role].extend(offset+index[j]for j in triangle)
 description.append({'part':['breaker','empty fuse holder','empty battery backup'][groupid],'yaw':yaw,'floor':floor,'positionXZ':[x,z],'obb':body})
data['contents']=contents;data['layout']=description;data['layoutPolicy']='Six rear-down/front-up modules, conservative OBB separation and chamfered wall clearance.'
f.write_text(json.dumps(data));subprocess.run([sys.executable,str(root/'Tools/create_module_kit.py')],check=True)
print('Six face-up modules: all wall/corner clearance and 15 pair separations passed.')
