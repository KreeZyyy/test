"""Same preserved crate as the module kit; original perforated DIN rail contents.
Decorative bundles of four different lengths. Run before render_rail_kit.py.
"""
from pathlib import Path
import json,subprocess,sys,math,random
from kit_layout import rotate,add,bounds,obb,separate,inside
root=Path(__file__).resolve().parents[1]
shell=json.loads((root/'Art/ModuleKit/source.json').read_text())['shell']
v=[];tri=[]
def quad(a,b,c,d):
 i=len(v);v.extend([a,b,c,d]);tri.extend([i,i+1,i+2,i,i+2,i+3])
def box(x0,x1,y0,y1,z0,z1):
 if x1-x0<1e-8 or y1-y0<1e-8 or z1-z0<1e-8:return
 quad([x0,y0,z0],[x0,y0,z1],[x0,y1,z1],[x0,y1,z0])
 quad([x1,y0,z1],[x1,y0,z0],[x1,y1,z0],[x1,y1,z1])
 quad([x0,y0,z1],[x0,y0,z0],[x1,y0,z0],[x1,y0,z1])
 quad([x0,y1,z0],[x0,y1,z1],[x1,y1,z1],[x1,y1,z0])
 quad([x1,y0,z0],[x0,y0,z0],[x0,y1,z0],[x1,y1,z0])
 quad([x0,y0,z1],[x1,y0,z1],[x1,y1,z1],[x0,y1,z1])
def rail(length,y,z):
 left=-.215;right=left+length
 # A thin perforated web, upright sides and outward lips: open TH35 section.
 slots=max(2,round(length/.060));pitch=length/slots;edge=left
 for i in range(slots):
  center=left+(i+.5)*pitch;a=center-.011;b=center+.011
  box(edge,a,y,y+.002,z-.018,z+.018)
  box(a,b,y,y+.002,z-.018,z-.004)
  box(a,b,y,y+.002,z+.004,z+.018)
  edge=b
 box(edge,right,y,y+.002,z-.018,z+.018)
 for side in [-1,1]:
  c=z+side*.019
  box(left,right,y,y+.027,c-.001,c+.001)
  c=z+side*.024
  box(left,right,y+.025,y+.027,c-.006,c+.006)
lengths=[.430,.350,.275,.200];placements=[];placed=[]
# Every layer combines different lengths; there are no length-based bundles.
# Seed is authoring-only, so every rebuild and game instance has the same layout.
rng=random.Random(1315)
order=[(.430,.200),(.275,.350),(.200,.430),(.350,.275),(.430,.200),(.275,.350)]
for layer,pair in enumerate(order):
 for length in pair:
  start=len(v);rail(length,0,0);pivot=-.215+length/2
  local=[[p[0]-pivot,p[1],p[2]]for p in v[start:]]
  selected=None
  for attempt in range(8000):
   angles=[rng.uniform(-2,2),rng.uniform(-85,85),rng.uniform(-2,2)]
   rotated=[rotate(p,angles)for p in local];low=min(p[1]for p in rotated)
   shift=[rng.uniform(-.105,.105),.078+layer*.045-low,rng.uniform(-.105,.105)]
   body=obb(local,angles,shift)
   if not inside(body['corners']):continue
   if not all(separate(body,other)for other in placed):continue
   selected=(body,angles,shift,rotated);break
  assert selected is not None,('Unable to pack rail',layer,length)
  body,angles,shift,rotated=selected;placed.append(body)
  v[start:]=[add(p,shift)for p in rotated]
  placements.append({'length':length,'center':shift,'rotationXYZ':angles,'layer':layer,'obb':body})
source={'shell':shell,'contents':{'vertices':v,'triangles':{'4':tri}},'design':{'lengths':lengths,'layers':6,'placements':placements,'layout':'mixed lengths across crossing directions, separated rigid bounds and inset chamfered corners','section':'open perforated DIN channel; real web holes','note':'decorative contents do not imply additional kit quantity'}}
(root/'Art/RailKit/source.json').write_text(json.dumps(source))
subprocess.run([sys.executable,str(root/'Tools/create_module_kit.py'),'RailKit'],check=True)
print('Rail crate: all four lengths mixed across directions; wall/corner and pairwise separation passed.')
