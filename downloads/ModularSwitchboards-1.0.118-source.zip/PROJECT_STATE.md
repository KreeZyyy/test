# Modular Switchboards 1.0.118 — visible IC10 and display pockets in unfinished Core

Core now shows the original-depth IC10 opening with an opaque gray floor before the socket is fitted. The display opening matches the native bezel footprint and is 4 mm deep, also with gray walls and a closed floor. These pockets remain beneath the fitted components. Stage0 shows both openings, stage1 adds the display, stage2 adds the original native IC10 socket. F1 images match the revised stage models.

Construction remains 5 Smart kits, then 2 Electronic Parts, then 5 Heavy Cable Coils; IC10 separate. Recipes, saved-stage migration, completed-only chip/control/network/power/wiring gates remain unchanged.

Validation: native-reference build without warnings/errors; 7,005 native geometry/ray/depth/material/nondegenerate checks and 49 stage/model/control/rollback checks passed. Actual Unity appearance/construction/save-load/multiplayer verification remains pending.

# Modular Switchboards 1.0.117 — Smart kit economy and three-stage Core

One Smart kit now costs 10 Copper + 8 Steel + 4 Solder in the Electronics Printer. Core construction: 5 Smart kits build the solid body without display or IC10 socket; 2 Electronic Parts add the display; 5 Heavy Cable Coils add the original socket and its pocket. Insert a separate removable IC10 only after completion. Other Smart module construction kit counts remain unchanged.

Each Core stage has its own F1 image. Incomplete Cores cannot accept IC10, use controls, run programs, bind power/data networks or receive new wiring. Heavy coil assembly uses native construction instead of internal wiring at the display-only stage. New saves preserve partial stages; older completed Core saves migrate to the final stage. The completed native display/socket appearance is preserved.

Validation: native-reference build without warnings/errors; 14 Smart-kit placement/recipe checks, 15 Core save/XML/chip/legacy checks, 49 stage/model/control/rollback checks, 2,085 native LED/socket geometry checks and 21,938 other geometry checks passed. Stage icons visually inspected. Actual Unity construction/slot/wiring/save-load/multiplayer verification remains pending.

# Modular Switchboards 1.0.116 — original battery floor depth and material

The unfinished battery holder now uses the original deepest native APC floor geometry and material instead of the shallow gray plate. Preserve its original floor depth, vertex channels, UVs, material roles and property blocks. Expand only in X/Y to close the unfinished aperture. The completed native holder stays unchanged. The F1 unfinished image matches the deeper original floor.

Battery construction remains 5 DIN kits plus 1 Electronic Parts; cell separate. Transformer construction remains Small 5 kits plus 2 Heavy Cable Coils, Medium 8 kits plus 6 Heavy Cable Coils. Completed-only new wiring and existing save/power/slot gates remain.

Validation: native-reference build without warnings/errors; 12 production floor-selection/material-role/depth/backface checks passed. Actual Unity appearance/construction/slot/wiring/save-load/multiplayer verification remains pending.

# Modular Switchboards 1.0.115 — battery completion parts and heavy transformer windings

Battery holder: 5 DIN module kits build the body; 1 Electronic Parts completes the original native holder. No Gold or Plastic Sheet is required for this completion. The removable cell remains separate. An opaque gray backing now closes the unfinished aperture, with a matching F1 stage image; the completed original holder is unchanged.

Transformer winding completion now requires Heavy Cable Coils: Small uses 5 DIN module kits plus 2 Heavy Cable Coils; Medium uses 8 DIN module kits plus 6 Heavy Cable Coils. The heavy coil prefab is resolved from the native cable catalog instead of guessing its name. Body construction, completed-only new wiring, slot/power gates, saved-stage migration and other recipes remain as before.

Validation: native-reference build without warnings/errors; 12 updated production winding/contact-priority checks and 21,938 geometry checks passed. Actual Unity appearance/construction/slot/wiring/save-load/multiplayer verification remains pending.

# Modular Switchboards 1.0.114 — restore original battery holder model

Restore the original battery holder appearance without added gray frame bars or extra gold contact pads. Five DIN module kits build the body with an empty opening; 1 g Gold completes the original native holder. The battery cell remains separately removable. Retain construction stages, old-save completion migration, power/slot gates, separate F1 stage images, and the rule allowing new wiring only on completed modules. Battery stage images now show only the original body and native holder.

Validation: native-reference build passes without warnings/errors. Recipe, migration and wiring sources remain identical to 1.0.113. Published source snapshots are preserved. Actual Unity appearance/interaction/save-load/multiplayer validation remains pending.

# Modular Switchboards 1.0.113 — battery construction, stage icons and completed-module wiring

Battery holder construction now uses 5 DIN module kits for the base, then 1 g Gold to finish. There is no Plastic Sheet requirement. The unfinished gray mounts differ visibly from the completed native holder with gold contact pads. Insert the removable battery cell only after completing the holder. Incomplete holders cannot conduct, charge or discharge. Existing completed holders migrate to the completed stage when loading older saves; new saves retain their construction stage.

New internal cables require completed modules at both endpoints. Incomplete contacts do not show wiring markers; attempting to connect displays a completion message. Existing wires are retained and can still be removed with wire cutters. A previously selected endpoint is rechecked before connecting.

F1 Build States now has separate unfinished/finished images for both transformers and the battery holder. All six new icons use the production geometry exports; transformer images retain the original winding supports and materials.

Validation: native-reference build without warnings/errors, 14 battery save/migration/conduction checks, 22 module wiring readiness checks, and 21,934 production geometry checks passed. The six stage icons were visually inspected. Actual Unity construction/slot/wiring/save-load/multiplayer verification remains pending.

# Modular Switchboards 1.0.112 — original winding supports in unfinished transformers

Based on the accepted 1.0.110 appearance, replacing the rejected 1.0.111 visual change. Unfinished Small and Medium transformers hide only the copper winding while retaining original holders, covers and leads. Small keeps its original WindingBands; Medium retains the exact gray/dark support triangles embedded in the original winding mesh. The original gray fascia is flat and coplanar behind the missing winding, without new holder primitives or a white plate. Completing construction restores the original recessed face and full winding. Kit prices, construction quantities, power gates, save migration and the state -1 startup fix remain unchanged.

Validation: native-reference build without warnings/errors; 17,422 geometry checks and 8 initialization checks pass, with exact support triangle/UV provenance verified. Actual Unity appearance, interaction and multiplayer verification remains pending.

# Modular Switchboards 1.0.110 — transformer prefab initialization fix

Fix the 1.0.109 startup failure: do not invoke native stage visualization on an unplaced transformer prefab at state -1, and do not rebuild its fitted hitbox while the native state has all children inactive. Explicitly restore shared body, terminals and controls in both placed construction stages. Completed-stage winding visibility and the 1.0.109 recipes/counts remain.

# Modular Switchboards 1.0.109 — cabinet economy and transformer construction

Cabinet kit: 60 Iron + 30 Copper, Electronics Printer only. Small uses 1 kit + 2 Plastic Sheets; Medium uses 3 kits + 5 Plastic Sheets, including reverse/collector variants.

DIN rail kit: 5 Iron. One kit per Small or Medium rail. DIN module kit: 5 Iron + 20 Copper. Other kit recipes remain unchanged; all custom kits remain exclusive to the Electronics Printer.

DIN transformers now have two construction stages. Small: 5 module kits for the body, then 3 normal Cable Coil units. Medium: 8 module kits, then 5 normal Cable Coil units. The unfinished body keeps the gray pocket backing without windings. Its terminals can be wired, but it transfers no power until finished. Aim the coil at the body to finish construction; terminal targets retain wiring priority. Native construction handles material consumption and stage dismantling. Existing completed transformers migrate to the completed stage when loading older saves.

Validation: native-reference build succeeds without warnings/errors; 28 save/XML/join-order checks, 12 winding-versus-terminal routing checks, and 4,791 power-engine regression checks pass. Actual Unity stage rendering, construction interaction and multiplayer still need in-game testing.

# Local 1.0.108 — ready, not uploaded

Last published107 commit8688521e121ef4c556852977f47de52219a5a586 tree41dacb5bcce8ddd0bd8ca329481908c54793b087. User authorized auditing all own previews/hitboxes, explicitly including door and Smart and opaque normal-model parts leaking through preview. No upload until nahraj; never Workshop publish.

See Verification/PREVIEW-HITBOX-AUDIT-1.0.108.md for complete family matrix and validation limits. New sources: OwnPreviewPolicy, CursorModelIsolation, FittedModelCollider, FittedControlSelection, FittedKitBounds, OwnPreviewAudit. Native HandleStructurePrefab only destroys registered ThingRenderer entries; unregistered added copper/native parts survived. A Priority.Last postfix now prepares a cursor-only isolation component; cached non-ghost/non-BlueprintHelper-descendant Renderer.forceRenderingOff flags are enforced in LateUpdate. No shared material mutation. Actual world renderers untouched.

Common selection now fits actual Wireframe.BlueprintBounds, transformed/scaled; fallback actual Thing.Bounds when no wireframe. Cabinet accepted box remains; native visibility/validity preserved and all own outlines get native tint. Active constructor or authoring guard preserved. All own structure families including DinTransformer and SmartContactor covered. Precise BoxCollider interaction selection applies to own controls, preserving IDs/pose.

ModelBlueprint.Build optionally filters to nearest owning Thing and includes disabled own renderers for physical-body rebuilds. Defaults keep preview behaviour. Final ModelBlueprint.Refresh installs fitted passive bodies for DinRail/DinBreaker(includingdoor)/SmartModule/SmartContactor; transformer and door constructors have explicit final install. Known passive body boxes are removed from build-state lists/lookup; dedicated controls and board surfaces retained. MeshCollider uses actual snapshot triangles. Serialized hit reference preserves prefab clone mapping. Borrowed initial mesh vs owned runtime rebuild mesh lifetimes separated. DinTransformer.ApplyWidth now tolerates removed bodyBox and uses Rebuild instead of leaking an unretained mesh for bounds. SmartContactor.ApplyWidth and DinRail.ApplySized rebuild fitted bodies. Native Structure.CachePrefabBounds retains its normal code then postfix restores fitted bounds/grid cache. Rebuild excludes mounted Things and includes temporarily disabled own renderers, but respects inactive alternate geometry.

SwitchboardKitModel.InstallBlueprint fits each custom kit Rigidbody's convex box and Bounds to combined geometry; trigger colliders retained in lookup and self/dynamic lists. Native quantities, identity, mass/hand/stack metadata not modified. Installed covers/labels already have shape/cutout-aware mesh colliders. Portable cover payload/visual/12mm carry-envelope code unchanged; dynamic selection fits preview mesh bounds.

Prefab.OnPrefabsLoaded VerifyRegistration calls OwnPreviewAudit.Verify for blueprint mesh/renderer and fitted-body presence diagnostics. Native API Release0warnings/errors. ModelBlueprint154 own-audit +29 general checks; supporting kit38/transformer-layout10006/Output-upgrade11/rail39/doorgeometry9395/doorplacement73/cover100/nativehelpers213/placement1414/casing2367 regressions passed. Stub tests do not prove real Unity/PhysX/Mono/MP/save/load/runtime visual behaviour.107sourceZIP1055entries still byte-match107snapshot. Power, wire protocol, accepted cabinet preview, casing collision, native connection detection, portable cover payload source files verified unchanged.

All modifications atomically replace hardlinked snapshot files. Source artifacts retained. SDK8.0.426 under/tmp/switchboard-dotnet; standardtask DOTNET_CLI_HOME/XDG_DATA_HOME/XDG_CONFIG_HOME/NUGET_PACKAGES. Native references work/build-deps, LibConstructPath needs /LibConstruct/LibConstruct.dll. Packaging work/archive1108.py, manifestwork/release1108-artifacts.json authoritative whencomplete.
