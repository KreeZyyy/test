using UnityEngine;
namespace ModularSwitchboards
{
    internal static class SmartCorePockets
    {
        internal const float DisplayDepth=.004f;
        internal static Mesh Display(Mesh body,Bounds opening,Vector3 scale)
        {
            float front=body.bounds.max.z*scale.z;
            float rear=front-DisplayDepth,top=front+.001f;
            var pocket=new Bounds(new Vector3(opening.center.x/scale.x,opening.center.y/scale.y,(rear+top)*.5f/scale.z),
                new Vector3(opening.size.x/scale.x,opening.size.y/scale.y,(top-rear)/scale.z));
            return SmartSocketPocket.Cut(body,pocket,.003f/scale.x,.003f/scale.y,wallRole:4);
        }
    }
}
