using System.Collections.Generic;
using System.Linq;
using Assets.Scripts.Objects;
using HarmonyLib;
using Rendering;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class SmartCoreConstruction
    {
        internal static void Install(SmartModule owner)
        {
            var body=owner.transform.Find("DinBreakerModel");var display=owner.transform.Find("OriginalDisplayMount");
            var socket=owner.transform.Find("NativeAirChipSocket");var target=owner.transform.Find("ChipInsertionHitbox");
            var location=owner.transform.Find("NativeIC10Location");
            var chipHit=target.GetComponent<Collider>();
            var common=owner.transform.Cast<Transform>().Where(t=>t!=display&&t!=socket&&t!=target&&t.name!="NativeIC10Location").Select(t=>t.gameObject).ToList();
            var hits=owner.BuildStates[0].Colliders.Where(c=>c!=chipHit).ToList();
            var controls=owner.Interactables.Where(i=>i.Action!=InteractableType.Slot1).ToList();
            for(int stage=0;stage<3;stage++)
            {
                var state=owner.BuildStates[stage];
                state.Visualizer=stage==0?body.GetComponent<MeshRenderer>():stage==1?display.GetComponentInChildren<MeshRenderer>(true):socket.GetComponentInChildren<MeshRenderer>(true);
                state.RendererInstance=null;state.StateMeshes=new List<Mesh>();state.RenderMode=BuildStateRenderMode.OnMineAndPreviousStates;
                state.Colliders=new List<Collider>(hits);state.Interactables=stage==2?owner.Interactables:new List<Interactable>(controls);
                state.LinkedGameObjects=new List<GameObject>(common);
                if(stage>=1)state.LinkedGameObjects.Add(display.gameObject);
                if(stage==2){state.LinkedGameObjects.Add(socket.gameObject);state.LinkedGameObjects.Add(target.gameObject);state.LinkedGameObjects.Add(location.gameObject);state.Colliders.Add(chipHit);}
                foreach(var hit in state.Colliders)if(hit!=null&&!state.LinkedGameObjects.Contains(hit.gameObject))state.LinkedGameObjects.Add(hit.gameObject);
                state.Thumbnail=CabinetIcons.Get("DinSmartStage"+stage);
                AccessTools.Field(typeof(BuildState),"initialDrawData").SetValue(state,new DrawData{mesh=null,materials=new Material[0]});
            }
            owner.Thumbnail=CabinetIcons.Get("DinSmartStage2");
            owner.CacheStates(true);
            // Do not visualize state -1 while authoring prefabs.
        }
        internal static void RefreshBody(SmartModule owner)
        {
            var model=owner.transform.Find("DinBreakerModel");if(model==null)return;
            var mesh=owner.CurrentBuildStateIndex==0?owner.UnfinishedCoreBody:owner.CurrentBuildStateIndex==1?owner.DisplayCoreBody:owner.FinishedCoreBody;
            if(mesh!=null)model.GetComponent<MeshFilter>().sharedMesh=mesh;
        }
    }
}
