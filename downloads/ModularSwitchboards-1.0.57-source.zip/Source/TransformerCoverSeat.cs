using System.Collections.Generic;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class TransformerCoverSeat
    {
        internal const float FaceFront=.0736f,CoverOffset=.0105f;
        internal static Mesh Fit(Mesh mesh)
        {
            // Preserve the raised front, warning, bolts and UVs. Only the rear
            // ends of the native side walls meet the shared face exactly.
            float rear=mesh.bounds.min.z,target=FaceFront-CoverOffset;
            var vertices=mesh.vertices;
            for(int i=0;i<vertices.Length;i++)
                if(Mathf.Abs(vertices[i].z-rear)<.000001f)vertices[i].z=target;
            mesh.SetVertices(new List<Vector3>(vertices));mesh.RecalculateNormals();mesh.RecalculateBounds();return mesh;
        }
    }
}
