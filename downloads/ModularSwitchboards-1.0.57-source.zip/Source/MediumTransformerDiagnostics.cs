using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Assets.Scripts;
using Assets.Scripts.Objects.Electrical;
using UnityEngine;
using UnityEngine.Rendering;

namespace ModularSwitchboards
{
    // Capture original data rather than calling the current depth heuristic exact.
    internal static class MediumTransformerDiagnostics
    {
        [Serializable] public sealed class Report
        {
            public string version = SwitchboardsMod.Version;
            public string prefab;
            public string coordinates = "native transformer original local coordinates; metres";
            public float frontSign;
            public List<string> errors=new List<string>();
            public float maximum, stepSmall, stepNormal, needleMinimum, needleMaximum;
            public double setting;
            public string needlePath;
            public List<Node> hierarchy=new List<Node>();
            public List<Control> controls=new List<Control>();
            public string paintMaterial;
            public float diffuseIndex, smoothnessIndex;
            public List<Part> parts = new List<Part>();
            public List<Port> ports = new List<Port>();
            public List<TextureInfo> textures = new List<TextureInfo>();
        }
        [Serializable] public sealed class Node {public string path;public Vector3 position,scale;public Quaternion rotation;public string[] components;}
        [Serializable] public sealed class Control {public string action,path,colliderType;public int state;public bool canKeyInteract;public Vector3 center,size;}
        [Serializable] public sealed class Part
        {
            public string path, mesh;
            public Vector3[] vertices;
            public Vector2[] uv;
            public List<Surface> surfaces = new List<Surface>();
            public List<Property> globalBlock = new List<Property>();
            public bool globalBlockEmpty;
        }
        [Serializable] public sealed class Surface
        {
            public int submesh;
            public int[] triangles;
            public Vector3 min, max;
            public string material, shader;
            public bool paintable, blockEmpty;
            public List<Property> properties = new List<Property>();
        }
        [Serializable] public sealed class Property
        {
            public string name, type, texture, blockTexture;
            public bool blockHasProperty;
            public float value, blockFloat;
            public Color color, blockColor;
            public Vector4 vector, blockVector;
        }
        [Serializable] public sealed class Port
        {
            public string role;
            public Vector3 position;
            public Vector3 colliderMin, colliderMax;
        }
        [Serializable] public sealed class TextureInfo
        {
            public string name, file, error;
            public int width, height;
        }
        private static bool captured;

        internal static void Capture()
        {
            if (captured) return;

            try
            {
                var native=WorldManager.Instance.SourcePrefabs.OfType<Transformer>().Where(t=>t.PrefabName!=null&&t.PrefabName=="StructureTransformerMedium").OrderBy(t=>t.OutputMaximum).ToArray();
                if(native.Length==0)throw new InvalidOperationException("Native transformer prefabs unavailable");
                var directory=Path.Combine(Application.persistentDataPath,"ModularSwitchboards-Transformer-Medium-reference");
                if(File.Exists(Path.Combine(Application.persistentDataPath,"ModularSwitchboards-Transformer-Medium-reference.zip"))){captured=true;return;}
                Directory.CreateDirectory(directory);
                foreach(var apc in native)CaptureOne(apc,Path.Combine(directory,apc.PrefabName));
                string zip=Path.Combine(Application.persistentDataPath,"ModularSwitchboards-Transformer-Medium-reference.zip");
                if(File.Exists(zip))File.Delete(zip);
                System.IO.Compression.ZipFile.CreateFromDirectory(directory,zip);
                captured=true;
                Debug.Log("[Modular Switchboards] TRANSFORMER DIAG upload this file: "+zip);
            }
            catch(Exception ex){Debug.LogError("[Modular Switchboards] TRANSFORMER DIAG failed: "+ex);}
        }
        private static void CaptureOne(Transformer apc,string directory)
        {
                Directory.CreateDirectory(directory);
                var frame = apc.transform.worldToLocalMatrix;
                var report = new Report { prefab=apc.PrefabName, frontSign=1f,
                    paintMaterial=apc.PaintableMaterial == null ? "" : apc.PaintableMaterial.name };
                report.maximum=apc.OutputMaximum;report.setting=apc.Setting;report.stepSmall=apc.StepSmall;report.stepNormal=apc.StepNormal;report.needleMinimum=apc.NeedleMinimum;report.needleMaximum=apc.NeedleMaximum;report.needlePath=apc.Needle==null?null:PathOf(apc.Needle.transform,apc.transform);
                foreach(var t in apc.GetComponentsInChildren<Transform>(true))report.hierarchy.Add(new Node{path=PathOf(t,apc.transform),position=t.localPosition,rotation=t.localRotation,scale=t.localScale,components=t.GetComponents<Component>().Where(c=>c!=null).Select(c=>c.GetType().FullName).ToArray()});
                if(apc.Interactables!=null)foreach(var c in apc.Interactables){var entry=new Control{action=c.Action.ToString(),state=c.State,canKeyInteract=c.CanKeyInteract,path=c.Collider==null?null:PathOf(c.Collider.transform,apc.transform),colliderType=c.Collider?.GetType().Name};if(c.Collider is BoxCollider box){entry.center=box.center;entry.size=box.size;}report.controls.Add(entry);}
                report.smoothnessIndex = apc.SmoothnessIndex;
                report.diffuseIndex = apc.CustomColor == null ? -1 : apc.CustomColor.Index;
                foreach (var renderer in apc.GetComponentsInChildren<MeshRenderer>(true))
                {
                    var mesh = renderer.GetComponent<MeshFilter>()?.sharedMesh;
                    if (mesh == null) continue;
                    try
                    {
                        CabinetGeometry.ReadNativeMesh(mesh,out var vertices,out var uv,out var groups);
                        var matrix = frame * renderer.transform.localToWorldMatrix;
                        for(int i=0;i<vertices.Length;i++) vertices[i]=matrix.MultiplyPoint3x4(vertices[i]);
                        var part = new Part {path=PathOf(renderer.transform,apc.transform),mesh=mesh.name,vertices=vertices,uv=uv};
                        var global = new MaterialPropertyBlock(); renderer.GetPropertyBlock(global);
                        part.globalBlockEmpty=global.isEmpty;
                        var mats=renderer.sharedMaterials;
                        for(int i=0;i<groups.Length;i++)
                        {
                            var mat=i<mats.Length?mats[i]:null;
                            var block=new MaterialPropertyBlock();renderer.GetPropertyBlock(block,i);
                            var surface=new Surface {submesh=i,triangles=groups[i],material=mat==null?"":mat.name,
                                shader=mat==null||mat.shader==null?"":mat.shader.name,paintable=mat==apc.PaintableMaterial,blockEmpty=block.isEmpty};
                            if(groups[i].Length>0)
                            {
                                var bounds=new Bounds(vertices[groups[i][0]],Vector3.zero);
                                foreach(int index in groups[i]) bounds.Encapsulate(vertices[index]);
                                surface.min=bounds.min;surface.max=bounds.max;
                            }
                            if(mat!=null && mat.shader!=null)
                            {
                                surface.properties=Properties(mat,block);
                                if(i==0) part.globalBlock=Properties(mat,global);
                            }
                            part.surfaces.Add(surface);
                            Debug.Log("[Modular Switchboards] TRANSFORMER DIAG: "+part.path+" sub="+i+" material="+surface.material+
                                " paintable="+surface.paintable+" min="+surface.min.ToString("F6")+" max="+surface.max.ToString("F6"));
                        }
                        report.parts.Add(part);
                    }
                    catch(Exception ex) { report.errors.Add(renderer.name+": "+ex.Message);Debug.LogWarning("[Modular Switchboards] TRANSFORMER DIAG mesh unavailable: "+renderer.name+": "+ex.Message); }
                }
                if(apc.OpenEnds!=null) foreach(var port in apc.OpenEnds)
                {
                    if(port?.Transform==null)continue;
                    var entry=new Port {role=port.ConnectionRole.ToString(),position=frame.MultiplyPoint3x4(port.Transform.position)};
                    if(port.Collider is BoxCollider box)
                    {
                        var bounds=CabinetWallMount.TransformedBounds(new Bounds(box.center,box.size),frame*box.transform.localToWorldMatrix);
                        entry.colliderMin=bounds.min;entry.colliderMax=bounds.max;
                    }
                    report.ports.Add(entry);
                }
                if(apc.BuildStates!=null)foreach(var state in apc.BuildStates){var draw=state.InitialDrawData;if(!draw.IsValid())continue;CabinetGeometry.ReadNativeMesh(draw.mesh,out var v,out var uv,out var groups);var m=frame*(state.Visualizer==null?apc.transform:state.Visualizer.transform).localToWorldMatrix;for(int i=0;i<v.Length;i++)v[i]=m.MultiplyPoint3x4(v[i]);var part=new Part{path="BuildState/"+report.parts.Count,mesh=draw.mesh.name,vertices=v,uv=uv};for(int i=0;i<groups.Length;i++)part.surfaces.Add(new Surface{submesh=i,triangles=groups[i],material=i<draw.materials.Length&&draw.materials[i]!=null?draw.materials[i].name:"",properties=i<draw.materials.Length&&draw.materials[i]!=null&&draw.materials[i].shader!=null?Properties(draw.materials[i],new MaterialPropertyBlock()):new List<Property>()});report.parts.Add(part);}
                if(report.parts.Count==0)throw new InvalidOperationException("No native transformer meshes captured");

                var seen=new HashSet<int>();
                foreach(var material in apc.GetComponentsInChildren<MeshRenderer>(true).SelectMany(r=>r.sharedMaterials).Concat(apc.BuildStates.Where(b=>b.InitialDrawData.IsValid()).SelectMany(b=>b.InitialDrawData.materials)).Where(m=>m!=null).Distinct())
                    foreach(var property in material.GetTexturePropertyNames())
                    {
                        var texture=material.GetTexture(property);
                        if(texture==null || !seen.Add(texture.GetInstanceID()))continue;
                        report.textures.Add(ExportTexture(texture,directory,report.textures.Count));
                    }
                string path=System.IO.Path.Combine(directory,"ModularSwitchboards-Transformer-Medium-reference.json");
                string json=DiagnosticJson.Serialize(report);
                if(json.IndexOf("\"vertices\":[",StringComparison.Ordinal)<0 || json.IndexOf("\"surfaces\":[",StringComparison.Ordinal)<0)
                    throw new InvalidOperationException("Diagnostic export omitted geometry; file not written");
                File.WriteAllText(path,json);
        }

        private static TextureInfo ExportTexture(Texture texture,string directory,int index)
        {
            var result=new TextureInfo{name=texture.name,width=texture.width,height=texture.height};
            RenderTexture temporary=null;Texture2D readable=null;var previous=RenderTexture.active;
            try
            {
                if(!(texture is Texture2D))throw new InvalidOperationException("Only 2D diffuse textures exported; material reference is retained");
                if(texture.width>8192 || texture.height>8192)throw new InvalidOperationException("Texture exceeds diagnostic readback limit");
                temporary=RenderTexture.GetTemporary(texture.width,texture.height,0,RenderTextureFormat.ARGB32,RenderTextureReadWrite.sRGB);
                Graphics.Blit(texture,temporary);RenderTexture.active=temporary;
                readable=new Texture2D(texture.width,texture.height,TextureFormat.RGBA32,false);
                readable.ReadPixels(new Rect(0,0,texture.width,texture.height),0,0);readable.Apply();
                result.file="diffuse-"+index+".png";
                File.WriteAllBytes(System.IO.Path.Combine(directory,result.file),readable.EncodeToPNG());
            }
            catch(Exception ex){result.error=ex.Message;result.file=null;}
            finally
            {
                RenderTexture.active=previous;
                if(temporary!=null)RenderTexture.ReleaseTemporary(temporary);
                if(readable!=null)UnityEngine.Object.Destroy(readable);
            }
            return result;
        }

        private static string PathOf(Transform current,Transform root)
        {
            var names=new List<string>();
            while(current!=null){names.Add(current.name);if(current==root)break;current=current.parent;}
            names.Reverse();return string.Join("/",names.ToArray());
        }

        private static List<Property> Properties(Material mat,MaterialPropertyBlock block)
        {
            var result=new List<Property>();
            for(int i=0;i<mat.shader.GetPropertyCount();i++)
            {
                string name=mat.shader.GetPropertyName(i);int id=Shader.PropertyToID(name);
                var type=mat.shader.GetPropertyType(i);var prop=new Property{name=name,type=type.ToString(),blockHasProperty=block.HasProperty(id)};
                if(type==ShaderPropertyType.Color){prop.color=mat.GetColor(id);prop.blockColor=block.GetColor(id);}
                else if(type==ShaderPropertyType.Vector){prop.vector=mat.GetVector(id);prop.blockVector=block.GetVector(id);}
                else if(type==ShaderPropertyType.Texture){var texture=mat.GetTexture(id);prop.texture=texture==null?"":texture.name;var overrideTexture=block.GetTexture(id);prop.blockTexture=overrideTexture==null?"":overrideTexture.name;}
                else if(type==ShaderPropertyType.Float || type==ShaderPropertyType.Range){prop.value=mat.GetFloat(id);prop.blockFloat=block.GetFloat(id);}
                result.Add(prop);
            }
            // Block values of zero alone do not establish that a property is overridden.
            // Preserve block emptiness and both scopes so analysis can distinguish them.
            return result;
        }
    }
}
