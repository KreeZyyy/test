using System.Collections.Generic;
using Assets.Scripts.Objects;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class MediumGeometry
    {
        internal static Mesh Stretch(Mesh source,float x,float y,bool mirror=false)
        {
            var mesh=UnityEngine.Object.Instantiate(source);mesh.name="Medium."+source.name;
            var vertices=mesh.vertices;
            for(int i=0;i<vertices.Length;i++)vertices[i]=new Vector3(vertices[i].x*x*(mirror?-1:1),vertices[i].y*y,vertices[i].z);
            mesh.vertices=vertices;
            if(mirror)for(int s=0;s<mesh.subMeshCount;s++){var t=mesh.GetTriangles(s);for(int i=0;i<t.Length;i+=3){int n=t[i+1];t[i+1]=t[i+2];t[i+2]=n;}mesh.SetTriangles(t,s);}
            mesh.RecalculateNormals();mesh.RecalculateTangents();mesh.RecalculateBounds();return mesh;
        }
        internal static void Install(SwitchboardCabinet host)
        {
            var model=host.transform.Find("SwitchboardModel");model.localPosition+=Vector3.up*.25f;
            var shell=model.Find("CompletedShell");
            foreach(var name in new[]{"Frame","CompletedShell/Housing","CompletedShell/Interior","CompletedShell/DoorReturnLip"})
            {
                var t=model.Find(name);if(t==null)continue;var filter=t.GetComponent<MeshFilter>();if(filter!=null)filter.sharedMesh=Stretch(filter.sharedMesh,2,2);
            }
            foreach(var collider in model.GetComponentsInChildren<BoxCollider>(true))
            {
                if(collider.transform.IsChildOf(shell.Find("DoorHinge")))continue;
                collider.center=new Vector3(collider.center.x*2,collider.center.y*2,collider.center.z);
                collider.size=new Vector3(collider.size.x*2,collider.size.y*2,collider.size.z);
            }
            shell.Find("RoundedHousingCollider").GetComponent<MeshCollider>().sharedMesh=shell.Find("Housing").GetComponent<MeshFilter>().sharedMesh;
            var left=shell.Find("DoorHinge");left.localPosition=new Vector3(-.4f,0,.187f);
            var door=left.Find("Door").GetComponent<MeshFilter>();door.sharedMesh=Stretch(door.sharedMesh,1,2);
            left.Find("DoorCollider").GetComponent<MeshCollider>().sharedMesh=door.sharedMesh;
            foreach(Transform t in left)if(t.name!="Door"&&t.name!="DoorCollider")
            {var v=t.localPosition;t.localPosition=new Vector3(v.x,v.y*2,v.z);if(t.name=="DoorHandleInteraction"){var handleBox=t.GetComponent<BoxCollider>();handleBox.size=new Vector3(handleBox.size.x,handleBox.size.y*2,handleBox.size.z);}}
            var right=new GameObject("RightDoorHinge"){layer=host.gameObject.layer};right.transform.SetParent(shell,false);right.transform.localPosition=new Vector3(.4f,0,.187f);
            foreach(var name in new[]{"Door","DoorCollider"})
            {
                var t=new GameObject(name){layer=host.gameObject.layer};t.transform.SetParent(right.transform,false);
                if(name=="Door"){t.AddComponent<MeshFilter>().sharedMesh=Stretch(CabinetGeometry.Meshes[3],1,2,true);t.AddComponent<MeshRenderer>().sharedMaterials=left.Find("Door").GetComponent<MeshRenderer>().sharedMaterials;}
                else{var c=t.AddComponent<MeshCollider>();c.sharedMesh=right.transform.Find("Door").GetComponent<MeshFilter>().sharedMesh;host.BuildStates[1].Colliders.Add(c);}
            }
            // Native Open state operates both leaves; the handles remain at their centre seam.
            var handle=new GameObject("DoorHandleInteraction"){layer=host.gameObject.layer};handle.transform.SetParent(right.transform,false);handle.transform.localPosition=new Vector3(-.37f,-.12f,.026f);
            var hit=handle.AddComponent<BoxCollider>();hit.size=new Vector3(.025f,.146f,.036f);host.BuildStates[1].Colliders.Add(hit);
            var other=new Interactable{Parent=host,Action=InteractableType.Open,Collider=hit,CanKeyInteract=true,JoinInProgressSync=true,KeyMap="PrimaryAction"};host.Interactables.Add(other);host.BuildStates[1].Interactables.Add(other);
            host.GetComponent<CabinetDoor>().RightHinge=right.transform;
            // Both frame previews use the new frame, with its correct wall offset.
            var ghost=Stretch(CabinetGeometry.Meshes[0],2,2);var points=ghost.vertices;
            for(int i=0;i<points.Length;i++)points[i]=model.localPosition+model.localRotation*points[i];ghost.vertices=points;ghost.RecalculateBounds();
            host.Blueprint.GetComponent<MeshFilter>().sharedMesh=ghost;var wire=host.Blueprint.GetComponent<Assets.Scripts.UI.Wireframe>();wire.BlueprintBounds=ghost.bounds;
        }
    }
}
