using System;
using System.Collections.Generic;
using Assets.Scripts.Objects;
using UnityEngine;

namespace ModularSwitchboards
{
    public sealed class OvenInputSupportState : MonoBehaviour
    {
        [NonSerialized] public Mesh InstanceMesh;
        private void OnDestroy(){if(InstanceMesh!=null)UnityEngine.Object.Destroy(InstanceMesh);}
    }

    // Model-only transition from the middle warning box to the top IN face.
    internal static class OvenInputSupport
    {
        internal const string RootName="OvenInputSupport";
        internal static void Install(SwitchboardCabinet cabinet)
        {
            var shell=cabinet.transform.Find("SwitchboardModel/CompletedShell");
            if(shell==null || shell.Find(OvenInputPanel.RootName)==null)return;
            var root=new GameObject(RootName){layer=cabinet.gameObject.layer};root.transform.SetParent(shell,false);
            root.AddComponent<MeshFilter>();root.AddComponent<OvenInputSupportState>();
            root.AddComponent<MeshRenderer>().sharedMaterials=CabinetGeometry.Materials;
            root.AddComponent<MeshCollider>();
            Fit(cabinet);CabinetRearSurface.Restore(root.GetComponent<MeshRenderer>());
            cabinet.BuildStates[1].Colliders.Add(root.GetComponent<MeshCollider>());
            CabinetModel.SetBounds(cabinet);
        }

        internal static void Fit(Structure cabinet)
        {
            var shell=cabinet.transform.Find("SwitchboardModel/CompletedShell");
            if(shell==null)return;
            var support=shell.Find(RootName);var panel=shell.Find(OvenInputPanel.RootName);var box=shell.Find("NativeApcRearBox");
            if(support==null||panel==null||box==null)return;
            var panelMesh=panel.GetComponent<MeshFilter>()?.sharedMesh;var boxMesh=box.GetComponent<MeshFilter>()?.sharedMesh;
            if(panelMesh==null||boxMesh==null)return;
            var top=CabinetWallMount.TransformedBounds(panelMesh.bounds,shell.worldToLocalMatrix*panel.localToWorldMatrix);
            var bottom=CabinetWallMount.TransformedBounds(boxMesh.bounds,shell.worldToLocalMatrix*box.localToWorldMatrix);
            float low=bottom.max.y-.0055f,high=panel.localPosition.y-.0005f;
            if(high<=low)return;
            var vertices=new List<Vector3>();var indices=new List<int>();
            const int cornerSteps=6,edgeSteps=4;
            const int ringSize=4*(cornerSteps+1);
            float edge=Mathf.Min(.002f,(high-low)*.2f);
            // Quarter-circle edge rolls, plus 4 mm vertical corner radii.
            for(int band=0;band<2;band++)
                for(int step=0;step<=edgeSteps;step++)
                {
                    float angle=step*Mathf.PI*.5f/edgeSteps;
                    float y=band==0?low+edge*(1f-Mathf.Cos(angle)):high-edge+edge*Mathf.Sin(angle);
                    float inset=band==0?edge*(1f-Mathf.Sin(angle)):edge*(1f-Mathf.Cos(angle));
                    float t=(y-low)/(high-low);
                    float half=top.size.x*.5f;
                    float xmin=Mathf.Lerp(-half,top.min.x,t)+inset,xmax=Mathf.Lerp(half,top.max.x,t)-inset;
                    float zmin=Mathf.Lerp(bottom.min.z,top.min.z,t)+inset,zmax=Mathf.Lerp(bottom.max.z,top.max.z,t)-inset;
                    float radius=Mathf.Min(.004f-inset,Mathf.Min(xmax-xmin,zmax-zmin)*.25f);
                    for(int corner=0;corner<4;corner++)
                    {
                        float cx=(corner==0||corner==3)?xmax-radius:xmin+radius;
                        float cz=corner<2?zmax-radius:zmin+radius;
                        for(int part=0;part<=cornerSteps;part++)
                        {
                            float theta=(corner*90f+part*90f/cornerSteps)*Mathf.Deg2Rad;
                            vertices.Add(new Vector3(cx+radius*Mathf.Cos(theta),y,cz+radius*Mathf.Sin(theta)));
                        }
                    }
                }
            int rings=2*(edgeSteps+1);
            for(int ring=0;ring<rings-1;ring++)
                for(int i=0;i<ringSize;i++)
                {
                    int a=ring*ringSize+i,b=ring*ringSize+(i+1)%ringSize,c=b+ringSize,d=a+ringSize;
                    indices.AddRange(new[]{a,b,c,a,c,d});
                }
            int cap=vertices.Count;vertices.Add(new Vector3(0,low,bottom.center.z));
            for(int i=0;i<ringSize;i++)indices.AddRange(new[]{cap,(i+1)%ringSize,i});
            // Leave the top open: the original panel and recessed socket cover it.
            var center=new Vector3(top.center.x*.5f,(low+high)*.5f,(bottom.center.z+top.center.z)*.5f);
            for(int i=0;i<indices.Count;i+=3)
            {
                var a=vertices[indices[i]];var b=vertices[indices[i+1]];var c=vertices[indices[i+2]];
                if(Vector3.Dot(Vector3.Cross(b-a,c-a),(a+b+c)/3f-center)<0f){int temp=indices[i+1];indices[i+1]=indices[i+2];indices[i+2]=temp;}
            }
            var state=support.GetComponent<OvenInputSupportState>();
            if(state.InstanceMesh==null)state.InstanceMesh=new Mesh{name="Switchboards.InputTransition"};
            var mesh=state.InstanceMesh;support.GetComponent<MeshFilter>().sharedMesh=mesh;mesh.Clear();mesh.SetVertices(vertices);mesh.subMeshCount=5;
            for(int i=0;i<5;i++)mesh.SetTriangles(i==CabinetRearSurface.Role?indices.ToArray():new int[0],i);
            mesh.RecalculateNormals();CabinetGeometry.ApplyNativeUv(mesh);CabinetRearSurface.ApplyUv(mesh);mesh.RecalculateBounds();
            var collider=support.GetComponent<MeshCollider>();collider.sharedMesh=null;collider.sharedMesh=mesh;
        }

        internal static void IncludeBounds(Structure cabinet,ref Bounds bounds)
        {
            var root=cabinet.transform.Find("SwitchboardModel/CompletedShell/"+RootName);
            var mesh=root==null?null:root.GetComponent<MeshFilter>()?.sharedMesh;
            if(mesh!=null)bounds.Encapsulate(CabinetWallMount.TransformedBounds(mesh.bounds,cabinet.transform.worldToLocalMatrix*root.localToWorldMatrix));
        }
    }
}
