using System;using System.Collections.Generic;using ModularSwitchboards;using UnityEngine;
namespace UnityEngine{
 public struct Color32{public byte r,g,b,a;public Color32(byte r,byte g,byte b,byte a){this.r=r;this.g=g;this.b=b;this.a=a;}}
 public enum TextureFormat{RGBA32}public struct Rect{public Rect(int a,int b,int c,int d){}}public struct Vector2{public Vector2(float a,float b){}}
 public class Texture2D{public string name;public int width,height;public Color32[] Pixels;public bool Sealed;public static int Created;public Texture2D(int w,int h,TextureFormat f,bool mip){width=w;height=h;Created++;}public Color32[] GetPixels32()=>(Color32[])Pixels.Clone();public void SetPixels32(Color32[] p){Pixels=p;}public void Apply(bool a,bool b){Sealed=b;}}
 public class Sprite{public string name;public Texture2D texture;public static Sprite Create(Texture2D t,Rect r,Vector2 v,float p)=>new(){texture=t};}
}
namespace Assets.Scripts{public static class GameManager{public class Swatch{public Color32 Color;}public static Dictionary<int,Swatch> Swatches=new();public static bool IsValidColor(int i)=>Swatches.ContainsKey(i);public static Swatch GetColorSwatch(int i)=>Swatches[i];}}
namespace ModularSwitchboards{public static class CabinetIcons{public static Sprite Source;public static Sprite Get(string name)=>Source;}}
class P{static int n;static void Check(bool ok,string msg){n++;if(!ok)throw new Exception(msg);}static void Main(){
var pixels=new[]{new Color32(255,255,255,255),new Color32(128,64,32,200),new Color32(200,200,200,0)};var source=new Texture2D(3,1,TextureFormat.RGBA32,false){Pixels=pixels};CabinetIcons.Source=new(){texture=source};
foreach(int colour in new[]{1,2,3}){var tint=colour==1?new Color32(255,255,255,255):colour==2?new Color32(200,120,20,255):new Color32(30,70,160,255);Assets.Scripts.GameManager.Swatches[colour]=new(){Color=tint};var icon=FittedCoverIcons.Get(colour);for(int i=0;i<pixels.Length;i++){var p=icon.texture.Pixels[i];Check(p.r==pixels[i].r*tint.r/255&&p.g==pixels[i].g*tint.g/255&&p.b==pixels[i].b*tint.b/255,"Icon tint differs from saved colour");Check(p.a==pixels[i].a,"Transparency lost");}int count=Texture2D.Created;Check(ReferenceEquals(icon,FittedCoverIcons.Get(colour))&&count==Texture2D.Created,"Icon regenerated every frame");Check(icon.texture.Sealed,"Tinted icon retained unnecessary CPU pixel buffer");}
Check(ReferenceEquals(FittedCoverIcons.Get(99),CabinetIcons.Source),"Unknown saved palette did not fall back safely");
Check(source.Pixels[0].r==255&&source.Pixels[1].g==64&&!source.Sealed,"Shared source icon changed");Console.WriteLine(n+" production fitted-cover icon checks passed: saved hue, white/grain shading, alpha, shared cache and immutable source.");}}
