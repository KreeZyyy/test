using UnityEngine;namespace ModularSwitchboards{static class DinTransformerModel{        internal static void UpdatePorts(DinTransformer owner)
        {
            float center=TransformerPanelLayout.PortCenterX(owner.ModuleWidth)/DinBreakerModel.VisualScale.x;
            owner.InternalInput=Vector3.Scale(new Vector3(center,WireContactLayout.BreakerEntryY,WireContactLayout.BreakerEntryZ),DinBreakerModel.VisualScale);
            owner.InternalOutput=Vector3.Scale(new Vector3(center,-WireContactLayout.BreakerEntryY,WireContactLayout.BreakerEntryZ),DinBreakerModel.VisualScale);
            owner.InternalInputAim=Vector3.Scale(new Vector3(center,WireContactLayout.BreakerScrewY,WireContactLayout.BreakerScrewZ),DinBreakerModel.VisualScale);
            owner.InternalOutputAim=Vector3.Scale(new Vector3(center,-WireContactLayout.BreakerScrewY,WireContactLayout.BreakerScrewZ),DinBreakerModel.VisualScale);
        }
}}