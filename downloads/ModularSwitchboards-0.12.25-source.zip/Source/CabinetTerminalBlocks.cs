using System;
using System.Collections.Generic;
using System.Linq;
using Assets.Scripts.Objects;
using UnityEngine;

namespace ModularSwitchboards
{
    public enum CabinetTerminalId { Input, Output1, Output2 }

    // Fixed cabinet interfaces; front contacts are reserved for the custom wire system.
    public sealed class CabinetTerminalBlock : MonoBehaviour
    {
        public SwitchboardCabinet Owner;
        public CabinetTerminalId TerminalId;
        public ConnectionRole ExternalRole;
        public Vector3[] FrontContacts,RearContacts;
        public TextMesh Label;
        public Connection ExternalConnection => Owner?.OpenEnds?.FirstOrDefault(c=>c.ConnectionRole==ExternalRole);
        public Vector3 FrontContactWorld(int index)=>transform.TransformPoint(FrontContacts[index]);
        private void LateUpdate()
        {
            if(Label==null || Owner==null)return;
            var renderer=Label.GetComponent<MeshRenderer>();
            var size=renderer.localBounds.size;
            Label.transform.localScale=Vector3.one*Mathf.Min(.060f/Mathf.Max(.0001f,size.x),.012f/Mathf.Max(.0001f,size.y));
            var camera=Camera.main;
            renderer.enabled=!Owner.IsCursor && Owner.IsStructureCompleted &&
                (camera==null || Vector3.Dot(transform.forward,camera.transform.position-transform.position)>0f);
        }
    }

    internal static class CabinetTerminalBlocks
    {
        internal const string RootName="CabinetTerminalBlocks";
        private static Mesh body,redTail,labelBorder,labelPlate;
        internal static readonly Vector3[] Centers={new Vector3(0,.211f,.014f),new Vector3(.108f,-.211f,.014f),new Vector3(-.108f,-.211f,.014f)};
        internal static readonly string[] Labels={"Input","Output 1","Output 2"};
        private static readonly ConnectionRole[] Roles={ConnectionRole.Input,ConnectionRole.Output,ConnectionRole.Output2};

        internal static void Install(SwitchboardCabinet cabinet)
        {
            if(body==null)
            {
                body=BuildBody();redTail=BuildTail(0);
                var border=new Geometry();border.Box(Vector3.zero,new Vector3(.068f,.022f,.0015f),.001f,3);labelBorder=border.Finish("Switchboards.TerminalLabelBorder");
                var plate=new Geometry();plate.Box(new Vector3(0,0,.001f),new Vector3(.065f,.019f,.001f),.0007f,1);labelPlate=plate.Finish("Switchboards.TerminalLabelPlate");
            }
            Font font=null;
            foreach(var name in new[]{"LegacyRuntime.ttf","Arial.ttf"})
            {try{font=Resources.GetBuiltinResource<Font>(name);}catch(Exception){}if(font!=null)break;}
            if(font==null)font=Resources.FindObjectsOfTypeAll<Font>().FirstOrDefault();
            if(font==null)Debug.LogWarning("[Modular Switchboards] Terminal font unavailable; terminal geometry retained without labels.");
            var shell=cabinet.transform.Find("SwitchboardModel/CompletedShell");
            var parent=new GameObject(RootName){layer=cabinet.gameObject.layer};parent.transform.SetParent(shell,false);
            for(int i=0;i<3;i++)
            {
                var root=new GameObject(Labels[i]){layer=cabinet.gameObject.layer};root.transform.SetParent(parent.transform,false);root.transform.localPosition=Centers[i];
                if(i==0)root.transform.localRotation=Quaternion.Euler(0,0,180f);
                var block=root.AddComponent<CabinetTerminalBlock>();block.Owner=cabinet;block.TerminalId=(CabinetTerminalId)i;block.ExternalRole=Roles[i];
                block.FrontContacts=new[]{new Vector3(0,-.006f,.032f)};
                block.RearContacts=new[]{new Vector3(0,-.026f,-.006f)};
                Surface(root.transform,"TerminalInsulator",body);
                Surface(root.transform,"TerminalWireRed",redTail);
                var hit=root.AddComponent<BoxCollider>();hit.center=new Vector3(0,0,.016f);hit.size=new Vector3(.072f,.032f,.032f);
                cabinet.BuildStates[1].Colliders.Add(hit);
                // Labels have their own unrotated frame, independent of the top terminal turn.
                var labelFrame=new GameObject("TerminalLabelFrame"){layer=cabinet.gameObject.layer};labelFrame.transform.SetParent(parent.transform,false);
                labelFrame.transform.localPosition=Centers[i]+(i==0?new Vector3(.078f,0,.018f):new Vector3(0,.031f,.018f));
                Surface(labelFrame.transform,"TerminalLabelBorder",labelBorder);
                Surface(labelFrame.transform,"TerminalLabelPlate",labelPlate);
                if(font!=null)
                {
                    var label=new GameObject("TerminalLabelText"){layer=cabinet.gameObject.layer};label.transform.SetParent(labelFrame.transform,false);
                    label.transform.localPosition=new Vector3(0,0,.002f);label.transform.localRotation=Quaternion.Euler(0,180f,0);
                    var text=label.AddComponent<TextMesh>();text.font=font;text.fontSize=128;text.fontStyle=FontStyle.Bold;text.characterSize=.012f;
                    text.anchor=TextAnchor.MiddleCenter;text.alignment=TextAlignment.Center;text.richText=false;text.color=Color.black;text.text=Labels[i];
                    label.GetComponent<MeshRenderer>().sharedMaterial=font.material;block.Label=text;
                }
            }
            Debug.Log("[Modular Switchboards] Fixed terminal blocks installed: Input top, Output 1 lower left, Output 2 lower right. Rear cable tails are visual; front contacts reserved for custom wiring. Output networks are not registered yet.");
        }

        private static void Surface(Transform parent,string name,Mesh mesh)
        {
            var go=new GameObject(name){layer=parent.gameObject.layer};go.transform.SetParent(parent,false);
            go.AddComponent<MeshFilter>().sharedMesh=mesh;var renderer=go.AddComponent<MeshRenderer>();renderer.sharedMaterials=CabinetGeometry.Materials;
            RestoreWireColor(renderer);
        }
        internal static bool RestoreWireColor(MeshRenderer renderer)
        {
            bool wire=renderer.name=="TerminalWireRed",plate=renderer.name=="TerminalLabelPlate";
            if(!wire&&!plate)return false;
            int role=wire?3:1;
            var block=new MaterialPropertyBlock();renderer.GetPropertyBlock(block,role);
            block.SetFloat(Thing.DiffuseIndexPropertyID,(int)(wire?Assets.Scripts.Objects.Motherboards.ColorType.Red:Assets.Scripts.Objects.Motherboards.ColorType.White));
            block.SetColor(Thing.EMISSION_COLOR,Color.black);renderer.SetPropertyBlock(block,role);return true;
        }
        private sealed class Geometry
        {
            internal readonly List<Vector3> Vertices=new List<Vector3>(),Normals=new List<Vector3>();
            internal readonly List<int>[] Triangles=Enumerable.Range(0,5).Select(_=>new List<int>()).ToArray();
            internal void Box(Vector3 center,Vector3 size,float radius,int role)=>RoundedGeometry.Box(Vertices,Normals,Triangles[role],center,size,radius);
            internal void Quad(Vector3 a,Vector3 b,Vector3 c,Vector3 d,Vector3 normal,int role)
            {
                int start=Vertices.Count;Vertices.AddRange(new[]{a,b,c,d});Normals.AddRange(new[]{normal,normal,normal,normal});Triangles[role].AddRange(new[]{start,start+1,start+2,start,start+2,start+3});
            }
            internal Mesh Finish(string name)
            {
                var mesh=new Mesh{name=name};mesh.SetVertices(Vertices);mesh.SetNormals(Normals);mesh.subMeshCount=5;
                for(int i=0;i<5;i++)mesh.SetTriangles(Triangles[i],i);CabinetGeometry.ApplyNativeUv(mesh);mesh.RecalculateBounds();return mesh;
            }
        }
        private static Mesh BuildBody()
        {
            var g=new Geometry();
            g.Box(new Vector3(0,0,.005f),new Vector3(.072f,.032f,.010f),.002f,3);
            foreach(float x in new[]{0f})
            {
                g.Box(new Vector3(x,0,.019f),new Vector3(.031f,.030f,.026f),.002f,1);
                // Front screw head and driver slot; separate recessed wire entry below it.
                Disk(g,new Vector3(x,.007f,.0323f),.0045f,4);
                g.Box(new Vector3(x,.007f,.0326f),new Vector3(.006f,.001f,.0005f),.0001f,3);
                Disk(g,new Vector3(x,-.006f,.0321f),.0048f,4);
                Disk(g,new Vector3(x,-.006f,.0323f),.0031f,3);
            }
            return g.Finish("Switchboards.SingleTerminal");
        }
        private static void Disk(Geometry g,Vector3 center,float radius,int role)
        {
            for(int i=0;i<16;i++)
            {
                float a=i*Mathf.PI/8,b=(i+1)*Mathf.PI/8;
                var p=center+new Vector3(Mathf.Cos(a)*radius,Mathf.Sin(a)*radius,0);
                var q=center+new Vector3(Mathf.Cos(b)*radius,Mathf.Sin(b)*radius,0);
                int start=g.Vertices.Count;g.Vertices.AddRange(new[]{center,p,q});g.Normals.AddRange(new[]{Vector3.forward,Vector3.forward,Vector3.forward});g.Triangles[role].AddRange(new[]{start,start+1,start+2});
            }
        }
        private static Mesh BuildTail(float x)
        {
            var g=new Geometry();
            // Fixed insulated conductor disappears through the mounting plate.
            var path=new[]{new Vector3(x,-.010f,.014f),new Vector3(x,-.018f,.014f),new Vector3(x,-.023f,.011f),new Vector3(x,-.026f,.005f),new Vector3(x,-.026f,-.006f)};
            var ring=new Vector3[path.Length,12];
            for(int point=0;point<path.Length;point++)
            {
                var tangent=(path[Math.Min(point+1,path.Length-1)]-path[Math.Max(0,point-1)]).normalized;
                var v=Vector3.Cross(tangent,Vector3.right);
                for(int i=0;i<12;i++)
                {
                    float a=i*Mathf.PI/6;
                    ring[point,i]=path[point]+(Vector3.right*Mathf.Cos(a)+v*Mathf.Sin(a))*.0018f;
                }
            }
            for(int segment=0;segment+1<path.Length;segment++)for(int i=0;i<12;i++)
            {
                int next=(i+1)%12;
                var normal=(ring[segment,i]+ring[segment,next]-path[segment]*2f).normalized;
                g.Quad(ring[segment,i],ring[segment,next],ring[segment+1,next],ring[segment+1,i],normal,3);
            }
            return g.Finish("Switchboards.FixedTerminalTail");
        }
    }
}
