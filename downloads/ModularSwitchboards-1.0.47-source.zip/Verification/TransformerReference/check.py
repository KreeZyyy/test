from pathlib import Path
import json,struct,math
r=Path(__file__).resolve().parents[2];src=json.loads((r/'Art/SmallTransformer-reference.json').read_text());prov=json.loads((r/'Art/TransformerParts-provenance.json').read_text());count=0
for name,report in prov.items():
 part=src['parts'][0] if name!='Dial'else next(p for p in src['parts']if p['path']==src['needlePath'])
 b=(r/'Assets/Transformer'/f'{name}.meshbin').read_bytes();nv,ni=struct.unpack_from('<ii',b);assert len(b)==8+nv*20+ni*4
 data=[struct.unpack_from('<5f',b,8+i*20)for i in range(nv)];ids=struct.unpack_from('<'+'i'*ni,b,8+nv*20);source_ids=report['sourceIndices'];assert [source_ids[i]for i in ids]==report['sourceTriangles'];count+=ni
 for i,source_index in enumerate(source_ids):
  assert abs(data[i][3]-part['uv'][source_index]['x'])<1e-7 and abs(data[i][4]-part['uv'][source_index]['y'])<1e-7;count+=2
 # Preserve every source edge length under one UNIFORM scale: all corners,
 # bevels, cross-section and full winding depth survive the conversion.
 for a,b,c in zip(ids[::3],ids[1::3],ids[2::3]):
  for first,last in [(a,b),(b,c),(c,a)]:
   p=part['vertices'][source_ids[first]];q=part['vertices'][source_ids[last]]
   native=math.sqrt(sum((p[k]-q[k])**2 for k in 'xyz'))*.195
   target=math.dist(data[first][:3],data[last][:3]);assert abs(native-target)<3e-8,(name,native,target);count+=1
 assert all(math.isfinite(v)for row in data for v in row)
assert prov['Winding']['triangles']==180 and prov['Dial']['triangles']==96 and prov['RangeArc']['triangles']==11
assert (r/'Assets/Transformer/Atlas.png').read_bytes()==(r/'Art/TransformerReferenceAtlas.png').read_bytes()
print(f'{count} exact exported topology/UV/uniform edge-scale checks passed; winding180/dial96/range11 triangles; atlas unchanged.')
