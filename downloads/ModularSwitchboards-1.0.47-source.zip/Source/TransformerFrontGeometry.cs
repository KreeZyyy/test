using System;
using System.Collections.Generic;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class TransformerFrontGeometry
    {
        internal const float KnobRadius=.010f,KnobDepth=.005284f;
        internal static readonly Vector3 KnobCenter=new Vector3(TransformerPanelLayout.CenterX,.0145f,.080683f);
        internal static readonly Bounds Pocket=new Bounds(new Vector3(TransformerPanelLayout.CenterX,-.0125f,.0818f),new Vector3(.057f,.0324f,.037f));
        internal static Mesh Body()
        {
            var s=DinBreakerModel.VisualScale;
            var hole=new Bounds(new Vector3(Pocket.center.x/s.x,Pocket.center.y/s.y,Pocket.center.z/s.z),new Vector3(Pocket.size.x/s.x,Pocket.size.y/s.y,Pocket.size.z/s.z));
            return TransformerCasePocket.Cut(TransformerPanelLayout.Body(),hole);
        }
        internal static Mesh Face()
        {
            var v=new List<Vector3>();var n=new List<Vector3>();var t=new List<int>[5];for(int i=0;i<t.Length;i++)t[i]=new List<int>();
            float x=TransformerPanelLayout.CenterX;
            RoundedGeometry.Box(v,n,t[0],new Vector3(x,0,.0745f),new Vector3(.071f,.058f,.0018f),.0013f);
            // Opaque closed rear seat, behind the actual full-depth winding.
            RoundedGeometry.Box(v,n,t[3],new Vector3(x,-.0125f,.0628f),new Vector3(.058f,.034f,.001f),.0005f);
            foreach(float y in new[]{.0048f,-.0297f})RoundedGeometry.Box(v,n,t[0],new Vector3(x,y,.077f),new Vector3(.057f,.0018f,.0032f),.0004f);
            var mesh=new Mesh{name="Switchboards.TransformerOwnMountingPlate"};mesh.SetVertices(v);mesh.SetNormals(n);mesh.subMeshCount=t.Length;for(int i=0;i<t.Length;i++)mesh.SetTriangles(t[i],i);mesh.RecalculateBounds();return TransformerCasePocket.Cut(mesh,Pocket);
        }
        internal static Mesh Knob()=>TransformerReferenceMesh.Load("Dial");
    }
}
