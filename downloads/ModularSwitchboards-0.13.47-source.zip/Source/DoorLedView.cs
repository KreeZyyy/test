using Assets.Scripts.Objects;
using UnityEngine;
namespace ModularSwitchboards
{
    // One controller on the actual module root. Never trust a copied prefab owner/renderer reference.
    public sealed class DoorLedView:MonoBehaviour
    {
        public DinBreaker Owner;public MeshRenderer Lens;
        private Material lensMaterial;private MeshRenderer boundLens;
        private Light glow;private GameObject glowObject;private bool reported;
        private void Awake()=>Bind();
        private void OnEnable()=>Bind();
        private void Bind()
        {
            Owner=GetComponent<DinBreaker>();
            Lens=transform.Find("DoorLedLens")?.GetComponent<MeshRenderer>();
            if(Lens!=null&&boundLens!=Lens)
            {
                if(lensMaterial!=null)Destroy(lensMaterial);
                lensMaterial=new Material(Lens.sharedMaterial){name="Switchboards.Door.Green.Live"};
                lensMaterial.EnableKeyword("_EMISSION");Lens.sharedMaterial=lensMaterial;boundLens=Lens;
            }
            var lightRoot=transform.Find("DoorLedGlow/NativeLedGlow");
            glowObject=lightRoot?.gameObject;glow=lightRoot?.GetComponent<Light>();
        }
        private void LateUpdate()
        {
            if(Owner==null||Owner.gameObject!=gameObject||Lens==null||lensMaterial==null||glowObject==null)Bind();
            if(Owner==null||Lens==null||lensMaterial==null)return;
            bool on=!Owner.IsCursor&&Owner.DoorLit;
            var color=on?new Color(.035f,.75f,.08f):new Color(.06f,.32f,.035f);
            var emission=on?new Color(.04f,1.4f,.10f):Color.black;
            lensMaterial.SetColor("_Color",color);lensMaterial.SetColor("_EmissionColor",emission);
            // Native things can leave per-slot blocks behind; write both override levels.
            var block=new MaterialPropertyBlock();block.SetColor("_Color",color);block.SetColor("_EmissionColor",emission);
            Lens.SetPropertyBlock(block);Lens.SetPropertyBlock(block,0);
            foreach(var hit in Owner.GetComponentsInChildren<Collider>())Thing._colliderLookup[hit]=Owner;
            if(glowObject!=null)glowObject.SetActive(on);if(glow!=null)glow.enabled=on;
            if(on&&!reported){reported=true;Debug.Log("[Modular Switchboards] Door LED live visual ON: "+Owner.ReferenceId+"; shader="+lensMaterial.shader.name+"; green emission applied.");}
        }
        private void OnDestroy(){if(lensMaterial!=null)Destroy(lensMaterial);}
    }
}
