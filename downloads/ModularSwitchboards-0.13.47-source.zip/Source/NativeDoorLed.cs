using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Assets.Scripts;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Structures;
using Assets.Scripts.Objects.Motherboards;
using UnityEngine;
using UnityEngine.Rendering;
namespace ModularSwitchboards
{
    // Keep the round lens on its own shader; reuse only small Lights Kit effects.
    // Do not clone a WallLight device: power and network state belong to the door module.
    internal static class NativeDoorLed
    {
        internal static void Install(DinBreaker owner,DoorLedView fallback)
        {
            // Native atlas materials require native UVs. Our round lens keeps its own Standard material.
            var group=new GameObject("DoorLedGlow"){layer=owner.gameObject.layer};group.transform.SetParent(owner.transform,false);
            // DoorLedView on the real module owns state and emission; this helper supplies native light assets only.
            fallback.enabled=true;
            var lightRoot=new GameObject("NativeLedGlow"){layer=owner.gameObject.layer};lightRoot.transform.SetParent(group.transform,false);
            lightRoot.transform.localPosition=new Vector3(0,0,.012f);
            var light=lightRoot.AddComponent<Light>();light.type=LightType.Point;light.range=.08f;light.intensity=.025f;
            light.renderMode=LightRenderMode.ForcePixel;light.shadows=LightShadows.None;light.color=new Color(.04f,1f,.08f);light.cullingMask=~0;light.enabled=false;lightRoot.SetActive(false);
            try
            {
                var sources=WorldManager.Instance.SourcePrefabs;
                var kits=sources.OfType<MultiConstructor>().Where(k=>k.PrefabName.IndexOf("Light",StringComparison.OrdinalIgnoreCase)>=0).ToArray();
                var listed=kits.SelectMany(k=>k.Constructables??new List<Structure>()).OfType<WallLight>().ToArray();
                var source=listed.Where(IsLed).OrderBy(l=>l.PrefabName,StringComparer.Ordinal).FirstOrDefault()??sources.OfType<WallLight>().Where(IsLed).OrderBy(l=>l.PrefabName,StringComparer.Ordinal).FirstOrDefault();
                if(source?.Light==null){Debug.LogWarning("[Modular Switchboards] Native LED settings unavailable; using the tiny local point light with the original round lens.");return;}
                const float scale=.05f;
                // Native settings and flare assets only: no second WallLight or powered device.
                light.type=source.Light.type==LightType.Spot?LightType.Spot:LightType.Point;light.spotAngle=source.Light.spotAngle;
                light.range=Mathf.Clamp(source.Light.range*scale,.04f,.12f);
                light.intensity=source.Light.intensity>0?source.Light.intensity*.01f:.025f;
                // A 4-12 cm indicator must light pixels, not only distant vertices of the door sheet.
                if(source.Light.cullingMask!=0)light.cullingMask=source.Light.cullingMask;
                var cached=source.Lights.FirstOrDefault(l=>l.Light==source.Light);if(cached!=null&&cached.LayerMask!=0)light.cullingMask=cached.LayerMask;
                var originalFlare=typeof(WallLight).GetField("lodFlare",BindingFlags.Instance|BindingFlags.NonPublic)?.GetValue(source) as LensFlare;
                if(originalFlare!=null&&originalFlare.flare!=null)
                {
                    var flare=lightRoot.AddComponent<LensFlare>();flare.flare=originalFlare.flare;flare.color=light.color;
                    flare.brightness=originalFlare.brightness*.02f;flare.fadeSpeed=originalFlare.fadeSpeed;
                }
                lightRoot.SetActive(false);
                Debug.Log("[Modular Switchboards] Round door LED: root-owned emission and original tiny light/flare settings from "+source.PrefabName);
            }
            catch(Exception ex){Debug.LogWarning("[Modular Switchboards] Native LED glow copy failed; round green lens retained: "+ex);}
        }
        private static bool IsLed(WallLight source)
        {
            if(source.PrefabName.IndexOf("LED",StringComparison.OrdinalIgnoreCase)>=0)return true;
            try{return Localization.GetThingName(source.PrefabName).IndexOf("LED",StringComparison.OrdinalIgnoreCase)>=0;}catch(Exception){return false;}
        }
    }
}
