using System;using System.Collections.Generic;using System.Linq;using UnityEngine;using ModularSwitchboards;
namespace UnityEngine{
struct Vector2 {public float x,y;public Vector2(float x,float y){this.x=x;this.y=y;}public float magnitude=>MathF.Sqrt(x*x+y*y);public Vector2 normalized=>this*(1/magnitude);public static Vector2 operator+(Vector2 a,Vector2 b)=>new(a.x+b.x,a.y+b.y);public static Vector2 operator-(Vector2 a,Vector2 b)=>new(a.x-b.x,a.y-b.y);public static Vector2 operator*(Vector2 a,float b)=>new(a.x*b,a.y*b);}
struct Vector3 {public float x,y,z;public Vector3(float x,float y,float z){this.x=x;this.y=y;this.z=z;}public float sqrMagnitude=>x*x+y*y+z*z;public Vector3 normalized=>this*(1/MathF.Sqrt(sqrMagnitude));public static Vector3 up=>new(0,1,0);public static Vector3 down=>new(0,-1,0);public static Vector3 forward=>new(0,0,1);public static Vector3 back=>new(0,0,-1);public static Vector3 operator*(Vector3 a,float b)=>new(a.x*b,a.y*b,a.z*b);public static Vector3 operator-(Vector3 a,Vector3 b)=>new(a.x-b.x,a.y-b.y,a.z-b.z);public static Vector3 Cross(Vector3 a,Vector3 b)=>new(a.y*b.z-a.z*b.y,a.z*b.x-a.x*b.z,a.x*b.y-a.y*b.x);public static float Dot(Vector3 a,Vector3 b)=>a.x*b.x+a.y*b.y+a.z*b.z;}
struct Bounds{public Vector3 center,size;public Bounds(Vector3 c,Vector3 s){center=c;size=s;}}
}
static class Mathf {public const float PI=(float)Math.PI;public static float Sin(float x)=>MathF.Sin(x);public static float Cos(float x)=>MathF.Cos(x);public static float Min(float a,float b)=>Math.Min(a,b);}
class Program{
static void Main(){int checks=0;foreach(float half in new[]{.025f,.0351f,.05f})foreach(float zmin in new[]{-.08f,-.16f,-.3f})foreach(float bottom in new[]{-.69f,-.72f,-.75f}){
var section=MediumOutputHousing.Outline(new[]{-.5f,0,.5f},new[]{bottom,bottom,bottom},half,-.566f,-.496f,-.116f);var outline=ChamferOutline(section,.003f);float zmax=zmin+.07f;var vertices=new List<Vector3>();var indices=new List<int>();int n=outline.Count;
foreach(float z in new[]{zmin,zmax})foreach(var v in outline)vertices.Add(new Vector3(v.x,v.y,z));
for(int i=0;i<n;i++){int j=(i+1)%n;indices.AddRange(new[]{i,j,j+n,i,j+n,i+n});}
var cap=Triangulate(outline);for(int i=0;i<cap.Count;i+=3)indices.AddRange(new[]{cap[i],cap[i+2],cap[i+1],cap[i]+n,cap[i+1]+n,cap[i+2]+n});
float area=0;for(int i=0;i<n;i++)area+=(outline[i].x*outline[(i+1)%n].y-outline[i].y*outline[(i+1)%n].x)*.5f;float sum=0;for(int i=0;i<cap.Count;i+=3)sum+=Cross(outline[cap[i]],outline[cap[i+1]],outline[cap[i+2]])*.5f;if(Math.Abs(area-sum)>1e-6||area<=0)throw new Exception("cap area");
var edges=new Dictionary<(int,int),int>();for(int i=0;i<indices.Count;i+=3){int a=indices[i],b=indices[i+1],c=indices[i+2];var normal=Vector3.Cross(vertices[b]-vertices[a],vertices[c]-vertices[a]);if(normal.sqrMagnitude<1e-20)throw new Exception("degenerate");if(i<n*6){int edge=i/6;var u=outline[edge];var v=outline[(edge+1)%n];if(Vector3.Dot(normal,new Vector3(v.y-u.y,u.x-v.x,0))<=0)throw new Exception("side winding");}else if(normal.z*((i-n*6)%6<3?-1:1)<=0)throw new Exception("cap winding");foreach(var e in new[]{(a,b),(b,c),(c,a)}){var key=e.Item1<e.Item2?e:(e.Item2,e.Item1);edges.TryGetValue(key,out int k);edges[key]=k+1;}checks++;}if(edges.Any(e=>e.Value!=2))throw new Exception("nonmanifold");
foreach(float x in new[]{-.5f,0,.5f})if(!section.Any(p=>Math.Abs(p.x-(x-half))<1e-6&&Math.Abs(p.y-bottom)<1e-6))throw new Exception("missing leg");
}Console.WriteLine($"Medium downward housing: 27 cases, {checks} triangles passed cap area, winding, watertight edges, three legs and nondegenerate geometry.");}
        private static List<Vector2> ChamferOutline(Vector2[] corners,float radius)
        {
            var result=new List<Vector2>();
            for(int i=0;i<corners.Length;i++)
            {
                var p=corners[i];var before=corners[(i+corners.Length-1)%corners.Length];var after=corners[(i+1)%corners.Length];
                float r=Mathf.Min(radius,Mathf.Min((before-p).magnitude,(after-p).magnitude)*.25f);
                var a=p+(before-p).normalized*r;var b=p+(after-p).normalized*r;
                result.Add(a);result.Add(b);
            }
            return result;
        }
        private static float Cross(Vector2 a,Vector2 b,Vector2 c)=>(b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x);
        private static List<int> Triangulate(List<Vector2> p)
        {
            var remaining=Enumerable.Range(0,p.Count).ToList();var result=new List<int>();int guard=p.Count*p.Count;
            while(remaining.Count>3 && guard-->0)
            {
                bool clipped=false;
                for(int i=0;i<remaining.Count;i++)
                {
                    int a=remaining[(i+remaining.Count-1)%remaining.Count],b=remaining[i],c=remaining[(i+1)%remaining.Count];
                    if(Cross(p[a],p[b],p[c])<=1e-10f)continue;
                    bool occupied=remaining.Any(v=>v!=a&&v!=b&&v!=c&&Cross(p[a],p[b],p[v])>=-1e-10f&&Cross(p[b],p[c],p[v])>=-1e-10f&&Cross(p[c],p[a],p[v])>=-1e-10f);
                    if(occupied)continue;
                    result.AddRange(new[]{a,b,c});remaining.RemoveAt(i);clipped=true;break;
                }
                if(!clipped)throw new InvalidOperationException("Cannot triangulate output housing.");
            }
            if(remaining.Count!=3)throw new InvalidOperationException("Incomplete output housing cap.");
            result.AddRange(remaining);return result;
        }
}
