using UnityEngine;
namespace ModularSwitchboards
{
    internal static class OutputPlacement
    {
        internal static Vector3 Outward(string name,int index,Vector3 left)
            =>CabinetShape.Medium(name)?Vector3.down:index==0?left:-left;
        internal static Vector3 Body(string name,int index,Vector3 left,float grid)
            =>CabinetLayout.OutputBodyCell(name,grid)+(CabinetShape.Medium(name)?left*((index==0?1:index==1?-1:0)*grid):new Vector3(0,0,0));
    }
}
