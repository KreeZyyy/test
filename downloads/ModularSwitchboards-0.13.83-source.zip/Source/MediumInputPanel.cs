using System.Collections.Generic;
using Assets.Scripts.Objects;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class MediumInputPanel
    {
        internal static void Install(SwitchboardCabinet cabinet)
        {
            var shell=cabinet.transform.Find("SwitchboardModel/CompletedShell");
            var root=new GameObject(OvenInputPanel.RootName){layer=cabinet.gameObject.layer};root.transform.SetParent(shell,false);
            var socket=NativeCableLayout.Read(CabinetLayout.InputCell(cabinet.PrefabName),CabinetLayout.InputOutward(cabinet.PrefabName));
            var data=root.AddComponent<OvenInputPanelMetadata>();data.SocketPoint=socket.Point;data.SocketAxis=socket.Forward;
            data.CableCell=socket.CableCell.ToVector3();data.BodyCell=socket.BodyCell.ToVector3();data.VisualAnchorPoint=socket.ContactPoint;
            var front=cabinet.transform.InverseTransformDirection(shell.TransformDirection(Vector3.forward)).normalized;
            root.transform.rotation=cabinet.transform.rotation*Quaternion.LookRotation(socket.Forward,front);
            data.NativeStyleCollider=ExternalCablePorts.AttachNativeOutput(cabinet,root.transform);
            Align(cabinet);CabinetModel.SetBounds(cabinet);
        }
        internal static void Align(Structure cabinet)
        {
            var shell=cabinet.transform.Find("SwitchboardModel/CompletedShell");var panel=shell.Find(OvenInputPanel.RootName);if(panel==null)return;
            var data=panel.GetComponent<OvenInputPanelMetadata>();if(data==null)return;
            panel.position=cabinet.transform.TransformPoint(data.VisualAnchorPoint);FitSupport(cabinet);
        }
        internal static void FitSupport(Structure cabinet)
        {
            var shell=cabinet.transform.Find("SwitchboardModel/CompletedShell");var support=shell.Find(OvenInputSupport.RootName);var panel=shell.Find(OvenInputPanel.RootName);
            if(support==null||panel==null)return;
            var join=CabinetWallMount.TransformedBounds(ExternalCablePorts.OutputJoinBounds,shell.worldToLocalMatrix*panel.localToWorldMatrix);
            var body=NativeRearBox.BodyBounds(cabinet);
            float low=body.max.y-.004f,high=join.min.y+.004f;
            if(high<=low)return;
            var vertices=new List<Vector3>();var indices=new List<int>();
            DinRailModel.AddBox(vertices,indices,new Vector3(join.center.x,(low+high)*.5f,join.center.z),new Vector3(join.size.x,high-low,join.size.z));
            var state=support.GetComponent<OvenInputSupportState>();if(state.InstanceMesh==null)state.InstanceMesh=new Mesh{name="Switchboards.MediumMatchedInputSupport"};
            var mesh=state.InstanceMesh;mesh.Clear();mesh.SetVertices(vertices);mesh.subMeshCount=5;
            for(int i=0;i<5;i++)mesh.SetTriangles(i==CabinetRearSurface.Role?indices.ToArray():new int[0],i);
            mesh.RecalculateNormals();CabinetGeometry.ApplyNativeUv(mesh);CabinetRearSurface.ApplyUv(mesh);mesh.RecalculateBounds();support.GetComponent<MeshFilter>().sharedMesh=mesh;
            var hit=support.GetComponent<MeshCollider>();hit.sharedMesh=null;hit.sharedMesh=mesh;
        }
    }
}
