"""Render the tested production mesh exports, never substitute primitive casings.
Run export_catalog_geometry.py then verification harnesses with CATALOG_ICON_EXPORT
and CATALOG_COVER_EXPORT before invoking Blender on this file.
"""
import bpy,json,math
from pathlib import Path
from mathutils import Vector
root=Path(__file__).resolve().parents[1]
geometry=json.loads((root/'Art/CatalogGeometry.json').read_text());cover=json.loads((root/'Art/CoverIconGeometry.json').read_text())
# Isolate the original lightning's connected component (20 triangles) from
# the grey bezel (48 triangles); they share one native material/UV atlas.
front=geometry['analyserFront'];indices=front['triangles']['0'];components=[]
for i in range(0,len(indices),3):
 points={tuple(round(v,6) for v in front['vertices'][j])for j in indices[i:i+3]};hits=[n for n,c in enumerate(components)if points&c[0]]
 if not hits:components.append((points,{i//3}))
 else:
  n=hits[0];components[n][0].update(points);components[n][1].add(i//3)
  for j in reversed(hits[1:]):components[n][0].update(components[j][0]);components[n][1].update(components[j][1]);components.pop(j)
assert sorted(len(c[1])for c in components)==[20,48]
lightning=next(c[1]for c in components if len(c[1])==20)
for kind,parts in [('DinFuse',['fuseBody','fuseClamps','fuseCartridge','fuseCaps']),('DinBattery',['batteryBody','batteryBay']),('DinAnalyser',['analyserBody','analyserFront']),('InnerCover',['cover'])]:
 bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
 mats=[]
 for name,rgb in [('White',(.78,.81,.80)),('Dark',(.035,.045,.045)),('Grey',(.24,.29,.29)),('Gold',(.78,.59,.045)),('Green',(.10,.48,.19)),('Lightning',(.7,.16,.02)),('Contact',(.55,.59,.59))]:
  m=bpy.data.materials.new(kind+name);m.diffuse_color=(*rgb,1);m.use_nodes=True;n=m.node_tree.nodes.get('Principled BSDF');n.inputs['Base Color'].default_value=(*rgb,1);n.inputs['Roughness'].default_value=.65;mats.append(m)
 allpoints=[]
 for part in parts:
  data=cover if part=='cover' else geometry[part];scale=(1,1,1) if part=='cover' else(2.25,1.35,1.15)
  # Convert Unity's left-handed view to Blender's right-handed camera frame.
  pts=[(-p[0]*scale[0],-p[2]*scale[2],p[1]*scale[1])for p in data['vertices']];allpoints.extend(pts)
  faces=[];roles=[]
  for role,indices in data['triangles'].items():
   role=int(role)
   for i in range(0,len(indices),3):
    faces.append(tuple(reversed(indices[i:i+3])));material={0:4,1:0,2:2,3:2,4:6}.get(role,2)
    if part=='batteryBay':material=3 if role==1 else 2
    if part=='fuseClamps':material=6
    if part=='fuseCartridge':material=4
    if part=='fuseCaps':material=0
    if part=='analyserFront':material=4 if role==2 else 5 if i//3 in lightning else 2
    if part=='cover':material=2
    roles.append(material)
  me=bpy.data.meshes.new(part);me.from_pydata(pts,[],faces);me.update();ob=bpy.data.objects.new(part,me);bpy.context.collection.objects.link(ob)
  for m in mats:me.materials.append(m)
  for face,role in zip(me.polygons,roles):face.material_index=role
 low=Vector(tuple(min(p[i]for p in allpoints)for i in range(3)));high=Vector(tuple(max(p[i]for p in allpoints)for i in range(3)));center=(low+high)/2
 size=high-low;scale=max(size.x,size.z,size.y*.65)*1.35
 scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=96;scene.cycles.use_denoising=False;scene.render.resolution_x=256;scene.render.resolution_y=256;scene.render.resolution_percentage=100;scene.render.film_transparent=True;scene.world.color=(.35,.35,.35);scene.view_settings.exposure=-1.4
 bpy.ops.object.camera_add(location=center+Vector((scale*.48,-scale*2.8,scale*.54)));cam=bpy.context.object;cam.rotation_euler=(center-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=scale;scene.camera=cam
 for offset,power in [((.1,-.3,.4),40),((-.3,.1,.2),25)]:
  bpy.ops.object.light_add(type='AREA',location=center+Vector(offset));bpy.context.object.data.energy=power;bpy.context.object.data.size=.5
 scene.render.filepath=str(root/'Assets/Icons'/(kind+'.png'));bpy.ops.render.render(write_still=True)
