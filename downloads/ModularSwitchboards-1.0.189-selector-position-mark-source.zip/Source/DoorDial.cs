using System;using System.Linq;using System.Xml.Serialization;
using Assets.Scripts;using Assets.Scripts.GridSystem;using Assets.Scripts.Networking;using Assets.Scripts.Networks;
using Assets.Scripts.Objects.Items;using Assets.Scripts.Objects;using Assets.Scripts.Objects.Electrical;using LibConstruct;using UnityEngine;
namespace ModularSwitchboards {
 public sealed class DoorDialSaveData:LogicBaseSaveData {[XmlElement]public PlacementBoardStructureSaveData Mount;}
 public sealed class DoorDial:LogicDial,IPlacementBoardStructure {
  public const string PrefabId="StructureSwitchboardDoorDial";
  public PlacementBoard Board{get;set;}public PlacementBoard.BoardCell[] BoardCells{get;set;}
  internal SwitchboardCabinet Cabinet=>Board?.PrimaryHost as SwitchboardCabinet;
  private CabinetWiring oldWiring;internal CabinetWiring Wiring{get{if(Cabinet!=null)oldWiring=Cabinet.Wiring;return oldWiring;}}
  internal Assets.Scripts.Objects.Electrical.Cable BoundCable;internal CableNetwork BoundNetwork;private float nextLink;
  internal static Bounds BodyBounds=>new Bounds(new Vector3(0,0,-.007f),new Vector3(.038f,.050f,.070f));
  internal static void SetBounds(DoorDial dial){dial.ThingTransform=dial.transform;dial.Bounds=BodyBounds;dial.GridBounds=new GridBounds(dial);}
  public override void Awake(){PrefabAudioOwner.PrepareInstance(this);DoorModules.BindDialKnob(this);base.Awake();BoardStructureHooks.Awake(this);}
  public override Grid3 GetLocalGrid()=>Board==null?default(Grid3):Board.WorldToGrid(transform.position);
  internal static bool CanPlace(PlacementBoard board,Grid3 p,int rotation)=>DoorModules.CanPlace(board,p,rotation)&&DoorDisplayClearance.ControlBoundsFit(board,p,BodyBounds);
  public override CanConstructInfo CanConstruct(){
   if(!(Board is SwitchboardDoorBoard)||Cabinet==null||IsCursor&&PlacementBoard.CursorBoard!=Board)return CanConstructInfo.InvalidPlacement("Aim at the outside of a completed cabinet door.");
   var p=GetLocalGrid();if(IsCursor){if(MountPlacement.TryLockedGrid(this,Board,out var locked))p=locked;else p=new Grid3(DoorModuleLayout.SnapSlot(p.x,-10,10),DoorModuleLayout.SnapSlot(p.y,CabinetShape.MinDoorY(Cabinet.PrefabName),10),0);PlacementBoard.CursorGrid=p;PlacementBoard.CursorRotation=0;transform.SetPositionAndRotation(Board.GridToWorld(p),Board.IndexToRotation(0));}
   return CanPlace(Board,p,Board.RotationToIndex(transform.rotation))?CanConstructInfo.ValidPlacement:CanConstructInfo.InvalidPlacement("Choose a free door position with room for its label.");
  }
  internal static DoorDial Target(PlacementBoard board,Grid3 p){
   var host=board?.PrimaryHost as SwitchboardCabinet;
   return host?.DoorBoardFor(board)?.Structures.OfType<DoorDial>().FirstOrDefault(d=>!d.IsBeingDestroyed&&!d.IsCursor&&d.IsStructureCompleted&&Same(board.WorldToGrid(d.transform.position),p));
  }
  private static bool Same(Grid3 a,Grid3 b)=>a.x==b.x&&a.y==b.y&&a.z==b.z;
  private bool HasLabel=>Cabinet?.DoorLabelsFor(Board)?.Structures.OfType<DoorLabel>().Any(l=>!l.IsBeingDestroyed&&Same(Board.WorldToGrid(l.transform.position),GetLocalGrid()))==true;
  protected override CanConstructInfo CanDeconstruct()=>HasLabel?CanConstructInfo.InvalidPlacement("Remove the door label first."):Cabinet?.CanAccessModules!=true?CanConstructInfo.InvalidPlacement("Open the cabinet first."):Wiring?.HasWires(ReferenceId)==true?CanConstructInfo.InvalidPlacement("Remove the DATA wire first."):CanConstructInfo.ValidPlacement;
  public override bool PreventInteraction(out DelayedActionInstance fail,Interactable control,Interaction interaction){
   if(!IsStructureCompleted||IsCursor||Cabinet?.IsStructureCompleted!=true){fail=new DelayedActionInstance{Duration=0}.Fail("Complete the door dial first.");return true;}
   return base.PreventInteraction(out fail,control,interaction);
  }
  public override DelayedActionInstance InteractWith(Interactable control,Interaction interaction,bool doAction=true){
   if(!IsStructureCompleted||IsCursor||Cabinet?.IsStructureCompleted!=true)return new DelayedActionInstance{Duration=0}.Fail("Complete the door dial first.");
   if((control.Action==InteractableType.Button1||control.Action==InteractableType.Button2)&&!(interaction.SourceSlot?.Get() is Screwdriver))return new DelayedActionInstance{Duration=0}.Fail("Requires Screwdriver.");
   return base.InteractWith(control,interaction,doAction);
  }
  public override DelayedActionInstance AttackWith(Attack attack,bool doAction=true){
   if(Cabinet!=null&&Wiring.TryAttack(attack,doAction,out var action))return action;
   return base.AttackWith(attack,doAction);
  }
  private void LateUpdate(){if(IsCursor)return;if(Time.unscaledTime<nextLink)return;nextLink=Time.unscaledTime+.15f;DoorDialNetwork.Refresh(this);}
  public override float GetUsedPower(CableNetwork network)=>-1;
  public override bool AllowSetPower(CableNetwork network)=>false;
  protected override void AssessPower(CableNetwork network,bool on){}
  public override void OnAddCableNetwork(CableNetwork network){}
  public override void OnRemoveCableNetwork(CableNetwork network){if(network==BoundNetwork)DoorDialNetwork.Unbind(this);}
  public override PassiveTooltip GetPassiveTooltip(Collider hit){var tip=base.GetPassiveTooltip(hit);tip.Extended="Setting: "+Setting+" / "+Mode+". DATA only; no power required. "+(BoundNetwork==null?"No data network connected.":"Connected to the external data network.")+" Use the two rear screws to adjust the maximum.";return tip;}
  public override void OnDeregistered(){DoorDialNetwork.Unbind(this);Wiring?.RemoveBreaker(ReferenceId);base.OnDeregistered();if(Board!=null)BoardStructureHooks.OnDeregistered(this);}
  public override void OnDestroy(){DoorDialNetwork.Unbind(this);Wiring?.RemoveBreaker(ReferenceId);base.OnDestroy();}
  public override ThingSaveData SerializeSave(){ThingSaveData data=new DoorDialSaveData();InitialiseSaveData(ref data);return data;}
  protected override void InitialiseSaveData(ref ThingSaveData data){base.InitialiseSaveData(ref data);if(data is DoorDialSaveData save&&Board!=null)save.Mount=BoardStructureHooks.SerializeSave(this);}
  public override void DeserializeSave(ThingSaveData data){base.DeserializeSave(data);if(data is DoorDialSaveData save&&save.Mount!=null)BoardStructureHooks.DeserializeSave(this,save.Mount);}
  public override void SerializeOnJoin(RocketBinaryWriter writer){base.SerializeOnJoin(writer);BoardStructureHooks.SerializeOnJoin(writer,this);}
  public override void DeserializeOnJoin(RocketBinaryReader reader){base.DeserializeOnJoin(reader);BoardStructureHooks.DeserializeOnJoin(reader,this);}
 }
}
