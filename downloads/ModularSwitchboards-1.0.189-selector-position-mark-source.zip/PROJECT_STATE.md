## 1.0.189 — Short selector position mark

Shortens the round selector's white position stripe from 11.2 to 5.2 mm and moves it toward the end of the grip. The grey grip, aligned control depth, Dial label range arc and control behavior are retained.

Production selector geometry/rotation checks and native compilation are validated; the selector icon is regenerated from the updated production mesh. Final appearance needs an in-game check.

## 1.0.188 — Dial label scale and matching selector depth

Removes the Dial's separate grey door plate and transfers its original range arc into the lower part of the optional Door Label. Dial labels now place the editable name in the upper row, like the round selector's name above 0/I. The arc appears only on a label attached to a completed Dial; other labels keep their existing markings. Removing a label removes the arc with it.

Matches the selector grip to the original Dial knob's grey texture and finish, retaining the white position stripe. Reduces Dial protrusion by 3 mm and brings the selector grip forward by 3 mm so their faces align at approximately 23.7 mm from the mounting plane. Both have a matching dark circular seat and the existing shared grey bezel. Front interaction bounds follow the new depths.

Mounting positions, label names, rear adjustment, native dial logic, wiring and saved state are retained. Native build, label placement/geometry and control checks are validated. Final appearance and label target switching need an in-game check.

## 1.0.187 — Matching door control finishes and selector

Unifies the Dial, round selector and five coloured pushbuttons with the same darker matte grey bezel finish and dark body. Dial retains its original transformer knob surface, grey door plate and dark range arc. Button face colours remain distinct.

Replaces the selector's broad white oval with a faceted, elongated dark handle and a narrow white position stripe. The grip remains inside the existing bezel throughout its quarter turn; mounting positions, labels, contacts, control timing and saved states are retained. Includes the rear Dial screw and Screwdriver-only adjustment changes from 1.0.186.

Native compilation, production selector geometry/rotation checks and button behavior checks are validated, and the seven control icons are regenerated. Final appearance requires an in-game check.

## 1.0.186 — Door Dial finishes and rear adjustment

Restores the transformer knob's original dark finish and native white pointer. The flush door plate now uses the same grey as the rounded silver bezel, with a dark range arc and black seat beneath the raised knob. Retains the larger knob and swapped front Increase/Decrease hitboxes.

Enlarges the rear Output-style screw heads to 11.52 mm and moves their white minus/plus marks above them. The two screws remain side by side near the bottom of the body, minus on the installed left and plus on the right. Physical maximum adjustment requires a Screwdriver; the native Labeller maximum-entry shortcut is rejected at these rear controls. Native logic properties and saved state remain compatible.

Native compilation and updated artwork preview are checked. Final appearance and rear control interaction require an in-game check.

## 1.0.185 — Door Dial sizing and adjustment controls

Places the two maximum adjustment screws side by side at the bottom of the Dial rear body, with minus on the installed left and plus on the right. Output-style screw heads are enlarged from 7.2 to 9.6 mm, and their white signs are enlarged and moved below them along the bottom edge. Removes the redundant DATA lettering above the unchanged top cable terminal.

Adds a fixed light plate flush on the door sheet with the original transformer range arc, automatically built with the Dial. The existing optional label is retained for later adjustment. Moves the transformer-shaped knob fully in front of the silver bezel, enlarges it by 10%, gives it a blue-grey finish with a white pointer and a dark circular seat underneath. Front interaction and selection bounds follow the raised knob. Swaps the front knob Increase/Decrease hitbox sides as requested. The shared door-control bezel, native dial behavior, data route and saved state are retained. Native compilation and existing Dial routing/registration and API checks pass. Final rear orientation and appearance require an in-game check.

## 1.0.184 — Door Dial controls and rear adjustment

Door Dial now reuses the transformer's exported knob and pointer inside the same silver bezel as the other door controls. Its rear body matches the door button family. Maximum adjustment uses the exact Output selector screw mesh and surface on the rear: plus on the right, minus at the bottom, with white marks above each screw. DATA remains at the top and gains a white label. The front has no adjustment screws.

Native dial behavior, wiring, data-only network registration, kit cost and saved state are retained. F1 and tooltip now identify the rear adjustment screws. Native compilation and existing Dial routing/registration and API checks pass; final appearance and interaction require an in-game check.

## 1.0.183 — Door Dial for native logic and Smart Core

Adds a door-mounted rotary dial using the shared silver control bezel, a black knob with white pointer, two front screws for the native maximum and one rear DATA terminal. It uses one Door Kit and accepts the ordinary door label.

Wire DATA to the door side of a dedicated Door Bridge, then its inside side to an external cabinet Output. With an external data cable connected, native logic can read Setting and Ratio and Smart Core can access the same dial through its Net. No power or Smart Core is required. Dedicated data bridges reject mixed power wiring and cannot join two external networks. Dial wires are excluded from the power solver.

Native LogicDial owns interaction, maximum adjustment, logic properties and saved/networked state. Routing, data-only registration and cleanup, placement, labels, F1, existing displays and Core scheduler checks pass. Native compilation passes; live Unity appearance, interaction and multiplayer still need an in-game check.

## 1.0.182 — Orange Output indicator without a Core chip

A completed Output attached to a powered, enabled Core now keeps its address visible and shows an orange indicator when the Core has no IC10 chip or its output session is not ready. OFF or unpowered Core remains dark. A ready, connected output keeps red for OFF and green for energized OUT.

The indicator uses available Core power independently of the permission to drive OUT. Missing-chip/reset protection and program-command reset behavior are retained. Tooltip and F1 explain the orange state. Native compilation and indicator, Output proxy/reset and scheduler checks pass; appearance still needs an in-game check.

## 1.0.181 — Reset Outputs before Core restart

Core OFF/ON, power loss/restoration and loading start a fresh Output session. Old Output commands and connected door display values are cleared before the bus becomes available and before the first instruction executes: On 0, display Mode 0, Setting 0 and green. The chip restarts from its first instruction, so the program can initialize the outputs again. Stable powered ticks do not clear fresh program writes. Output addresses and wires remain unchanged.

Keeps the final display behavior from 1.0.180: IDLE without a chip/program, WORK for a healthy loaded program, explicit db content retained even after a short script finishes, ERR overriding custom content, and a blank display when OFF/unpowered. Native display modes and save/network payloads remain compatible.

Native compilation and scheduler/reset-order, display/save/join, Output proxy, routing and status checks pass. Load behavior is covered by the managed native-scheduler fixture; live Unity/multiplayer testing remains to be done.

## 1.0.180 — Core WORK status, db display persistence and Output reset

A powered, enabled Core with a healthy non-empty program now displays WORK even after a short script reaches its end. IDLE is reserved for a missing chip or empty program. Faults display ERR with the line number; OFF or loss of power blanks the screen. Status no longer depends on the native instruction pointer or reflection over the private parsed-line collection.

Explicit db Setting writes retain the game's Mode, Setting and Color formatting after execution ends. Untouched display values keep automatic status; Automatic WORK restores it. Errors always override custom values. Native display mode numbers and the existing same-value store-intent hook are preserved.

Removing, replacing or reprogramming the chip clears attached Smart Output ON commands and connected door display values (OFF, Mode 0, Setting 0, green). A Core without a chip cannot energize its Outputs, including legacy loaded state. Periodic cleanup covers saved/disconnected modules and late wiring resolution. Output addresses and wires are retained. An ordinary power interruption with the same installed chip preserves the existing command-resume behavior.

Native compilation and status, scheduler, display/save/join and Output proxy/reset checks pass. No live Unity or multiplayer execution is claimed.

## 1.0.179 — Rounded industrial selector grip

Replaces the pointed round-switch paddle with a broader, rounded black grip and a large rounded white face inspired by the reference selector. Both meshes fit the existing shared silver bezel and keep the 3 mm forward mounting offset. The hollow collar, rear terminals, door labels and switching behavior stay in place.

The body and white face are closed, smooth-normal capsule meshes. Geometry checks cover their winding, normals, envelope and full quarter-turn clearance; the updated icon is rendered from the same production meshes. Button colours, names, pulse timing and save/network formats are unchanged. Final appearance requires an in-game check.

## 1.0.178 — Selector grip clearance and door button names

Shrinks the round switch grip and its white marker so the complete quarter-turn stays inside the silver bezel opening. The grip retains its 3 mm forward position. Geometry checks verify at least 0.4 mm radial clearance throughout rotation; the rear terminals, bezel, mounting and switching behavior remain unchanged.

Button names are now Door Green Button, Door Blue Button, Door Red Button, Door Black Button and Door Yellow Button. Blue and yellow keep their light face colours. Existing prefab identities, saved wiring, kit costs and pulse behavior are preserved.

Native compilation and geometry, control, label and catalog checks pass. Final appearance needs an in-game check.

## 1.0.177 — Five button colours and raised selector grip

Raises the round switch grip and white marker by 3 mm, with matching interaction bounds. The shared rounded bezel, rear terminals and label fit stay in place.

The existing button becomes Green Button with a lighter green face and retains its saved prefab identity. Adds Light Blue Button, Red Button, Black Button and Light Yellow Button to the Door Kit. Each costs one kit, uses one door position and supports the existing editable label. All five share the same non-illuminated face, 550 ms pulse and wiring behavior. Colour-specific icons, F1 titles and English/Czech search terms are included.

Native compilation and control, label, catalog and model checks pass. Artwork previews use the production palette; final appearance requires an in-game check.

## 1.0.176 — Matching rounded collars for door controls

The Door Button and Door Round Switch now share a rounded, hollow silver-grey bezel above the black mounting ring. The green push face sits slightly below the rim; the selector retains its rotary grip and white marker. The original outside diameter, mounting positions, rear terminals and label fit are preserved. The hollow opening keeps the button visible throughout its 2 mm press travel.

Regenerates both icons from the actual production bezel mesh. Pulse duration, switching, wiring, kit costs and save/network formats are unchanged. Native compilation and geometry/control regressions pass; final appearance needs an in-game check.

## 1.0.175 — Momentary door pushbutton

Adds Door Button to the Door Kit for one kit and one door position. Reuses the round switch mounting collar, silver-grey bezel, rear block and two screw terminals with a green, non-illuminated push face. A click connects IN to OUT for 550 ms, matching the installed game's LogicButton delay, then releases automatically. No hold is required; repeated clicks during a pulse do not extend it. Requires an external supply to pass a signal and provides no overload protection.

The existing Door Label fits the button and can be edited with a Labeller. Includes F1 help, catalog/search and a dedicated icon. Server state owns the timed release, clients use the native interaction/update path, and loaded saves release any transient press. Existing switch, TOTAL STOP, display and holder behavior remain intact. Native compilation and offline control/geometry regressions pass; live game appearance and multiplayer still need testing.

## 1.0.174 — Battery holder limit follows wiring through OFF devices

The one-holder-per-output-branch limit now follows installed wiring through OFF breakers, switches, contactors and transformers. Switching a device off or removing a cell no longer permits a second holder in series or on a merged output. New conflicting internal wires are rejected. Existing banks keep their cells and energy; only the holder with the lowest stable reference stays eligible until the wiring is physically separated. Separate output branches may share a charging feed. Contactor coil terminals remain isolated from the power contacts.

Includes the improved door display F1 help from 1.0.173. F1 now explains that OFF devices do not separate a holder branch. Holders remain usable for ordinary circuits as well as Smart Core backup.

## 1.0.173 — Clearer door display F1 help

Rewrites the Smart Door Display and its label descriptions to match the other modules: purpose, wiring and programming, then placement and kit requirements. Adds linked Door Bridge, Smart Output and label entries, explains the screwdriver-selected d0–d5 address and shows On, Mode, Setting and Color IC10 commands. Display geometry and behavior are unchanged.

## 1.0.172 — Rounded display label bottom

Rounds both lower corners of the door display label with smooth 22 mm arcs, matching the door LED label style. The filled upper shoulders, white caption, flat door mounting and native bezel opening remain intact. Native compilation and offline geometry checks verify the change; final appearance needs an in-game check.

## 1.0.171 — Filled door-label shoulders and wider white caption

The caption grows upward and sideways while its lower edge stays fixed. The white field is 179 x 15 mm inside a 184 x 21 mm plate, using the same 2.5 mm side borders as the door LED labels. The dark grey upper shoulders now fill to the full caption width, removing the cut-out corners. The display bezel remains free and the label stays flat on the cabinet door. Placement checks reserve the enlarged outline and retain clearance from the standard upper control row.

Rear connections, display logic, power and save/network formats are unchanged. Native compilation and geometry/clearance checks run offline; final appearance requires an in-game check.

## 1.0.170 — Display label sits flat on the cabinet door

Corrects the display label mounting plane: like the existing button label, its ring lies from -0.8 to +1.2 mm relative to the door board. It no longer follows the raised LED bezel height or covers the screen. Its opening fits around the native display bezel, leaving that bezel and the complete LED face exposed.

Retains the slightly wider white nameplate and larger text from 169, its compact row height, placement clearance checks, grey rear panel and upper screw/top cable entry. Display logic, energy and save/network formats remain unchanged. Existing labels adopt the corrected geometry without moving their board anchors.

Native compilation and geometry tests verify that every label mesh vertex stays within the original thin door-label depth and the opening clears the entire native bezel. Appearance still needs an in-game check.

## 1.0.169 — Thin display label and larger caption

Removes the deep label walls that made the LED surround look like a black enclosure. The surround is now a 1.2 mm skin seated above the native bezel, with only a 1.5 mm outward extension. The LED opening and native visible characters remain clear.

Widens the white caption face from 150 to 160 mm (outer frame 170 mm) and slightly enlarges its text. Nameplate height and vertical position stay unchanged, preserving clearance to the controls above. The grey rear, upper screw, top cable entry, logic, power and save/network formats stay unchanged.

Native compilation and geometry tests verify thin surround walls, clear LED opening and placement clearance. Final appearance still needs an in-game check.

## 1.0.168 — Compact display nameplate, LED surround and top cable entry

The optional display label now fills inward to the actual visible LED opening, above the original raised bezel. Its opening is the intersection of the native LED mesh and the native bezel's inner front boundary: letters remain in the same visible area and white bezel corners are covered. The upper white nameplate is narrower (150 mm face) and lower (12 mm face), positioned immediately above the display instead of protruding into the control row above.

Placement checks reserve room for the display and its nameplate on the correct door leaf. New displays/labels cannot overlap existing control or label bounds; controls and labels cannot be placed into an existing display's reserved footprint by reversing build order. Ordinary neighboring stop/main-switch controls fit above the new compact nameplate. Existing objects are not deleted or moved; their nameplate adopts the revised geometry.

The single rear screw moves to the upper position used by buttons. Cable entry now matches their top entry (Y 23 mm, Z -30 mm); the screw is at Y 16 mm, Z -38.5 mm. Existing endpoint-drift checks reroute saved display leads using the established atomic migration. The filled grey rear panel, two-position door mounting, Output addresses, display logic, energy accounting and save/network format stay unchanged.

Offline validation covers native compilation, native captured bezel opening extraction, visible LED clipping, exact-corner polygon cleanup, front/rear normals, compact-header screenshot reproduction, both construction orders, overlapping labels, rotated door frames and separate leaves, plus existing display/preview/mount/wiring tests. In-game appearance and multiplayer still require a live check.

## 1.0.167 — Filled grey display back and fuller label

Fills the complete rear display silhouette with the same grey material as its perimeter. The black button-style housing, single DATA IN screw and cable endpoint remain in front of the grey panel.

Widens the display label rim to a 5 mm outward offset and reduces the clearance around the native bezel to 0.25 mm. The original upper nameplate and native screen opening remain clear. Display logic, power, placement, wiring and save/network formats are unchanged.

Native compilation and production geometry checks verify face orientation, clear bezel opening and full rear-face area without holes or overlapping fill. In-game appearance still needs confirmation.

## 1.0.166 — Door display rear terminals and fitted label

Replaces the plain rear connector block with the same black rear housing, grey terminal and screw-slot style used by door buttons. The display has one central DATA IN screw; cable entry and the aiming point now meet that screw. Adds a thin grey display outline visible inside the cabinet door. The exterior remains the original native display/bezel without an extra casing or pedestal.

The display label now follows the actual native bezel silhouette with a small, uniform clearance instead of an approximate oval. Its original button-style upper nameplate is retained. Both the label opening and inside grey outline use the contour extracted from the installed game's native LED bezel, transformed to the final door pose. Front and rear face winding is verified so both sides remain visible.

Existing display wire paths are checked against the moved terminal and use the existing atomic route repair: connections, cable type/colour and coil quantities are preserved. If obstacles prevent repair, the original path remains and manual rewiring is reported. Output addresses, Mode/Setting/Color logic, power demand, label restrictions and save/network formats are unchanged.

Native compilation and geometry/placement/logic/route regressions run offline. Exact seating, selection and rear appearance still require an in-game check.

## 1.0.165 — Smart door display and matching label

Adds a Smart Door Display occupying two adjacent horizontal positions on one cabinet door. Only the original screen/bezel sits flush on the door; there is no added front casing or pedestal. Built with 4 Smart kits, it is door-only and uses the original five-character LED display renderer, modes and numeric/text formatting. Its rear DATA IN terminal connects through a dedicated Door Bridge to the existing Smart Output module. Net modules remain external network taps. One Output controls either a classic contactor A1 or one display; output addresses remain d0–d5, selected with the existing screwdriver control.

Programming uses ordinary display properties through the Output address. For Output d1:

```ic10
s d1 On 1
s d1 Mode 1
s d1 Setting 3
s d1 Color 2
```

Use `Setting` (singular), as with the native display. On controls the addressed Output and display together. Mode, Setting and Color are exposed when a completed display is connected. The display retains its settings across disconnection and power loss and resumes when control power returns. Its native power requirement is added to the Output's real service demand from the Core supply, including backup; the signal bridge is not a separate load feeder.

Wiring: Output OUT → bridge plate contact → bridge door contact → Display DATA IN. Each display signal requires a dedicated bridge, isolated from load wiring and A1. Direct wiring across the hinge, a second display/output on that signal, or mixed power/coil connections is rejected. Ambiguous, burnt or incomplete signal paths do not drive a display. Other outputs may still control ordinary contactors. Both leaves of a Medium cabinet have independent mounting and routing surfaces. Display placement reserves both positions; existing door controls cannot overlap either one.

Adds a two-position Smart Display Label derived from the existing button label, with its rounded ring widened around the display and the same upper nameplate. The matching label is available in the Label kit (1 kit). It fits only a completed Smart Door Display on the same door, supports the existing Labeller rename workflow, and must be removed before dismantling the display. The display cable must also be removed before dismantling. F1 descriptions/search and dedicated icons cover the new display and label. Native display state, custom color, mounting data and label text use save/join/update synchronization.

Validation includes native game-reference compilation, production routing/footprint and extracted Output-proxy tests, native API contracts, physical-hit board selection on both door leaves, existing native LED/store behavior, Stationpedia, model preview, wiring/combiner, holder-limit and breaker protection regressions. These are offline checks, not Unity gameplay or multiplayer/save-load execution. Test the first model and rendering in-game before public deployment. The previous holder limit and protection fix are retained.

## 1.0.164 — One Battery Holder per connected output branch

One Battery Holder per electrically connected output branch. Additional holders require separate branches.

The holder with the lowest persistent ReferenceId remains active. Additional completed holders on the same branch neither charge nor supply power; their cells and stored energy are preserved. Empty holders still reserve their branch. Existing cables are not deleted and no artificial short circuit is introduced. Separating branches or removing the active holder restores the next eligible holder automatically. New internal wires that create an additional conflicting holder are refused with an explanatory message. Existing conflicts do not prevent unrelated wiring edits.

Branch detection includes linked cabinet outputs, shared external cable networks across cabinets, downstream input links and series holders. Directional paths through breakers and transformers detect downstream merges without treating a common charging supply as a single backed-up output. Cell presence and state of charge never affect ownership. Power reservations are invalidated when the limit changes, including offers already cached in another cabinet. Native electricity ticks refresh external network membership before service and output calculations.

F1 includes the English rule. Inactive holder tooltips show: “Battery backup limit exceeded — connect to a separate output branch.” The stationary DIN battery experiments remain removed; the breaker-trip priority fix is retained. Cell capacity, native cell identities, construction costs and slot handling are unchanged.

Verification: native API compilation, production holder-limit regression (26 holders, energy preservation, branch split/merge, cross-cabinet links, cached offers, downstream protection, deterministic priority and wire adapter), existing combiner, wiring, protection and Stationpedia regressions. These are offline tests; Unity gameplay, save/reload and multiplayer behavior require an in-game check before public deployment.

## 1.0.145 — DIN battery casing assembled like the transformers (first visual test)

Replaces the miniature whole stationary-battery cabinet with the same DIN casing and terminal geometry used by the transformers. Small remains4positions and Large6. There is no rotated/scaled stock enclosure, back, base, feet, external connectors or ventilation grille left in the DIN model. Large is a wider DIN assembly; the earlier request to lay the whole original Large model sideways is superseded by the user's explicit transformer-style construction.

The front is assembled from the stock battery's individual charge segment meshes/UVs/materials and its original ON/OFF rocker. The native Battery still owns the five charge/color/blink states. Native mode0segment geometry forms the dark inactive sockets. The native SwitchOnOff driver, when available, retains its actual on/off rotations, materials/error animation and sounds; a legacy mesh variant uses the serialized ON/OFF state for its rocker pose. Both widgets are independently fitted onto the front, keeping each part's proportions. A small capacity label identifies the native stored-energy maximum. Source battery meshes/materials/controls are read but not moved or mutated.

Separate stage bodies preserve all original battery build tools/costs after the DIN mounting kit. Front widgets appear at completion. Headless servers build the same CPU DIN body/controls/contacts without reading GPU-only stock meshes. IN/OUT now use the same end-face entries and front screw aiming coordinates as transformers. Existing saved wire ends use the existing reroute mechanism when endpoints move. Body paint/finish follows transformers, with the native charge and rocker materials excluded from case recoloring.

Storage capacity, actual energy accounting, cell Holder, Core, data binding and battery save/join payload remain unchanged; only the old whole-model Animator setup is removed from Awake. Existing prefab identities and widths are retained. Install matching full folders on clients/server.

Validation: native-reference build0warnings/errors;613face layout/fit/clearance checks,49actual paint registration/palette checks including native battery isolation,50finish checks,25registration,26audio,21input,35blueprint+154families,15F1/104catalog and4819combiner checks pass. These are offline fixtures, not an in-game render. Native mesh extraction, rocker selection/pose, source material appearance, completed build visibility and loaded-world wire rerouting need the first Unity visual test. No live game was available. This release does not claim to fix the separate dedicated-server printing issue.

## 1.0.144 — Full140/143 source comparison and battery registration fix

Reviewed all26 changed/added source files from140to143. Original runtime Assets(87files), complete recipe GameData, dependency/package references, existing Holder and Smart Core code are unchanged. Both140 and144 compile against the same native references with zero warnings/errors. The common production energy and routing checks pass against both source versions;144 also passes28stationary-store checks. Full findings and limits: Verification/AUDIT-1.0.140-vs-1.0.143.md.

Fixes battery registration validation: inspect serialized ON/OFF controls instead of the private InteractOnOff runtime cache, which is not serialized onto an unawakened registered clone. Validation still rejects missing prefabs, missing controls/stages, wrong widths/mount kit and invalid capacity, and now logs the exact prefab/field failure. The previous combined error did not disclose which predicate failed. A cloned-data fixture reproduces the empty-cache false failure;25production validator checks pass. Actual Unity startup remains to be retried.

Unfinished battery construction now stays in the native tool flow instead of being intercepted as cabinet wiring when holding cable. The actual143 ModePrefix reproduces this regression in the same fixture that144 passes. Completed battery wiring and original targets/authority dispatch remain covered by21input-hook checks. The headless presentation setup also clears removed animation helpers consistently with the original transformer setup.

Retains143inactive-owner preview fix and142initialization/audio guards. Re-ran4819combiner,12464circuit/persistence/routing,33service binding,12setup,26audio,35blueprint+154family,15F1/104catalog and23name checks. The140baseline passed4791common combiner and12464routing/circuit checks. Fixture unused-field warnings are separate from the native build. No Unity visual, actual new battery save/late-join or dedicated server run was available; the separate StationeersMods.AssemblyMod exception and older multiplayer-printing report are not claimed fixed.

## 1.0.143 — Battery preview under inactive prefab storage

Fixes the reported startup exception: `Cannot build a preview without model geometry` in DinStationBatteryModel.Install. ModelBlueprint's owner filter used GetComponentInParent<Thing>() with Unity's default includeInactive=false. During authoring, the battery lives below inactive prefab storage, so the filter rejected its renderers even though their mesh geometry existed. The filter now uses GetComponentInParent<Thing>(true). It still excludes meshes belonging to a nested foreign Thing, retains the original ownership check and does not activate storage or replace native meshes.

The regression fixture now models inactive-ancestor lookup correctly and tests the same battery/storage hierarchy. Running the old production filter against this fixture reproduces the exact reported exception; the fixed production filter passes. Existing visibility, nested transforms, mirrored winding, native submeshes, source ownership, large meshes, cursor selection and hitbox checks also pass:35 blueprint checks plus154 own-family checks. Final native-reference build:zero warnings/errors. This is an offline reproduction and targeted fix; an actual Unity startup retry is still needed.

Keeps142normalization/audio guards and141batteries, construction costs and energy behavior. No recipe XML or power solver change. The recipe-verification messages in this report followed the aborted prefab transaction; this fix addresses that demonstrated startup failure, not the older separate dedicated-server printing report.

## 1.0.142 — Battery prefab preparation guard fixes

Normalizes native battery controls before replacing their owner: preserves controls declared only in construction stages, removes null/duplicate entries, initializes absent lists and caches the native ON/OFF reference before authoring checks. Audio rebinding/runtime cloning now accepts null native event/condition lists; the added mount stage shifts only existing audio build-state conditions. Component reference remapping now touches serialized fields only, avoiding unrelated runtime caches.

Removes the premature startup requirement for exactly five indicator renderers. The five visible charge segments are native Battery behavior; the number of mesh renderers is native prefab data. An unavailable pre-registration visual reference now produces a focused warning rather than aborting every switchboard prefab. Construction costs, energy accounting, widths and native battery storage remain as in141.

On prefab failure, the original exception is recorded/logged before cleanup. Registration verification repeats that original exception once and skips the cascade of missing-object errors. Module preparation logs name the variant being built. This preserves atomic publication of the complete prefab set; it does not silently discard failed battery variants.

Validation: native-reference build zero warnings/errors;26 actual production audio-owner checks including null lists/conditions and12 actual production battery-normalization checks including stage-only ON/OFF, stable control identity/order and repeated setup. No live Unity runtime is available. The supplied screenshot contained only downstream verification failures, so the exact exception from that run is not confirmed and this startup fix needs an in-game retry. The earlier dedicated-server printing report is separate.

## 1.0.141 — Native Station Batteries on DIN rails (first test build)

Adds DIN Station Battery (4 positions) and DIN Station Battery (Large), occupying 6 positions with the original large model turned sideways. Both use uniformly scaled native geometry, native materials, the original ON/OFF control, five charge indicators, native Battery capacity/charge storage, logic values and charge/save/join serialization. The capacities come directly from the game's StructureBattery/StructureBatteryLarge prefabs. The existing cell-based Battery Holder is retained.

Build from Kit (Switchboard Modules): one kit mounts the DIN plate, then all original native battery construction stages/materials/tools follow. New batteries start empty. Connect IN for charging and OUT to a protected load circuit. OFF disables charging and discharging; the native stationary-battery self-discharge/thermal behavior is retained. The cabinet owns energy transfer, so the native object cannot register a second external power provider. Holder charging remains capped at its existing 1 kJ per cycle; stationary batteries retain their native uncapped throughput, subject to the wired circuit and its protection. Shared bidirectional battery terminals, new parallel wiring rules and short-circuit simulation are deferred.

Headless servers use a procedural footprint with the same battery identity/capacity/controls and construction costs; they do not need native visual meshes or indicator materials. Visual animation is skipped only in batch mode. This path is compiled but still needs a real dedicated-server check.

Mounting, occupied DIN positions, cover openings, wiring endpoints/routing, teardown/refunds, save/join and data-only network registration include both variants. The native model and controls are nested below an unscaled board root; the large variant's visual rotation does not change its saved board orientation. This build must be installed with the complete folder on all participating clients/server.

Offline validation: native-reference build with zero warnings/errors; 4819 collecting-cabinet checks (including 28 new live-store battery checks), 12464 circuit/budget/persistence/routing checks and existing battery/transformer/protection regressions, 33 actual service bindings, 23 name checks, 15 F1 binding and 104 catalog/search checks. Fixture unused-field warnings are separate from the native build. Native Unity model fitting, indicator animation, switch hitboxes and actual save/late-join still require an in-game check. No live Unity or dedicated server was available here. This does not claim to fix the separately reported dedicated-server printing problem.

Source archive note: additional large authoring JSON is supplied losslessly as .xz; decompress beside the original path when needed. Raw authoring inputs and historical snapshots remain unchanged in the workspace.

## 1.0.140 — Direct cabinet Output to Smart Net DATA

A completed Smart Net DATA contact can now connect directly to cabinet Output1,2or3 (where present), in either click order. Each cabinet Output has one separate direct DATA-tap slot alongside its unchanged power-feeder capacity. Collecting outputs retain their existing branch limit. A Net still accepts a single DATA connection. Core POWER IN, ordinary module inputs, Output-to-Output connections and Net-to-Net connections do not gain this exception.

The explicit tap selects that Output's real external cable network even if the upstream breaker is open, the Output is unpowered or its internal feed is reachable from Input. An external cable/network must exist at the Output. Different Net modules retain indexed network access and native data isolation; the Net does not join native networks or supply any device. Direct DATA-tap edges are removed from the energy/overload graph. Existing feeder-side taps still work.

Markers and routing support the shared power/data terminal; paths still reserve space around existing wires and devices. Save/network loading preserves the new narrow Output-to-Net leaf before board identities are available, then existing deferred cleanup checks that its owner really is a Net. Invalid staged leaves cannot transfer power. The existing wire packet format, coil cost/paint/refund, model and module economy are unchanged. F1 now explains direct taps. Install this version on both client/server and keep the full GameData folder.

Validation: native-reference build0warnings/errors;1101 production topology/capacity checks;18 actual CabinetWiring XML/binary/load checks with board identities deliberately absent;actual mirrored routing tests with an occupied Output;existing malformed/legacy/paint/damage serialization checks.99SmartPLC and33Smart-network checks include independent direct Output networks and open protections.4791collecting-cabinet checks,18046service-power checks and the existing power/battery/transformer/protection suite pass. Fixture stubs needed updates for existing service-load fields; fixture unused-field warnings are not native-build warnings. These are offline checks, not a live Unity/multiplayer visual test.

Includes139native Core execution and138XML recipes unchanged. The separately reported dedicated-server printing problem remains unresolved.

## 1.0.139 — Smart Core native chip execution test

Smart Core now uses only the native ElectricityManager -> CircuitHolders -> ICircuitHolder.Execute path used by IC Housing. Removed the separate LateUpdate execution timer. Native Device.Awake normally registers the Core already; placement and finished-load callbacks now explicitly ensure registration using the native duplicate-safe DensePoolReference. Deregistration removes the holder and marks Lua inactive. No second VM tick or blanket device-pool patch.

Core Execute refreshes its paid internal service-power state and retains construction, mounted-board, ON, power, simulation, running-game and pause guards. IC10 uses the native128-instruction budget. Lua goes through ProgrammableChip.Execute too, allowing StationeersLua's own patch to apply runtime/save/compile guards and its GameTickSpeedSeconds cadence. The ordinary IC10 path has no mandatory Lua dependency.

IC10 status stays idle until this chip has passed through Execute; a valid line0 alone no longer labels an unexecuted chip RUNNING. Reprogramming/insertion/removal clears the execution marker. Lua compilation/runtime status comes from the Lua adapter rather than the native IC10 compiler flag. Internal battery/transformer control power, physical slot/model, programme/save formats and138native XML recipes are retained.

Validation: native-reference build0warnings/errors.322 checks use ACTUAL native CircuitHolders/DensePoolReference with extracted production execution/registration/status methods, including100loop ticks and duplicate Awake/placement/load callbacks. The chip/VM in that fixture are explicit stand-ins, not the real IC10 interpreter/Lua VM.23optionalLua adapter/actualDLLAPI checks and32status-display checks pass. Live Unity/singleplayer/DS execution of the reported programme remains to be tested; the specific original freeze is not claimed reproduced. Retest powered Core with the five-line counter loop, then save/reload and OFF/ON; optionally retest Lua. The independent dedicated-server printer issue remains unresolved.

## 1.0.138 — Native XML recipe registration test

All seven kit recipes now live in `ModularSwitchboards/GameData/electronics.xml` and use the native GameData loader, matching the supplied Modular Consoles Reloaded package. Removed the `GenerateRecipieList` Harmony prefix, its C# recipe injection and the unused SmartKitRecipe factory. XML is the sole recipe source. Existing post-load recipe diagnostics, kit identities, costs, durations, energy, Tier One and one-kit outputs remain unchanged. Native XML loading performs recipe range checks and associates recipes with mod metadata.

Install the full folder, including the new GameData directory, on server and clients. Replacing only the DLL will omit every kit recipe. Restart the game/server after installation. This is a candidate for the reported multiplayer printing problem, not a confirmed fix. The native XML load notices should now include this mod when its GameData file loads.

Validation: native-reference build with zero warnings/errors; all seven XML recipes deserialize with the actual native WorldManager.RecipeData type;14 Smart kit/placement checks pass using the production XML. Native LoadGameDataAsync awaits Prefab.LoadAll before LoadDataFiles, so the existing PreparePrefabs hook publishes our kits before recipe XML is processed. Economy/package parity checked against137. Live multiplayer printing still requires a server/client retest of both vanilla items and switchboard kits. Includes137spawn cache/diagnostics and preceding internal control power; no Large prototype or manual routing.

## 1.0.137 — Wall spawn cache test

The wall-fit cache now includes the wall mesh identity, vertex count/bounds and renderer-to-wall transform. A late native wall mesh replacement or renderer-space change triggers a fresh fit even when cabinet/wall roots and the build-state index are unchanged. Stable geometry keeps the existing short circuit. This fixes an offline-reproduced cache defect; it does not establish the cause of the intermittent opaque white panel in the player screenshots.

Adds bounded, read-only `Cabinet spawn view` log records after spawn and when the open/build state changes. Records include cabinet position/rotation, model offset/rotation and own renderer mesh names, visibility and centres. They distinguish a real cover from hidden interior geometry without altering cover/save state. No blind axis flip.

Validation: native-reference build with zero warnings/errors; 107 production-source wall-fit/cache checks, including late mesh replacement, renderer movement, bounds changes and native draw-data fallback. The 1.0.136 wall-fit source fails the late replacement regression in the same fixture. Live Unity appearance remains unverified; test the same location repeatedly and retain Player.log if the white panel returns. Includes the existing control-power and printer-name changes; no Large prototype or manual routing.

## 1.0.136 — Symmetric wall mounting envelope

Back-face mounting now uses the same outer mounting envelope as the opposite face, instead of pulling the cabinet inward to the native wall's thin/asymmetric rear skin. The envelope is centred on the native wall mounting grid. It applies to both the template/ghost offset and the actual supporting-wall fit. The known native flat-wall profile (rear+0.012642m,front+0.130001m,grid plane0) retains its front face and uses-0.130001m at the back, with the existing0.5mm clearance. This is a conservative mounting envelope, not a new scan of every surrounding frame.

Cabinet root/grid positions, roll/orientation choices, models, costs, wiring graph and save formats are unchanged. Existing model-relative rails/modules, covers, door boards and wire visuals move with their existing parent transforms. Existing cable-port alignment and bounds refresh remain in place. Previously placed back-side cabinets refit through the existing wall-fit update after loading. No forced save migration or electrical reconnection.

Validation: native-reference build0warnings/errors;34,014 wall-envelope fixture checks cover the reported asymmetric profile, opposite faces, shifted mounting grid planes, cardinal rotations, model-relative child translation, symmetric/invalid profiles. Existing upright/manual mount-orientation fixture also passes. Native LibConstruct AddStructure parents mounted structures to each board Origin; those origins are children of CompletedShell. Offline fixtures do not reproduce the player's exact scene or prove all surrounding structural geometry is clear. Actual game appearance and a populated cabinet on the back wall still need testing.

Includes135internal control power,134stable printer names and orange indicator; manual cable routing remains removed. The separate vanilla multiplayer printer issue remains unconfirmed. Install the same version on server and clients. No Steam Workshop publication.

## 1.0.135 — Internal control power from the wired supply branch

Core and Smart Output control electronics now use the cabinet's real path-based source allocator, alongside transformer control electronics. Supply can come from external inputs, transformers or battery OUT according to the actual connected circuit. A Core no longer requires an external output cable or native external network to run. Outputs take their control supply through their attached Core's side bus and each enabled, correctly addressed Output retains its existing5W cost. Core and transformer costs retain their existing native UsedPower values. Smart Net data-only behaviour is unchanged.

Internal consumers reserve and pay energy once per native electricity cycle. Native consumer billing is disabled for Core and Smart Outputs to avoid double charging; external data-network registration remains independent. Batteries pay actual delivered consumption; native source shortfalls can be topped up from available battery energy at cycle end. Transformer transfer limits, upstream breakers/fuses and physical wire limits remain on the real supply path. Unfinished/OFF/detached or insufficiently supplied consumers do not run. Core supply loss releases control Outputs. No new save format or prefab identities; existing objects keep their wiring.

Validation: final native-reference build0warnings/errors;18,046 service-power checks including3,000 changing-source/enable cycles, isolated battery, mixed/duplicate/multiple inputs, bus loads, actual brownout top-up, exact battery use, output competition, transfer caps, protection, removal and disabled/zero-power states.33 actual mapping/runtime-method checks;33 data-network checks;96 Smart bus/PLC checks. Existing power/protection/battery/transformer regression suite passed. Several old test stubs were brought up to current source interfaces; fixture unused-field warnings are not native build warnings. These are offline checks, not a live Unity or multiplayer validation.

Test on matching1.0.135 server/clients: feed battery IN from a transformer and wire battery OUT to Core POWER IN; install a charged cell. Core should run without an external Output cable. Fit Smart Outputs, verify their commands, disconnect mains, then test battery depletion and an open upstream breaker. Consumption must follow the battery/source. Manual routing remains removed; orange LED and134 stable printer-name correction remain. The separate all-vanilla multiplayer Print issue is not claimed resolved by this power change. No Steam publication.

## 1.0.134 — Stable fallback names for printer kit ordering

Fixes an offline-reproduced language-dependent ordering defect for the seven Switchboards kit recipes. The native printer sorts by Localization.GetFallbackName, while the old mod supplied only GetThingName. The new narrow fallback hook supplies stable English names for these seven kit prefab IDs and shares the same mapping with display-name lookup. It leaves vanilla, other mods and non-recipe prefabs on the original localization path. Recipe costs, outputs, networking, electrical behaviour and existing prefab identities are unchanged. Automatic routing from133 is retained; manual routing remains removed. Orange indicator, DS support and printer diagnostics remain.

Use the same1.0.134 on server and clients, restart both, and reselect the desired recipe before testing Print. This correction addresses the reproduced own-kit ordering bug; it is NOT proof that the separate report of all vanilla printing stopping is resolved. The supplied multiplayer logs were client1.0.130 and did not include the authoritative server state.

Validation: native-reference build0warnings/errors;22,849 checks of the actual new name helper against native sorting/fallback method fixtures, including600 catalogue comparisons across6languages, random insertion orders, exact per-index identity, custom-name independence and vanilla/foreign/null fallthrough. Negative control reproduces the old mismatch. No live multiplayer reproduction or validation yet.

## 1.0.133 — Remove experimental manual routing

Restores the automatic cable routing, normal terminal selection and original wire network packet format from 1.0.131. Removes manual routing points, their markers and automatic raised crossings introduced in 1.0.132. Existing completed wires keep their stored paths and electrical endpoints; no save wipe or forced rerouting. Orange Door LED, DS startup support, Core IC10 access repair and printer diagnostics are retained. The Electronics Printer issue remains unresolved. Use matching versions on server and clients, and restart both when switching from 1.0.132.

## 1.0.131 — Electronics Printer diagnostic candidate

Based on DS/orange 1.0.130. Adds observation of the Electronics Printer catalogue and ordered prefab fingerprint on startup, recipe selection on the client, recipe-index receipt on the server, and Print interactions (power, activation, error, tier, ingredients and current recipe). Logs include version and headless/simulation mode. Native exceptions are logged and returned unchanged; diagnostic read failures do not block the game action. No recipe, power, button or network-message behaviour is intentionally changed.

This is NOT a confirmed fix. Install this exact candidate on both the Linux server and testing client, restart, select a vanilla recipe with enough materials and press Print once. Send both logs from startup through that attempt; search for `Printer diagnostic`. One startup catalogue line lists prefab identities only. No player data is logged by these added diagnostics. Actual DS/Unity testing is still required. Native-reference build: zero warnings/errors. Includes orange Door LED; no Large prototypes.

## 1.0.130 — Orange door indicator

Adds Door LED Orange to the existing Door kit for 1 kit. Includes orange off/on lens, emission, native light, icon, F1 catalogue and orange/amber search aliases. Existing prefab names remain unchanged. Based on DS candidate 1.0.127; no Large cabinet changes. The reported Electronics Printer server failure is still under investigation; this addition does not fix it.

Validation: native-reference build passed with 0 warnings/errors; 134 production LED controller checks passed. Actual in-game and multiplayer validation pending.

# Modular Switchboards 1.0.127 — dedicated-server startup candidate

Based on stable 1.0.126 (the Workshop-linked 1.0.122 line plus IC10 access fix). No Large cabinet prototype changes.

The reported first error, Native game paint material unavailable, comes from graphics validation during prefab preparation. Failed recipe checks follow the aborted prefab transaction. A non-rendering server must not require Shader.isSupported to be true.

- Centralized headless detection (batch mode or Null graphics device) and shader validation. Normal rendered clients still reject unsupported shaders. Missing server-wide paint templates/custom shaders can use an existing native APC material/shader; no null shader is accepted.
- Native CPU-readable meshes are copied with all native channels for the battery holder and analyzer, retaining selected triangles without GPU-buffer readback. Client GPU-copy/verification path is retained.
- Headless startup skips cosmetic warning texture readback, lever recolour blits and thumbnails. Shapes/ports/slots/recipes remain registered normally.
- Non-readable mesh data on a headless server fails with the exact mesh name before attempting GPU access. No fake geometry or placeholder colliders are supplied. Fully stripped native meshes require further matching CPU geometry support.
- Startup log reports headless status and graphics backend; paint failures report whether template/shader is missing.

Validation: native-reference build0warnings/errors;72headless shader/material policy checks;16CPU mesh selection/channel-preservation checks;97IC10 access checks passed. This is NOT a real dedicated-server or multiplayer test. The reporter must verify server startup and joining/constructing with matching clients. Use this same version on the DS and every client. If startup still fails, capture the FIRST complete prefab setup exception and stack trace, not only the later recipe failures. Steam Workshop has not been updated.

# Modular Switchboards 1.0.126 — Smart Core IC10 access repair

Based on Workshop-linked 1.0.122, without any Large cabinet prototype changes.

Completed Core slot access now explicitly rebinds the native slot/action/collider dictionaries after registration and construction-state visualization, and checks them during runtime. This covers the native renderer-dependent state-update path that can leave a visible finished socket with stale interaction caches. The custom slot is authored as interactable rather than inheriting the source Air Conditioner's UI flag. Incomplete Core stages remain unavailable; closed/detached cabinet access stays disabled. Existing slot, occupant and chip seating transform are retained.

Validation: native-reference build0warnings/errors;97production slot/cache/state/access/rollback/chip-preservation checks;61Core stage checks;15Core save/migration checks;22wire-readiness checks passed. These are fixture/stub checks, not Unity reproduction. Actual cause of the user's selection failure and in-game insertion still need confirmation. A one-time log on cache rebind reports stage and binding availability.

Test a fully completed Core: aim at the right-hand socket with an IC10 in hand, insert/remove it, close/reopen the cabinet, then save/reload. If it still fails, collect the Core IC10 access rebound log and check whether the slot action appears while aiming at the socket. Large prototypes remain separate and Steam Workshop has not been updated.

# Modular Switchboards 1.0.122 — restore cabinet door pose during load

Saved door positions now apply immediately during save/join restoration and registration, with first-physics-step initialization as a fallback. Small and both Medium door hinges retain their existing animation and physical colliders. This addresses a door initialization gap; whether it resolves reported player displacement near cabinets requires in-game verification.

Validation: 23 door load/physics/animation checks passed; native-reference build without warnings/errors.

# Modular Switchboards 1.0.121 — empty cover kit refunds

Removing a cover without live labels uses normal deconstruction and returns its cover kits (Small 1, Medium 2). Covers with labels remain portable Fitted Covers, preserving labels, openings and colour. Empty painted covers also return kits.

Validation: 94 cover-transfer checks passed; native-reference build without warnings/errors. Actual in-game refund verification remains pending.

# Modular Switchboards 1.0.120 — remaining kit economy and cover size costs

Smart Output now uses4 Smart kits (Net remains1). Door kit recipe:5 Iron +20 Copper; LEDs, round switches and individual bridges use1 kit, while TOTAL STOP and Main Switch use3. Label kit recipe:5 Silicon, with1 kit per label regardless of width. Cover kit recipe:20 Silicon; Small cover uses1 kit, Medium2.

Medium cover has a separate hidden native-cost prefab so LibConstruct consumes2 kits through its normal construction path. Mounting and server authority select the cabinet-size-matched prefab. All cabinet orientations/input-output variants use the corresponding Small/Medium cost. Existing fitted covers retain labels/color/openings and can be refitted without new kits. The standalone covers remain hidden from F1/creative listings; the kit entry describes both costs.

Validation: native-reference build without warnings/errors;74 direct cover/name/preview/client/cancellation/size/cost checks and70 actual cover-transfer checks passed. Other staged module behavior and accepted geometry remain unchanged. Actual Unity printer/consumption/refund/new-prefab/save-load/multiplayer verification remains pending.

# Modular Switchboards 1.0.119 — native rounded display outline and pocket surfaces

The unfinished Core display opening follows the actual original white bezel outline, including its curved segments, instead of simple chamfered corners. Its floor remains 4 mm deep. Display and IC10 pocket floors/walls now use source material roles, sampled native UVs and original material property blocks instead of the bright cabinet gray. Chip lining is visible only before the native socket is installed; the completed native socket remains unchanged. F1 stage images match the revised models.

Construction, kit recipes, save migration and completed-only chip/control/network/power/wiring gates remain unchanged.

Validation: native-reference build without warnings/errors; 7,395 geometry/ray/rounded-outline/depth/UV-role/nondegenerate checks and 61 stage/model/control/rollback/lining checks passed. F1 icons visually inspected. Actual Unity appearance/color/construction/save-load/multiplayer verification remains pending.

# Modular Switchboards 1.0.118 — visible IC10 and display pockets in unfinished Core

Core now shows the original-depth IC10 opening with an opaque gray floor before the socket is fitted. The display opening matches the native bezel footprint and is 4 mm deep, also with gray walls and a closed floor. These pockets remain beneath the fitted components. Stage0 shows both openings, stage1 adds the display, stage2 adds the original native IC10 socket. F1 images match the revised stage models.

Construction remains 5 Smart kits, then 2 Electronic Parts, then 5 Heavy Cable Coils; IC10 separate. Recipes, saved-stage migration, completed-only chip/control/network/power/wiring gates remain unchanged.

Validation: native-reference build without warnings/errors; 7,005 native geometry/ray/depth/material/nondegenerate checks and 49 stage/model/control/rollback checks passed. Actual Unity appearance/construction/save-load/multiplayer verification remains pending.

# Modular Switchboards 1.0.117 — Smart kit economy and three-stage Core

One Smart kit now costs 10 Copper + 8 Steel + 4 Solder in the Electronics Printer. Core construction: 5 Smart kits build the solid body without display or IC10 socket; 2 Electronic Parts add the display; 5 Heavy Cable Coils add the original socket and its pocket. Insert a separate removable IC10 only after completion. Other Smart module construction kit counts remain unchanged.

Each Core stage has its own F1 image. Incomplete Cores cannot accept IC10, use controls, run programs, bind power/data networks or receive new wiring. Heavy coil assembly uses native construction instead of internal wiring at the display-only stage. New saves preserve partial stages; older completed Core saves migrate to the final stage. The completed native display/socket appearance is preserved.

Validation: native-reference build without warnings/errors; 14 Smart-kit placement/recipe checks, 15 Core save/XML/chip/legacy checks, 49 stage/model/control/rollback checks, 2,085 native LED/socket geometry checks and 21,938 other geometry checks passed. Stage icons visually inspected. Actual Unity construction/slot/wiring/save-load/multiplayer verification remains pending.

# Modular Switchboards 1.0.116 — original battery floor depth and material

The unfinished battery holder now uses the original deepest native APC floor geometry and material instead of the shallow gray plate. Preserve its original floor depth, vertex channels, UVs, material roles and property blocks. Expand only in X/Y to close the unfinished aperture. The completed native holder stays unchanged. The F1 unfinished image matches the deeper original floor.

Battery construction remains 5 DIN kits plus 1 Electronic Parts; cell separate. Transformer construction remains Small 5 kits plus 2 Heavy Cable Coils, Medium 8 kits plus 6 Heavy Cable Coils. Completed-only new wiring and existing save/power/slot gates remain.

Validation: native-reference build without warnings/errors; 12 production floor-selection/material-role/depth/backface checks passed. Actual Unity appearance/construction/slot/wiring/save-load/multiplayer verification remains pending.

# Modular Switchboards 1.0.115 — battery completion parts and heavy transformer windings

Battery holder: 5 DIN module kits build the body; 1 Electronic Parts completes the original native holder. No Gold or Plastic Sheet is required for this completion. The removable cell remains separate. An opaque gray backing now closes the unfinished aperture, with a matching F1 stage image; the completed original holder is unchanged.

Transformer winding completion now requires Heavy Cable Coils: Small uses 5 DIN module kits plus 2 Heavy Cable Coils; Medium uses 8 DIN module kits plus 6 Heavy Cable Coils. The heavy coil prefab is resolved from the native cable catalog instead of guessing its name. Body construction, completed-only new wiring, slot/power gates, saved-stage migration and other recipes remain as before.

Validation: native-reference build without warnings/errors; 12 updated production winding/contact-priority checks and 21,938 geometry checks passed. Actual Unity appearance/construction/slot/wiring/save-load/multiplayer verification remains pending.

# Modular Switchboards 1.0.114 — restore original battery holder model

Restore the original battery holder appearance without added gray frame bars or extra gold contact pads. Five DIN module kits build the body with an empty opening; 1 g Gold completes the original native holder. The battery cell remains separately removable. Retain construction stages, old-save completion migration, power/slot gates, separate F1 stage images, and the rule allowing new wiring only on completed modules. Battery stage images now show only the original body and native holder.

Validation: native-reference build passes without warnings/errors. Recipe, migration and wiring sources remain identical to 1.0.113. Published source snapshots are preserved. Actual Unity appearance/interaction/save-load/multiplayer validation remains pending.

# Modular Switchboards 1.0.113 — battery construction, stage icons and completed-module wiring

Battery holder construction now uses 5 DIN module kits for the base, then 1 g Gold to finish. There is no Plastic Sheet requirement. The unfinished gray mounts differ visibly from the completed native holder with gold contact pads. Insert the removable battery cell only after completing the holder. Incomplete holders cannot conduct, charge or discharge. Existing completed holders migrate to the completed stage when loading older saves; new saves retain their construction stage.

New internal cables require completed modules at both endpoints. Incomplete contacts do not show wiring markers; attempting to connect displays a completion message. Existing wires are retained and can still be removed with wire cutters. A previously selected endpoint is rechecked before connecting.

F1 Build States now has separate unfinished/finished images for both transformers and the battery holder. All six new icons use the production geometry exports; transformer images retain the original winding supports and materials.

Validation: native-reference build without warnings/errors, 14 battery save/migration/conduction checks, 22 module wiring readiness checks, and 21,934 production geometry checks passed. The six stage icons were visually inspected. Actual Unity construction/slot/wiring/save-load/multiplayer verification remains pending.

# Modular Switchboards 1.0.112 — original winding supports in unfinished transformers

Based on the accepted 1.0.110 appearance, replacing the rejected 1.0.111 visual change. Unfinished Small and Medium transformers hide only the copper winding while retaining original holders, covers and leads. Small keeps its original WindingBands; Medium retains the exact gray/dark support triangles embedded in the original winding mesh. The original gray fascia is flat and coplanar behind the missing winding, without new holder primitives or a white plate. Completing construction restores the original recessed face and full winding. Kit prices, construction quantities, power gates, save migration and the state -1 startup fix remain unchanged.

Validation: native-reference build without warnings/errors; 17,422 geometry checks and 8 initialization checks pass, with exact support triangle/UV provenance verified. Actual Unity appearance, interaction and multiplayer verification remains pending.

# Modular Switchboards 1.0.110 — transformer prefab initialization fix

Fix the 1.0.109 startup failure: do not invoke native stage visualization on an unplaced transformer prefab at state -1, and do not rebuild its fitted hitbox while the native state has all children inactive. Explicitly restore shared body, terminals and controls in both placed construction stages. Completed-stage winding visibility and the 1.0.109 recipes/counts remain.

# Modular Switchboards 1.0.109 — cabinet economy and transformer construction

Cabinet kit: 60 Iron + 30 Copper, Electronics Printer only. Small uses 1 kit + 2 Plastic Sheets; Medium uses 3 kits + 5 Plastic Sheets, including reverse/collector variants.

DIN rail kit: 5 Iron. One kit per Small or Medium rail. DIN module kit: 5 Iron + 20 Copper. Other kit recipes remain unchanged; all custom kits remain exclusive to the Electronics Printer.

DIN transformers now have two construction stages. Small: 5 module kits for the body, then 3 normal Cable Coil units. Medium: 8 module kits, then 5 normal Cable Coil units. The unfinished body keeps the gray pocket backing without windings. Its terminals can be wired, but it transfers no power until finished. Aim the coil at the body to finish construction; terminal targets retain wiring priority. Native construction handles material consumption and stage dismantling. Existing completed transformers migrate to the completed stage when loading older saves.

Validation: native-reference build succeeds without warnings/errors; 28 save/XML/join-order checks, 12 winding-versus-terminal routing checks, and 4,791 power-engine regression checks pass. Actual Unity stage rendering, construction interaction and multiplayer still need in-game testing.

# Local 1.0.108 — ready, not uploaded

Last published107 commit8688521e121ef4c556852977f47de52219a5a586 tree41dacb5bcce8ddd0bd8ca329481908c54793b087. User authorized auditing all own previews/hitboxes, explicitly including door and Smart and opaque normal-model parts leaking through preview. No upload until nahraj; never Workshop publish.

See Verification/PREVIEW-HITBOX-AUDIT-1.0.108.md for complete family matrix and validation limits. New sources: OwnPreviewPolicy, CursorModelIsolation, FittedModelCollider, FittedControlSelection, FittedKitBounds, OwnPreviewAudit. Native HandleStructurePrefab only destroys registered ThingRenderer entries; unregistered added copper/native parts survived. A Priority.Last postfix now prepares a cursor-only isolation component; cached non-ghost/non-BlueprintHelper-descendant Renderer.forceRenderingOff flags are enforced in LateUpdate. No shared material mutation. Actual world renderers untouched.

Common selection now fits actual Wireframe.BlueprintBounds, transformed/scaled; fallback actual Thing.Bounds when no wireframe. Cabinet accepted box remains; native visibility/validity preserved and all own outlines get native tint. Active constructor or authoring guard preserved. All own structure families including DinTransformer and SmartContactor covered. Precise BoxCollider interaction selection applies to own controls, preserving IDs/pose.

ModelBlueprint.Build optionally filters to nearest owning Thing and includes disabled own renderers for physical-body rebuilds. Defaults keep preview behaviour. Final ModelBlueprint.Refresh installs fitted passive bodies for DinRail/DinBreaker(includingdoor)/SmartModule/SmartContactor; transformer and door constructors have explicit final install. Known passive body boxes are removed from build-state lists/lookup; dedicated controls and board surfaces retained. MeshCollider uses actual snapshot triangles. Serialized hit reference preserves prefab clone mapping. Borrowed initial mesh vs owned runtime rebuild mesh lifetimes separated. DinTransformer.ApplyWidth now tolerates removed bodyBox and uses Rebuild instead of leaking an unretained mesh for bounds. SmartContactor.ApplyWidth and DinRail.ApplySized rebuild fitted bodies. Native Structure.CachePrefabBounds retains its normal code then postfix restores fitted bounds/grid cache. Rebuild excludes mounted Things and includes temporarily disabled own renderers, but respects inactive alternate geometry.

SwitchboardKitModel.InstallBlueprint fits each custom kit Rigidbody's convex box and Bounds to combined geometry; trigger colliders retained in lookup and self/dynamic lists. Native quantities, identity, mass/hand/stack metadata not modified. Installed covers/labels already have shape/cutout-aware mesh colliders. Portable cover payload/visual/12mm carry-envelope code unchanged; dynamic selection fits preview mesh bounds.

Prefab.OnPrefabsLoaded VerifyRegistration calls OwnPreviewAudit.Verify for blueprint mesh/renderer and fitted-body presence diagnostics. Native API Release0warnings/errors. ModelBlueprint154 own-audit +29 general checks; supporting kit38/transformer-layout10006/Output-upgrade11/rail39/doorgeometry9395/doorplacement73/cover100/nativehelpers213/placement1414/casing2367 regressions passed. Stub tests do not prove real Unity/PhysX/Mono/MP/save/load/runtime visual behaviour.107sourceZIP1055entries still byte-match107snapshot. Power, wire protocol, accepted cabinet preview, casing collision, native connection detection, portable cover payload source files verified unchanged.

All modifications atomically replace hardlinked snapshot files. Source artifacts retained. SDK8.0.426 under/tmp/switchboard-dotnet; standardtask DOTNET_CLI_HOME/XDG_DATA_HOME/XDG_CONFIG_HOME/NUGET_PACKAGES. Native references work/build-deps, LibConstructPath needs /LibConstruct/LibConstruct.dll. Packaging work/archive1108.py, manifestwork/release1108-artifacts.json authoritative whencomplete.
