from pathlib import Path
r=Path(__file__).resolve().parents[2]
s=(r/'Source/SmartContactor.cs').read_text()
def method(signature):
 a=s.index(signature);arrow=s.find('=>',a);brace=s.find('{',a)
 if arrow>=0 and arrow<brace:return s[a:s.index(';',arrow)+1]
 depth=0
 for i in range(brace,len(s)):
  if s[i]=='{':depth+=1
  elif s[i]=='}':
   depth-=1
   if depth==0:return s[a:i+1]
parts=[method(x)for x in ['internal bool IndicatorPowered','internal bool BusPowered','internal bool Conducting','private static bool DisplayProperty','public override bool CanLogicRead','public override bool CanLogicWrite','public override void SetLogicValue','public override double GetLogicValue','internal void ResetProgramCommand']]
out=Path(__file__).parent/'ProxyExtracted.cs';tmp=out.with_suffix('.tmp165');tmp.write_text('namespace ModularSwitchboards {class SmartContactor:Device {internal DoorSmartDisplay Display;internal bool IsStructureCompleted=true,IsCursor,IsBeingDestroyed;internal int OutputAddress;internal SmartModule Core;'+''.join(parts)+'}}');tmp.replace(out)

core=(r/'Source/SmartModule.cs').read_text();a=core.index('        private void ResetOutputCommands()');b=core.index('        public string GetSourceCode()',a)
out=Path(__file__).parent/'CoreResetExtracted.cs';tmp=out.with_name(out.name+'.extracttmp')
tmp.write_text('using System.Linq;namespace ModularSwitchboards {class SmartModule {internal bool OutputsReady=true;internal object Chip=new object();internal bool Powered=true,OnOff=true;internal SmartContactor[] Outputs;'+core[a:b]+'internal void Reset()=>ResetOutputCommands();}static class SmartBus{internal static SmartModule Core(SmartContactor output)=>output.Core;internal static SmartContactor OutputAt(SmartModule core,int address)=>core.Outputs.FirstOrDefault(o=>o.OutputAddress==address);internal static System.Collections.Generic.IEnumerable<SmartContactor> PowerOutputs(SmartModule core)=>core.Outputs;}}');tmp.replace(out)
