"""Render DIN-front thumbnails for the F1 catalog (no game textures required)."""
import bpy,math
from pathlib import Path
from mathutils import Vector
root=Path(__file__).resolve().parents[1]
# The casing dimensions/scales match DinBreakerModel. These compact front
# illustrations distinguish the cartridge, APC battery bay and analyzer in F1.
for kind,slots in [('DinFuse',1),('DinBattery',2),('DinAnalyser',3),('InnerCover',1)]:
 bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
 mats=[]
 for name,rgb in [('White',(.75,.77,.78)),('Dark',(.035,.045,.045)),('Grey',(.26,.30,.30)),('Gold',(.8,.62,.06)),('Green',(.12,.52,.22)),('Lightning',(.75,.19,.025))]:
  m=bpy.data.materials.new(name);m.diffuse_color=(*rgb,1);m.use_nodes=True;n=m.node_tree.nodes.get('Principled BSDF');n.inputs['Base Color'].default_value=(*rgb,1);n.inputs['Roughness'].default_value=.65;mats.append(m)
 def box(role,x,y,z,w,h,d):
  bpy.ops.mesh.primitive_cube_add(size=1,location=(x,-z,y));o=bpy.context.object;o.dimensions=(w,d,h);bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.append(mats[role]);bevel=o.modifiers.new('edge','BEVEL');bevel.width=min(.0012,w*.08,h*.08,d*.3);bevel.segments=2
 def poly(role,points,z):
  me=bpy.data.meshes.new('front');me.from_pydata([(x,-z,y)for x,y in points],[],[tuple(range(len(points)))]);ob=bpy.data.objects.new('front',me);bpy.context.collection.objects.link(ob);me.materials.append(mats[role])
 width=.0396+(slots-1)*.0405
 if kind=='InnerCover':
  # Same small-cabinet panel proportions; rows remain open for module faces.
  for y,h in [(-.19,.106),(0,.144),(.19,.106)]:box(2,0,y,.1015,.386,h,.002)
  for x in [-.18,.18]:box(2,x,0,.1015,.026,.486,.002)
  scale=.60;target=(0,-.1,0)
 else:
  box(0,0,0,.03335,width,.10125,.0644);box(0,0,0,.09985,width,.0702,.0092)
  for side in [-1,1]:box(2,0,side*.0405,.100,width*.4,.008,.0015)
  if kind=='DinFuse':
   box(1,0,0,.106,.030,.061,.002);box(2,0,0,.107,.023,.056,.002)
   bpy.ops.mesh.primitive_cylinder_add(vertices=32,radius=.006,depth=.039,location=(0,-.116,0));bpy.context.object.data.materials.append(mats[4])
   for y in [-.022,.022]:
    bpy.ops.mesh.primitive_cylinder_add(vertices=32,radius=.0066,depth=.005,location=(0,-.116,y));bpy.context.object.data.materials.append(mats[0])
  elif kind=='DinBattery':
   box(2,0,0,.106,.062,.064,.001)
   points=[(-.025,-.022),(-.022,-.026),(.022,-.026),(.026,-.022),(.026,.022),(.022,.026),(-.022,.026),(-.026,.022)]
   poly(1,points,.108);box(2,0,0,.109,.028,.036,.001)
   for y in [-.015,.015]:
    for x in [-.009,0,.009]:box(3,x,y,.110,.005,.006,.001)
  else:
   box(2,0,0,.106,width-.005,.062,.001)
   points=[(-.053,-.020),(-.047,-.026),(.024,-.026),(.030,-.020),(.030,.020),(.024,.026),(-.047,.026),(-.053,.020)]
   poly(1,points,.108);poly(4,[(x*.94,y*.88)for x,y in points],.109)
   poly(5,[(.047,.022),(.037,-.002),(.044,-.002),(.039,-.022),(.054,.006),(.046,.006)],.110)
  scale=max(.155,width*1.45);target=(0,-.060,0)
 scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=48;scene.cycles.use_denoising=False;scene.render.resolution_x=256;scene.render.resolution_y=256;scene.render.resolution_percentage=100;scene.render.film_transparent=True;scene.world.color=(.35,.35,.35);scene.view_settings.exposure=-1.5
 bpy.ops.object.camera_add(location=(scale*.5,-scale*1.9,scale*.7));cam=bpy.context.object;cam.rotation_euler=(Vector(target)-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=scale;scene.camera=cam
 for loc,power in [((.1,-.3,.4),40),((-.3,.1,.2),25)]:
  bpy.ops.object.light_add(type='AREA',location=loc);bpy.context.object.data.energy=power;bpy.context.object.data.size=.5
 scene.render.filepath=str(root/'Assets/Icons'/(kind+'.png'));bpy.ops.render.render(write_still=True)
