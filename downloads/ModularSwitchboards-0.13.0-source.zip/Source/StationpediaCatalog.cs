using System;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
namespace ModularSwitchboards
{
    // Search terms are separate from long visible descriptions, which vanilla
    // deliberately refuses to search beyond 255 characters.
    internal static class StationpediaCatalog
    {
        internal static string Kind(string name)
        {
            if(name==SwitchboardsMod.KitName||name==SwitchboardsMod.CabinetName)return "cabinet";
            if(name==SwitchboardsMod.CoverKitName||name==SwitchboardsMod.CoverName)return "cover";
            if(name==SwitchboardsMod.RailKitName||name==SwitchboardsMod.RailName)return "rail";
            if(name==SwitchboardsMod.BreakerKitName)return "modules";
            if(DinModuleCatalog.Specs.TryGetValue(name??"",out var spec)&&spec.Selectable)
                return spec.Analyser?"analyser":spec.Battery?"battery":spec.Fuse?"fuse":"breaker";
            return null;
        }
        internal static string Terms(string name)
        {
            var kind=Kind(name);if(kind==null)return null;
            string common="modular switchboards electronics electronic elektrika elektro din ";
            switch(kind)
            {
                case "cabinet":return common+"switchboard cabinet enclosure rozvadec rozvadece rozvodnice skrin skrinka elektricky rozvadec electrical panel";
                case "cover":return common+"inner cover front cover dead front kryt krytu krytka zakryt panel rozvadec";
                case "rail":return common+"din rail mounting rail lista listy listu list dinlista uchyceni montazni lista rozvadec";
                case "modules":return common+"kit modules modul moduly jistice jistice pojistky baterie baterka analyzer analyser analyzator elektromer breaker fuse battery";
                case "battery":return common+"battery backup holder apc baterie baterka akumulator zaloha zalozni bateriovy modul drzak";
                case "analyser":return common+"cable analyzer analyser analyzator analizator kabelu elektromer merak mereni spotreba vykon watt wattmeter meter energy monitor";
                case "fuse":return common+"fuse holder cartridge cable fuse pojistka pojistky pojistek pojistkovy drzak patrona "+DinModuleCatalog.Specs[name].Title;
                default:return common+"circuit breaker breaker jistice jistic jistice jisticu jisticovy vypinac ochrana "+DinModuleCatalog.Specs[name].Title;
            }
        }
        internal static string Normalize(string text)
        {
            if(string.IsNullOrEmpty(text))return "";
            var result=new StringBuilder();
            foreach(char c in text.Normalize(NormalizationForm.FormD))
                if(CharUnicodeInfo.GetUnicodeCategory(c)!=UnicodeCategory.NonSpacingMark)result.Append(c);
            return result.ToString().Normalize(NormalizationForm.FormC);
        }
        internal static bool Matches(string name,string pattern)
        {
            var terms=Terms(name);if(terms==null||string.IsNullOrWhiteSpace(pattern)||pattern.Length>1024)return false;
            try{return Regex.IsMatch(Normalize(terms),Normalize(pattern),RegexOptions.IgnoreCase|RegexOptions.CultureInvariant|RegexOptions.IgnorePatternWhitespace,TimeSpan.FromMilliseconds(50));}
            catch(ArgumentException){return false;}catch(RegexMatchTimeoutException){return false;}
        }
    }
}
