using System;using System.Collections.Generic;using UnityEngine;namespace ModularSwitchboards {static class WireContactLayout{        internal const float BreakerEntryY=.0375f,BreakerEntryZ=.029f,BreakerScrewY=.030f,BreakerScrewZ=.0595f;}static partial class DinBreakerModel{        internal static Mesh Build(float width=.0176f,float centerX=0f,bool battery=false)
        {
            var vertices=new List<Vector3>();var normals=new List<Vector3>();var triangles=new List<int>[5];
            for(int i=0;i<5;i++)triangles[i]=new List<int>();
            System.Action<Vector3,Vector3,int,float> shape=(center,size,role,radius)=>
            {
                center.x+=centerX;
                if(!battery){RoundedGeometry.Box(vertices,normals,triangles[role],center,size,radius);return;}
                // Same breaker surfaces, with only the seated battery aperture cut out.
                float holeX=(ApcBatteryRegion.SocketHeight+.0006f)/VisualScale.x;
                float holeY=(ApcBatteryRegion.SocketHeight+.0006f)/VisualScale.y;
                BatteryAperture.Box(vertices,normals,triangles[role],center,size,radius,holeX,holeY);
            };
            shape(new Vector3(0,0,.029f),new Vector3(width,.075f,.056f),1,.0018f);
            shape(new Vector3(0,0,.059f),new Vector3(width,.052f,.008f),1,.0015f);
            shape(new Vector3(0,0,.0635f),new Vector3(width-.0046f,.045f,.001f),3,.0004f);
            if(battery)RoundedGeometry.Box(vertices,normals,triangles[1],new Vector3(centerX,0,.003f),new Vector3(width,.075f,.002f),.0007f);
            foreach(float side in new[]{-1f,1f})
            {
                RoundedGeometry.Box(vertices,normals,triangles[4],new Vector3(centerX,side*.03f,.0577f),new Vector3(.009f,.009f,.0015f),.0005f);
                RoundedGeometry.Box(vertices,normals,triangles[3],new Vector3(centerX,side*.03f,.0586f),new Vector3(.006f,.001f,.0005f),.00015f);
            }
            foreach(float side in new[]{-1f,1f})
            {
                EndDisk(vertices,normals,triangles[4],new Vector3(centerX,side*(WireContactLayout.BreakerEntryY+.0001f),WireContactLayout.BreakerEntryZ),.0042f,side);
                EndDisk(vertices,normals,triangles[3],new Vector3(centerX,side*(WireContactLayout.BreakerEntryY+.0002f),WireContactLayout.BreakerEntryZ),.0032f,side);
            }
            // Two fixed spindle bearings straddle the flap, matching the APC's mounting.
            // Their inner edges clear the 12 mm plate while enclosing its axle ends.
            if(!battery)foreach(float side in new[]{-1f,1f})
                RoundedGeometry.Box(vertices,normals,triangles[4],new Vector3(side*.0073f,0,.0667f),
                    new Vector3(.0022f,.0042f,.0048f),.0007f);
            var mesh=new Mesh{name="Switchboards.RoundedBreaker"};mesh.SetVertices(vertices);mesh.SetNormals(normals);mesh.subMeshCount=5;
            for(int i=0;i<5;i++)mesh.SetTriangles(triangles[i],i);
            CabinetGeometry.ApplyNativeUv(mesh);mesh.RecalculateBounds();return mesh;
        }
        private static void EndDisk(List<Vector3> vertices,List<Vector3> normals,List<int> triangles,Vector3 center,float worldRadius,float side)
        {
            for(int i=0;i<16;i++)
            {
                float a=i*Mathf.PI/8,b=(i+1)*Mathf.PI/8;
                var p=center+new Vector3(Mathf.Cos(a)*worldRadius/VisualScale.x,0,Mathf.Sin(a)*worldRadius/VisualScale.z);
                var q=center+new Vector3(Mathf.Cos(b)*worldRadius/VisualScale.x,0,Mathf.Sin(b)*worldRadius/VisualScale.z);
                int start=vertices.Count;vertices.AddRange(side>0?new[]{center,q,p}:new[]{center,p,q});normals.AddRange(new[]{Vector3.up*side,Vector3.up*side,Vector3.up*side});triangles.AddRange(new[]{start,start+1,start+2});
            }
        }
}}