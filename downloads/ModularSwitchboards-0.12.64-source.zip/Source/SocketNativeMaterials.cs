using System.Collections.Generic;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class SocketNativeMaterials
    {
        private static readonly Dictionary<int,Material> cache=new Dictionary<int,Material>();
        internal static Material GreyWhite(Material source)
        {
            if(source==null||!(source.mainTexture is Texture2D texture))return source;
            if(cache.TryGetValue(source.GetInstanceID(),out var saved))return saved;
            var previous=RenderTexture.active;var target=RenderTexture.GetTemporary(texture.width,texture.height,0,RenderTextureFormat.ARGB32,RenderTextureReadWrite.sRGB);
            Texture2D copy=null;
            try
            {
                Graphics.Blit(texture,target);RenderTexture.active=target;
                copy=new Texture2D(texture.width,texture.height,TextureFormat.RGBA32,true);
                copy.ReadPixels(new Rect(0,0,texture.width,texture.height),0,0);var pixels=copy.GetPixels();
                for(int i=0;i<pixels.Length;i++)pixels[i]=SocketWhitePixels.Grey(pixels[i]);
                copy.SetPixels(pixels);copy.wrapMode=texture.wrapMode;copy.filterMode=texture.filterMode;copy.anisoLevel=texture.anisoLevel;copy.name=texture.name+".SocketGrey";copy.Apply();
                var material=new Material(source){name=source.name+".SocketGrey",mainTexture=copy};cache.Add(source.GetInstanceID(),material);return material;
            }
            catch
            {
                if(copy!=null)Object.Destroy(copy);throw;
            }
            finally{RenderTexture.active=previous;RenderTexture.ReleaseTemporary(target);}
        }
    }
}
