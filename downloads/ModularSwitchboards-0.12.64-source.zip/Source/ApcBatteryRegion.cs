using UnityEngine;

namespace ModularSwitchboards
{
    internal static class ApcBatteryRegion
    {
        // Native socket height is fitted to the actual frame opening, not to
        // an unrelated 40 mm width. Depth uses the APC front plane and cell rear.
        internal const float OpeningHeight=.06075f;
        internal const float NativeFront=.211f;
        internal static float RearSource=.04753667f;
        internal static bool Contains(Vector3 p)=>p.x>=-.155f&&p.x<=-.040f&&p.y>=-.175f&&p.y<=-.060f&&p.z>=.125f&&p.z<=.212f;
        internal const float DinFace=.0635f;
        internal const float NativeSocketHeight=.10804666f;
        internal static float FitScale(Vector3 size)=>Mathf.Min(OpeningHeight/size.x,(DinFace*DinBreakerModel.VisualScale.z-.006f)/(NativeFront-RearSource));
        internal static float SocketHeight=>NativeSocketHeight*FitScale(new Vector3(NativeSocketHeight,NativeSocketHeight,0));
        internal static float Front(float scale)=>(.006f+(NativeFront-RearSource)*scale)/DinBreakerModel.VisualScale.z;
        internal static Vector3 Map(Vector3 p,Vector3 center,float minDepth,float scale)
        {
            return new Vector3(DinBatteryLayout.CenterX-(p.y-center.y)*scale/DinBreakerModel.VisualScale.x,
                (p.x-center.x)*scale/DinBreakerModel.VisualScale.y,
                (.006f+(p.z-RearSource)*scale)/DinBreakerModel.VisualScale.z);
        }
    }
}
