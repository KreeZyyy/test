using System.Linq;
using System.Xml.Serialization;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Networking;
using Assets.Scripts.Objects;
using Assets.Scripts.Localization2;
using LibConstruct;
using UnityEngine;

namespace ModularSwitchboards
{
    public sealed class DinRailSaveData : StructureSaveData
    {
        [XmlElement] public PlacementBoardStructureSaveData RailBoard;
    }

    public sealed class DinRail : Structure, IPlacementBoardStructure
    {
        public PlacementBoard Board { get; set; }
        public PlacementBoard.BoardCell[] BoardCells { get; set; }
        public override void Awake()
        {
            base.Awake();
            BoardStructureHooks.Awake(this);
            DinRailModel.Refresh(this);
        }
        public override Grid3 GetLocalGrid() => Board == null ? default(Grid3) : Board.WorldToGrid(Transform.position);

        internal static bool CanPlace(PlacementBoard board, Grid3 position, int rotation)
        {
            if (!(board is CabinetRailBoard) || !(board.PrimaryHost is SwitchboardCabinet host) || !host.CanFitRails)
                return false;
            if (!DinLayout.IsRailPosition(position.x, position.y, position.z, rotation)) return false;
            return !board.Structures.OfType<DinRail>().Any(r =>
                board.WorldToGrid(r.Transform.position).y == position.y);
        }
        public override CanConstructInfo CanConstruct()
        {
            if (Board == null) return CanConstructInfo.InvalidPlacement("Open a completed switchboard cabinet.");
            var position = Board.WorldToGrid(Transform.position);
            if (IsCursor)
            {
                position = new Grid3(0, DinLayout.SnapRow(position.y), 0);
                Transform.SetPositionAndRotation(Board.GridToWorld(position), Board.IndexToRotation(0));
            }
            return CanPlace(Board, position, Board.RotationToIndex(Transform.rotation))
                ? CanConstructInfo.ValidPlacement
                : CanConstructInfo.InvalidPlacement("Open the cabinet and choose an empty DIN row.");
        }
        protected override CanConstructInfo CanDeconstruct()
            => Board?.PrimaryHost is SwitchboardCabinet host && host.CanFitRails
                ? CanConstructInfo.ValidPlacement : CanConstructInfo.InvalidPlacement("Open the cabinet first.");
        public override DelayedActionInstance AttackWith(Attack attack, bool doAction = true)
        {
            if (!(Board?.PrimaryHost is SwitchboardCabinet host) || !host.CanFitRails) return null;
            return base.AttackWith(attack, doAction);
        }
        public override void OnDeregistered()
        {
            base.OnDeregistered();
            if (Board != null) BoardStructureHooks.OnDeregistered(this);
        }
        public override ThingSaveData SerializeSave()
        {
            ThingSaveData data = new DinRailSaveData();
            InitialiseSaveData(ref data);
            return data;
        }
        protected override void InitialiseSaveData(ref ThingSaveData data)
        {
            base.InitialiseSaveData(ref data);
            if (data is DinRailSaveData save && Board != null)
                save.RailBoard = BoardStructureHooks.SerializeSave(this);
        }
        public override void DeserializeSave(ThingSaveData data)
        {
            base.DeserializeSave(data);
            if (data is DinRailSaveData save && save.RailBoard != null)
                BoardStructureHooks.DeserializeSave(this, save.RailBoard);
        }
        public override void SerializeOnJoin(RocketBinaryWriter writer)
        {
            base.SerializeOnJoin(writer);
            BoardStructureHooks.SerializeOnJoin(writer, this);
        }
        public override void DeserializeOnJoin(RocketBinaryReader reader)
        {
            base.DeserializeOnJoin(reader);
            BoardStructureHooks.DeserializeOnJoin(reader, this);
        }
    }
}
