using System;
using UnityEngine;
namespace ModularSwitchboards
{
    // Private materials for our authored carton, webbing and frame.
    internal static class CabinetKitSurface
    {
        internal const string RendererName="Switchboards.CabinetPackage";
        private static Material[] materials;
        internal static Material[] Materials
        {
            get
            {
                if(materials!=null)return materials;
                var shader=Shader.Find("Standard");
                if(shader==null||!shader.isSupported)throw new InvalidOperationException("Cabinet package shader unavailable");
                var colours=new[]{new Color(.070f,.075f,.072f),new Color(.87f,.86f,.79f),
                    new Color(.48f,.34f,.20f),new Color(.28f,.17f,.085f),new Color(.43f,.48f,.49f)};
                materials=new Material[colours.Length];
                for(int i=0;i<materials.Length;i++)
                {
                    var m=new Material(shader){name="Switchboards.CabinetPackage.Surface"+i,color=colours[i]};
                    m.SetFloat("_Glossiness",i==4?.26f:.08f);m.SetFloat("_Metallic",i==4?.45f:0f);materials[i]=m;
                }
                return materials;
            }
        }
        internal static void Refresh(MeshRenderer renderer)
        {
            renderer.SetPropertyBlock(null);
            for(int i=0;i<renderer.sharedMaterials.Length;i++)renderer.SetPropertyBlock(null,i);
            renderer.sharedMaterials=Materials;
        }
    }
}
