using System.Collections.Generic;
using UnityEngine;
namespace ModularSwitchboards
{
    internal enum SwitchboardKitKind{Cabinet,Rails,Modules,Cover}
    internal static class SwitchboardKitGeometry
    {
        internal static float Fit(Vector3 envelope,Vector3 size)=>Mathf.Min(envelope.x/size.x,Mathf.Min(envelope.y/size.y,envelope.z/size.z))*.92f;
        internal static Mesh Build(SwitchboardKitKind kind)
        {
            if(kind==SwitchboardKitKind.Cabinet)return CabinetPackage();
            var v=new List<Vector3>();var n=new List<Vector3>();var t=new[]{new List<int>(),new List<int>(),new List<int>(),new List<int>(),new List<int>()};
            System.Action<int,float,float,float,float,float,float> box=(role,x,y,z,w,h,d)=>RoundedGeometry.Box(v,n,t[role],new Vector3(x,y,z),new Vector3(w,h,d),.0025f);
            bool cabinet=kind==SwitchboardKitKind.Cabinet,cover=kind==SwitchboardKitKind.Cover,rails=kind==SwitchboardKitKind.Rails;
            float width=cabinet?.400f:cover?.360f:rails?.330f:.280f;
            float depth=cabinet?.280f:cover?.260f:rails?.200f:.240f;
            float wall=cabinet?.135f:cover?.090f:.110f,floor=-wall*.5f;
            // Open transport tray: real bottom, walls, reinforced rim and feet.
            box(3,0,floor,0,width,.014f,depth);
            foreach(float side in new[]{-1f,1f})
            {
                box(3,side*(width*.5f-.007f),floor+wall*.5f,0,.014f,wall,depth);
                box(4,side*(width*.5f-.006f),floor+wall+.003f,0,.020f,.012f,depth+.008f);
                box(3,0,floor+wall*.34f,side*(depth*.5f-.007f),width-.026f,wall*.68f,.014f);
                box(4,0,floor+wall*.70f,side*(depth*.5f-.006f),width,.012f,.020f);
                foreach(float x in new[]{-width*.5f+.014f,width*.5f-.014f})
                {
                    box(4,x,floor+wall*.5f,side*(depth*.5f-.014f),.022f,wall+.014f,.022f);
                    box(0,x,floor-.013f,side*(depth*.5f-.025f),.032f,.018f,.040f);
                }
                // Recessed dark carry grips read clearly even in small menu icons.
                box(0,side*(width*.5f+.001f),floor+wall*.60f,0,.003f,.018f,depth*.28f);
            }
            if(cabinet)
            {
                // Loose enclosure panels, upright channels and a rectangular frame.
                for(int i=0;i<3;i++)box(2,-.065f+i*.006f,floor+.020f+i*.015f,.012f,.210f,.009f,.204f);
                foreach(float x in new[]{.074f,.112f,.150f})
                {
                    box(4,x,floor+.028f,0,.023f,.012f,.214f);
                    foreach(float side in new[]{-1f,1f})box(2,x+side*.010f,floor+.043f,0,.004f,.025f,.214f);
                }
                foreach(float z in new[]{-.080f,.080f})box(4,-.033f,floor+.099f,z,.270f,.018f,.018f);
                foreach(float x in new[]{-.159f,.093f})box(4,x,floor+.099f,0,.018f,.018f,.160f);
            }
            else if(cover)
            {
                // A stack of panels rather than one thin plate: mounting hardware
                // occupies a separate, visibly partitioned compartment.
                for(int i=0;i<4;i++)box(i%2==0?2:4,-.037f+i*.005f,floor+.020f+i*.012f,.003f,.235f,.008f,.206f);
                box(0,.104f,floor+.040f,0,.006f,.065f,.222f);
                foreach(float z in new[]{-.073f,-.024f,.025f,.074f})
                {
                    box(4,.137f,floor+.025f,z,.030f,.015f,.026f);
                    box(0,.137f,floor+.034f,z,.014f,.003f,.003f);
                }
                // Two retaining crossbars expose the stepped panel edges.
                foreach(float z in new[]{-.070f,.070f})box(4,-.029f,floor+.071f,z,.246f,.010f,.012f);
            }
            else if(rails)
            {
                // Three separate U channels, their open sections and fixing slots
                // remain readable from the top instead of hiding behind a lid.
                foreach(float z in new[]{-.059f,0,.059f})
                {
                    box(4,0,floor+.022f,z,.284f,.012f,.040f);
                    foreach(float side in new[]{-1f,1f})box(2,0,floor+.041f,z+side*.018f,.284f,.030f,.006f);
                    foreach(float x in new[]{-.099f,-.033f,.033f,.099f})box(0,x,floor+.029f,z,.025f,.002f,.010f);
                }
            }
            else
            {
                // Neutral unfinished module bodies in padded dividers. No rating
                // colours: this shared kit must suit every module variant.
                foreach(float x in new[]{-.082f,0,.082f})
                {
                    box(0,x,floor+.020f,0,.073f,.025f,.194f);
                    box(2,x,floor+.045f,0,.057f,.053f,.154f);
                    box(3,x,floor+.075f,0,.042f,.008f,.091f);
                    foreach(float z in new[]{-.063f,.063f})
                    {
                        box(4,x,floor+.075f,z,.033f,.007f,.022f);
                        box(0,x,floor+.079f,z,.020f,.002f,.003f);
                    }
                }
            }
            Label(box,kind,0,floor+wall*.30f,depth*.5f+.004f,.078f,.029f);
            var mesh=new Mesh{name="Switchboards.Kit."+kind};mesh.SetVertices(v);mesh.SetNormals(n);mesh.subMeshCount=5;
            for(int i=0;i<5;i++)mesh.SetTriangles(t[i],i);
            CabinetGeometry.ApplyNativeUv(mesh);mesh.RecalculateBounds();return mesh;
        }
        // Original transport package, authored from dimensions of our mounting
        // skeleton. Console kit is a visual reference only; no external mesh/material.
        private static Mesh CabinetPackage()
        {
            var v=new List<Vector3>();var n=new List<Vector3>();
            var t=new[]{new List<int>(),new List<int>(),new List<int>(),new List<int>(),new List<int>()};
            System.Action<int,float,float,float,float,float,float> box=(role,x,y,z,w,h,d)=>
                RoundedGeometry.Box(v,n,t[role],new Vector3(x,y,z),new Vector3(w,h,d),.0018f);
            // Closed corrugated carton, folded lid, recessed seam and taped ends.
            box(2,0,0,0,.560f,.160f,.580f);
            box(3,0,.081f,0,.558f,.003f,.006f);
            foreach(float z in new[]{-.147f,.147f})box(2,0,.084f,z,.558f,.006f,.278f);
            box(3,0,.088f,0,.555f,.002f,.035f);
            foreach(float z in new[]{-.292f,.292f})box(3,0,0,z,.035f,.154f,.002f);
            // Our rectangular cabinet skeleton packed flat, with open channel lips.
            foreach(float x in new[]{-.267f,.267f})
            {
                box(4,x,.111f,0,.026f,.026f,.668f);
                foreach(float side in new[]{-1f,1f})
                    box(4,x+side*.010f,.131f,0,.006f,.018f,.668f);
                box(0,x,.125f,0,.012f,.0015f,.616f);
            }
            foreach(float z in new[]{-.321f,.321f})
            {
                box(4,0,.111f,z,.510f,.026f,.026f);
                foreach(float side in new[]{-1f,1f})
                    box(4,0,.131f,z+side*.010f,.510f,.018f,.006f);
                box(0,0,.125f,z,.477f,.0015f,.012f);
            }
            // Protect projecting frame ends with cardboard packing shoes.
            foreach(float z in new[]{-.316f,.316f})
                box(2,0,.067f,z,.558f,.031f,.052f);
            // Two continuous bands around the carton and frame; front metal buckles.
            foreach(float x in new[]{-.179f,.179f})
            {
                box(0,x,.146f,0,.023f,.006f,.688f);
                box(0,x,-.084f,0,.023f,.006f,.596f);
                foreach(float side in new[]{-1f,1f})
                {
                    PackageBand(v,n,t[0],x,.146f,side*.344f,.063f,side*.344f);
                    PackageBand(v,n,t[0],x,.063f,side*.344f,.043f,side*.298f);
                    PackageBand(v,n,t[0],x,.043f,side*.298f,-.084f,side*.298f);
                }
                box(4,x,.012f,.304f,.035f,.042f,.008f);
                box(0,x,.012f,.309f,.020f,.026f,.003f);
                box(4,x,.011f,.312f,.025f,.005f,.004f);
                box(0,x,-.028f,.305f,.023f,.034f,.005f);
            }
            // Printed assembly label: frame silhouette and small packing stripes.
            box(1,.035f,-.002f,.293f,.175f,.084f,.003f);
            foreach(float x in new[]{-.022f,.022f})
                box(0,x+.006f,.005f,.2955f,.003f,.043f,.0015f);
            foreach(float y in new[]{-.016f,.026f})
                box(0,.006f,y,.2955f,.046f,.003f,.0015f);
            foreach(float y in new[]{-.018f,-.007f,.004f,.015f,.026f})
                box(3,.075f,y,.2955f,.043f,.003f,.0015f);
            // Folded edge reinforcements expose the carton construction.
            foreach(float x in new[]{-.282f,.282f})
                foreach(float z in new[]{-.259f,.259f})
                    box(3,x,-.002f,z,.003f,.145f,.034f);
            var mesh=new Mesh{name="Switchboards.Kit.Cabinet"};mesh.SetVertices(v);mesh.SetNormals(n);mesh.subMeshCount=5;
            for(int i=0;i<5;i++)mesh.SetTriangles(t[i],i);
            CabinetGeometry.ApplyNativeUv(mesh);mesh.RecalculateBounds();return mesh;
        }
        private static void PackageBand(List<Vector3> v,List<Vector3> n,List<int> t,float x,float y1,float z1,float y2,float z2)
        {
            float dy=y2-y1,dz=z2-z1,length=(float)System.Math.Sqrt(dy*dy+dz*dz);
            float cy=dy/length,sz=dz/length;int first=v.Count;
            RoundedGeometry.Box(v,n,t,new Vector3(0,0,0),new Vector3(.023f,length,.006f),.001f);
            for(int i=first;i<v.Count;i++)
            {
                var p=v[i];v[i]=new Vector3(x+p.x,(y1+y2)*.5f+p.y*cy-p.z*sz,(z1+z2)*.5f+p.y*sz+p.z*cy);
                p=n[i];n[i]=new Vector3(p.x,p.y*cy-p.z*sz,p.y*sz+p.z*cy);
            }
        }
        private static void Label(System.Action<int,float,float,float,float,float,float> box,SwitchboardKitKind kind,float x,float y,float z,float w,float h)
        {
            box(1,x,y,z,w,h,.003f);float front=z+.0025f,stroke=.002f;
            if(kind==SwitchboardKitKind.Modules)
            {
                foreach(float offset in new[]{-.018f,0,.018f})box(0,x+offset,y,front,.010f,h*.65f,.0015f);
            }
            else if(kind==SwitchboardKitKind.Rails)
            {
                foreach(float offset in new[]{-h*.18f,h*.18f})box(0,x,y+offset,front,w*.68f,stroke,.0015f);
            }
            else
            {
                float sw=w*.55f,sh=h*.65f;
                foreach(float side in new[]{-1f,1f}){box(0,x+side*sw*.5f,y,front,stroke,sh,.0015f);box(0,x,y+side*sh*.5f,front,sw,stroke,.0015f);}
                if(kind==SwitchboardKitKind.Cabinet)box(0,x+sw*.28f,y,front,stroke,sh*.22f,.0015f);
                else box(0,x,y,front,sw*.65f,stroke,.0015f);
            }
        }
    }
}
