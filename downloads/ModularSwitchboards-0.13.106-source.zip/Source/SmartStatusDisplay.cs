using System.Globalization;
using System.Text.RegularExpressions;
namespace ModularSwitchboards
{
    internal static class SmartStatusDisplay
    {
        internal static string Text(SmartRunState state,int line)
        {
            if(state==SmartRunState.Off)return "";
            if(state==SmartRunState.Running)return "RUN";
            if(state==SmartRunState.Fault)return line<0?"ERR":"ERR"+line.ToString(CultureInfo.InvariantCulture);
            return "IDLE";
        }
        internal static int LuaLine(string detail)
        {
            if(string.IsNullOrWhiteSpace(detail))return -1;
            var match=Regex.Match(detail,@"(?:\]:|\bline\s+)(\d+)",RegexOptions.IgnoreCase);
            return match.Success&&int.TryParse(match.Groups[1].Value,NumberStyles.None,CultureInfo.InvariantCulture,out var line)?line:-1;
        }
    }
}
