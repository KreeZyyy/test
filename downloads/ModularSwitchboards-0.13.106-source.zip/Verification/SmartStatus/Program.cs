using System;
using ModularSwitchboards;
class Program{
 static int checks;static void Check(bool b){checks++;if(!b)throw new Exception("Status check "+checks);}
 static void Main(){
 Check(SmartStatusDisplay.Text(SmartRunState.Running,-1)=="RUN");
 Check(SmartStatusDisplay.Text(SmartRunState.Fault,4)=="ERR4");
 Check(SmartStatusDisplay.Text(SmartRunState.Fault,0)=="ERR0");
 Check(SmartStatusDisplay.Text(SmartRunState.Fault,127)=="ERR127");
 Check(SmartStatusDisplay.Text(SmartRunState.Fault,-1)=="ERR");
 Check(SmartStatusDisplay.Text(SmartRunState.Off,4)=="");
 Check(SmartStatusDisplay.Text(SmartRunState.Idle,-1)=="IDLE");
 Check(SmartStatusDisplay.LuaLine("Compile error: [string \"script\"]:12: syntax error near 'db'")==12);
 Check(SmartStatusDisplay.LuaLine("runtime error (line 7)")==7);
 Check(SmartStatusDisplay.LuaLine("38 bytes; runtime unavailable")==-1);
 Check(SmartStatusDisplay.LuaLine(null)==-1);
 Check(SmartRunStatus.Evaluate(false,true,true,true,true,true,false)==SmartRunState.Off);
 Check(SmartRunStatus.Evaluate(true,true,true,true,true,true,false)==SmartRunState.Fault);
 Check(SmartRunStatus.Evaluate(true,true,true,false,true,true,false)==SmartRunState.Running);
 Check(SmartRunStatus.Evaluate(true,true,false,false,false,false,false)==SmartRunState.Idle);
 Console.WriteLine(checks+" housing status display checks passed: RUN/ERR/row/idle/power and optional Lua line parsing.");
 }
}
