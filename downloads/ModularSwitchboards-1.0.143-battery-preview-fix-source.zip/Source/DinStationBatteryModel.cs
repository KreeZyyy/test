using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Assets.Scripts;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Electrical;
using Assets.Scripts.UI;
using HarmonyLib;
using Rendering;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class DinStationBatteryModel
    {
        internal static void Install(DinStationBattery owner,Transform storage)
        {
            if(GameManager.IsBatchMode){InstallHeadless(owner,storage);return;}
            var model=new GameObject("NativeStationBatteryModel"){layer=owner.gameObject.layer};
            var children=owner.transform.Cast<Transform>().ToArray();model.transform.SetParent(owner.transform,false);
            foreach(var child in children)child.SetParent(model.transform,false);
            var mapped=new Dictionary<UnityEngine.Object,UnityEngine.Object>();
            var filter=owner.GetComponent<MeshFilter>();var renderer=owner.GetComponent<MeshRenderer>();
            if(filter!=null){model.AddComponent<MeshFilter>().sharedMesh=filter.sharedMesh;mapped[filter]=model.GetComponent<MeshFilter>();}
            if(renderer!=null){var r=model.AddComponent<MeshRenderer>();r.sharedMaterials=renderer.sharedMaterials;r.enabled=renderer.enabled;r.shadowCastingMode=renderer.shadowCastingMode;r.receiveShadows=renderer.receiveShadows;r.lightProbeUsage=renderer.lightProbeUsage;r.reflectionProbeUsage=renderer.reflectionProbeUsage;mapped[renderer]=r;}
            foreach(var hit in owner.GetComponents<Collider>())
            {
                Collider clone=null;
                if(hit is BoxCollider b){var c=model.AddComponent<BoxCollider>();c.center=b.center;c.size=b.size;clone=c;}
                else if(hit is SphereCollider s){var c=model.AddComponent<SphereCollider>();c.center=s.center;c.radius=s.radius;clone=c;}
                else if(hit is CapsuleCollider k){var c=model.AddComponent<CapsuleCollider>();c.center=k.center;c.radius=k.radius;c.height=k.height;c.direction=k.direction;clone=c;}
                else if(hit is MeshCollider m){var c=model.AddComponent<MeshCollider>();c.sharedMesh=m.sharedMesh;c.convex=m.convex;clone=c;}
                if(clone==null)throw new InvalidOperationException("Unsupported native battery collider: "+hit.GetType().Name);
                clone.isTrigger=hit.isTrigger;clone.enabled=hit.enabled;clone.sharedMaterial=hit.sharedMaterial;mapped[hit]=clone;
            }
            var animator=owner.GetComponent<Animator>();
            if(animator!=null){var a=model.AddComponent<Animator>();a.runtimeAnimatorController=animator.runtimeAnimatorController;a.avatar=animator.avatar;a.applyRootMotion=animator.applyRootMotion;a.updateMode=animator.updateMode;a.cullingMode=animator.cullingMode;mapped[animator]=a;}
            // Serialized native helpers, build state references, and indicator arrays
            // must all follow any components moved off the placement root.
            Rebind(owner,mapped);foreach(var script in owner.GetComponentsInChildren<MonoBehaviour>(true))Rebind(script,mapped);
            foreach(var control in owner.Interactables)Rebind(control,mapped);
            foreach(var state in owner.BuildStates){Rebind(state,mapped);foreach(var control in state.Interactables)Rebind(control,mapped);state.StateMeshes=new List<Mesh>();state.RendererInstance=null;AccessTools.Field(typeof(BuildState),"initialDrawData").SetValue(state,new DrawData{mesh=null,materials=new Material[0]});}
            foreach(var old in mapped.Keys)UnityEngine.Object.DestroyImmediate(old);
            // All rotations/scaling live below the board root, so its snapping and
            // saved orientation remain identical to every other DIN module.
            var bounds=BoundsOf(model.transform,owner.transform);
            float frontZ=owner.Screen!=null?owner.transform.InverseTransformPoint(owner.Screen.transform.position).z:bounds.center.z;
            var rotation=Quaternion.Euler(0,frontZ<bounds.center.z-.0001f?180:0,owner.LargeVariant?90:0);
            var oriented=CabinetWallMount.TransformedBounds(bounds,Matrix4x4.Rotate(rotation));
            float scale=Mathf.Min((owner.ModuleWidth*DinLayout.SlotPitch-.012f)/Mathf.Max(.001f,oriented.size.x),.088f/Mathf.Max(.001f,oriented.size.y),.105f/Mathf.Max(.001f,oriented.size.z));
            model.transform.localRotation=rotation;model.transform.localScale=Vector3.one*scale;
            float centerX=(owner.ModuleWidth-1)*DinLayout.SlotPitch*.5f;
            model.transform.localPosition=new Vector3(centerX,0,.008f+oriented.size.z*scale*.5f)-oriented.center*scale;
            owner.NativeModel=model.transform;owner.PowerStored=0;
            foreach(var state in owner.BuildStates.Skip(1))
            {
                state.LinkedGameObjects=new List<GameObject>(state.LinkedGameObjects);state.LinkedGameObjects.Add(model);
                state.BlockAir=state.AlwaysBlockAir=state.BlockLight=state.BlockGravity=false;
            }
            owner.Renderers=new List<ThingRenderer>();owner.MPBRenderers.Clear();
            owner._staticColliders=new List<Collider>();owner._dynamicColliders=new List<Collider>();owner._selfColliders=new List<Collider>();
            owner.OpenEnds.Clear();owner.InputConnection=null;owner.OutputConnection=null;
            owner.structureRenderMode=StructureRenderMode.Standard;owner.UseCellPosition=false;
            owner.CustomNavMeshFilter=null;owner.ForceGridBounds.Clear();owner.BrokenBuildStates=new List<BrokenBuildState>();
            owner.StructureCollisionType=CollisionType.BlockCustom;
            // A separate mounting stage avoids sharing the final native visualizer
            // with stage zero; the native battery stages and tools follow unchanged.
            var plate=GameObject.CreatePrimitive(PrimitiveType.Cube);plate.name="Battery DIN mount";plate.layer=owner.gameObject.layer;plate.transform.SetParent(owner.transform,false);
            plate.transform.localPosition=new Vector3(centerX,0,.004f);plate.transform.localScale=new Vector3(owner.ModuleWidth*DinLayout.SlotPitch-.008f,.035f,.006f);plate.GetComponent<MeshRenderer>().sharedMaterial=CabinetGeometry.Materials[4];
            var mount=owner.BuildStates[0];mount.Visualizer=plate.GetComponent<MeshRenderer>();mount.Colliders=new List<Collider>{plate.GetComponent<Collider>()};mount.Interactables=new List<Interactable>();mount.LinkedGameObjects=new List<GameObject>{plate};mount.RenderMode=BuildStateRenderMode.OnMineAndPreviousStates;mount.InteractableParent=plate;mount.BlockAir=mount.AlwaysBlockAir=mount.BlockLight=mount.BlockGravity=false;

            owner.ModelBounds=BoundsOf(model.transform,owner.transform);
            foreach(var control in owner.Interactables)control.CacheBounds();
            owner.Bounds=owner.ModelBounds;owner.GridBounds=new GridBounds(owner);
            owner.InternalInput=new Vector3(centerX,.052f,.055f);owner.InternalOutput=new Vector3(centerX,-.052f,.055f);
            owner.InternalInputAim=owner.InternalInput;owner.InternalOutputAim=owner.InternalOutput;
            Terminal(owner,"Battery IN",owner.InternalInput);Terminal(owner,"Battery OUT",owner.InternalOutput);
            owner.CacheStates(true);
            var indicators=AccessTools.Field(typeof(Battery),"displayRenderers").GetValue(owner) as MeshRenderer[];
            owner.NativeIndicatorCount=indicators?.Length??0;
            // The renderer layout is native prefab data, not a registration
            // prerequisite. Different game builds can represent the five segments
            // using a different number of renderers. Keep the native array intact.
            if(owner.NativeIndicatorCount==0)Debug.LogWarning("[Modular Switchboards] Native battery has no indicator renderers before registration: "+owner.PrefabName);
            if(owner.InteractOnOff==null)Debug.LogWarning("[Modular Switchboards] Native battery ON/OFF is not cached before registration: "+owner.PrefabName);
            var blueprint=new GameObject("DinStationBatteryBlueprint"){layer=owner.gameObject.layer};blueprint.transform.SetParent(storage,false);
            var originalActive=owner.GetComponentsInChildren<Transform>(true).Where(t=>t!=owner.transform).ToDictionary(t=>t,t=>t.gameObject.activeSelf);
            foreach(var child in originalActive.Keys)child.gameObject.SetActive(true);
            Mesh ghost;try{ghost=ModelBlueprint.Build(owner.transform,owner,true);}finally{foreach(var item in originalActive)item.Key.gameObject.SetActive(item.Value);}
            var mf=blueprint.AddComponent<MeshFilter>();mf.sharedMesh=ghost;
            var mr=blueprint.AddComponent<MeshRenderer>();mr.sharedMaterial=CabinetGeometry.Materials[4];var wire=blueprint.AddComponent<Wireframe>();
            wire.BlueprintTransform=blueprint.transform;wire.BlueprintBounds=ghost.bounds;wire.BlueprintMeshFilter=mf;wire.BlueprintRenderer=mr;blueprint.AddComponent<CabinetBlueprint>();owner.Blueprint=blueprint;owner.BlueprintOrientVector=Vector3.zero;
            Debug.Log("[Modular Switchboards] Native DIN battery fitted: "+owner.PrefabName+", slots="+owner.ModuleWidth+", capacity="+owner.PowerMaximum+", uniform scale="+scale+", indicators="+owner.NativeIndicatorCount);
        }
        // Dedicated builds may strip native visual meshes/materials. They still
        // need the same Battery type, tools, controls, mount width and energy state.
        // Never let an unavailable presentation asset abort all prefab registration.
        private static void InstallHeadless(DinStationBattery owner,Transform storage)
        {
            foreach(var r in owner.GetComponentsInChildren<Renderer>(true))UnityEngine.Object.DestroyImmediate(r);
            foreach(var f in owner.GetComponentsInChildren<MeshFilter>(true))UnityEngine.Object.DestroyImmediate(f);
            foreach(var a in owner.GetComponentsInChildren<Animator>(true))UnityEngine.Object.DestroyImmediate(a);
            foreach(var c in owner.GetComponentsInChildren<Collider>(true))UnityEngine.Object.DestroyImmediate(c);
            owner.BaseAnimator=null;owner.NativeModel=null;owner.NativeIndicatorCount=0;
            owner.Renderers=new List<ThingRenderer>();owner.MPBRenderers.Clear();owner._staticColliders=new List<Collider>();owner._dynamicColliders=new List<Collider>();owner._selfColliders=new List<Collider>();
            owner.OpenEnds.Clear();owner.InputConnection=null;owner.OutputConnection=null;owner.PowerStored=0;owner.UseCellPosition=false;
            owner.structureRenderMode=StructureRenderMode.Standard;owner.StructureCollisionType=CollisionType.BlockCustom;owner.CustomNavMeshFilter=null;owner.ForceGridBounds.Clear();owner.BrokenBuildStates=new List<BrokenBuildState>();
            float x=(owner.ModuleWidth-1)*DinLayout.SlotPitch*.5f;
            var mesh=new Mesh{name="DIN battery server footprint"};var v=new List<Vector3>();var t=new List<int>();DinRailModel.AddBox(v,t,new Vector3(x,0,.0605f),new Vector3(owner.ModuleWidth*DinLayout.SlotPitch-.012f,.088f,.105f));mesh.SetVertices(v);mesh.SetTriangles(t,0);mesh.RecalculateNormals();mesh.RecalculateBounds();
            var body=new GameObject("Battery server footprint"){layer=owner.gameObject.layer};body.transform.SetParent(owner.transform,false);body.AddComponent<MeshFilter>().sharedMesh=mesh;
            var renderer=body.AddComponent<MeshRenderer>();renderer.sharedMaterial=CabinetGeometry.Materials[4];var hit=body.AddComponent<BoxCollider>();hit.center=mesh.bounds.center;hit.size=mesh.bounds.size;
            foreach(var control in owner.Interactables){control.Animator=null;control.Collider=control.Action==InteractableType.OnOff?hit:null;control.Parent=owner;}
            foreach(var state in owner.BuildStates)
            {
                state.Visualizer=renderer;state.StateMeshes=new List<Mesh>();state.RendererInstance=null;state.Colliders=new List<Collider>{hit};state.Interactables=owner.Interactables;state.InteractableParent=body;state.LinkedGameObjects=new List<GameObject>{body};state.RenderMode=BuildStateRenderMode.OnMineAndPreviousStates;state.BlockAir=state.AlwaysBlockAir=state.BlockLight=state.BlockGravity=false;AccessTools.Field(typeof(BuildState),"initialDrawData").SetValue(state,new DrawData{mesh=null,materials=new Material[0]});
            }
            owner.ModelBounds=owner.Bounds=mesh.bounds;owner.GridBounds=new GridBounds(owner);owner.CacheStates(true);
            owner.InternalInput=owner.InternalInputAim=new Vector3(x,.052f,.055f);owner.InternalOutput=owner.InternalOutputAim=new Vector3(x,-.052f,.055f);
            var preview=new GameObject("DIN battery server blueprint"){layer=owner.gameObject.layer};preview.transform.SetParent(storage,false);var filter=preview.AddComponent<MeshFilter>();filter.sharedMesh=mesh;var render=preview.AddComponent<MeshRenderer>();render.sharedMaterial=CabinetGeometry.Materials[4];var wire=preview.AddComponent<Wireframe>();wire.BlueprintTransform=preview.transform;wire.BlueprintBounds=mesh.bounds;wire.BlueprintMeshFilter=filter;wire.BlueprintRenderer=render;preview.AddComponent<CabinetBlueprint>();owner.Blueprint=preview;owner.BlueprintOrientVector=Vector3.zero;
            Debug.Log("[Modular Switchboards] Native DIN battery server footprint: "+owner.PrefabName+", slots="+owner.ModuleWidth+", capacity="+owner.PowerMaximum);
        }
        private static Bounds BoundsOf(Transform model,Transform root)
        {
            var result=new Bounds();bool first=true;
            foreach(var f in model.GetComponentsInChildren<MeshFilter>(true))if(f.sharedMesh!=null){var b=CabinetWallMount.TransformedBounds(f.sharedMesh.bounds,root.worldToLocalMatrix*f.transform.localToWorldMatrix);if(first){result=b;first=false;}else result.Encapsulate(b);}
            if(first)throw new InvalidOperationException("Native battery geometry missing.");return result;
        }
        private static void Rebind(object target,Dictionary<UnityEngine.Object,UnityEngine.Object> mapped)
        {
            if(target==null)return;
            for(var type=target.GetType();type!=null&&type!=typeof(MonoBehaviour)&&type!=typeof(UnityEngine.Object);type=type.BaseType)
            foreach(var f in type.GetFields(BindingFlags.Instance|BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.DeclaredOnly))
            {
                if(f.IsInitOnly||f.IsNotSerialized||(!f.IsPublic&&!f.IsDefined(typeof(SerializeField),true)))continue;var value=f.GetValue(target);
                if(value is UnityEngine.Object obj&&mapped.TryGetValue(obj,out var replacement)&&f.FieldType.IsInstanceOfType(replacement))f.SetValue(target,replacement);
                else if(value is System.Collections.IList list&&!list.IsReadOnly)for(int i=0;i<list.Count;i++)if(list[i] is UnityEngine.Object old&&mapped.TryGetValue(old,out var next))list[i]=next;
            }
        }
        private static void Terminal(DinStationBattery owner,string name,Vector3 position)
        {
            var go=GameObject.CreatePrimitive(PrimitiveType.Cube);go.name=name;go.layer=owner.gameObject.layer;go.transform.SetParent(owner.transform,false);go.transform.localPosition=position;go.transform.localScale=new Vector3(.016f,.012f,.008f);go.GetComponent<MeshRenderer>().sharedMaterial=CabinetGeometry.Materials[4];
            var screw=new GameObject(name+" screw"){layer=owner.gameObject.layer};screw.transform.SetParent(owner.transform,false);screw.transform.localScale=DinBreakerModel.VisualScale;screw.transform.localPosition=position+Vector3.forward*.005f-Vector3.Scale(HousingAddressScrew.Center,DinBreakerModel.VisualScale);
            owner.BuildStates.Last().LinkedGameObjects.Add(go);owner.BuildStates.Last().LinkedGameObjects.Add(screw);
            screw.AddComponent<MeshFilter>().sharedMesh=HousingAddressScrew.Build();
            var housing=WorldManager.Instance.SourcePrefabs.First(p=>p!=null&&p.GetType().Name=="CircuitHousing");
            NativePortSurface.Capture(housing.GetComponentsInChildren<MeshRenderer>(true).First(r=>r.name=="SphereColliderTriggerRendererButton1NoShadow"),screw.AddComponent<MeshRenderer>());
        }
    }
}
