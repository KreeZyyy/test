// Frozen C# registration from 1.0.137, executed only by this migration test.
using System;using System.Collections.Generic;using Assets.Scripts;using Assets.Scripts.Objects;using Reagents;
namespace RecipeMigrationBaseline {
class MultiConstructor{public string PrefabName;}
static class Prefab{static readonly Dictionary<string,MultiConstructor> items=new();public static T Find<T>(string name) where T:class {if(!items.ContainsKey(name))items.Add(name,new(){PrefabName=name});return items[name] as T;}}
class DynamicThingRecipeComparable{public Dictionary<MultiConstructor,WorldManager.RecipeData> AllRecipes=new();public bool AddRecipe(WorldManager.RecipeData data,object mod){AllRecipes.Add(Prefab.Find<MultiConstructor>(data.PrefabName),data);return true;}}
static class ElectronicsPrinter{public static DynamicThingRecipeComparable RecipeComparable=new();}
static class Debug{public static void Log(object x){}}
static class SwitchboardsMod{
public const string KitName = "ItemKitModularSwitchboard";
public const string CoverKitName="ItemKitSwitchboardInnerCover";
public const string RailKitName = "ItemKitDinRail";
public const string SmartKitName="ItemKitDinSmartModule";
public const string BreakerKitName = "ItemKitDinBreaker1P";
public const string DoorKitName="ItemKitSwitchboardDoorModules";
public const string LabelKitName="ItemKitSwitchboardLabels";
        public static void PrepareRecipe(DynamicThingRecipeComparable __instance)
        {
            if (!ReferenceEquals(__instance, ElectronicsPrinter.RecipeComparable)) return;
            var smartKit=Prefab.Find<MultiConstructor>(SmartKitName);
            if(smartKit!=null&&!__instance.AllRecipes.ContainsKey(smartKit))__instance.AddRecipe(SmartKitRecipe.Create(),null);
            var doorKit=Prefab.Find<MultiConstructor>(DoorKitName);
            if(doorKit!=null&&!__instance.AllRecipes.ContainsKey(doorKit))__instance.AddRecipe(new WorldManager.RecipeData{PrefabName=DoorKitName,RecipeTier=MachineTier.TierOne,Output=1f,Recipe=new Recipe{Iron=5,Copper=20,Time=3f,Energy=400f}},null);
            var labelKit=Prefab.Find<MultiConstructor>(LabelKitName);
            if(labelKit!=null&&!__instance.AllRecipes.ContainsKey(labelKit))__instance.AddRecipe(new WorldManager.RecipeData{PrefabName=LabelKitName,RecipeTier=MachineTier.TierOne,Output=1f,Recipe=new Recipe{Silicon=5,Time=2f,Energy=200f}},null);
            var coverKit=Prefab.Find<MultiConstructor>(CoverKitName);
            var kit = Prefab.Find<MultiConstructor>(KitName);
            var railKit = Prefab.Find<MultiConstructor>(RailKitName);
            if (railKit != null && !__instance.AllRecipes.ContainsKey(railKit))
                __instance.AddRecipe(new WorldManager.RecipeData {
                    PrefabName = RailKitName, RecipeTier = MachineTier.TierOne, Output = 1f,
                    Recipe = new Recipe { Iron = 5, Time = 2f, Energy = 200f }
                }, null);
            if(coverKit!=null&&!__instance.AllRecipes.ContainsKey(coverKit))
                __instance.AddRecipe(new WorldManager.RecipeData{PrefabName=CoverKitName,RecipeTier=MachineTier.TierOne,Output=1f,
                    Recipe=new Recipe{Silicon=20,Time=2f,Energy=200f}},null);
            var breakerKit = Prefab.Find<MultiConstructor>(BreakerKitName);
            if (breakerKit != null && !__instance.AllRecipes.ContainsKey(breakerKit))
                __instance.AddRecipe(new WorldManager.RecipeData {
                    PrefabName = BreakerKitName, RecipeTier = MachineTier.TierOne, Output = 1f,
                    Recipe = new Recipe { Iron = 5, Copper = 20, Time = 3f, Energy = 400f }
                }, null);
            if (kit == null || __instance.AllRecipes.ContainsKey(kit)) return;
            var recipe = new WorldManager.RecipeData
            {
                PrefabName = KitName, RecipeTier = MachineTier.TierOne, Output = 1f,
                Recipe = new Recipe { Iron = 60, Copper = 30, Time = 5f, Energy = 1000f }
            };
            if (__instance.AddRecipe(recipe, null))
                Debug.Log("[Modular Switchboards] Electronics Printer recipe added: 60 Iron + 30 Copper -> 1 kit.");
        }

public static Dictionary<string,WorldManager.RecipeData> Read(){ElectronicsPrinter.RecipeComparable=new();PrepareRecipe(ElectronicsPrinter.RecipeComparable);var result=new Dictionary<string,WorldManager.RecipeData>();foreach(var row in ElectronicsPrinter.RecipeComparable.AllRecipes.Values)result.Add(row.PrefabName,row);return result;}
}
    internal static class SmartKitRecipe
    {
        internal static WorldManager.RecipeData Create()=>new WorldManager.RecipeData
        {
            PrefabName=SwitchboardsMod.SmartKitName,RecipeTier=MachineTier.TierOne,Output=1f,
            Recipe=new Recipe{Copper=10,Steel=8,Solder=4,Time=3f,Energy=400f}
        };
    }

static class BaselineRecipes{public static Dictionary<string,WorldManager.RecipeData> Read()=>SwitchboardsMod.Read();}
}
