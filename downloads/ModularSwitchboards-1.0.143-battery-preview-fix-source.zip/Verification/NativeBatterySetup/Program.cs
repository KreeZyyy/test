using System;using System.Linq;using System.Collections.Generic;using Assets.Scripts.Objects;using ModularSwitchboards;
class Program
{
 static int n;static void Check(bool b,string s){n++;if(!b)throw new Exception(s);}
 static void Main(){
 var on=new Interactable{OnOff=true,AssociatedAudioEvents=null};var mode=new Interactable();var b=new DinStationBattery{AudioEvents=null,Interactables=new(){null,mode,mode}};
 b.BuildStates.Add(new BuildState{Interactables=new(){on,mode,null,on}});b.BuildStates.Add(new BuildState{Interactables=null});
 NativeBatterySetup.Normalize(b);Check(b.Interactables.Count==2,"stage controls missing or duplicated");Check(b.Interactables[0]==mode&&b.Interactables[1]==on,"control identity/order changed");Check(b.InteractOnOff==on,"state-only ON/OFF not cached");Check(on.Parent==b&&mode.Parent==b,"native owner not rebound");Check(on.AssociatedAudioEvents!=null,"null audio list not initialized");Check(b.AudioEvents!=null,"global audio list not initialized");
 foreach(var state in b.BuildStates){Check(state.StateMeshes!=null&&state.Colliders!=null&&state.LinkedGameObjects!=null&&state.Interactables!=null,"null build-state collection survives");Check(state.Interactables.All(c=>c!=null),"null control survives");}
 NativeBatterySetup.Normalize(b);Check(b.Interactables.Count==2&&b.InteractOnOff==on,"normalization not idempotent");
 var empty=new DinStationBattery{Interactables=null};NativeBatterySetup.Normalize(empty);Check(empty.Interactables.Count==0,"empty native control list crashes");Console.WriteLine(n+" native battery preparation checks passed: stage-only switch, null audio/state lists, stable identity/order, no duplicates, idempotence.");
 }
}
namespace UnityEngine{public class Mesh{}public class Collider{}public class GameObject{}}
namespace Assets.Scripts.Sound{public class GameAudioEvent{}}
namespace Assets.Scripts.Objects{public class Interactable{public object Parent;public bool OnOff;public List<Assets.Scripts.Sound.GameAudioEvent> AssociatedAudioEvents=new();}public class BuildState{public List<UnityEngine.Mesh> StateMeshes;public List<UnityEngine.Collider> Colliders;public List<UnityEngine.GameObject> LinkedGameObjects;public List<Interactable> Interactables=new();}}
namespace ModularSwitchboards{public class DinStationBattery{public List<Interactable> Interactables=new();public List<Assets.Scripts.Sound.GameAudioEvent> AudioEvents=new();public List<BuildState> BuildStates=new();public Interactable InteractOnOff;public void CacheStates(bool cache){InteractOnOff=Interactables.Find(c=>c.OnOff);}}}
