using Assets.Scripts.Objects;
namespace ModularSwitchboards
{
    internal static class PrinterRecipeNames
    {
        // Native printer indices are sorted by GetFallbackName, not GetThingName.
        // Keep these names identical across locales and independent of custom item names.
        internal static bool TryGet(string prefab,out string title)
        {
            switch(prefab)
            {
                case SwitchboardsMod.KitName:title="Kit (Switchboard)";return true;
                case SwitchboardsMod.RailKitName:title="Kit (Switchboard Rails)";return true;
                case SwitchboardsMod.BreakerKitName:title="Kit (Switchboard Modules)";return true;
                case SwitchboardsMod.SmartKitName:title="Kit (DIN Smart Modules)";return true;
                case SwitchboardsMod.DoorKitName:title=SwitchboardNames.DoorKitTitle;return true;
                case SwitchboardsMod.LabelKitName:title="Kit (Switchboard Labels)";return true;
                case SwitchboardsMod.CoverKitName:title="Kit (Switchboard Cover)";return true;
                default:title=null;return false;
            }
        }
        internal static bool BeforeFallback(Thing __0,ref string __result)
        {
            if(__0==null||!TryGet(__0.PrefabName,out var title))return true;
            __result=title;return false;
        }
    }
}
