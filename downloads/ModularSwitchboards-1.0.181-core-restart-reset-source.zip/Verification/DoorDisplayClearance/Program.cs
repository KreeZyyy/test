using System;using System.Linq;using System.Collections.Generic;using UnityEngine;using ModularSwitchboards;using Assets.Scripts.Objects;using Assets.Scripts.GridSystem;using LibConstruct;
namespace UnityEngine{
 public struct Vector3{public float x,y,z;public Vector3(float x,float y,float z){this.x=x;this.y=y;this.z=z;}public static Vector3 operator+(Vector3 a,Vector3 b)=>new(a.x+b.x,a.y+b.y,a.z+b.z);public static Vector3 operator-(Vector3 a,Vector3 b)=>new(a.x-b.x,a.y-b.y,a.z-b.z);public static Vector3 operator*(Vector3 a,float b)=>new(a.x*b,a.y*b,a.z*b);}
 public struct Bounds{public Vector3 center,size;public Bounds(Vector3 c,Vector3 s){center=c;size=s;}public Vector3 min=>center-size*.5f;public Vector3 max=>center+size*.5f;}
 public struct Matrix4x4{public float a,b,c,d,x,y;public Vector3 Point(Vector3 p)=>new(a*p.x+b*p.y+x,c*p.x+d*p.y+y,p.z);public static Matrix4x4 operator*(Matrix4x4 p,Matrix4x4 q)=>new(){a=p.a*q.a+p.b*q.c,b=p.a*q.b+p.b*q.d,c=p.c*q.a+p.d*q.c,d=p.c*q.b+p.d*q.d,x=p.a*q.x+p.b*q.y+p.x,y=p.c*q.x+p.d*q.y+p.y};}
 public class Transform{public Vector3 position;public float Angle;public Matrix4x4 localToWorldMatrix{get{float c=(float)Math.Cos(Angle),s=(float)Math.Sin(Angle);return new(){a=c,b=-s,c=s,d=c,x=position.x,y=position.y};}}public Matrix4x4 worldToLocalMatrix{get{var m=localToWorldMatrix;return new(){a=m.a,b=m.c,c=m.b,d=m.d,x=-m.a*m.x-m.c*m.y,y=-m.b*m.x-m.d*m.y};}}public Vector3 InverseTransformPoint(Vector3 p)=>worldToLocalMatrix.Point(p);public Vector3 TransformPoint(Vector3 p)=>localToWorldMatrix.Point(p);}
}
namespace Assets.Scripts.GridSystem{public struct Grid3{public int x,y,z;public Grid3(int x,int y,int z){this.x=x;this.y=y;this.z=z;}}}
namespace Assets.Scripts.Objects{public class Structure{public bool IsBeingDestroyed,IsCursor;public Bounds Bounds;public Transform transform=new();}}
namespace LibConstruct{public class PlacementBoard{public object PrimaryHost;public List<Structure> Structures=new();public Transform Frame;public Vector3 GridToWorld(Grid3 p)=>Frame.TransformPoint(new Vector3(p.x*.01f,p.y*.01f,0));}}
namespace ModularSwitchboards{
 public class SwitchboardCabinet{public Transform DoorOrigin=new(),RightDoorOrigin=new();public PlacementBoard DoorBoard,DoorLabels,RightDoorBoard,RightDoorLabels;public SwitchboardCabinet(){DoorBoard=new(){PrimaryHost=this,Frame=DoorOrigin};DoorLabels=new(){PrimaryHost=this,Frame=DoorOrigin};RightDoorBoard=new(){PrimaryHost=this,Frame=RightDoorOrigin};RightDoorLabels=new(){PrimaryHost=this,Frame=RightDoorOrigin};}public bool IsRightBoard(PlacementBoard b)=>b==RightDoorBoard||b==RightDoorLabels;public PlacementBoard DoorBoardFor(PlacementBoard b)=>IsRightBoard(b)?RightDoorBoard:DoorBoard;public PlacementBoard DoorLabelsFor(PlacementBoard b)=>IsRightBoard(b)?RightDoorLabels:DoorLabels;}
 public class DoorSmartDisplay:Structure{public Grid3 Cell;}
 public class DoorLabel:Structure{public Grid3 Cell;public static Structure Target(PlacementBoard b,Grid3 p,bool e)=>(b.PrimaryHost as SwitchboardCabinet).DoorBoardFor(b).Structures.OfType<Control>().FirstOrDefault(c=>c.Cell.x==p.x&&c.Cell.y==p.y);}
 public class DoorDisplayLabel:DoorLabel{public static DoorSmartDisplay TargetDisplay(PlacementBoard b,Grid3 p)=>(b.PrimaryHost as SwitchboardCabinet).DoorBoardFor(b).Structures.OfType<DoorSmartDisplay>().FirstOrDefault(c=>c.Cell.x==p.x&&c.Cell.y==p.y);}
 public class Control:Structure{public Grid3 Cell;}
 public static class CabinetWallMount{public static Bounds TransformedBounds(Bounds b,Matrix4x4 m){var lo=b.min;var hi=b.max;var vs=new[]{m.Point(new(lo.x,lo.y,0)),m.Point(new(lo.x,hi.y,0)),m.Point(new(hi.x,lo.y,0)),m.Point(new(hi.x,hi.y,0))};float x=vs.Min(v=>v.x),y=vs.Min(v=>v.y),xx=vs.Max(v=>v.x),yy=vs.Max(v=>v.y);return new(new((x+xx)/2,(y+yy)/2,0),new(xx-x,yy-y,0));}}
}
class Program{
 static int count;static void Check(bool ok,string why){count++;if(!ok)throw new Exception(why);}
 static T Place<T>(PlacementBoard b,Grid3 cell,Bounds bounds)where T:Structure,new(){var s=new T{Bounds=bounds};s.transform.position=b.GridToWorld(cell);s.transform.Angle=b.Frame.Angle;if(s is Control c)c.Cell=cell;if(s is DoorSmartDisplay d)d.Cell=cell;if(s is DoorLabel l)l.Cell=cell;b.Structures.Add(s);return s;}
 static void Main(){foreach(float angle in new[]{0f,.7f,1.57f,3.14f})foreach(bool right in new[]{false,true}){
 var h=new SwitchboardCabinet();h.DoorOrigin.Angle=angle;h.RightDoorOrigin.Angle=angle;h.DoorOrigin.position=new(2,3,0);h.RightDoorOrigin.position=new(-2,1,0);var b=right?h.RightDoorBoard:h.DoorBoard;var labels=h.DoorLabelsFor(b);var p=new Grid3(-10,0,0);var upper=new Grid3(-10,10,0);
 var standard=Place<Control>(b,upper,new(new(0,0,0),new(.072f,.072f,.02f)));
 Check(DoorDisplayClearance.DisplayFits(b,p),"Compact display/nameplate rejects standard upper control");
 var oldHeader=new Bounds(new(-.05f,.050f,0),new(.192f,.032f,.003f));var oldUpper=new Bounds(new(-.1f,.1f,0),new(.072f,.072f,.02f));Check(DoorDisplayClearance.Overlaps(oldHeader,oldUpper),"Old screenshot nameplate overlap not reproduced");
 standard.Bounds=new(new(0,0,0),new(.08f,.12f,.02f));Check(!DoorDisplayClearance.DisplayFits(b,p),"Display can be built through oversized upper control");standard.IsBeingDestroyed=true;Check(DoorDisplayClearance.DisplayFits(b,p),"Removed control still blocks display");standard.IsBeingDestroyed=false;b.Structures.Clear();
 var display=Place<DoorSmartDisplay>(b,p,new());var small=new Control{Bounds=new(new(0,0,0),new(.072f,.072f,.02f))};var big=new Control{Bounds=new(new(0,0,0),new(.08f,.12f,.02f))};
 Check(DoorDisplayClearance.ControlFits(b,upper,small),"Standard control cannot be built above compact display");Check(!DoorDisplayClearance.ControlFits(b,upper,big),"Reverse build order bypasses display clearance");Check(DoorDisplayClearance.LabelFits(labels,p,false,true),"Display label rejects own display");
 var obstacle=Place<Control>(b,upper,big.Bounds);Check(!DoorDisplayClearance.LabelFits(labels,p,false,true),"Label can be built through control above");obstacle.IsCursor=true;Check(DoorDisplayClearance.LabelFits(labels,p,false,true),"Ghost blocks label");b.Structures.Remove(obstacle);
 var other=right?h.DoorBoard:h.RightDoorBoard;Place<Control>(other,upper,big.Bounds);Check(DoorDisplayClearance.LabelFits(labels,p,false,true),"Other door leaf interferes");
 var hugeLabel=Place<DoorLabel>(labels,upper,new(new(0,0,0),new(.09f,.15f,.004f)));Check(!DoorDisplayClearance.LabelFits(labels,p,false,true),"Label overlaps another label");labels.Structures.Remove(hugeLabel);
 Check(DoorDisplayClearance.ReservedBounds.max.y<.055f,"Header extends into next row");
 }Console.WriteLine(count+" production clearance checks passed: screenshot reproduction, compact header, forward/reverse build order, existing labels, ghost/deletion handling, rotated door frames and separate leaves.");}
}
