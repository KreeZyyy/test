using System;using System.Reflection;using ModularSwitchboards;using Assets.Scripts.Objects;using Assets.Scripts.Networking;using Assets.Scripts;using UnityEngine;
namespace UnityEngine{
 public class GameObject{public Transform transform;public GameObject(){transform=new Transform{gameObject=this};}}
 public struct Vector3{public float x,y,z;public Vector3(float x,float y,float z){this.x=x;this.y=y;this.z=z;}}
 public static class Time{public static float deltaTime=.01f;}
 public static class Mathf{public static float Max(float x,float y)=>Math.Max(x,y);public static float MoveTowards(float a,float b,float d)=>Math.Abs(b-a)<=d?b:a+Math.Sign(b-a)*d;}
 public class Transform{public GameObject gameObject;public Transform parent,child;public Vector3 localPosition;public Transform Find(string name)=>child;}
 public class MonoBehaviour{public GameObject gameObject;public Transform transform=>gameObject.transform;public DinBreaker actual;public T GetComponent<T>()where T:class=>actual as T;}
}
namespace Assets.Scripts{public static class GameManager{public static bool RunSimulation=true;}}
namespace Assets.Scripts.Objects{
 public enum InteractableType{OnOff}
 public class Thing{
  public class DelayedActionInstance{public float Duration;public string ActionMessage;public bool Success;public DelayedActionInstance Fail(string why){Success=false;return this;}public DelayedActionInstance Succeed(){Success=true;return this;}}
  private bool on;public bool OnOff{get=>on;set{if(on==value)return;on=value;OnInteractableUpdated(new Interactable{Action=InteractableType.OnOff});}}
  public virtual void OnInteractableUpdated(Interactable c){}public virtual void OnFinishedLoad(){}
 }
 public class Interactable{public DinBreaker Parent;public InteractableType Action;}
 public class MultiConstructor{public int Quantity=1,PrefabHash;}
}
namespace Assets.Scripts.Networking{public static class OnServer{public static int Calls;public static bool Apply=true;public static void Interact(Interactable c,int state){Calls++;if(Apply)c.Parent.OnOff=state==1;}}}
namespace ModularSwitchboards{
 public class Board{public object PrimaryHost;}public class SwitchboardCabinet{public bool IsStructureCompleted=true;}
 public class Slot{public object Get()=>null;}
 public partial class DinBreaker:Thing{
  public bool IsDoorButton=true,IsCursor,IsBeingDestroyed,IsStructureCompleted=true,IsBatteryModule,IsSmartOutputModule,IsContactor,ContactorClosed,IsDoorStop,IsDoorBridge,IsDoorLed,IsAnalyserModule,IsFuseHolder,Tripped;
  public System.Collections.Generic.List<Slot> Slots=new();public int[] AllowedFuseKits=Array.Empty<int>();public Board Board;public GameObject gameObject=new();
  private DoorButtonPulse buttonPulse;private const ushort ModuleUpdate=32768;public ushort NetworkUpdateFlags;
 }
}
class Program{
 static int n;static void Check(bool ok,string why){n++;if(!ok)throw new Exception(why);}
 static void Tick(DinBreaker owner,float dt){Time.deltaTime=dt;typeof(DinBreaker).GetMethod("LateUpdate",BindingFlags.Instance|BindingFlags.NonPublic).Invoke(owner,null);}
 static void View(DoorButtonView view){typeof(DoorButtonView).GetMethod("LateUpdate",BindingFlags.Instance|BindingFlags.NonPublic).Invoke(view,null);}
 static void Main(){
 var h=new SwitchboardCabinet();var p=new DinBreaker{Board=new(){PrimaryHost=h}};var c=new Interactable{Parent=p};
 Check(!p.Conducting,"new button must be open");
 Check(DoorButtonControl.Interact(p,c,false).Success&&!p.OnOff&&OnServer.Calls==0,"preview pressed button");
 Check(DoorButtonControl.Interact(p,c,true).Success&&p.OnOff&&p.Conducting&&OnServer.Calls==1,"press not routed through native state");
 for(int i=0;i<5;i++)Tick(p,.1f);Check(p.Conducting,"pulse ended before 550 ms");
 int calls=OnServer.Calls;Check(!DoorButtonControl.Interact(p,c,true).Success&&calls==OnServer.Calls,"active press retriggered");
 p.OnInteractableUpdated(c);Tick(p,.049f);Check(p.Conducting,"duplicate update shortened pulse");
 Tick(p,.002f);Check(!p.OnOff&&!p.Conducting&&(p.NetworkUpdateFlags&32768)!=0,"pulse did not release/replicate after 550 ms");
 Check(DoorButtonControl.Interact(p,c,true).Success,"second independent press failed");Tick(p,.55f);Check(!p.OnOff,"second pulse failed");
 DoorButtonControl.Interact(p,c,true);Tick(p,0);Check(p.OnOff,"pause consumed pulse");Tick(p,float.NaN);Tick(p,float.PositiveInfinity);Tick(p,-1);Check(p.OnOff,"invalid clock expired pulse");Tick(p,.6f);Check(!p.OnOff,"long frame left pulse stuck");
 GameManager.RunSimulation=false;OnServer.Apply=false;calls=OnServer.Calls;
 Check(DoorButtonControl.Interact(p,c,true).Success&&OnServer.Calls==calls+1&&!p.OnOff,"client must request, never mutate locally");
 p.OnOff=true;Tick(p,1);Check(p.OnOff,"client timer changed authoritative state");
 GameManager.RunSimulation=true;OnServer.Apply=true;p.OnFinishedLoad();Check(!p.OnOff&&!p.Conducting,"loaded press became latched");
 foreach(int state in new[]{0,1,2,3,4}){
  p.IsCursor=state==0;p.IsBeingDestroyed=state==1;p.IsStructureCompleted=state!=2;h.IsStructureCompleted=state!=3;p.Board=state==4?null:new(){PrimaryHost=h};calls=OnServer.Calls;
  Check(!DoorButtonControl.Interact(p,c,true).Success&&calls==OnServer.Calls,"invalid button accepted press");
  p.OnOff=true;Check(!p.OnOff,"server accepted forced invalid press");
  p.IsCursor=p.IsBeingDestroyed=false;p.IsStructureCompleted=h.IsStructureCompleted=true;p.Board=new(){PrimaryHost=h};
 }
 var face=new GameObject().transform;face.parent=p.gameObject.transform;p.gameObject.transform.child=face;var v=new DoorButtonView{gameObject=p.gameObject,actual=p};
 View(v);Check(face.localPosition.z==0,"released face moved");p.OnOff=true;Time.deltaTime=.1f;View(v);Check(face.localPosition.z==-.002f,"pressed face not depressed");Tick(p,.6f);View(v);Check(face.localPosition.z==0,"released face stuck");
 var cloneOwner=new DinBreaker{Board=p.Board,OnOff=true};var ownFace=new GameObject().transform;ownFace.parent=cloneOwner.gameObject.transform;cloneOwner.gameObject.transform.child=ownFace;
 var clone=new DoorButtonView{gameObject=cloneOwner.gameObject,actual=cloneOwner,Owner=p,Button=face};View(clone);
 Check(clone.Owner==cloneOwner&&clone.Button==ownFace&&ownFace.localPosition.z==-.002f&&face.localPosition.z==0,"clone animated prefab/source button");
 Console.WriteLine(n+" production door-button checks passed: preview, server/client authority, 550 ms pulse, no retrigger, pause, stale updates, load release, invalid placement, replicated release and cloned model pose.");
 }
}
