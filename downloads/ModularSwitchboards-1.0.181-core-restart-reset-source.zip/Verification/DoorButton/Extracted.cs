using UnityEngine;using Assets.Scripts;using Assets.Scripts.Objects;
namespace ModularSwitchboards { partial class DinBreaker {
public override void OnInteractableUpdated(Interactable interactable)
        {
            base.OnInteractableUpdated(interactable);
            if(!IsDoorButton||interactable.Action!=InteractableType.OnOff||!GameManager.RunSimulation)return;
            if(OnOff&&!DoorButtonControl.CanUse(this))OnOff=false;
            if(buttonPulse==null)buttonPulse=new DoorButtonPulse();
            buttonPulse.Set(OnOff);
        }
private void LateUpdate()
        {
            if(!IsDoorButton||IsCursor||IsBeingDestroyed||!GameManager.RunSimulation)return;
            if(buttonPulse==null)buttonPulse=new DoorButtonPulse();
            if(buttonPulse.Tick(OnOff,Time.deltaTime))
            {
                OnOff=false;buttonPulse.Set(false);NetworkUpdateFlags|=ModuleUpdate;
            }
        }
public override void OnFinishedLoad()
        {
            base.OnFinishedLoad();
            // A transient press is never restored as a latched switch after loading.
            if(IsDoorButton&&GameManager.RunSimulation){OnOff=false;buttonPulse=null;NetworkUpdateFlags|=ModuleUpdate;}
        }
public bool Conducting=>!IsBeingDestroyed&&(!(IsBatteryModule||IsDoorButton)||IsStructureCompleted)&&!IsSmartOutputModule&&(IsContactor?ContactorClosed:(IsDoorStop?!OnOff:(IsDoorBridge||IsDoorLed||IsBatteryModule||IsAnalyserModule|| (IsFuseHolder?!Tripped&&Slots.Count==1&&Slots[0].Get() is MultiConstructor kit&&kit.Quantity==1&&System.Array.IndexOf(AllowedFuseKits,kit.PrefabHash)>=0:OnOff))));
}}
