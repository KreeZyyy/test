from pathlib import Path
root=Path(__file__).resolve().parents[2]
s=(root/'Source/DinBreaker.cs').read_text()
def method(signature):
 start=s.index(signature);at=s.index('{',start);depth=1;end=at+1
 while depth:
  if s[end]=='{':depth+=1
  if s[end]=='}':depth-=1
  end+=1
 return s[start:end]
out='using UnityEngine;using Assets.Scripts;using Assets.Scripts.Objects;\nnamespace ModularSwitchboards { partial class DinBreaker {\n'
for sig in ['public override void OnInteractableUpdated(', 'private void LateUpdate()', 'public override void OnFinishedLoad()']:
 out+=method(sig)+'\n'
out+=next(line.strip() for line in s.splitlines() if 'public bool Conducting=>' in line)+'\n}}\n'
p=Path(__file__).with_name('Extracted.cs');t=p.with_suffix('.tmp175');t.write_text(out);t.replace(p)
