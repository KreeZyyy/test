using System;using System.Linq;using System.Collections.Generic;using Assets.Scripts.GridSystem;using LibConstruct;using UnityEngine;namespace ModularSwitchboards{ public sealed class DoorDisplayLabel:DoorLabel {
  public const string PrefabId="StructureSwitchboardDoorDisplayLabel";
  internal static DoorSmartDisplay TargetDisplay(PlacementBoard board,Grid3 p){var host=board?.PrimaryHost as SwitchboardCabinet;return host?.DoorBoardFor(board)?.Structures.OfType<DoorSmartDisplay>().FirstOrDefault(d=>!d.IsBeingDestroyed&&!d.IsCursor&&d.IsStructureCompleted&&Same(board.WorldToGrid(d.transform.position),p));}
  private static bool Same(Grid3 a,Grid3 b)=>a.x==b.x&&a.y==b.y&&a.z==b.z;
  internal static bool Attached(DoorSmartDisplay display){var board=display.Cabinet?.DoorLabelsFor(display.Board);return board!=null&&board.Structures.OfType<DoorDisplayLabel>().Any(l=>!l.IsBeingDestroyed&&Same(board.WorldToGrid(l.transform.position),display.GetLocalGrid()));}
 }
    internal static class DoorDisplayLabelModel{internal static Mesh Build()=>DoorDisplayOutline.Build(true);}}