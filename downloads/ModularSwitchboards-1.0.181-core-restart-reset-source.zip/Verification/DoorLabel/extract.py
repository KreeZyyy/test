from pathlib import Path
p=Path(__file__).resolve().parents[2]
out=Path(__file__).parent
def put(name,text):
 f=out/name;t=f.with_name(f.name+'.extracttmp');t.write_text(text);t.replace(f)
s=(p/'Source/DoorLabel.cs').read_text();a=s.index('        internal static DinBreaker Target');b=s.index('        public override void Awake',a)
# Display clearance is tested separately by DoorDisplayClearance; this fixture isolates target/anchor policy.
put('Policy.cs','using System;using System.Linq;using Assets.Scripts.GridSystem;using LibConstruct; namespace ModularSwitchboards{public partial class DoorLabel{'+s[a:b].replace('&&DoorDisplayClearance.LabelFits(board,p,emergency,display)','')+'}}')
s=(p/'Source/DoorLabelModel.cs').read_text();s=s[:s.index('    public sealed class DoorLabelView')]+ '}\n';put('Geometry.cs',s)
s=(p/'Source/DinRailModel.cs').read_text();a=s.index('        internal static void AddBox');b=s.index('        internal static void Install',a)
put('Box.cs','using System.Collections.Generic;using UnityEngine;namespace ModularSwitchboards{static class DinRailModel{'+s[a:b]+'}}')
s=(p/'Source/DoorModuleLayout.cs').read_text();a=s.index('        internal const float GridOffsetY');b=s.index('        internal static WireRect HarnessWindow',a)
put('Layout.cs','using System;namespace ModularSwitchboards{static class DoorModuleLayout{'+s[a:b]+'}}')
s=(p/'Source/EmergencyStopLabel.cs').read_text();a=s.index('    internal static class EmergencyStopLabelModel');b=s.index('        private static Material[] materials',a)
put('EmergencyGeometry.cs','using System.Collections.Generic;using UnityEngine;namespace ModularSwitchboards{'+s[a:b]+'}}')
