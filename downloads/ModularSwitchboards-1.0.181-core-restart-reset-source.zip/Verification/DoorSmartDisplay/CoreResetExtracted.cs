using System.Linq;namespace ModularSwitchboards {class SmartModule {internal bool OutputsReady=true;internal object Chip=new object();internal bool Powered=true,OnOff=true;internal SmartContactor[] Outputs;        private void ResetOutputCommands()
        {
            if(GameManager.RunSimulation)foreach(var output in SmartBus.PowerOutputs(this).ToArray())output.ResetProgramCommand();
        }
internal void Reset()=>ResetOutputCommands();}static class SmartBus{internal static SmartModule Core(SmartContactor output)=>output.Core;internal static SmartContactor OutputAt(SmartModule core,int address)=>core.Outputs.FirstOrDefault(o=>o.OutputAddress==address);internal static System.Collections.Generic.IEnumerable<SmartContactor> PowerOutputs(SmartModule core)=>core.Outputs;}}