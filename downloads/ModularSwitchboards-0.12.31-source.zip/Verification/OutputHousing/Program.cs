using System;using System.Collections.Generic;using System.Linq;
struct Vector2 {public float x,y;public Vector2(float x,float y){this.x=x;this.y=y;}public float magnitude=>MathF.Sqrt(x*x+y*y);public Vector2 normalized=>this*(1/magnitude);public static Vector2 operator+(Vector2 a,Vector2 b)=>new(a.x+b.x,a.y+b.y);public static Vector2 operator-(Vector2 a,Vector2 b)=>new(a.x-b.x,a.y-b.y);public static Vector2 operator*(Vector2 a,float b)=>new(a.x*b,a.y*b);}
struct Vector3 {public float x,y,z;public Vector3(float x,float y,float z){this.x=x;this.y=y;this.z=z;}public float sqrMagnitude=>x*x+y*y+z*z;public Vector3 normalized=>this*(1/MathF.Sqrt(sqrMagnitude));public static Vector3 forward=>new(0,0,1);public static Vector3 back=>new(0,0,-1);public static Vector3 operator*(Vector3 a,float b)=>new(a.x*b,a.y*b,a.z*b);public static Vector3 operator-(Vector3 a,Vector3 b)=>new(a.x-b.x,a.y-b.y,a.z-b.z);public static Vector3 Cross(Vector3 a,Vector3 b)=>new(a.y*b.z-a.z*b.y,a.z*b.x-a.x*b.z,a.x*b.y-a.y*b.x);public static float Dot(Vector3 a,Vector3 b)=>a.x*b.x+a.y*b.y+a.z*b.z;}
static class Mathf {public static float Min(float a,float b)=>Math.Min(a,b);}
class Program {static void Main(){int count=0;foreach(float span in new[]{.17f,.25f,.50f,.75f})foreach(float low in new[]{-.31f,-.56f})foreach(float offset in new[]{0f,.025f,.125f,.25f}){Check(-span,span,low,low+.07004f,-.114f,-.18f-offset,-.08f);count++;}Check(-.1112f,.1112f,-.5351f,-.4649f,-.116f,-.161f,-.086f);count++;Console.WriteLine($"Production T housing geometry passed {count} cases: cap area, outward winding, nondegenerate faces, watertight welded edges.");}
static void Check(float xmin,float xmax,float low,float barTop,float stemTop,float zmin,float zmax){
            float half=(barTop-low)*.5f;
            var corners=new[]{new Vector2(xmin,low),new Vector2(xmax,low),new Vector2(xmax,barTop),
                new Vector2(half,barTop),new Vector2(half,stemTop),new Vector2(-half,stemTop),
                new Vector2(-half,barTop),new Vector2(xmin,barTop)};
            var outline=RoundOutline(corners,.003f);
            var vertices=new List<Vector3>();var normals=new List<Vector3>();var indices=new List<int>();
            int n=outline.Count;
            for(int i=0;i<n;i++)
            {
                var a=outline[i];var b=outline[(i+1)%n];int first=vertices.Count;
                vertices.AddRange(new[]{new Vector3(a.x,a.y,zmin),new Vector3(b.x,b.y,zmin),new Vector3(b.x,b.y,zmax),new Vector3(a.x,a.y,zmax)});
                var normal=new Vector3(b.y-a.y,a.x-b.x,0).normalized;normals.AddRange(new[]{normal,normal,normal,normal});
                indices.AddRange(new[]{first,first+1,first+2,first,first+2,first+3});
            }
            var triangles=Triangulate(outline);
            foreach(bool front in new[]{false,true})
            {
                int first=vertices.Count;foreach(var p in outline){vertices.Add(new Vector3(p.x,p.y,front?zmax:zmin));normals.Add(front?Vector3.forward:Vector3.back);}
                for(int i=0;i<triangles.Count;i+=3)
                    indices.AddRange(front?new[]{first+triangles[i],first+triangles[i+1],first+triangles[i+2]}:new[]{first+triangles[i],first+triangles[i+2],first+triangles[i+1]});
            }

if(vertices.Count!=240||indices.Count!=468)throw new Exception("mesh counts");
float polygonArea=0;for(int i=0;i<outline.Count;i++){var a=outline[i];var b=outline[(i+1)%outline.Count];polygonArea+=(a.x*b.y-a.y*b.x)/2;}
float capArea=0;for(int i=0;i<triangles.Count;i+=3){float cross=Cross(outline[triangles[i]],outline[triangles[i+1]],outline[triangles[i+2]]);if(cross<=0)throw new Exception("cap orientation");capArea+=cross/2;}
if(Math.Abs(capArea-polygonArea)>1e-6)throw new Exception("cap coverage");
var canonical=new Dictionary<(float,float,float),int>();var welded=new int[vertices.Count];for(int i=0;i<vertices.Count;i++){var p=vertices[i];var key=(p.x,p.y,p.z);if(!canonical.TryGetValue(key,out int id)){id=i;canonical[key]=id;}welded[i]=id;}
var edges=new Dictionary<(int,int),int>();
for(int i=0;i<indices.Count;i+=3){int a=indices[i],b=indices[i+1],c=indices[i+2];var normal=Vector3.Cross(vertices[b]-vertices[a],vertices[c]-vertices[a]);if(normal.sqrMagnitude<1e-20||Vector3.Dot(normal,normals[a])<=0)throw new Exception("triangle normal");foreach(var raw in new[]{(a,b),(b,c),(c,a)}){int from=welded[raw.Item1],to=welded[raw.Item2];var key=from<to?(from,to):(to,from);edges.TryGetValue(key,out int count);edges[key]=count+1;}}
if(edges.Any(e=>e.Value!=2))throw new Exception("open or nonmanifold edge");
}
        private static List<Vector2> RoundOutline(Vector2[] corners,float radius)
        {
            var result=new List<Vector2>();
            for(int i=0;i<corners.Length;i++)
            {
                var p=corners[i];var before=corners[(i+corners.Length-1)%corners.Length];var after=corners[(i+1)%corners.Length];
                float r=Mathf.Min(radius,Mathf.Min((before-p).magnitude,(after-p).magnitude)*.25f);
                var a=p+(before-p).normalized*r;var b=p+(after-p).normalized*r;
                for(int step=0;step<=4;step++){float t=step/4f;result.Add(a*(1-t)*(1-t)+p*(2*t*(1-t))+b*t*t);}
            }
            return result;
        }
        private static float Cross(Vector2 a,Vector2 b,Vector2 c)=>(b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x);
        private static List<int> Triangulate(List<Vector2> p)
        {
            var remaining=Enumerable.Range(0,p.Count).ToList();var result=new List<int>();int guard=p.Count*p.Count;
            while(remaining.Count>3 && guard-->0)
            {
                bool clipped=false;
                for(int i=0;i<remaining.Count;i++)
                {
                    int a=remaining[(i+remaining.Count-1)%remaining.Count],b=remaining[i],c=remaining[(i+1)%remaining.Count];
                    if(Cross(p[a],p[b],p[c])<=1e-10f)continue;
                    bool occupied=remaining.Any(v=>v!=a&&v!=b&&v!=c&&Cross(p[a],p[b],p[v])>=-1e-10f&&Cross(p[b],p[c],p[v])>=-1e-10f&&Cross(p[c],p[a],p[v])>=-1e-10f);
                    if(occupied)continue;
                    result.AddRange(new[]{a,b,c});remaining.RemoveAt(i);clipped=true;break;
                }
                if(!clipped)throw new InvalidOperationException("Cannot triangulate output housing.");
            }
            if(remaining.Count!=3)throw new InvalidOperationException("Incomplete output housing cap.");
            result.AddRange(remaining);return result;
        }
}
