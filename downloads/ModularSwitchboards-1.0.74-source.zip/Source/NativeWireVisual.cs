using System;
using System.Collections.Generic;
using System.Linq;
using Assets.Scripts;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Electrical;
using Assets.Scripts.Objects.Motherboards;
using UnityEngine;
using UnityEngine.Rendering;
namespace ModularSwitchboards
{
    public sealed class NativeWireRenderer:MonoBehaviour
    {
        internal CabinetWireKind Kind;internal int LastColor=-1;internal bool Active=true;
    }
    internal static class NativeWireVisual
    {
        private sealed class Template{internal NativeWireShape.Profile Shape;internal Material[] Materials;internal Material Paintable;internal float Smoothness;}
        private static readonly Dictionary<CabinetWireKind,Template> Templates=new Dictionary<CabinetWireKind,Template>();
        private static readonly Dictionary<Material,Material> Materials=new Dictionary<Material,Material>();
        private static readonly HashSet<CabinetWireKind> Failed=new HashSet<CabinetWireKind>();
        private static Template Get(CabinetWireKind kind)
        {
            if(Templates.TryGetValue(kind,out var known))return known;if(Failed.Contains(kind))return null;
            try
            {
                string name=kind==CabinetWireKind.SuperHeavy?"StructureCableSuperHeavyStraight":kind==CabinetWireKind.Heavy?"StructureCableStraightH":"StructureCableStraight";
                var native=WorldManager.Instance.SourcePrefabs.OfType<Cable>().First(c=>c.PrefabName==name);
                var renderer=native.GetComponentsInChildren<MeshRenderer>(true).First(r=>r.GetComponent<MeshFilter>()?.sharedMesh!=null);
                var mesh=renderer.GetComponent<MeshFilter>().sharedMesh;CabinetGeometry.ReadNativeMesh(mesh,out var vertices,out var uv,out var groups);
                var normals=ReadNormals(mesh);var points=vertices.Select(v=>new WirePoint(v.x,v.y,v.z)).ToArray();float radius=(float)Math.Sqrt(points.Max(v=>v.X*v.X+v.Y*v.Y));
                var template=new Template{Materials=renderer.sharedMaterials,Paintable=native.PaintableMaterial,Smoothness=native.SmoothnessIndex,Shape=new NativeWireShape.Profile{Vertices=points,Normals=normals,Uv=uv.Select(v=>new WireUv(v.x,v.y)).ToArray(),Groups=groups,Start=points.Min(v=>v.Z),End=points.Max(v=>v.Z),Scale=CabinetWireKinds.Radius(kind)/radius}};
                if(template.Shape.End-template.Shape.Start<.001f||normals.Length!=vertices.Length||uv.Length!=vertices.Length)throw new InvalidOperationException("Invalid native cable profile");
                Templates[kind]=template;Debug.Log("[Modular Switchboards] Native wire profile ready: "+kind+"; prefab="+name+"; vertices="+vertices.Length+"; UVs="+uv.Length);return template;
            }
            catch(Exception ex){Failed.Add(kind);Debug.LogWarning("[Modular Switchboards] Native wire visual unavailable for "+kind+"; using plain wire: "+ex.Message);return null;}
        }
        private static WirePoint[] ReadNormals(Mesh mesh)
        {
            var attribute=mesh.GetVertexAttributes().First(a=>a.attribute==VertexAttribute.Normal);
            if(attribute.format!=VertexAttributeFormat.Float32||attribute.dimension<3)throw new InvalidOperationException("Unsupported native normal format");
            int stream=mesh.GetVertexAttributeStream(VertexAttribute.Normal),stride=mesh.GetVertexBufferStride(stream),offset=mesh.GetVertexAttributeOffset(VertexAttribute.Normal);byte[] bytes;
            using(var buffer=mesh.GetVertexBuffer(stream)){int count=buffer.count*buffer.stride;if(count%4!=0)throw new InvalidOperationException("Unaligned native vertex buffer");var words=new uint[count/4];buffer.GetData(words);bytes=new byte[count];Buffer.BlockCopy(words,0,bytes,0,count);}
            var normals=new WirePoint[mesh.vertexCount];for(int i=0;i<normals.Length;i++){int n=i*stride+offset;normals[i]=new WirePoint(BitConverter.ToSingle(bytes,n),BitConverter.ToSingle(bytes,n+4),BitConverter.ToSingle(bytes,n+8));}return normals;
        }
        internal static Mesh Build(WirePoint[] path,CabinetWireKind kind)
        {
            var template=Get(kind);if(template==null)return null;
            var data=NativeWireShape.Build(template.Shape,path);var mesh=new Mesh{name="Switchboards.NativeWire."+kind};if(data.Vertices.Count>65535)mesh.indexFormat=IndexFormat.UInt32;
            mesh.SetVertices(data.Vertices.Select(CabinetWiring.Vector).ToList());mesh.SetNormals(data.Normals.Select(CabinetWiring.Vector).ToList());mesh.SetUVs(0,data.Uv.Select(v=>new Vector2(v.U,v.V)).ToList());mesh.subMeshCount=data.Groups.Length;for(int i=0;i<data.Groups.Length;i++)mesh.SetTriangles(data.Groups[i],i);mesh.RecalculateBounds();mesh.RecalculateTangents();return mesh;
        }
        internal static void Install(MeshRenderer renderer,CabinetWireKind kind)
        {
            var marker=renderer.GetComponent<NativeWireRenderer>();
            if(Get(kind)==null){if(marker!=null)marker.Active=false;renderer.sharedMaterial=CabinetGeometry.Materials[3];return;}
            if(marker==null)marker=renderer.gameObject.AddComponent<NativeWireRenderer>();marker.Active=true;marker.Kind=kind;marker.LastColor=-1;
        }
        private static bool IsPaintSlot(Material material,Template template)=>material!=null&&(material==template.Paintable||material.mainTexture is Texture2DArray);
        private static Material Copy(Material source)
        {
            if(source==null)return null;
            if(!Materials.TryGetValue(source,out var copy)){copy=new Material(source){name="Switchboards.NativeWire."+source.name};Materials[source]=copy;}return copy;
        }
        internal static bool Paint(MeshRenderer renderer,ColorType colour)
        {
            var marker=renderer.GetComponent<NativeWireRenderer>();if(marker==null||!marker.Active)return false;
            if(marker.LastColor==(int)colour)return true;var template=Get(marker.Kind);if(template==null)return false;
            // Native CustomColorMapping replaces paintable prefab materials with
            // this texture-array material during initialization. Swatch.Normal is
            // a legacy solid-colour material and loses the cable's atlas detail.
            var paint=GameManager.GetTextureArrayColorMaterial();
            if(paint==null)return false;
            renderer.sharedMaterials=template.Materials.Select(m=>Copy(IsPaintSlot(m,template)?paint:m)).ToArray();
            // Match native cable initialization: unchanged UVs + array atlas + palette index.
            for(int i=0;i<template.Materials.Length;i++){if(!IsPaintSlot(template.Materials[i],template)){renderer.SetPropertyBlock(null,i);continue;}var block=new MaterialPropertyBlock();block.SetFloat(Thing.DiffuseIndexPropertyID,(int)colour);block.SetFloat(Thing.SmoothnessIndexPropertyID,template.Smoothness);block.SetColor(Thing.EMISSION_COLOR,Color.black);renderer.SetPropertyBlock(block,i);}
            marker.LastColor=(int)colour;return true;
        }
    }
}
