using System;
using System.Collections.Generic;
using System.Linq;
using Assets.Scripts;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Electrical;
using Assets.Scripts.Objects.Items;
using Assets.Scripts.Objects.Motherboards;
namespace ModularSwitchboards
{
    // Resolve actual native construction kits, rather than guessing heavy coil IDs.
    internal static class CabinetCableCoils
    {
        private static readonly Dictionary<string,CabinetWireKind> kinds=new Dictionary<string,CabinetWireKind>(StringComparer.Ordinal);
        private static readonly Dictionary<CabinetWireKind,string> prefabs=new Dictionary<CabinetWireKind,string>();
        internal static void Configure(IEnumerable<Thing> sources)
        {
            kinds.Clear();prefabs.Clear();
            foreach(var kit in sources.OfType<MultiConstructor>().OrderBy(k=>k.PrefabName,StringComparer.Ordinal))
            {
                var cables=kit.Constructables?.OfType<Cable>().ToArray();
                if(cables==null||cables.Length==0||cables.Select(c=>c.CableType).Distinct().Count()!=1)continue;
                var type=cables[0].CableType;
                if(type!=Cable.Type.normal&&type!=Cable.Type.heavy&&type!=Cable.Type.superHeavy)continue;
                var kind=type==Cable.Type.superHeavy?CabinetWireKind.SuperHeavy:type==Cable.Type.heavy?CabinetWireKind.Heavy:CabinetWireKind.Normal;
                kinds[kit.PrefabName]=kind;
                if(!prefabs.ContainsKey(kind)||kit.PrefabName=="ItemCableCoil")prefabs[kind]=kit.PrefabName;
            }
            kinds["ItemCableCoil"]=CabinetWireKind.Normal;prefabs[CabinetWireKind.Normal]="ItemCableCoil";
        }
        internal static bool TryKind(DynamicThing item,out CabinetWireKind kind)
        {
            kind=CabinetWireKind.Normal;
            return item is Stackable&&item.PrefabName!=null&&(item.PrefabName=="ItemCableCoil"||kinds.TryGetValue(item.PrefabName,out kind));
        }
        internal static Item RefundPrefab(CabinetWireKind kind)=>prefabs.TryGetValue(kind,out var name)?Prefab.Find<Item>(name):kind==CabinetWireKind.Normal?Prefab.Find<Item>("ItemCableCoil"):null;
    }
}
