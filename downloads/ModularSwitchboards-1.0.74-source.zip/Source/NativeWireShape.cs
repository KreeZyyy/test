using System;
using System.Collections.Generic;
namespace ModularSwitchboards
{
    internal struct WireUv
    {
        internal float U,V;internal WireUv(float u,float v){U=u;V=v;}
        internal static WireUv Mix(WireUv a,WireUv b,float t)=>new WireUv(a.U+(b.U-a.U)*t,a.V+(b.V-a.V)*t);
    }
    // Deform actual straight-cable triangles and UVs along the existing route.
    // No invented stripe pattern or new texture coordinates.
    internal static class NativeWireShape
    {
        internal sealed class Profile
        {
            internal WirePoint[] Vertices,Normals;internal WireUv[] Uv;internal int[][] Groups;
            internal float Start,End,Scale;
        }
        internal sealed class Result
        {
            internal readonly List<WirePoint> Vertices=new List<WirePoint>(),Normals=new List<WirePoint>();
            internal readonly List<WireUv> Uv=new List<WireUv>();internal List<int>[] Groups;
        }
        private struct Vertex
        {
            internal WirePoint P,N;internal WireUv Uv;
            internal static Vertex Mix(Vertex a,Vertex b,float t)=>new Vertex{P=a.P+(b.P-a.P)*t,N=a.N+(b.N-a.N)*t,Uv=WireUv.Mix(a.Uv,b.Uv,t)};
        }
        private static WirePoint Unit(WirePoint p)=>p*(1f/(float)Math.Sqrt(Math.Max(1e-20f,p.Squared)));
        private static WirePoint Cross(WirePoint a,WirePoint b)=>new WirePoint(a.Y*b.Z-a.Z*b.Y,a.Z*b.X-a.X*b.Z,a.X*b.Y-a.Y*b.X);
        private static List<Vertex> Clip(List<Vertex> input,float plane,bool greater)
        {
            var output=new List<Vertex>();if(input.Count==0)return output;var previous=input[input.Count-1];bool was=greater?previous.P.Z>=plane:previous.P.Z<=plane;
            foreach(var current in input)
            {
                bool inside=greater?current.P.Z>=plane:current.P.Z<=plane;
                if(inside!=was){float t=(plane-previous.P.Z)/(current.P.Z-previous.P.Z);var hit=Vertex.Mix(previous,current,t);hit.P.Z=plane;output.Add(hit);}
                if(inside)output.Add(current);previous=current;was=inside;
            }
            return output;
        }
        internal static Result Build(Profile profile,WirePoint[] route)
        {
            var path=WireTube.Supports(route);var distances=new float[path.Length];var right=new WirePoint[path.Length];var up=new WirePoint[path.Length];var tangent=new WirePoint[path.Length];
            var r=new WirePoint();var t=new WirePoint();
            for(int i=0;i<path.Length;i++){if(i>0)distances[i]=distances[i-1]+(float)Math.Sqrt((path[i]-path[i-1]).Squared);WireTube.Ring(path,i,4,ref r,ref t);right[i]=r;tangent[i]=t;up[i]=Unit(Cross(t,r));}
            float total=distances[distances.Length-1],span=profile.End-profile.Start;
            int tiles=Math.Max(1,(int)Math.Ceiling(total/(span*profile.Scale)));float tileLength=total/tiles;
            var result=new Result{Groups=new List<int>[profile.Groups.Length]};for(int i=0;i<result.Groups.Length;i++)result.Groups[i]=new List<int>();
            for(int tile=0;tile<tiles;tile++)
            {
                float begin=tile*tileLength,end=(tile+1)*tileLength;
                for(int group=0;group<profile.Groups.Length;group++)
                {
                    var indices=profile.Groups[group];for(int tri=0;tri<indices.Length;tri+=3)
                    {
                        var triangle=new List<Vertex>(3);for(int k=0;k<3;k++){int index=indices[tri+k];triangle.Add(new Vertex{P=profile.Vertices[index],N=profile.Normals[index],Uv=profile.Uv[index]});}
                        float low=Math.Min(triangle[0].P.Z,Math.Min(triangle[1].P.Z,triangle[2].P.Z)),high=Math.Max(triangle[0].P.Z,Math.Max(triangle[1].P.Z,triangle[2].P.Z));
                        // Original end caps only belong on the two exterior ends.
                        if(high-low<1e-6f){if(tile>0&&Math.Abs(low-profile.Start)<1e-5f||tile<tiles-1&&Math.Abs(high-profile.End)<1e-5f)continue;}
                        float from=begin+(low-profile.Start)/span*tileLength,to=begin+(high-profile.Start)/span*tileLength;
                        int segment=1;while(segment<path.Length-1&&distances[segment]<from-1e-7f)segment++;
                        for(;segment<path.Length&&distances[segment-1]<=to+1e-7f&&distances[segment-1]<end;segment++)
                        {
                            float a=Math.Max(begin,distances[segment-1]),b=Math.Min(end,distances[segment]);if(b-a<1e-8f)continue;
                            float sourceA=profile.Start+(a-begin)/tileLength*span,sourceB=profile.Start+(b-begin)/tileLength*span;
                            if(Math.Abs(a-begin)<1e-7f)sourceA=profile.Start;if(Math.Abs(b-end)<1e-7f)sourceB=profile.End;
                            var polygon=Clip(Clip(triangle,sourceA,true),sourceB,false);if(polygon.Count<3)continue;
                            for(int face=1;face<polygon.Count-1;face++)
                            {
                                var points=new[]{polygon[0],polygon[face],polygon[face+1]};var transformed=new WirePoint[3];var normals=new WirePoint[3];
                                for(int k=0;k<3;k++)
                                {
                                    var vertex=points[k];float distance=begin+(vertex.P.Z-profile.Start)/span*tileLength;
                                    float blend=Math.Max(0,Math.Min(1,(distance-distances[segment-1])/(distances[segment]-distances[segment-1])));
                                    var center=path[segment-1]+(path[segment]-path[segment-1])*blend;
                                    var axis=Unit(tangent[segment-1]+(tangent[segment]-tangent[segment-1])*blend);
                                    var x=Unit(right[segment-1]+(right[segment]-right[segment-1])*blend);x=Unit(x-axis*WirePoint.Dot(x,axis));var y=Unit(Cross(axis,x));
                                    transformed[k]=center+x*(vertex.P.X*profile.Scale)+y*(vertex.P.Y*profile.Scale);
                                    normals[k]=Unit(x*vertex.N.X+y*vertex.N.Y+axis*vertex.N.Z);
                                }
                                if(Cross(transformed[1]-transformed[0],transformed[2]-transformed[0]).Squared<1e-20f)continue;
                                for(int k=0;k<3;k++){result.Groups[group].Add(result.Vertices.Count);result.Vertices.Add(transformed[k]);result.Normals.Add(normals[k]);result.Uv.Add(points[k].Uv);}
                            }
                        }
                    }
                }
            }
            return result;
        }
    }
}
