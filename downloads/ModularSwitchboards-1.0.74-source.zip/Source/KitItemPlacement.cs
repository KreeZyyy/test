using System.Collections.Generic;
using Assets.Scripts;
using System.Reflection;
using Assets.Scripts.Inventory;
using Assets.Scripts.FirstPerson;
using Assets.Scripts.Objects;
using HarmonyLib;
using UnityEngine;
namespace ModularSwitchboards
{
    // T uses a separate native item-cursor cache, not construction cursors.
    // Populate a missing entry only for our kits; native code still moves the item.
    internal static class KitItemPlacement
    {
        private static readonly FieldInfo Cursors=AccessTools.Field(typeof(InventoryManager),"_dynamicThingCursors");
        private static readonly FieldInfo CursorParent=AccessTools.Field(typeof(InventoryManager),"_dynamicCursorParent");
        private static readonly MethodInfo UpdateCursor=AccessTools.Method(typeof(InventoryManager),"UpdatePrecisionPlacement",new[]{typeof(DynamicThing)});
        internal static bool TryBeginPrecisionPlacement(InventoryManager inventory,DynamicThing active)
        {
            if(!SwitchboardKitModel.IsKit(active)||UpdateCursor==null||
                (InventoryManager.CurrentMode!=InventoryManager.Mode.Normal&&InventoryManager.CurrentMode!=InventoryManager.Mode.Placement)||
                !KeyManager.GetButtonDown(KeyMap.PrecisionPlace))return false;
            if(InventoryManager.CurrentMode==InventoryManager.Mode.Placement)inventory.CancelPlacement();
            InventoryManager.CurrentMode=InventoryManager.Mode.PrecisionPlacement;
            CursorManager.SetSelectionVisibility(false);CursorManager.ClearLastSelectionId();
            UpdateCursor.Invoke(null,new object[]{active});
            return true;
        }
        // Native initialization resets the world rotation to identity. Set the initial
        // facing afterwards; subsequent native rotation controls remain available.
        internal static void AfterPrecisionPlacement(DynamicThing __0)
        {
            if(!(__0 is PortableCoverItem)||InventoryManager.PrecisionPlaceCursor==null||CameraController.CurrentCamera==null)return;
            var towardPlayer=-CameraController.CurrentCamera.transform.forward;
            towardPlayer.y=0f;
            if(towardPlayer.sqrMagnitude<.0001f)return;
            InventoryManager.PrecisionPlaceCursor.transform.rotation=Quaternion.LookRotation(towardPlayer,Vector3.up);
        }
        internal static void BeforePrecisionPlacement(DynamicThing __0)
        {
            if(!SwitchboardKitModel.IsKit(__0)||InventoryManager.Instance==null)return;
            var cursors=Cursors?.GetValue(null) as IDictionary<string,GameObject>;
            if(cursors==null||(__0.Blueprint==null))return;
            if(__0 is PortableCoverItem fitted)fitted.RefreshNow();
            if(cursors.TryGetValue(__0.PrefabName,out var existing)&&existing!=null)
            {
                if(!(__0 is PortableCoverItem saved)||existing.name==saved.CursorKey)return;
                existing.SetActive(false);Object.Destroy(existing);cursors.Remove(__0.PrefabName);
            }
            var parent=CursorParent?.GetValue(InventoryManager.Instance) as GameObject;
            if(parent==null)return;
            var cursor=Object.Instantiate(__0.Blueprint,parent.transform);
            cursor.name=__0 is PortableCoverItem savedCover?savedCover.CursorKey:"Switchboards.ItemCursor."+__0.PrefabName;
            cursor.transform.localPosition=Vector3.zero;cursor.transform.localRotation=Quaternion.identity;
            var renderer=cursor.GetComponent<MeshRenderer>();
            if(renderer==null){Object.Destroy(cursor);Debug.LogError("[Modular Switchboards] Item placement blueprint has no renderer: "+__0.PrefabName);return;}
            var color=Color.green;color.a=.2f;renderer.material.color=color;
            cursor.SetActive(false);cursors[__0.PrefabName]=cursor;
        }
    }
}
