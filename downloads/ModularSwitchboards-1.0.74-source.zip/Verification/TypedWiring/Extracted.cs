using System;using System.Linq;using System.Collections.Generic;using Assets.Scripts;using Assets.Scripts.Objects;using Assets.Scripts.Objects.Items;using Assets.Scripts.Objects.Motherboards;using UnityEngine;namespace ModularSwitchboards{partial class CabinetWiring{        internal bool TryAttack(Attack attack,bool doAction,out Thing.DelayedActionInstance result)
        {
            result=null;
            if(attack.SourceItem is ISprayer sprayer&&TryPaintWire(attack,sprayer,doAction,out result))return true;
            bool cutting=attack.SourceItem is WireCutter;
            var coil=IsCoil(attack.SourceItem)?attack.SourceItem as Stackable:null;
            if(!cutting&&coil==null)return false;
            if(Owner.HasInnerCover){result=new Thing.DelayedActionInstance{Duration=0};result.Fail("Remove the inner cover with a wrench first.");return true;}
            HidePreview();
            result=new Thing.DelayedActionInstance{Duration=0};
            if(Owner.IsCursor||!Owner.IsStructureCompleted||!Owner.IsOpen){result.Fail("Open the completed cabinet first.");return true;}
            var actor=attack.SourceItem.RootParentHuman;
            if(actor==null){result.Fail("Hold a cable coil to connect, or wire cutters to remove a wire.");return true;}
            if((actor.Transform.position-Owner.Transform.position).sqrMagnitude>16f){result.Fail("Move closer to the cabinet.");return true;}
            RefreshContacts();
            if(migrationFailure!=null)result.AppendStateMessage(migrationFailure);
            long actorId=actor.ReferenceId;
            if(!cutting&&attack.IsDestroy)
            {
                result.ActionMessage="Cancel wire selection";
                if(doAction&&GameManager.RunSimulation){pending.Remove(actorId);pendingUntil.Remove(actorId);Owner.NetworkUpdateFlags|=UpdateFlag;}
                return true;
            }
            if(cutting)
            {
                result.ActionMessage="Cut internal wire";
                int index=WireAt(attack.Position);
                if(index<0){result.Fail("Aim at an internal wire to cut it.");return true;}
                result.ActionMessage="Cut "+CabinetWireKinds.Title(wires[index].CableKind)+" internal wire";
                var refund=CabinetCableCoils.RefundPrefab(wires[index].CableKind);
                if(refund==null){result.Fail("Cable coil prefab unavailable.");return true;}
                if(doAction&&GameManager.RunSimulation)
                {
                    int units=wires[index].CableUnits;
                    OnServer.CreateOrStack(refund,units,attack.Position,Quaternion.identity,attack.OtherHand);
                    wires.RemoveAt(index);pending.Remove(actorId);pendingUntil.Remove(actorId);Changed();
                }
                return true;
            }
            if(!TryContact(attack,out var target)){result.Fail("Choose a highlighted contact. Right click cancels; wire cutters remove a wire.");return true;}
            if(Occupied(target.End)>=Capacity(target.End)){result.Fail("Contact occupied.");return true;}
            if(!pending.TryGetValue(actorId,out var selected))
            {
                result.ActionMessage="Select "+ContactName(target.End);
                if(doAction&&GameManager.RunSimulation){pending[actorId]=target.End;pendingUntil[actorId]=Time.unscaledTime+60;Owner.NetworkUpdateFlags|=UpdateFlag;}
                return true;
            }
            if(selected.Equals(target.End))
            {
                result.ActionMessage="Cancel wire selection";
                if(doAction&&GameManager.RunSimulation){pending.Remove(actorId);pendingUntil.Remove(actorId);Owner.NetworkUpdateFlags|=UpdateFlag;}
                return true;
            }
            if(!contacts.ContainsKey(selected)){result.Fail("Selected contact no longer exists. Select it again.");if(doAction&&GameManager.RunSimulation){pending.Remove(actorId);Owner.NetworkUpdateFlags|=UpdateFlag;}return true;}
            if(!CanConnectContacts(selected,target.End,out var reason)){result.Fail(reason);return true;}
            if(wires.Count>=64){result.Fail("Cabinet wire capacity reached.");return true;}
            if(coil.Quantity<1){result.Fail("One cable coil unit is required.");return true;}
            WireCircuit.Orient(selected,target.End,out var from,out var to);
            if(routeRevision!=revision||!from.Equals(routeFrom)||!to.Equals(routeTo))
            {routeFrom=from;routeTo=to;routeRevision=revision;route=MakeRoute(from,to,out routeSlot,out routeFailure);}
            CabinetCableCoils.TryKind(coil,out var cableKind);
            result.ActionMessage="Wire ("+CabinetWireKinds.Title(cableKind)+") "+ContactName(from)+" -> "+ContactName(to);
            if(route==null){result.Fail(routeFailure??"No clear route. Move a wire or a breaker first.");return true;}
            if(!doAction)ShowPreview(route,cableKind);
            if(doAction&&GameManager.RunSimulation)
            {
                if(coil.RemoveQuantity(1)!=1){result.Fail("Cable coil is empty.");return true;}
                wires.Add(new CabinetWireSaveData{From=from,To=to,InputSlot=routeSlot,RouteVersion=CurrentRouteVersion,CableUnits=1,CableKind=cableKind,Points=Flatten(route)});
                pending.Remove(actorId);pendingUntil.Remove(actorId);Changed();
            }
            return true;
        }
        private static bool CanRefundWires(IEnumerable<CabinetWireSaveData> batch)=>batch.All(w=>CabinetCableCoils.RefundPrefab(w.CableKind)!=null);
        internal bool CanRefundBreaker(long id)=>CanRefundWires(wires.Where(w=>w.From.Owner==id||w.To.Owner==id));
        private static void RefundWires(IEnumerable<CabinetWireSaveData> batch,Vector3 position,Slot destination)
        {
            foreach(var group in batch.GroupBy(w=>w.CableKind))
                OnServer.CreateOrStack(CabinetCableCoils.RefundPrefab(group.Key),group.Sum(w=>w.CableUnits),position,Quaternion.identity,destination);
        }
        internal void RefundAndRemoveBreaker(long id,Vector3 position,Slot destination)
        {
            if(!GameManager.RunSimulation)return;
            var batch=wires.Where(w=>w.From.Owner==id||w.To.Owner==id).ToArray();
            if(!CanRefundWires(batch))throw new InvalidOperationException("Cable coil prefab unavailable during module demolition");
            RefundWires(batch,position,destination);RemoveBreaker(id);
        }
        internal void RemoveBreaker(long id)
        {
            if(wires.RemoveAll(w=>w.From.Owner==id||w.To.Owner==id)>0)Changed();
            foreach(var actor in pending.Where(p=>p.Value.Owner==id).Select(p=>p.Key).ToArray()){pending.Remove(actor);pendingUntil.Remove(actor);Owner.NetworkUpdateFlags|=UpdateFlag;}
            topology=null;
        }
}}