using System;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
namespace ModularSwitchboards
{
    // Search terms are separate from long visible descriptions, which vanilla
    // deliberately refuses to search beyond 255 characters.
    internal static class StationpediaCatalog
    {
        internal static string Kind(string name)
        {
            if(name==SwitchboardsMod.DoorRoundSwitchName||name==SwitchboardsMod.DoorIsolatorName||name==SwitchboardsMod.DoorStopName||name==SwitchboardsMod.DoorKitName||DoorLedColours.Find(name)!=null||name==SwitchboardsMod.DoorBridgeName)return "door";
            if(name==SwitchboardsMod.EmergencyStopLabelName||name==SwitchboardsMod.DoorLabelName||name==SwitchboardsMod.LabelKitName||name==SwitchboardsMod.LabelName(1)||name==SwitchboardsMod.LabelName(2)||name==SwitchboardsMod.LabelName(3)||name==SwitchboardsMod.LabelName(4)||name==SwitchboardsMod.LabelName(6))return "label";
            if(name==SwitchboardsMod.KitName||SwitchboardsMod.IsCabinetName(name))return "cabinet";
            if(name==SwitchboardsMod.CoverKitName||name==SwitchboardsMod.CoverName)return "cover";
            if(name==SwitchboardsMod.RailKitName||name==SwitchboardsMod.RailName)return "rail";
            if(name==SwitchboardsMod.SmartKitName)return "smartkit";
            if(name==SwitchboardsMod.BreakerKitName)return "modules";
            if(DinModuleCatalog.Specs.TryGetValue(name??"",out var spec)&&spec.Selectable)
                return spec.Transformer?"transformer":spec.SmartContactor||spec.Contactor?"contactor":spec.SmartOutput?"smartoutput":spec.Smart?"smart":spec.Analyser?"analyser":spec.StationBattery||spec.Battery?"battery":spec.Fuse?"fuse":"breaker";
            return null;
        }
        internal static string Terms(string name)
        {
            var kind=Kind(name);if(kind==null)return null;
            string common="modular switchboards electronics electronic elektrika elektro din ";
            switch(kind)
            {
                case "door":if(name==SwitchboardsMod.DoorRoundSwitchName)return common+"door round switch rotary selector circular dvere kulaty prepinac vypinac";if(name==SwitchboardsMod.DoorIsolatorName)return common+"door main switch isolator rotary disconnect dvere hlavni vypinac odpinac otocny";if(name==SwitchboardsMod.DoorStopName)return common+"door total stop emergency mushroom reset button pushbutton dvere dverni nouzove zastaveni tlacitko hrib vypinac";return common+"door led indicator lamp light dvere dverni kontrolka signalka "+(name==DoorLedColours.OrangeName?"orange amber oranzova oranžová jantarova":name==DoorLedColours.BlueName?"blue modra":name==DoorLedColours.WhiteName?"white bila":name==DoorLedColours.RedName?"red cervena":name==DoorLedColours.GreenName?"green zelena":"green blue white red orange amber zelena modra bila cervena oranzova");
                case "label":if(name==SwitchboardsMod.EmergencyStopLabelName)return common+"door emergency stop total label ring yellow dvere dverni nouzovy stop stitek popisek zluty krouzek labels labeller";return common+"label labels plate nameplate labeller stitek stitky popisek popisky oznaceni";
                case "cabinet":return (SwitchboardsMod.IsCabinetName(name)?(CabinetShape.Medium(name)?"medium ":"small "):"")+(CabinetDocumentation.Listed(name)?"basic reverse reversed inverted combiner collector multiple inputs outputs obraceny slucovaci vstupy vystupy "+(CabinetShape.Medium(name)?"1 in 3 out 3 in 1 out ":"1 in 2 out 2 in 1 out "):"")+(CabinetPorts.Combiner(name)?"combiner collector multiple inputs one output slucovaci vice vstupu jeden vystup ":"")+(CabinetShape.Medium(name)?"medium double twin doors three rows stredni dvojite dvere "+(CabinetPorts.Combiner(name)?"three inputs tri vstupy ":"three outputs tri vystupy "):"")+(CabinetLayout.Reversed(name)?"reverse reversed inverted obraceny "+(CabinetPorts.Combiner(name)?"top inputs bottom output vstupy nahore vystup dole ":"bottom input top outputs vstup dole vystupy nahore "):"")+common+"switchboard cabinet enclosure rozvadec rozvadece rozvodnice skrin skrinka elektricky rozvadec electrical panel";
                case "cover":return common+"inner cover front cover dead front kryt krytu krytka zakryt panel rozvadec";
                case "rail":return common+"din rail mounting rail lista listy listu list dinlista uchyceni montazni lista rozvadec";
                case "modules":return common+"kit modules modul moduly jistice jistice pojistky baterie baterka analyzer analyser analyzator elektromer breaker fuse battery";
                case "battery":return common+"battery backup holder apc baterie baterka akumulator zaloha zalozni bateriovy modul drzak";
                case "analyser":return common+"cable analyzer analyser analyzator analizator kabelu elektromer merak mereni spotreba vykon watt wattmeter meter energy monitor";
                case "transformer":return common+"transformer transformator trafo limiter regulator watts vykon limit regulace oddeleni siti";
                case "contactor":return common+"smart contactor rele relay stykac on off spinani napajeni data plc";
                case "smartoutput":return common+"smart output module core plc net network led status industrial data bus extension rozsireni vystup komunikace sbernice";
                case "smartkit":return common+"smart kit kits contactor stykac programmable ic10 lua housing chytry modul programovatelny";
                case "smart":return common+"smart core module plc four slots 4 din chytry modul "+DinModuleCatalog.Specs[name].Title;
                case "fuse":return common+"fuse holder cartridge cable fuse pojistka pojistky pojistek pojistkovy drzak patrona "+DinModuleCatalog.Specs[name].Title;
                default:return common+"circuit breaker breaker jistice jistic jistice jisticu jisticovy vypinac ochrana "+DinModuleCatalog.Specs[name].Title;
            }
        }
        internal static string Normalize(string text)
        {
            if(string.IsNullOrEmpty(text))return "";
            var result=new StringBuilder();
            foreach(char c in text.Normalize(NormalizationForm.FormD))
                if(CharUnicodeInfo.GetUnicodeCategory(c)!=UnicodeCategory.NonSpacingMark)result.Append(c);
            return result.ToString().Normalize(NormalizationForm.FormC);
        }
        internal static string ExpandQuery(string query)
        {
            if(string.IsNullOrEmpty(query))return query;
            string normal=Normalize(query);if(normal==query)return query;
            string pattern=string.Concat(normal.Split(new[]{' '},StringSplitOptions.RemoveEmptyEntries).Select(t=>"(?=.*"+Regex.Escape(t)+")"));
            var names=new[]{SwitchboardsMod.DoorKitName,SwitchboardsMod.DoorRoundSwitchName,SwitchboardsMod.DoorIsolatorName,SwitchboardsMod.DoorStopName,SwitchboardsMod.DoorLedName,SwitchboardsMod.DoorLedBlueName,SwitchboardsMod.DoorLedWhiteName,SwitchboardsMod.DoorLedRedName,SwitchboardsMod.DoorLedOrangeName,SwitchboardsMod.DoorBridgeName,SwitchboardsMod.DoorLabelName,SwitchboardsMod.EmergencyStopLabelName,SwitchboardsMod.LabelKitName,SwitchboardsMod.LabelName(1),SwitchboardsMod.LabelName(2),SwitchboardsMod.LabelName(3),SwitchboardsMod.LabelName(4),SwitchboardsMod.LabelName(6),SwitchboardsMod.SmallCombinerName,SwitchboardsMod.SmallCombinerReverseName,SwitchboardsMod.MediumCombinerName,SwitchboardsMod.MediumCombinerReverseName,SwitchboardsMod.CabinetName,SwitchboardsMod.MediumCabinetName,SwitchboardsMod.MediumReverseCabinetName,SwitchboardsMod.ReverseCabinetName,SwitchboardsMod.KitName,SwitchboardsMod.CoverName,SwitchboardsMod.CoverKitName,SwitchboardsMod.RailName,SwitchboardsMod.RailKitName,SwitchboardsMod.SmartKitName,SwitchboardsMod.BreakerKitName}.Concat(DinModuleCatalog.Specs.Keys);
            return names.Any(n=>Matches(n,pattern))?query+","+normal:query;
        }
        internal static bool Matches(string name,string pattern)
        {
            var terms=Terms(name);if(terms==null||string.IsNullOrWhiteSpace(pattern)||pattern.Length>1024)return false;
            try{return Regex.IsMatch(Normalize(terms),Normalize(pattern),RegexOptions.IgnoreCase|RegexOptions.CultureInvariant|RegexOptions.IgnorePatternWhitespace,TimeSpan.FromMilliseconds(50));}
            catch(ArgumentException){return false;}catch(RegexMatchTimeoutException){return false;}
        }
    }
}
