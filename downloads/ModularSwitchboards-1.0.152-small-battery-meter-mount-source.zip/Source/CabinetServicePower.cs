using System.Collections.Generic;
using System.Linq;
namespace ModularSwitchboards
{
    public sealed partial class CabinetWiring
    {
        private IEnumerable<CabinetPowerNode> SmartServiceNodes()
        {
            foreach(var core in SmartModules.Where(c=>!c.IsBeingDestroyed))
            {
                bool enabled=!core.IsCursor&&core.IsStructureCompleted&&core.OnOff&&core.Cabinet==Owner;
                yield return new CabinetPowerNode{ReferenceId=core.ReferenceId,IsServiceLoad=true,ServiceEnabled=enabled,OwnWatts=TransformerBudget.Finite(core.UsedPower)};
                foreach(var output in SmartBus.PowerOutputs(core).Where(o=>!o.IsBeingDestroyed))
                    yield return new CabinetPowerNode{ReferenceId=output.ReferenceId,IsServiceLoad=true,ServiceOwner=core.ReferenceId,ServiceDependency=core.ReferenceId,
                        ServiceEnabled=enabled&&!output.IsCursor&&output.IsStructureCompleted&&output.OnOff&&SmartBus.OutputAt(core,output.OutputAddress)==output,OwnWatts=TransformerBudget.Finite(output.UsedPower)};
            }
        }
    }
}
