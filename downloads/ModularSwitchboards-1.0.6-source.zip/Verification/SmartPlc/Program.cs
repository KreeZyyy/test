using System;using System.Linq;using System.Collections.Generic;using ModularSwitchboards;using Assets.Scripts.GridSystem;using Assets.Scripts.Objects;using Assets.Scripts.Objects.Pipes;using Assets.Scripts.Objects.Electrical;using Assets.Scripts.Networks;
class Program{
 static int n;static void Check(bool v,string why){n++;if(!v)throw new Exception(why);}
 static CabinetWireSaveData W(long a,int p,long b,int q)=>new(){From=new(a,p),To=new(b,q)};
 static void Main(){
 var board=new DinModuleBoard();var cab=new Cabinet();cab.Wiring=new(){Owner=cab};var core=new SmartModule{ReferenceId=10,Board=board,Cabinet=cab};core.transform.position=new(110);board.Structures.Add(core);
 Check(SmartBus.CanPlace(board,new(150,0,0),0),"cannot place directly left");Check(!SmartBus.CanPlace(board,new(160,0,0),0),"gap placement allowed");Check(!SmartBus.CanPlace(board,new(100,0,0),0),"right-side placement allowed");
 var first=new DinBreaker{ReferenceId=30,IsSmartOutputModule=true,Board=board};first.transform.position=new(150);board.Structures.Add(first);
 Check(SmartBus.CanPlace(board,new(160,0,0),0),"cannot extend contiguous row");Check(SmartBus.Core(first)==core,"first Output has wrong Core");
 var second=new DinBreaker{ReferenceId=31,IsSmartOutputModule=true,Board=board};second.transform.position=new(160);board.Structures.Add(second);
 Check(SmartBus.Outputs(core).Select(o=>o.ReferenceId).SequenceEqual(new long[]{30,31}),"bus order must be nearest Core first");
 Check(SmartBus.NextPosition(board,new(999,0,0)).Value.x==170,"placement does not snap to left end");
 Check(SmartBus.HasLeftNeighbour(core,4)&&SmartBus.HasLeftNeighbour(first,1)&&!SmartBus.HasLeftNeighbour(second,1),"demolition order wrong");
 var unrelated=new DinBreaker{ReferenceId=99,Board=board};unrelated.transform.position=new(170);board.Structures.Add(unrelated);Check(!SmartBus.CanPlace(board,new(180,0,0),0),"bus traversed ordinary breaker");board.Structures.Remove(unrelated);
 board.Blocked=true;Check(!SmartBus.CanPlace(board,new(170,0,0),0),"wire/board block bypassed");board.Blocked=false;
 var request=new Request{StructurePrefab=new DinBreaker{IsSmartOutputModule=true},Constructor=new MultiConstructor{PrefabName=SwitchboardsMod.SmartKitName},Board=board,Position=new(170,0,0)};
 Check(Authority.Allows(request),"authority rejects valid attachment");request.Constructor.PrefabName="ordinary";Check(!Authority.Allows(request),"wrong kit accepted by server");request.Constructor.PrefabName=SwitchboardsMod.SmartKitName;request.Position=new(180,0,0);Check(!Authority.Allows(request),"server accepts standalone gap");request.Position=new(170,0,0);request.Rotation=1;Check(!Authority.Allows(request),"rotated bus accepted");request.Rotation=0;
 var empty=new DinModuleBoard();Check(!SmartBus.CanPlace(empty,new(150,0,0),0),"standalone placement allowed");
 var another=new SmartModule{ReferenceId=11,Board=board,Cabinet=cab};another.transform.position=new(40);board.Structures.Add(another);Check(SmartBus.NextPosition(board,new(40,0,0),core).Value.x==170,"aiming at one Core attached to another");board.Blocked=true;Check(SmartBus.NextPosition(board,new(40,0,0),core)==null,"blocked preferred Core redirected attachment");board.Blocked=false;board.Structures.Remove(another);
 var protector1=new DinBreaker{ReferenceId=20,Conducting=true};var protector2=new DinBreaker{ReferenceId=21,Conducting=true};cab.Wiring.Breakers=new[]{protector1,protector2,first,second};
 cab.Wiring.CircuitWires=new[]{W(0,0,10,0),W(0,0,20,0),W(20,1,0,1),W(20,1,30,0),W(0,0,21,0),W(21,1,0,2),W(21,1,31,0)};
 Check(cab.Wiring.ContactCapacity(new(20,1))==3,"breaker OUT must accept three wires");
 Check(cab.Wiring.ContactCapacity(new(20,0))==1&&cab.Wiring.ContactCapacity(new(30,0))==1,"inputs must remain single-wire");
 protector2.IsFuseHolder=true;Check(cab.Wiring.ContactCapacity(new(21,1))==2,"fuse capacity changed");protector2.IsFuseHolder=false;
 var branchWires=new List<CabinetWireSaveData>{W(20,1,100,0),W(20,1,101,0)};
 Check(WireCircuit.CanConnect(new(20,1),new(102,0),branchWires,new long[]{20},out _,capacity:cab.Wiring.ContactCapacity),"third branch rejected");Check(WireCircuit.CanConnect(new(20,1),new(102,0),branchWires,new long[]{20},out _,allowLegacyBypass:true),"save load drops third branch");branchWires.Add(W(20,1,102,0));
 Check(!WireCircuit.CanConnect(new(20,1),new(103,0),branchWires,new long[]{20},out _,allowLegacyBypass:true),"save load allows fourth branch");
 Check(!WireCircuit.CanConnect(new(20,1),new(103,0),branchWires,new long[]{20},out _,capacity:cab.Wiring.ContactCapacity),"fourth branch accepted");branchWires.RemoveAt(1);
 Check(WireCircuit.CanConnect(new(20,1),new(103,0),branchWires,new long[]{20},out _,capacity:cab.Wiring.ContactCapacity),"removed branch did not free capacity");
 var a=cab.InputConnection.cable;var b=cab.Output1Connection.cable;var c=cab.Output2Connection.cable;
 var db=new Device{ReferenceId=101};db.OnNetwork(b);Referencable.All[101]=db;var dc=new Device{ReferenceId=102};dc.OnNetwork(c);Referencable.All[102]=dc;var dp=new Device{ReferenceId=103};dp.OnNetwork(a);Referencable.All[103]=dp;
 // Regression: a protected Core must work with neither external Output cable nor Output expansion.
 var initialWires=cab.Wiring.CircuitWires.ToArray();
 cab.Wiring.CircuitWires=new[]{W(0,0,20,0),W(20,1,10,0)};
 Check(cab.Wiring.SmartPowerCable(core)==a,"protected Core power depends on cabinet Output wiring");
 board.Structures.Remove(first);board.Structures.Remove(second);SmartModuleNetwork.Refresh(core);
 Check(core.PowerCable==a&&core.DataCables.Length==0,"Core needs an Output expansion for power");
 protector1.Conducting=false;SmartModuleNetwork.Refresh(core);Check(core.PowerCable==null,"open breaker still powers Core");
 protector1.Conducting=true;SmartModuleNetwork.Refresh(core);Check(core.PowerCable==a,"closing breaker did not restore Core power");
 board.Structures.Add(first);board.Structures.Add(second);cab.Wiring.CircuitWires=initialWires;
 SmartModuleNetwork.Refresh(core);Check(core.PowerCable==a&&core.PowerCables.SequenceEqual(new[]{a}),"data network powers Core");Check(core.DataCables.SequenceEqual(new[]{b,c}),"multi-output data cables wrong");
 Check(a.CableNetwork.PowerDeviceList.Contains(core)&&!a.CableNetwork.DataDeviceList.Contains(core),"power feed exposes data");Check(b.CableNetwork.DataDeviceList.Contains(core)&&c.CableNetwork.DataDeviceList.Contains(core),"computer visibility missing on Output branches");
 Check(!b.CableNetwork.DataDeviceList.Contains(dc)&&!c.CableNetwork.DataDeviceList.Contains(db),"cable networks bridged");
 Check(core.GetBatchOutput().Select(d=>((Device)d).ReferenceId).OrderBy(x=>x).SequenceEqual(new long[]{10,101,102}),"batch not merged/deduplicated or power branch leaked");
 Check(core.GetLogicableFromId(101)==db&&core.GetLogicableFromId(102)==dc&&core.GetLogicableFromId(103)==null,"device scope ignores outputs");
 Check(SmartBus.NetworkAt(core,0)==b.CableNetwork&&SmartBus.NetworkAt(core,1)==c.CableNetwork&&SmartBus.NetworkAt(core,2)==null,"network indices wrong");
 Check(core.GetLogicableFromIndex(int.MaxValue,1)==c.CableNetwork,"Lua indexed batch missing");
 var savedWires=cab.Wiring.CircuitWires.ToArray();cab.Wiring.CircuitWires=savedWires.Where(w=>w.To.Owner!=30);SmartModuleNetwork.Refresh(core);Check(SmartBus.NetworkAt(core,0)==null&&SmartBus.NetworkAt(core,1)==c.CableNetwork,"unwired slot renumbered later networks");cab.Wiring.CircuitWires=savedWires;SmartModuleNetwork.Refresh(core);
 var third=new DinBreaker{ReferenceId=32,Board=board,IsSmartOutputModule=true};third.transform.position=new(170);board.Structures.Add(third);var protector3=new DinBreaker{ReferenceId=22,Conducting=true};cab.Wiring.Breakers=cab.Wiring.Breakers.Concat(new[]{third,protector3}).ToArray();cab.Wiring.CircuitWires=savedWires.Concat(new[]{W(0,0,22,0),W(22,1,0,3),W(22,1,32,0)}).ToArray();var dd=new Device{ReferenceId=104};dd.OnNetwork(cab.Output3Connection.cable);Referencable.All[104]=dd;SmartModuleNetwork.Refresh(core);Check(core.DataCables.Length==3&&core.GetLogicableFromId(104)==dd&&SmartBus.NetworkAt(core,2)==cab.Output3Connection.cable.CableNetwork,"third Output network not visible");board.Structures.Remove(third);cab.Wiring.CircuitWires=savedWires;SmartModuleNetwork.Refresh(core);Check(core.GetLogicableFromId(104)==null&&!cab.Output3Connection.cable.CableNetwork.DataDeviceList.Contains(core),"removed leaf Output still visible");
 var beforePowerDrop=core.PowerClears;cab.Wiring.CircuitWires=savedWires.Where(w=>w.To.Owner!=10);SmartModuleNetwork.Refresh(core);Check(core.PowerCable==null&&core.PowerCables.Length==0&&core.DataCables.Length==2&&core.PowerClears>beforePowerDrop,"data branches powered Core without POWER IN");cab.Wiring.CircuitWires=savedWires;SmartModuleNetwork.Refresh(core);
 var old=c.CableNetwork;c.CableNetwork=new();dc.OnNetwork(c);SmartModuleNetwork.Refresh(core);Check(!old.DeviceList.Contains(core)&&c.CableNetwork.DataDeviceList.Contains(core),"nonfirst cable network rebuild leaked registration");
 b.CableNetwork.DeviceList.Add(core);SmartModuleNetwork.Refresh(core);Check(b.CableNetwork.DeviceList.Count(d=>d==core)==1,"duplicate native Core registration");
 int oldPowerClears=core.PowerClears;board.Structures.Remove(first);SmartModuleNetwork.Refresh(core);Check(core.PowerClears==oldPowerClears,"data-only change interrupted Core power");Check(core.DataCables.Length==0&&core.PowerCable==a&&SmartBus.Core(second)==null,"broken bus retains data or cuts power");Check(core.GetBatchOutput().Count==0&&core.GetLogicableFromId(102)==null,"broken bus exposes external devices");
 Check(SmartBus.NextPosition(board,new(0,0,0)).Value.x==150,"damaged middle gap cannot be repaired");board.Structures.Add(first);SmartModuleNetwork.Refresh(core);Check(core.DataCables.Length==2,"bus does not recover after repair");
 first.IsBeingDestroyed=true;SmartModuleNetwork.Refresh(core);Check(core.DataCables.Length==0,"destroyed middle Output leaves data");first.IsBeingDestroyed=false;
 core.IsBeingDestroyed=true;Check(SmartBus.Core(first)==null,"destroyed Core accepts extensions");core.IsBeingDestroyed=false;
 SmartModuleNetwork.Unbind(core);SmartModuleNetwork.Unbind(core);Check(new[]{a,b,c}.All(x=>!x.CableNetwork.DeviceList.Contains(core)),"unlink leaked registrations");
 Check(!WireCircuit.Reachable(new(30,0),new(30,1),cab.Wiring.CircuitWires,new long[]{20,21}),"Output invented power pass-through");
 Console.WriteLine(n+" Smart PLC checks passed: contiguous left-only bus, snapping/removal, two data networks, isolated power, native visibility, scope, rebuild and disconnect.");
 }
}
