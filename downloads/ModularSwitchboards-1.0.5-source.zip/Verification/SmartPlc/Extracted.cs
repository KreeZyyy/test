using System;using System.Linq;using System.Collections.Generic;using Assets.Scripts.Objects.Pipes;using Assets.Scripts.Networks;
namespace ModularSwitchboards{partial class CabinetWiring{        internal Assets.Scripts.Objects.Electrical.Cable SmartCable(SmartModule module)
        {
            return SmartCable(module.ReferenceId);
        }
        internal Assets.Scripts.Objects.Electrical.Cable SmartCable(long id)
        {
            if(Owner==null||Owner.IsCursor||!Owner.IsStructureCompleted||Owner.GridController==null)return null;
            var modules=Breakers.ToArray();
            int selection=SmartCircuit.Selection(id,CircuitWires,
                modules.Where(b=>b.Conducting).Select(b=>b.ReferenceId),
                modules.Where(b=>!b.IsAnalyserModule&&!b.IsBatteryModule&&!b.IsSmartOutputModule&&!b.IsDoorPart).Select(b=>b.ReferenceId));
            if(selection==AnalyserCircuit.Input)return Owner.InputConnection?.GetCable();
            if(selection==0)return null;
            var cables=new[]{Owner.Output1Connection,Owner.Output2Connection,Owner.Output3Connection}
                .Select((port,i)=>new{port,bit=i==2?8:1<<i}).Where(p=>(selection&p.bit)!=0)
                .Select(p=>p.port?.GetCable()).ToArray();
            // Register the real device on exactly one native network. Never bridge
            // unrelated output data networks through the internal module.
            if(cables.Select(c=>c?.CableNetwork).Distinct().Count()!=1)return null;
            return cables.FirstOrDefault(c=>c!=null&&c.CableNetwork!=null);
        }

}
partial class SmartModule{        public bool IsValidIndex(int index)=>index==int.MaxValue;
        public ILogicable GetLogicableFromIndex(int index,int networkIndex=int.MinValue)=>index==int.MaxValue?(networkIndex==int.MinValue?this:SmartBus.NetworkAt(this,networkIndex)):null;
        public ILogicable GetLogicableFromId(int id,int networkIndex=int.MinValue)
        {
            if(id==ReferenceId)return networkIndex==int.MinValue?this:SmartBus.NetworkAt(this,networkIndex);
            var device=Referencable.Find<Device>(id);
            return device!=null&&SmartBus.Networks(this).Any(n=>n.DataDeviceList.Contains(device))?networkIndex==int.MinValue?(ILogicable)device:device.GetNetwork(networkIndex):null;
        }
        public List<ILogicable> GetBatchOutput()=>SmartBus.Networks(this).SelectMany(n=>n.DataDeviceList).GroupBy(d=>d.ReferenceId).Select(g=>(ILogicable)g.First()).ToList();
        internal void ClearSupplyPower()=>AssessPower(null,false);}}