using System;
using System.Collections.Generic;
using System.Linq;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Objects;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class SmartOutputModel
    {
        internal const string PrefabName="StructureSmartOutputModule";
        internal static void Install(DinBreaker module,Sprite thumbnail)
        {
            var model=module.transform.Find("DinBreakerModel");
            foreach(var name in new[]{"BreakerLever","BreakerIndicator","BreakerControl"})
            {var part=model.Find(name);if(part!=null)UnityEngine.Object.DestroyImmediate(part.gameObject);}
            var view=module.GetComponent<BreakerSwitchView>();if(view!=null)UnityEngine.Object.DestroyImmediate(view);
            var mesh=DinBreakerModel.Build(plain:true,inputOnly:true);model.GetComponent<MeshFilter>().sharedMesh=mesh;
            var hit=model.GetComponent<BoxCollider>();hit.center=mesh.bounds.center;hit.size=mesh.bounds.size;
            module.Interactables=new List<Interactable>();module.HasOnOffState=false;
            module.BuildStates[0].Interactables=module.Interactables;module.BuildStates[0].Colliders=new List<Collider>{hit};
            module.CacheStates(true);module.Bounds=new Bounds(Vector3.Scale(mesh.bounds.center,DinBreakerModel.VisualScale),Vector3.Scale(mesh.bounds.size,DinBreakerModel.VisualScale));module.GridBounds=new GridBounds(module);
            module.Thumbnail=thumbnail;module.BuildStates[0].Thumbnail=thumbnail;
            var plate=new GameObject("ModuleRatingPlate"){layer=module.gameObject.layer};plate.transform.SetParent(model,false);
            var vertices=new List<Vector3>();var normals=new List<Vector3>();var triangles=new List<int>();
            RoundedGeometry.Box(vertices,normals,triangles,new Vector3(0,0,.0645f),new Vector3(.012f,.034f,.0005f),.0003f);
            var plateMesh=new Mesh{name="Smart.Output.NamePlate"};plateMesh.SetVertices(vertices);plateMesh.SetNormals(normals);plateMesh.subMeshCount=5;
            for(int role=0;role<5;role++)plateMesh.SetTriangles(role==1?triangles.ToArray():new int[0],role);
            CabinetGeometry.ApplyNativeUv(plateMesh);plate.AddComponent<MeshFilter>().sharedMesh=plateMesh;
            var plateRenderer=plate.AddComponent<MeshRenderer>();plateRenderer.sharedMaterials=CabinetGeometry.Materials;
            var plateBlock=new MaterialPropertyBlock();plateBlock.SetFloat(Thing.DiffuseIndexPropertyID,(int)Assets.Scripts.Objects.Motherboards.ColorType.White);plateBlock.SetColor(Thing.EMISSION_COLOR,Color.black);plateRenderer.SetPropertyBlock(plateBlock,1);
            Font font=null;foreach(var name in new[]{"LegacyRuntime.ttf","Arial.ttf"}){try{font=Resources.GetBuiltinResource<Font>(name);}catch(Exception){}if(font!=null)break;}
            if(font==null)font=Resources.FindObjectsOfTypeAll<Font>().FirstOrDefault();
            if(font!=null)
            {
                var go=new GameObject("SmartOutputText"){layer=module.gameObject.layer};go.transform.SetParent(model,false);go.transform.localPosition=new Vector3(0,0,.0651f);go.transform.localRotation=Quaternion.Euler(0,180,0);
                var text=go.AddComponent<TextMesh>();text.font=font;text.fontSize=64;text.fontStyle=FontStyle.Bold;text.characterSize=.004f;text.anchor=TextAnchor.MiddleCenter;text.alignment=TextAlignment.Center;text.richText=false;text.color=Color.black;text.text="D\nA\nT\nA";DepthLabelText.Apply(text);
            }
        }
    }
}
