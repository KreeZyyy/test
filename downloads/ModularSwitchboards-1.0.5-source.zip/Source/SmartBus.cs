using System.Collections.Generic;
using System.Linq;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Networks;
using Assets.Scripts.Objects;
using LibConstruct;
namespace ModularSwitchboards
{
    internal readonly struct SmartBusPart
    {
        internal readonly long Id;internal readonly int X,Width;internal readonly bool Core,Extension;
        internal SmartBusPart(long id,int x,int width,bool core,bool extension){Id=id;X=x;Width=width;Core=core;Extension=extension;}
    }
    internal static class SmartBusLayout
    {
        internal static long CoreToRight(int x,int width,IEnumerable<SmartBusPart> parts)
        {
            var items=parts.ToArray();var seen=new HashSet<long>();int next=x+width;
            while(true)
            {
                var adjacent=items.Where(p=>p.X==next).ToArray();
                if(adjacent.Length!=1)return 0;
                var part=adjacent[0];if(part.Id<=0||part.Width<=0||!seen.Add(part.Id))return 0;
                if(part.Core)return part.Id;
                if(!part.Extension)return 0;
                next+=part.Width;
            }
        }
    }
    internal static class SmartBus
    {
        private static SmartBusPart[] Parts(PlacementBoard board)=>DinParts.On(board).Where(p=>!p.IsBeingDestroyed&&!p.IsCursor)
            .Select(p=>new SmartBusPart(p.ReferenceId,board.WorldToGrid(p.transform.position).x/10,DinParts.Width(p),p is SmartModule,p is DinBreaker d&&d.IsSmartOutputModule)).ToArray();
        internal static SmartModule Core(DinModuleBoard board,Grid3 position,int width=1)
        {
            if(board==null||position.y!=0||position.z!=0||position.x%10!=0)return null;
            long id=SmartBusLayout.CoreToRight(position.x/10,width,Parts(board));
            return id==0?null:board.Structures.OfType<SmartModule>().FirstOrDefault(m=>m.ReferenceId==id&&!m.IsBeingDestroyed);
        }
        internal static SmartModule Core(DinBreaker extension)=>extension.IsSmartOutputModule?Core(extension.Board as DinModuleBoard,extension.GetLocalGrid(),extension.ModuleWidth):null;
        internal static IEnumerable<DinBreaker> Outputs(SmartModule core)=>core.Board==null?Enumerable.Empty<DinBreaker>():core.Board.Structures.OfType<DinBreaker>()
            .Where(m=>m.IsSmartOutputModule&&!m.IsBeingDestroyed&&Core(m)==core).OrderByDescending(m=>m.GetLocalGrid().x);
        internal static CableNetwork NetworkAt(SmartModule core,int index)
        {
            if(index<0)return null;
            var output=Outputs(core).Skip(index).FirstOrDefault();
            return output==null?null:core.Cabinet?.Wiring.SmartCable(output.ReferenceId)?.CableNetwork;
        }
        internal static CableNetwork[] Networks(SmartModule core)=>Outputs(core).Select(m=>core.Cabinet?.Wiring.SmartCable(m.ReferenceId)?.CableNetwork)
            .Where(n=>n!=null).Distinct().ToArray();
        internal static Grid3? NextPosition(DinModuleBoard board,Grid3 aimed,SmartModule preferred=null)
        {
            if(board==null)return null;
            var candidates=board.Structures.OfType<SmartModule>().Where(c=>!c.IsBeingDestroyed&&!c.IsCursor&&(preferred==null||c==preferred))
                .Select(c=>{var outputs=Outputs(c).ToArray();int x=outputs.Length==0?c.GetLocalGrid().x:outputs.Min(o=>o.GetLocalGrid().x);return new Grid3(x-10,0,0);})
                .Where(p=>CanPlace(board,p,0)).OrderBy(p=>System.Math.Abs(p.x-aimed.x)).ToArray();
            return candidates.Length==0?(Grid3?)null:candidates[0];
        }
        internal static bool CanPlace(DinModuleBoard board,Grid3 position,int rotation)
            =>rotation==0&&board.CanPlace(position,rotation,1)&&Core(board,position)!=null;
        internal static bool HasLeftNeighbour(Structure part,int width)
            =>part is IPlacementBoardStructure mounted&&mounted.Board!=null&&Parts(mounted.Board).Any(p=>p.Extension&&p.X+p.Width==mounted.Board.WorldToGrid(part.transform.position).x/10);
    }
}
