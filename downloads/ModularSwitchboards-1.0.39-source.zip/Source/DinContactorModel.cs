using System;
using System.Collections.Generic;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Motherboards;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class DinContactorModel
    {
        internal const string PrefabName="StructureDinContactor";
        internal static void Install(DinBreaker module)
        {
            var model=module.transform.Find("DinBreakerModel");
            foreach(var name in new[]{"BreakerLever","BreakerIndicator","BreakerControl"}){var t=model.Find(name);if(t!=null)UnityEngine.Object.DestroyImmediate(t.gameObject);}
            var oldView=module.GetComponent<BreakerSwitchView>();if(oldView!=null)UnityEngine.Object.DestroyImmediate(oldView);
            var mesh=Build();
            model.GetComponent<MeshFilter>().sharedMesh=mesh;
            var hit=model.GetComponent<BoxCollider>();hit.center=mesh.bounds.center;hit.size=mesh.bounds.size;
            module.Interactables=new List<Interactable>();module.HasOnOffState=false;module.ContactorClosed=false;
            var state=module.BuildStates[0];state.Interactables=module.Interactables;state.Colliders=new List<Collider>{hit};
            module.Thumbnail=CabinetIcons.Get("DinContactor");module.Thumbnails=new Sprite[0];state.Thumbnail=module.Thumbnail;
            module.CacheStates(true);
            var well=new GameObject("ContactorGuide"){layer=module.gameObject.layer};well.transform.SetParent(model,false);
            well.AddComponent<MeshFilter>().sharedMesh=BuildGuide();well.AddComponent<MeshRenderer>().sharedMaterials=CabinetGeometry.Materials;
            var window=ApcContactorWindow.Install(model);
            foreach(bool on in new[]{true,false})
            {
                var panel=new GameObject(on?"ContactorOnPanel":"ContactorOffPanel"){layer=module.gameObject.layer};panel.transform.SetParent(model,false);
                panel.AddComponent<MeshFilter>().sharedMesh=BuildPanel(on);panel.AddComponent<MeshRenderer>().sharedMaterials=CabinetGeometry.Materials;
            }
            var slider=new GameObject("ContactorMechanicalSlider"){layer=module.gameObject.layer};slider.transform.SetParent(model,false);
            slider.transform.localPosition=new Vector3(0,ContactorIndicatorMotion.HalfTravel,0);
            var moving=BuildSlider();
            slider.AddComponent<MeshFilter>().sharedMesh=moving;slider.AddComponent<MeshRenderer>().sharedMaterials=CabinetGeometry.Materials;
            var view=module.gameObject.AddComponent<DinContactorView>();view.Owner=module;view.Slider=slider.transform;view.WindowSurface=window;
            DinBreakerModel.Refresh(module);
            if(module.Blueprint!=null)ModelBlueprint.Refresh(module);
        }

        internal static Mesh ScaleSurface(Mesh mesh)
        {
            var points=mesh.vertices;var normals=mesh.normals;
            for(int i=0;i<points.Length;i++)
            {
                points[i].x*=ContactorWindowLayout.ScaleX;points[i].y*=ContactorWindowLayout.ScaleY;
                normals[i]=new Vector3(normals[i].x/ContactorWindowLayout.ScaleX,normals[i].y/ContactorWindowLayout.ScaleY,normals[i].z).normalized;
            }
            mesh.vertices=points;mesh.SetNormals(new List<Vector3>(normals));mesh.RecalculateBounds();return mesh;
        }

        internal static Mesh BuildSlider()
        {
            var vertices=new List<Vector3>();var normals=new List<Vector3>();var groups=new List<int>[5];for(int i=0;i<5;i++)groups[i]=new List<int>();
            RoundedGeometry.Box(vertices,normals,groups[4],new Vector3(0,0,.0609f),new Vector3(.0114f,.011f,.0012f),.0005f);
            RoundedGeometry.Box(vertices,normals,groups[4],new Vector3(0,0,.0621f),new Vector3(.0068f,.002f,.0015f),.0004f);
            var moving=new Mesh{name="Contactor.CompactSlider"};moving.SetVertices(vertices);moving.SetNormals(normals);moving.subMeshCount=5;for(int i=0;i<5;i++)moving.SetTriangles(groups[i],i);CabinetGeometry.ApplyNativeUv(moving);moving.RecalculateBounds();return ScaleSurface(moving);
        }

        internal static Mesh BuildGuide()
        {
            var v=new List<Vector3>();var n=new List<Vector3>();var g=new List<int>[5];for(int i=0;i<5;i++)g[i]=new List<int>();
            Action<Vector3,Vector3,Vector3,Vector3,Vector3> quad=(a,b,c,d,normal)=>
            {
                int start=v.Count;v.AddRange(new[]{a,b,c,d});n.AddRange(new[]{normal,normal,normal,normal});
                var cross=Vector3.Cross(b-a,c-a);bool reverse=cross.x*normal.x+cross.y*normal.y+cross.z*normal.z<0;
                g[4].AddRange(reverse?new[]{start,start+2,start+1,start,start+3,start+2}:new[]{start,start+1,start+2,start,start+2,start+3});
            };
            const float x=.0059f,y=.0123f,rear=.059f,front=.064f;
            // One floor and two end walls. The existing breaker fascia is the rim;
            // there is no second frame sitting across it or proud wall end to shimmer.
            quad(new Vector3(-x,-y,rear),new Vector3(x,-y,rear),new Vector3(x,y,rear),new Vector3(-x,y,rear),Vector3.forward);
            quad(new Vector3(-x,-y,rear),new Vector3(x,-y,rear),new Vector3(x,-y,front),new Vector3(-x,-y,front),Vector3.up);
            quad(new Vector3(-x,y,rear),new Vector3(x,y,rear),new Vector3(x,y,front),new Vector3(-x,y,front),Vector3.down);
            // Each side is one continuous extruded profile with a real groove.
            // All edges reach the end walls; no short overlapping rail boxes remain.
            foreach(float side in new[]{-1f,1f})
            {
                var section=new[]{new Vector3(side*x,0,front),new Vector3(side*x,0,.062f),new Vector3(side*.00505f,0,.062f),new Vector3(side*.00505f,0,.06165f),new Vector3(side*.00585f,0,.06165f),new Vector3(side*.00585f,0,.06015f),new Vector3(side*.00505f,0,.06015f),new Vector3(side*.00505f,0,.0599f),new Vector3(side*x,0,.0599f),new Vector3(side*x,0,rear)};
                for(int i=0;i<section.Length-1;i++)
                {
                    var a=section[i];var b=section[i+1];var edge=b-a;
                    var normal=new Vector3(edge.z,0,-edge.x).normalized*side;
                    quad(a+new Vector3(0,-y,0),b+new Vector3(0,-y,0),b+new Vector3(0,y,0),a+new Vector3(0,y,0),normal);
                }
            }
            var mesh=new Mesh{name="Contactor.SimpleContinuousWell"};mesh.SetVertices(v);mesh.SetNormals(n);mesh.subMeshCount=5;for(int i=0;i<5;i++)mesh.SetTriangles(g[i],i);CabinetGeometry.ApplyNativeUv(mesh);mesh.RecalculateBounds();return ScaleSurface(mesh);
        }

        internal static Mesh Build(){return DinBreakerModel.Build(plain:true,contactor:true,wideFace:true);}
        internal static Mesh BuildPanel(bool on)
        {
            var v=new List<Vector3>();var n=new List<Vector3>();var g=new List<int>[5];for(int i=0;i<5;i++)g[i]=new List<int>();
            RoundedGeometry.Box(v,n,g[0],new Vector3(0,on?.0063f:-.0063f,.05945f),new Vector3(.0088f,.0078f,.0003f),.0001f);
            var mesh=new Mesh{name="Contactor.FlatStatePanel"};mesh.SetVertices(v);mesh.SetNormals(n);mesh.subMeshCount=5;for(int i=0;i<5;i++)mesh.SetTriangles(g[i],i);CabinetGeometry.ApplyNativeUv(mesh);mesh.RecalculateBounds();return ScaleSurface(mesh);
        }

    }
    // Only the visual follows the replicated contact state. Initial load/join/preview
    // snaps silently; subsequent changes animate and play one local native clack.
    public sealed class DinContactorView:MonoBehaviour
    {
        public DinBreaker Owner;
        public Transform Slider;
        public NativePortSurface WindowSurface;
        private ContactorIndicatorMotion motion;
        private void LateUpdate()
        {
            if(Owner==null)Owner=GetComponent<DinBreaker>();
            if(Owner==null||Slider==null)return;
            if(Owner.IsCursor){motion=null;return;}
            if(motion==null)motion=new ContactorIndicatorMotion();
            bool active=!Owner.IsCursor&&!Owner.IsBeingDestroyed&&Owner.Board!=null;
            bool changed=motion.Tick(active,Owner.ContactorClosed,Time.deltaTime);
            Slider.localPosition=new Vector3(0,motion.Offset,0);
            if(WindowSurface!=null)
            {
                var renderer=WindowSurface.GetComponent<MeshRenderer>();
                if(renderer!=null){renderer.SetPropertyBlock(null);WindowSurface.Restore();}
            }
            if(changed)ContactorSwitchAudio.Play(Owner,Owner.ContactorClosed);
        }
    }
}
