# LibConstruct integration — 0.8.0

User supplied Workshop 3751750326, About ModID LibConstructReloaded, version 0.3.0.
The DLL is named LibConstruct.dll and its runtime Mod ID remains LibConstruct.
SHA256: 18021b2f752c9f1eb7ba167454e67de8991a02727e0bf2cba8c2bc3aae08b8b5
This differs from the original GitHub v0.3.0 binary. Use the supplied Workshop DLL.

Project: -p:LibConstructPath=<path to Workshop LibConstruct.dll>, Private=false.
About.xml requires and loads after LibConstructReloaded / Workshop 3751750326.
Entry point checks API resolution; prefab preparation checks library initialization.
No third-party DLL is bundled. Existing prefab IDs are unchanged. DinRailSaveData gains an optional Modules board field; 0.7.0 rails create an empty board on load.
Compilation and PlacementBoard/API probe against supplied game and Booster DLLs passed.
Host and structure hooks for save, join, registration and destruction are implemented. Engine-stub tests passed; actual game and multiplayer tests remain required.

Implemented: cabinet board host, two separately mountable DIN rails, row occupancy, save/network lifecycle. DIN rail kit: 1 Iron, Electronics Printer only. Implemented in 0.8.0: rail-owned DinModuleBoard and one-module DinBreaker mounting prototype with nested save/join hooks. Future work: functional switching, trip protection and wiring.
