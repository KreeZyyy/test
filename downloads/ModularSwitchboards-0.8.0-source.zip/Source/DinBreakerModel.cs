using System.Collections.Generic;
using Assets.Scripts;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Motherboards;
using UnityEngine;
using UnityEngine.Rendering;
using HarmonyLib;
using Rendering;
using Assets.Scripts.UI;

namespace ModularSwitchboards
{
    internal static class DinBreakerModel
    {
        internal static Mesh Build()
        {
            var vertices = new List<Vector3>();
            var triangles = new List<int>[5];
            for (int i=0;i<5;i++) triangles[i]=new List<int>();
            Box(vertices,triangles,1,new Vector3(0,0,.029f),new Vector3(.0176f,.075f,.056f));
            Box(vertices,triangles,1,new Vector3(0,0,.059f),new Vector3(.0176f,.04f,.008f));
            Box(vertices,triangles,3,new Vector3(0,0,.0635f),new Vector3(.013f,.022f,.001f));
            Box(vertices,triangles,0,new Vector3(0,.003f,.068f),new Vector3(.012f,.007f,.009f));
            foreach (float side in new[]{-1f,1f})
            {
                Box(vertices,triangles,4,new Vector3(0,side*.03f,.0577f),new Vector3(.009f,.009f,.0015f));
                Box(vertices,triangles,3,new Vector3(0,side*.03f,.0586f),new Vector3(.006f,.001f,.0005f));
            }
            var mesh=new Mesh{name="Switchboards.DinBreaker1P"};mesh.SetVertices(vertices);mesh.subMeshCount=5;
            for(int i=0;i<5;i++)mesh.SetTriangles(triangles[i],i);
            mesh.RecalculateNormals();CabinetGeometry.ApplyNativeUv(mesh);mesh.RecalculateBounds();return mesh;
        }
        private static void Box(List<Vector3> vertices,List<int>[] triangles,int role,Vector3 center,Vector3 size)
            => DinRailModel.AddBox(vertices,triangles[role],center,size);
        internal static void Install(DinBreaker module, Transform storage)
        {
            foreach(var component in module.GetComponentsInChildren<Renderer>(true)) Object.DestroyImmediate(component);
            foreach(var component in module.GetComponentsInChildren<MeshFilter>(true)) Object.DestroyImmediate(component);
            foreach(var component in module.GetComponentsInChildren<Collider>(true)) Object.DestroyImmediate(component);
            foreach(var component in module.GetComponentsInChildren<Animator>(true)) Object.DestroyImmediate(component);
            module.BaseAnimator=null;
            module.Renderers=new List<ThingRenderer>();
            module.Interactables=new List<Interactable>();module.Slots=new List<Slot>();
            module._staticColliders=new List<Collider>();module._dynamicColliders=new List<Collider>();module._selfColliders=new List<Collider>();
            module.CustomNavMeshFilter=null;module.structureRenderMode=StructureRenderMode.Standard;
            module.ForceGridBounds.Clear();module.BrokenBuildStates=new List<BrokenBuildState>();
            module.StructureCollisionType=CollisionType.BlockCustom;
            module.SelectionDisplay=SelectionHighlightMethod.Bounds;module.UseCellPosition=false;
            module.PaintableMaterial=null;module.HasColorState=false;module.MPBRenderers.Clear();
            var model=new GameObject("DinBreakerModel"){layer=module.gameObject.layer};model.transform.SetParent(module.transform,false);
            var mesh=Build();
            model.AddComponent<MeshFilter>().sharedMesh=mesh;
            var renderer=model.AddComponent<MeshRenderer>();renderer.sharedMaterials=CabinetGeometry.Materials;
            renderer.lightProbeUsage=LightProbeUsage.BlendProbes;renderer.reflectionProbeUsage=ReflectionProbeUsage.BlendProbes;
            renderer.shadowCastingMode=ShadowCastingMode.On;renderer.receiveShadows=true;
            var collider=model.AddComponent<BoxCollider>();collider.center=mesh.bounds.center;collider.size=mesh.bounds.size;
            module.Bounds=mesh.bounds;module.SurfaceArea=.016f;
            module.GridBounds=new GridBounds(module);
            module.Thumbnail=CabinetIcons.Get("DinBreaker");module.Thumbnails=new Sprite[0];
            var state=module.BuildStates[0];state.Visualizer=renderer;state.StateMeshes=new List<Mesh>();state.RendererInstance=null;
            state.Colliders=new List<Collider>{collider};state.Interactables=new List<Interactable>();
            state.LinkedGameObjects=new List<GameObject>();state.RenderMode=BuildStateRenderMode.OnMyState;
            state.BlockAir=state.AlwaysBlockAir=state.BlockLight=state.BlockGravity=false;state.Thumbnail=module.Thumbnail;
            AccessTools.Field(typeof(BuildState),"initialDrawData").SetValue(state,new DrawData{mesh=null,materials=new Material[0]});
            var blueprint=new GameObject("DinBreakerBlueprint"){layer=module.gameObject.layer};blueprint.transform.SetParent(storage,false);
            var filter=blueprint.AddComponent<MeshFilter>();filter.sharedMesh=mesh;
            var br=blueprint.AddComponent<MeshRenderer>();br.sharedMaterial=CabinetGeometry.Materials[4];
            var wire=blueprint.AddComponent<Wireframe>();wire.BlueprintTransform=blueprint.transform;
            wire.BlueprintBounds=mesh.bounds;wire.BlueprintMeshFilter=filter;wire.BlueprintRenderer=br;
            blueprint.AddComponent<CabinetBlueprint>();
            module.Blueprint=blueprint;module.BlueprintOrientVector=Vector3.zero;
        }
        internal static void Refresh(Thing module)
        {
            foreach(var renderer in module.GetComponentsInChildren<MeshRenderer>(true))
            {
                if(renderer.name!="DinBreakerModel" || renderer.GetComponentInParent<Thing>()!=module)continue;
                for(int role=0;role<5;role++)
                {
                    var block=new MaterialPropertyBlock();renderer.GetPropertyBlock(block,role);
                    block.SetFloat(Thing.DiffuseIndexPropertyID,role==0?(int)ColorType.Blue:CabinetGeometry.PaletteIndices[role]);
                    block.SetFloat(Thing.SmoothnessIndexPropertyID,module.SmoothnessIndex);
                    block.SetColor(Thing.EMISSION_COLOR,Color.black);renderer.SetPropertyBlock(block,role);
                }
            }
        }
    }
}
