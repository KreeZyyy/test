using System.Xml.Serialization;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Networking;
using Assets.Scripts.Objects;
using Assets.Scripts.Localization2;
using LibConstruct;
using UnityEngine;

namespace ModularSwitchboards
{
    public sealed class DinBreakerSaveData : StructureSaveData
    {
        [XmlElement] public PlacementBoardStructureSaveData RailBoard;
    }

    public sealed class DinBreaker : Structure, IPlacementBoardStructure
    {
        public PlacementBoard Board { get; set; }
        public PlacementBoard.BoardCell[] BoardCells { get; set; }
        public override void Awake()
        {
            base.Awake();
            BoardStructureHooks.Awake(this);
            DinBreakerModel.Refresh(this);
        }
        public override Grid3 GetLocalGrid() => Board == null ? default(Grid3) : Board.WorldToGrid(Transform.position);

        public int ModuleWidth => 1;
        internal static bool CanPlace(PlacementBoard board, Grid3 position, int rotation)
            => board is DinModuleBoard modules && modules.CanPlace(position, rotation, 1);
        public override CanConstructInfo CanConstruct()
        {
            if ((IsCursor && PlacementBoard.CursorBoard != Board) || !(Board is DinModuleBoard modules)) return CanConstructInfo.InvalidPlacement("Aim at an installed DIN rail inside an open cabinet.");
            var position = Board.WorldToGrid(Transform.position);
            if (IsCursor)
            {
                position = new Grid3(position.x, 0, 0);
                Transform.SetPositionAndRotation(Board.GridToWorld(position), Board.IndexToRotation(0));
            }
            return CanPlace(Board, position, Board.RotationToIndex(Transform.rotation))
                ? CanConstructInfo.ValidPlacement : CanConstructInfo.InvalidPlacement("Choose a free module position on an installed rail.");
        }
        protected override CanConstructInfo CanDeconstruct()
            => Board?.PrimaryHost is DinRail host && host.CanFitModules
                ? CanConstructInfo.ValidPlacement : CanConstructInfo.InvalidPlacement("Open the cabinet first.");
        public override DelayedActionInstance AttackWith(Attack attack, bool doAction = true)
        {
            if (!(Board?.PrimaryHost is DinRail host) || !host.CanFitModules) return null;
            return base.AttackWith(attack, doAction);
        }
        public override void OnDeregistered()
        {
            base.OnDeregistered();
            if (Board != null) BoardStructureHooks.OnDeregistered(this);
        }
        public override ThingSaveData SerializeSave()
        {
            ThingSaveData data = new DinBreakerSaveData();
            InitialiseSaveData(ref data);
            return data;
        }
        protected override void InitialiseSaveData(ref ThingSaveData data)
        {
            base.InitialiseSaveData(ref data);
            if (data is DinBreakerSaveData save && Board != null)
                save.RailBoard = BoardStructureHooks.SerializeSave(this);
        }
        public override void DeserializeSave(ThingSaveData data)
        {
            base.DeserializeSave(data);
            if (data is DinBreakerSaveData save && save.RailBoard != null)
                BoardStructureHooks.DeserializeSave(this, save.RailBoard);
        }
        public override void SerializeOnJoin(RocketBinaryWriter writer)
        {
            base.SerializeOnJoin(writer);
            BoardStructureHooks.SerializeOnJoin(writer, this);
        }
        public override void DeserializeOnJoin(RocketBinaryReader reader)
        {
            base.DeserializeOnJoin(reader);
            BoardStructureHooks.DeserializeOnJoin(reader, this);
        }
    }
}
