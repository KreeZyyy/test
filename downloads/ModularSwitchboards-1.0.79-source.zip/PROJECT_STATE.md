# Latest local candidate: 1.0.79 (not uploaded)

Local rupture visuals only: retained saved insulation/type material slots, two local6mm scorched ends with22percent taper and three grey metal strands per end. Power/routing/save/effects semantics unchanged178, already burnt saves update automatically. Build0warnings/errors;66123 actual mesh/material/geometry checks. Visual preview /workspace/work/WireDamage-1.0.79-preview.png is Blender approximation, not Unity verification. No upload request yet for179.

# Current local candidate: 1.0.78

Universal8mm route reservations; native-rated actual per-wire overload and persistent rupture. Local tests/build reports are in Verification. No GitHub upload has been authorized for this candidate yet. Host/clients need matching1.0.78 due packet revision -4 and route revision8. Larger spacing intentionally lowers dense-door capacity; old paths migrate atomically or remain untouched.

# Current build: 0.13.106

UserreportsMedium/MediumReverse internalwireslostafterloadwhileSmallworks. Rootcause productionCabinetWiring.Valid fixedSmallcoordinatebounds .18/.20X,.24Y evenforMediumwidth.8/height1. ValidnowINSTANCE method readsOwner?.PrefabName viaCabinetShape.Width/Height:halfwidth-.02ordinary/fullhalfwidthneutral,halfheight-.01. Smalllimitsunchanged,Medium±.38/±.40Xand±.49Y. AllotherdataguardsandLoadconnectivityunchanged,samevalidatorforXMLworldloadandbinaryReadjoin. No schemachange/rerouteversionbump;restorefromoriginalsavewithrecords,alreadyresavedemptycannotrecoverautomatically.

Verification/Wiring/make-serde.py nowextractsactualupdatedValid/Load/Write/Read,ownerstubexistingSwitchboardCabinet,routeversion6(notstale5). NewVariantSerdeHarness partialSerdeHarness:62checks across4variants XMLarraythenLoad+binaryjoin,exactpoints/endpoints/Output3/Bridge/color/InputSlot/routeversion,invalidwidthheightNaNdepth,provesMediumfixturesfailoldSmallbounds. Fullwiringproductiongeometry/power/routes/migrations/serde suitepassed12464reportedchecks+62newvariantchecks. ProductionRelease0errors/0warnings. No unrelatedtestsneeded. User sentimagegreenstatusIC10running/nativeLEDtext;confirmedin-gamenativeIC10diode/status,NOTLua/106persistence. Lua/poweraudio/preview otherlivevalidationstillpending.

README/PROJECT_STATE/wires106-verification.jsonupdated,106versioncsproj/About/SourceSwitchboardsMod. Existingpreviewimages+example+optionalLua preserved. Packaging/publicationcompletionseehandoff.

## Follow-up editor issue in same release

User105screenshotstill2rowswithonephysicalSmart, plusorangecompilefaultline4lonet (explainedcorrectly). ExtendedSmartComputerDevices.Module resolvesICircuitHolderwrapper.GetLogicableFromIndex(max),InvalidexcludesCabinetnull/inactive. FinalUIguard SmartEditorDropdown: Track onmotherboardOnInserted/HandleDeviceListChange (Firstprefix) bindsprivate_dropdown toSmartEditorOwner; BeforeItemsChanged(Lastprefix) pairsprivate_circuitHolders and_items,filtersand rebuildslabels+holders together,preserves selectedbaseidentity. ScopeonlytrackedICeditordropdowns. LuaEnsurelazyprobe onTrack, optionalpostfixRebuildDeviceList restores selectionagainafterLua'slateItemClicked(oldindex). SourceSortfilterretained. Runtimeidentitydiagnostic writesSmartEditor-devices.txt underpersistentLocalLow/ModularSwitchboards/Diagnostics withassembly-qualifiedholders/IDs/position/Cabinet andbefore/aftercounts. Preciseliverootcauseunknown,don'tcollapsegenuinelydistinctIDsbyname.21actualfilter+finalUIfixturetests pass;23Luaadapterchecks alsoincludeoptionalpostfixmock,metadataagainstsuppliedDLL andNoLuaassemblyreference. NativeIC10greenrunningandorangenativecompilationfaultshowninuserimages,Luastillnotconfirmed. Finalrebuildandpackagingseehandoff.

## Previous version

# Current build: 0.13.105

User uploaded3659911735.rar (StationeersLua1.0), requested optional Lua support AND fullmod-list preview/metadata; author explicitly KreeZy, notGitHubKreeZyyy. Thirdparty archive extracted read-onlyreference via libarchive into work/lua-reference/3659911735; decompiled inspection only, NOTredistributed. Native ModData.GetPreviewImage explicitlyloadsAbout/Preview.png; ModAbout fieldsName/Author/Version/Description/WorkshopHandle/Tags inspected. New ownBlender preview render inTools/render_mod_preview.py,AboutPreview1600x900/thumb640x360;AuthorKreeZy,Description/Tags; nofabricated WorkshopID. Existing LibConstruct dependencies preserved, noLua required. SourceSwitchboardsMod.Version had stale81; now105 matchesDLL/About.

SmartLuaRuntime optionalreflection adapter to uploadedinternal LuaChipRuntimeManager API: TickServerSide(chip,double),UpdateActivityState(long,bool),GetChipErrorTooltip(long),HasActiveRuntime(long),TrySnapshotAndDisposeRuntime(long),SaveInProgress. IsLua knownprefabname prefix ItemIntegratedCircuitLua. No compileReference/mandatorymetadata/copyLuaDLL. Lazy discovery; safeabsence/incompatibleAPI leavesIC10path;missingLua gets explanatory statuserror. Execute selectsLua anddirectoriginalVMtick(.5s) vsIC10Execute128; server/power/on/paused/run guards. SmartLateUpdate updatesLuaactivity includingoff/paused; removal/destruction snapshots throughLuaVM; globalLua chip save patches keepownership. LuaRunStatus usesVMactive notnative_lines;GetPassiveTooltip detail fromLua runtime. NativeICircuitHolder already gives ownmodule(db=2147483647) andscopednetwork. Examples/DinSmartModule.lua counter viaic.writeBASE_UNIT_INDEX Setting,Mode0. No d0-d5 selectors.

LuaNetManager customeditorpath bypassesComputer.DeviceList viaResolveComputerDevices. OptionalHarmony prefix SortCircuitHolderDisplayData filtersSmart duplicateinstance/nonzeroID andnames together. StandardComputerfilter/NormalizeRegistration from104 retained. DecompiledLua host supportgenericDevice/ICircuitHolder confirmed; customeditor supportsICircuitHolder. Editor/import/export delegatedtonativeLua patches. ActualVMprogram notexecutedlocally.23adapter+realDLLmetadata+productionNoLuaAssemblyReference checks,13pairedEditoridentitytests pass. Release0warnings/0errors. Previewrender/packaging andpublication completion see laterentry. Runtime Lua/powercycle/savejoin/ICeditor/modlist tests stillpending.

## Previous version

# Current build: 0.13.104

User screenshot: one physical Smart module, two equal labels in IC editor. Native decompiled Computer.DeviceList returns copy of DataCable.CableNetwork.DataDeviceList; native ProgrammableChipMotherboard.HandleDeviceListChange sorts/iterates it withoutdedupe. Root cause path in liveworld unconfirmed. SmartComputerDevices.Filter postfix on Computer.DeviceList filters only Smart modules: cursor/destroyed/ReferenceId0 omitted; repeated same instance or same positiveID collapsed; distinctID same-name modules kept. Other native devices untouched. SmartDeviceIdentity helper handles seeninstances/seenIDs. SmartModuleNetwork.Refresh begins NormalizeRegistration: under DeviceList lock keep one exactmodule instance, removeextras; dirty nativepower/data caches and RefreshNetworkDevice afterlock to notifycomputers. RegistrationCableHashSet untouched; no networkmerging or branch changes. 9 production filter tests+33 production network tests pass; network fixture models duplicate list and refresh notifications. Release0errors/0warnings. No unchanged103logic retesting. All actual in-game behavior pending. Source/README/smart104-verification updated. No104publication yet.

## Previous version

# Current build: 0.13.103

User explicitly confirms102 still GameAudioEvent.IsValid NRE on power OFF/ON after full restart. No live runtime available. Add PrefabAudioOwner.PrepareInstance(this) before base.Awake in SmartModule: deep clone event objects and condition/buildstate lists, preserve within-instance aliases via dictionary, rebind owner to live instance. Global, interaction and build-state-only paths included; native clip asset/channel/name/hash/StopIfInvalid preserved. Template Rebind remains. 24 owner regression cases include two instances, absent serialized owner and power cycle;10 lifecycle checks pass. Actual power-cycle fix pending in game.

User requests no red; green running, orange fault with detail. New SmartStatusLed lens3.6x1.8mm at(.009,.028,.0738), independent Standard emissive material; no other part repaint. SmartRunStatus priority power/on -> chip -> fault -> active program/instruction range/notpaused. sleep/yield stay green; empty/completed/paused idle unlit. Native GetErrorCode supplies compilation/runtime text+line in passive tooltip. Server refresh .1s, reads native _LinesOfCode count and LineNumber to distinguish completion. runStatus replicated via unused base512flag and join byte; bases checked Thing/Structure/Device/LogicUnitBase/LogicDisplay: base uses1..256, custom512available. Save is derived, no save schema addition. Client power gates stale status. 259 state cases pass; Release0errors/0warnings. Runtime diode and network validation pending. No103publication yet.

## Previous version

# Current build: 0.13.102

User reports native GameAudioEvent.IsValid -> Interactable.PlayInteractableSounds -> PlayScheduledSounds -> AudioManager.LateUpdate NRE on world load. Decompiled IsValid accesses Parent.IsState and Parent.AsStructure. ReplaceComponent rebinds interaction.Parent but left GameAudioEvent.Parent referencing removed source component. New PrefabAudioOwner.Rebind(Structure) called before original DestroyImmediate transfers global, interaction and build-state interaction event owners. No global audio patches or suppressed sounds; conditions/channels/materials/geometry/native state unchanged. Source clone isolation preserved. Native Thing.Awake still initializes AudioSources and private event lookup. 14 regression checks plus10 Smart lifecycle checks passed, Release build0errors/0warnings. In-game worldload/audio check pending.

## Previous version

# Current build: 0.13.101

Socket front now flush with casing fascia z.0736 instead of .0741. No rectangular .15mm perimeter gap. SmartSocketPocket fills four fascia corners and builds an octagonal floor/liner matching the original 2.607mm rim chamfers. Functional native slot follows the same original pose and shifted socket transform. LED/native logic untouched. Tests verify four corner continuity rays, flush rim, original UVs, open pocket and nondegenerate mesh triangles. In-game fit pending.

## Previous build 0.13.100

Visual-only Smart fascia revision, plus matching slot seating transform. AirChipSocketGeometry selects exactly166 complete original Air IC10 socket triangles in prefab bounds x[-.006,.126],y[.703,.846],z[.111,.158]. Full native UV/material groups kept; surrounding panels z>=.205 excluded. Socket fit46x49.5mm, centerX.009, front rimz.0741 over fasciaz.0736. SmartSocketPocket subtracts a pocket and adds closed floor/four lining walls before the native slot is added. Rear depth includes actual native IC10 source bounds. Native slot and original frame use identical uniform map/pose.

LED centerz.0743 (2.7mm closer to fascia), screen remains visible, frame maxz~.077386. LedBezelGeometry excludes10 separate original button pedestal triangles; native state/rendering/logic untouched. User screenshot confirms native text rendering and IC10 appearance in99. SmartPrefabState pre-Awake fix retained.

Verification/SmartGeometry uses actual external original Air/LED Diagnostics JSON and included own procedural CasingFixture, checks332 cases including UV and floor/wall ray clearance. Art/SmartGeometry.json is pocketed actual casing; native-face100.json remains outside source package and is used for the icon render. Source game models/decompiled reference excluded. In-game100 geometry/slot fit still pending.

## Previous lifecycle fix

Hotfix for the reported startup stack: SmartModuleModel.Install -> Interactable.State -> LogicDisplay.OnInteractableUpdated -> Thing.OnOff -> null InteractOnOff. SmartPrefabState seeds serialized _state before Awake without live callbacks and then CacheStates(true). Clone animators removed and ParentInteractableIndex reset so live states have their own native owner. Production SmartPrefabState regression reproduces pre-Awake failure, verifies silent authoring and preserved live callbacks. No native game/decompiled assets bundled.

## Feature state inherited from 0.13.98

DIN Smart Module is a native LogicDisplay + ICircuitHolder, four DIN positions/cost4, native LED glyph rendering and transplanted Air Conditioner IC10 socket. Single upper power/data IN only; no OUT or overload protection. SmartCircuit selects the Input or common feeder/output network, never joins separate data networks. Native device registration lets the selected branch computer IC motherboard discover DIN Smart Module. db addresses the display-owning module; ID/batch reads scoped to selected native network. No physical d0-d5 selectors yet.

Source models are read from native runtime SourcePrefabs. Original uploaded Diagnostics dumps/decompiled reference live outside this package. Native socket and occupant preserve original pose/materials and move together onto fascia. Body paint is separate from native LED color/materials. Standard breaker geometry unchanged.

SmartModuleSaveData extends native LogicBaseSaveData; native base owns settings and inventory. Mount/editor/error added, old prototype mount accepted. Old Smart OUT wires are refunded, IN preserved. Seven save data types registered. Authoritative placement validates4slots before kit consumption; detached/authoring targeting/cover window/label occupancy include Smart.

See README for wiring and test program. Production DLL build + fixture checks complete; actual Unity glyph draw, IC10 seating, motherboard dropdown, multiplayer and game save/load pending user testing.
