namespace ModularSwitchboards
{
    internal static class SmartOutputStatus
    {
        // The indicator reports a usable bus/data connection, independently of IC execution or power.
        internal static bool Connected(DinBreaker module)
        {
            if(module==null||!module.IsSmartOutputModule||module.IsBeingDestroyed||module.IsCursor)return false;
            var core=SmartBus.Core(module);
            return core!=null&&core.Cabinet?.Wiring.SmartCable(module.ReferenceId)?.CableNetwork!=null;
        }
    }
}
