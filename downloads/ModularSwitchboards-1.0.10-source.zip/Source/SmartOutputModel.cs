using System;
using System.Collections.Generic;
using System.Linq;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Objects;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class SmartOutputModel
    {
        internal const string PrefabName="StructureSmartOutputModule";
        internal static void Install(DinBreaker module,Sprite thumbnail)
        {
            var model=module.transform.Find("DinBreakerModel");
            foreach(var name in new[]{"BreakerLever","BreakerIndicator","BreakerControl"})
            {var part=model.Find(name);if(part!=null)UnityEngine.Object.DestroyImmediate(part.gameObject);}
            var view=module.GetComponent<BreakerSwitchView>();if(view!=null)UnityEngine.Object.DestroyImmediate(view);
            var mesh=DinBreakerModel.Build(plain:true,bottomOnly:true);model.GetComponent<MeshFilter>().sharedMesh=mesh;
            var hit=model.GetComponent<BoxCollider>();hit.center=mesh.bounds.center;hit.size=mesh.bounds.size;
            module.Interactables=new List<Interactable>();module.HasOnOffState=false;
            module.BuildStates[0].Interactables=module.Interactables;module.BuildStates[0].Colliders=new List<Collider>{hit};
            module.CacheStates(true);module.Bounds=new Bounds(Vector3.Scale(mesh.bounds.center,DinBreakerModel.VisualScale),Vector3.Scale(mesh.bounds.size,DinBreakerModel.VisualScale));module.GridBounds=new GridBounds(module);
            module.Thumbnail=thumbnail;module.BuildStates[0].Thumbnail=thumbnail;
            var plate=new GameObject("ModuleRatingPlate"){layer=module.gameObject.layer};plate.transform.SetParent(model,false);
            var vertices=new List<Vector3>();var normals=new List<Vector3>();var triangles=new List<int>();
            RoundedGeometry.Box(vertices,normals,triangles,new Vector3(0,-.006f,.0645f),new Vector3(.012f,.011f,.0005f),.0003f);
            var plateMesh=new Mesh{name="Smart.Output.NamePlate"};plateMesh.SetVertices(vertices);plateMesh.SetNormals(normals);plateMesh.subMeshCount=5;
            for(int role=0;role<5;role++)plateMesh.SetTriangles(role==1?triangles.ToArray():new int[0],role);
            CabinetGeometry.ApplyNativeUv(plateMesh);plate.AddComponent<MeshFilter>().sharedMesh=plateMesh;
            var plateRenderer=plate.AddComponent<MeshRenderer>();plateRenderer.sharedMaterials=CabinetGeometry.Materials;
            var plateBlock=new MaterialPropertyBlock();plateBlock.SetFloat(Thing.DiffuseIndexPropertyID,(int)Assets.Scripts.Objects.Motherboards.ColorType.White);plateBlock.SetColor(Thing.EMISSION_COLOR,Color.black);plateRenderer.SetPropertyBlock(plateBlock,1);
            var lens=GameObject.CreatePrimitive(PrimitiveType.Sphere);lens.name="SmartOutputLens";lens.layer=module.gameObject.layer;lens.transform.SetParent(model,false);
            lens.transform.localPosition=new Vector3(0,.010f,.065f);
            lens.transform.localScale=new Vector3(.004f/DinBreakerModel.VisualScale.x,.004f/DinBreakerModel.VisualScale.y,.002f/DinBreakerModel.VisualScale.z);
            UnityEngine.Object.DestroyImmediate(lens.GetComponent<Collider>());
            var lensRenderer=lens.GetComponent<MeshRenderer>();
            CabinetGeometry.ReadNativeMesh(lens.GetComponent<MeshFilter>().sharedMesh,out var lensVertices,out _,out var lensGroups);
            var lensMesh=new Mesh{name="Smart.Output.NativeLens"};lensMesh.vertices=lensVertices;lensMesh.subMeshCount=lensGroups.Length;
            for(int i=0;i<lensGroups.Length;i++)lensMesh.SetTriangles(lensGroups[i],i);
            lensMesh.RecalculateNormals();CabinetGeometry.ApplyNativeUv(lensMesh);lens.GetComponent<MeshFilter>().sharedMesh=lensMesh;
            var lensMaterial=new Material(CabinetGeometry.Materials[0]){name="Switchboards.SmartOutput.Indicator"};
            lensMaterial.EnableKeyword("_EMISSION");CabinetMatteSurface.Configure(lensMaterial);
            lensMaterial.SetFloat(Thing.DiffuseIndexPropertyID,(int)Assets.Scripts.Objects.Motherboards.ColorType.Orange);
            lensMaterial.SetColor(Thing.EMISSION_COLOR,new Color(1f,.38f,.015f));
            lensRenderer.sharedMaterial=lensMaterial;
            lensRenderer.shadowCastingMode=UnityEngine.Rendering.ShadowCastingMode.Off;lensRenderer.receiveShadows=false;
            module.gameObject.AddComponent<SmartOutputView>();
            Font font=null;foreach(var name in new[]{"LegacyRuntime.ttf","Arial.ttf"}){try{font=Resources.GetBuiltinResource<Font>(name);}catch(Exception){}if(font!=null)break;}
            if(font==null)font=Resources.FindObjectsOfTypeAll<Font>().FirstOrDefault();
            if(font!=null)
            {
                var go=new GameObject("SmartOutputText"){layer=module.gameObject.layer};go.transform.SetParent(model,false);go.transform.localPosition=new Vector3(0,-.006f,.0651f);go.transform.localRotation=Quaternion.Euler(0,180,0);
                var text=go.AddComponent<TextMesh>();text.font=font;text.fontSize=64;text.fontStyle=FontStyle.Bold;text.characterSize=.004f;text.anchor=TextAnchor.MiddleCenter;text.alignment=TextAlignment.Center;text.richText=false;text.color=Color.black;text.text="AQ";
                // Fit the actual font bounds inside the plate, without affecting the casing.
                var size=text.GetComponent<MeshRenderer>().localBounds.size;
                go.transform.localScale=Vector3.one*Mathf.Min(.009f/Mathf.Max(.0001f,size.x),.007f/Mathf.Max(.0001f,size.y));
                DepthLabelText.Apply(text);
            }
        }
    }
}
