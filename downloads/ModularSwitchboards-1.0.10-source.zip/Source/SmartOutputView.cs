using UnityEngine;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Motherboards;
namespace ModularSwitchboards
{
    public sealed class SmartOutputView:MonoBehaviour
    {
        private DinBreaker owner;
        private MeshRenderer lens,boundLens;
        private Material lensMaterial;
        private readonly MaterialPropertyBlock block=new MaterialPropertyBlock();
        private bool connected,reported,reportedState;
        private float nextCheck;
        private static readonly int ColorId=Shader.PropertyToID("_Color"),EmissionId=Shader.PropertyToID("_EmissionColor");
        private void Bind()
        {
            owner=GetComponent<DinBreaker>();lens=transform.Find("DinBreakerModel/SmartOutputLens")?.GetComponent<MeshRenderer>();
            if(lens!=null&&(lensMaterial==null||boundLens!=lens))
            {
                if(lensMaterial!=null)Destroy(lensMaterial);
                lensMaterial=new Material(lens.sharedMaterial){name="Switchboards.SmartOutput.Indicator.Live"};
                lensMaterial.EnableKeyword("_EMISSION");
                lensMaterial.SetFloat("_Glossiness",0f);lensMaterial.SetFloat("_SpecularHighlights",0f);lensMaterial.SetFloat("_GlossyReflections",0f);
                lensMaterial.EnableKeyword("_SPECULARHIGHLIGHTS_OFF");lensMaterial.EnableKeyword("_GLOSSYREFLECTIONS_OFF");
                lens.sharedMaterial=lensMaterial;boundLens=lens;
            }
        }
        private void OnEnable()
        {
            // Bind the placed instance, including after prefab cloning or re-enabling.
            Bind();connected=false;nextCheck=0f;Paint();
        }
        private void LateUpdate()
        {
            if(owner==null||lens==null||lensMaterial==null)Bind();
            if(owner==null||lens==null||lensMaterial==null)return;
            if(Time.unscaledTime>=nextCheck)
            {nextCheck=Time.unscaledTime+.15f;connected=SmartOutputStatus.Connected(owner);}
            // Native material-slot blocks override renderer-wide blocks. Reapply
            // both every frame even when the connection itself has not changed.
            Paint();
        }
        private void Paint()
        {
            if(lens==null||lensMaterial==null)return;
            if(lens.sharedMaterial!=lensMaterial)lens.sharedMaterial=lensMaterial;
            int palette=(int)(connected?ColorType.Green:ColorType.Orange);
            var color=connected?new Color(.08f,1f,.12f):new Color(1f,.38f,.015f);
            lensMaterial.SetFloat(Thing.DiffuseIndexPropertyID,palette);lensMaterial.SetFloat(Thing.SmoothnessIndexPropertyID,0f);
            lensMaterial.SetColor(ColorId,color);lensMaterial.SetColor(EmissionId,color*2f);
            block.Clear();block.SetFloat(Thing.DiffuseIndexPropertyID,palette);block.SetFloat(Thing.SmoothnessIndexPropertyID,0f);block.SetColor(ColorId,color);block.SetColor(EmissionId,color*2f);
            lens.SetPropertyBlock(block);lens.SetPropertyBlock(block,0);
            if(owner!=null&&owner.ReferenceId!=0&&!owner.IsCursor&&(!reported||reportedState!=connected))
            {
                Debug.Log("[Modular Switchboards] Smart Output LED "+owner.ReferenceId+": "+(connected?"green":"orange")+"; native palette="+palette+"; shader="+lensMaterial.shader.name+"; mod="+SwitchboardsMod.Version);
                reported=true;reportedState=connected;
            }
        }
        private void OnDestroy(){if(lensMaterial!=null)Destroy(lensMaterial);}
    }
}
