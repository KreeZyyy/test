using System;using System.Collections.Generic;using System.Reflection;using ModularSwitchboards;using UnityEngine;
class Program
{
 static int checks;static readonly int ColorId=Shader.PropertyToID("_Color"),EmissionId=Shader.PropertyToID("_EmissionColor");
 static void Check(bool value,string message){checks++;if(!value)throw new Exception(message);}
 static void Call(SmartOutputView view,string method)=>typeof(SmartOutputView).GetMethod(method,BindingFlags.NonPublic|BindingFlags.Instance).Invoke(view,null);
 static void White(MeshRenderer lens){var b=new MaterialPropertyBlock();b.SetColor(ColorId,new(1,1,1));b.SetColor(EmissionId,new(1,1,1));lens.SetPropertyBlock(b,0);}
 static void Tick(SmartOutputView v){Time.unscaledTime+=.2f;Call(v,"LateUpdate");}
 static void Main()
 {
  var owner=new DinBreaker();var lens=new MeshRenderer();White(lens);
  var view=new SmartOutputView{TestOwner=owner};view.transform.Lens=lens;Call(view,"OnEnable");
  var c=lens.Effective(ColorId);Check(c.r>c.g&&c.g>c.b,"material-slot white override hides orange indicator");
  Check(lens.sharedMaterial.Floats[Assets.Scripts.Objects.Thing.DiffuseIndexPropertyID]==(int)Assets.Scripts.Objects.Motherboards.ColorType.Orange,"native material has no orange palette index");
  owner.Connected=true;Tick(view);c=lens.Effective(ColorId);Check(c.g>c.r&&c.g>c.b,"connected indicator is not green");
  Check(lens.Effective(EmissionId).g>0,"indicator has no green emission");
  Check(lens.sharedMaterial.Floats[Assets.Scripts.Objects.Thing.DiffuseIndexPropertyID]==(int)Assets.Scripts.Objects.Motherboards.ColorType.Green,"native material has no green palette index");
  var ownedMaterial=lens.sharedMaterial;lens.sharedMaterial=new Material(ownedMaterial);Call(view,"LateUpdate");Check(ReferenceEquals(lens.sharedMaterial,ownedMaterial),"finish replacement detached the live LED material");
  White(lens);Tick(view);c=lens.Effective(ColorId);Check(c.g>c.r,"unchanged state fails to repair a later native white override");
  White(lens);Call(view,"LateUpdate");Check(lens.Effective(ColorId).g>lens.Effective(ColorId).r,"native override repair waits for the next topology poll");
  owner.Connected=false;Tick(view);c=lens.Effective(ColorId);Check(c.r>c.g&&c.g>c.b,"disconnect does not restore orange");
  var second=new SmartOutputView{TestOwner=new DinBreaker{Connected=true}};var secondLens=new MeshRenderer();second.transform.Lens=secondLens;Call(second,"OnEnable");Tick(second);
  Check(secondLens.Effective(ColorId).g>secondLens.Effective(ColorId).r&&lens.Effective(ColorId).r>lens.Effective(ColorId).g,"instances share indicator colour");
  var delayed=new SmartOutputView{TestOwner=owner};Call(delayed,"OnEnable");var delayedLens=new MeshRenderer();delayed.transform.Lens=delayedLens;Tick(delayed);
  Check(delayedLens.Effective(ColorId).r>delayedLens.Effective(ColorId).g,"late renderer binding leaves a white indicator");
  var cloneOwner=new DinBreaker{Connected=true};view.TestOwner=cloneOwner;view.transform.Lens=secondLens;Call(view,"OnEnable");Tick(view);
  Check(secondLens.Effective(ColorId).g>secondLens.Effective(ColorId).r,"re-enable does not bind the actual cloned owner/lens");
  Console.WriteLine(checks+" Output LED rendering checks passed: per-material precedence, state changes, native overrides, instance isolation and rebinding.");
 }
}
namespace ModularSwitchboards{public class DinBreaker{public bool Connected,IsCursor;public long ReferenceId=1;}public static class SwitchboardsMod{public const string Version="1.0.10";}internal static class SmartOutputStatus{internal static bool Connected(DinBreaker m)=>m.Connected;}}
namespace UnityEngine
{
 public class MonoBehaviour{public static void Destroy(object o){}public object TestOwner;public Transform transform=new();public T GetComponent<T>()where T:class=>TestOwner as T;}
 public class Transform{public MeshRenderer Lens;public Transform Find(string path)=>Lens==null?null:this;public T GetComponent<T>()where T:class=>Lens as T;}
 public static class Time{public static float unscaledTime;}
 public struct Color{public float r,g,b;public Color(float r,float g,float b){this.r=r;this.g=g;this.b=b;}public static Color operator *(Color c,float k)=>new(c.r*k,c.g*k,c.b*k);}
 public class Shader{public string name="native-palette";static Dictionary<string,int> ids=new();public static int PropertyToID(string s){if(!ids.TryGetValue(s,out var n))ids[s]=n=ids.Count+1;return n;}}
 public class MaterialPropertyBlock{public Dictionary<int,Color> Values=new();public Dictionary<int,float> Floats=new();public void SetFloat(int id,float value)=>Floats[id]=value;public void Clear(){Values.Clear();Floats.Clear();}public void SetColor(int id,Color c)=>Values[id]=c;}
 // Unity gives a per-material block priority over the renderer-wide block.
 public class Material{public Shader shader=new();public string name;public Dictionary<int,Color> Values=new();public Material(){}public Material(Material other){Values=new(other.Values);}public void EnableKeyword(string s){}public void SetFloat(string key,float value){}public void SetFloat(int id,float value){Floats[id]=value;}public Dictionary<int,float> Floats=new();public void SetColor(int id,Color c)=>Values[id]=c;}
 public class MeshRenderer{public Material sharedMaterial=new();Dictionary<int,Color> global=new(),slot=new();public void SetPropertyBlock(MaterialPropertyBlock b)=>global=new(b.Values);public void SetPropertyBlock(MaterialPropertyBlock b,int i)=>slot=new(b.Values);public Color Effective(int id)=>slot.TryGetValue(id,out var c)?c:global.GetValueOrDefault(id);}
}

namespace Assets.Scripts.Objects{public static class Thing{public static int DiffuseIndexPropertyID=UnityEngine.Shader.PropertyToID("_DiffuseIndex"),SmoothnessIndexPropertyID=UnityEngine.Shader.PropertyToID("_SmoothnessIndex");}}
namespace Assets.Scripts.Objects.Motherboards{public enum ColorType{Green=3,Orange=4}}
namespace UnityEngine{public static class Debug{public static void Log(string text){}}}
