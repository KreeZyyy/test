using System;
using System.Collections.Generic;
using UnityEngine;

namespace ModularSwitchboards
{
    // Clip triangles, rather than dropping whole faces at a connector/body boundary.
    // Original UVs are interpolated at cuts; no atlas coordinates are invented.
    internal static class NativeMeshCrop
    {
        private struct Vertex {internal Vector3 P;internal Vector2 U;internal Vertex(Vector3 p,Vector2 u){P=p;U=u;}}
        internal static Mesh Read(Mesh source,Matrix4x4 frame,Bounds region,string name)
        {
            CabinetGeometry.ReadNativeMesh(source,out var points,out var uv,out var triangles);
            var vertices=new List<Vector3>();var texcoords=new List<Vector2>();var subs=new List<int>[triangles.Length];
            for(int s=0;s<triangles.Length;s++)
            {
                subs[s]=new List<int>();
                for(int t=0;t<triangles[s].Length;t+=3)
                {
                    var polygon=new List<Vertex>();
                    for(int j=0;j<3;j++){int id=triangles[s][t+j];polygon.Add(new Vertex(frame.MultiplyPoint3x4(points[id]),uv[id]));}
                    for(int axis=0;axis<3 && polygon.Count>0;axis++)
                    {
                        polygon=Clip(polygon,axis,region.min[axis],true);
                        polygon=Clip(polygon,axis,region.max[axis],false);
                    }
                    for(int j=1;j+1<polygon.Count;j++)
                    {
                        var a=polygon[0];var b=polygon[j];var c=polygon[j+1];
                        if(Vector3.Cross(b.P-a.P,c.P-a.P).sqrMagnitude<1e-16f)continue;
                        int offset=vertices.Count;
                        foreach(var v in new[]{a,b,c}){vertices.Add(v.P);texcoords.Add(v.U);}
                        subs[s].Add(offset);subs[s].Add(offset+(frame.determinant<0?2:1));subs[s].Add(offset+(frame.determinant<0?1:2));
                    }
                }
            }
            if(vertices.Count==0)return null;
            var mesh=new Mesh{name=name};if(vertices.Count>65535)mesh.indexFormat=UnityEngine.Rendering.IndexFormat.UInt32;
            mesh.SetVertices(vertices);mesh.SetUVs(0,texcoords);mesh.subMeshCount=subs.Length;
            for(int s=0;s<subs.Length;s++)mesh.SetTriangles(subs[s],s);
            mesh.RecalculateNormals();mesh.RecalculateTangents();mesh.RecalculateBounds();return mesh;
        }
        internal static Mesh Exclude(Mesh source,IList<Bounds> holes)
        {
            var output=new List<Vector3>();var texcoords=new List<Vector2>();var subs=new List<int>[source.subMeshCount];
            var points=source.vertices;var uv=source.uv;
            for(int sub=0;sub<subs.Length;sub++)
            {
                subs[sub]=new List<int>();var ids=source.GetTriangles(sub);
                for(int i=0;i<ids.Length;i+=3)
                {
                    var polygons=new List<List<Vertex>>{new List<Vertex>{new Vertex(points[ids[i]],uv[ids[i]]),new Vertex(points[ids[i+1]],uv[ids[i+1]]),new Vertex(points[ids[i+2]],uv[ids[i+2]])}};
                    foreach(var hole in holes)
                    {
                        var outside=new List<List<Vertex>>();
                        foreach(var polygon in polygons)
                        {
                            var inside=polygon;
                            for(int axis=0;axis<3 && inside.Count>0;axis++)
                            {
                                var piece=Clip(inside,axis,hole.min[axis],false);if(piece.Count>=3)outside.Add(piece);
                                inside=Clip(inside,axis,hole.min[axis],true);
                                piece=Clip(inside,axis,hole.max[axis],true);if(piece.Count>=3)outside.Add(piece);
                                inside=Clip(inside,axis,hole.max[axis],false);
                            }
                        }
                        polygons=outside;
                    }
                    foreach(var polygon in polygons)for(int j=1;j+1<polygon.Count;j++)
                    {
                        var a=polygon[0];var b=polygon[j];var c=polygon[j+1];if(Vector3.Cross(b.P-a.P,c.P-a.P).sqrMagnitude<1e-16f)continue;
                        int n=output.Count;foreach(var v in new[]{a,b,c}){output.Add(v.P);texcoords.Add(v.U);}
                        subs[sub].Add(n);subs[sub].Add(n+1);subs[sub].Add(n+2);
                    }
                }
            }
            var mesh=new Mesh{name=source.name+".LugClearance"};if(output.Count>65535)mesh.indexFormat=UnityEngine.Rendering.IndexFormat.UInt32;
            mesh.SetVertices(output);mesh.SetUVs(0,texcoords);mesh.subMeshCount=subs.Length;for(int sub=0;sub<subs.Length;sub++)mesh.SetTriangles(subs[sub],sub);
            mesh.RecalculateNormals();mesh.RecalculateTangents();mesh.RecalculateBounds();return mesh;
        }
        private static List<Vertex> Clip(List<Vertex> input,int axis,float plane,bool above)
        {
            var result=new List<Vertex>();if(input.Count==0)return result;
            var previous=input[input.Count-1];float pd=previous.P[axis]-plane;bool pin=above?pd>=0:pd<=0;
            foreach(var current in input)
            {
                float cd=current.P[axis]-plane;bool cin=above?cd>=0:cd<=0;
                if(pin!=cin)
                {
                    float t=pd/(pd-cd);
                    result.Add(new Vertex(previous.P+(current.P-previous.P)*t,previous.U+(current.U-previous.U)*t));
                }
                if(cin)result.Add(current);
                previous=current;pd=cd;pin=cin;
            }
            return result;
        }
    }
}
