using System;
using System.Collections.Generic;
using System.Linq;
using Assets.Scripts;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Electrical;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Util;
using UnityEngine;
using UnityEngine.Rendering;

namespace ModularSwitchboards
{
    internal static class ExternalPortLayout
    {
        internal static readonly Vector3[] Positions={new Vector3(0,.5f,-CabinetModel.MountOffset),new Vector3(-.5f,-.5f,-CabinetModel.MountOffset),new Vector3(.5f,-.5f,-CabinetModel.MountOffset)};
        internal static readonly Vector3[] Directions={Vector3.up,Vector3.left,Vector3.right};
        internal static readonly ConnectionRole[] Roles={ConnectionRole.Input,ConnectionRole.Output,ConnectionRole.Output2};
    }

    public sealed class NativePortSurface : MonoBehaviour
    {
        public int TemplateIndex;
        private sealed class Surface {internal Material[] Materials;internal MaterialPropertyBlock[] Blocks;}
        private static readonly List<Surface> Templates=new List<Surface>();
        internal static void Capture(Renderer source,MeshRenderer destination)
        {
            var materials=source.sharedMaterials;var blocks=new MaterialPropertyBlock[materials.Length];
            var global=new MaterialPropertyBlock();source.GetPropertyBlock(global);
            for(int i=0;i<blocks.Length;i++){var block=new MaterialPropertyBlock();source.GetPropertyBlock(block,i);blocks[i]=block.isEmpty?global:block;}
            var marker=destination.gameObject.AddComponent<NativePortSurface>();marker.TemplateIndex=Templates.Count;
            Templates.Add(new Surface{Materials=materials,Blocks=blocks});marker.Restore();
        }
        internal void Restore()
        {
            if(TemplateIndex<0||TemplateIndex>=Templates.Count)return;
            var renderer=GetComponent<MeshRenderer>();var surface=Templates[TemplateIndex];renderer.sharedMaterials=surface.Materials;
            for(int i=0;i<surface.Blocks.Length;i++)renderer.SetPropertyBlock(surface.Blocks[i],i);
        }
    }

    internal static class ExternalCablePorts
    {
        private sealed class Part {internal Mesh Mesh;internal MeshRenderer Source;}
        private sealed class Template {internal Connection Source;internal bool ForwardInward;internal Matrix4x4 SourceFrame;internal Vector3 GridRemainder;internal Bounds Region;internal List<Part> Parts=new List<Part>();}
        private static readonly Dictionary<Connection,Template> NativeTemplates=new Dictionary<Connection,Template>();
        private static Template Read(AreaPowerControl apc,Connection connection)
        {
            if(connection?.Transform==null)throw new InvalidOperationException("APC cable connection transform unavailable");
            if(NativeTemplates.TryGetValue(connection,out var cached))return cached;
            var center=apc.transform.TransformPoint(apc.Bounds.center);
            var result=new Template{Source=connection,ForwardInward=Vector3.Dot(connection.Transform.forward,center-connection.Transform.position)>0f};
            var frame=Matrix4x4.TRS(connection.Transform.position,connection.Transform.rotation,Vector3.one).inverse;
            var view=frame.MultiplyVector(apc.transform.forward*CabinetModel.FrontSign);view.z=0f;
            if(view.sqrMagnitude>.001f)frame=Matrix4x4.Rotate(Quaternion.Inverse(Quaternion.LookRotation(Vector3.forward,view.normalized)))*frame;
            result.SourceFrame=frame;
            var sourcePosition=apc.transform.InverseTransformPoint(connection.Transform.position);
            var sourceGrid=sourcePosition.ToGrid(SmallGrid.SmallGridSize,SmallGrid.SmallGridOffset).ToVector3();
            result.GridRemainder=frame.MultiplyVector(apc.transform.TransformVector(sourcePosition-sourceGrid));
            // Native half-cell boundary ties change when an axis is rotated. A 10-micron
            // inset keeps the selected cell stable without a visible change to the lug.
            for(int axis=0;axis<3;axis++)result.GridRemainder[axis]=Mathf.Clamp(result.GridRemainder[axis],-.24999f,.24999f);
            // Include the whole native lug from the electrical hitbox back to the body edge.
            Bounds? region=null;
            if(connection.Collider is BoxCollider sourceBox)
            {
                var nativeBounds=CabinetWallMount.TransformedBounds(new Bounds(sourceBox.center,sourceBox.size),frame*sourceBox.transform.localToWorldMatrix);
                nativeBounds.Expand(.025f);region=nativeBounds;
            }
            var crop=region??new Bounds(Vector3.zero,new Vector3(.15f,.15f,.3f));
            var door=apc.GetComponentsInChildren<MeshRenderer>(true).FirstOrDefault(r=>r.name=="Door");
            if(door!=null && door.GetComponent<MeshFilter>()?.sharedMesh!=null)
            {
                var doorBounds=CabinetWallMount.TransformedBounds(door.GetComponent<MeshFilter>().sharedMesh.bounds,frame*door.transform.localToWorldMatrix);
                var lo=crop.min;var hi=crop.max;
                if(result.ForwardInward)hi.z=Math.Max(hi.z,doorBounds.min.z+.003f);
                else lo.z=Math.Min(lo.z,doorBounds.max.z-.003f);
                crop.SetMinMax(lo,hi);
            }
            if(crop.size.z>.65f || crop.size.x>.3f || crop.size.y>.4f)throw new InvalidOperationException("Native APC connector crop unexpectedly includes body: "+crop);
            result.Region=crop;
            var renderers=apc.GetComponentsInChildren<MeshRenderer>(true)
                .Where(r=>r!=connection.HelperRenderer && r.name!="Door" && r.name!="MasterLever" && r.name.IndexOf("Destroyed",StringComparison.OrdinalIgnoreCase)<0).ToArray();
            foreach(var renderer in renderers)
            {
                var original=renderer.GetComponent<MeshFilter>()?.sharedMesh;if(original==null)continue;
                var mesh=NativeMeshCrop.Read(original,frame*renderer.transform.localToWorldMatrix,crop,"Switchboards.NativeAPCPort."+renderer.name);
                if(mesh!=null)result.Parts.Add(new Part{Mesh=mesh,Source=renderer});
            }
            if(result.Parts.Count==0 && connection.HelperRenderer is MeshRenderer helper)
            {
                var original=helper.GetComponent<MeshFilter>()?.sharedMesh;
                if(original!=null)
                {
                    CabinetGeometry.ReadNativeMesh(original,out var points,out var uv,out var triangles);
                    var matrix=frame*helper.transform.localToWorldMatrix;
                    for(int i=0;i<points.Length;i++)points[i]=matrix.MultiplyPoint3x4(points[i]);
                    var mesh=new Mesh{name="Switchboards.NativeCableConnectorHelper"};mesh.vertices=points;mesh.uv=uv;mesh.subMeshCount=triangles.Length;
                    for(int i=0;i<triangles.Length;i++)mesh.SetTriangles(triangles[i],i);
                    mesh.RecalculateNormals();mesh.RecalculateTangents();mesh.RecalculateBounds();
                    result.Parts.Add(new Part{Mesh=mesh,Source=helper});
                    Debug.LogWarning("[Modular Switchboards] APC port uses native helper geometry; inspect external connector appearance.");
                }
            }
            if(result.Parts.Count==0)throw new InvalidOperationException("No native APC cable connector geometry found");
            Debug.Log("[Modular Switchboards] Native APC connector captured: "+connection.ConnectionRole+"; parts="+result.Parts.Count+"; crop="+crop+"; native local position="+sourcePosition+"; native local grid="+sourceGrid+"; native axis="+connection.Transform.forward+"; forward inward="+result.ForwardInward);
            NativeTemplates[connection]=result;return result;
        }

        internal static bool TryInstall(SwitchboardCabinet cabinet)
        {
            var oldPorts=cabinet.OpenEnds;var oldBody=cabinet.PortBodyGrids;float oldPower=cabinet.UsedPower;var oldMask=cabinet.SmallCollisionType;
            var oldColliders=new List<Collider>(cabinet.BuildStates[1].Colliders);
            try {Install(cabinet);return true;}
            catch(Exception ex)
            {
                var root=cabinet.transform.Find("SwitchboardModel/CompletedShell/ExternalCablePorts");
                if(root!=null)UnityEngine.Object.DestroyImmediate(root.gameObject);
                cabinet.OpenEnds=oldPorts;cabinet.PortBodyGrids=oldBody;cabinet.UsedPower=oldPower;cabinet.SmallCollisionType=oldMask;
                cabinet.BuildStates[1].Colliders=oldColliders;CabinetModel.SetBounds(cabinet);
                Debug.LogError("[Modular Switchboards] External APC ports unavailable; cabinet preserved: "+ex);
                return false;
            }
        }
        private static void Install(SwitchboardCabinet cabinet)
        {
            var apc=WorldManager.Instance.SourcePrefabs.OfType<AreaPowerControl>().FirstOrDefault(p=>p.PrefabName=="StructureAreaPowerControl")
                ?? WorldManager.Instance.SourcePrefabs.OfType<AreaPowerControl>().FirstOrDefault();
            if(apc==null)throw new InvalidOperationException("Native APC unavailable for external cable ports");
            var input=Read(apc,apc.InputConnection);var output=Read(apc,apc.OutputConnection);
            // Match APC cable coexistence instead of inheriting the locker's blocking flags.
            cabinet.SmallCollisionType=apc.SmallCollisionType;
            if(cabinet.PortBodyGrids==null)cabinet.PortBodyGrids=new[]{Vector3.zero.ToGrid(SmallGrid.SmallGridSize,SmallGrid.SmallGridOffset)};
            Debug.Log("[Modular Switchboards] Native APC collision mask reused: "+apc.SmallCollisionType);
            var shell=cabinet.transform.Find("SwitchboardModel/CompletedShell");
            var root=new GameObject("ExternalCablePorts"){layer=cabinet.gameObject.layer};root.transform.SetParent(shell,false);
            cabinet.OpenEnds=new List<Connection>();cabinet.UsedPower=0f;
            for(int i=0;i<3;i++)
            {
                var template=i==0?input:output;
                var go=new GameObject("NativeCablePort_"+ExternalPortLayout.Roles[i]){layer=cabinet.gameObject.layer};go.transform.SetParent(root.transform,false);
                go.transform.localRotation=Quaternion.LookRotation(ExternalPortLayout.Directions[i]*(template.ForwardInward?-1f:1f),Vector3.forward);
                // Keep the native transform's exact offset within its cell, including native depth.
                go.transform.localPosition=ExternalPortLayout.Positions[i]+go.transform.localRotation*template.GridRemainder;
                Debug.Log("[Modular Switchboards] APC-style port "+ExternalPortLayout.Roles[i]+"; native subcell offset="+template.GridRemainder+"; local position="+go.transform.localPosition);
                Renderer helper=null;
                foreach(var part in template.Parts)
                {
                    var visual=new GameObject("NativeCablePortSurface"){layer=cabinet.gameObject.layer};visual.transform.SetParent(go.transform,false);
                    visual.AddComponent<MeshFilter>().sharedMesh=part.Mesh;
                    var renderer=visual.AddComponent<MeshRenderer>();NativePortSurface.Capture(part.Source,renderer);
                    renderer.lightProbeUsage=LightProbeUsage.BlendProbes;renderer.reflectionProbeUsage=ReflectionProbeUsage.BlendProbes;
                    renderer.shadowCastingMode=ShadowCastingMode.On;renderer.receiveShadows=true;
                    if(part.Source==template.Source.HelperRenderer)helper=renderer;
                }
                var hit=go.AddComponent<BoxCollider>();
                if(template.Source.Collider is BoxCollider box)
                {
                    var matrix=template.SourceFrame*box.transform.localToWorldMatrix;
                    var bounds=CabinetWallMount.TransformedBounds(new Bounds(box.center,box.size),matrix);hit.center=bounds.center;hit.size=bounds.size;
                }
                else {hit.center=new Vector3(0,0,-.02f);hit.size=new Vector3(.07f,.07f,.08f);}
                cabinet.OpenEnds.Add(new Connection(cabinet){Transform=go.transform,Collider=hit,HelperRenderer=helper,ConnectionType=cabinet.IsStructureCompleted?NetworkType.Power:NetworkType.None,ConnectionRole=ExternalPortLayout.Roles[i]});
                cabinet.BuildStates[1].Colliders.Add(hit);
            }
            AlignToGrid(cabinet);CabinetModel.SetBounds(cabinet);
            Debug.Log("[Modular Switchboards] External ports installed: top Input; lower Output/Output2; independent cells, no internal power bridge.");
        }
        private static Part ReadRearBody(AreaPowerControl apc)
        {
            var source=apc.GetComponentsInChildren<MeshRenderer>(true).FirstOrDefault(r=>r.name==apc.name || r.name==apc.PrefabName)
                ??apc.GetComponentsInChildren<MeshRenderer>(true).FirstOrDefault(r=>r.name!="Door" && r.name!="MasterLever" && r.name.IndexOf("Destroyed",StringComparison.OrdinalIgnoreCase)<0);
            var original=source?.GetComponent<MeshFilter>()?.sharedMesh;if(original==null)return null;
            var canonical=Matrix4x4.Rotate(CabinetModel.FrontSign<0?Quaternion.Euler(0,180,0):Quaternion.identity)*apc.transform.worldToLocalMatrix;
            var native=CabinetWallMount.TransformedBounds(original.bounds,canonical*source.transform.localToWorldMatrix);
            var door=apc.GetComponentsInChildren<MeshRenderer>(true).FirstOrDefault(r=>r.name=="Door");
            if(door==null || door.GetComponent<MeshFilter>()?.sharedMesh==null)return null;
            var body=CabinetWallMount.TransformedBounds(door.GetComponent<MeshFilter>().sharedMesh.bounds,canonical*door.transform.localToWorldMatrix);
            var lo=new Vector3(body.min.x,body.min.y,native.min.z);var hi=new Vector3(body.max.x,body.max.y,Math.Min(native.max.z,CabinetModel.MountOffset));
            if(hi.z<=lo.z || hi.x-lo.x<.05f || hi.y-lo.y<.05f)return null;
            var region=new Bounds();region.SetMinMax(lo,hi);
            var mesh=NativeMeshCrop.Read(original,canonical*source.transform.localToWorldMatrix,region,"Switchboards.NativeAPCRearBody");
            if(mesh==null)return null;
            var points=mesh.vertices;
            for(int v=0;v<points.Length;v++)points[v]=new Vector3((points[v].x-body.center.x)*(.396f/body.size.x),(points[v].y-body.center.y)*(.496f/body.size.y),points[v].z-CabinetModel.MountOffset);
            mesh.vertices=points;mesh.RecalculateNormals();mesh.RecalculateTangents();mesh.RecalculateBounds();
            Debug.Log("[Modular Switchboards] Native APC rear body retained: "+mesh.bounds+"; original depth, rear warning, UVs and materials; only width/height adapted.");
            return new Part{Mesh=mesh,Source=source};
        }
        private static bool RearSample(Part rear,out int sub,out Vector2 uv)
        {
            sub=0;uv=Vector2.zero;float largest=0f;if(rear==null)return false;
            var points=rear.Mesh.vertices;var tex=rear.Mesh.uv;
            for(int s=0;s<rear.Mesh.subMeshCount;s++)
            {
                var ids=rear.Mesh.GetTriangles(s);
                for(int j=0;j<ids.Length;j+=3)
                {
                    var n=Vector3.Cross(points[ids[j+1]]-points[ids[j]],points[ids[j+2]]-points[ids[j]]);
                    if(n.z>=0 || n.sqrMagnitude<=largest)continue;
                    largest=n.sqrMagnitude;sub=s;uv=(tex[ids[j]]+tex[ids[j+1]]+tex[ids[j+2]])/3f;
                }
            }
            return largest>0;
        }
        internal static void InstallRearBody(SwitchboardCabinet cabinet)
        {
            // Fixed dark rear casing extends into the wall; the front and mounting plate stay put.
            var vertices=new List<Vector3>();var normals=new List<Vector3>();var indices=new List<int>();
            var apc=WorldManager.Instance.SourcePrefabs.OfType<AreaPowerControl>().FirstOrDefault(p=>p.PrefabName=="StructureAreaPowerControl")??WorldManager.Instance.SourcePrefabs.OfType<AreaPowerControl>().FirstOrDefault();
            float carrierZ=-CabinetModel.MountOffset+.025f,carrierDepth=.05f;
            try
            {
                var lug=Read(apc,apc.InputConnection);
                var canonical=Matrix4x4.Rotate(CabinetModel.FrontSign<0?Quaternion.Euler(0,180,0):Quaternion.identity)*apc.transform.worldToLocalMatrix*lug.SourceFrame.inverse;
                float lo=float.PositiveInfinity,hi=float.NegativeInfinity;
                foreach(var part in lug.Parts){var bounds=CabinetWallMount.TransformedBounds(part.Mesh.bounds,canonical);lo=Math.Min(lo,bounds.min.z);hi=Math.Max(hi,bounds.max.z);}
                if(!float.IsInfinity(lo)){carrierZ=(lo+hi)*.5f-CabinetModel.MountOffset;carrierDepth=Math.Max(.02f,hi-lo);}
            }
            catch(Exception ex){Debug.LogWarning("[Modular Switchboards] Native lug depth unavailable: "+ex.Message);}
            Part rear=null;
            try{if(apc!=null)rear=ReadRearBody(apc);}catch(Exception ex){Debug.LogWarning("[Modular Switchboards] Native rear body unavailable: "+ex);}
            float depth=rear==null?CabinetModel.MountOffset:Math.Max(.02f,-rear.Mesh.bounds.min.z);
            RoundedGeometry.Box(vertices,normals,indices,new Vector3(0,0,-depth*.5f),new Vector3(.390f,.490f,Math.Max(.01f,depth-.006f)),.005f);
            var lugClearance=new List<Bounds>();
            try
            {
                for(int i=0;i<3;i++)
                {
                    var template=Read(apc,i==0?apc.InputConnection:apc.OutputConnection);
                    var q=Quaternion.LookRotation(ExternalPortLayout.Directions[i]*(template.ForwardInward?-1f:1f),Vector3.forward);
                    var pose=Matrix4x4.TRS(ExternalPortLayout.Positions[i]+q*template.GridRemainder,q,Vector3.one);
                    var bounds=CabinetWallMount.TransformedBounds(template.Parts[0].Mesh.bounds,pose);
                    foreach(var part in template.Parts)bounds.Encapsulate(CabinetWallMount.TransformedBounds(part.Mesh.bounds,pose));
                    bounds.Expand(.003f);var lo=bounds.min;lo.z=Math.Min(lo.z,-depth-.01f);bounds.SetMinMax(lo,bounds.max);lugClearance.Add(bounds);
                }
                if(rear!=null)rear.Mesh=NativeMeshCrop.Exclude(rear.Mesh,lugClearance);
            }
            catch(Exception ex){Debug.LogWarning("[Modular Switchboards] Native lug clearance unavailable: "+ex.Message);lugClearance.Clear();}
            // Bottom T: a stem below the cabinet and a horizontal carrier behind the two original lugs.
            RoundedGeometry.Box(vertices,normals,indices,new Vector3(0,-.36f,carrierZ),new Vector3(.065f,.24f,carrierDepth),.005f);
            RoundedGeometry.Box(vertices,normals,indices,new Vector3(0,-.5f,carrierZ),new Vector3(.5f,.065f,carrierDepth),.005f);
            RoundedGeometry.Box(vertices,normals,indices,new Vector3(0,.29f,carrierZ),new Vector3(.065f,.09f,carrierDepth),.005f);
            var supportMesh=new Mesh{name="Switchboards.RearCableCasing"};supportMesh.SetVertices(vertices);supportMesh.SetNormals(normals);supportMesh.subMeshCount=5;
            for(int i=0;i<5;i++)supportMesh.SetTriangles(i==4?indices.ToArray():new int[0],i);
            CabinetGeometry.ApplyNativeUv(supportMesh);
            var darkUv=supportMesh.uv;for(int i=0;i<darkUv.Length;i++)darkUv[i].x=Math.Min(.995f,darkUv[i].x+.5f);supportMesh.uv=darkUv;
            supportMesh.RecalculateBounds();
            var support=new GameObject("RearCableCasing"){layer=cabinet.gameObject.layer};support.transform.SetParent(cabinet.transform.Find("SwitchboardModel/CompletedShell"),false);
            support.AddComponent<MeshFilter>().sharedMesh=supportMesh;
            var supportRenderer=support.AddComponent<MeshRenderer>();supportRenderer.sharedMaterials=CabinetGeometry.Materials;
            if(RearSample(rear,out var nativeSub,out var nativeUv))
            {
                supportMesh.subMeshCount=rear.Source.sharedMaterials.Length;
                for(int sub=0;sub<supportMesh.subMeshCount;sub++)supportMesh.SetTriangles(sub==nativeSub?indices.ToArray():new int[0],sub);
                var tex=new Vector2[vertices.Count];for(int v=0;v<tex.Length;v++)tex[v]=nativeUv;supportMesh.uv=tex;
                NativePortSurface.Capture(rear.Source,supportRenderer);
            }
            if(rear!=null)
            {
                var surface=new GameObject("NativeAPCRearSurface"){layer=cabinet.gameObject.layer};surface.transform.SetParent(support.transform,false);
                surface.AddComponent<MeshFilter>().sharedMesh=rear.Mesh;NativePortSurface.Capture(rear.Source,surface.AddComponent<MeshRenderer>());
            }
            if(lugClearance.Count>0){supportMesh=NativeMeshCrop.Exclude(supportMesh,lugClearance);support.GetComponent<MeshFilter>().sharedMesh=supportMesh;}
            var supportCollider=support.AddComponent<MeshCollider>();supportCollider.sharedMesh=supportMesh;cabinet.BuildStates[1].Colliders.Add(supportCollider);
            CabinetModel.SetBounds(cabinet);
        }
        internal static void AlignToGrid(Structure cabinet)
        {
            var root=cabinet.transform.Find("SwitchboardModel/CompletedShell/ExternalCablePorts");if(root==null)return;
            // Wall fitting may move the visible casing. Native electrical coordinates stay
            // on the original wall-grid plane, including cursor previews and other wall skins.
            root.localPosition=root.parent.InverseTransformPoint(cabinet.transform.position)+Vector3.forward*CabinetModel.MountOffset;
        }
        internal static void IncludeBounds(Structure cabinet,ref Bounds bounds)
        {
            foreach(var name in new[]{"ExternalCablePorts","RearCableCasing"})
            {
            var root=cabinet.transform.Find("SwitchboardModel/CompletedShell/"+name);if(root==null)continue;
            foreach(var filter in root.GetComponentsInChildren<MeshFilter>(true))
                if(filter.sharedMesh!=null)bounds.Encapsulate(CabinetWallMount.TransformedBounds(filter.sharedMesh.bounds,cabinet.transform.worldToLocalMatrix*filter.transform.localToWorldMatrix));
            }
        }
    }
}
