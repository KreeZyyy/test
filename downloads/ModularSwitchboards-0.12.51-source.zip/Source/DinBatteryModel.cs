using System.Collections.Generic;
using System.Linq;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Items;
using UnityEngine;
using Rendering;
using Assets.Scripts.UI;

namespace ModularSwitchboards
{
    internal static class DinBatteryModel
    {
        internal static Mesh Build()
        {
            var v=new List<Vector3>();var n=new List<Vector3>();var t=new List<int>[5];for(int i=0;i<5;i++)t[i]=new List<int>();
            float x=DinLayout.SlotPitch*1.5f/DinBreakerModel.VisualScale.x;
            float width=.0176f+3f*DinLayout.SlotPitch/DinBreakerModel.VisualScale.x;
            System.Action<Vector3,Vector3,int> box=(p,s,r)=>RoundedGeometry.Box(v,n,t[r],p,s,.0007f);
            box(new Vector3(x,0,.018f),new Vector3(width,.075f,.032f),1);
            box(new Vector3(x,0,.0345f),new Vector3(width-.006f,.046f,.001f),3);
            foreach(float side in new[]{-1f,1f})
            {
                box(new Vector3(x+side*(width*.5f-.0015f),0,.047f),new Vector3(.003f,.047f,.026f),1);
                box(new Vector3(x,side*.030f,.033f),new Vector3(width,.015f,.058f),1);
                box(new Vector3(x,side*.030f,.0625f),new Vector3(.009f,.009f,.001f),4);
                box(new Vector3(x,side*.030f,.0632f),new Vector3(.006f,.001f,.0004f),3);
                box(new Vector3(x,side*.0376f,.029f),new Vector3(.004f,.0003f,.004f),3);
            }
            var mesh=new Mesh{name="Switchboards.DinBatteryHousing"};mesh.SetVertices(v);mesh.SetNormals(n);mesh.subMeshCount=5;
            for(int i=0;i<5;i++)mesh.SetTriangles(t[i],i);CabinetGeometry.ApplyNativeUv(mesh);mesh.RecalculateBounds();return mesh;
        }
        internal static void Install(DinBreaker module)
        {
            var oldView=module.GetComponent<BreakerSwitchView>();if(oldView!=null)Object.DestroyImmediate(oldView);
            var model=module.transform.Find("DinBreakerModel");
            foreach(string name in new[]{"BreakerLever","BreakerControl","BreakerIndicator"}){var child=model.Find(name);if(child!=null)Object.DestroyImmediate(child.gameObject);}
            var mesh=Build();model.GetComponent<MeshFilter>().sharedMesh=mesh;
            var body=model.GetComponent<BoxCollider>();body.center=mesh.bounds.center;body.size=mesh.bounds.size;
            float center=module.ContactOffsetX;
            var action=new GameObject("BatteryControl"){layer=module.gameObject.layer};action.transform.SetParent(model,false);
            var collider=action.AddComponent<BoxCollider>();collider.center=new Vector3(center,0,.050f);collider.size=new Vector3(.052f,.044f,.027f);
            var toggle=new Interactable{Parent=module,Action=InteractableType.Slot1,Collider=collider,JoinInProgressSync=true,CanKeyInteract=true,KeyMap="PrimaryAction"};
            var location=new GameObject("BatteryContents").transform;location.SetParent(model,false);location.localPosition=new Vector3(center,0,.047f);
            module.Slots=new List<Slot>{new Slot{Parent=module,StringKey="Battery",Type=Slot.Class.Battery,Location=location,HidesOccupant=true,IsSwappable=false,Action=InteractableType.Slot1,Collider=collider,Interactable=toggle}};
            module.Interactables=new List<Interactable>{toggle};module.HasOnOffState=false;
            module.BuildStates[0].Interactables=module.Interactables;module.BuildStates[0].Colliders=new List<Collider>{body,collider};
            module.Bounds=new Bounds(Vector3.Scale(mesh.bounds.center,model.localScale),Vector3.Scale(mesh.bounds.size,model.localScale));module.SurfaceArea=.064f;
            module.GridBounds=new GridBounds(module);
            var ghost=module.Blueprint.GetComponent<MeshFilter>().sharedMesh;ghost.Clear();
            ghost.CombineMeshes(Enumerable.Range(0,5).Select(i=>new CombineInstance{mesh=mesh,subMeshIndex=i,transform=Matrix4x4.Scale(model.localScale)}).ToArray(),true,true);ghost.RecalculateBounds();
            module.Blueprint.GetComponent<Wireframe>().BlueprintBounds=ghost.bounds;
            var view=module.gameObject.AddComponent<DinBatteryView>();view.Owner=module;
        }
    }

    // Show the native inserted cell's mesh/materials inside the wider DIN pocket.
    public sealed class DinBatteryView:MonoBehaviour
    {
        public DinBreaker Owner;
        private BatteryCell previous;
        private GameObject visual;
        private readonly List<Mesh> meshes=new List<Mesh>();
        private void Clear()
        {
            if(visual!=null)Object.Destroy(visual);visual=null;
            foreach(var mesh in meshes)Object.Destroy(mesh);meshes.Clear();
        }
        private void OnDestroy()=>Clear();
        private void LateUpdate()
        {
            if(Owner==null)return;var cell=Owner.Battery;if(ReferenceEquals(cell,previous))return;previous=cell;Clear();if(cell==null)return;
            try
            {
                visual=new GameObject("NativeBatteryVisual"){layer=Owner.gameObject.layer};visual.transform.SetParent(Owner.transform.Find("DinBreakerModel"),false);
                var source=WorldManager.Instance.SourcePrefabs.OfType<BatteryCell>().FirstOrDefault(b=>b.PrefabHash==cell.PrefabHash)??cell;
                var parts=new List<MeshRenderer>();var bounds=new Bounds();bool first=true;
                foreach(var renderer in source.GetComponentsInChildren<MeshRenderer>(true))
                {
                    var original=renderer.GetComponent<MeshFilter>()?.sharedMesh;if(original==null)continue;
                    CabinetGeometry.ReadNativeMesh(original,out var vertices,out var uv,out var triangles);
                    var matrix=source.transform.worldToLocalMatrix*renderer.transform.localToWorldMatrix;
                    for(int i=0;i<vertices.Length;i++){vertices[i]=matrix.MultiplyPoint3x4(vertices[i]);if(first){bounds=new Bounds(vertices[i],Vector3.zero);first=false;}else bounds.Encapsulate(vertices[i]);}
                    var copy=new Mesh{name="Switchboards.InsertedBattery"};copy.vertices=vertices;copy.uv=uv;copy.subMeshCount=triangles.Length;
                    for(int i=0;i<triangles.Length;i++){if(matrix.determinant<0)for(int j=0;j<triangles[i].Length;j+=3){int swap=triangles[i][j+1];triangles[i][j+1]=triangles[i][j+2];triangles[i][j+2]=swap;}copy.SetTriangles(triangles[i],i);}copy.RecalculateNormals();copy.RecalculateBounds();meshes.Add(copy);
                    var go=new GameObject("BatteryPart"){layer=Owner.gameObject.layer};go.transform.SetParent(visual.transform,false);go.AddComponent<MeshFilter>().sharedMesh=copy;
                    var draw=go.AddComponent<MeshRenderer>();draw.sharedMaterials=renderer.sharedMaterials;
                    var block=new MaterialPropertyBlock();renderer.GetPropertyBlock(block);draw.SetPropertyBlock(block);
                    for(int i=0;i<draw.sharedMaterials.Length;i++){renderer.GetPropertyBlock(block,i);draw.SetPropertyBlock(block,i);}parts.Add(draw);
                }
                if(first)throw new System.InvalidOperationException("Native battery has no readable visual meshes");
                bool turn=bounds.size.y>bounds.size.x;var rotation=Quaternion.Euler(0,0,turn?90:0);
                var size=turn?new Vector3(bounds.size.y,bounds.size.x,bounds.size.z):bounds.size;
                float scale=Mathf.Min(.052f/Mathf.Max(size.x,.00001f),Mathf.Min(.041f/Mathf.Max(size.y,.00001f),.026f/Mathf.Max(size.z,.00001f)));
                foreach(var renderer in parts)renderer.transform.localPosition=-bounds.center;
                visual.transform.localRotation=rotation;visual.transform.localScale=Vector3.one*scale;
                visual.transform.localPosition=new Vector3(Owner.ContactOffsetX,0,.047f);
            }
            catch(System.Exception ex){Clear();Debug.LogWarning("[Modular Switchboards] Battery visual: "+ex.Message);}
        }
    }
}
