from pathlib import Path
root=Path(__file__).resolve().parents[2];s=(root/'Source/SwitchboardLabel.cs').read_text()
def block(start):
 a=s.index(start);b=s.index('{',a);depth=1;i=b+1
 while depth:
  depth+=(s[i]=='{')-(s[i]=='}');i+=1
 return s[a:i]
p='using System.Linq;using UnityEngine;using Assets.Scripts.GridSystem;using LibConstruct;namespace ModularSwitchboards{'+block('internal static class LabelLayout')+'public partial class SwitchboardLabel{'+block('internal static bool CanPlace(')+block('internal static void SetBounds(')+'}}'
(Path(__file__).parent/'Extracted.cs').write_text(p)
