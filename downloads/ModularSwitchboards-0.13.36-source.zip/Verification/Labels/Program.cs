using System;using System.Collections.Generic;using ModularSwitchboards;using UnityEngine;using Assets.Scripts.GridSystem;using LibConstruct;
namespace UnityEngine{public struct Bounds{public Vector3 center,size;public Bounds(Vector3 c,Vector3 s){center=c;size=s;}}public struct Vector3{public float x,y,z;public Vector3(float a,float b,float c){x=a;y=b;z=c;}}public class Transform{public Vector3 position;public Vector3 InverseTransformPoint(Vector3 p)=>p;}public static class Mathf{public static float Abs(float x)=>Math.Abs(x);}}
namespace Assets.Scripts.GridSystem{public class GridBounds{public GridBounds(object owner){}}public struct Grid3{public int x,y,z;public Grid3(int a,int b,int c){x=a;y=b;z=c;}}}
namespace LibConstruct{public class PlacementBoard{public object PrimaryHost;public List<object> Structures=new();public Grid3 WorldToGrid(Vector3 p)=>new((int)Math.Round(p.x/.0045*10),(int)Math.Round(p.y/.0045*10),0);}}
namespace ModularSwitchboards{class DinLayout{public const float SlotPitch=.0405f;}class DinBreaker{public Transform transform=new();public int ModuleWidth;}class Wiring{public List<DinBreaker> Breakers=new();}class Cabinet{public bool IsOpen=true;public Wiring Wiring=new();}class InnerCoverModule{public Cabinet Host=new();public Transform transform=new();}class SwitchboardLabelBoard:PlacementBoard{}public partial class SwitchboardLabel{public Bounds Bounds;public GridBounds GridBounds;public Transform ThingTransform;public Transform transform=new();public int Width;}}
class Program{
 static int n;static void Check(bool ok,string m){n++;if(!ok)throw new Exception(m);}
 static void Main(){
 for(int width=1;width<=3;width++)for(int row=-240;row<=240;row+=480)for(int slot=0;slot<8;slot++)Check(LabelLayout.Fits(slot*90,row,0,0,width)==(slot+width<=8),"row bounds");
 foreach(var p in new[]{new Grid3(0,0,0),new Grid3(0,120,0),new Grid3(0,-120,0),new Grid3(-90,240,0),new Grid3(10,240,0),new Grid3(0,240,10)})Check(!LabelLayout.Fits(p.x,p.y,p.z,0,1),"reject under/between/offset/outside");
 Check(!LabelLayout.Fits(0,240,0,1,1),"rotation rejected");Check(!LabelLayout.Fits(0,240,0,0,0)&&!LabelLayout.Fits(0,240,0,0,4),"width bound");
 var cover=new InnerCoverModule();var board=new SwitchboardLabelBoard{PrimaryHost=cover};var p0=new Grid3(0,240,0);
 Check(!SwitchboardLabel.CanPlace(board,p0,0,1),"needs installed module");
 cover.Host.Wiring.Breakers.Add(new(){ModuleWidth=2,transform=new(){position=new(-3.5f*.0405f,.108f,0)}});
 Check(SwitchboardLabel.CanPlace(board,p0,0,2),"2-wide module supports 2-wide label");Check(!SwitchboardLabel.CanPlace(board,p0,0,3),"unsupported end rejected");
 Check(!SwitchboardLabel.CanPlace(board,new(0,-240,0),0,1),"wrong row rejected");
 cover.Host.Wiring.Breakers.Add(new(){ModuleWidth=1,transform=new(){position=new(-1.5f*.0405f,.108f,0)}});Check(SwitchboardLabel.CanPlace(board,p0,0,3),"group of modules supports 3-wide");
 var placed=new SwitchboardLabel{Width=2,transform=new(){position=new(0,.108f,0)}};board.Structures.Add(placed);
 Check(!SwitchboardLabel.CanPlace(board,p0,0,1),"overlap rejected");Check(!SwitchboardLabel.CanPlace(board,new(90,240,0),0,2),"partial overlap rejected");Check(SwitchboardLabel.CanPlace(board,new(180,240,0),0,1),"adjacent label permitted");
 cover.Host.IsOpen=false;Check(!SwitchboardLabel.CanPlace(board,new(180,240,0),0,1),"closed cabinet rejected");cover.Host.IsOpen=true;
 Check(!SwitchboardLabel.CanPlace(new PlacementBoard{PrimaryHost=cover},p0,0,1),"wrong board rejected");Check(!SwitchboardLabel.CanPlace(null,p0,0,1),"missing cover rejected");
 for(int width=1;width<=3;width++){var label=new SwitchboardLabel{Width=width,Bounds=new Bounds(new(1,1,1),new(1,1,1))};SwitchboardLabel.SetBounds(label);Check(Math.Abs(label.Bounds.size.x-(width*.0405f-.004f))<.000001f,"selection width matches plate");Check(label.Bounds.size.y==.018f&&label.Bounds.size.z==.002f,"selection hugs label height/depth");Check(label.Bounds.center.x==(width-1)*.0405f*.5f&&label.Bounds.center.y==0&&label.Bounds.center.z==0,"selection centered on actual offset model");Check(label.ThingTransform==label.transform&&label.GridBounds!=null,"preview transform and grid bounds refreshed");}
 Console.WriteLine(n+" production label placement checks passed.");
 }
}
