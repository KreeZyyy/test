"""Apply fixed loose placements to preserved packed module geometry, non-cumulatively."""
from pathlib import Path
import json,math,subprocess,sys
root=Path(__file__).resolve().parents[1];f=root/'Art/ModuleKit/source.json';data=json.loads(f.read_text())
contents=json.loads((root/'Art/ModuleKit/packed-contents.json').read_text())
def rotate(p,angles):
 x,y,z=p;rx,ry,rz=[math.radians(a)for a in angles]
 y,z=y*math.cos(rx)-z*math.sin(rx),y*math.sin(rx)+z*math.cos(rx)
 x,z=x*math.cos(ry)+z*math.sin(ry),-x*math.sin(ry)+z*math.cos(ry)
 return [x*math.cos(rz)-y*math.sin(rz),x*math.sin(rz)+y*math.cos(rz),z]
layout=[{'part':'breaker','pivot':[-.158,.08,-.04],'shift':[-.012,.006,.020],'angles':[7,-9,7]},
        {'part':'empty fuse holder','pivot':[-.049,.08,-.04],'shift':[.005,.014,-.045],'angles':[-5,7,-5]},
        {'part':'empty battery backup','pivot':[.109,.08,-.04],'shift':[.012,0,.025],'angles':[3,-6,-3]}]
# The packed authoring data has three disjoint x ranges, including each module's details.
def group(x):return 0 if x<-.106 else 1 if x<.005 else 2
for indices in contents['triangles'].values():
 for i in range(0,len(indices),3):assert len({group(contents['vertices'][j][0])for j in indices[i:i+3]})==1
for i,p in enumerate(contents['vertices']):
 spec=layout[group(p[0])];q=rotate([p[k]-spec['pivot'][k]for k in range(3)],spec['angles'])
 contents['vertices'][i]=[q[k]+spec['pivot'][k]+spec['shift'][k]for k in range(3)]
data['contents']=contents;data['layout']=layout;data['layoutPolicy']='Fixed slight lean, yaw and offsets; details transformed with their module; crate unchanged.'
f.write_text(json.dumps(data))
subprocess.run([sys.executable,str(root/'Tools/create_module_kit.py')],check=True)
