"""Same preserved crate as the module kit; original perforated DIN rail contents.
Decorative bundles of four different lengths. Run before render_rail_kit.py.
"""
from pathlib import Path
import json,subprocess,sys,math
root=Path(__file__).resolve().parents[1]
shell=json.loads((root/'Art/ModuleKit/source.json').read_text())['shell']
v=[];tri=[]
def quad(a,b,c,d):
 i=len(v);v.extend([a,b,c,d]);tri.extend([i,i+1,i+2,i,i+2,i+3])
def box(x0,x1,y0,y1,z0,z1):
 if x1-x0<1e-8 or y1-y0<1e-8 or z1-z0<1e-8:return
 quad([x0,y0,z0],[x0,y0,z1],[x0,y1,z1],[x0,y1,z0])
 quad([x1,y0,z1],[x1,y0,z0],[x1,y1,z0],[x1,y1,z1])
 quad([x0,y0,z1],[x0,y0,z0],[x1,y0,z0],[x1,y0,z1])
 quad([x0,y1,z0],[x0,y1,z1],[x1,y1,z1],[x1,y1,z0])
 quad([x1,y0,z0],[x0,y0,z0],[x0,y1,z0],[x1,y1,z0])
 quad([x0,y0,z1],[x1,y0,z1],[x1,y1,z1],[x0,y1,z1])
def rail(length,y,z):
 left=-.215;right=left+length
 # A thin perforated web, upright sides and outward lips: open TH35 section.
 slots=max(2,round(length/.060));pitch=length/slots;edge=left
 for i in range(slots):
  center=left+(i+.5)*pitch;a=center-.011;b=center+.011
  box(edge,a,y,y+.002,z-.018,z+.018)
  box(a,b,y,y+.002,z-.018,z-.004)
  box(a,b,y,y+.002,z+.004,z+.018)
  edge=b
 box(edge,right,y,y+.002,z-.018,z+.018)
 for side in [-1,1]:
  c=z+side*.019
  box(left,right,y,y+.027,c-.001,c+.001)
  c=z+side*.024
  box(left,right,y+.025,y+.027,c-.006,c+.006)
def rotate(point,angles):
 x,y,z=point;rx,ry,rz=[math.radians(a)for a in angles]
 y,z=y*math.cos(rx)-z*math.sin(rx),y*math.sin(rx)+z*math.cos(rx)
 x,z=x*math.cos(ry)+z*math.sin(ry),-x*math.sin(ry)+z*math.cos(ry)
 return [x*math.cos(rz)-y*math.sin(rz),x*math.sin(rz)+y*math.cos(rz),z]
lengths=[.430,.350,.275,.200];placements=[]
for row,(length,z)in enumerate(zip(lengths,[-.150,-.050,.050,.150])):
 for layer,y in enumerate([.142,.200,.258]):
  if layer<2:
   angles=[(-1 if row%2 else 1)*2,[-3,5,-4,6][row]*(1 if layer else -.5),[-2,2,1,-1][row]]
   center=[-.215+length/2+([-.005,.010,-.008,.009][row]if layer else 0),y,z+(.005 if row%2 else -.005)]
  else:
   angles=[[5,-7,4,-4][row],[-18,12,-22,19][row],[14,-10,8,-12][row]]
   center=[[.065,-.015,-.055,-.070][row],[.325,.310,.285,.300][row],[-.125,-.035,.060,.150][row]]
  start=len(v);rail(length,0,0);pivot=-.215+length/2
  for i in range(start,len(v)):
   q=rotate([v[i][0]-pivot,v[i][1],v[i][2]],angles);v[i]=[q[k]+center[k]for k in range(3)]
  placements.append({'length':length,'center':center,'rotationXYZ':angles})
source={'shell':shell,'contents':{'vertices':v,'triangles':{'4':tri}},'design':{'lengths':lengths,'layers':3,'placements':placements,'layout':'fixed irregular offsets; upper pieces lean over the rim','section':'open perforated DIN channel; real web holes','note':'decorative contents do not imply additional kit quantity'}}
(root/'Art/RailKit/source.json').write_text(json.dumps(source))
subprocess.run([sys.executable,str(root/'Tools/create_module_kit.py'),'RailKit'],check=True)
print('Rail crate: four lengths, three loosely arranged layers; original crate shell and atlas retained.')
