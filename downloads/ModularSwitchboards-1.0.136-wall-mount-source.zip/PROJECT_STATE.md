## 1.0.136 — Symmetric wall mounting envelope

Back-face mounting now uses the same outer mounting envelope as the opposite face, instead of pulling the cabinet inward to the native wall's thin/asymmetric rear skin. The envelope is centred on the native wall mounting grid. It applies to both the template/ghost offset and the actual supporting-wall fit. The known native flat-wall profile (rear+0.012642m,front+0.130001m,grid plane0) retains its front face and uses-0.130001m at the back, with the existing0.5mm clearance. This is a conservative mounting envelope, not a new scan of every surrounding frame.

Cabinet root/grid positions, roll/orientation choices, models, costs, wiring graph and save formats are unchanged. Existing model-relative rails/modules, covers, door boards and wire visuals move with their existing parent transforms. Existing cable-port alignment and bounds refresh remain in place. Previously placed back-side cabinets refit through the existing wall-fit update after loading. No forced save migration or electrical reconnection.

Validation: native-reference build0warnings/errors;34,014 wall-envelope fixture checks cover the reported asymmetric profile, opposite faces, shifted mounting grid planes, cardinal rotations, model-relative child translation, symmetric/invalid profiles. Existing upright/manual mount-orientation fixture also passes. Native LibConstruct AddStructure parents mounted structures to each board Origin; those origins are children of CompletedShell. Offline fixtures do not reproduce the player's exact scene or prove all surrounding structural geometry is clear. Actual game appearance and a populated cabinet on the back wall still need testing.

Includes135internal control power,134stable printer names and orange indicator; manual cable routing remains removed. The separate vanilla multiplayer printer issue remains unconfirmed. Install the same version on server and clients. No Steam Workshop publication.

## 1.0.135 — Internal control power from the wired supply branch

Core and Smart Output control electronics now use the cabinet's real path-based source allocator, alongside transformer control electronics. Supply can come from external inputs, transformers or battery OUT according to the actual connected circuit. A Core no longer requires an external output cable or native external network to run. Outputs take their control supply through their attached Core's side bus and each enabled, correctly addressed Output retains its existing5W cost. Core and transformer costs retain their existing native UsedPower values. Smart Net data-only behaviour is unchanged.

Internal consumers reserve and pay energy once per native electricity cycle. Native consumer billing is disabled for Core and Smart Outputs to avoid double charging; external data-network registration remains independent. Batteries pay actual delivered consumption; native source shortfalls can be topped up from available battery energy at cycle end. Transformer transfer limits, upstream breakers/fuses and physical wire limits remain on the real supply path. Unfinished/OFF/detached or insufficiently supplied consumers do not run. Core supply loss releases control Outputs. No new save format or prefab identities; existing objects keep their wiring.

Validation: final native-reference build0warnings/errors;18,046 service-power checks including3,000 changing-source/enable cycles, isolated battery, mixed/duplicate/multiple inputs, bus loads, actual brownout top-up, exact battery use, output competition, transfer caps, protection, removal and disabled/zero-power states.33 actual mapping/runtime-method checks;33 data-network checks;96 Smart bus/PLC checks. Existing power/protection/battery/transformer regression suite passed. Several old test stubs were brought up to current source interfaces; fixture unused-field warnings are not native build warnings. These are offline checks, not a live Unity or multiplayer validation.

Test on matching1.0.135 server/clients: feed battery IN from a transformer and wire battery OUT to Core POWER IN; install a charged cell. Core should run without an external Output cable. Fit Smart Outputs, verify their commands, disconnect mains, then test battery depletion and an open upstream breaker. Consumption must follow the battery/source. Manual routing remains removed; orange LED and134 stable printer-name correction remain. The separate all-vanilla multiplayer Print issue is not claimed resolved by this power change. No Steam publication.

## 1.0.134 — Stable fallback names for printer kit ordering

Fixes an offline-reproduced language-dependent ordering defect for the seven Switchboards kit recipes. The native printer sorts by Localization.GetFallbackName, while the old mod supplied only GetThingName. The new narrow fallback hook supplies stable English names for these seven kit prefab IDs and shares the same mapping with display-name lookup. It leaves vanilla, other mods and non-recipe prefabs on the original localization path. Recipe costs, outputs, networking, electrical behaviour and existing prefab identities are unchanged. Automatic routing from133 is retained; manual routing remains removed. Orange indicator, DS support and printer diagnostics remain.

Use the same1.0.134 on server and clients, restart both, and reselect the desired recipe before testing Print. This correction addresses the reproduced own-kit ordering bug; it is NOT proof that the separate report of all vanilla printing stopping is resolved. The supplied multiplayer logs were client1.0.130 and did not include the authoritative server state.

Validation: native-reference build0warnings/errors;22,849 checks of the actual new name helper against native sorting/fallback method fixtures, including600 catalogue comparisons across6languages, random insertion orders, exact per-index identity, custom-name independence and vanilla/foreign/null fallthrough. Negative control reproduces the old mismatch. No live multiplayer reproduction or validation yet.

## 1.0.133 — Remove experimental manual routing

Restores the automatic cable routing, normal terminal selection and original wire network packet format from 1.0.131. Removes manual routing points, their markers and automatic raised crossings introduced in 1.0.132. Existing completed wires keep their stored paths and electrical endpoints; no save wipe or forced rerouting. Orange Door LED, DS startup support, Core IC10 access repair and printer diagnostics are retained. The Electronics Printer issue remains unresolved. Use matching versions on server and clients, and restart both when switching from 1.0.132.

## 1.0.131 — Electronics Printer diagnostic candidate

Based on DS/orange 1.0.130. Adds observation of the Electronics Printer catalogue and ordered prefab fingerprint on startup, recipe selection on the client, recipe-index receipt on the server, and Print interactions (power, activation, error, tier, ingredients and current recipe). Logs include version and headless/simulation mode. Native exceptions are logged and returned unchanged; diagnostic read failures do not block the game action. No recipe, power, button or network-message behaviour is intentionally changed.

This is NOT a confirmed fix. Install this exact candidate on both the Linux server and testing client, restart, select a vanilla recipe with enough materials and press Print once. Send both logs from startup through that attempt; search for `Printer diagnostic`. One startup catalogue line lists prefab identities only. No player data is logged by these added diagnostics. Actual DS/Unity testing is still required. Native-reference build: zero warnings/errors. Includes orange Door LED; no Large prototypes.

## 1.0.130 — Orange door indicator

Adds Door LED Orange to the existing Door kit for 1 kit. Includes orange off/on lens, emission, native light, icon, F1 catalogue and orange/amber search aliases. Existing prefab names remain unchanged. Based on DS candidate 1.0.127; no Large cabinet changes. The reported Electronics Printer server failure is still under investigation; this addition does not fix it.

Validation: native-reference build passed with 0 warnings/errors; 134 production LED controller checks passed. Actual in-game and multiplayer validation pending.

# Modular Switchboards 1.0.127 — dedicated-server startup candidate

Based on stable 1.0.126 (the Workshop-linked 1.0.122 line plus IC10 access fix). No Large cabinet prototype changes.

The reported first error, Native game paint material unavailable, comes from graphics validation during prefab preparation. Failed recipe checks follow the aborted prefab transaction. A non-rendering server must not require Shader.isSupported to be true.

- Centralized headless detection (batch mode or Null graphics device) and shader validation. Normal rendered clients still reject unsupported shaders. Missing server-wide paint templates/custom shaders can use an existing native APC material/shader; no null shader is accepted.
- Native CPU-readable meshes are copied with all native channels for the battery holder and analyzer, retaining selected triangles without GPU-buffer readback. Client GPU-copy/verification path is retained.
- Headless startup skips cosmetic warning texture readback, lever recolour blits and thumbnails. Shapes/ports/slots/recipes remain registered normally.
- Non-readable mesh data on a headless server fails with the exact mesh name before attempting GPU access. No fake geometry or placeholder colliders are supplied. Fully stripped native meshes require further matching CPU geometry support.
- Startup log reports headless status and graphics backend; paint failures report whether template/shader is missing.

Validation: native-reference build0warnings/errors;72headless shader/material policy checks;16CPU mesh selection/channel-preservation checks;97IC10 access checks passed. This is NOT a real dedicated-server or multiplayer test. The reporter must verify server startup and joining/constructing with matching clients. Use this same version on the DS and every client. If startup still fails, capture the FIRST complete prefab setup exception and stack trace, not only the later recipe failures. Steam Workshop has not been updated.

# Modular Switchboards 1.0.126 — Smart Core IC10 access repair

Based on Workshop-linked 1.0.122, without any Large cabinet prototype changes.

Completed Core slot access now explicitly rebinds the native slot/action/collider dictionaries after registration and construction-state visualization, and checks them during runtime. This covers the native renderer-dependent state-update path that can leave a visible finished socket with stale interaction caches. The custom slot is authored as interactable rather than inheriting the source Air Conditioner's UI flag. Incomplete Core stages remain unavailable; closed/detached cabinet access stays disabled. Existing slot, occupant and chip seating transform are retained.

Validation: native-reference build0warnings/errors;97production slot/cache/state/access/rollback/chip-preservation checks;61Core stage checks;15Core save/migration checks;22wire-readiness checks passed. These are fixture/stub checks, not Unity reproduction. Actual cause of the user's selection failure and in-game insertion still need confirmation. A one-time log on cache rebind reports stage and binding availability.

Test a fully completed Core: aim at the right-hand socket with an IC10 in hand, insert/remove it, close/reopen the cabinet, then save/reload. If it still fails, collect the Core IC10 access rebound log and check whether the slot action appears while aiming at the socket. Large prototypes remain separate and Steam Workshop has not been updated.

# Modular Switchboards 1.0.122 — restore cabinet door pose during load

Saved door positions now apply immediately during save/join restoration and registration, with first-physics-step initialization as a fallback. Small and both Medium door hinges retain their existing animation and physical colliders. This addresses a door initialization gap; whether it resolves reported player displacement near cabinets requires in-game verification.

Validation: 23 door load/physics/animation checks passed; native-reference build without warnings/errors.

# Modular Switchboards 1.0.121 — empty cover kit refunds

Removing a cover without live labels uses normal deconstruction and returns its cover kits (Small 1, Medium 2). Covers with labels remain portable Fitted Covers, preserving labels, openings and colour. Empty painted covers also return kits.

Validation: 94 cover-transfer checks passed; native-reference build without warnings/errors. Actual in-game refund verification remains pending.

# Modular Switchboards 1.0.120 — remaining kit economy and cover size costs

Smart Output now uses4 Smart kits (Net remains1). Door kit recipe:5 Iron +20 Copper; LEDs, round switches and individual bridges use1 kit, while TOTAL STOP and Main Switch use3. Label kit recipe:5 Silicon, with1 kit per label regardless of width. Cover kit recipe:20 Silicon; Small cover uses1 kit, Medium2.

Medium cover has a separate hidden native-cost prefab so LibConstruct consumes2 kits through its normal construction path. Mounting and server authority select the cabinet-size-matched prefab. All cabinet orientations/input-output variants use the corresponding Small/Medium cost. Existing fitted covers retain labels/color/openings and can be refitted without new kits. The standalone covers remain hidden from F1/creative listings; the kit entry describes both costs.

Validation: native-reference build without warnings/errors;74 direct cover/name/preview/client/cancellation/size/cost checks and70 actual cover-transfer checks passed. Other staged module behavior and accepted geometry remain unchanged. Actual Unity printer/consumption/refund/new-prefab/save-load/multiplayer verification remains pending.

# Modular Switchboards 1.0.119 — native rounded display outline and pocket surfaces

The unfinished Core display opening follows the actual original white bezel outline, including its curved segments, instead of simple chamfered corners. Its floor remains 4 mm deep. Display and IC10 pocket floors/walls now use source material roles, sampled native UVs and original material property blocks instead of the bright cabinet gray. Chip lining is visible only before the native socket is installed; the completed native socket remains unchanged. F1 stage images match the revised models.

Construction, kit recipes, save migration and completed-only chip/control/network/power/wiring gates remain unchanged.

Validation: native-reference build without warnings/errors; 7,395 geometry/ray/rounded-outline/depth/UV-role/nondegenerate checks and 61 stage/model/control/rollback/lining checks passed. F1 icons visually inspected. Actual Unity appearance/color/construction/save-load/multiplayer verification remains pending.

# Modular Switchboards 1.0.118 — visible IC10 and display pockets in unfinished Core

Core now shows the original-depth IC10 opening with an opaque gray floor before the socket is fitted. The display opening matches the native bezel footprint and is 4 mm deep, also with gray walls and a closed floor. These pockets remain beneath the fitted components. Stage0 shows both openings, stage1 adds the display, stage2 adds the original native IC10 socket. F1 images match the revised stage models.

Construction remains 5 Smart kits, then 2 Electronic Parts, then 5 Heavy Cable Coils; IC10 separate. Recipes, saved-stage migration, completed-only chip/control/network/power/wiring gates remain unchanged.

Validation: native-reference build without warnings/errors; 7,005 native geometry/ray/depth/material/nondegenerate checks and 49 stage/model/control/rollback checks passed. Actual Unity appearance/construction/save-load/multiplayer verification remains pending.

# Modular Switchboards 1.0.117 — Smart kit economy and three-stage Core

One Smart kit now costs 10 Copper + 8 Steel + 4 Solder in the Electronics Printer. Core construction: 5 Smart kits build the solid body without display or IC10 socket; 2 Electronic Parts add the display; 5 Heavy Cable Coils add the original socket and its pocket. Insert a separate removable IC10 only after completion. Other Smart module construction kit counts remain unchanged.

Each Core stage has its own F1 image. Incomplete Cores cannot accept IC10, use controls, run programs, bind power/data networks or receive new wiring. Heavy coil assembly uses native construction instead of internal wiring at the display-only stage. New saves preserve partial stages; older completed Core saves migrate to the final stage. The completed native display/socket appearance is preserved.

Validation: native-reference build without warnings/errors; 14 Smart-kit placement/recipe checks, 15 Core save/XML/chip/legacy checks, 49 stage/model/control/rollback checks, 2,085 native LED/socket geometry checks and 21,938 other geometry checks passed. Stage icons visually inspected. Actual Unity construction/slot/wiring/save-load/multiplayer verification remains pending.

# Modular Switchboards 1.0.116 — original battery floor depth and material

The unfinished battery holder now uses the original deepest native APC floor geometry and material instead of the shallow gray plate. Preserve its original floor depth, vertex channels, UVs, material roles and property blocks. Expand only in X/Y to close the unfinished aperture. The completed native holder stays unchanged. The F1 unfinished image matches the deeper original floor.

Battery construction remains 5 DIN kits plus 1 Electronic Parts; cell separate. Transformer construction remains Small 5 kits plus 2 Heavy Cable Coils, Medium 8 kits plus 6 Heavy Cable Coils. Completed-only new wiring and existing save/power/slot gates remain.

Validation: native-reference build without warnings/errors; 12 production floor-selection/material-role/depth/backface checks passed. Actual Unity appearance/construction/slot/wiring/save-load/multiplayer verification remains pending.

# Modular Switchboards 1.0.115 — battery completion parts and heavy transformer windings

Battery holder: 5 DIN module kits build the body; 1 Electronic Parts completes the original native holder. No Gold or Plastic Sheet is required for this completion. The removable cell remains separate. An opaque gray backing now closes the unfinished aperture, with a matching F1 stage image; the completed original holder is unchanged.

Transformer winding completion now requires Heavy Cable Coils: Small uses 5 DIN module kits plus 2 Heavy Cable Coils; Medium uses 8 DIN module kits plus 6 Heavy Cable Coils. The heavy coil prefab is resolved from the native cable catalog instead of guessing its name. Body construction, completed-only new wiring, slot/power gates, saved-stage migration and other recipes remain as before.

Validation: native-reference build without warnings/errors; 12 updated production winding/contact-priority checks and 21,938 geometry checks passed. Actual Unity appearance/construction/slot/wiring/save-load/multiplayer verification remains pending.

# Modular Switchboards 1.0.114 — restore original battery holder model

Restore the original battery holder appearance without added gray frame bars or extra gold contact pads. Five DIN module kits build the body with an empty opening; 1 g Gold completes the original native holder. The battery cell remains separately removable. Retain construction stages, old-save completion migration, power/slot gates, separate F1 stage images, and the rule allowing new wiring only on completed modules. Battery stage images now show only the original body and native holder.

Validation: native-reference build passes without warnings/errors. Recipe, migration and wiring sources remain identical to 1.0.113. Published source snapshots are preserved. Actual Unity appearance/interaction/save-load/multiplayer validation remains pending.

# Modular Switchboards 1.0.113 — battery construction, stage icons and completed-module wiring

Battery holder construction now uses 5 DIN module kits for the base, then 1 g Gold to finish. There is no Plastic Sheet requirement. The unfinished gray mounts differ visibly from the completed native holder with gold contact pads. Insert the removable battery cell only after completing the holder. Incomplete holders cannot conduct, charge or discharge. Existing completed holders migrate to the completed stage when loading older saves; new saves retain their construction stage.

New internal cables require completed modules at both endpoints. Incomplete contacts do not show wiring markers; attempting to connect displays a completion message. Existing wires are retained and can still be removed with wire cutters. A previously selected endpoint is rechecked before connecting.

F1 Build States now has separate unfinished/finished images for both transformers and the battery holder. All six new icons use the production geometry exports; transformer images retain the original winding supports and materials.

Validation: native-reference build without warnings/errors, 14 battery save/migration/conduction checks, 22 module wiring readiness checks, and 21,934 production geometry checks passed. The six stage icons were visually inspected. Actual Unity construction/slot/wiring/save-load/multiplayer verification remains pending.

# Modular Switchboards 1.0.112 — original winding supports in unfinished transformers

Based on the accepted 1.0.110 appearance, replacing the rejected 1.0.111 visual change. Unfinished Small and Medium transformers hide only the copper winding while retaining original holders, covers and leads. Small keeps its original WindingBands; Medium retains the exact gray/dark support triangles embedded in the original winding mesh. The original gray fascia is flat and coplanar behind the missing winding, without new holder primitives or a white plate. Completing construction restores the original recessed face and full winding. Kit prices, construction quantities, power gates, save migration and the state -1 startup fix remain unchanged.

Validation: native-reference build without warnings/errors; 17,422 geometry checks and 8 initialization checks pass, with exact support triangle/UV provenance verified. Actual Unity appearance, interaction and multiplayer verification remains pending.

# Modular Switchboards 1.0.110 — transformer prefab initialization fix

Fix the 1.0.109 startup failure: do not invoke native stage visualization on an unplaced transformer prefab at state -1, and do not rebuild its fitted hitbox while the native state has all children inactive. Explicitly restore shared body, terminals and controls in both placed construction stages. Completed-stage winding visibility and the 1.0.109 recipes/counts remain.

# Modular Switchboards 1.0.109 — cabinet economy and transformer construction

Cabinet kit: 60 Iron + 30 Copper, Electronics Printer only. Small uses 1 kit + 2 Plastic Sheets; Medium uses 3 kits + 5 Plastic Sheets, including reverse/collector variants.

DIN rail kit: 5 Iron. One kit per Small or Medium rail. DIN module kit: 5 Iron + 20 Copper. Other kit recipes remain unchanged; all custom kits remain exclusive to the Electronics Printer.

DIN transformers now have two construction stages. Small: 5 module kits for the body, then 3 normal Cable Coil units. Medium: 8 module kits, then 5 normal Cable Coil units. The unfinished body keeps the gray pocket backing without windings. Its terminals can be wired, but it transfers no power until finished. Aim the coil at the body to finish construction; terminal targets retain wiring priority. Native construction handles material consumption and stage dismantling. Existing completed transformers migrate to the completed stage when loading older saves.

Validation: native-reference build succeeds without warnings/errors; 28 save/XML/join-order checks, 12 winding-versus-terminal routing checks, and 4,791 power-engine regression checks pass. Actual Unity stage rendering, construction interaction and multiplayer still need in-game testing.

# Local 1.0.108 — ready, not uploaded

Last published107 commit8688521e121ef4c556852977f47de52219a5a586 tree41dacb5bcce8ddd0bd8ca329481908c54793b087. User authorized auditing all own previews/hitboxes, explicitly including door and Smart and opaque normal-model parts leaking through preview. No upload until nahraj; never Workshop publish.

See Verification/PREVIEW-HITBOX-AUDIT-1.0.108.md for complete family matrix and validation limits. New sources: OwnPreviewPolicy, CursorModelIsolation, FittedModelCollider, FittedControlSelection, FittedKitBounds, OwnPreviewAudit. Native HandleStructurePrefab only destroys registered ThingRenderer entries; unregistered added copper/native parts survived. A Priority.Last postfix now prepares a cursor-only isolation component; cached non-ghost/non-BlueprintHelper-descendant Renderer.forceRenderingOff flags are enforced in LateUpdate. No shared material mutation. Actual world renderers untouched.

Common selection now fits actual Wireframe.BlueprintBounds, transformed/scaled; fallback actual Thing.Bounds when no wireframe. Cabinet accepted box remains; native visibility/validity preserved and all own outlines get native tint. Active constructor or authoring guard preserved. All own structure families including DinTransformer and SmartContactor covered. Precise BoxCollider interaction selection applies to own controls, preserving IDs/pose.

ModelBlueprint.Build optionally filters to nearest owning Thing and includes disabled own renderers for physical-body rebuilds. Defaults keep preview behaviour. Final ModelBlueprint.Refresh installs fitted passive bodies for DinRail/DinBreaker(includingdoor)/SmartModule/SmartContactor; transformer and door constructors have explicit final install. Known passive body boxes are removed from build-state lists/lookup; dedicated controls and board surfaces retained. MeshCollider uses actual snapshot triangles. Serialized hit reference preserves prefab clone mapping. Borrowed initial mesh vs owned runtime rebuild mesh lifetimes separated. DinTransformer.ApplyWidth now tolerates removed bodyBox and uses Rebuild instead of leaking an unretained mesh for bounds. SmartContactor.ApplyWidth and DinRail.ApplySized rebuild fitted bodies. Native Structure.CachePrefabBounds retains its normal code then postfix restores fitted bounds/grid cache. Rebuild excludes mounted Things and includes temporarily disabled own renderers, but respects inactive alternate geometry.

SwitchboardKitModel.InstallBlueprint fits each custom kit Rigidbody's convex box and Bounds to combined geometry; trigger colliders retained in lookup and self/dynamic lists. Native quantities, identity, mass/hand/stack metadata not modified. Installed covers/labels already have shape/cutout-aware mesh colliders. Portable cover payload/visual/12mm carry-envelope code unchanged; dynamic selection fits preview mesh bounds.

Prefab.OnPrefabsLoaded VerifyRegistration calls OwnPreviewAudit.Verify for blueprint mesh/renderer and fitted-body presence diagnostics. Native API Release0warnings/errors. ModelBlueprint154 own-audit +29 general checks; supporting kit38/transformer-layout10006/Output-upgrade11/rail39/doorgeometry9395/doorplacement73/cover100/nativehelpers213/placement1414/casing2367 regressions passed. Stub tests do not prove real Unity/PhysX/Mono/MP/save/load/runtime visual behaviour.107sourceZIP1055entries still byte-match107snapshot. Power, wire protocol, accepted cabinet preview, casing collision, native connection detection, portable cover payload source files verified unchanged.

All modifications atomically replace hardlinked snapshot files. Source artifacts retained. SDK8.0.426 under/tmp/switchboard-dotnet; standardtask DOTNET_CLI_HOME/XDG_DATA_HOME/XDG_CONFIG_HOME/NUGET_PACKAGES. Native references work/build-deps, LibConstructPath needs /LibConstruct/LibConstruct.dll. Packaging work/archive1108.py, manifestwork/release1108-artifacts.json authoritative whencomplete.
