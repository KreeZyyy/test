using System;
using System.Collections.Generic;
using System.Linq;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Structures;
using Assets.Scripts.Objects.Electrical;
using Assets.Scripts.Objects.Motherboards;
using Assets.Scripts;
using Assets.Scripts.UI;
using HarmonyLib;
using Rendering;
using UnityEngine.Rendering;
using UnityEngine;
using Object = UnityEngine.Object;

namespace ModularSwitchboards
{
    internal static class CabinetModel
    {
        internal static float MountOffset => CabinetWallMount.BackOffset;
        internal static float FrontSign => frontSign;
        private static float frontSign = -1f;
        private static MeshRenderer apcRenderer;

        internal static void Install(Structure cabinet)
        {
            var oldRenderers = cabinet.GetComponentsInChildren<Renderer>(true);
            var apc = WorldManager.Instance.SourcePrefabs.OfType<AreaPowerControl>()
                .FirstOrDefault(p => p.PaintableMaterial != null);
            apcRenderer = apc == null ? null : apc.GetComponentsInChildren<MeshRenderer>(true).FirstOrDefault();
            if (apc != null && Mathf.Abs(apc.Bounds.center.z) > .005f)
                frontSign = Mathf.Sign(apc.Bounds.center.z);
            Debug.Log("[Modular Switchboards] APC mounting orientation: front sign " + frontSign +
                "; APC bounds centre " + (apc == null ? "unavailable" : apc.Bounds.center.ToString()));
            CabinetWallMount.MeasureNativeWall(frontSign);
            CabinetGeometry.MapFromApc(apc);
            CabinetGeometry.EnsureLoaded();
            // Keep the tested native object/save type, replace its visual and collision geometry.
            foreach (var r in oldRenderers) Object.DestroyImmediate(r);
            foreach (var m in cabinet.GetComponentsInChildren<MeshFilter>(true)) Object.DestroyImmediate(m);
            foreach (var c in cabinet.GetComponentsInChildren<Collider>(true)) Object.DestroyImmediate(c);
            foreach (var a in cabinet.GetComponentsInChildren<Animator>(true)) Object.DestroyImmediate(a);
            if (cabinet is Locker locker)
            {
                locker.DontUseOpen = false;
                AccessTools.Field(typeof(Locker), "lockerAnimComponent")?.SetValue(locker, null);
                AccessTools.Field(typeof(Locker), "shutterMaterialAnimComponent")?.SetValue(locker, null);
            }
            cabinet.BaseAnimator = null;
            cabinet.Renderers = new List<ThingRenderer>();
            cabinet._staticColliders = new List<Collider>();
            cabinet._dynamicColliders = new List<Collider>();
            cabinet._selfColliders = new List<Collider>();
            cabinet.CustomNavMeshFilter = null;
            cabinet.structureRenderMode = StructureRenderMode.Standard;
            cabinet.PlacementType = PlacementSnap.FaceMount;
            cabinet.AllowedRotations = AllowedRotations.Wall;
            cabinet.RotationAxis = RotationAxis.Z;
            cabinet.GridSize = SmallGrid.SmallGridSize;
            // GridCenter adds half a cell internally. The native small-grid offset cancels
            // that half-cell shift so the back-plane origin can lie on a wall face.
            cabinet.GridOffset = SmallGrid.SmallGridOffset;
            // Locker prefabs can override GridSize/GridOffset with private per-axis snapping.
            // FaceMount needs the cabinet origin on the wall plane, not the locker grid offset.
            var axisSnap = AccessTools.Field(typeof(Structure), "_useAxisIndependentGridSnapping");
            var requiresFrame = AccessTools.Field(typeof(SmallGrid), "requiresFrame");
            if (axisSnap == null || requiresFrame == null)
                throw new MissingFieldException("Native mount configuration changed.");
            axisSnap.SetValue(cabinet, false);
            requiresFrame.SetValue(cabinet, false);
            cabinet.BoundsGridShiftForward = cabinet.BoundsGridShiftSide = 0f;
            cabinet.BoundsGridAddHeight = cabinet.BoundsGridAddBottom = 0f;
            cabinet.BoundsGridExtraHeight = cabinet.BoundsGridExtraWidth = 0f;
            cabinet.BoundsGridExtraForward = cabinet.BoundsForward = 0f;
            if (cabinet is SmallGrid smallGrid) smallGrid.DualRegister = false;
            Debug.Log("[Modular Switchboards] Wall mount reset: native small grid (0.5 m, offset 0.25 m), wall/frame support.");
            cabinet.SelectionDisplay = SelectionHighlightMethod.Bounds;
            cabinet.UseCellPosition = false;
            cabinet.ForceGridBounds.Clear();
            cabinet.HasColorState = false;
            cabinet.MPBRenderers.Clear();
            cabinet.CustomColor = GameManager.GetColorSwatch((int)ColorType.White);
            cabinet.PaintableMaterial = cabinet.CustomColor.Normal;
            if (apc != null) cabinet.SmoothnessIndex = apc.SmoothnessIndex;
            Debug.Log("[Modular Switchboards] APC paint style: " + (apc == null ? "native color palette" : apc.PrefabName));

            var open = cabinet.Interactables.FirstOrDefault(i => i.Action == InteractableType.Open);
            if (open == null) throw new InvalidOperationException("Native cabinet has no Open interaction.");
            open.Animator = null; open.FakeCollider = null;
            open.CanKeyInteract = true;
            cabinet.Interactables = new List<Interactable> { open };

            var model = Child(cabinet.transform, "SwitchboardModel", cabinet.gameObject.layer);
            model.localPosition = new Vector3(0f, 0f, frontSign * MountOffset);
            model.localRotation = frontSign < 0f ? Quaternion.Euler(0f, 180f, 0f) : Quaternion.identity;
            var frame = Renderer(model, "Frame", CabinetGeometry.Meshes[0], CabinetGeometry.Materials);
            CabinetMatteSurface.Apply(frame);
            var shell = Child(model, "CompletedShell", cabinet.gameObject.layer);
            shell.localPosition = Vector3.zero;
            var housing = Renderer(shell, "Housing", CabinetGeometry.Meshes[1], CabinetGeometry.Materials);
            CabinetRearSurface.Restore(housing);CabinetMatteSurface.Apply(housing);
            var interior = Renderer(shell, "Interior", CabinetGeometry.Meshes[2], CabinetGeometry.Materials);
            CabinetMatteSurface.Apply(interior);
            // Door back starts at z=.185, housing ends at .180: overlap the joint
            // with an internal return lip so an oblique view cannot see inside.
            var seal=Renderer(shell,"DoorReturnLip",DoorReturnLip(),CabinetGeometry.Materials);
            CabinetMatteSurface.Apply(seal);
            var hinge = Child(shell, "DoorHinge", cabinet.gameObject.layer);
            hinge.localPosition = new Vector3(-.20f, 0f, .187f);
            var doorRenderer=Renderer(hinge, "Door", CabinetGeometry.Meshes[3], CabinetGeometry.Materials);CabinetMatteSurface.Apply(doorRenderer);
            ApcWarning.Install(apc, hinge);
            var doorCollider = SurfaceCollider(hinge, "DoorCollider", CabinetGeometry.Meshes[3]);
            // Separate the precise physical door mesh from the easy-to-hit handle interaction.
            var handleHit=Box(hinge,"DoorHandleInteraction",Vector3.zero,new Vector3(.025f,.073f,.036f));
            handleHit.transform.localPosition=new Vector3(.37f,-.06f,.026f);
            open.Collider=handleHit;
            open.Bounds=new Bounds(Vector3.zero,handleHit.size);
            var frameColliders = new List<Collider>
            {
                Box(model,"FrameLeft",new Vector3(-.185f,0f,.015f),new Vector3(.02f,.48f,.03f)),
                Box(model,"FrameRight",new Vector3(.185f,0f,.015f),new Vector3(.02f,.48f,.03f)),
                Box(model,"FrameTop",new Vector3(0f,.23f,.015f),new Vector3(.35f,.02f,.03f)),
                Box(model,"FrameBottom",new Vector3(0f,-.23f,.015f),new Vector3(.35f,.02f,.03f))
            };
            var colliders = new List<Collider>
            {
                SurfaceCollider(shell, "RoundedHousingCollider", CabinetGeometry.Meshes[1]),
                doorCollider, handleHit
            };
            var renderers = new[] { frame, housing };
            var drawField = AccessTools.Field(typeof(BuildState), "initialDrawData");
            if (drawField == null) throw new MissingFieldException("BuildState.initialDrawData");
            for (int i = 0; i < cabinet.BuildStates.Count; i++)
            {
                var state = cabinet.BuildStates[i];
                state.Visualizer = renderers[i];
                state.RendererInstance = null;
                state.RenderMode = BuildStateRenderMode.OnMyState;
                state.StateMeshes = new List<Mesh>();
                state.LinkedGameObjects = i == 1 ? new List<GameObject> { shell.gameObject } : new List<GameObject>();
                state.Colliders = new List<Collider>(i == 0 ? frameColliders : colliders);
                state.Interactables = i == 1 ? new List<Interactable> { open } : new List<Interactable>();
                state.Thumbnail = CabinetIcons.Get(i == 0 ? "Frame" : "Cabinet");
                state.BlockAir = false; state.AlwaysBlockAir = false;
                state.BlockGravity = false; state.BlockLight = false;
                drawField.SetValue(state, new DrawData { mesh = null, materials = new Material[0] });
            }
            // Damaged stock locker meshes would not match the replacement geometry.
            cabinet.BrokenBuildStates = new List<BrokenBuildState>();
            var door = cabinet.gameObject.AddComponent<CabinetDoor>();
            door.Owner = cabinet; door.Hinge = hinge;

            // Keep the preview external to the cabinet hierarchy. Native cursor setup destroys
            // the cabinet renderers before instantiating this independent blueprint.
            var blueprint = Child(cabinet.transform.parent, "SwitchboardBlueprint", cabinet.gameObject.layer);
            var combine = new List<CombineInstance>();
            foreach (int meshIndex in new[] { 0 })
                for (int m = 0; m < CabinetGeometry.Meshes[meshIndex].subMeshCount; m++)
                    if (CabinetGeometry.Meshes[meshIndex].GetIndexCount(m) != 0)
                        combine.Add(new CombineInstance
                        {
                            mesh = CabinetGeometry.Meshes[meshIndex], subMeshIndex = m,
                            transform = Matrix4x4.TRS(model.localPosition, model.localRotation, Vector3.one) *
                                (meshIndex == 3 ? Matrix4x4.Translate(hinge.localPosition) : Matrix4x4.identity)
                        });
            var ghostMesh = new Mesh { name = "Switchboards.ClosedBlueprint" };
            ghostMesh.CombineMeshes(combine.ToArray(), true, true);
            ghostMesh.RecalculateBounds();
            var ghostRenderer = blueprint.gameObject.AddComponent<MeshRenderer>();
            ghostRenderer.sharedMaterial = new Material(CabinetGeometry.Materials[0]);
            var ghostFilter = blueprint.gameObject.AddComponent<MeshFilter>(); ghostFilter.sharedMesh = ghostMesh;
            var wireframe = blueprint.gameObject.AddComponent<Wireframe>();
            wireframe.BlueprintTransform = blueprint;
            wireframe.BlueprintBounds = ghostMesh.bounds;
            wireframe.BlueprintMeshFilter = ghostFilter;
            wireframe.BlueprintRenderer = ghostRenderer;
            blueprint.gameObject.AddComponent<CabinetBlueprint>();
            cabinet.Blueprint = blueprint.gameObject;
            cabinet.BlueprintOrientVector = Vector3.zero;
            cabinet.Thumbnail = CabinetIcons.Get("Cabinet");
            cabinet.Thumbnails = new Sprite[0];
            cabinet.gameObject.AddComponent<CabinetWallFit>();
            SetBounds(cabinet);
            Debug.Log("[Modular Switchboards] Native APC mapped cabinet: bare mounting frame then sheet housing; dedicated state thumbnails.");
        }

        // Called from a narrowly scoped bounds prefix, including construction preview copies.
        internal static void SetBounds(Structure cabinet)
        {
            cabinet.ThingTransform = cabinet.transform;
            var rotation=frontSign<0f?Quaternion.Euler(0f,180f,0f):Quaternion.identity;
            var modelTransform=cabinet.transform.Find("SwitchboardModel");
            float offset=modelTransform==null?MountOffset:frontSign*modelTransform.localPosition.z;
            var model=Matrix4x4.TRS(new Vector3(0f,CabinetShape.OffsetY(cabinet.PrefabName),frontSign*offset),rotation,Vector3.one);
            var bounds=CabinetWallMount.TransformedBounds(CabinetGeometry.Meshes[0].bounds,model);
            for(int i=1;i<CabinetGeometry.Meshes.Length;i++)
            {
                var matrix=model*(i==3?Matrix4x4.Translate(new Vector3(-.20f,0f,.187f)):Matrix4x4.identity);
                bounds.Encapsulate(CabinetWallMount.TransformedBounds(CabinetGeometry.Meshes[i].bounds,matrix));
            }
            if(CabinetShape.Medium(cabinet.PrefabName))
                bounds=CabinetWallMount.TransformedBounds(new Bounds(new Vector3(0,0,.06f),new Vector3(.8f,1f,.4f)),model);
            ExternalCablePorts.IncludeBounds(cabinet,ref bounds);
            NativeRearBox.IncludeBounds(cabinet,ref bounds);
            OvenInputPanel.IncludeBounds(cabinet,ref bounds);
            OvenInputSupport.IncludeBounds(cabinet,ref bounds);
            CabinetPowerOutputs.IncludeBounds(cabinet,ref bounds);
            cabinet.Bounds=bounds;
            cabinet.SurfaceArea = 2f * (CabinetShape.Width(cabinet.PrefabName)*CabinetShape.Height(cabinet.PrefabName)+CabinetShape.Height(cabinet.PrefabName)*.18f+.18f*CabinetShape.Width(cabinet.PrefabName));
            cabinet.GridBounds = new GridBounds(cabinet);
        }

        private static Transform Child(Transform parent, string name, int layer)
        {
            var obj = new GameObject(name) { layer = layer };
            obj.transform.SetParent(parent, false);
            return obj.transform;
        }

        private static MeshRenderer Renderer(Transform parent, string name, Mesh mesh, Material[] materials)
        {
            var obj = Child(parent, name, parent.gameObject.layer).gameObject;
            obj.AddComponent<MeshFilter>().sharedMesh = mesh;
            var renderer = obj.AddComponent<MeshRenderer>(); renderer.sharedMaterials = materials;
            renderer.lightProbeUsage = apcRenderer == null ? LightProbeUsage.BlendProbes : apcRenderer.lightProbeUsage;
            renderer.reflectionProbeUsage = apcRenderer == null ? ReflectionProbeUsage.BlendProbes : apcRenderer.reflectionProbeUsage;
            renderer.shadowCastingMode = apcRenderer == null ? ShadowCastingMode.On : apcRenderer.shadowCastingMode;
            renderer.receiveShadows = apcRenderer == null || apcRenderer.receiveShadows;
            renderer.probeAnchor = obj.transform;
            return renderer;
        }

        internal static Mesh DoorReturnLip()
        {
            var vertices=new List<Vector3>();var triangles=new List<int>();
            const int steps=12, count=4*(steps+1);
            // Closed rounded return: continuous through all four corners.
            for(int ring=0;ring<4;ring++)
            {
                bool inside=ring>=2;float radius=inside?.006f:.016f;
                float depth=(ring%2==0)?.174f:.190f;
                for(int corner=0;corner<4;corner++)
                    for(int step=0;step<=steps;step++)
                    {
                        float angle=(corner*90f+step*90f/steps)*Mathf.Deg2Rad;
                        float cx=(corner==0||corner==3)?.180f:-.180f;
                        float cy=corner<2?.230f:-.230f;
                        vertices.Add(new Vector3(cx+radius*Mathf.Cos(angle),cy+radius*Mathf.Sin(angle),depth));
                    }
            }
            for(int i=0;i<count;i++)
            {
                int j=(i+1)%count;
                LipQuad(triangles,i,count+i,count+j,j);
                LipQuad(triangles,2*count+i,2*count+j,3*count+j,3*count+i);
                LipQuad(triangles,i,j,2*count+j,2*count+i);
                LipQuad(triangles,count+i,3*count+i,3*count+j,count+j);
            }
            var mesh=new Mesh{name="Switchboards.DoorReturnLip"};mesh.SetVertices(vertices);mesh.subMeshCount=5;
            for(int i=0;i<5;i++)mesh.SetTriangles(i==0?triangles.ToArray():new int[0],i);
            mesh.RecalculateNormals();CabinetGeometry.ApplyNativeUv(mesh);mesh.RecalculateBounds();return mesh;
        }

        private static void LipQuad(List<int> triangles,int a,int b,int c,int d)
        {
            triangles.AddRange(new[]{a,c,b,a,d,c});
        }

        private static MeshCollider SurfaceCollider(Transform parent,string name,Mesh mesh)
        {
            var obj=Child(parent,name,parent.gameObject.layer).gameObject;
            var collider=obj.AddComponent<MeshCollider>();collider.sharedMesh=mesh;collider.convex=false;
            return collider;
        }

        private static BoxCollider Box(Transform parent, string name, Vector3 center, Vector3 size)
        {
            var obj = Child(parent, name, parent.gameObject.layer).gameObject;
            var collider = obj.AddComponent<BoxCollider>(); collider.center = center; collider.size = size;
            return collider;
        }
    }
}
