using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Serialization;

namespace ModularSwitchboards
{
    public sealed class CabinetWireEnd : IEquatable<CabinetWireEnd>
    {
        [XmlAttribute] public long Owner;
        [XmlAttribute] public int Contact;
        public CabinetWireEnd(){}
        public CabinetWireEnd(long owner,int contact){Owner=owner;Contact=contact;}
        public bool Equals(CabinetWireEnd other)=>other!=null&&Owner==other.Owner&&Contact==other.Contact;
        public override bool Equals(object obj)=>Equals(obj as CabinetWireEnd);
        public override int GetHashCode()=>Owner.GetHashCode()*397^Contact;
        public bool IsNeutral=>Owner!=0&&(Contact==2||Contact==3);
        public bool IsSource=>Owner==0?(Contact==0||Contact==4||Contact==6):Contact%2==1;
        public int Capacity=>IsNeutral?1:Owner==0&&IsSource?16:Owner!=0&&Contact%2==1?3:1;
        public override string ToString()=>IsNeutral?"Bridge "+(Contact==2?"plate":"door"):Owner==0?(Contact==4?"Input 2":Contact==6?"Input 3":new[]{"Input","Output 1","Output 2","Output 3"}[Contact]):"Module "+(Contact==0?"IN (top)":"OUT (bottom)");
    }
    public enum CabinetWireKind { Normal=0,Heavy=1,SuperHeavy=2 }
    internal static class CabinetWireKinds
    {
        internal static bool Valid(CabinetWireKind kind)=>kind>=CabinetWireKind.Normal&&kind<=CabinetWireKind.SuperHeavy;
        // Actual visual radii; routing reserves the largest envelope for every type.
        internal static float Radius(CabinetWireKind kind)=>kind==CabinetWireKind.SuperHeavy?.004f:kind==CabinetWireKind.Heavy?.0022f:.0012f;
        internal static string Title(CabinetWireKind kind)=>kind==CabinetWireKind.SuperHeavy?"Super Heavy":kind==CabinetWireKind.Heavy?"Heavy":"Normal";
    }
    public sealed class CabinetWireSaveData
    {
        [XmlElement] public CabinetWireEnd From,To;
        internal long PowerId;
        [XmlAttribute] public bool Burnt; // Permanently open; cutters return no coil.
        [XmlAttribute] public int InputSlot;
        [XmlAttribute] public int RouteVersion;
        [XmlAttribute] public int CableUnits=1;
        [XmlAttribute] public CabinetWireKind CableKind; // Missing in legacy saves means Normal.
        [XmlAttribute] public int ColorIndex=-1; // Legacy/default wires use native red.
        [XmlArray] public float[] Points;
    }
    internal static class WireCircuit
    {
        internal static IEnumerable<CabinetWireSaveData> Through(IEnumerable<CabinetWireSaveData> wires,IEnumerable<long> passages)
            =>wires.Concat((passages??Enumerable.Empty<long>()).SelectMany(id=>new[]{new CabinetWireSaveData{From=new CabinetWireEnd(id,2),To=new CabinetWireEnd(id,3)},new CabinetWireSaveData{From=new CabinetWireEnd(id,3),To=new CabinetWireEnd(id,2)}}));
        internal static bool Reachable(CabinetWireEnd from,CabinetWireEnd to,IEnumerable<CabinetWireSaveData> wires,IEnumerable<long> closedBreakers)
        {
            var edges=new Dictionary<CabinetWireEnd,List<CabinetWireEnd>>();
            Action<CabinetWireEnd,CabinetWireEnd> add=(a,b)=>{if(!edges.TryGetValue(a,out var list))edges[a]=list=new List<CabinetWireEnd>();list.Add(b);};
            foreach(var wire in wires.Where(w=>!w.Burnt)){add(wire.From,wire.To);if(wire.From.IsNeutral&&wire.To.IsNeutral)add(wire.To,wire.From);}
            foreach(var breaker in closedBreakers)add(new CabinetWireEnd(breaker,0),new CabinetWireEnd(breaker,1));
            var seen=new HashSet<CabinetWireEnd>();var queue=new Queue<CabinetWireEnd>();queue.Enqueue(from);
            while(queue.Count>0){var n=queue.Dequeue();if(!seen.Add(n))continue;if(n.Equals(to))return true;if(edges.TryGetValue(n,out var list))foreach(var next in list)queue.Enqueue(next);}return false;
        }
        internal static bool CanConnect(CabinetWireEnd a,CabinetWireEnd b,IList<CabinetWireSaveData> wires,IEnumerable<long> breakers,out string reason,bool allowLegacyBypass=false,Func<CabinetWireEnd,int> capacity=null,IEnumerable<long> passages=null,IEnumerable<long> normallyClosed=null)
        {
            reason=null;
            if(a==null||b==null||a.Equals(b)){reason="Choose two different contacts.";return false;}
            if(!a.IsNeutral&&!b.IsNeutral&&a.IsSource==b.IsSource){reason="Connect a supply contact to an input contact.";return false;}
            Orient(a,b,out var from,out var to);
            if(!allowLegacyBypass&&from.Owner==0&&to.Owner==0){reason="Connect Input to a module's top contact first.";return false;}
            if(from.Owner!=0&&from.Owner==to.Owner){reason="Cannot wire a module back into itself.";return false;}
            foreach(var e in new[]{a,b})if(wires.Count(w=>w.From.Equals(e)||w.To.Equals(e))>=(capacity==null?e.Capacity:capacity(e))){reason="Contact occupied.";return false;}
            if(Reachable(to,from,Through(wires,passages).Concat((normallyClosed??Enumerable.Empty<long>()).Select(id=>new CabinetWireSaveData{From=new CabinetWireEnd(id,0),To=new CabinetWireEnd(id,5)})),breakers)){reason="This connection would create a loop.";return false;}
            return true;
        }
        internal static void Orient(CabinetWireEnd a,CabinetWireEnd b,out CabinetWireEnd from,out CabinetWireEnd to)
        {
            if(a.IsNeutral&&b.IsNeutral){from=a;to=b;}
            else if(a.IsNeutral){from=b.IsSource?b:a;to=b.IsSource?a:b;}
            else if(b.IsNeutral){from=a.IsSource?a:b;to=a.IsSource?b:a;}
            else{from=a.IsSource?a:b;to=a.IsSource?b:a;}
        }
        // Share one native input budget. A second output must not advertise it a second time.
        internal static float[] Allocate(float available,float firstDemand,float secondDemand,bool first,bool second)
        {
            available=Finite(available);firstDemand=Finite(firstDemand);secondDemand=Finite(secondDemand);
            if(!first&&!second)return new float[2];if(!first)return new[]{0f,available};if(!second)return new[]{available,0f};
            float total=firstDemand+secondDemand;if(total<=0)return new[]{available*.5f,available*.5f};
            float one=available*(firstDemand/total);return new[]{one,available-one};
        }
        internal static float[] Allocate(float available,float[] demands,bool[] active)
        {
            available=Finite(available);var result=new float[demands.Length];var ids=Enumerable.Range(0,demands.Length).Where(i=>active[i]).ToArray();if(ids.Length==0)return result;
            double total=ids.Sum(i=>(double)Finite(demands[i]));float remaining=available;
            for(int k=0;k<ids.Length;k++){int i=ids[k];result[i]=k==ids.Length-1?remaining:Math.Min(remaining,total<=0?available/ids.Length:(float)(available*(Finite(demands[i])/total)));remaining-=result[i];}return result;
        }
        // Cover current demand first, then share unused supply between live branches.
        // A zero-demand branch needs advertised headroom to start a newly switched load.
        internal static float[] AllocateSupply(float available,float[] demands,bool[] active)
        {
            available=Finite(available);var ids=Enumerable.Range(0,demands.Length).Where(i=>active[i]).ToArray();
            double demand=ids.Sum(i=>(double)Finite(demands[i]));
            if(ids.Length<2||demand>=available)return Allocate(available,demands,active);
            var result=new float[demands.Length];float spare=(float)(available-demand),remaining=available;
            for(int k=0;k<ids.Length;k++)
            {
                int i=ids[k];result[i]=k==ids.Length-1?remaining:Math.Min(remaining,Finite(demands[i])+spare/ids.Length);remaining-=result[i];
            }
            return result;
        }
        internal static float Finite(float value)=>float.IsNaN(value)||float.IsInfinity(value)?0:Math.Max(0,value);
    }
}
