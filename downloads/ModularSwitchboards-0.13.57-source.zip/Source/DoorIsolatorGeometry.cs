using System.Collections.Generic;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class DoorIsolatorGeometry
    {
        internal static Mesh Dish()
        {
            // Closed radial section: back plate, raised rim, sloping recessed face.
            var r=new[]{0f,.027f,.0295f,.0295f,.0275f,.0255f,.024f,0f};
            var z=new[]{.006f,.006f,.009f,.019f,.021f,.018f,.012f,.009f};
            var v=new List<Vector3>();var n=new List<Vector3>();var t=new List<int>();
            for(int j=0;j<r.Length-1;j++)
            {
                float dr=r[j+1]-r[j],dz=z[j+1]-z[j],length=(float)System.Math.Sqrt(dr*dr+dz*dz);
                for(int i=0;i<32;i++)
                {
                    float a=i*Mathf.PI/16,b=(i+1)*Mathf.PI/16;
                    var na=new Vector3(dz/length*Mathf.Cos(a),dz/length*Mathf.Sin(a),-dr/length);
                    var nb=new Vector3(dz/length*Mathf.Cos(b),dz/length*Mathf.Sin(b),-dr/length);
                    int p=v.Count;
                    v.AddRange(new[]{new Vector3(r[j]*Mathf.Cos(a),r[j]*Mathf.Sin(a),Notch(r[j],z[j],a)),new Vector3(r[j]*Mathf.Cos(b),r[j]*Mathf.Sin(b),Notch(r[j],z[j],b)),new Vector3(r[j+1]*Mathf.Cos(b),r[j+1]*Mathf.Sin(b),Notch(r[j+1],z[j+1],b)),new Vector3(r[j+1]*Mathf.Cos(a),r[j+1]*Mathf.Sin(a),Notch(r[j+1],z[j+1],a))});
                    n.AddRange(new[]{na,nb,nb,na});
                    // Winding follows the radial section outward.
                    if(r[j]!=0)t.AddRange(new[]{p,p+1,p+2});
                    if(r[j+1]!=0)t.AddRange(new[]{p,p+2,p+3});
                }
            }
            var flatV=new List<Vector3>();var flatN=new List<Vector3>();var flatT=new List<int>();
            for(int k=0;k<t.Count;k+=3)
            {
                var a=v[t[k]];var b=v[t[k+1]];var c=v[t[k+2]];
                float ux=b.x-a.x,uy=b.y-a.y,uz=b.z-a.z,vx=c.x-a.x,vy=c.y-a.y,vz=c.z-a.z;
                var normal=new Vector3(uy*vz-uz*vy,uz*vx-ux*vz,ux*vy-uy*vx);float len=(float)System.Math.Sqrt(normal.x*normal.x+normal.y*normal.y+normal.z*normal.z);
                normal=new Vector3(normal.x/len,normal.y/len,normal.z/len);int offset=flatV.Count;
                flatV.AddRange(new[]{a,b,c});flatN.AddRange(new[]{normal,normal,normal});flatT.AddRange(new[]{offset,offset+1,offset+2});
            }
            return Finish("Rotary isolator recessed dish",flatV,flatN,flatT);
        }
        // Lower the rim at top and left to expose the fixed white 0/I inserts.
        private static float Notch(float radius,float depth,float angle)
            =>radius>=.024f&&(Mathf.Sin(angle)>.98f||-Mathf.Cos(angle)>.98f)&&depth>.014f?.014f:depth;
        internal static Mesh Grip()
        {
            // Asymmetric pointed handle, with a long lower grip and bevelled face.
            var x=new[]{0f,-.007f,-.006f,-.0045f,.0045f,.006f,.007f};
            var y=new[]{.023f,.011f,-.010f,-.027f,-.027f,-.010f,.011f};
            var v=new List<Vector3>();var n=new List<Vector3>();var t=new List<int>();
            System.Action<Vector3,Vector3,Vector3> tri=(a,b,c)=>{
                float ux=b.x-a.x,uy=b.y-a.y,uz=b.z-a.z,vx=c.x-a.x,vy=c.y-a.y,vz=c.z-a.z;
                var normal=new Vector3(uy*vz-uz*vy,uz*vx-ux*vz,ux*vy-uy*vx);float len=(float)System.Math.Sqrt(normal.x*normal.x+normal.y*normal.y+normal.z*normal.z);
                normal=new Vector3(normal.x/len,normal.y/len,normal.z/len);int p=v.Count;v.AddRange(new[]{a,b,c});n.AddRange(new[]{normal,normal,normal});t.AddRange(new[]{p,p+1,p+2});};
            for(int i=0;i<x.Length;i++)
            {
                int j=(i+1)%x.Length;
                var a=new Vector3(x[i],y[i],.012f);var b=new Vector3(x[j],y[j],.012f);
                var c=new Vector3(x[j],y[j],.029f);var d=new Vector3(x[i],y[i],.029f);
                var e=new Vector3(x[j]*.75f,y[j]*.95f,.034f);var f=new Vector3(x[i]*.75f,y[i]*.95f,.034f);
                tri(a,b,c);tri(a,c,d);tri(d,c,e);tri(d,e,f);
                tri(new Vector3(0,0,.034f),f,e);tri(new Vector3(0,0,.012f),b,a);
            }
            return Finish("Rotary isolator bevelled pointer grip",v,n,t);
        }
        private static Mesh Finish(string name,List<Vector3> v,List<Vector3> n,List<int> t)
        {var mesh=new Mesh{name=name};mesh.SetVertices(v);mesh.SetNormals(n);mesh.SetTriangles(t,0);mesh.RecalculateBounds();return mesh;}
    }
}
