using System.Linq;
using Assets.Scripts.Objects;
using UnityEngine;
using Rendering;
using Assets.Scripts.UI;

namespace ModularSwitchboards
{
    internal static class DinModuleAccess
    {
        internal static bool CanEnter(Thing __instance,Slot destinationSlot,ref CanEnterResult __result)
        {
            if(!(destinationSlot?.Parent is DinBreaker module)||!module.IsFuseHolder)return true;
            if((!LibConstruct.PlacementBoard.Loading&&(module.Tripped||!(module.Board?.PrimaryHost is DinRail rail)||!rail.CanFitModules))||!(__instance is MultiConstructor kit)||kit.Quantity!=1||!module.AllowedFuseKits.Contains(kit.PrefabHash))
            {__result=CanEnterResult.Fail("Open the cabinet and insert one unit of the matching Cable Fuse kit.");return false;}
            return true;
        }
        internal static void Install(DinBreaker module)
        {
            var model=module.transform.Find("DinBreakerModel");
            if(module.IsFuseHolder)
            {
                var view=module.GetComponent<BreakerSwitchView>();if(view!=null)Object.DestroyImmediate(view);
                var lever=model.Find("BreakerLever");if(lever!=null)Object.DestroyImmediate(lever.gameObject);
                var control=model.Find("BreakerControl");var hit=control.GetComponent<BoxCollider>();
                var indicator=model.Find("BreakerIndicator");if(indicator!=null)Object.DestroyImmediate(indicator.gameObject);
                model.GetComponent<MeshFilter>().sharedMesh=DinFuseModel.Housing();
                var intact=new GameObject("IntactFuse"){layer=module.gameObject.layer};intact.transform.SetParent(model,false);
                intact.AddComponent<MeshFilter>().sharedMesh=DinFuseModel.Cartridge(false);intact.AddComponent<MeshRenderer>().sharedMaterials=CabinetGeometry.Materials;intact.SetActive(false);
                var burnt=new GameObject("BurntFuse"){layer=module.gameObject.layer};burnt.transform.SetParent(model,false);
                burnt.AddComponent<MeshFilter>().sharedMesh=DinFuseModel.Cartridge(true);burnt.AddComponent<MeshRenderer>().sharedMaterials=CabinetGeometry.Materials;burnt.SetActive(false);
                var fuseView=module.gameObject.AddComponent<DinFuseView>();fuseView.Owner=module;fuseView.Intact=intact;fuseView.Burnt=burnt;
                var ghost=module.Blueprint.GetComponent<MeshFilter>().sharedMesh;
                var pieces=new System.Collections.Generic.List<CombineInstance>();var body=model.GetComponent<MeshFilter>().sharedMesh;
                foreach(int role in new[]{1,3,4})pieces.Add(new CombineInstance{mesh=body,subMeshIndex=role,transform=Matrix4x4.Scale(model.localScale)});
                ghost.Clear();ghost.CombineMeshes(pieces.ToArray(),true,true);ghost.RecalculateBounds();
                var wire=module.Blueprint.GetComponent<Wireframe>();wire.BlueprintBounds=ghost.bounds;
                var toggle=new Interactable{Parent=module,Action=InteractableType.Slot1,Collider=hit,JoinInProgressSync=true,CanKeyInteract=true,KeyMap="PrimaryAction"};
                var location=new GameObject("FuseContents").transform;location.SetParent(model,false);location.localPosition=new Vector3(0,0,.07f);
                module.Slots=new System.Collections.Generic.List<Slot>{new Slot{Parent=module,StringKey="Cable Fuse",Type=Slot.Class.None,SpecificTypePrefabHashes=module.AllowedFuseKits,
                    Location=location,HidesOccupant=true,IsSwappable=false,Action=InteractableType.Slot1,Collider=hit,Interactable=toggle}};
                module.Interactables=new System.Collections.Generic.List<Interactable>{toggle};module.HasOnOffState=false;
                module.BuildStates[0].Interactables=new System.Collections.Generic.List<Interactable>{toggle};
            }
            var labelObject=new GameObject("ModuleRating"){layer=module.gameObject.layer};labelObject.transform.SetParent(model,false);
            labelObject.transform.localPosition=new Vector3(0,-.0238f,module.IsFuseHolder?.0613f:.0633f);labelObject.transform.localRotation=Quaternion.Euler(0,180,0);
            Font font=null;foreach(var name in new[]{"LegacyRuntime.ttf","Arial.ttf"}){try{font=Resources.GetBuiltinResource<Font>(name);}catch(System.Exception){}if(font!=null)break;}
            if(font==null)font=Resources.FindObjectsOfTypeAll<Font>().FirstOrDefault();
            if(font==null){Object.DestroyImmediate(labelObject);return;}
            labelObject.tag="ExcludeFromBounds";
            var text=labelObject.AddComponent<TextMesh>();text.font=font;text.text="";text.fontSize=96;text.characterSize=.01f;labelObject.transform.localScale=Vector3.one*.25f;
            text.anchor=TextAnchor.MiddleCenter;text.alignment=TextAlignment.Center;text.color=Color.black;
            labelObject.GetComponent<MeshRenderer>().sharedMaterial=text.font.material;
            var label=module.gameObject.AddComponent<DinModuleLabel>();label.Owner=module;label.Text=text;
        }
    }
    public sealed class DinModuleLabel:MonoBehaviour
    {
        public DinBreaker Owner;public TextMesh Text;
        private string previous;
        private void LateUpdate()
        {
            if(Owner==null||Text==null)return;
            string value=DinModuleCatalog.Rating(Owner.RatedWatts);
            if(value!=previous){Text.text=value;previous=value;}
            // TextMesh can rebuild its glyph mesh after LateUpdate. Fit from real
            // bounds every frame, never enlarge an initially empty text mesh.
            var bounds=Text.GetComponent<MeshRenderer>().localBounds.size;
            if(bounds.x>.00001f&&bounds.y>.00001f)Text.transform.localScale=Vector3.one*Mathf.Min(.015f/bounds.x,.0025f/bounds.y);
            var cabinet=CabinetWiring.CabinetOf(Owner);var renderer=Text.GetComponent<MeshRenderer>();
            bool visible=!Owner.IsCursor&&cabinet!=null&&cabinet.IsOpen;var camera=Camera.main;
            if(visible&&camera!=null){var delta=Text.transform.position-camera.transform.position;visible=Vector3.Dot(Owner.transform.forward,-delta)>0&&!Physics.RaycastAll(camera.transform.position,delta.normalized,delta.magnitude-.0001f,Physics.DefaultRaycastLayers,QueryTriggerInteraction.Ignore).Any(hit=>hit.collider.GetComponentInParent<DinBreaker>()!=Owner);}
            renderer.enabled=visible;
            var indicator=Owner.transform.Find("DinBreakerModel/BreakerIndicator")?.GetComponent<MeshRenderer>();
            if(indicator!=null){var block=new MaterialPropertyBlock();block.SetFloat(Thing.DiffuseIndexPropertyID,BreakerSwitchPose.IndicatorColor(Owner.Conducting));indicator.SetPropertyBlock(block);}
        }
    }
}
