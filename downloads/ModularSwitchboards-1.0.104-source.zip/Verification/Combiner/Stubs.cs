using System;using System.Collections.Generic;using System.Linq;
namespace UnityEngine
{
 public struct Vector3 {public float x,y,z;public Vector3(float x,float y,float z){this.x=x;this.y=y;this.z=z;}public static Vector3 up=>new(0,1,0);public static Vector3 down=>new(0,-1,0);public static Vector3 operator +(Vector3 a,Vector3 b)=>new(a.x+b.x,a.y+b.y,a.z+b.z);public static Vector3 operator -(Vector3 a)=>new(-a.x,-a.y,-a.z);public static Vector3 operator *(Vector3 a,float n)=>new(a.x*n,a.y*n,a.z*n);}
 public struct Bounds {public Vector3 center,size;public Bounds(Vector3 c,Vector3 s){center=c;size=s;}}
}
namespace Assets.Scripts.Objects
{
 public enum ConnectionRole {Input,Output,Output2,Waste}
 public class Connection {public Assets.Scripts.Objects.Electrical.Cable cable;public Assets.Scripts.Objects.Electrical.Cable GetCable()=>cable;}
}
namespace Assets.Scripts.Objects.Electrical {public class Cable {public Assets.Scripts.Networks.CableNetwork CableNetwork;}}
namespace Assets.Scripts.Objects.Pipes
{
 public class Device {public const int MaxProviderRecursionIterations=50;public long ReferenceId;public bool IsProviderToDevice(Device other,ref List<long> seen)=>false;}
}
namespace Assets.Scripts.Networks
{
 public class CableNetwork {public float PotentialLoad,RequiredLoad;public Tick PowerTick;}
 public class Tick {public List<Provider> InputOutputDevices=new();}
 public class Provider {public Assets.Scripts.Objects.Pipes.Device Device;}
}
namespace Assets.Scripts.Objects.Items {public class BatteryCell {public float PowerStored;public float Capacity=10000;public float PowerDelta=>Math.Max(0,Capacity-PowerStored);}}
namespace ModularSwitchboards
{
 using Assets.Scripts.Objects;using Assets.Scripts.Networks;using Assets.Scripts.Objects.Items;
 static class SwitchboardsMod
 {
  public const string CabinetName="StructureModularSwitchboard",ReverseCabinetName="StructureModularSwitchboardReverse",MediumCabinetName="StructureModularSwitchboardMedium",MediumReverseCabinetName="StructureModularSwitchboardMediumReverse";
  public const string SmallCombinerName="StructureModularSwitchboardCombiner",SmallCombinerReverseName="StructureModularSwitchboardCombinerReverse",MediumCombinerName="StructureModularSwitchboardMediumCombiner",MediumCombinerReverseName="StructureModularSwitchboardMediumCombinerReverse";
 }
 class CabinetPowerNode {public long ReferenceId;public bool Conducting,IsContactor,IsBatteryModule,IsTransformer,IsAnalyserModule,IsDoorPart,ServiceEnabled;public float RatedWatts,TransferLimit,OwnWatts;public BatteryCell Battery;}
 class SwitchboardCabinet
 {
  public bool IsStructureCompleted=true,IsCursor;public object GridController=new();public string PrefabName=SwitchboardsMod.SmallCombinerName;
  public readonly Dictionary<int,Connection> Feeds=new();public Connection Output1Connection;
  public IEnumerable<int> InputContacts=>CabinetPorts.InputContacts(PrefabName);public Connection InputPort(int i)=>Feeds.TryGetValue(i,out var c)?c:null;
 }
 static class CabinetCombinerTick {public static void Register(CabinetCombinerPower p){}public static void Remove(CabinetCombinerPower p){}}
}
