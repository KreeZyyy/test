using System;using System.Linq;using System.Collections.Generic;using System.IO;using System.Xml.Serialization;using ModularSwitchboards;using Assets.Scripts.Objects;using Assets.Scripts.Objects.Items;using Assets.Scripts.Objects.Electrical;using Assets.Scripts.Networks;
class Program
{
 static int n;static void Check(bool b,string why){n++;if(!b)throw new Exception(why);}static void Near(float a,float b,string why)=>Check(Math.Abs(a-b)<.02f,$"{why}: {a} vs {b}");
 static CabinetWireEnd E(long id,int pin)=>new(id,pin);static CabinetWireSaveData W(long a,int p,long b,int q)=>new(){From=E(a,p),To=E(b,q)};
 static Connection Port(CableNetwork network)=>new(){cable=new Cable{CableNetwork=network}};
 static CabinetPowerNode Node(long id,float watts=10000)=>new(){ReferenceId=id,Conducting=true,RatedWatts=watts};
 static (SwitchboardCabinet,CableNetwork,CableNetwork,CableNetwork,CabinetPowerNode[],List<CabinetWireSaveData>) Setup(bool same=false)
 {
  var a=new CableNetwork{PotentialLoad=1000};var b=same?a:new CableNetwork{PotentialLoad=2000};var output=new CableNetwork{RequiredLoad=3000};
  var host=new SwitchboardCabinet{Output1Connection=Port(output)};host.Feeds[0]=Port(a);host.Feeds[4]=Port(b);
  return(host,a,b,output,new[]{Node(10),Node(20)},new(){W(0,0,10,0),W(10,1,0,1),W(0,4,20,0),W(20,1,0,1)});
 }
 static void Mapping()
 {
  var names=new[]{SwitchboardsMod.CabinetName,SwitchboardsMod.ReverseCabinetName,SwitchboardsMod.MediumCabinetName,SwitchboardsMod.MediumReverseCabinetName,SwitchboardsMod.SmallCombinerName,SwitchboardsMod.SmallCombinerReverseName,SwitchboardsMod.MediumCombinerName,SwitchboardsMod.MediumCombinerReverseName};
  foreach(var name in names)
  {
   int branches=CabinetShape.Medium(name)?3:2;Check(CabinetShape.OutputCount(name)==branches,"physical port count");int inputs=CabinetPorts.InputCount(name);Check(inputs==(CabinetPorts.Combiner(name)?branches:1),"logical input count");
   var roles=Enumerable.Range(0,branches+1).Select(i=>i==0?CabinetPorts.SingleRole(name):CabinetPorts.BranchRole(name,i-1)).ToArray();Check(roles.Distinct().Count()==roles.Length,"roles collide");Check(roles.Count(r=>CabinetPorts.IsInputRole(name,r))==inputs,"native/logical input mapping");
   var contacts=Enumerable.Range(0,branches+1).Select(i=>CabinetPorts.SlotContact(name,i)).ToArray();Check(contacts.Distinct().Count()==contacts.Length,"contact IDs collide");Check(contacts.Count(i=>E(0,i).IsSource)==inputs,"source direction");
   foreach(int slot in Enumerable.Range(0,branches+1)){Check(CabinetPorts.ContactSlot(name,contacts[slot])==slot,"slot/contact inverse");Check(CabinetPorts.SlotLabel(name,slot).StartsWith(E(0,contacts[slot]).IsSource?"Input":"Output"),"label direction");}
   foreach(float leftSign in new[]{-1f,1f})
   {
    var cells=new HashSet<string>();var single=CabinetLayout.InputCell(name);cells.Add($"{single.x:F3}/{single.y:F3}/{single.z:F3}");
    for(int branch=0;branch<branches;branch++){var left=new UnityEngine.Vector3(leftSign,0,0);var cell=OutputPlacement.Body(name,branch,left,.5f)+OutputPlacement.Outward(name,branch,left)*.5f;Check(cells.Add($"{cell.x:F3}/{cell.y:F3}/{cell.z:F3}"),"logical I/O ports overlap cable grid cells");}
   }
   foreach(int slot in Enumerable.Range(0,branches+1))
   {
    var position=CabinetLayout.Map(name,CabinetShape.Terminal(name,slot));bool input=E(0,contacts[slot]).IsSource;float expected=(CabinetPorts.Combiner(name)?(input?-1:1):(input?1:-1))*CabinetLayout.YSign(name);Check(Math.Sign(position.y)==expected,"terminal side does not match orientation and I/O type");
   }
   Near(CabinetShape.RailWidth(name),CabinetShape.Medium(name)?.65f:.35f,"rail width");Check(CabinetLayout.YSign(name)==(name.EndsWith("Reverse")?-1:1),"reverse orientation");
  }
  Check(!WireCircuit.CanConnect(E(0,0),E(0,4),new List<CabinetWireSaveData>(),new long[0],out _),"direct IN-IN allowed");Check(!WireCircuit.CanConnect(E(0,4),E(0,1),new List<CabinetWireSaveData>(),new long[0],out _),"direct IN-OUT bypass allowed");
  var saved=new[]{W(0,4,10,0),W(0,6,20,0)};var serializer=new XmlSerializer(typeof(CabinetWireSaveData[]));using var text=new StringWriter();serializer.Serialize(text,saved);using var reader=new StringReader(text.ToString());var copy=(CabinetWireSaveData[])serializer.Deserialize(reader);Check(copy[0].From.Contact==4&&copy[1].From.Contact==6,"new source IDs fail save roundtrip");
 }
 static void Sources()
 {
  foreach(bool same in new[]{false,true})
  {
   var(h,a,b,o,nodes,wires)=Setup(same);var p=new CabinetCombinerPower();p.RefreshNodes(h,wires,nodes);Near(p.Generated(o),same?1000:3000,"independent vs shared budgets");Near(p.Generated(o),same?1000:3000,"repeat query duplicates reservation");p.Use(o,same?600:1500);Near(p.Used(a),same?600:500,"first native debt");if(!same)Near(p.Used(b),1000,"second native debt");p.Receive(a,p.Used(a));Near(p.Used(a),0,"first repayment");if(!same){Near(p.Used(b),1000,"repayment leaked across independent feeds");p.Receive(b,1000);Near(p.Used(b),0,"second repayment");}
  }
  {
   var(h,a,b,o,nodes,wires)=Setup();var p=new CabinetCombinerPower();nodes[1].Conducting=false;p.RefreshNodes(h,wires,nodes);Near(p.Generated(o),1000,"open feeder still contributes");p.ObserveIdle(o);nodes[0].Conducting=false;p.RefreshNodes(h,wires,nodes);Near(p.Generated(o),0,"all open feeds powered output");p.ObserveIdle(o);nodes[1].Conducting=true;p.RefreshNodes(h,wires,nodes);Near(p.Generated(o),2000,"second-only feed dead");
   p.Use(o,1000);Near(p.Used(a),0,"unwired input charged");Near(p.Used(b),1000,"second source debt missing");
  }
  {
   var(h,a,b,o,nodes,wires)=Setup();h.PrefabName=SwitchboardsMod.MediumCombinerName;var c=new CableNetwork{PotentialLoad=500};h.Feeds[6]=Port(c);var mods=nodes.Concat(new[]{Node(30)}).ToArray();wires.AddRange(new[]{W(0,6,30,0),W(30,1,0,1)});var p=new CabinetCombinerPower();p.RefreshNodes(h,wires,mods);Near(p.Generated(o),3500,"third input absent");p.Use(o,1750);Near(p.Used(c),250,"third input debt");
  }
  {
   var(h,a,b,o,nodes,wires)=Setup();h.Output1Connection=Port(a);var p=new CabinetCombinerPower();p.RefreshNodes(h,wires,nodes);Near(p.Generated(a),0,"external cable loop generates power");
  }
 }
 static void Protection()
 {
  var(h,a,b,o,nodes,wires)=Setup();nodes[0].RatedWatts=400;var p=new CabinetCombinerPower();p.RefreshNodes(h,wires,nodes);p.Generated(o);p.Use(o,1500);Check(p.DrainTrips().SequenceEqual(new long[]{10}),"actual per-feeder protection accounting");
  var shared=Node(50);shared.IsTransformer=true;shared.TransferLimit=1200;
  wires=new(){W(0,0,10,0),W(10,1,50,0),W(0,4,20,0),W(20,1,50,0),W(50,1,0,1)};p=new CabinetCombinerPower();p.RefreshNodes(h,wires,nodes.Concat(new[]{shared}).ToArray());Near(p.Generated(o),1200,"shared transformer cap duplicated across sources");
  p.Use(o,1200);Near(p.Used(a),600,"shared cap first contribution");Near(p.Used(b),600,"shared cap second contribution");
  // A pin may have multiple incoming wires in a synthetic topology; gameplay
  // still enforces analyzer/protector input capacity separately.
  nodes[0].IsTransformer=true;nodes[0].TransferLimit=300;p=new CabinetCombinerPower();p.RefreshNodes(h,new List<CabinetWireSaveData>(){W(0,0,10,0),W(10,1,0,1),W(0,4,20,0),W(20,1,0,1)},nodes);Near(p.Generated(o),2300,"independent transformer budget");
 }
 static void ParallelProtection()
 {
  var(h,a,b,o,nodes,wires)=Setup();h.Feeds.Remove(4);nodes[0].RatedWatts=600;nodes[1].RatedWatts=600;
  wires=new(){W(0,0,10,0),W(10,1,0,1),W(0,0,20,0),W(20,1,0,1)};var p=new CabinetCombinerPower();p.RefreshNodes(h,wires,nodes);Near(p.Generated(o),1000,"same IN parallel branches duplicate network");p.Use(o,1000);Check(p.DrainTrips().Length==0,"parallel breakers charged whole load instead of own path");Near(p.Used(a),1000,"parallel input debt not conserved");
  nodes[0].IsTransformer=true;nodes[0].TransferLimit=300;nodes[1].IsTransformer=true;nodes[1].TransferLimit=500;p=new CabinetCombinerPower();p.RefreshNodes(h,wires,nodes);Near(p.Generated(o),800,"parallel path caps collapsed into serial minimum");
  nodes[0].IsTransformer=false;nodes[0].RatedWatts=400;nodes[1].IsTransformer=false;p=new CabinetCombinerPower();p.RefreshNodes(h,wires,nodes);p.Generated(o);p.Use(o,1000);Check(p.DrainTrips().SequenceEqual(new[]{10L}),"wrong parallel protector trips");
 }
 static void Batteries()
 {
  var(h,a,b,o,nodes,wires)=Setup();var cell=new BatteryCell{PowerStored=5000};var battery=Node(40);battery.IsBatteryModule=true;battery.Battery=cell;wires.Add(W(40,1,0,1));var p=new CabinetCombinerPower();p.RefreshNodes(h,wires,nodes.Concat(new[]{battery}).ToArray());Check(p.Generated(o)>=3000,"battery offer");p.Use(o,1000);Near(cell.PowerStored,5000,"battery drained with ample external supply");Near(p.Used(a)+p.Used(b),1000,"external debt lost with battery present");
  a.PotentialLoad=0;b.PotentialLoad=0;p.ObserveIdle(o);p.RefreshNodes(h,wires,nodes.Concat(new[]{battery}).ToArray());p.Generated(o);p.Use(o,500);Near(cell.PowerStored,4500,"battery backup failed");
  // Two networks charge one cell under one aggregate native 1 kJ limit.
  a.PotentialLoad=5000;b.PotentialLoad=5000;wires.AddRange(new[]{W(10,1,40,0),W(20,1,40,0)});p=new CabinetCombinerPower();p.RefreshNodes(h,wires,nodes.Concat(new[]{battery}).ToArray());float da=p.Used(a),db=p.Used(b);Check(da+db<=1000.01f,"multi-feed charging duplicates cell rate");float before=cell.PowerStored;p.Receive(a,da);p.Receive(b,db);Near(cell.PowerStored-before,da+db,"charged energy/debt mismatch");Near(p.Used(a)+p.Used(b),0,"sequential native network ticks duplicate cell charge rate");p.BeginOwnTick();p.EndOwnTick();Check(p.Used(a)+p.Used(b)<=1000.01f,"fresh native charge cycle exceeds rate");
 }
 static void OwnAndSensors()
 {
  var(h,a,b,o,nodes,wires)=Setup();var tr=Node(50);tr.IsTransformer=true;tr.ServiceEnabled=true;tr.OwnWatts=100;tr.TransferLimit=1000;wires.Add(W(20,1,50,0));var p=new CabinetCombinerPower();p.RefreshNodes(h,wires,nodes.Concat(new[]{tr}).ToArray());p.BeginOwnTick();Near(p.Used(a),0,"standby charged disconnected input");Near(p.Used(b),100,"standby on second input");p.Receive(b,100);p.EndOwnTick();Check(p.TransformerPowered(50),"transformer standby on input2 not paid");Near(p.Used(b),0,"standby charged repeatedly");
  p.RemoveOwnTransformer(50);Check(!p.TransformerPowered(50),"removed transformer remains ready");p.StopOwnPower();Near(p.Generated(o),0,"stopped combiner still generates");
  var remove=new CabinetCombinerPower();nodes[1].RatedWatts=50;remove.RefreshNodes(h,wires,nodes.Concat(new[]{tr}).ToArray());remove.BeginOwnTick();remove.Receive(b,remove.Used(b));remove.RemoveOwnTransformer(50);Check(remove.DrainTrips().Contains(20),"paid standby lost protective load on removal");remove.EndOwnTick();remove.BeginOwnTick();Near(remove.Used(b),0,"removed transformer keeps consuming standby");remove.EndOwnTick();
  var sensor=Node(70);sensor.IsAnalyserModule=true;wires=new(){W(0,0,10,0),W(10,1,70,0),W(70,1,0,1),W(0,4,20,0),W(20,1,0,1)};var ids=new long[]{10,20,70};int result=AnalyserCircuit.Selection(70,wires,ids,new long[]{10,20},new[]{E(0,0),E(0,4)});Check(result==1,"shared analyzer should read common Output network");
  var control=new[]{W(0,4,80,0)};Check(SmartCircuit.Selection(80,control,new long[0],new long[0],inputs:new[]{E(0,0),E(0,4)})==AnalyserCircuit.Input,"Core does not recognize input2");
  var coil=new[]{W(0,6,90,2)};Check(ContactorCircuit.Resolve(coil,new long[0],new[]{90L},new long[0],false,new long[0],new[]{E(0,6)}).Contains(90),"coil cannot energize from input3");
 }
 static void Conservation()
 {
  var random=new Random(104);
  for(int iteration=0;iteration<100;iteration++)
  {
   var(h,a,b,o,nodes,wires)=Setup(iteration%3==0);a.PotentialLoad=random.Next(10,10000);if(!ReferenceEquals(a,b))b.PotentialLoad=random.Next(10,10000);
   nodes[0].Conducting=iteration%4!=0;nodes[1].Conducting=iteration%5!=0;nodes[0].RatedWatts=nodes[1].RatedWatts=100000;
   var eligible=new[]{(net:a,on:nodes[0].Conducting),(net:b,on:nodes[1].Conducting)}.Where(x=>x.on).Select(x=>x.net).Distinct().ToArray();float potential=eligible.Sum(x=>x.PotentialLoad);
   var p=new CabinetCombinerPower();p.RefreshNodes(h,wires,nodes);Near(p.Generated(o),potential,"random budget/duplicate/isolation");float consumed=potential*(float)random.NextDouble();p.Use(o,consumed);Near(new[]{a,b}.Distinct().Sum(net=>p.Used(net)),consumed,"random energy conservation");Check(p.DrainTrips().Length==0,"unused headroom trips protection");foreach(var net in new[]{a,b}.Distinct()){float used=p.Used(net);p.Receive(net,used*.5f);Near(p.Used(net),used*.5f,"random partial repayment");}
  }
  var(c,x,y,outNet,mods,physical)=Setup();var bridge=new CabinetWirePower(physical,physical,_=>100);var power=new CabinetCombinerPower();power.RefreshNodes(c,bridge.Graph,mods.Concat(bridge.Nodes).ToArray());power.Generated(outNet);power.Use(outNet,1500);Check(power.DrainTrips().Any(id=>id<0&&bridge.Wires.ContainsKey(id)),"actual overloaded internal wire not reported");
 }
 static void Main(){Mapping();Sources();Protection();ParallelProtection();Batteries();OwnAndSensors();Conservation();Console.WriteLine($"{n} production combiner checks passed: eight profiles, roles/contact/save mapping, isolated and duplicate networks, actual energy/protection, transformer caps, battery priority/charge, standby and shared analyzer/Core/coil circuits.");}
}
