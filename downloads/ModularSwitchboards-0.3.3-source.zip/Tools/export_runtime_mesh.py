import bpy,struct,math,sys
from pathlib import Path
from mathutils import Matrix,Vector
args=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else []
if not args: raise SystemExit('Usage: blender -b --python export_runtime_mesh.py -- path/to/SwitchboardCabinet.blend [output.meshbin]')
bpy.ops.wm.open_mainfile(filepath=str(Path(args[0]).resolve()))
bpy.context.scene.frame_set(1)
pivot=bpy.data.objects['Door_Hinge_PIVOT']
def is_door(obj):
 p=obj
 while p:
  if p==pivot:return True
  p=p.parent
 return False
materials=[]
for name in ['Stage_0_Housing','Stage_1_Mounting','Stage_2_Wiring']:
 for obj in bpy.data.collections[name].objects:
  if obj.type=='MESH':
   for m in obj.data.materials:
    if m not in materials:materials.append(m)
groups=[]
for stage in range(4):
 col=bpy.data.collections[['Stage_0_Housing','Stage_1_Mounting','Stage_2_Wiring','Stage_0_Housing'][stage]]
 vertices=[];normals=[];submeshes=[[] for m in materials]
 for obj in col.objects:
  if obj.type!='MESH' or (stage==0 and is_door(obj)) or (stage==3 and not is_door(obj)):continue
  mesh=obj.data;mesh.calc_loop_triangles()
  mat=obj.matrix_world if stage!=3 else pivot.matrix_world.inverted()@obj.matrix_world
  norm=mat.to_3x3().inverted().transposed()
  for tri in mesh.loop_triangles:
   mi=materials.index(obj.data.materials[tri.material_index])
   start=len(vertices)
   for li in tri.loops:
    v=mat@mesh.vertices[mesh.loops[li].vertex_index].co
    n=(norm@mesh.corner_normals[li].vector).normalized()
    vertices.append((v.x,v.z,-v.y));normals.append((n.x,n.z,-n.y))
   submeshes[mi].extend([start,start+2,start+1])
 assert len(vertices)<65535
 groups.append((vertices,normals,submeshes))
out=Path(args[1]) if len(args)>1 else Path(__file__).resolve().parent.parent/'Assets/Cabinet.meshbin'
out.parent.mkdir(parents=True,exist_ok=True)
with out.open('wb') as f:
 f.write(b'SBMS');f.write(struct.pack('<iii',1,len(materials),len(groups)))
 for m in materials:
  bs=m.node_tree.nodes.get('Principled BSDF')
  values=list(bs.inputs['Base Color'].default_value)+[bs.inputs['Metallic'].default_value,bs.inputs['Roughness'].default_value]
  f.write(struct.pack('<6f',*values))
 for vv,nn,ss in groups:
  f.write(struct.pack('<i',len(vv)))
  for v,n in zip(vv,nn):f.write(struct.pack('<6f',*(v+n)))
  for inds in ss:
   f.write(struct.pack('<i',len(inds)))
   if inds:f.write(struct.pack('<%di'%len(inds),*inds))
print('RUNTIME_MESH',out.stat().st_size,[(len(v),sum(len(x) for x in s)//3) for v,n,s in groups])
