using System.Collections.Generic;
namespace ModularSwitchboards
{
    internal static class AnalyserCircuit
    {
        // Follow the actual downstream wiring, including closed protective devices.
        // A sensor is passive: opening an upstream breaker does not disconnect its
        // downstream cable network or invent a zero reading for that network.
        internal static int Output(long id,IEnumerable<CabinetWireSaveData> wires,IEnumerable<long> closed)
        {
            var start=new CabinetWireEnd(id,1);
            return (WireCircuit.Reachable(start,new CabinetWireEnd(0,1),wires,closed)?1:0)|
                (WireCircuit.Reachable(start,new CabinetWireEnd(0,2),wires,closed)?2:0);
        }
    }
}
