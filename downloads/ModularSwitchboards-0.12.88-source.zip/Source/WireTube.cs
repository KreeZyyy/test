using System;
using System.Collections.Generic;

namespace ModularSwitchboards
{
    // Fixed-radius circular sections, transported without arbitrary frame flips.
    internal static class WireTube
    {
        private static float Length(WirePoint p)=>(float)Math.Sqrt(p.Squared);
        private static WirePoint Unit(WirePoint p)=>p*(1f/Length(p));
        private static WirePoint Cross(WirePoint a,WirePoint b)=>new WirePoint(a.Y*b.Z-a.Z*b.Y,a.Z*b.X-a.X*b.Z,a.X*b.Y-a.Y*b.X);
        internal static WirePoint[] Ring(WirePoint[] path,int index,int sides,ref WirePoint previousRight,ref WirePoint previousTangent)
        {
            var incoming=index==0?Unit(path[1]-path[0]):Unit(path[index]-path[index-1]);
            var outgoing=index==path.Length-1?incoming:Unit(path[index+1]-path[index]);
            var tangent=Unit(incoming+outgoing);
            WirePoint right;
            if(index==0)right=Unit(Cross(tangent,Math.Abs(tangent.Z)<.9f?new WirePoint(0,0,1):new WirePoint(0,1,0)));
            else
            {
                // Minimal rotation carrying the previous tangent onto this tangent.
                var axis=Cross(previousTangent,tangent);float cosine=WirePoint.Dot(previousTangent,tangent);
                right=previousRight+Cross(axis,previousRight)+Cross(axis,Cross(axis,previousRight))*(1f/Math.Max(.00001f,1f+cosine));
                right=Unit(right-tangent*WirePoint.Dot(right,tangent));
            }
            previousRight=right;previousTangent=tangent;var up=Cross(tangent,right);var ring=new WirePoint[sides];
            for(int k=0;k<sides;k++){float angle=(float)(k*Math.PI*2/sides);ring[k]=right*(float)Math.Cos(angle)+up*(float)Math.Sin(angle);}
            return ring;
        }
        internal static WirePoint[] Supports(WirePoint[] path)
        {
            // End-bisector rings must not twist an entire long straight span.
            // Add straight-tangent sections near each end; the centreline is unchanged.
            var points=new List<WirePoint>{path[0]};
            for(int i=1;i<path.Length;i++)
            {
                var delta=path[i]-path[i-1];float length=Length(delta);
                if(length>.012f){var direction=delta*(1f/length);points.Add(path[i-1]+direction*.005f);points.Add(path[i]-direction*.005f);}
                points.Add(path[i]);
            }
            return points.ToArray();
        }
        internal static WirePoint[] Clean(WirePoint[] path,Func<WirePoint,WirePoint,bool> clear)
        {
            var points=new List<WirePoint>(path);bool changed=true;
            while(changed)
            {
                changed=false;
                for(int i=1;i<points.Count-1;i++)
                {
                    var a=points[i]-points[i-1];var b=points[i+1]-points[i];
                    bool collinear=Cross(a,b).Squared<1e-14f&&WirePoint.Dot(a,b)>=0;
                    // Eliminate sub-grid connector jogs, preserving the normal
                    // departure and arrival directions at the physical contacts.
                    bool tiny=i>1&&i<points.Count-2&&Math.Min(a.Squared,b.Squared)<.002f*.002f;
                    if((collinear||tiny)&&clear(points[i-1],points[i+1])){points.RemoveAt(i);changed=true;break;}
                }
            }
            return points.ToArray();
        }
        internal static WirePoint[] Round(WirePoint[] path,float maximumCut)
        {
            var result=new List<WirePoint>{path[0]};
            for(int i=1;i<path.Length-1;i++)
            {
                var a=path[i]-path[i-1];var b=path[i+1]-path[i];float la=Length(a),lb=Length(b);
                if(la<.00001f||lb<.00001f)continue;
                var u=a*(1f/la);var v=b*(1f/lb);float cosine=Math.Max(-1f,Math.Min(1f,WirePoint.Dot(u,v)));
                if(cosine>.9999f||cosine<-.9999f){result.Add(path[i]);continue;}
                float cut=Math.Min(maximumCut,Math.Min(la,lb)*.45f);
                if(cut<.004f){result.Add(path[i]);continue;}
                // Quadratic fillet retains both end tangents. Its centreline is sampled
                // and validated by the router; tube radius never changes with curvature.
                var start=path[i]-u*cut;var end=path[i]+v*cut;result.Add(start);
                for(int k=1;k<=6;k++){float t=k/6f;result.Add(start*((1-t)*(1-t))+path[i]*(2*t*(1-t))+end*(t*t));}
            }
            result.Add(path[path.Length-1]);
            var compact=new List<WirePoint>();foreach(var p in result)if(compact.Count==0||(p-compact[compact.Count-1]).Squared>1e-12f)compact.Add(p);
            return compact.ToArray();
        }
    }
}
