from pathlib import Path
r=Path(__file__).resolve().parents[2]
s=(r/'Source/DinBreaker.cs').read_text();data=s[s.index('    public sealed class DinBreakerSaveData'):s.index('    public sealed class DinBreaker :')];persistence=s[s.index('        public override ThingSaveData SerializeSave()'):s.rindex('    }')];trip=s[s.index('        internal void Trip()'):s.index('        public PlacementBoard Board')]
handle=s[s.index('        public override DelayedActionInstance HandleSwitch('):s.index('        public override CanConstructInfo CanConstruct()')];
p=(r/'Source/DinModuleAccess.cs').read_text();access=p[p.index('        internal static bool CanEnter('):p.index('        internal static void Install(')]
save=s[s.index('        public override void BuildUpdate('):s.index('        public override void OnDeregistered(')]
(r/'Verification/Modules/Extracted.cs').write_text('''using System.Linq;using Assets.Scripts.Objects.Electrical;using Assets.Scripts.Objects;using Assets.Scripts;using Assets.Scripts.Networking;using System.Xml.Serialization;using LibConstruct;
namespace ModularSwitchboards {
'''+data+'''
partial class DinBreaker {
'''+trip+save+persistence+handle+'''
}
static class DinModuleAccess {
'''+access+'\n}}')
