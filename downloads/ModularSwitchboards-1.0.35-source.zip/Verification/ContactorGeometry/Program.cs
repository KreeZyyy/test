using System;using System.Linq;using System.IO;using System.Text.Json;using UnityEngine;using ModularSwitchboards;
class Program
{
 static int checks;static void Check(bool v,string why){checks++;if(!v)throw new Exception(why);}
 static float Front(Mesh mesh,float x,float y)
 {
  float z=float.NegativeInfinity;var v=mesh.vertices;
  foreach(var t in mesh.T.Values)for(int i=0;i<t.Length;i+=3)
  {
   var a=v[t[i]];var b=v[t[i+1]];var c=v[t[i+2]];
   float d=(b.y-c.y)*(a.x-c.x)+(c.x-b.x)*(a.y-c.y);if(Math.Abs(d)<1e-12f)continue;
   float u=((b.y-c.y)*(x-c.x)+(c.x-b.x)*(y-c.y))/d;
   float w=((c.y-a.y)*(x-c.x)+(a.x-c.x)*(y-c.y))/d;float r=1-u-w;
   if(u>=0&&w>=0&&r>=0)z=Math.Max(z,u*a.z+w*b.z+r*c.z);
  }
  return z;
 }
 static object Data(Mesh mesh)=>new{vertices=mesh.vertices.Select(v=>new[]{v.x,v.y,v.z}),triangles=mesh.T.ToDictionary(p=>p.Key.ToString(),p=>p.Value)};
 static void Main(string[] args)
 {
  var body=DinContactorModel.Build();Check(body.subMeshCount==5,"native body material roles retained");
  Check(body.bounds.size.x<.018f&&body.bounds.size.y<=DinBreakerModel.Build(plain:true).bounds.size.y+.0001f,"one DIN footprint");
  using var j=JsonDocument.Parse(File.ReadAllText(args[0]));var r=j.RootElement;
  var source=new Mesh{subMeshCount=1};source.vertices=r.GetProperty("vertices").EnumerateArray().Select(p=>new Vector3(p[0].GetSingle(),p[1].GetSingle(),p[2].GetSingle())).ToArray();
  source.uv=r.GetProperty("uv").EnumerateArray().Select(p=>new Vector2(p[0].GetSingle(),p[1].GetSingle())).ToArray();source.SetTriangles(r.GetProperty("triangles").EnumerateArray().Select(x=>x.GetInt32()).ToArray(),0);
  // Stub read uses UV as stored rather than UV list; preserve original fixture.
  source.UV=source.uv.ToList();var window=ApcContactorWindow.Build(source,Matrix4x4.identity);
  Check(window.GetTriangles(0).Length/3==106,"actual original APC master region retained, with boundary clipping");
  Check(window.bounds.size.x*2.25f<.029f&&window.bounds.size.y*1.35f>.050f,"fills fascia but fits one DIN");
  foreach(var p in window.vertices)Check(p.x>=-.00582f&&p.x<=.00582f&&Math.Abs(p.y)<=.01890f,"native frame stays on dark face");
  // Both native legend areas remain in front of the hollow body, below shutter.
  foreach(float y in new[]{-.0077f,.0077f})Check(Front(body,0,y)<Front(window,0,y)&&Front(window,0,y)<.062f,"native legend visible, shutter can cover it");
  Check(window.UV.Count==window.vertices.Length,"native UV present for every clipped vertex");
  int nativeLegendVertices=0;
  for(int i=0;i<source.vertices.Length;i++)
  {
   var a=source.vertices[i];if(a.x<0||a.x>.138f||Math.Abs(a.y)<.09f||Math.Abs(a.y)>.14f||Math.Abs(a.z-.17091f)>.00001f)continue;
   var mapped=ApcContactorWindow.MapInset(a);bool match=false;
   for(int k=0;k<window.vertices.Length;k++)if((window.vertices[k]-mapped).sqrMagnitude<1e-12f&&Math.Abs(window.UV[k].x-source.uv[i].x)<1e-5f&&Math.Abs(window.UV[k].y-source.uv[i].y)<1e-5f){match=true;break;}
   Check(match,"native ON/OFF letter vertex and original UV retained");nativeLegendVertices++;
  }
  Check(nativeLegendVertices>40,"fixture exercises original ON/OFF legend geometry");
  var slider=DinContactorModel.BuildSlider();
  Check(slider.bounds.size.y<.015f,"slider is visibly smaller than old 19mm model plate");
  Check(slider.GetTriangles(3).Length==0,"extra ribs removed, single raised grip");
  foreach(float x in new[]{-.001f,0,.001f})Check(Front(body,x,.030f)>.0569f,"terminal gap has real opaque backing");
  // The cavity must expose dark role3 surfaces, not white cut edges.
  foreach(float x in new[]{-.00605f,.00605f})Check(Front(body,x,0)>.0648f,"dark side wall closes window seam");
  foreach(float y in new[]{-.01995f,.01995f})Check(Front(body,0,y)>.0648f,"dark end wall closes window seam");
  foreach(float y in new[]{-.0077f,.0077f})
  {
   float offMin=ContactorIndicatorMotion.HalfTravel-slider.bounds.size.y*.5f,offMax=ContactorIndicatorMotion.HalfTravel+slider.bounds.size.y*.5f;
   Check(y>0?(y>offMin&&y<offMax):y<offMin,"OFF slider covers ON but leaves OFF visible");
  }
  File.WriteAllText(args[1],JsonSerializer.Serialize(new{body=Data(body),nativeWindow=Data(window),slider=Data(slider)}));
  Console.WriteLine(checks+" original APC contactor geometry checks passed.");
 }
}
