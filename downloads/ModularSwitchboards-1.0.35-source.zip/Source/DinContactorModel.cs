using System;
using System.Collections.Generic;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Motherboards;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class DinContactorModel
    {
        internal const string PrefabName="StructureDinContactor";
        internal static void Install(DinBreaker module)
        {
            var model=module.transform.Find("DinBreakerModel");
            foreach(var name in new[]{"BreakerLever","BreakerIndicator","BreakerControl"}){var t=model.Find(name);if(t!=null)UnityEngine.Object.DestroyImmediate(t.gameObject);}
            var oldView=module.GetComponent<BreakerSwitchView>();if(oldView!=null)UnityEngine.Object.DestroyImmediate(oldView);
            var mesh=Build();
            model.GetComponent<MeshFilter>().sharedMesh=mesh;
            var hit=model.GetComponent<BoxCollider>();hit.center=mesh.bounds.center;hit.size=mesh.bounds.size;
            module.Interactables=new List<Interactable>();module.HasOnOffState=false;module.ContactorClosed=false;
            var state=module.BuildStates[0];state.Interactables=module.Interactables;state.Colliders=new List<Collider>{hit};
            module.Thumbnail=CabinetIcons.Get("DinContactor");module.Thumbnails=new Sprite[0];state.Thumbnail=module.Thumbnail;
            module.CacheStates(true);
            var window=ApcContactorWindow.Install(model);
            var slider=new GameObject("ContactorMechanicalSlider"){layer=module.gameObject.layer};slider.transform.SetParent(model,false);
            slider.transform.localPosition=new Vector3(0,ContactorIndicatorMotion.HalfTravel,0);
            var moving=BuildSlider();
            slider.AddComponent<MeshFilter>().sharedMesh=moving;slider.AddComponent<MeshRenderer>().sharedMaterials=CabinetGeometry.Materials;
            var view=module.gameObject.AddComponent<DinContactorView>();view.Owner=module;view.Slider=slider.transform;view.WindowSurface=window;
            DinBreakerModel.Refresh(module);
            if(module.Blueprint!=null)ModelBlueprint.Refresh(module);
        }

        internal static Mesh BuildSlider()
        {
            var vertices=new List<Vector3>();var normals=new List<Vector3>();var groups=new List<int>[5];for(int i=0;i<5;i++)groups[i]=new List<int>();
            RoundedGeometry.Box(vertices,normals,groups[4],new Vector3(0,0,.0626f),new Vector3(.0092f,.011f,.0012f),.0005f);
            RoundedGeometry.Box(vertices,normals,groups[4],new Vector3(0,0,.0638f),new Vector3(.0068f,.002f,.0015f),.0004f);
            var moving=new Mesh{name="Contactor.CompactSlider"};moving.SetVertices(vertices);moving.SetNormals(normals);moving.subMeshCount=5;for(int i=0;i<5;i++)moving.SetTriangles(groups[i],i);CabinetGeometry.ApplyNativeUv(moving);moving.RecalculateBounds();return moving;
        }

        internal static Mesh Build()
        {
            var body=DinBreakerModel.Build(plain:true);
            // Replace the single top terminal with two independently aimed terminals.
            var cropped=NativeMeshCrop.Outside(body,new Bounds(new Vector3(0,.030f,.059f),new Vector3(.011f,.011f,.005f)),"Contactor.Housing");
            var cavity=NativeMeshCrop.Outside(cropped,new Bounds(new Vector3(0,0,.063f),new Vector3(.0117f,.039f,.012f)),"Contactor.WindowCavity");
            UnityEngine.Object.DestroyImmediate(cropped);cropped=cavity;
            var v=new List<Vector3>(cropped.vertices);var n=new List<Vector3>(cropped.normals);var g=new List<int>[5];for(int i=0;i<5;i++)g[i]=new List<int>(cropped.GetTriangles(i));
            // Seal the old terminal cut-out, including the gap BETWEEN the screws.
            // Its front sits just behind the two unchanged gray terminal plates.
            RoundedGeometry.Box(v,n,g[1],new Vector3(0,.030f,.0566f),new Vector3(.0134f,.011f,.0011f),.00025f);
            // A continuous dark well covers the cut edge and white inner shell,
            // including oblique sightlines beside the borrowed APC frame.
            RoundedGeometry.Box(v,n,g[3],new Vector3(0,0,.0584f),new Vector3(.013f,.042f,.0012f),.0002f);
            foreach(float x in new[]{-.00605f,.00605f})
                RoundedGeometry.Box(v,n,g[3],new Vector3(x,0,.0615f),new Vector3(.0009f,.041f,.007f),.00015f);
            foreach(float y in new[]{-.01995f,.01995f})
                RoundedGeometry.Box(v,n,g[3],new Vector3(0,y,.0615f),new Vector3(.013f,.0015f,.007f),.00015f);
            foreach(float x in new[]{-.004f,.004f})
            {
                RoundedGeometry.Box(v,n,g[4],new Vector3(x,.030f,.058f),new Vector3(.0057f,.009f,.0015f),.0004f);
                RoundedGeometry.Box(v,n,g[3],new Vector3(x,.030f,.059f),new Vector3(.0035f,.001f,.0005f),.0001f);
                RoundedGeometry.Box(v,n,g[4],new Vector3(x,.03755f,.029f),new Vector3(.0035f,.0003f,.006f),.0001f);
            }
            var mesh=new Mesh{name="DIN.Contactor.Body"};mesh.SetVertices(v);mesh.SetNormals(n);mesh.subMeshCount=5;for(int i=0;i<5;i++)mesh.SetTriangles(g[i],i);CabinetGeometry.ApplyNativeUv(mesh);mesh.RecalculateBounds();
            UnityEngine.Object.DestroyImmediate(body);UnityEngine.Object.DestroyImmediate(cropped);return mesh;
        }
    }
    // Only the visual follows the replicated contact state. Initial load/join/preview
    // snaps silently; subsequent changes animate and play one local native clack.
    public sealed class DinContactorView:MonoBehaviour
    {
        public DinBreaker Owner;
        public Transform Slider;
        public NativePortSurface WindowSurface;
        private readonly ContactorIndicatorMotion motion=new ContactorIndicatorMotion();
        private void LateUpdate()
        {
            if(Owner==null)Owner=GetComponent<DinBreaker>();
            if(Owner==null||Slider==null)return;
            bool active=!Owner.IsCursor&&!Owner.IsBeingDestroyed&&Owner.Board!=null;
            bool changed=motion.Tick(active,Owner.ContactorClosed,Time.deltaTime);
            Slider.localPosition=new Vector3(0,motion.Offset,0);
            if(WindowSurface!=null){WindowSurface.GetComponent<MeshRenderer>().SetPropertyBlock(null);WindowSurface.Restore();}
            if(changed)ContactorSwitchAudio.Play(Owner,Owner.ContactorClosed);
        }
    }
}
