using System;
using System.Linq;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Electrical;
using UnityEngine;
namespace ModularSwitchboards
{
    // The actual APC master window/backplate, including its original ON/OFF
    // lettering, UVs, materials and property blocks. No second Thing or lever.
    internal static class ApcContactorWindow
    {
        internal const float Scale=.17f;
        internal static readonly Bounds Region=new Bounds(new Vector3(.069f,0,.184f),new Vector3(.154f,.30f,.032f));
        internal static Vector3 Map(Vector3 p)=>new Vector3((p.x-.069f)*Scale/DinBreakerModel.VisualScale.x,p.y*Scale/DinBreakerModel.VisualScale.y,.064f+(p.z-.198f)*Scale/DinBreakerModel.VisualScale.z);
        // Keep the long native rim unchanged. Bring only the recessed backplate
        // and its original legends closer together for the smaller moving grip.
        internal static Vector3 MapInset(Vector3 p)
        {
            var mapped=Map(p);mapped.x*=.85f;mapped.y*=.55f;return mapped;
        }
        private static Mesh mesh;
        private static MeshRenderer source;
        internal static Mesh Build(Mesh original,Matrix4x4 frame)
        {
            var result=NativeMeshCrop.Read(original,frame,Region,"Contactor.OriginalAPCMasterWindow");
            if(result==null)throw new InvalidOperationException("Original APC master window not found.");
            var originalPoints=result.vertices;var points=new Vector3[originalPoints.Length];for(int i=0;i<points.Length;i++)points[i]=Map(originalPoints[i]);
            // Crop emits independent triangle vertices; compress full recessed
            // triangles only, never distort the front rim or its side walls.
            for(int sub=0;sub<result.subMeshCount;sub++)
            {
                var ids=result.GetTriangles(sub);
                for(int i=0;i<ids.Length;i+=3)
                    if(originalPoints[ids[i]].z<.18f&&originalPoints[ids[i+1]].z<.18f&&originalPoints[ids[i+2]].z<.18f)
                        for(int j=0;j<3;j++)points[ids[i+j]]=MapInset(originalPoints[ids[i+j]]);
            }
            result.vertices=points;
            result.RecalculateNormals();result.RecalculateTangents();result.RecalculateBounds();return result;
        }
        internal static NativePortSurface Install(Transform parent)
        {
            if(mesh==null)
            {
                var apc=WorldManager.Instance.SourcePrefabs.OfType<AreaPowerControl>().First(p=>p.PrefabName=="StructureAreaPowerControl");
                source=apc.GetComponent<MeshRenderer>();
                var frame=Matrix4x4.Rotate(CabinetModel.FrontSign<0?Quaternion.Euler(0,180,0):Quaternion.identity)*apc.transform.worldToLocalMatrix*source.transform.localToWorldMatrix;
                mesh=Build(source.GetComponent<MeshFilter>().sharedMesh,frame);
            }
            var go=new GameObject("ContactorAPCWindow"){layer=parent.gameObject.layer};go.transform.SetParent(parent,false);
            go.AddComponent<MeshFilter>().sharedMesh=mesh;var renderer=go.AddComponent<MeshRenderer>();NativePortSurface.Capture(source,renderer);
            return go.GetComponent<NativePortSurface>();
        }
    }
}
