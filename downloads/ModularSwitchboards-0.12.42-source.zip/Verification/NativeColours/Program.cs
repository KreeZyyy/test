using System;
using Assets.Scripts.Objects.Motherboards;
using ModularSwitchboards;
namespace ModularSwitchboards{static class SwitchboardsMod{public const string BreakerName="StructureDinBreaker1P";}}
static class Program
{
 static void Main()
 {
  if(Enum.GetUnderlyingType(typeof(ColorType))!=typeof(byte))throw new Exception("Native ColorType backing type changed; inspect game version.");
  bool reproduced=false;try{int bad=(int)Enum.Parse(typeof(ColorType),"Green");}catch(InvalidCastException){reproduced=true;}
  if(!reproduced)throw new Exception("Reported original cast wasn't reproduced against native enum.");
  float[] watts={1000,5000,50000,100000,500000};int[] expected={(int)ColorType.Green,(int)ColorType.Yellow,(int)ColorType.Orange,(int)ColorType.Red,(int)ColorType.Purple};
  for(int i=0;i<watts.Length;i++)if(DinModuleColours.Index(watts[i])!=expected[i])throw new Exception("Native palette index mismatch.");
  Console.WriteLine("Native Stationeers ColorType(byte): original InvalidCastException reproduced; all five production palette conversions passed against actual Assembly-CSharp.dll.");
 }
}
