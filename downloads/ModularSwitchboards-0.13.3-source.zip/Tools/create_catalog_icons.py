"""Render production mesh exports with neutral white bodies and native surface roles.
Models are exported by Verification/FuseGeometry and Verification/KitGeometry;
APC lever topology comes from Art/ApcLeverReference.json, never a proxy casing.
"""
import bpy,json,math,os
from pathlib import Path
from mathutils import Vector
root=Path(__file__).resolve().parents[1]
geometry=json.loads((root/'Art/CatalogGeometry.json').read_text());cover=json.loads((root/'Art/CoverIconGeometry.json').read_text());kits=json.loads((root/'Art/KitGeometry.json').read_text());lever=json.loads((root/'Art/LeverIconGeometry.json').read_text())
front=geometry['analyserFront'];indices=front['triangles']['0'];components=[]
for i in range(0,len(indices),3):
 points={tuple(round(v,6) for v in front['vertices'][j])for j in indices[i:i+3]};hits=[n for n,c in enumerate(components)if points&c[0]]
 if not hits:components.append((points,{i//3}))
 else:
  n=hits[0];components[n][0].update(points);components[n][1].add(i//3)
  for j in reversed(hits[1:]):components[n][0].update(components[j][0]);components[n][1].update(components[j][1]);components.pop(j)
assert sorted(len(c[1])for c in components)==[20,48]
lightning=next(c[1]for c in components if len(c[1])==20)
palette={'Green':(.06,.34,.10),'Yellow':(.85,.69,.015),'Orange':(.72,.30,.07),'Red':(.52,.055,.055),'Purple':(.23,.07,.43)}
jobs=[('DinBattery',['batteryBody','batteryBay'],None),('DinAnalyser',['analyserBody','analyserFront'],None),('InnerCover',['cover'],None)]
for colour in palette:
 jobs.extend([('DinFuse'+colour,['fuseBody','fuseClamps','fuseCartridge','fuseCaps'],colour),('DinBreaker'+colour,['breakerBody','breakerLever','breakerInk','breakerIndicator'],colour)])
jobs.extend(('Kit'+kind,['kit'+kind],None)for kind in kits)
for kind,parts,colour in jobs:
 if os.getenv('ICON_FILTER') and kind not in os.environ['ICON_FILTER'].split(','):continue
 bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
 mats=[]
 for name,rgb in [('White',(.78,.81,.80)),('Dark',(.018,.024,.025)),('Grey',(.075,.095,.095)),('Gold',(.72,.52,.025)),('Rating',palette.get(colour,(.075,.36,.14))),('Lightning',(.7,.16,.02)),('Contact',(.31,.36,.36)),('KitGrey',(.15,.18,.19)),('KitLight',(.32,.36,.37))]:
  m=bpy.data.materials.new(kind+name);m.diffuse_color=(*rgb,1);m.use_nodes=True;n=m.node_tree.nodes.get('Principled BSDF');n.inputs['Base Color'].default_value=(*rgb,1);n.inputs['Roughness'].default_value=.65;mats.append(m)
 allpoints=[]
 for part in parts:
  data=cover if part=='cover' else kits[part[3:]] if part.startswith('kit') else lever if part=='breakerLever' else geometry[part]
  scale=(1,1,1) if part=='cover' or part.startswith('kit') else(2.25,1.35,1.15)
  # Unity front +Z maps to Blender front -Y, preserving the lightning on the right.
  pts=[(p[0]*scale[0]*(1 if part=="breakerInk" else -1),-(p[2]+(.0675 if part in ['breakerLever','breakerInk'] else 0))*scale[2],p[1]*scale[1])for p in data['vertices']];allpoints.extend(pts)
  faces=[];roles=[]
  for role,indices in data['triangles'].items():
   role=int(role)
   for i in range(0,len(indices),3):
    faces.append(tuple(reversed(indices[i:i+3])));material={0:4,1:0,2:2,3:2,4:6}.get(role,2)
    if part=='batteryBay':material=3 if role==1 else 2
    if part=='fuseClamps':material=6
    if part in ['fuseCartridge','breakerLever']:material=4
    if part in ['fuseCaps','breakerInk']:material=0
    if part=='analyserFront':material=4 if role==2 else 5 if i//3 in lightning else 2
    if part=='breakerIndicator':material=4
    if part=='cover':material=2
    if part.startswith('kit'):material={0:1,1:0,2:0,3:7,4:6}[role]
    roles.append(material)
  me=bpy.data.meshes.new(part);me.from_pydata(pts,[],faces);me.update();ob=bpy.data.objects.new(part,me);bpy.context.collection.objects.link(ob)
  for m in mats:me.materials.append(m)
  for face,role in zip(me.polygons,roles):face.material_index=role
 low=Vector(tuple(min(p[i]for p in allpoints)for i in range(3)));high=Vector(tuple(max(p[i]for p in allpoints)for i in range(3)));center=(low+high)/2
 size=high-low;scale=max(size.x,size.z,size.y*.65)*1.35
 scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=64;scene.cycles.use_denoising=False;scene.render.resolution_x=256;scene.render.resolution_y=256;scene.render.resolution_percentage=100;scene.render.film_transparent=True;scene.world.color=(.2,.2,.2);scene.view_settings.view_transform='Standard';scene.view_settings.exposure=0
 bpy.ops.object.camera_add(location=center+Vector((scale*.48,-scale*2.8,scale*(1.5 if kind.startswith('Kit') else .54))));cam=bpy.context.object;cam.rotation_euler=(center-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=scale;scene.camera=cam
 for offset,power in [((1,-3,4),240),((-3,-1,2),80)]:
  bpy.ops.object.light_add(type='AREA',location=center+Vector(offset)*scale);bpy.context.object.data.energy=power*scale*scale;bpy.context.object.data.size=5*scale;bpy.context.object.rotation_euler=(center-bpy.context.object.location).to_track_quat('-Z','Y').to_euler()
 scene.render.filepath=str(root/'Assets/Icons'/(kind+'.png'));bpy.ops.render.render(write_still=True)
