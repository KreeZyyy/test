using System.Collections.Generic;
using UnityEngine;
namespace ModularSwitchboards
{
    internal enum SwitchboardKitKind{Cabinet,Rails,Modules,Cover}
    internal static class SwitchboardKitGeometry
    {
        internal static float Fit(Vector3 envelope,Vector3 size)=>Mathf.Min(envelope.x/size.x,Mathf.Min(envelope.y/size.y,envelope.z/size.z))*.92f;
        internal static Mesh Build(SwitchboardKitKind kind)
        {
            var v=new List<Vector3>();var n=new List<Vector3>();var t=new[]{new List<int>(),new List<int>(),new List<int>(),new List<int>(),new List<int>()};
            System.Action<int,float,float,float,float,float,float> box=(role,x,y,z,w,h,d)=>RoundedGeometry.Box(v,n,t[role],new Vector3(x,y,z),new Vector3(w,h,d),.0025f);
            bool flat=kind==SwitchboardKitKind.Cover;
            if(kind==SwitchboardKitKind.Cabinet||flat)
            {
                float floor=flat?-.030f:-.075f,wall=flat?.054f:.140f;
                box(3,0,floor,0,.400f,.014f,.280f);
                box(3,-.193f,floor+wall*.5f,0,.014f,wall,.280f);box(3,.193f,floor+wall*.5f,0,.014f,wall,.280f);
                box(3,0,floor+wall*.5f,-.133f,.372f,wall,.014f);
                // Low front lip leaves the components visible from the front/top.
                box(3,0,floor+wall*.30f,.133f,.372f,wall*.60f,.014f);
                foreach(float x in new[]{-.182f,.182f})foreach(float z in new[]{-.122f,.122f})box(4,x,floor+wall*.5f,z,.018f,wall+.008f,.018f);
                if(flat)
                {
                    for(int i=0;i<3;i++)box(i%2==0?2:1,0,floor+.016f+i*.010f,0,.340f,.006f,.216f);
                    foreach(float x in new[]{-.174f,.174f})box(4,x,floor+.024f,.025f,.009f,.012f,.080f);
                }
                else
                {
                    // Loose panels and separate frame profiles: neutral assembly parts,
                    // not a finished enclosure tied to a particular cabinet size.
                    for(int i=0;i<3;i++)box(i%2==0?2:1,-.061f,floor+.018f+i*.014f,0,.196f,.009f,.206f);
                    foreach(float x in new[]{.071f,.110f,.149f})
                    {
                        box(4,x,floor+.030f,0,.014f,.020f,.218f);
                        box(2,x-.006f,floor+.041f,0,.004f,.012f,.218f);
                    }
                    foreach(float z in new[]{-.085f,.085f})box(4,.041f,floor+.082f,z,.254f,.015f,.014f);
                }
                Label(box,kind,0,floor+wall*.28f,.142f,.074f,flat?.022f:.036f);
            }
            else
            {
                float width=kind==SwitchboardKitKind.Rails?.300f:.260f,height=kind==SwitchboardKitKind.Rails?.110f:.145f,depth=kind==SwitchboardKitKind.Rails?.160f:.200f;
                box(3,0,0,0,width,height,depth);
                box(2,0,height*.5f+.004f,0,width-.010f,.012f,depth-.010f);
                foreach(float x in new[]{-width*.31f,width*.31f})
                {
                    box(0,x,height*.5f+.012f,0,.020f,.009f,depth+.004f);
                    foreach(float side in new[]{-1f,1f})box(0,x,0,side*(depth*.5f+.003f),.020f,height+.012f,.006f);
                    box(0,x,-height*.5f-.004f,0,.020f,.008f,depth+.004f);
                    box(4,x,-height*.18f,depth*.5f+.007f,.028f,.016f,.004f);
                }
                Label(box,kind,0,0,depth*.5f+.006f,.088f,.045f);
            }
            var mesh=new Mesh{name="Switchboards.Kit."+kind};mesh.SetVertices(v);mesh.SetNormals(n);mesh.subMeshCount=5;
            for(int i=0;i<5;i++)mesh.SetTriangles(t[i],i);
            CabinetGeometry.ApplyNativeUv(mesh);mesh.RecalculateBounds();return mesh;
        }
        private static void Label(System.Action<int,float,float,float,float,float,float> box,SwitchboardKitKind kind,float x,float y,float z,float w,float h)
        {
            box(1,x,y,z,w,h,.003f);float front=z+.0025f,stroke=.002f;
            if(kind==SwitchboardKitKind.Modules)
            {
                foreach(float offset in new[]{-.018f,0,.018f})box(0,x+offset,y,front,.010f,h*.65f,.0015f);
            }
            else if(kind==SwitchboardKitKind.Rails)
            {
                foreach(float offset in new[]{-h*.18f,h*.18f})box(0,x,y+offset,front,w*.68f,stroke,.0015f);
            }
            else
            {
                float sw=w*.55f,sh=h*.65f;
                foreach(float side in new[]{-1f,1f}){box(0,x+side*sw*.5f,y,front,stroke,sh,.0015f);box(0,x,y+side*sh*.5f,front,sw,stroke,.0015f);}
                if(kind==SwitchboardKitKind.Cabinet)box(0,x+sw*.28f,y,front,stroke,sh*.22f,.0015f);
                else box(0,x,y,front,sw*.65f,stroke,.0015f);
            }
        }
    }
}
