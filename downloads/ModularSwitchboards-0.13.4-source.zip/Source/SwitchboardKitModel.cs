using System.Collections.Generic;
using System.Linq;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Motherboards;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class SwitchboardKitModel
    {
        internal static bool IsKit(Thing thing)=>thing is MultiConstructor&&(thing.PrefabName==SwitchboardsMod.KitName||thing.PrefabName==SwitchboardsMod.RailKitName||thing.PrefabName==SwitchboardsMod.BreakerKitName||thing.PrefabName==SwitchboardsMod.CoverKitName);
        internal static void Install(MultiConstructor kit,SwitchboardKitKind kind)
        {
            var original=kit.Bounds;
            if(original.size.x<.001f||original.size.y<.001f||original.size.z<.001f)
            {
                bool first=true;
                foreach(var filter in kit.GetComponentsInChildren<MeshFilter>(true))
                {
                    if(filter.sharedMesh==null)continue;
                    var b=CabinetWallMount.TransformedBounds(filter.sharedMesh.bounds,kit.transform.worldToLocalMatrix*filter.transform.localToWorldMatrix);
                    if(first){original=b;first=false;}else original.Encapsulate(b);
                }
            }
            if(original.size.x<=0||original.size.y<=0||original.size.z<=0)throw new System.InvalidOperationException("Kit visual bounds unavailable: "+kit.PrefabName);
            foreach(var lod in kit.GetComponentsInChildren<LODGroup>(true))Object.DestroyImmediate(lod);
            foreach(var renderer in kit.GetComponentsInChildren<MeshRenderer>(true))Object.DestroyImmediate(renderer);
            var mesh=SwitchboardKitGeometry.Build(kind);
            float fit=SwitchboardKitGeometry.Fit(original.size,mesh.bounds.size);
            var model=new GameObject("SwitchboardKitModel"){layer=kit.gameObject.layer};model.transform.SetParent(kit.transform,false);
            model.transform.localScale=Vector3.one*fit;model.transform.localPosition=original.center-mesh.bounds.center*fit;
            model.AddComponent<MeshFilter>().sharedMesh=mesh;
            var view=model.AddComponent<MeshRenderer>();view.sharedMaterials=CabinetGeometry.Materials;
            kit.Renderers=new List<ThingRenderer>{new ThingRenderer(kit,view)};
            kit.PaintableMaterial=null;kit.HasColorState=false;
            kit.Thumbnail=CabinetIcons.Get("Kit"+kind);kit.Thumbnails=new Sprite[0];
            // Native kit identity, hand poses, stack behaviour, rigidbody and
            // collision envelope remain intact. Only the fitted visual is replaced.
            Refresh(kit);
        }
        internal static void Refresh(Thing kit)
        {
            foreach(var renderer in kit.GetComponentsInChildren<MeshRenderer>(true))
            {
                if(renderer.name!="SwitchboardKitModel")continue;
                for(int role=0;role<5;role++)
                {
                    var block=new MaterialPropertyBlock();renderer.GetPropertyBlock(block,role);
                    int color=role==0?(int)ColorType.Black:role==1?(int)ColorType.White:role==2?(int)ColorType.White:(int)ColorType.Gray;
                    block.SetFloat(Thing.DiffuseIndexPropertyID,color);block.SetFloat(Thing.SmoothnessIndexPropertyID,0f);block.SetColor(Thing.EMISSION_COLOR,Color.black);renderer.SetPropertyBlock(block,role);
                }
            }
        }
    }
}
