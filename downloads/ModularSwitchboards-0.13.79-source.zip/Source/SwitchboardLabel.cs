using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Serialization;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Items;
using Assets.Scripts.Inventory;
using Assets.Scripts.Networking;
using Assets.Scripts.Localization2;
using LibConstruct;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class LabelLayout
    {
        internal static bool Fits(int x,int y,int z,int rotation,int width)
            =>x%90==0&&x>=0&&x/90+width<=8&&(y==240||y==-240)&&z==0&&rotation==0&&width>=1&&width<=3;
        internal static bool Overlaps(int x,int width,int other,int otherWidth)=>x<other+otherWidth&&other<x+width;
    }
    public sealed class SwitchboardLabelSaveData:StructureSaveData
    {
        [XmlElement] public PlacementBoardStructureSaveData Mount;
    }
    public sealed class SwitchboardLabelBoard:PlacementBoard
    {
        public override float GridSize=>.0045f;
        public override IPlacementBoardStructure EquivalentStructure(Structure structure)
            =>structure is SwitchboardLabel&&PrimaryHost is InnerCoverModule cover&&cover.Host!=null&&cover.Host.IsOpen?structure as IPlacementBoardStructure:null;
    }
    public sealed class SwitchboardLabel:Structure,IPlacementBoardStructure
    {
        public int Width=1;
        public PlacementBoard Board{get;set;}
        public PlacementBoard.BoardCell[] BoardCells{get;set;}
        internal InnerCoverModule Cover=>Board?.PrimaryHost as InnerCoverModule;
        internal static bool CanSupport(PlacementBoard board,Grid3 position,int rotation,int width)
        {
            if(!(board is SwitchboardLabelBoard)||!(board.PrimaryHost is InnerCoverModule cover)||cover.Host==null||!cover.Host.IsOpen||!LabelLayout.Fits(position.x,position.y,position.z,rotation,width))return false;
            // Every covered position must actually contain a module in the row below.
            for(int slot=position.x/90;slot<position.x/90+width;slot++)
            {
                float x=-3.5f*DinLayout.SlotPitch+slot*DinLayout.SlotPitch;
                float y=position.y>0?.108f:-.108f;
                if(!cover.Host.Wiring.Breakers.Any(b=>{var p=cover.transform.InverseTransformPoint(b.transform.position);return Mathf.Abs(p.y-y)<.01f&&x>=p.x-.01f&&x<p.x+(b.ModuleWidth-1)*DinLayout.SlotPitch+.01f;}))return false;
            }
            return true;
        }
        internal static bool CanPlace(PlacementBoard board,Grid3 position,int rotation,int width)
        {
            return CanSupport(board,position,rotation,width)&&!board.Structures.OfType<SwitchboardLabel>().Any(l=>{var p=board.WorldToGrid(l.transform.position);return p.y==position.y&&LabelLayout.Overlaps(position.x/90,width,p.x/90,l.Width);});
        }
        public override void Awake(){base.Awake();BoardStructureHooks.Awake(this);}
        public override Grid3 GetLocalGrid()=>Board==null?default(Grid3):Board.WorldToGrid(Transform.position);
        public override CanConstructInfo CanConstruct()
        {
            if(!(Board is SwitchboardLabelBoard)||(IsCursor&&PlacementBoard.CursorBoard!=Board))return CanConstructInfo.InvalidPlacement(InnerLabelPlacementHint.For(SwitchboardCoverInput.Target()));
            var p=Board.WorldToGrid(Transform.position);
            if(IsCursor)
            {
                if(!MountPlacement.TryLockedGrid(this,Board,out var locked))
                {
                    var candidates=Enumerable.Range(0,9-Width).SelectMany(x=>new[]{new Grid3(x*90,-240,0),new Grid3(x*90,240,0)}).Where(g=>CanSupport(Board,g,0,Width));
                    if(!MountSnap.TryNearest(p,candidates,out p))return CanConstructInfo.InvalidPlacement("Aim above installed modules.");
                }
                else p=locked;
                PlacementBoard.CursorGrid=p;PlacementBoard.CursorRotation=0;Transform.SetPositionAndRotation(Board.GridToWorld(p),Board.IndexToRotation(0));
            }
            return CanPlace(Board,p,Board.RotationToIndex(Transform.rotation),Width)?CanConstructInfo.ValidPlacement:CanConstructInfo.InvalidPlacement("Choose free space directly above installed modules.");
        }
        protected override CanConstructInfo CanDeconstruct()=>Cover?.Host!=null&&Cover.Host.IsOpen?CanConstructInfo.ValidPlacement:CanConstructInfo.InvalidPlacement("Open the cabinet first.");
        public override DelayedActionInstance AttackWith(Attack attack,bool doAction=true)
        {
            if(Cover?.Host==null||!Cover.Host.IsOpen)return new DelayedActionInstance{Duration=0}.Fail("Open the cabinet first.");
            if(attack.SourceItem is Labeller labeller)
            {
                // Match native Device/ItemRenamable, including local UI authority
                // and native rename network/save handling inside Labeller.Rename.
                var action=new DelayedActionInstance{Duration=0f,ActionMessage=ActionStrings.Rename};
                if(!labeller.OnOff)return action.Fail(GameStrings.DeviceNotOn);
                if(!labeller.IsOperable)return action.Fail(GameStrings.DeviceNoPower);
                if(doAction)labeller.Rename(this);
                return action;
            }
            return base.AttackWith(attack,doAction);
        }
        public override void OnDeregistered(){base.OnDeregistered();if(Board!=null)BoardStructureHooks.OnDeregistered(this);}
        public override ThingSaveData SerializeSave(){ThingSaveData data=new SwitchboardLabelSaveData();InitialiseSaveData(ref data);return data;}
        protected override void InitialiseSaveData(ref ThingSaveData data){base.InitialiseSaveData(ref data);if(data is SwitchboardLabelSaveData save&&Board!=null)save.Mount=BoardStructureHooks.SerializeSave(this);}
        public override void DeserializeSave(ThingSaveData data){base.DeserializeSave(data);if(data is SwitchboardLabelSaveData save&&save.Mount!=null)BoardStructureHooks.DeserializeSave(this,save.Mount);}
        public override void SerializeOnJoin(RocketBinaryWriter writer){base.SerializeOnJoin(writer);BoardStructureHooks.SerializeOnJoin(writer,this);}
        public override void DeserializeOnJoin(RocketBinaryReader reader){base.DeserializeOnJoin(reader);BoardStructureHooks.DeserializeOnJoin(reader,this);}
        internal static void SetBounds(SwitchboardLabel label)
        {
            label.ThingTransform=label.transform;
            label.Bounds=new Bounds(new Vector3((label.Width-1)*DinLayout.SlotPitch*.5f,0,0),new Vector3(label.Width*DinLayout.SlotPitch-.004f,.018f,.002f));
            label.GridBounds=new GridBounds(label);
        }
        internal static Mesh Mesh(int width)
        {
            float w=width*DinLayout.SlotPitch-.004f,h=.018f,edge=.0012f,c=(width-1)*DinLayout.SlotPitch*.5f;
            var vertices=new List<Vector3>();var border=new List<int>();var face=new List<int>();
            DinRailModel.AddBox(vertices,border,new Vector3(c-w*.5f+edge*.5f,0,0),new Vector3(edge,h,.002f));
            DinRailModel.AddBox(vertices,border,new Vector3(c+w*.5f-edge*.5f,0,0),new Vector3(edge,h,.002f));
            DinRailModel.AddBox(vertices,border,new Vector3(c,h*.5f-edge*.5f,0),new Vector3(w-2*edge,edge,.002f));
            DinRailModel.AddBox(vertices,border,new Vector3(c,-h*.5f+edge*.5f,0),new Vector3(w-2*edge,edge,.002f));
            DinRailModel.AddBox(vertices,face,new Vector3(c,0,0),new Vector3(w-2*edge,h-2*edge,.002f));
            var mesh=new Mesh{name="Switchboard label"};mesh.SetVertices(vertices);mesh.subMeshCount=5;
            for(int i=0;i<5;i++)mesh.SetTriangles(i==0?border.ToArray():i==1?face.ToArray():new int[0],i);
            mesh.RecalculateNormals();mesh.RecalculateBounds();return mesh;
        }
    }
    internal static class SwitchboardLabelSurface
    {
        private static Material[] materials;
        internal static void Apply(MeshRenderer renderer)
        {
            if(materials==null){var shader=Shader.Find("Standard");if(shader==null||!shader.isSupported)shader=Shader.Find("StandardInstanced");if(shader==null||!shader.isSupported)throw new InvalidOperationException("Label shader unavailable");materials=new Material[5];for(int i=0;i<5;i++){var m=new Material(shader){name=i==1?"Switchboards.Label.White":"Switchboards.Label.Black",color=i==1?Color.white:Color.black};CabinetMatteSurface.Configure(m);materials[i]=m;}}
            renderer.sharedMaterials=materials;renderer.SetPropertyBlock(null);for(int i=0;i<5;i++)renderer.SetPropertyBlock(null,i);
        }
    }
    public sealed class SwitchboardLabelView:MonoBehaviour
    {
        public SwitchboardLabel Owner;
        public TextMesh Text;
        private string lastValue;
        private int lastWidth;
        private void LateUpdate()
        {
            if(Owner==null||Text==null)return;
            var renderer=Text.GetComponent<MeshRenderer>();
            var cabinet=Owner.Cover?.Host;
            bool visible=!Owner.IsCursor&&cabinet!=null&&cabinet.IsStructureCompleted;
            var camera=Camera.main;
            renderer.enabled=visible&&(camera==null||Vector3.Dot(Owner.transform.forward,camera.transform.position-Owner.transform.position)>0);
            var body=Owner.transform.Find("InnerCoverModel");if(body!=null){var hit=body.GetComponent<MeshCollider>();hit.enabled=visible&&cabinet.IsOpen;Thing._colliderLookup[hit]=Owner;SwitchboardLabelSurface.Apply(body.GetComponent<MeshRenderer>());}
            string value=Owner.CustomName;
            if(string.IsNullOrWhiteSpace(value)||(value==SwitchboardNames.LabelTitle(Owner.Width)||value=="Switchboard Label ("+Owner.Width+" module"+(Owner.Width==1?"":"s")+")"))value="LABEL";
            value=LabelTextLayout.Normalize(value);
            if(value!=lastValue||Owner.Width!=lastWidth)
            {
                var fit=LabelTextLayout.Arrange(value,Owner.Width*DinLayout.SlotPitch-.0068f,.015f,candidate=>
                {
                    Text.text=candidate;
                    var bounds=renderer.localBounds.size;
                    return new LabelTextLayout.Size(bounds.x,bounds.y);
                });
                Text.text=fit.Text;
                Text.transform.localScale=Vector3.one*fit.Scale;
                lastValue=value;lastWidth=Owner.Width;
            }
            DepthLabelText.Apply(Text);
        }
        internal static void Install(SwitchboardLabel owner)
        {
            Font font=null;
            foreach(var name in new[]{"LegacyRuntime.ttf","Arial.ttf"}){try{font=Resources.GetBuiltinResource<Font>(name);}catch(Exception){}if(font!=null)break;}
            if(font==null)font=Resources.FindObjectsOfTypeAll<Font>().FirstOrDefault();if(font==null)return;
            var go=new GameObject("LabelText"){layer=owner.gameObject.layer};go.transform.SetParent(owner.transform,false);go.transform.localPosition=new Vector3((owner.Width-1)*DinLayout.SlotPitch*.5f,0,.0015f);go.transform.localRotation=Quaternion.Euler(0,180,0);
            var text=go.AddComponent<TextMesh>();text.font=font;text.fontSize=96;text.fontStyle=FontStyle.Bold;text.lineSpacing=.85f;text.characterSize=.01f;text.anchor=TextAnchor.MiddleCenter;text.alignment=TextAlignment.Center;text.richText=false;text.color=Color.black;text.text="LABEL";DepthLabelText.Apply(text);
            var view=owner.gameObject.AddComponent<SwitchboardLabelView>();view.Owner=owner;view.Text=text;
        }
    }
}
