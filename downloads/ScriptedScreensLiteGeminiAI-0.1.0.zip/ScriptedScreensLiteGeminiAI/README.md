# ScriptedScreensLiteGeminiAI 0.1.0

Testovací mod pro StationeersLua a ScriptedScreens. Lua pošle otázku a preference,
mod získá text z Gemini, případně vytvoří hlas přes Gemini TTS a vrátí text + URL WAV.
Přehrávání ze zařízení i prostorový zvuk patří ScriptedScreens. Žádný Windows Jakub,
PowerShell, mikrofon, vlastní AudioSource ani zvukový výstup serveru.

## Instalace a první test

1. Měj funkční BepInEx 5.x, StationeersLaunchPad, StationeersLua a ScriptedScreens.
2. Rozbal ZIP tak, aby vznikla složka `ScriptedScreensLiteGeminiAI` v místní složce
   modů (`Dokumenty/My Games/Stationeers/mods`). U dedikovaného serveru použij jeho
   složku `mods` a mod povol v LaunchPad modconfigu stejně jako ostatní serverové mody.
3. Povol mod v LaunchPadu na **hostiteli / dedikovaném serveru**. Nech jednou
   vytvořit konfiguraci a hru/server ukonči. Klienti potřebují existující
   StationeersLua/ScriptedScreens; tento AI mod nemusí spouštět u sebe.
4. V `BepInEx/config/oasis.stationeers.scriptedscreenslitegeminiai.cfg` nastav:

   ```ini
   [Gemini]
   ApiKey = TVUJ_GOOGLE_AI_STUDIO_KLIC
   TextModel = gemini-3.1-flash-lite

   [Speech]
   Enabled = true
   Model = gemini-3.8-flash-lite-tts
   Api = interactions
   Voice = Kore

   [Memory]
   WorldId = moje-zakladna-01
   ```

   Modely musí být dostupné tvému klíči/projektu. Názvy můžeš změnit v konfiguraci,
   není potřeba přestavovat DLL. Pro starší podporované TTS modely přepni
   `Speech.Api = generateContent` a zadej odpovídající model (např.
   `gemini-3.1-flash-tts-preview`, pokud ho tvůj účet nabízí).
5. Ze sekce `[Bridge]` zkopíruj **jen Token** do `TOKEN` v `examples/OASIS.lua`.
   Klíč Gemini do Lua nepatří. Nový bridge používá localhost port **18766**, audio **18767**.
6. Na hostiteli v StationeersLua `[Features]` nastav `AllowHttp = true` a
   `AllowHttpLocalhost = true`. Ve ScriptedScreens musí být povolené
   `AllowMediaPlayback`; u klientů `EnableMediaLocally`. Pokud omezuješ typy médií,
   povol WAV. Experimentální video není potřeba, používáme `ss.play_sound()`.
7. Restartuj hru/server. Nahraj `examples/OASIS.lua` do Lua chipu v zařízení
   ScriptedScreens přes IC10Editor. Tento example je samostatný, nepotřebuje library chip.
8. Nejdřív vypni hlas a pošli krátkou otázku. Pak zapni hlas a zkus krátkou odpověď.
   Odpověď se přehraje ze zařízení. Hlasitost upravuje ScriptedScreens/herní klient.

## Multiplayer: adresa audia

Lua běží na hostiteli, takže `BASE = http://localhost:18766` zůstává správně.
Přehrávání ale běží u hráčů. Jejich `localhost` není server!

Na hostiteli nastav například:

```ini
[Media]
BindAddress = 0.0.0.0
Port = 18767
PublicBaseUrl = http://192.168.1.50:18767
```

Tento příklad je pro hráče na stejné LAN. Pro hráče z internetu použij dostupnou
veřejnou adresu/doménu, odpovídající firewall/port forwarding, případně HTTPS
reverse proxy. **Zpřístupňuje se pouze audio port 18767**, ne control port 18766.
Mod nepřesměrovává router automaticky. HTTP stačí pro soukromou LAN; pro veřejný
přístup je vhodná vlastní HTTPS proxy. Každý klient musí zvládnout stáhnout
vrácenou `audio_url`. URL obsahuje náhodný identifikátor, nikoli Gemini klíč nebo
Bridge Token. Kdo má URL, může po dobu platnosti přehrát/stáhnout dané audio.

Stejná DLL používá přenositelné .NET/Mono API pro Windows i Linux hostitele.
Skutečný běh s Linuxovým loaderem a ve hře je potřeba ověřit; sestavení neznamená
potvrzenou kompatibilitu všech kombinací hry/loaderu. Na serveru se audio jen
vytváří a poskytuje jako soubor, nikdy se tam nepřehrává.

## Vlastní Lua skripty

`examples/geminiai.lua` je knihovna s anotací `--@module geminiai`. Nahraj ji do
library chipu v IC Housing na stejné datové síti. `require("geminiai")` ji načte
v kontextu volajícího chipu. Ukázka:

```lua
local GeminiAI = require("geminiai")
local ai = GeminiAI.new({
    token = "MISTNI_BRIDGE_TOKEN",
    system_prompt = "Jsi technik základny. Odpovídej stručně česky.",
    voice = "Charon",
})
local ok, error = ai:ask("Co znamená tlak 25 kPa?", {
    remember = true,
    speak = true,
    max_output_tokens = 300,
}, function(result, error)
    if error then print(error); return end
    print(result.text)
    if result.audio_url then ai:play_audio(result) end
    if result.voice_error then print(result.voice_error) end
end)
if not ok then print(error) end
function tick(dt) ai:tick(dt) end
```

Mod nedostává senzory ani oprávnění řídit základnu automaticky. Předej potřebné
hodnoty jako text otázky a chování zařízení implementuj ve svém Lua skriptu.
ReferenceId je ID **hostitelského zařízení**, ne samostatné instance cartridge.
Výchozí konverzace je `device:<ReferenceId>`. Přehrání provede volající chip ve svém
ScriptedScreens kontextu; server sám nemusí hledat Unity objekt zařízení.

Celý HTTP kontrakt a parametry jsou v [API.md](API.md). Při dalších HTTP API
používej jeden společný poll loop a `ai:handle_completion(...)`; potom volej
`ai:tick(dt, false)`. Výchozí `ai:tick()` odčerpává HTTP frontu chipu.

## Lite paměť a limity

Výchozí hodnoty, nastavitelné v `[Limits]`:

| Omezení | Výchozí hodnota |
|---|---:|
| Konverzace v daném WorldId | 25 |
| Uložené výměny na konverzaci | 20 |
| Kontext posílaný Gemini | nejvýše 12 000 UTF-8 bajtů nedávné historie |
| Otázka / odpověď | 2 000 / 4 000 UTF-16 znaků |
| Maximální nastavení výstupních tokenů | 800 |
| Text pro hlas | nejvýše 2 000 znaků |
| Souběžné / celkem čekající dotazy | 2 / 8 |
| Přijaté dotazy za minutu | 12 celkem |
| Prodleva na zařízení | 3 sekundy |
| Hotové výsledky / jejich platnost | 128 / 10 minut |
| Platnost audio URL | 30 minut |
| Audio cache / jeden soubor | 64 / 8 MiB |

Jedna konverzace smí mít jeden rozpracovaný dotaz. Plná paměť vrací chybu; mod
nikdy tiše nesmaže cizí historii. `remember=false` paměť obejde. OASIS má tlačítko
pro potvrzené smazání místní historie i serverové paměti svého zařízení.

Historie je obyčejný JSON ve `Memory.DataDirectory/worlds/<hash WorldId>/conversations`.
Audio je v `Memory.DataDirectory/audio` a automaticky expiruje. Složka je mimo
instalaci modu, takže aktualizace DLL historii nesmaže. **WorldId v 0.1 nastavuje
správce ručně per save**; před přepnutím světa zvol jiné WorldId a restartuj.
Mod zatím neodvozuje identitu světa z herního save API. OASIS ukládá krátkou kopii
zobrazeného chatu do `ic.persist`; autoritativní kontext Gemini je na serveru.

Omezení kontextu v bajtech není přesný tokenový rozpočet. Cena závisí na modelu,
délce instrukcí, historie a odpovědi. S hlasem jsou obvykle **dva Google API
požadavky**. Mod nemůže ověřit účtování tvého projektu ani slíbit free tier.
Neprovádí automatické opakování placených požadavků a neaktivuje billing.
Otázky/kontext i text pro TTS se posílají Googlu. API klíč není v historii ani v URL.
Bridge Token je sdílené oprávnění skriptů k dotazům i paměti, nikoli individuální
ověření hráče/chipu. Proto ho dávej pouze důvěryhodným skriptům.

## Ověření této verze

- DLL sestavena pro `netstandard2.1`, bez chyb a varování, proti veřejným
  referencím BepInEx 5.4.23.2, StationeersLaunchPad 0.5.1 a UnityEngine.Modules 2021.3.33.
- Automatické C# kontroly: payloady Gemini/TTS, klíč v hlavičce, WAV/PCM, paměť po
  restartu, namespace světů, fronta, limity, chyby, autorizace a lokální audio HTTP.
- Lua 5.2 syntaxe a testy s náhradami herních API pro knihovnu i OASIS example.
- **Skutečné Gemini API/TTS a přehrávání v singleplayeru/multiplayeru zatím
  nejsou ověřené.** Ve vývojovém prostředí nemáme tvůj API klíč ani běžící hru.

Aktuální API formáty jsou podle oficiální dokumentace:
[Gemini TTS](https://ai.google.dev/gemini-api/docs/speech-generation),
[textové modely](https://ai.google.dev/gemini-api/docs/models/gemini-3.1-flash-lite),
[ScriptedScreens sound](https://orbitalfoundrymodteam.github.io/ScriptedScreensDocs/api/sound).

## Vývoj

Zkopíruj `Stationeers.User.props.example` na `Stationeers.User.props` a doplň
cesty ke knihovnám svého loaderu/hry. .NET SDK 8:

```sh
dotnet build ScriptedScreensLiteGeminiAI.csproj -c Release
dotnet run --project tests/CoreTests.csproj -c Release
python tests/test_lua.py
python scripts/package.py --output ./output
```

Testy Lua vyžadují `lupa==2.6`. Herní knihovny se do balíčku nepřibalují.
