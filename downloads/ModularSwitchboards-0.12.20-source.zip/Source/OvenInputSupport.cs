using System;
using System.Collections.Generic;
using Assets.Scripts.Objects;
using UnityEngine;

namespace ModularSwitchboards
{
    public sealed class OvenInputSupportState : MonoBehaviour
    {
        [NonSerialized] public Mesh InstanceMesh;
        private void OnDestroy(){if(InstanceMesh!=null)UnityEngine.Object.Destroy(InstanceMesh);}
    }

    // One continuous base body, rooted tunnel and upper IN transition mesh.
    internal static class OvenInputSupport
    {
        internal const string RootName="OvenInputSupport";
        internal static void Install(SwitchboardCabinet cabinet)
        {
            var shell=cabinet.transform.Find("SwitchboardModel/CompletedShell");
            if(shell==null || shell.Find(OvenInputPanel.RootName)==null)return;
            var root=new GameObject(RootName){layer=cabinet.gameObject.layer};root.transform.SetParent(shell,false);
            root.AddComponent<MeshFilter>();root.AddComponent<OvenInputSupportState>();
            root.AddComponent<MeshRenderer>().sharedMaterials=CabinetGeometry.Materials;
            root.AddComponent<MeshCollider>();
            Fit(cabinet);CabinetRearSurface.Restore(root.GetComponent<MeshRenderer>());
            cabinet.BuildStates[1].Colliders.Add(root.GetComponent<MeshCollider>());
            CabinetModel.SetBounds(cabinet);
        }

        internal static void Fit(Structure cabinet)
        {
            var shell=cabinet.transform.Find("SwitchboardModel/CompletedShell");
            if(shell==null)return;
            var support=shell.Find(RootName);var panel=shell.Find(OvenInputPanel.RootName);var box=shell.Find("NativeApcRearBox");
            if(support==null||panel==null||box==null)return;
            var panelMesh=panel.GetComponent<MeshFilter>()?.sharedMesh;var boxMesh=box.GetComponent<MeshFilter>()?.sharedMesh;
            if(panelMesh==null||boxMesh==null)return;
            var top=CabinetWallMount.TransformedBounds(panelMesh.bounds,shell.worldToLocalMatrix*panel.localToWorldMatrix);
            var bottom=NativeRearBox.BodyBounds(cabinet);
            float low=bottom.min.y,high=panel.localPosition.y-.0005f;
            if(high<=low)return;
            var vertices=new List<Vector3>();var indices=new List<int>();
            const int cornerSteps=6,edgeSteps=4;
            const int ringSize=4*(cornerSteps+1);
            float edge=Mathf.Min(.002f,(high-low)*.2f);
            // Full panel width from the box upward; a straight depth transition
            // reaches the complete panel footprint without a mushroom-shaped lip.
            float innerZ=Mathf.Max(bottom.min.z+.060f,Mathf.Min(top.max.z,bottom.max.z-.004f));
            float neckOuterZ=Mathf.Min(innerZ-.050f,bottom.max.z-.010f);
            float flareStart=Mathf.Max(low+edge+.001f,high-.060f);
            var levels=new List<Vector2>();
            for(int step=0;step<=edgeSteps;step++)
            {
                float angle=step*Mathf.PI*.5f/edgeSteps;
                levels.Add(new Vector2(low+edge*(1f-Mathf.Cos(angle)),edge*(1f-Mathf.Sin(angle))));
            }
            float rootStart=bottom.max.y;
            float rootEnd=Mathf.Min(bottom.max.y+.018f,flareStart-.004f);
            levels.Add(new Vector2(rootStart,0));
            for(int step=1;step<=6;step++)levels.Add(new Vector2(Mathf.Lerp(rootStart,rootEnd,(step-1)/5f),0));
            levels.Add(new Vector2(flareStart,0));
            for(int step=1;step<=6;step++)levels.Add(new Vector2(Mathf.Lerp(flareStart,high-edge,step/6f),0));
            for(int step=1;step<=edgeSteps;step++)
            {
                float angle=step*Mathf.PI*.5f/edgeSteps;
                levels.Add(new Vector2(high-edge+edge*Mathf.Sin(angle),edge*(1f-Mathf.Cos(angle))));
            }
            for(int levelIndex=0;levelIndex<levels.Count;levelIndex++)
            {
                var level=levels[levelIndex];
                float y=level.x,inset=level.y;
                float t=Mathf.Clamp01((y-rootStart)/(high-edge-rootStart));
                // Flat box shoulder with a hard shading edge at the tunnel root.
                float rootT=levelIndex<=edgeSteps+1?0f:1f;
                float cx=Mathf.Lerp(bottom.center.x,top.center.x,rootT);
                float width=Mathf.Lerp(bottom.size.x,top.size.x,rootT);
                float xmin=cx-width*.5f+inset,xmax=cx+width*.5f-inset;
                float zmin=Mathf.Lerp(bottom.min.z,Mathf.Lerp(neckOuterZ,top.min.z,t),rootT)+inset;
                float zmax=Mathf.Lerp(bottom.max.z,Mathf.Lerp(innerZ,top.max.z,t),rootT)-inset;
                float cornerRadius=.004f;
                float radius=Mathf.Min(cornerRadius-inset,Mathf.Min(xmax-xmin,zmax-zmin)*.25f);
                for(int corner=0;corner<4;corner++)
                {
                    float px=(corner==0||corner==3)?xmax-radius:xmin+radius;
                    float pz=corner<2?zmax-radius:zmin+radius;
                    for(int part=0;part<=cornerSteps;part++)
                    {
                        float theta=(corner*90f+part*90f/cornerSteps)*Mathf.Deg2Rad;
                        vertices.Add(new Vector3(px+radius*Mathf.Cos(theta),y,pz+radius*Mathf.Sin(theta)));
                    }
                }
            }
            int rings=levels.Count;
            for(int ring=0;ring<rings-1;ring++)
                for(int i=0;i<ringSize;i++)
                {
                    int a=ring*ringSize+i,b=ring*ringSize+(i+1)%ringSize,c=b+ringSize,d=a+ringSize;
                    indices.AddRange(new[]{a,c,b,a,d,c});
                }
            int cap=vertices.Count;vertices.Add(new Vector3(bottom.center.x,low,bottom.center.z));
            for(int i=0;i<ringSize;i++)indices.AddRange(new[]{cap,i,(i+1)%ringSize});
            // Split the planar shoulder from the vertical walls for normal calculation.
            // Shared positions keep the surface closed; separate normals prevent
            // a flat shoulder from looking like a rounded bulge under a flashlight.
            int shoulderFirst=(edgeSteps+1)*ringSize*6;
            var shoulderCopies=new Dictionary<int,int>();
            for(int i=shoulderFirst;i<shoulderFirst+ringSize*6;i++)
            {
                int original=indices[i];
                if(!shoulderCopies.TryGetValue(original,out int copy))
                {
                    copy=vertices.Count;vertices.Add(vertices[original]);shoulderCopies.Add(original,copy);
                }
                indices[i]=copy;
            }
            // No top cap across the panel's recessed connector.
            var state=support.GetComponent<OvenInputSupportState>();
            if(state.InstanceMesh==null)state.InstanceMesh=new Mesh{name="Switchboards.InputTransition"};
            var mesh=state.InstanceMesh;support.GetComponent<MeshFilter>().sharedMesh=mesh;mesh.Clear();mesh.SetVertices(vertices);mesh.subMeshCount=5;
            for(int i=0;i<5;i++)mesh.SetTriangles(i==CabinetRearSurface.Role?indices.ToArray():new int[0],i);
            mesh.RecalculateNormals();CabinetGeometry.ApplyNativeUv(mesh);CabinetRearSurface.ApplyUv(mesh);mesh.RecalculateBounds();
            var collider=support.GetComponent<MeshCollider>();collider.sharedMesh=null;collider.sharedMesh=mesh;
        }

        internal static void IncludeBounds(Structure cabinet,ref Bounds bounds)
        {
            var root=cabinet.transform.Find("SwitchboardModel/CompletedShell/"+RootName);
            var mesh=root==null?null:root.GetComponent<MeshFilter>()?.sharedMesh;
            if(mesh!=null)bounds.Encapsulate(CabinetWallMount.TransformedBounds(mesh.bounds,cabinet.transform.worldToLocalMatrix*root.localToWorldMatrix));
        }
    }
}
