using UnityEngine;
namespace ModularSwitchboards
{
    public sealed class DoorIsolatorView:MonoBehaviour
    {
        public DinBreaker Owner;
        public Transform Handle;
        private bool initialized;
        private float angle;
        private void Bind(){Owner=GetComponent<DinBreaker>();Handle=transform.Find("DoorIsolatorHandle");}
        private void Awake(){Bind();}
        private void OnEnable(){Bind();}
        private void LateUpdate()
        {
            if(Owner==null||Owner.gameObject!=gameObject||Handle==null||Handle.parent!=transform){Bind();initialized=false;}
            if(Owner==null||Handle==null)return;
            float target=DoorIsolatorControl.Angle(Owner.OnOff);
            if(!initialized){angle=target;initialized=true;}
            else angle=Mathf.MoveTowards(angle,target,360f*Mathf.Max(0,Time.deltaTime));
            Handle.localRotation=Quaternion.Euler(0,0,angle);
        }
    }
}
