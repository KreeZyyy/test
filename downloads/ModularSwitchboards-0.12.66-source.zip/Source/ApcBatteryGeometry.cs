using System;
using System.Collections.Generic;
using System.Linq;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Electrical;
using UnityEngine;

namespace ModularSwitchboards
{
    internal static class ApcBatteryGeometry
    {
        private static Mesh mesh;
        private static Material[] materials;
        private static MaterialPropertyBlock[] blocks;
        private static Slot nativeSlot;
        private static Matrix4x4 slotMatrix;
        private static Bounds selectedBounds,hitBounds;
        private static float scale;
        internal static readonly Quaternion Turn=Quaternion.identity;
        // Measured in the preserved APC export, then validated against the live prefab.
        // Whole triangles only: socket and gold contacts only; the APC backing plate and bolts are excluded.
        internal static bool Contains(Vector3 p)=>ApcBatteryRegion.Contains(p);
        internal static Vector3 Map(Vector3 p)=>ApcBatteryRegion.Map(p,selectedBounds.center,selectedBounds.min.z,scale);
        internal static void EnsureLoaded()
        {
            if(mesh!=null)return;
            var apc=WorldManager.Instance.SourcePrefabs.OfType<AreaPowerControl>().First(p=>p.PrefabName=="StructureAreaPowerControl");
            nativeSlot=apc.BatterySlot;
            var renderer=apc.GetComponent<MeshRenderer>();var original=renderer.GetComponent<MeshFilter>().sharedMesh;
            CabinetGeometry.ReadNativeMesh(original,out var vertices,out var uv,out var groups);
            var frame=Matrix4x4.Rotate(CabinetModel.FrontSign<0?Quaternion.Euler(0,180,0):Quaternion.identity)*apc.transform.worldToLocalMatrix;
            var matrix=frame*renderer.transform.localToWorldMatrix;
            for(int i=0;i<vertices.Length;i++)vertices[i]=matrix.MultiplyPoint3x4(vertices[i]);
            var selected=new List<int>[groups.Length];bool first=true;int count=0;
            for(int role=0;role<groups.Length;role++)
            {
                selected[role]=new List<int>();
                for(int i=0;i<groups[role].Length;i+=3)
                {
                    int a=groups[role][i],b=groups[role][i+1],c=groups[role][i+2];
                    if(!Contains(vertices[a])||!Contains(vertices[b])||!Contains(vertices[c]))continue;
                    selected[role].AddRange(matrix.determinant<0?new[]{a,c,b}:new[]{a,b,c});count++;
                    foreach(int k in new[]{a,b,c}){if(first){selectedBounds=new Bounds(vertices[k],Vector3.zero);first=false;}else selectedBounds.Encapsulate(vertices[k]);}
                }
            }
            if(count<100||selectedBounds.size.y<.08f||selectedBounds.size.x<.08f)throw new InvalidOperationException("Native APC battery bay does not match measured socket geometry");
            slotMatrix=frame*nativeSlot.Location.localToWorldMatrix;
            // Measure the rear envelope using original compatible cell meshes in
            // the original APC slot pose. Keep that envelope clear of the back wall.
            float rear=float.PositiveInfinity;
            foreach(var cell in WorldManager.Instance.SourcePrefabs.OfType<Assets.Scripts.Objects.Items.BatteryCell>())
            {
                if(nativeSlot.SpecificTypePrefabHashes!=null&&nativeSlot.SpecificTypePrefabHashes.Length>0&&!nativeSlot.SpecificTypePrefabHashes.Contains(cell.PrefabHash))continue;
                foreach(var filter in cell.GetComponentsInChildren<MeshFilter>(true))
                {
                    if(filter.sharedMesh==null)continue;var bounds=filter.sharedMesh.bounds;
                    var pose=slotMatrix*cell.transform.worldToLocalMatrix*filter.transform.localToWorldMatrix;
                    foreach(float x in new[]{-.5f,.5f})foreach(float y in new[]{-.5f,.5f})foreach(float z in new[]{-.5f,.5f})
                        rear=Mathf.Min(rear,pose.MultiplyPoint3x4(bounds.center+Vector3.Scale(bounds.size,new Vector3(x,y,z))).z);
                }
            }
            if(!float.IsInfinity(rear))ApcBatteryRegion.RearSource=rear;
            scale=ApcBatteryRegion.FitScale(selectedBounds.size);
            var points=new List<Vector3>();var texcoords=new List<Vector2>();var indices=new List<int>[selected.Length];
            for(int role=0;role<selected.Length;role++)
            {
                indices[role]=new List<int>();foreach(int index in selected[role]){indices[role].Add(points.Count);points.Add(Map(vertices[index]));texcoords.Add(uv[index]);}
            }
            mesh=new Mesh{name="Switchboards.NativeApcBatteryBay"};mesh.SetVertices(points);mesh.SetUVs(0,texcoords);mesh.subMeshCount=indices.Length;
            for(int role=0;role<indices.Length;role++)mesh.SetTriangles(indices[role],role);
            mesh.RecalculateNormals();mesh.RecalculateTangents();mesh.RecalculateBounds();materials=renderer.sharedMaterials;
            var global=new MaterialPropertyBlock();renderer.GetPropertyBlock(global);blocks=new MaterialPropertyBlock[materials.Length];
            for(int i=0;i<blocks.Length;i++){var block=new MaterialPropertyBlock();renderer.GetPropertyBlock(block,i);blocks[i]=block.isEmpty?global:block;}
            slotMatrix=frame*nativeSlot.Location.localToWorldMatrix;
            hitBounds=new Bounds(SocketCenter,new Vector3(.016f,.027f,.040f));
            if(nativeSlot.Collider!=null)
            {
                var box=nativeSlot.Collider;var colliderMatrix=frame*box.transform.localToWorldMatrix;bool firstCorner=true;
                foreach(float x in new[]{-.5f,.5f})foreach(float y in new[]{-.5f,.5f})foreach(float z in new[]{-.5f,.5f})
                {
                    var point=Map(colliderMatrix.MultiplyPoint3x4(box.center+Vector3.Scale(box.size,new Vector3(x,y,z))));
                    if(firstCorner){hitBounds=new Bounds(point,Vector3.zero);firstCorner=false;}else hitBounds.Encapsulate(point);
                }
            }
            // Give the visible socket its own front interaction volume. The original
            // APC collider can be recessed after fitting and lose the ray to the
            // module body; then the game's native slot tooltip is never selected.
            var socket=mesh.bounds;
            hitBounds=new Bounds(new Vector3(socket.center.x,socket.center.y,ApcBatteryRegion.Front(scale)+.004f),
                new Vector3(socket.size.x,socket.size.y,.004f));
            Debug.Log("[Modular Switchboards] Native APC battery bay: "+count+" triangles, original UV/materials; native battery slot pose retained.");
        }
        internal static Mesh Install(Transform parent)
        {
            EnsureLoaded();var go=new GameObject("NativeApcBatteryBay"){layer=parent.gameObject.layer};go.transform.SetParent(parent,false);
            go.AddComponent<MeshFilter>().sharedMesh=mesh;var renderer=go.AddComponent<MeshRenderer>();
            var local=(Material[])materials.Clone();
            for(int i=0;i<local.Length;i++)
            {
                if(local[i]!=null&&local[i].name.IndexOf("White",StringComparison.OrdinalIgnoreCase)>=0)
                    local[i]=SocketNativeMaterials.GreyWhite(local[i]);
                renderer.SetPropertyBlock(blocks[i],i);
            }
            renderer.sharedMaterials=local;return mesh;
        }
        internal static Slot CreateSlot(DinBreaker module,Transform model,BoxCollider hit,Interactable action)
        {
            EnsureLoaded();var location=new GameObject("NativeBatterySlot").transform;location.SetParent(module.transform,false);
            location.localPosition=Vector3.Scale(Map(slotMatrix.MultiplyPoint3x4(Vector3.zero)),DinBreakerModel.VisualScale);
            location.localRotation=Turn*slotMatrix.rotation;location.localScale=slotMatrix.lossyScale*scale;
            return new Slot{Parent=module,StringKey=nativeSlot.StringKey,StringHash=nativeSlot.StringHash,Type=nativeSlot.Type,SpecificTypePrefabHashes=(int[])(nativeSlot.SpecificTypePrefabHashes??new int[0]).Clone(),
                Location=location,RealWorldScale=nativeSlot.RealWorldScale,ScaleMultiplier=nativeSlot.ScaleMultiplier,
                HidesOccupant=false,OccupantCastsShadows=nativeSlot.OccupantCastsShadows,UseInternalAtmosphere=nativeSlot.UseInternalAtmosphere,
                IsSwappable=nativeSlot.IsSwappable,AllowDragging=nativeSlot.AllowDragging,IsInteractable=nativeSlot.IsInteractable,Size=nativeSlot.Size,Action=InteractableType.Slot1,Collider=hit,Interactable=action};
        }
        internal static float FaceDepth{get{EnsureLoaded();return ApcBatteryRegion.Front(scale);}}
        internal static Bounds HitBounds{get{EnsureLoaded();return hitBounds;}}
        internal static Vector3 SocketCenter=>Map(new Vector3(-.0968f,-.115f,.170f));
    }
}
