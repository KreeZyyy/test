using System;
using System.Collections.Generic;
using System.Linq;
using Assets.Scripts;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Electrical;
using Assets.Scripts.GridSystem;
using UnityEngine;
using UnityEngine.Rendering;

namespace ModularSwitchboards
{
    internal static class ExternalPortLayout
    {
        internal static readonly Vector3[] Positions={new Vector3(0,.28f,-CabinetModel.MountOffset),new Vector3(-.265f,-.28f,-CabinetModel.MountOffset),new Vector3(.265f,-.28f,-CabinetModel.MountOffset)};
        internal static readonly Vector3[] Directions={Vector3.up,Vector3.down,Vector3.down};
        internal static readonly ConnectionRole[] Roles={ConnectionRole.Input,ConnectionRole.Output,ConnectionRole.Output2};
    }

    public sealed class NativePortSurface : MonoBehaviour
    {
        public int TemplateIndex;
        private sealed class Surface {internal Material[] Materials;internal MaterialPropertyBlock[] Blocks;}
        private static readonly List<Surface> Templates=new List<Surface>();
        internal static void Capture(Renderer source,MeshRenderer destination)
        {
            var materials=source.sharedMaterials;var blocks=new MaterialPropertyBlock[materials.Length];
            var global=new MaterialPropertyBlock();source.GetPropertyBlock(global);
            for(int i=0;i<blocks.Length;i++){var block=new MaterialPropertyBlock();source.GetPropertyBlock(block,i);blocks[i]=block.isEmpty?global:block;}
            var marker=destination.gameObject.AddComponent<NativePortSurface>();marker.TemplateIndex=Templates.Count;
            Templates.Add(new Surface{Materials=materials,Blocks=blocks});marker.Restore();
        }
        internal void Restore()
        {
            if(TemplateIndex<0||TemplateIndex>=Templates.Count)return;
            var renderer=GetComponent<MeshRenderer>();var surface=Templates[TemplateIndex];renderer.sharedMaterials=surface.Materials;
            for(int i=0;i<surface.Blocks.Length;i++)renderer.SetPropertyBlock(surface.Blocks[i],i);
        }
    }

    internal static class ExternalCablePorts
    {
        private sealed class Part {internal Mesh Mesh;internal MeshRenderer Source;}
        private sealed class Template {internal Connection Source;internal bool ForwardInward;internal Matrix4x4 SourceFrame;internal List<Part> Parts=new List<Part>();}
        private static Template Read(AreaPowerControl apc,Connection connection)
        {
            if(connection?.Transform==null)throw new InvalidOperationException("APC cable connection transform unavailable");
            var center=apc.transform.TransformPoint(apc.Bounds.center);
            var result=new Template{Source=connection,ForwardInward=Vector3.Dot(connection.Transform.forward,center-connection.Transform.position)>0f};
            var frame=Matrix4x4.TRS(connection.Transform.position,connection.Transform.rotation,Vector3.one).inverse;
            var view=frame.MultiplyVector(apc.transform.forward*CabinetModel.FrontSign);view.z=0f;
            if(view.sqrMagnitude>.001f)frame=Matrix4x4.Rotate(Quaternion.Inverse(Quaternion.LookRotation(Vector3.forward,view.normalized)))*frame;
            result.SourceFrame=frame;
            // Use the original connector hit volume, not a guessed origin-centred crop.
            Bounds? region=null;
            if(connection.Collider is BoxCollider sourceBox)
            {
                var nativeBounds=CabinetWallMount.TransformedBounds(new Bounds(sourceBox.center,sourceBox.size),frame*sourceBox.transform.localToWorldMatrix);
                nativeBounds.Expand(.012f);region=nativeBounds;
            }
            var descendants=connection.Transform.GetComponentsInChildren<MeshRenderer>(true)
                .Where(r=>r!=connection.HelperRenderer && r.GetComponent<MeshFilter>()?.sharedMesh!=null).ToArray();
            bool isolated=connection.Transform!=apc.transform && descendants.Length>0;
            var renderers=isolated?descendants:apc.GetComponentsInChildren<MeshRenderer>(true)
                .Where(r=>r!=connection.HelperRenderer && r.name!="Door" && r.name!="MasterLever" && r.name.IndexOf("Destroyed",StringComparison.OrdinalIgnoreCase)<0).ToArray();
            foreach(var renderer in renderers)
            {
                var original=renderer.GetComponent<MeshFilter>()?.sharedMesh;if(original==null)continue;
                CabinetGeometry.ReadNativeMesh(original,out var points,out var uv,out var triangles);
                var matrix=frame*renderer.transform.localToWorldMatrix;
                for(int i=0;i<points.Length;i++)points[i]=matrix.MultiplyPoint3x4(points[i]);
                var selected=new List<int>[triangles.Length];int count=0;
                for(int sub=0;sub<triangles.Length;sub++)
                {
                    selected[sub]=new List<int>();
                    for(int t=0;t<triangles[sub].Length;t+=3)
                    {
                        int a=triangles[sub][t],b=triangles[sub][t+1],c=triangles[sub][t+2];
                        if(!isolated && (!InConnector(points[a],region)||!InConnector(points[b],region)||!InConnector(points[c],region)))continue;
                        selected[sub].Add(a);selected[sub].Add(matrix.determinant<0?c:b);selected[sub].Add(matrix.determinant<0?b:c);count++;
                    }
                }
                if(count==0)continue;
                var usedIds=selected.SelectMany(s=>s).Distinct().ToArray();
                var map=new Dictionary<int,int>();for(int i=0;i<usedIds.Length;i++)map[usedIds[i]]=i;
                var mesh=new Mesh{name="Switchboards.NativeAPCPort."+renderer.name};
                mesh.vertices=usedIds.Select(i=>points[i]).ToArray();mesh.uv=usedIds.Select(i=>uv[i]).ToArray();mesh.subMeshCount=selected.Length;
                for(int i=0;i<selected.Length;i++)mesh.SetTriangles(selected[i].Select(id=>map[id]).ToArray(),i);
                mesh.RecalculateNormals();mesh.RecalculateTangents();mesh.RecalculateBounds();
                result.Parts.Add(new Part{Mesh=mesh,Source=renderer});
            }
            if(result.Parts.Count==0 && connection.HelperRenderer is MeshRenderer helper)
            {
                var original=helper.GetComponent<MeshFilter>()?.sharedMesh;
                if(original!=null)
                {
                    CabinetGeometry.ReadNativeMesh(original,out var points,out var uv,out var triangles);
                    var matrix=frame*helper.transform.localToWorldMatrix;
                    for(int i=0;i<points.Length;i++)points[i]=matrix.MultiplyPoint3x4(points[i]);
                    var mesh=new Mesh{name="Switchboards.NativeCableConnectorHelper"};mesh.vertices=points;mesh.uv=uv;mesh.subMeshCount=triangles.Length;
                    for(int i=0;i<triangles.Length;i++)mesh.SetTriangles(triangles[i],i);
                    mesh.RecalculateNormals();mesh.RecalculateTangents();mesh.RecalculateBounds();
                    result.Parts.Add(new Part{Mesh=mesh,Source=helper});
                    Debug.LogWarning("[Modular Switchboards] APC port uses native helper geometry; inspect external connector appearance.");
                }
            }
            if(result.Parts.Count==0)throw new InvalidOperationException("No native APC cable connector geometry found");
            Debug.Log("[Modular Switchboards] Native APC connector captured: "+connection.ConnectionRole+"; parts="+result.Parts.Count+"; isolated="+isolated+"; native axis="+connection.Transform.forward+"; forward inward="+result.ForwardInward);
            return result;
        }
        private static bool InConnector(Vector3 p,Bounds? region)=>region.HasValue?region.Value.Contains(p):Mathf.Abs(p.x)<.085f && Mathf.Abs(p.y)<.085f && p.z>-.115f && p.z<.055f;

        internal static bool TryInstall(SwitchboardCabinet cabinet)
        {
            var oldPorts=cabinet.OpenEnds;var oldBody=cabinet.PortBodyGrids;float oldPower=cabinet.UsedPower;
            var oldColliders=new List<Collider>(cabinet.BuildStates[1].Colliders);
            try {Install(cabinet);return true;}
            catch(Exception ex)
            {
                var root=cabinet.transform.Find("SwitchboardModel/CompletedShell/ExternalCablePorts");
                if(root!=null)UnityEngine.Object.DestroyImmediate(root.gameObject);
                cabinet.OpenEnds=oldPorts;cabinet.PortBodyGrids=oldBody;cabinet.UsedPower=oldPower;
                cabinet.BuildStates[1].Colliders=oldColliders;CabinetModel.SetBounds(cabinet);
                Debug.LogError("[Modular Switchboards] External APC ports unavailable; cabinet preserved: "+ex);
                return false;
            }
        }
        private static void Install(SwitchboardCabinet cabinet)
        {
            var apc=WorldManager.Instance.SourcePrefabs.OfType<AreaPowerControl>().FirstOrDefault(p=>p.PrefabName=="StructureAreaPowerControl")
                ?? WorldManager.Instance.SourcePrefabs.OfType<AreaPowerControl>().FirstOrDefault();
            if(apc==null)throw new InvalidOperationException("Native APC unavailable for external cable ports");
            var input=Read(apc,apc.InputConnection);var output=Read(apc,apc.OutputConnection);
            cabinet.PortBodyGrids=(Grid3[])cabinet.GetLocalSmallGridBounds();
            var shell=cabinet.transform.Find("SwitchboardModel/CompletedShell");
            var root=new GameObject("ExternalCablePorts"){layer=cabinet.gameObject.layer};root.transform.SetParent(shell,false);
            cabinet.OpenEnds=new List<Connection>();cabinet.UsedPower=0f;
            for(int i=0;i<3;i++)
            {
                var template=i==0?input:output;
                var go=new GameObject("NativeCablePort_"+ExternalPortLayout.Roles[i]){layer=cabinet.gameObject.layer};go.transform.SetParent(root.transform,false);
                go.transform.localPosition=ExternalPortLayout.Positions[i];go.transform.localRotation=Quaternion.LookRotation(ExternalPortLayout.Directions[i]*(template.ForwardInward?-1f:1f),Vector3.forward);
                Renderer helper=null;
                foreach(var part in template.Parts)
                {
                    var visual=new GameObject("NativeCablePortSurface"){layer=cabinet.gameObject.layer};visual.transform.SetParent(go.transform,false);
                    visual.AddComponent<MeshFilter>().sharedMesh=part.Mesh;
                    var renderer=visual.AddComponent<MeshRenderer>();NativePortSurface.Capture(part.Source,renderer);
                    renderer.lightProbeUsage=LightProbeUsage.BlendProbes;renderer.reflectionProbeUsage=ReflectionProbeUsage.BlendProbes;
                    renderer.shadowCastingMode=ShadowCastingMode.On;renderer.receiveShadows=true;
                    if(part.Source==template.Source.HelperRenderer)helper=renderer;
                }
                var hit=go.AddComponent<BoxCollider>();
                if(template.Source.Collider is BoxCollider box)
                {
                    var matrix=template.SourceFrame*box.transform.localToWorldMatrix;
                    var bounds=CabinetWallMount.TransformedBounds(new Bounds(box.center,box.size),matrix);hit.center=bounds.center;hit.size=bounds.size;
                }
                else {hit.center=new Vector3(0,0,-.02f);hit.size=new Vector3(.07f,.07f,.08f);}
                cabinet.OpenEnds.Add(new Connection(cabinet){Transform=go.transform,Collider=hit,HelperRenderer=helper,ConnectionType=cabinet.IsStructureCompleted?NetworkType.Power:NetworkType.None,ConnectionRole=ExternalPortLayout.Roles[i]});
                cabinet.BuildStates[1].Colliders.Add(hit);
            }
            CabinetModel.SetBounds(cabinet);
            Debug.Log("[Modular Switchboards] External ports installed: top Input; lower Output/Output2; independent cells, no internal power bridge.");
        }
        internal static void InstallRearBody(SwitchboardCabinet cabinet)
        {
            // Fixed dark rear casing extends into the wall; the front and mounting plate stay put.
            var vertices=new List<Vector3>();var normals=new List<Vector3>();var indices=new List<int>();
            float depth=CabinetModel.MountOffset;
            RoundedGeometry.Box(vertices,normals,indices,new Vector3(0,0,-depth*.5f),new Vector3(.396f,.496f,depth+.002f),.008f);
            foreach(float side in new[]{-1f,1f})RoundedGeometry.Box(vertices,normals,indices,new Vector3(side*.23f,-.238f,-depth),new Vector3(.13f,.024f,.06f),.003f);
            var supportMesh=new Mesh{name="Switchboards.RearCableCasing"};supportMesh.SetVertices(vertices);supportMesh.SetNormals(normals);supportMesh.subMeshCount=5;
            for(int i=0;i<5;i++)supportMesh.SetTriangles(i==4?indices.ToArray():new int[0],i);
            CabinetGeometry.ApplyNativeUv(supportMesh);supportMesh.RecalculateBounds();
            var support=new GameObject("RearCableCasing"){layer=cabinet.gameObject.layer};support.transform.SetParent(cabinet.transform.Find("SwitchboardModel/CompletedShell"),false);
            support.AddComponent<MeshFilter>().sharedMesh=supportMesh;support.AddComponent<MeshRenderer>().sharedMaterials=CabinetGeometry.Materials;
            var supportCollider=support.AddComponent<MeshCollider>();supportCollider.sharedMesh=supportMesh;cabinet.BuildStates[1].Colliders.Add(supportCollider);
            CabinetModel.SetBounds(cabinet);
        }
        internal static void IncludeBounds(Structure cabinet,ref Bounds bounds)
        {
            foreach(var name in new[]{"ExternalCablePorts","RearCableCasing"})
            {
            var root=cabinet.transform.Find("SwitchboardModel/CompletedShell/"+name);if(root==null)continue;
            foreach(var filter in root.GetComponentsInChildren<MeshFilter>(true))
                if(filter.sharedMesh!=null)bounds.Encapsulate(CabinetWallMount.TransformedBounds(filter.sharedMesh.bounds,cabinet.transform.worldToLocalMatrix*filter.transform.localToWorldMatrix));
            }
        }
    }
}
