$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Runtime.WindowsRuntime
[Windows.Media.SpeechSynthesis.SpeechSynthesizer, Windows.Media.SpeechSynthesis, ContentType=WindowsRuntime] | Out-Null
[Windows.Media.SpeechSynthesis.SpeechSynthesisStream, Windows.Media.SpeechSynthesis, ContentType=WindowsRuntime] | Out-Null
[Windows.Storage.Streams.DataReader, Windows.Storage.Streams, ContentType=WindowsRuntime] | Out-Null
function Await-Operation($operation, [Type]$resultType) {
    $method = [System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
        $_.Name -eq 'AsTask' -and $_.IsGenericMethodDefinition -and
        $_.GetGenericArguments().Count -eq 1 -and $_.GetParameters().Count -eq 1 -and
        $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1'
    } | Select-Object -First 1
    $task = $method.MakeGenericMethod($resultType).Invoke($null, @($operation))
    return $task.GetAwaiter().GetResult()
}
$synth = $null; $stream = $null; $reader = $null
try {
    $inputData = [IO.File]::ReadAllText($env:STATION_ASSISTANT_SPEECH_INPUT, [Text.Encoding]::UTF8) | ConvertFrom-Json
    $voices = [Windows.Media.SpeechSynthesis.SpeechSynthesizer]::AllVoices
    $voice = $voices | Where-Object { $_.Language -eq 'cs-CZ' -and $_.DisplayName.IndexOf([string]$inputData.voice, [StringComparison]::OrdinalIgnoreCase) -ge 0 } | Select-Object -First 1
    if ($null -eq $voice) { $voice = $voices | Where-Object { $_.Language -eq 'cs-CZ' } | Select-Object -First 1 }
    if ($null -eq $voice) { throw 'No Czech Windows voice installed.' }
    $synth = New-Object Windows.Media.SpeechSynthesis.SpeechSynthesizer
    $synth.Voice = $voice
    $stream = Await-Operation ($synth.SynthesizeTextToStreamAsync([string]$inputData.text)) ([Windows.Media.SpeechSynthesis.SpeechSynthesisStream])
    if ($stream.Size -gt 16777216) { throw 'Speech output too large.' }
    $reader = [Windows.Storage.Streams.DataReader]::new($stream)
    $null = Await-Operation ($reader.LoadAsync([uint32]$stream.Size)) ([uint32])
    $bytes = New-Object byte[] ([int]$stream.Size)
    $reader.ReadBytes($bytes)
    [IO.File]::WriteAllBytes($env:STATION_ASSISTANT_SPEECH_OUTPUT, $bytes)
} catch {
    # Never print text, keys, paths, or raw exception details.
    exit 1
} finally {
    if ($null -ne $reader) { $reader.Dispose() }
    if ($null -ne $stream) { $stream.Dispose() }
    if ($null -ne $synth) { $synth.Dispose() }
}
