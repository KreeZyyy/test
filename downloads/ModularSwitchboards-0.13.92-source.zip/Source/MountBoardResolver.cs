using System.Linq;
using Assets.Scripts;
using Assets.Scripts.Inventory;
using Assets.Scripts.Objects;
using LibConstruct;
using HarmonyLib;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class MountBoardResolver
    {
        private static readonly System.Reflection.FieldInfo MaxDistance=AccessTools.Field(typeof(PlacementBoard),"MaxCursorDistance");
        internal static void Resolve(CursorManager manager)
        {
            if(manager==null||GameManager.IsBatchMode||InventoryManager.CurrentMode!=InventoryManager.Mode.Placement||
                !(InventoryManager.ActiveHandSlot?.Get() is MultiConstructor kit)||!SwitchboardKitModel.IsKit(kit))return;
            var cursor=InventoryManager.ConstructionCursor;
            if(!(cursor is IPlacementBoardStructure mount)||!cursor.IsCursor)return;
            bool matches=(cursor is SwitchboardLabel||cursor is DoorLabel)?kit.PrefabName==SwitchboardsMod.LabelKitName:
                cursor is DinRail?kit.PrefabName==SwitchboardsMod.RailKitName:
                cursor is DinBreaker module?kit.PrefabName==(module.IsDoorPart?SwitchboardsMod.DoorKitName:SwitchboardsMod.BreakerKitName):false;
            if(!matches)return;
            if(MountPlacement.TryLockedGrid(cursor,mount.Board,out _))return;
            var hit=manager.CursorTargetCollider;
            if(hit==null||!(MaxDistance?.GetValue(null) is float limit)||CursorManager.CursorHit.distance>limit)return;
            var target=hit.GetComponentInParent<Thing>()??manager.FoundThing;
            var host=hit.GetComponentInParent<SwitchboardCabinet>()??HostOf(target);
            if(host==null||host.IsCursor||!host.IsStructureCompleted)return;
            var board=ForTarget(cursor,target,host,hit);
            if(board==null||!MountPlacement.Usable(board)||board.EquivalentStructure(cursor)==null)return;
            PlacementBoard.CursorBoard=board;PlacementBoard.CursorGrid=board.WorldToGrid(CursorManager.CursorHit.point);PlacementBoard.CursorRotation=0;
            mount.Board=board;
            if(cursor is DinBreaker bridge&&bridge.IsDoorBridge)
            {
                var grid=PlacementBoard.CursorGrid;grid=new Assets.Scripts.GridSystem.Grid3(0,DoorModuleLayout.SnapSlot(grid.y,CabinetShape.MinBridgeY(host.PrefabName),CabinetShape.MaxBridgeY(host.PrefabName)),0);
                PlacementBoard.CursorGrid=grid;cursor.transform.SetPositionAndRotation(board.GridToWorld(grid),board.IndexToRotation(0));
            }
        }
        private static SwitchboardCabinet HostOf(Thing target)
        {
            if(target is SwitchboardCabinet host)return host;
            if(target is DinBreaker module)return CabinetWiring.CabinetOf(module);
            if(target is DinRail rail)return rail.Board?.PrimaryHost as SwitchboardCabinet;
            if(target is InnerCoverModule cover)return cover.Host;
            if(target is SwitchboardLabel label)return label.Cover?.Host;
            if(target is DoorLabel doorLabel)return doorLabel.Board?.PrimaryHost as SwitchboardCabinet;
            return null;
        }
        private static PlacementBoard ForTarget(Structure cursor,Thing target,SwitchboardCabinet host,Collider hit)
        {
            if(cursor is SwitchboardLabel)
            {
                // A cover is both a mounted structure and a host for labels.
                // The native fallback takes cover.Board (its cabinet mounting
                // board), while this construction needs cover.Labels.
                var cover=target as InnerCoverModule;
                if(target is SwitchboardLabel label)cover=label.Cover;
                if(cover==null&&((target is DinBreaker module&&!module.IsDoorPart)||
                    (target==host&&!DoorHit(host,hit)&&host.Wiring.ContainsInteractionPoint(CursorManager.CursorHit.point))))
                    cover=host.CoverBoard?.Structures.OfType<InnerCoverModule>().FirstOrDefault(c=>!c.IsCursor&&c.IsStructureCompleted);
                return cover!=null&&cover.Host==host?cover.Labels:null;
            }
            if(cursor is DinRail)return DoorHit(host,hit)?null:host.RailBoard;
            if(cursor is DinBreaker part)
            {
                if(part.IsDoorBridge)return CabinetShape.Medium(host.PrefabName)&&host.transform.Find("SwitchboardModel/CompletedShell").InverseTransformPoint(CursorManager.CursorHit.point).x>0?host.RightBridgeBoard:host.BridgeBoard;
                if(part.IsDoorPart)return DoorHit(host,hit)?(RightHit(host,hit)?host.RightDoorBoard:host.DoorBoard):null;
                if(target is DinRail rail)return rail.Modules;
                if(target is DinBreaker module&&!module.IsDoorPart)return module.Board as DinModuleBoard;
            }
            if(cursor is DoorLabel)return DoorHit(host,hit)?(RightHit(host,hit)?host.RightDoorLabels:host.DoorLabels):null;
            return null;
        }
        private static bool RightHit(SwitchboardCabinet host,Collider hit)
        {var right=host.transform.Find("SwitchboardModel/CompletedShell/RightDoorHinge");return right!=null&&hit.transform.IsChildOf(right);}
        private static bool DoorHit(SwitchboardCabinet host,Collider hit)
        {
            var hinge=host.transform.Find("SwitchboardModel/CompletedShell/DoorHinge");
            return hinge!=null&&hit.transform.IsChildOf(hinge)||RightHit(host,hit);
        }
    }
}
