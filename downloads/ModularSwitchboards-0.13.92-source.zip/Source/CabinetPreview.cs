using System.Collections.Generic;
using UnityEngine;
using Assets.Scripts.UI;
namespace ModularSwitchboards
{
    internal static class CabinetPreview
    {
        internal static Mesh Build(Mesh frame,Matrix4x4 transform,float height)
        {
            var vertices=new List<Vector3>();var triangles=new List<int>();
            foreach(var p in frame.vertices)vertices.Add(transform.MultiplyPoint3x4(p));
            for(int s=0;s<frame.subMeshCount;s++)triangles.AddRange(frame.GetTriangles(s));
            // A filled upward arrow belongs only to the independent construction ghost.
            float length=Mathf.Min(.13f,height*.26f),width=length*.6f,y=height*.5f-.04f;
            var arrow=new[]{new Vector3(0,y,.034f),new Vector3(-width*.5f,y-length*.4f,.034f),new Vector3(-width*.18f,y-length*.4f,.034f),new Vector3(-width*.18f,y-length,.034f),new Vector3(width*.18f,y-length,.034f),new Vector3(width*.18f,y-length*.4f,.034f),new Vector3(width*.5f,y-length*.4f,.034f)};
            int start=vertices.Count;foreach(var p in arrow)vertices.Add(transform.MultiplyPoint3x4(p));
            foreach(var i in new[]{0,1,2,0,2,5,0,5,6,2,3,4,2,4,5})triangles.Add(start+i);
            var mesh=new Mesh{name="Switchboards.FrameWithUpArrow"};mesh.SetVertices(vertices);mesh.SetTriangles(triangles,0);mesh.RecalculateNormals();mesh.RecalculateBounds();return mesh;
        }
        internal static void Install(SwitchboardCabinet host)
        {
            var model=host.transform.Find("SwitchboardModel");var frame=model.Find("Frame").GetComponent<MeshFilter>().sharedMesh;
            var wire=host.Blueprint.GetComponent<Wireframe>();var old=wire.BlueprintMeshFilter.sharedMesh;
            var ghost=Build(frame,Matrix4x4.TRS(model.localPosition,model.localRotation,Vector3.one),CabinetShape.Height(host.PrefabName));
            CabinetPortPreview.Append(host,ghost);
            wire.BlueprintMeshFilter.sharedMesh=ghost;wire.BlueprintBounds=ghost.bounds;
            if(old!=null&&old!=frame)UnityEngine.Object.DestroyImmediate(old);
        }
    }
}
