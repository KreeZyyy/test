using System.Collections.Generic;using UnityEngine;namespace ModularSwitchboards {static class CabinetPortPreview {        internal static void Add(List<Vector3> vertices,List<int> triangles,Vector3 point,Vector3 outward,bool input)
        {
            var side=new Vector3(outward.y,-outward.x,0);
            // Arrow points into Input and out of each Output.
            var direction=input?-outward:outward;
            var center=point+outward*.075f;
            Line(vertices,triangles,center-direction*.027f,center+direction*.027f,.0025f);
            Line(vertices,triangles,center+direction*.027f,center+direction*.006f+side*.016f,.0025f);
            Line(vertices,triangles,center+direction*.027f,center+direction*.006f-side*.016f,.0025f);
            // Upright lightning bolt and a three-node data/network pictogram.
            var power=center+side*.065f;
            var bolt=new[]{new Vector3(.003f,.036f,0),new Vector3(-.022f,-.004f,0),new Vector3(-.002f,-.004f,0),new Vector3(-.008f,-.036f,0),new Vector3(.024f,.009f,0),new Vector3(.003f,.009f,0)};
            for(int i=0;i<bolt.Length;i++)Line(vertices,triangles,power+bolt[i],power+bolt[(i+1)%bolt.Length],.002f);
            var data=center-side*.065f;
            Line(vertices,triangles,data+new Vector3(0,.018f,0),data,.002f);
            Line(vertices,triangles,data+new Vector3(-.024f,0,0),data+new Vector3(.024f,0,0),.002f);
            foreach(var p in new[]{new Vector3(0,.025f,0),new Vector3(-.024f,-.009f,0),new Vector3(.024f,-.009f,0)})
                Box(vertices,triangles,data+p,.014f,.014f);
        }
        private static void Box(List<Vector3> v,List<int> t,Vector3 center,float width,float height)
        {
            var p=new[]{center+new Vector3(-width/2,-height/2,0),center+new Vector3(width/2,-height/2,0),center+new Vector3(width/2,height/2,0),center+new Vector3(-width/2,height/2,0)};
            for(int i=0;i<4;i++)Line(v,t,p[i],p[(i+1)%4],.002f);
        }
        private static void Line(List<Vector3> v,List<int> t,Vector3 a,Vector3 b,float width)
        {
            var d=b-a;var n=new Vector3(-d.y,d.x,0).normalized*(width*.5f);int s=v.Count;
            v.AddRange(new[]{a+n,a-n,b-n,b+n});
            // Both sides remain visible when rolling/flipping a wall preview.
            foreach(int i in new[]{0,1,2,0,2,3,2,1,0,3,2,0})t.Add(s+i);
        }
    }
}
