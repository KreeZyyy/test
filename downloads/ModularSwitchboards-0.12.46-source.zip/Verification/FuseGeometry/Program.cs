using System;using System.Linq;using System.Collections.Generic;using UnityEngine;using ModularSwitchboards;
namespace UnityEngine {
 public struct Vector3{public float x,y,z;public Vector3(float x,float y,float z){this.x=x;this.y=y;this.z=z;}public static Vector3 one=>new(1,1,1);public static Vector3 right=>new(1,0,0);public static Vector3 left=>new(-1,0,0);public static Vector3 up=>new(0,1,0);public static Vector3 down=>new(0,-1,0);public static Vector3 forward=>new(0,0,1);public static Vector3 back=>new(0,0,-1);public static Vector3 operator *(Vector3 a,float b)=>new(a.x*b,a.y*b,a.z*b);public static Vector3 operator +(Vector3 a,Vector3 b)=>new(a.x+b.x,a.y+b.y,a.z+b.z);public static Vector3 operator -(Vector3 a,Vector3 b)=>new(a.x-b.x,a.y-b.y,a.z-b.z);public Vector3 normalized{get{float d=MathF.Sqrt(x*x+y*y+z*z);return new(x/d,y/d,z/d);}}public static Vector3 Cross(Vector3 a,Vector3 b)=>new(a.y*b.z-a.z*b.y,a.z*b.x-a.x*b.z,a.x*b.y-a.y*b.x);}
 public static class Mathf{public const float PI=MathF.PI,Deg2Rad=MathF.PI/180;public static float Abs(float n)=>MathF.Abs(n);public static float Min(float a,float b)=>MathF.Min(a,b);public static float Clamp(float n,float a,float b)=>Math.Clamp(n,a,b);public static float Cos(float n)=>MathF.Cos(n);public static float Sin(float n)=>MathF.Sin(n);}
 public class Mesh{public string name;public List<Vector3> V,N;public int subMeshCount;public Dictionary<int,int[]> T=new();public void SetVertices(List<Vector3> v)=>V=v;public void SetNormals(List<Vector3> n)=>N=n;public void SetTriangles(List<int> t,int sub)=>T[sub]=t.ToArray();public void RecalculateBounds(){}}
 public class Material{public string name;public Material(){}public Material(Material source){}public Dictionary<string,float> Floats=new();public void SetFloat(int id,float value){}public void SetFloat(string name,float value){Floats[name]=value;}}public struct Color{public static Color black=>new();}public class MaterialPropertyBlock{public float Index;public void SetFloat(int id,float value){Index=value;}public void SetColor(int id,Color value){}}
 public class Renderer{public Material[] sharedMaterials=new Material[5];public Dictionary<int,float> Blocks=new();public void SetPropertyBlock(MaterialPropertyBlock b){if(b==null)Blocks.Remove(-1);else Blocks[-1]=b.Index;}public void SetPropertyBlock(MaterialPropertyBlock b,int role){if(b==null)Blocks.Remove(role);else Blocks[role]=b.Index;}}public class MeshRenderer:Renderer{}public class GameObject{public bool activeSelf;public void SetActive(bool b)=>activeSelf=b;public T GetComponent<T>() where T:new()=>new();}public class MonoBehaviour{}
}
namespace Assets.Scripts.Objects {public class Thing{public const int DiffuseIndexPropertyID=1,EMISSION_COLOR=2;}}
namespace Assets.Scripts.Objects.Motherboards{public enum ColorType:byte{Blue,Gray,Green,Orange,Red,Yellow,White,Black,Brown,Khaki,Pink,Purple}}
namespace ModularSwitchboards {
 public class DinBreaker{public bool Conducting,Tripped;public float RatedWatts;}
 static class FuseSurfaces{public static Material[] White=>new Material[5];}
 static class FuseAppearanceDiagnostics{public static void Capture(DinFuseView v){}}
 static class DinModuleCatalog{public static string Colour(float w)=>"Green";}
 static class DinBreakerModel{public static Vector3 VisualScale=new(2.25f,1.35f,1.15f);}
 static class CabinetGeometry{public static Material[] Materials=new Material[5];public static int[] PaletteIndices=new int[5];public static void ApplyNativeUv(Mesh m){}}

}
static class Program {
 static bool HitZ(Vector3 a,Vector3 b,Vector3 c,out float z){float d=(b.y-c.y)*(a.x-c.x)+(c.x-b.x)*(a.y-c.y);z=0;if(Math.Abs(d)<1e-10)return false;float u=((b.y-c.y)*(-c.x)+(c.x-b.x)*(-c.y))/d;float v=((c.y-a.y)*(-c.x)+(a.x-c.x)*(-c.y))/d;float w=1-u-v;if(u<0||v<0||w<0)return false;z=u*a.z+v*b.z+w*c.z;return true;}
 static void Main(){var body=DinFuseModel.Housing();float front=0;foreach(var indices in body.T.Values)for(int i=0;i<indices.Length;i+=3)if(HitZ(body.V[indices[i]],body.V[indices[i+1]],body.V[indices[i+2]],out float z))front=Math.Max(front,z);if(front>.026f||front<.022f)throw new Exception("Holder centre is not recessed/hollow");
 var contacts=DinFuseModel.Contacts();int contactRays=0;
 foreach(float y in new[]{-.0158f,.0158f})foreach(float x in new[]{-.0048f,.0048f}){
 float visible=0,occluder=0;var shift=new Vector3(x,y,0);foreach(var indices in contacts.T.Values)for(int i=0;i<indices.Length;i+=3)if(HitZ(contacts.V[indices[i]]-shift,contacts.V[indices[i+1]]-shift,contacts.V[indices[i+2]]-shift,out float z))visible=Math.Max(visible,z);
 foreach(var indices in body.T.Values)for(int i=0;i<indices.Length;i+=3)if(HitZ(body.V[indices[i]]-shift,body.V[indices[i+1]]-shift,body.V[indices[i+2]]-shift,out float z))occluder=Math.Max(occluder,z);
 if(visible<.058f||visible<=occluder)throw new Exception("Fixed contact hidden behind housing");contactRays++;
 }
 var healthy=DinFuseModel.Cartridge(false);var burnt=DinFuseModel.Cartridge(true);
 if(healthy.T[0].Length==0||burnt.T[0].Length!=0||burnt.T[3].Length==0)throw new Exception("Healthy coloured barrel/burnt charred body absent");
 if(burnt.V.Any(v=>Math.Abs(v.y)<.0019f))throw new Exception("Burnt cartridge doesn't have a physical broken gap");
 var caps=DinFuseModel.Caps();if(caps.T[1].Length==0||caps.T.Where(p=>p.Key!=1).Any(p=>p.Value.Length!=0))throw new Exception("Caps not isolated to white role");var renderer=new MeshRenderer();DinFuseModel.PaintCaps(renderer);if(renderer.Blocks.Count!=0)throw new Exception("Palette blocks retained on plain caps");
 foreach(var m in new[]{body,contacts,healthy,burnt,caps}){if(m.V.Count!=m.N.Count||m.T.Values.Any(t=>t.Any(i=>i<0||i>=m.V.Count)))throw new Exception("Invalid production fuse mesh");foreach(var v in m.V)if(float.IsNaN(v.x+v.y+v.z)||Math.Abs(v.x)>.009f||Math.Abs(v.y)>.038f||v.z>.064f)throw new Exception("Fuse geometry exceeds body envelope");}
 var owner=new DinBreaker();var view=new DinFuseView{Owner=owner,Intact=new GameObject(),Burnt=new GameObject(),Caps=new GameObject()};var update=typeof(DinFuseView).GetMethod("LateUpdate",System.Reflection.BindingFlags.NonPublic|System.Reflection.BindingFlags.Instance);
 update.Invoke(view,null);if(view.Intact.activeSelf||view.Burnt.activeSelf||view.Caps.activeSelf)throw new Exception("Empty holder shows a cartridge");owner.Conducting=true;update.Invoke(view,null);if(!view.Intact.activeSelf||view.Burnt.activeSelf||!view.Caps.activeSelf)throw new Exception("Healthy holder model wrong");owner.Conducting=false;owner.Tripped=true;update.Invoke(view,null);if(view.Intact.activeSelf||!view.Burnt.activeSelf||!view.Caps.activeSelf)throw new Exception("Burnt cartridge model missing");owner.Tripped=false;update.Invoke(view,null);if(view.Intact.activeSelf||view.Burnt.activeSelf||view.Caps.activeSelf)throw new Exception("Removed burnt cartridge still visible");
 foreach(bool on in new[]{true,false}){var m=BreakerLettering.Build(on,.013f,on?.0014f:-.0014f);if(m.V.Count==0||m.V.Count!=m.N.Count)throw new Exception("Missing lettering");foreach(var v in m.V)if(Math.Abs(v.x)>.006f||v.y<.010f||v.y>.016f)throw new Exception("Letter outside flap");var t=m.T[0];for(int i=0;i<t.Length;i+=3){var normal=Vector3.Cross(m.V[t[i+1]]-m.V[t[i]],m.V[t[i+2]]-m.V[t[i]]);if(normal.z*(on?1:-1)<=0)throw new Exception("Letter winding wrong");}}
 Console.WriteLine("Production fuse meshes passed: real recessed empty centre, coloured intact barrel, broken charred gap, valid indices and unchanged module envelope. Actual production rounded geometry used; four front contact rays clear housing. Plain surface shader still requires Unity visual verification.");
 }
}
