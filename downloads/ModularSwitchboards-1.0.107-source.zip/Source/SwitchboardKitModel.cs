using System.Collections.Generic;
using System.Linq;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Motherboards;
using UnityEngine;
using Assets.Scripts.UI;
namespace ModularSwitchboards
{
    internal static class SwitchboardKitModel
    {
        internal static bool IsKit(Thing thing)=>thing is PortableCoverItem||thing is MultiConstructor&&(thing.PrefabName==SwitchboardsMod.SmartKitName||thing.PrefabName==SwitchboardsMod.DoorKitName||thing.PrefabName==SwitchboardsMod.LabelKitName||thing.PrefabName==SwitchboardsMod.KitName||thing.PrefabName==SwitchboardsMod.RailKitName||thing.PrefabName==SwitchboardsMod.BreakerKitName||thing.PrefabName==SwitchboardsMod.CoverKitName);
        internal static void Install(MultiConstructor kit,SwitchboardKitKind kind)
        {
            var original=kit.Bounds;
            if(original.size.x<.001f||original.size.y<.001f||original.size.z<.001f)
            {
                bool first=true;
                foreach(var filter in kit.GetComponentsInChildren<MeshFilter>(true))
                {
                    if(filter.sharedMesh==null)continue;
                    var b=CabinetWallMount.TransformedBounds(filter.sharedMesh.bounds,kit.transform.worldToLocalMatrix*filter.transform.localToWorldMatrix);
                    if(first){original=b;first=false;}else original.Encapsulate(b);
                }
            }
            if(original.size.x<=0||original.size.y<=0||original.size.z<=0)throw new System.InvalidOperationException("Kit visual bounds unavailable: "+kit.PrefabName);
            if(kind==SwitchboardKitKind.Smart||kind==SwitchboardKitKind.Doors||kind==SwitchboardKitKind.Labels||kind==SwitchboardKitKind.Modules||kind==SwitchboardKitKind.Rails||kind==SwitchboardKitKind.Cover){ModuleKitModel.Install(kit,original,kind==SwitchboardKitKind.Rails,kind==SwitchboardKitKind.Cover,kind==SwitchboardKitKind.Labels,kind==SwitchboardKitKind.Doors,kind==SwitchboardKitKind.Smart);return;}
            foreach(var lod in kit.GetComponentsInChildren<LODGroup>(true))Object.DestroyImmediate(lod);
            foreach(var renderer in kit.GetComponentsInChildren<MeshRenderer>(true))Object.DestroyImmediate(renderer);
            foreach(var filter in kit.GetComponentsInChildren<MeshFilter>(true))Object.DestroyImmediate(filter);
            var mesh=SwitchboardKitGeometry.Build(kind);
            bool cabinetPackage=kind==SwitchboardKitKind.Cabinet;
            Material[] surfaces=cabinetPackage?CabinetKitSurface.Materials:CabinetGeometry.Materials;
            float fit=cabinetPackage?1f:SwitchboardKitGeometry.Fit(original.size,mesh.bounds.size);
            var model=new GameObject(cabinetPackage?CabinetKitSurface.RendererName:"SwitchboardKitModel"){layer=kit.gameObject.layer};model.transform.SetParent(kit.transform,false);
            model.transform.localScale=Vector3.one*fit;model.transform.localPosition=original.center-mesh.bounds.center*fit;
            model.AddComponent<MeshFilter>().sharedMesh=mesh;
            var view=model.AddComponent<MeshRenderer>();view.sharedMaterials=surfaces;
            kit.Renderers=new List<ThingRenderer>{new ThingRenderer(kit,view)};
            kit.PaintableMaterial=null;kit.HasColorState=false;
            kit.Thumbnail=CabinetIcons.Get("Kit"+kind);kit.Thumbnails=new Sprite[0];
            // Native kit identity, hand poses, stack behaviour, rigidbody and
            // collision envelope remain intact. Only the fitted visual is replaced.
            Refresh(kit);
            InstallBlueprint(kit,model.transform,mesh);
        }
        // Native item placement clones Thing.Blueprint, independently of the visible kit.
        // Give each custom kit its own fitted geometry; never mutate the stock Logic blueprint.
        internal static void InstallBlueprint(MultiConstructor kit,Transform model,Mesh mesh)
        {
            var blueprint=new GameObject("Switchboards.KitBlueprint."+kit.PrefabName){layer=kit.gameObject.layer};
            blueprint.transform.SetParent(kit.transform.parent,false);
            var ghost=new Mesh{name="Switchboards.KitPlacement",indexFormat=SwitchboardKitGeometry.WideBlueprintIndices(mesh.vertexCount,mesh.subMeshCount)?UnityEngine.Rendering.IndexFormat.UInt32:mesh.indexFormat};
            var parts=new CombineInstance[mesh.subMeshCount];
            var matrix=Matrix4x4.TRS(model.localPosition,model.localRotation,model.localScale);
            for(int i=0;i<parts.Length;i++)parts[i]=new CombineInstance{mesh=mesh,subMeshIndex=i,transform=matrix};
            ghost.CombineMeshes(parts,true,true);ghost.RecalculateBounds();
            var filter=blueprint.AddComponent<MeshFilter>();filter.sharedMesh=ghost;
            var renderer=blueprint.AddComponent<MeshRenderer>();renderer.sharedMaterial=CabinetGeometry.Materials[4];
            var wire=blueprint.AddComponent<Wireframe>();wire.BlueprintTransform=blueprint.transform;
            wire.BlueprintBounds=ghost.bounds;wire.BlueprintMeshFilter=filter;wire.BlueprintRenderer=renderer;
            blueprint.AddComponent<CabinetBlueprint>();
            kit.Blueprint=blueprint;kit.BlueprintOrientVector=Vector3.zero;kit.Wireframe=null;
        }
        internal static void Refresh(Thing kit)
        {
            foreach(var renderer in kit.GetComponentsInChildren<MeshRenderer>(true))
            {
                if(renderer.name==ModuleKitModel.SmartRendererName||renderer.name==ModuleKitModel.DoorRendererName||renderer.name==ModuleKitModel.LabelRendererName||renderer.name==ModuleKitModel.RendererName||renderer.name==ModuleKitModel.RailRendererName||renderer.name==ModuleKitModel.CoverRendererName){ModuleKitModel.Refresh(renderer);continue;}
                if(renderer.name==CabinetKitSurface.RendererName){CabinetKitSurface.Refresh(renderer);continue;}
                if(renderer.name!="SwitchboardKitModel")continue;
                for(int role=0;role<5;role++)
                {
                    var block=new MaterialPropertyBlock();renderer.GetPropertyBlock(block,role);
                    int color=role==0?(int)ColorType.Black:role==1?(int)ColorType.White:role==2?(int)ColorType.White:(int)ColorType.Gray;
                    block.SetFloat(Thing.DiffuseIndexPropertyID,color);block.SetFloat(Thing.SmoothnessIndexPropertyID,0f);block.SetColor(Thing.EMISSION_COLOR,Color.black);renderer.SetPropertyBlock(block,role);
                }
            }
        }
    }
}
