using System;namespace ModularSwitchboards{static partial class SwitchboardsMod{internal static bool LocalizeDescription(string __0, ref string __result)
        {
            if(__0==DinTransformer.PrefabNameId||__0==DinTransformer.MediumPrefabNameId)
            {
                bool medium=__0==DinTransformer.MediumPrefabNameId;
                __result=Localization.GetThingDescription(medium?"StructureTransformerMedium":"StructureTransformerSmall")+
                    "\n\nDIN version: "+(medium?"6":"4")+" positions. Adjust the dial in 100 W steps, or 10 W with the quantity modifier. Setting zero stops output; the input-side control electronics remain powered while IN has a supply.";
                return false;
            }
            var text=SwitchboardDescriptions.Get(__0);
            if(text==null)return true;
            __result=text;
            return false;
        }}partial class DinTransformer{public override double GetLogicValue(LogicType type)=>type==LogicType.RequiredPower?TransformerBudget.Finite(UsedPower):base.GetLogicValue(type);internal bool Conducting=>!IsCursor&&!IsBeingDestroyed&&IsStructureCompleted&&Board!=null&&OnOff&&TransformerBudget.Finite((float)Setting)>0&&(UsedPower<=0||(!GameManager.RunSimulation?Powered:Wiring?.Power.TransformerPowered(ReferenceId)==true));internal CabinetPowerNode PowerNode()=>new CabinetPowerNode{ReferenceId=ReferenceId,Conducting=Conducting,IsTransformer=true,TransferLimit=TransformerBudget.Finite((float)Setting),OwnWatts=TransformerBudget.Finite(UsedPower),ServiceEnabled=!IsCursor&&!IsBeingDestroyed&&IsStructureCompleted&&Board!=null};}static class NativeMetadataCopy{public static void Apply(DinTransformer owner,Native source,Native limits=null){owner.UsedPower=TransformerBudget.Finite((limits??source).UsedPower);}}}namespace ModularSwitchboards{class NativeF1Formatter{internal void AddDevice(Native prefab, ref NativePage page)
	{
		if (!(prefab is Native { UsedPower: >0f } device))
		{
			return;
		}
		try
		{
			page.BasePowerDraw = device.UsedPower.ToStringPrefix("W", "yellow");
		}
		catch (FormatException ex)
		{
			Debug.LogError("There was an error with text " + DevicePage.Parsed + " " + ex.Message);
		}
	}}}