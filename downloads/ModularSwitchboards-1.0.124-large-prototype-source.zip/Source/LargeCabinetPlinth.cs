using System.Collections.Generic;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class LargeCabinetPlinth
    {
        internal static void Install(SwitchboardCabinet host)
        {
            var model=host.transform.Find("SwitchboardModel");var shell=model.Find("CompletedShell");
            var housing=shell.Find("Housing").GetComponent<MeshFilter>().sharedMesh;
            var bounds=LargeCabinetDimensions.Plinth(housing.bounds);
            var points=new List<Vector3>();var normals=new List<Vector3>();var indices=new List<int>();
            RoundedGeometry.Box(points,normals,indices,bounds.center,bounds.size,.006f);
            var mesh=new Mesh{name="Switchboards.LargeFloorPlinth"};mesh.SetVertices(points);mesh.SetNormals(normals);mesh.subMeshCount=CabinetGeometry.Materials.Length;
            for(int role=0;role<mesh.subMeshCount;role++)mesh.SetTriangles(role==CabinetRearSurface.Role?indices:new List<int>(),role);
            CabinetGeometry.ApplyNativeUv(mesh);CabinetRearSurface.ApplyUv(mesh);mesh.RecalculateBounds();
            var root=new GameObject("FloorPlinth"){layer=host.gameObject.layer};root.transform.SetParent(shell,false);
            root.AddComponent<MeshFilter>().sharedMesh=mesh;var renderer=root.AddComponent<MeshRenderer>();renderer.sharedMaterials=CabinetGeometry.Materials;
            CabinetRearSurface.Restore(renderer);CabinetMatteSurface.Apply(renderer);
            var collider=root.AddComponent<MeshCollider>();collider.sharedMesh=mesh;host.BuildStates[1].Colliders.Add(collider);
            // Include the base in the bare-frame mesh and its physical hitbox,
            // so the construction ghost and every construction stage agree.
            var frame=model.Find("Frame").GetComponent<MeshFilter>();var old=frame.sharedMesh;
            frame.sharedMesh=CabinetRearShell.Append(old,mesh);
            model.Find("ProfiledFrameCollider").GetComponent<MeshCollider>().sharedMesh=frame.sharedMesh;
            UnityEngine.Object.DestroyImmediate(old);
        }
    }
}
