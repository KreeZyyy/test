using System;using System.Linq;using System.Collections.Generic;using Assets.Scripts.Objects;using Assets.Scripts.UI;namespace ModularSwitchboards{class SmartModule:Thing,ICircuitHolder{public List<LogicBinding> GetLogicBindings()=>new[]{new LogicBinding("HOUSING")}.Concat(Enumerable.Range(0,SmartOutputAddresses.Count).Select(i=>new LogicBinding(i,"SCREW_"+i))).ToList();}class NativeStationpedia{	internal void AddBindingsInfo(Thing prefab, ref StationpediaPage page)
	{
		if (!(prefab is ICircuitHolder circuitHolder))
		{
			return;
		}
		if (circuitHolder.GetLogicBindings() == null)
		{
			page.HasBindings = false;
			return;
		}
		foreach (LogicBinding logicBinding in circuitHolder.GetLogicBindings())
		{
			page.HasBindings = true;
			try
			{
				StationBinding item = new StationBinding
				{
					Header = logicBinding.Header,
					Label = logicBinding.Label
				};
				page.LogicBindings.Add(item);
			}
			catch (FormatException ex)
			{
				ConsoleWindow.PrintError("There was an error with text " + prefab.PrefabName + " " + ex.Message);
			}
		}
	}
}}