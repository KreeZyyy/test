using System;using System.Collections.Generic;using System.Linq;using Assets.Scripts.Objects;using Assets.Scripts.UI;using ModularSwitchboards;
namespace Assets.Scripts.UI{public class StationBinding{public string Header,Label;}}
namespace ModularSwitchboards{
interface ICircuitHolder{List<LogicBinding> GetLogicBindings();}
class LogicBinding{public string Header,Label;public LogicBinding(string label){Header="db";Label=label;}public LogicBinding(int index,string label){Header="d"+index;Label=label;}}
static class SmartOutputAddresses{public const int Count=6;}
static class ConsoleWindow{public static void PrintError(string s)=>throw new Exception(s);}
class VanillaHousing:Thing,ICircuitHolder{public List<LogicBinding> GetLogicBindings()=>new(){new("HOUSING"),new(0,"SCREW_0")};}
}
static class BindingsChecks{
static void Check(bool ok,string why){if(!ok)throw new Exception(why);}
public static void Run(){var native=new NativeStationpedia();var core=new SmartModule{PrefabName="StructureDinSmartModule"};
for(int i=0;i<3;i++){var page=new StationpediaPage();native.AddBindingsInfo(core,ref page);Check(page.LogicBindings.Count==7&&page.LogicBindings.Any(b=>b.Label=="SCREW_5"),"native pipeline must reproduce reported table");SwitchboardStationpedia.FormatBindings(core,ref page);Check(page.HasBindings&&page.LogicBindings.Count==1&&page.LogicBindings[0].Header=="db"&&page.LogicBindings[0].Label=="CORE","Core F1 still shows nonexistent screws");SwitchboardStationpedia.FormatBindings(core,ref page);Check(page.LogicBindings.Count==1,"duplicate F1 entries on regeneration");Check(core.GetLogicBindings().Count==7&&core.GetLogicBindings().Any(b=>b.Header=="d5"),"F1 formatting removed runtime Output addresses");}
var vanilla=new VanillaHousing{PrefabName="StructureCircuitHousing"};var other=new StationpediaPage();native.AddBindingsInfo(vanilla,ref other);SwitchboardStationpedia.FormatBindings(vanilla,ref other);Check(other.LogicBindings.Count==2&&other.LogicBindings[1].Label=="SCREW_0","native IC housing affected");
var empty=new StationpediaPage();SwitchboardStationpedia.FormatBindings(new Thing{PrefabName="unrelated"},ref empty);Check(empty.LogicBindings.Count==0&&!empty.HasBindings,"unrelated device gained bindings");StationpediaPage missing=null;SwitchboardStationpedia.FormatBindings(core,ref missing);Console.WriteLine("15 actual native AddBindingsInfo/Core F1 formatting checks passed, including runtime-address preservation and vanilla isolation.");}}
