from pathlib import Path
r=Path(__file__).resolve().parents[2];out=Path(__file__).parent
s=(r/'Source/SmartModule.cs').read_text();binding=next(l.strip()for l in s.splitlines()if 'GetLogicBindings()=>'in l)
# Exact game AddBindingsInfo source copied from the installed assembly.
native=(out/'NativeBindings-reference.txt').read_text().replace('private void AddBindingsInfo','internal void AddBindingsInfo')
(out/'BindingsExtracted.cs').write_text('using System;using System.Linq;using System.Collections.Generic;using Assets.Scripts.Objects;using Assets.Scripts.UI;namespace ModularSwitchboards{class SmartModule:Thing,ICircuitHolder{'+binding+'}class NativeStationpedia{'+native+'}}')
