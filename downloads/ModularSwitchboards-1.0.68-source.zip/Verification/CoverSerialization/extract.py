from pathlib import Path
r=Path(__file__).resolve().parents[2];out=Path(__file__).parent

def block(s,marker):
 a=s.index(marker);b=s.index('{',a);i=b+1;n=1
 while n:n+=(s[i]=='{')-(s[i]=='}');i+=1
 return s[a:i]
classes=[]
for file,typ,dto in [('PortableCoverItem.cs','PortableCoverItem','PortableCoverSaveData'),('InnerCoverModule.cs','InnerCoverModule','InnerCoverSaveData')]:
 s=(r/'Source'/file).read_text();methods=''.join(block(s,m)for m in ['public override ThingSaveData SerializeSave()','protected override void InitialiseSaveData(','public override void DeserializeSave(','public override void SerializeOnJoin(','public override void DeserializeOnJoin('])
 if typ=='InnerCoverModule':methods+=''.join(block(s,m)for m in ['public override void BuildUpdate(','public override void ProcessUpdate('])
 classes.append(block(s,'public sealed class '+dto)+ 'partial class '+typ+'{'+methods+'}')
(out/'Extracted.cs').write_text('using System.Xml.Serialization;using LibConstruct;using Assets.Scripts.Objects;using Assets.Scripts.Networking;namespace ModularSwitchboards{'+''.join(classes)+'}')
