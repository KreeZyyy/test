from pathlib import Path
r=Path(__file__).resolve().parents[2];v=Path(__file__).parent
s=(r/'Source/DinTransformerModel.cs').read_text();marker='owner.UsedPower=TransformerBudget.Finite((limits??source).UsedPower);';assert marker in s
prefix=(r/'Source/SwitchboardsMod.cs').read_text();a=prefix.index('private static bool LocalizeDescription(');b=prefix.index('{',a);i=b+1;n=1
while n:n+=(prefix[i]=='{')-(prefix[i]=='}');i+=1
logic=next(l.strip()for l in(r/'Source/DinTransformer.cs').read_text().splitlines()if 'override double GetLogicValue('in l)
conducting=next(l.strip()for l in(r/'Source/DinTransformer.cs').read_text().splitlines()if 'internal bool Conducting=>'in l)
power=next(l.strip()for l in(r/'Source/DinTransformer.cs').read_text().splitlines()if 'CabinetPowerNode PowerNode()'in l)
(v/'Extracted.cs').write_text('using System;namespace ModularSwitchboards{static partial class SwitchboardsMod{'+prefix[a:i].replace('private static','internal static')+'}partial class DinTransformer{'+logic+conducting+power+'}static class NativeMetadataCopy{public static void Apply(DinTransformer owner,Native source,Native limits=null){'+marker+'}}}')

native=(v/'NativeBasePower-reference.txt').read_text().replace('private void','internal void')
import re
native=re.sub(r'\bThing\b','Native',native);native=re.sub(r'\bDevice\b','Native',native);native=re.sub(r'\bStationpediaPage\b','NativePage',native)
p=v/'Extracted.cs';p.write_text(p.read_text()+'namespace ModularSwitchboards{class NativeF1Formatter{'+native+'}}')
