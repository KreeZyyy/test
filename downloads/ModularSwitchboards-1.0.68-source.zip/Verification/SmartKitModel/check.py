"""Validate the shipped Smart crate against its shared shell and checked layout."""
from pathlib import Path
import json,struct,math
from PIL import Image
root=Path(__file__).resolve().parents[2]
source=json.loads((root/'Art/SmartKit/source.json').read_text());base=json.loads((root/'Art/ModuleKit/source.json').read_text());assert source['shell']==base['shell'],'ordinary crate shell changed'
data=json.loads((root/'Art/SmartKit/model.json').read_text());raw=(root/'Assets/SmartKit/Model.meshbin').read_bytes();assert raw[:4]==b'MKIT';count,length=struct.unpack_from('<ii',raw,4);assert count==len(data['vertices'])<=250000;assert length==len(data['triangles']['0'])<=750000;offset=12
for p,n,uv in zip(data['vertices'],data['normals'],data['uv']):
 assert all(math.isfinite(x)for x in p+n+uv);assert .98<sum(x*x for x in n)<1.02;assert raw[offset:offset+32]==struct.pack('<8f',*p,*n,*uv);offset+=32
indices=list(struct.unpack_from('<'+'i'*length,raw,offset));assert offset+length*4==len(raw);assert indices==data['triangles']['0'];assert all(0<=i<count for i in indices)
# Shared crate vertices, native normals, UVs and indices are an exact prefix.
shell=base['shell'];total=len(shell['vertices']);assert data['vertices'][:total]==shell['vertices'];assert data['normals'][:total]==shell['normals'];assert data['uv'][:total]==shell['uv'];assert indices[:data['originalCrateIndexCount']]==shell['triangles']['0']
layout=json.loads((root/'Art/SmartKit/layout.json').read_text());kinds=[p['metadata']['smartVariant']for p in layout['parts']];assert {k:kinds.count(k)for k in set(kinds)}=={'Core':2,'Net':4,'Output':4}
audit=json.loads((root/'Art/SmartKit/support-audit.json').read_text());assert audit['grounded_count']==10 and not audit['ungrounded'];assert audit['max_height']<.36
# Regression: mirrored Unity imports previously had negative signed body volume
# and rendered inside-out under Unity's back-face culling.
def volume(mesh):
 v=mesh['vertices'];total=0
 for ids in mesh['triangles'].values():
  for i in range(0,len(ids),3):
   a,b,c=(v[j]for j in ids[i:i+3]);total+=a[0]*(b[1]*c[2]-b[2]*c[1])+a[1]*(b[2]*c[0]-b[0]*c[2])+a[2]*(b[0]*c[1]-b[1]*c[0])
 return total/6
parts=json.loads((root/'Art/SmartKit/pile-input.json').read_text())['parts']
for part in parts:assert volume(part['mesh'])>0,(part['name'],'inside-out body faces')
settled=json.loads((root/'Art/SmartKit/pile-settled.json').read_text())
for part in settled['parts']:
 for p in part['mesh']['vertices']:assert p[1]<=.36 and abs(p[0])<=.22401 and abs(p[2])<=.22401 and abs(p[0])+abs(p[2])<=.42401,(part['name'],'contents exceed rim/inset')
for p in data['vertices']:assert abs(p[0])<=.5399921/2+1e-5 and abs(p[2])<=.5461208/2+1e-5 and -.00001<=p[1]<=.436002
Image.open(root/'Assets/ModuleKit/Surface.png').verify();Image.open(root/'Assets/Icons/KitSmart.png').verify()
print('Smart crate verified:',count,'vertices,',length//3,'triangles; exact shared shell/UVs, only 3 Smart designs, 10 grounded parts, native crate envelope and valid atlas/icon.')
