using System;using System.IO;using System.Linq;using System.Collections.Generic;using System.Text.Json;using UnityEngine;using ModularSwitchboards;
class P{static int n;static void Check(bool b,string m){n++;if(!b)throw new Exception(m);}static float Edge(Vector3 a,Vector3 b,Vector3 p)=>(p.x-b.x)*(a.y-b.y)-(a.x-b.x)*(p.y-b.y);
static bool Covers(Vector3 a,Vector3 b,Vector3 c,Vector3 p){float x=Edge(a,b,p),y=Edge(b,c,p),z=Edge(c,a,p);return(x>=-1e-10&&y>=-1e-10&&z>=-1e-10)||(x<=1e-10&&y<=1e-10&&z<=1e-10);}
static Mesh Move(Mesh mesh,float dx){mesh.SetVertices(mesh.vertices.Select(v=>v+new Vector3(dx,0,0)).ToList());mesh.RecalculateBounds();return mesh;}
static Mesh Shift(Mesh m,float x){m.SetVertices(m.vertices.Select(p=>p+new Vector3(x,0,0)).ToList());m.RecalculateBounds();return m;}
static void Main(){
foreach(int slots in new[]{2,4,6}){
var body=TransformerFrontGeometry.Body(slots);var face=TransformerFrontGeometry.Face(slots);var original=TransformerPanelLayout.Body(slots);
Check(Math.Abs(face.bounds.size.y-.045f*DinBreakerModel.VisualScale.y)<1e-7,"fascia height differs from breaker");Check(Math.Abs(body.bounds.size.y-original.bounds.size.y)<1e-7,"outer housing height changed");
var pockets=(slots==6?MediumTransformerGeometry.Pockets:new[]{TransformerFrontGeometry.Pocket}).Select(p=>TransformerFit.Pocket(p,slots)).ToArray();
var fv=face.vertices;var ids=face.GetTriangles(0);
foreach(var hole in pockets)for(int ix=0;ix<11;ix++)for(int iy=0;iy<11;iy++){
var p=new Vector3(hole.min.x+.00002f+(hole.size.x-.00004f)*ix/10,hole.min.y+.00002f+(hole.size.y-.00004f)*iy/10,hole.min.z+.0002f);bool covered=false;
for(int i=0;i<ids.Length;i+=3){var a=fv[ids[i]];var b=fv[ids[i+1]];var c=fv[ids[i+2]];if(Math.Abs(a.z-p.z)<1e-7&&Math.Abs(b.z-p.z)<1e-7&&Math.Abs(c.z-p.z)<1e-7&&Covers(a,b,c,p)){covered=true;break;}}
Check(covered,"gray rear missing behind winding");}
if(slots==2)continue;
var parts=new Dictionary<string,Mesh>{{"body",body},{"front",face},{"dial",TransformerFrontGeometry.Knob()},{"range",TransformerReferenceMesh.Load("RangeArc")},{"frame",TransformerFrontGeometry.DialFrame()}};
if(slots==4){parts["winding"]=TransformerReferenceMesh.Load("Winding");parts["leads"]=TransformerReferenceMesh.Load("CoverLeads");parts["leadsRight"]=TransformerReferenceMesh.Load("CoverLeadsRight");parts["sideCover"]=TransformerCoverSeat.Fit(TransformerReferenceMesh.Load("SideCover"));parts["bands"]=TransformerReferenceMesh.Load("WindingBands");}
else{parts["mediumCover"]=TransformerReferenceMesh.Load("MediumCover");for(int k=0;k<2;k++){parts[k==0?"mediumRibs":"mediumRibsLeft"]=Shift(TransformerReferenceMesh.Load("MediumRibs"),MediumTransformerGeometry.RibCenters[k]-.10125f);parts[k==0?"mediumWinding":"mediumWindingLeft"]=Shift(TransformerReferenceMesh.Load("MediumWinding"),MediumTransformerGeometry.WindingCenters[k]-.02025f);}}
var export=new Dictionary<string,object>();foreach(var pair in parts){var m=pair.Value;var vv=m.vertices;
if(pair.Key!="body"&&pair.Key!="front")foreach(var v in vv){var p=v;
if(pair.Key=="dial")p=new Vector3(v.x,-v.z,v.y)+TransformerFrontGeometry.KnobCenter;
if(pair.Key=="range")p+=new Vector3(0,.004f,0);if(pair.Key=="sideCover")p+=new Vector3(0,0,TransformerCoverSeat.CoverOffset);
if(slots==6&&!pair.Key.StartsWith("medium"))p+=new Vector3(.081f+MediumTransformerGeometry.KnobShift,0,0);
p=TransformerFit.Point(p,slots);Check(p.y>=face.bounds.min.y+.0005f&&p.y<=face.bounds.max.y-.0005f,"component exceeds matching fascia: "+pair.Key);
}
for(int role=0;role<m.subMeshCount;role++){var tt=m.GetTriangles(role);for(int i=0;i<tt.Length;i+=3)Check(Vector3.Cross(vv[tt[i+1]]-vv[tt[i]],vv[tt[i+2]]-vv[tt[i]]).sqrMagnitude>1e-22,"degenerate mesh");}
export[pair.Key]=new{vertices=vv.Select(p=>new[]{p.x,p.y,p.z}),uv=m.uv.Select(p=>new[]{p.x,p.y}),triangles=Enumerable.Range(0,m.subMeshCount).ToDictionary(i=>i.ToString(),i=>m.GetTriangles(i))};}
File.WriteAllText(Path.Combine(AppContext.BaseDirectory,slots==6?"../../../../../Art/TransformerMediumGeometry.json":"../../../../../Art/TransformerGeometry.json"),JsonSerializer.Serialize(export));
}
Console.WriteLine(n+" production matching-fascia/component-clearance/gray-pocket/mesh checks passed; geometry exported.");}}
