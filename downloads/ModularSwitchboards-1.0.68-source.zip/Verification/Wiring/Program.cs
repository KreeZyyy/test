using System;using System.Collections.Generic;using System.Linq;using System.Diagnostics;using System.IO;using System.Xml.Serialization;using ModularSwitchboards;
class Program
{
 static int checks;static void Check(bool c,string m){checks++;if(!c)throw new Exception(m);}
 static CabinetWireSaveData W(CabinetWireEnd a,CabinetWireEnd b)=>new(){From=a,To=b,Points=new[]{0f,.1f,.1f,.1f,.1f,.1f}};
 static void Main()
 {
  MediumPowerHarness.Run();AnalyserHarness.Run();SingleBridgeHarness.Run();StopCircuitHarness.Run();DoorLaneHarness.Run();
  var indexRandom=new Random(1340);
  var indexWires=new List<WirePoint[]>();
  for(int w=0;w<10;w++){var points=new WirePoint[24];for(int k=0;k<points.Length;k++)points[k]=new WirePoint((float)indexRandom.NextDouble()*.3f-.15f,(float)indexRandom.NextDouble()*.42f-.21f,.03f+(float)indexRandom.NextDouble()*.08f);if(w%3==0)points[0]=new(0,.2f,.033f);indexWires.Add(points);}
  var indexBlocks=new List<WireRect>{new(-.1f,-.07f,-.1f,-.03f),new(.04f,.06f,.02f,.04f)};
  foreach(bool jointMode in new[]{false,true}){
   var geometry=new WireRouting.Geometry(indexBlocks,indexWires,jointMode);
   for(int sample=0;sample<600;sample++){
    var a=new WirePoint((float)indexRandom.NextDouble()*.32f-.16f,(float)indexRandom.NextDouble()*.44f-.22f,.03f+(float)indexRandom.NextDouble()*.08f);
    var b=new WirePoint(a.X+(float)indexRandom.NextDouble()*.02f-.01f,a.Y+(float)indexRandom.NextDouble()*.02f-.01f,a.Z);
    Check(geometry.Clear(a,b)==WireRouting.Clear(a,b,indexBlocks,indexWires,jointMode),"spatial index must preserve exact clearance result");
    float expected=WireRouting.ProjectedCrossings(a,b,indexWires,jointMode)*.12f+WireRouting.ProjectedCrowding(a,b,indexWires,jointMode)*WireRouting.Step*8f*.73f;
    Check(Math.Abs(geometry.Visual(a,b,.73f)-expected)<.000001f,"spatial index must preserve exact visual cost");
   }
  }
  var connector=new[]{new WirePoint(0,0,0),new WirePoint(0,.006f,0),new WirePoint(0,.02f,0),new WirePoint(.003f,.02f,0),new WirePoint(.003f,.08f,0),new WirePoint(.003f,.1f,0)};
  var tidied=WireTube.Clean(connector,(a,b)=>true);Check(tidied.Length<5,"remove a free 3mm grid connector step");
  Check(tidied[0].Squared==0&&(tidied[tidied.Length-1]-connector[connector.Length-1]).Squared==0,"cleanup retains exact contacts");
  Check(WireTube.Clean(connector,(a,b)=>false).Length==connector.Length,"blocked connector shortcut must remain untouched");

  var parallelWire=new List<WirePoint[]>{new[]{new WirePoint(-.06f,0,.06535f),new WirePoint(.06f,0,.06535f)}};
  Check(WireRouting.ProjectedCrowding(new(-.03f,0,.08135f),new(.03f,0,.08135f),parallelWire,false)>.99f,"parallel overlap in different depth is recognized");
  Check(WireRouting.ProjectedCrowding(new(-.03f,.012f,.08135f),new(.03f,.012f,.08135f),parallelWire,false)==0,"spaced parallel wires are not crowded");
  var spread=WireRouting.Find(new(-.12f,0,.08135f),new(.12f,0,.08135f),new List<WireRect>(),parallelWire,false);
  Check(spread!=null,"side-by-side route exists");AssertRoute(spread,new List<WireRect>(),parallelWire);
  float projectedGap=float.PositiveInfinity;
  for(int i=1;i<spread.Length;i++)projectedGap=Math.Min(projectedGap,WireRouting.SegmentDistanceSquared(new(spread[i-1].X,spread[i-1].Y,0),new(spread[i].X,spread[i].Y,0),new(-.06f,0,0),new(.06f,0,0)));
  Check(projectedGap>=WireRouting.Clearance*WireRouting.Clearance,"use free lateral space instead of hiding behind existing wire");
  var narrow=new List<WireRect>{new(-.168f,.168f,.005f,.228f),new(-.168f,.168f,-.228f,-.005f)};
  var layered=WireRouting.Find(new(-.12f,0,.08135f),new(.12f,0,.08135f),narrow,parallelWire,false);
  Check(layered!=null,"depth fallback allowed when lateral corridor is full");AssertRoute(layered,narrow,parallelWire);
  var jointWire=new List<WirePoint[]>{new[]{new WirePoint(0,.21f,.033f),new WirePoint(0,.195f,.06535f)}};
  Check(WireRouting.ProjectedCrowding(new(0,.21f,.08135f),new(0,.195f,.08135f),jointWire,true)==0,"shared Input joint is not treated as unwanted stacking");

  var projectedWire=new List<WirePoint[]>{new[]{new WirePoint(-.04f,0,.06535f),new WirePoint(.04f,0,.06535f)}};
  Check(WireRouting.ProjectedCrossings(new(0,-.06f,.08135f),new(0,.06f,.08135f),projectedWire,false)>0,"detect visual crossing despite physical depth clearance");
  Check(WireRouting.ProjectedCrossings(new(-.06f,.02f,.08135f),new(.06f,.02f,.08135f),projectedWire,false)==0,"parallel routes not penalized as crossings");
  var cleaner=WireRouting.Find(new(0,-.06f,.08135f),new(0,.06f,.08135f),new List<WireRect>(),projectedWire,false);
  Check(cleaner!=null,"avoidance fixture routed");AssertRoute(cleaner,new List<WireRect>(),projectedWire);
  Check(Enumerable.Range(1,cleaner.Length-1).Sum(i=>WireRouting.ProjectedCrossings(cleaner[i-1],cleaner[i],projectedWire,false))==0,"prefer clear detour over crossover in other layer");
  var lowRoute=WireRouting.Find(new(-.12f,0,.06535f),new(.12f,.09f,.06535f),new List<WireRect>{new(-.02f,.05f,.04f,.12f)},new List<WirePoint[]>(),false);
  Check(lowRoute!=null&&lowRoute.Max(p=>p.Y)<=.091f,"do not make needless tall detour to avoid per-step lane fee");

  var input=new CabinetWireEnd(0,0);var o1=new CabinetWireEnd(0,1);var o2=new CabinetWireEnd(0,2);var b1=new CabinetWireEnd(10,0);var b1out=new CabinetWireEnd(10,1);var b2=new CabinetWireEnd(20,0);var b2out=new CabinetWireEnd(20,1);
  var wires=new List<CabinetWireSaveData>{W(input,b1),W(b1out,o1),W(input,b2),W(b2out,o2)};
  Check(!WireCircuit.Reachable(input,o1,wires,Array.Empty<long>()),"OFF passed power");
  Check(WireCircuit.Reachable(input,o1,wires,new long[]{10}),"ON not connected");Check(!WireCircuit.Reachable(input,o2,wires,new long[]{10}),"output 2 leaked");Check(WireCircuit.Reachable(input,o2,wires,new long[]{20}),"second branch failed");Check(!WireCircuit.Reachable(o1,input,wires,new long[]{10,20}),"backfeed");
  Check(!WireCircuit.CanConnect(input,b1,wires,new long[]{10,20},out _),"occupied accepted");Check(!WireCircuit.CanConnect(b1,b2,wires,new long[]{10,20},out _),"two inputs accepted");Check(!WireCircuit.CanConnect(b1out,b1,new List<CabinetWireSaveData>(),new long[]{10},out _),"self loop");
  Check(!WireCircuit.CanConnect(input,o1,new List<CabinetWireSaveData>(),Array.Empty<long>(),out _),"new direct bypass accepted");
  Check(WireCircuit.CanConnect(input,o1,new List<CabinetWireSaveData>(),Array.Empty<long>(),out _,allowLegacyBypass:true),"legacy bypass cannot load");
  var loop=new List<CabinetWireSaveData>{W(b1out,b2)};Check(!WireCircuit.CanConnect(b2out,b1,loop,new long[]{10,20},out _),"cycle accepted");Check(WireCircuit.CanConnect(input,b2,new List<CabinetWireSaveData>{W(input,b1)},new long[]{10,20},out _),"IN fanout rejected");
  var rng=new Random(72);for(int i=0;i<10000;i++){float budget=(float)rng.NextDouble()*100000,d1=(float)rng.NextDouble()*10000,d2=(float)rng.NextDouble()*10000;var p=WireCircuit.Allocate(budget,d1,d2,true,true);Check(p[0]>=0&&p[1]>=0&&Math.Abs(p[0]+p[1]-budget)<.02f,"duplicated input budget");}
  var serializer=new XmlSerializer(typeof(CabinetWireSaveData[]));var xml=new StringWriter();serializer.Serialize(xml,wires.ToArray());var restored=(CabinetWireSaveData[])serializer.Deserialize(new StringReader(xml.ToString()));Check(restored.Length==4&&restored[2].From.Equals(input)&&restored[3].To.Equals(o2),"save roundtrip");
  var blocks=new List<WireRect>{new(-.036f,.036f,.195f,.227f),new(.072f,.144f,-.227f,-.195f),new(-.144f,-.072f,-.227f,-.195f)};
  for(int row=0;row<2;row++)for(int col=0;col<8;col++){float x=-.14175f+col*.0405f,y=row==0?.122f:-.094f;blocks.Add(new(x-.0198f,x+.0198f,y-.050625f,y+.050625f));}
  // Actual cabinet rail origin is y +/- .108, so adjust below for the nominal fixture.
  for(int i=3;i<blocks.Count;i++){var r=blocks[i];float shift=i<11?-.014f:-.014f;r.Bottom+=shift;r.Top+=shift;blocks[i]=r;}
  var occupied=new List<WirePoint[]>();var watch=Stopwatch.StartNew();
  var start=new WirePoint(0,.184f,WireRouting.Plane);var goal=new WirePoint(-.14175f,.167625f,WireRouting.Plane);
  var path=WireRouting.Find(start,goal,blocks,occupied,false);Check(path!=null,"first route missing");AssertRoute(path,blocks,occupied);occupied.Add(path);
  var path2=WireRouting.Find(new WirePoint(.012f,.184f,WireRouting.Plane),new WirePoint(-.10125f,.167625f,WireRouting.Plane),blocks,occupied,false);Check(path2!=null,"second route missing");AssertRoute(path2,blocks,occupied);occupied.Add(path2);
  var barrier=new List<WireRect>{new(-.17f,.17f,-.01f,.01f)};Check(WireRouting.Find(new(0,-.15f,WireRouting.Plane),new(0,.15f,WireRouting.Plane),barrier,new List<WirePoint[]>(),false)==null,"routed through sealed barrier");
  var crossing=new[]{new WirePoint(-.1f,0,.108f),new WirePoint(.1f,0,.108f)};Check(!WireRouting.Clear(new(0,-.1f,.108f),new(0,.1f,.108f),new List<WireRect>(),new List<WirePoint[]>{crossing},false),"wire crossing accepted");
  Check(Math.Abs(WireRouting.SegmentDistanceSquared(new(0,0,0),new(1,0,0),new(.5f,1,0),new(.5f,-1,0)))<1e-7,"distance crossing");
  Check(Math.Abs(WireRouting.SegmentDistanceSquared(new(0,0,0),new(1,0,0),new(0,.1f,0),new(1,.1f,0))-.01f)<1e-6,"distance parallel");
  Check(WireRouting.SelfIntersects(new[]{new WirePoint(0,0,.1f),new WirePoint(.1f,.1f,.1f),new WirePoint(.1f,0,.1f),new WirePoint(0,.1f,.1f)}),"self crossing accepted");
  Check(!WireRouting.SelfIntersects(new[]{new WirePoint(0,0,.1f),new WirePoint(.1f,0,.1f),new WirePoint(.1f,.1f,.1f)}),"simple elbow rejected");
  TestPower(wires);TransformerHarness.Run();TransformerOwnHarness.Run();NormallyClosedPowerHarness.Run();BatteryHarness.Run();ProtectionHarness.Run();TubeHarness.Run();RouteHarness.Run();RouteHarness.RunReverse();RouteHarness.RunMedium();BridgeFlexHarness.Run();SerdeHarness.RunVariants();SerdeHarness.Run();
  Console.WriteLine($"Passed {checks} circuit, budget, persistence and routing checks in {watch.ElapsedMilliseconds} ms (routing fixture).");
 }
 static void TestPower(List<CabinetWireSaveData> wires)
 {
  var c=new SwitchboardCabinet();var input=new Assets.Scripts.Networks.CableNetwork{PotentialLoad=1000};var n1=new Assets.Scripts.Networks.CableNetwork{RequiredLoad=100};var n2=new Assets.Scripts.Networks.CableNetwork{RequiredLoad=300};
  c.InputConnection.cable.CableNetwork=input;c.Output1Connection.cable.CableNetwork=n1;c.Output2Connection.cable.CableNetwork=n2;
  var breakers=new[]{new DinBreaker{ReferenceId=10},new DinBreaker{ReferenceId=20}};var power=new CabinetWiringPower();power.Refresh(c,wires,breakers);
  Check(power.Generated(n1)==0&&power.Generated(n2)==0,"power through OFF");breakers[0].OnOff=true;power.Refresh(c,wires,breakers);Check(power.Generated(n1)==1000&&power.Generated(n2)==0,"one branch");
  breakers[1].OnOff=true;power.Refresh(c,wires,breakers);Check(power.Generated(n1)==400&&power.Generated(n2)==600,"shared power allocation");Check(power.Generated(input)==0,"input backfeed");
  n1.RequiredLoad=9999;Check(power.Generated(n1)+power.Generated(n2)==1000,"budget changed mid snapshot");
  power.Use(n1,100);power.Use(n2,300);Check(power.Used(input)==400,"output consumption not charged to IN");power.Receive(input,250);Check(power.Used(input)==150,"input repayment");
  power.Receive(n1,500);Check(power.Used(input)==150,"output repaid input debt");power.Receive(input,999);Check(power.Used(input)==0,"negative input debt");
  breakers[0].OnOff=false;power.Refresh(c,wires,breakers);Check(power.Generated(n1)==0&&power.Generated(n2)==1000,"OFF affected wrong branch");
  power.Use(n1,25);Check(power.Used(input)==25,"completed provider tick after OFF was not charged");power.Receive(input,25);
  c.Output2Connection.cable.CableNetwork=input;power.Refresh(c,wires,breakers);Check(power.Generated(input)==0,"external same input/output loop");
  breakers[0].OnOff=true;c.Output2Connection.cable.CableNetwork=n1;power.Refresh(c,wires,breakers);Check(power.Generated(n1)==1000,"same output network duplicated");
  c.InputConnection.cable.CableNetwork=null;power.Refresh(c,wires,breakers);Check(power.Generated(n1)==0,"disconnected source generated");
  c.InputConnection.cable.CableNetwork=input;c.IsStructureCompleted=false;power.Refresh(c,wires,breakers);Check(power.Generated(n1)==0,"frame generated");
 }
 static void AssertRoute(WirePoint[] path,IList<WireRect> blocks,IList<WirePoint[]> wires){for(int i=1;i<path.Length;i++)Check(WireRouting.Clear(path[i-1],path[i],blocks,wires,false),"invalid simplified segment");}
}
