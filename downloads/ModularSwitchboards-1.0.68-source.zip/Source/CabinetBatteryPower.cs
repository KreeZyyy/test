using System;
using System.Collections.Generic;
using System.Linq;
using Assets.Scripts.Networks;
using Assets.Scripts.Objects.Items;
using Assets.Scripts.Objects.Pipes;

namespace ModularSwitchboards
{
    // Activated only in cabinets using the new module. The original non-battery
    // bridge remains unchanged. Native BatteryCell owns charge/save/network state.
    internal sealed partial class CabinetBatteryPower
    {
        private sealed class Source
        {
            internal BatteryCell Cell;
            internal bool Charge;
            internal readonly bool[] Output=new bool[3];
            internal readonly long[][] Paths=new long[3][];
            internal long[] ChargePath=new long[0];
            internal readonly Dictionary<long,long[]> OwnPaths=new Dictionary<long,long[]>();
        }
        private sealed class Reservation
        {
            internal Source Source;internal float Energy;internal long[] Path;
        }
        private sealed class Offer
        {
            internal int Branch,Revision;internal float External;internal long[] Path;
            internal readonly List<Reservation> Cells=new List<Reservation>();
            internal float Total=>External+Cells.Sum(c=>c.Energy);
        }
        private readonly Dictionary<CableNetwork,Offer> offers=new Dictionary<CableNetwork,Offer>();
        private sealed class State
        {
            internal CableNetwork Input;
            internal readonly CableNetwork[] Output=new CableNetwork[3];
            internal readonly float[] External=new float[3];
            internal readonly long[][] ExternalPaths={new long[0],new long[0],new long[0]};
            internal Source[] Cells=new Source[0];
            internal Dictionary<long,float> Limits=new Dictionary<long,float>();
            internal Dictionary<long,float> TransferLimits=new Dictionary<long,float>();
            internal OwnLoad[] Own=new OwnLoad[0];
            internal readonly bool[] ExternalReachable=new bool[3];
        }
        private readonly object gate=new object();
        private State state=new State();
        private float debt;
        private readonly Dictionary<long,float[]> loads=new Dictionary<long,float[]>();
        private readonly HashSet<long> trips=new HashSet<long>();
        private string topology="";
        private int revision;
        internal CabinetBatteryPower(float pendingDebt){debt=pendingDebt;CabinetOwnTick.Register(this);}
        internal void Refresh(SwitchboardCabinet owner,IList<CabinetWireSaveData> wires,DinBreaker[] modules)
        {
            RefreshNodes(owner,wires,modules.Select(CabinetPowerNode.From).ToArray());
        }
        internal void RefreshNodes(SwitchboardCabinet owner,IList<CabinetWireSaveData> wires,CabinetPowerNode[] modules)
        {
            var next=new State();
            if(owner.IsStructureCompleted&&!owner.IsCursor&&owner.GridController!=null)
            {
                next.Input=owner.InputConnection?.GetCable()?.CableNetwork;
                var closed=modules.Where(m=>m.Conducting).ToArray();var ids=closed.Select(m=>m.ReferenceId).ToArray();
                var input=new CabinetWireEnd(0,0);
                Func<CabinetWireEnd,CabinetWireEnd,bool> reach=(a,b)=>WireCircuit.Reachable(a,b,wires,ids);
                Func<CabinetWireEnd,CabinetWireEnd,long[]> path=(a,b)=>closed.Where(m=>!m.IsBatteryModule&&reach(a,new CabinetWireEnd(m.ReferenceId,0))&&reach(new CabinetWireEnd(m.ReferenceId,1),b)).Select(m=>m.ReferenceId).ToArray();
                next.Own=modules.Where(m=>m.IsTransformer&&m.ServiceEnabled&&TransformerBudget.Finite(m.OwnWatts)>0).Select(m=>new OwnLoad{Id=m.ReferenceId,Watts=TransformerBudget.Finite(m.OwnWatts),External=reach(input,new CabinetWireEnd(m.ReferenceId,0)),Path=path(input,new CabinetWireEnd(m.ReferenceId,0))}).ToArray();
                var cells=new List<Source>();
                foreach(var module in closed.Where(m=>m.IsBatteryModule))
                {
                    var cell=module.Battery;if(cell==null)continue;
                    var source=new Source{Cell=cell,Charge=reach(input,new CabinetWireEnd(module.ReferenceId,0)),ChargePath=path(input,new CabinetWireEnd(module.ReferenceId,0))};
                    for(int i=0;i<3;i++){source.Output[i]=reach(new CabinetWireEnd(module.ReferenceId,1),new CabinetWireEnd(0,i+1));source.Paths[i]=path(new CabinetWireEnd(module.ReferenceId,1),new CabinetWireEnd(0,i+1));}
                    foreach(var own in next.Own)if(reach(new CabinetWireEnd(module.ReferenceId,1),new CabinetWireEnd(own.Id,0)))source.OwnPaths[own.Id]=path(new CabinetWireEnd(module.ReferenceId,1),new CabinetWireEnd(own.Id,0));
                    cells.Add(source);
                }
                next.Cells=cells.ToArray();var ext=new bool[3];
                for(int i=0;i<3;i++)
                {
                    var end=new CabinetWireEnd(0,i+1);ext[i]=reach(input,end);
                    if(ext[i]||cells.Any(s=>s.Output[i]))next.Output[i]=i==0?owner.Output1Connection?.GetCable()?.CableNetwork:i==1?owner.Output2Connection?.GetCable()?.CableNetwork:owner.Output3Connection?.GetCable()?.CableNetwork;
                    if(ReferenceEquals(next.Output[i],next.Input))next.Output[i]=null;
                    next.ExternalPaths[i]=path(input,end);next.ExternalReachable[i]=ext[i];
                }
                for(int i=0;i<3;i++)for(int j=0;j<i;j++)if(ReferenceEquals(next.Output[i],next.Output[j]))next.Output[i]=null;
                next.TransferLimits=closed.Where(m=>m.IsTransformer).ToDictionary(m=>m.ReferenceId,m=>TransformerBudget.Finite(m.TransferLimit));
                var allocation=TransformerBudget.Allocate(next.Input?.PotentialLoad??0,next.Output.Select(n=>n?.RequiredLoad??0).ToArray(),Enumerable.Range(0,3).Select(i=>ext[i]&&next.Output[i]!=null).ToArray(),next.ExternalPaths,next.TransferLimits);
                for(int i=0;i<3;i++)next.External[i]=allocation[i];
                next.Limits=closed.Where(m=>!m.IsContactor&&!m.IsTransformer&&!m.IsBatteryModule&&!m.IsAnalyserModule&&!m.IsDoorPart).ToDictionary(m=>m.ReferenceId,m=>m.RatedWatts);
            }
            string signature=string.Join(";",wires.Select(w=>w.From.Owner+"/"+w.From.Contact+">"+w.To.Owner+"/"+w.To.Contact))+":"+string.Join(",",modules.Where(m=>m.Conducting).Select(m=>m.ReferenceId))+":"+string.Join(",",next.Cells.Select(c=>c.Cell.ReferenceId))+":"+string.Join(",",next.TransferLimits.Select(p=>p.Key+"="+p.Value));
            lock(gate){if(signature!=topology||!ReferenceEquals(next.Input,state.Input)||!ReferenceEquals(next.Output[0],state.Output[0])||!ReferenceEquals(next.Output[1],state.Output[1])||!ReferenceEquals(next.Output[2],state.Output[2])){loads.Clear();topology=signature;revision++;}state=next;RebudgetOwn();}
        }
        private int Branch(CableNetwork network)=>network==null?-1:ReferenceEquals(network,state.Output[0])?0:ReferenceEquals(network,state.Output[1])?1:ReferenceEquals(network,state.Output[2])?2:-1;
        private float CellShare(Source cell,int branch)
        {
            if(!cell.Output[branch]||state.Output[branch]==null)return 0;
            var p=TransformerBudget.Allocate(Math.Max(0,cell.Cell.PowerStored-ownUses.Sum(o=>o.Offer.Cells.Where(c=>ReferenceEquals(c.Source.Cell,cell.Cell)).Sum(c=>c.Energy))),state.Output.Select(n=>n?.RequiredLoad??0).ToArray(),Enumerable.Range(0,3).Select(i=>cell.Output[i]&&state.Output[i]!=null).ToArray(),cell.Paths,OwnAdjustedLimits());
            return p[branch];
        }
        internal float Generated(CableNetwork network)
        {
            lock(gate)
            {
                if(network==null)return 0;
                int branch=Branch(network);if(branch<0)return 0;
                if(offers.TryGetValue(network,out var existing))return existing.Revision==revision?existing.Total:0;
                ClearLoad(branch); // Start this branch's next provider tick, keeping the other branches reserved.
                // An older query can still own its promised share while demand changes.
                // Reserve that external supply just as we reserve shared cell energy.
                float reservedExternal=AllOffers.Where(o=>o.Revision==revision).Sum(o=>o.External);
                float availableExternal=Math.Max(0,WireCircuit.Finite(state.Input?.PotentialLoad??0)-reservedExternal);
                var offer=new Offer{Branch=branch,Revision=revision,External=Math.Min(Math.Min(state.External[branch],availableExternal),TransferRemaining(state.ExternalPaths[branch])),Path=state.ExternalPaths[branch]};
                foreach(var source in state.Cells)
                {
                    float reserved=AllOffers.Sum(o=>o.Cells.Where(c=>ReferenceEquals(c.Source.Cell,source.Cell)).Sum(c=>c.Energy));
                    float available=Math.Max(0,source.Cell.PowerStored-reserved);
                    float amount=Math.Min(Math.Min(available,CellShare(source,branch)),TransferRemaining(source.Paths[branch],offer));
                    if(amount>0)offer.Cells.Add(new Reservation{Source=source,Energy=amount,Path=source.Paths[branch]});
                }
                // The native tick queries twice, then finishes with Use or ObserveIdle.
                // Pin this offer across both queries and reserve shared cell energy.
                if(offer.Total>0)offers[network]=offer;
                return offer.Total;
            }
        }
        internal float Used(CableNetwork network)
        {
            lock(gate){if(network==null||!ReferenceEquals(network,state.Input))return 0;ClearLoad(3);var reserved=new Dictionary<long,float>();float demand=0;
                foreach(var source in state.Cells.Where(c=>c.Charge))
                {
                    float amount=Math.Min(Math.Min(1000f,WireCircuit.Finite(source.Cell.PowerDelta)),TransferRemaining(source.ChargePath,null,3,reserved));demand+=amount;
                    foreach(long id in source.ChargePath){reserved.TryGetValue(id,out float old);reserved[id]=old+amount;}
                }
                return debt+OwnPending(network)+demand;}
        }
        private float TransferRemaining(long[] path,Offer local=null,int exclude=-1,Dictionary<long,float> extra=null)
        {
            float available=float.MaxValue;
            foreach(long id in path??new long[0])if(state.TransferLimits.TryGetValue(id,out float limit))
            {
                float used=loads.TryGetValue(id,out var values)?values.Where((v,i)=>i!=exclude).Sum():0;
                foreach(var offer in AllOffers){if(offer.Path.Contains(id))used+=offer.External;used+=offer.Cells.Where(c=>c.Path.Contains(id)).Sum(c=>c.Energy);}
                if(local!=null){if(local.Path.Contains(id))used+=local.External;used+=local.Cells.Where(c=>c.Path.Contains(id)).Sum(c=>c.Energy);}
                if(extra!=null&&extra.TryGetValue(id,out float reserved))used+=reserved;
                available=Math.Min(available,Math.Max(0,limit-used));
            }
            return available;
        }
        private void ClearLoad(int index){foreach(var value in loads.Values)value[index]=0;}
        private void AddLoad(IEnumerable<long> path,int index,float value)
        {foreach(long id in path){if(!loads.TryGetValue(id,out var load))loads[id]=load=new float[5];load[index]+=value;}}
        private void CheckTrips(){foreach(var pair in loads)if(state.Limits.TryGetValue(pair.Key,out float limit)&&pair.Value.Sum()>limit)trips.Add(pair.Key);}
        internal void Use(CableNetwork network,float amount)
        {
            lock(gate)
            {
                amount=WireCircuit.Finite(amount);
                if(network==null||!offers.TryGetValue(network,out var offer)){debt+=amount;return;}
                ClearLoad(offer.Branch);float external=Math.Min(amount,offer.External);float remainder=amount-external;
                foreach(var reservation in offer.Cells)
                {
                    float used=Math.Min(remainder,Math.Min(reservation.Energy,WireCircuit.Finite(reservation.Source.Cell.PowerStored)));
                    if(used<=0)continue;reservation.Source.Cell.PowerStored-=used;remainder-=used;AddLoad(reservation.Path,offer.Branch,used);
                }
                external+=remainder;debt=Math.Min(float.MaxValue/2,debt+external);AddLoad(offer.Path,offer.Branch,external);
                offers.Remove(network);CheckTrips();
            }
        }
        internal void Receive(CableNetwork network,float amount)
        {
            lock(gate)
            {
                if(network==null)return;
                amount=WireCircuit.Finite(amount);
                if(!ReferenceEquals(network,state.Input)){PayOwn(network,amount);return;}float repaid=Math.Min(debt,amount);debt-=repaid;amount-=repaid;amount=PayOwn(network,amount);ClearLoad(3);
                foreach(var source in state.Cells)
                {
                    if(!source.Charge||amount<=0)continue;
                    float charged=Math.Min(Math.Min(amount,Math.Min(1000f,WireCircuit.Finite(source.Cell.PowerDelta))),TransferRemaining(source.ChargePath));
                    source.Cell.PowerStored+=charged;amount-=charged;AddLoad(source.ChargePath,3,charged);
                }
                CheckTrips();
            }
        }
        internal void ObserveIdle(CableNetwork network){lock(gate){int branch=Branch(network);if(branch>=0)ClearLoad(branch);if(network!=null)offers.Remove(network);}}
        internal long[] DrainTrips(){lock(gate){var result=trips.ToArray();trips.Clear();return result;}}
        internal bool AllowsPower(CableNetwork network){lock(gate)return network!=null&&ReferenceEquals(network,state.Input);}
        internal bool IsProviderTo(Device self,Device other,ref List<long> visited)
        {
            CableNetwork input;lock(gate)input=state.Input;
            if(other==null||input?.PowerTick?.InputOutputDevices==null||visited.Contains(self.ReferenceId))return false;
            visited.Add(self.ReferenceId);var providers=input.PowerTick.InputOutputDevices;
            if(providers.Any(p=>p?.Device==other))return true;
            foreach(var provider in providers){if(provider?.Device==null)continue;if(visited.Count>=Device.MaxProviderRecursionIterations)return false;if(provider.Device.IsProviderToDevice(other,ref visited))return true;}return false;
        }
    }
}
