using System;
using System.Collections.Generic;
using System.Linq;
using Assets.Scripts;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Items;
using LibConstruct;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class CoverTransfer
    {
        internal static bool Remove(InnerCoverModule cover,Attack attack,bool doAction,out Thing.DelayedActionInstance result)
        {
            result=null;
            if(cover.IsBeingDestroyed){result=new Thing.DelayedActionInstance{Duration=0};result.Fail("The cover is already being removed.");return true;}
            if(cover.Labels==null||!cover.Labels.Structures.OfType<SwitchboardLabel>().Any(l=>!l.IsBeingDestroyed))return false;
            var use=cover.BuildStates[0].Tool;var tool=attack.SourceItem as Tool;
            if(tool==null||!use.IsToolExit(tool))return false;
            result=new Thing.DelayedActionInstance{Duration=use.ExitTime,ActionMessage="Remove fitted cover"};
            if(!tool.IsOperable){result.Fail("The tool is not operable.");return true;}
            if(cover.Host==null||!cover.Host.CanAccessModules){result.Fail("Open the cabinet first.");return true;}
            var prefab=Prefab.Find<PortableCoverItem>(PortableCoverItem.PrefabId);
            if(prefab==null){result.Fail("Fitted cover item unavailable.");return true;}
            if(!doAction||!GameManager.RunSimulation||!(attack.CompletedRatio>=1f))return true;
            CoverMemory state;
            try{state=CoverMemory.Unpack(cover.CaptureMemory().Pack());}
            catch(Exception ex){result.Fail("Could not preserve this cover; it was left installed.");Debug.LogError("[Modular Switchboards] Cover snapshot: "+ex);return true;}
            var item=OnServer.Create<PortableCoverItem>(prefab,cover.transform.TransformPoint(new Vector3(0,0,state.Depth+.12f)),cover.transform.rotation);
            if(item==null){result.Fail("Could not recover the fitted cover.");return true;}
            state.FixedColour=true;item.State=state;
            if(!tool.OnUseItem(use.ExitQuantity,cover)){OnServer.Destroy(item);result.Fail("Tool use failed.");return true;}
            // Clear actual board children without kit refunds; their state belongs
            // to the one item now. Native damage/orphan handling remains unchanged.
            ClearLabels(cover);OnServer.Destroy(cover);OnServer.MoveToSlotOrWorld(item,attack.OtherHand);
            return true;
        }
        internal static void ClearLabels(InnerCoverModule cover)
        {
            if(cover.Labels==null)return;
            foreach(var label in cover.Labels.Structures.OfType<SwitchboardLabel>().ToArray())
            {cover.Labels.Deregister(label);OnServer.Destroy(label);}
        }
        internal static bool Mount(SwitchboardCabinet host,Attack attack,bool doAction,out Thing.DelayedActionInstance result)
        {
            result=null;if(!(attack.SourceItem is PortableCoverItem item))return false;
            result=new Thing.DelayedActionInstance{Duration=2,ActionMessage="Fit saved switchboard cover"};
            if(host==null||host.IsCursor||host.IsBeingDestroyed||!host.IsStructureCompleted||!host.IsOpen||!host.CanFitRails||host.HasInnerCover||item.IsCursor||item.IsBeingDestroyed||item.State==null){result.Fail("Open a completed switchboard without a cover.");return true;}
            var actor=item.RootParentHuman;
            if(actor?.OrganBrain==null||(actor.transform.position-host.transform.position).sqrMagnitude>9||!host.Wiring.ContainsInteractionPoint(attack.Position)){result.Fail("Aim inside a nearby open switchboard.");return true;}
            if(!item.State.Fits(host.CoverProfile)){result.Fail("This cover fits a different cabinet size.");return true;}
            var prefab=Prefab.Find<InnerCoverModule>(SwitchboardsMod.CoverName);
            if(prefab==null||!InnerCoverModule.CanPlace(host.CoverBoard,new Grid3(0,0,0),0)){result.Fail("Cover mounting point unavailable.");return true;}
            if(attack.IsDestroy||attack.IsCopy){result.Fail("Hold left click to fit the cover.");return true;}
            if(!doAction||!GameManager.RunSimulation||!(attack.CompletedRatio>=1f))return true;
            CoverMemory state;
            try{item.State.Validate();state=CoverMemory.Unpack(item.State.Pack());}
            catch(Exception ex){result.Fail("Invalid saved cover; item retained.");Debug.LogError("[Modular Switchboards] Cover state: "+ex);return true;}
            InnerCoverModule mounted=null;var labels=new List<SwitchboardLabel>();
            try
            {
                var grid=new Grid3(0,0,0);var rotation=host.CoverBoard.IndexToRotation(0);
                mounted=Thing.Create<InnerCoverModule>(prefab,host.CoverBoard.GridToWorld(grid),rotation,0);
                mounted.SetStructureData(rotation,actor.OrganBrain.ClientId,grid,state.Colour);host.CoverBoard.Register(mounted);
                mounted.Memory=state;mounted.EnsureLabels();if(mounted.Labels==null)throw new InvalidOperationException("Cover label board not ready.");
                foreach(var saved in state.Labels)
                {
                    var labelPrefab=Prefab.Find<SwitchboardLabel>(SwitchboardsMod.LabelName(saved.Width));if(labelPrefab==null)throw new InvalidOperationException("Label variant missing.");
                    var p=new Grid3(saved.X,saved.Y,0);var label=Thing.Create<SwitchboardLabel>(labelPrefab,mounted.Labels.GridToWorld(p),mounted.Labels.IndexToRotation(0),0);labels.Add(label);saved.OwnerId=label.ReferenceId;
                    label.SetStructureData(mounted.Labels.IndexToRotation(0),actor.OrganBrain.ClientId,p,state.Colour);label.CustomName=saved.Text;label.OnRenamed();mounted.Labels.Register(label);
                }
                mounted.MarkMemoryChanged();OnServer.Destroy(item);
            }
            catch(Exception ex)
            {
                foreach(var label in labels){label.Board?.Deregister(label);OnServer.Destroy(label);}
                if(mounted!=null){ClearLabels(mounted);OnServer.Destroy(mounted);}
                result.Fail("Could not fit the saved cover; item retained.");Debug.LogError("[Modular Switchboards] Cover transfer: "+ex);
            }
            return true;
        }
    }
}
