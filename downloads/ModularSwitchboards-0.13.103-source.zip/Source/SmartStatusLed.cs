using System.Collections.Generic;
using Assets.Scripts.Objects;
using UnityEngine;
namespace ModularSwitchboards
{
    public sealed class SmartStatusLed:MonoBehaviour
    {
        private SmartModule owner;private MeshRenderer lens;private Material material;private int previous=-1;
        internal static void Install(SmartModule module)
        {
            var root=new GameObject("SmartStatusLED"){layer=module.gameObject.layer};root.transform.SetParent(module.transform,false);
            root.transform.localPosition=new Vector3(.009f,.028f,.0738f);
            var v=new List<Vector3>();var n=new List<Vector3>();var t=new List<int>();
            RoundedGeometry.Box(v,n,t,Vector3.zero,new Vector3(.0036f,.0018f,.0007f),.00035f);
            var mesh=new Mesh{name="Smart.StatusLens"};mesh.SetVertices(v);mesh.SetNormals(n);mesh.SetTriangles(t,0);mesh.RecalculateBounds();root.AddComponent<MeshFilter>().sharedMesh=mesh;
            root.AddComponent<MeshRenderer>().sharedMaterial=new Material(Shader.Find("Standard")){name="Smart.StatusLens.Template"};
            module.gameObject.AddComponent<SmartStatusLed>();
        }
        private void Awake()=>Bind();
        private void Bind()
        {
            owner=GetComponent<SmartModule>();lens=transform.Find("SmartStatusLED")?.GetComponent<MeshRenderer>();
            if(lens!=null&&material==null){material=new Material(lens.sharedMaterial){name="Smart.StatusLens.Live"};material.EnableKeyword("_EMISSION");material.SetFloat("_Glossiness",.25f);lens.sharedMaterial=material;}
        }
        private void LateUpdate()
        {
            if(owner==null||lens==null||material==null)Bind();if(owner==null||material==null)return;
            int state=owner.IsCursor?0:(int)owner.RunStatus;if(state==previous)return;previous=state;
            var colour=state==(int)SmartRunState.Running?new Color(.04f,.8f,.08f):state==(int)SmartRunState.Fault?new Color(1f,.38f,.015f):new Color(.025f,.03f,.025f);
            var emission=state==(int)SmartRunState.Running||state==(int)SmartRunState.Fault?colour*1.4f:Color.black;
            material.SetColor("_Color",colour);material.SetColor("_EmissionColor",emission);
            var block=new MaterialPropertyBlock();block.SetColor("_Color",colour);block.SetColor("_EmissionColor",emission);lens.SetPropertyBlock(block);lens.SetPropertyBlock(block,0);
        }
        private void OnDestroy(){if(material!=null)Destroy(material);}
    }
}
