using System;using ModularSwitchboards;
int n=0;
void Check(bool b,string message){n++;if(!b)throw new Exception(message);}
for(int mask=0;mask<128;mask++){
 bool powered=(mask&1)!=0,on=(mask&2)!=0,chip=(mask&4)!=0,error=(mask&8)!=0,program=(mask&16)!=0,inRange=(mask&32)!=0,paused=(mask&64)!=0;
 var state=SmartRunStatus.Evaluate(powered,on,chip,error,program,inRange,paused);
 Check(Enum.IsDefined(state),"unsupported LED colour state");
 if(!powered||!on)Check(state==SmartRunState.Off,"disabled device has a lit status");
 else if(!chip)Check(state==SmartRunState.Idle,"empty slot is running or in error");
 else if(error)Check(state==SmartRunState.Fault,"compile/runtime fault does not take precedence");
 else if(program&&inRange&&!paused)Check(state==SmartRunState.Running,"active program is not green");
 else Check(state==SmartRunState.Idle,"empty/completed/paused program reported running");
}
Check(SmartRunStatus.Evaluate(true,true,true,true,true,true,false)==SmartRunState.Fault,"orange error missing");
Check(SmartRunStatus.Evaluate(true,true,true,false,true,true,false)==SmartRunState.Running,"green recovery missing");
Check(SmartRunStatus.Evaluate(false,true,true,true,true,true,false)==SmartRunState.Off,"power removal did not extinguish fault LED");
Console.WriteLine(n+" Smart status checks passed: green run, orange fault, power gating, empty/completed/paused idle and recovery.");
