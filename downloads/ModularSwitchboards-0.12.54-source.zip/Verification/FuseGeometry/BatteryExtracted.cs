using System;using System.Collections.Generic;using UnityEngine;namespace ModularSwitchboards {static class DinBatteryModel{
        internal static Mesh Build()
        {
            var v=new List<Vector3>();var n=new List<Vector3>();var t=new List<int>[5];for(int i=0;i<5;i++)t[i]=new List<int>();
            float x=DinBatteryLayout.CenterX;
            float width=DinBatteryLayout.Width;
            System.Action<Vector3,Vector3,int> box=(p,s,r)=>RoundedGeometry.Box(v,n,t[r],p,s,.0007f);
            box(new Vector3(x,0,.018f),new Vector3(width,.075f,.032f),1);
            box(new Vector3(x,0,.0345f),new Vector3(width-.006f,.046f,.001f),3);
            foreach(float side in new[]{-1f,1f})
            {
                box(new Vector3(x+side*(width*.5f-.0015f),0,.047f),new Vector3(.003f,.047f,.026f),1);
                box(new Vector3(x,side*.030f,.033f),new Vector3(width,.015f,.058f),1);
                box(new Vector3(x,side*.030f,.0625f),new Vector3(.009f,.009f,.001f),4);
                box(new Vector3(x,side*.030f,.0632f),new Vector3(.006f,.001f,.0004f),3);
                box(new Vector3(x,side*.0376f,.029f),new Vector3(.004f,.0003f,.004f),3);
            }
            var mesh=new Mesh{name="Switchboards.DinBatteryHousing"};mesh.SetVertices(v);mesh.SetNormals(n);mesh.subMeshCount=5;
            for(int i=0;i<5;i++)mesh.SetTriangles(t[i],i);CabinetGeometry.ApplyNativeUv(mesh);mesh.RecalculateBounds();return mesh;
        }
}
    internal static class ModuleLayout
    {
        internal static bool Fits(int x, int y, int z, int rotation, int width, int capacity)
            => x % 10 == 0 && y == 0 && z == 0 && rotation == 0 && width > 0 &&
                x >= 0 && x / 10 + width <= capacity;
        internal static bool Overlaps(int start, int width, int other, int otherWidth)
            => start < other + otherWidth && other < start + width;
    }

}