using UnityEngine;

namespace ModularSwitchboards
{
    // APC-local bounds measured from the preserved original plate/socket mesh.
    internal static class ApcBatteryRegion
    {
        internal const float Width=.040f;
        internal static bool Contains(Vector3 p)=>p.x>=-.155f&&p.x<=-.040f&&p.y>=-.175f&&p.y<=-.060f&&p.z>=.125f&&p.z<=.212f;
        internal static Vector3 Map(Vector3 p,Vector3 center,float minDepth,float scale)
        {
            return new Vector3(DinBatteryLayout.CenterX-(p.y-center.y)*scale/DinBreakerModel.VisualScale.x,
                (p.x-center.x)*scale/DinBreakerModel.VisualScale.y,
                .040f+(p.z-minDepth)*scale/DinBreakerModel.VisualScale.z);
        }
    }
}
