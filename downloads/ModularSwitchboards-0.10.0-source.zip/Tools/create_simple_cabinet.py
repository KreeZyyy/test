import bpy,math,struct,json
from pathlib import Path
OUT=Path(__file__).resolve().parent.parent/'Art'
OUT.mkdir(parents=True,exist_ok=True)
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
bpy.context.preferences.filepaths.save_version=0
scene=bpy.context.scene;scene.unit_settings.system='METRIC'
def mat(name,rgb):
 m=bpy.data.materials.new(name);m.diffuse_color=(*rgb,1);m.use_nodes=True
 bs=m.node_tree.nodes.get('Principled BSDF');bs.inputs['Base Color'].default_value=(*rgb,1);bs.inputs['Metallic'].default_value=.25;bs.inputs['Roughness'].default_value=.65
 return m
materials=[mat('Paintable_Shell',(.55,.58,.6)),mat('Fixed_LightGrey_MountingPlate',(.72,.74,.76)),mat('Fixed_Warning_Yellow',(.95,.7,.025)),mat('Fixed_Black_Details',(.025,.025,.025)),mat('Fixed_Hinge_Metal',(.42,.44,.46))]
collections=[]
for n in ['Frame','Housing','Interior','Door']:
 c=bpy.data.collections.new(n);scene.collection.children.link(c);collections.append(c)
root=bpy.data.objects.new('SimpleSwitchboard_ROOT',None);collections[0].objects.link(root)
pivot=bpy.data.objects.new('Door_Hinge_PIVOT',None);collections[3].objects.link(pivot);pivot.parent=root;pivot.location=(-.2,-.187,0)
def box(name,loc,size,mi,group,parent=root,inner=None):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=bpy.context.object;o.name=name;o.dimensions=size;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
 for c in list(o.users_collection):c.objects.unlink(o)
 collections[group].objects.link(o);o.parent=parent;o.data.materials.append(materials[mi])
 if inner:
  o.data.materials.append(materials[1])
  for p in o.data.polygons:
   if p.normal.dot(inner)>.9:p.material_index=1
 bevel=o.modifiers.new('Manufactured_Edge','BEVEL');bevel.width=.0015;bevel.segments=2
 bpy.context.view_layer.objects.active=o;bpy.ops.object.modifier_apply(modifier=bevel.name)
 return o
from mathutils import Vector
# Bare mounting skeleton only, before the sheet assembly step.
for x in [-.185,.185]:
 box('Frame_Vertical',(x,-.015,0),(.02,.03,.48),4,0)
for z in [-.23,.23]:
 box('Frame_Crossbar',(0,-.015,z),(.35,.03,.02),4,0)
# Completed shell panels
box('Back',(0,-.003,0),(.4,.006,.5),0,1)
box('Left',(-.197,-.09,0),(.006,.18,.5),0,1)
box('Right',(.197,-.09,0),(.006,.18,.5),0,1)
box('Top',(0,-.09,.247),(.388,.18,.006),0,1)
box('Bottom',(0,-.09,-.247),(.388,.18,.006),0,1)
# An empty, light-grey back plate; no rails, cables, holes or electronic devices.
box('Empty_Interior_Plate',(0,-.011,0),(.35,.004,.44),1,2)
box('Solid_Metal_Door',(.2,-.004,0),(.4,.012,.5),0,3,parent=pivot)
box('Handle',(.37,-.025,-.06),(.017,.028,.065),3,3,parent=pivot)
for z in [-.17,.17]:box('Hinge',(-.204,-.18,z),(.014,.023,.035),4,1)
# Warning comes directly from APC at runtime; do not export an approximate substitute.
pivot.rotation_euler.z=0;pivot.keyframe_insert(data_path='rotation_euler',frame=1)
pivot.rotation_euler.z=math.radians(-110);pivot.keyframe_insert(data_path='rotation_euler',frame=30);scene.frame_end=30;scene.frame_set(1)
root['purpose']='Empty cabinet only; no DIN rails or wiring.'
root['dimensions']='400 x 500 x 180 mm';root['construction']='1 kit, then Wrench + 2 Iron Sheets'
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'SimpleSwitchboard.blend'))
bpy.ops.object.select_all(action='SELECT')
bpy.ops.export_scene.gltf(filepath=str(OUT/'SimpleSwitchboard.glb'),export_format='GLB',use_selection=True)
# Offline thumbnails use the same geometry as the game, not a stock locker image.
scene.render.engine='CYCLES';scene.cycles.samples=24;scene.cycles.use_denoising=False
scene.render.resolution_x=256;scene.render.resolution_y=256;scene.render.resolution_percentage=100
scene.render.film_transparent=True
world=scene.world or bpy.data.worlds.new('Studio');scene.world=world;world.use_nodes=True
world.node_tree.nodes['Background'].inputs[0].default_value=(.65,.65,.65,1)
world.node_tree.nodes['Background'].inputs[1].default_value=.7
bpy.ops.object.camera_add(location=(.9,-1.5,.8));camera=bpy.context.object
camera.rotation_euler=(Vector((0,-.07,0))-camera.location).to_track_quat('-Z','Y').to_euler()
camera.data.type='ORTHO';camera.data.ortho_scale=.76;scene.camera=camera
for loc,power,size in [((1,-2,2),140,3),((-2,-1,1),90,2)]:
 bpy.ops.object.light_add(type='AREA',location=loc);light=bpy.context.object;light.data.energy=power;light.data.shape='DISK';light.data.size=size
 light.rotation_euler=(-light.location).to_track_quat('-Z','Y').to_euler()
icons=OUT.parent/'Assets/Icons';icons.mkdir(parents=True,exist_ok=True)
# Outside-view left/right follows Unity's front-face convention after coordinate conversion.
root.scale.x=-1
for name,visible in [('Frame',{0}),('Cabinet',{1,2,3})]:
 for g,c in enumerate(collections):
  for o in c.objects:
   if o.type=='MESH':o.hide_render=g not in visible
 scene.render.filepath=str(icons/(name+'.png'));bpy.ops.render.render(write_still=True)
root.scale.x=1
bpy.context.view_layer.update()
for c in collections:
 for o in c.objects:o.hide_render=False
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'SimpleSwitchboard.blend'))
groups=[]
for g in range(4):
 vv=[];nn=[];ss=[[] for _ in materials]
 for o in collections[g].objects:
  if o.type!='MESH':continue
  mesh=o.data;mesh.calc_loop_triangles();mx=o.matrix_world if g!=3 else pivot.matrix_world.inverted()@o.matrix_world;nm=mx.to_3x3().inverted().transposed()
  for t in mesh.loop_triangles:
   mi=materials.index(o.data.materials[t.material_index]);idx=len(vv)
   for li in t.loops:
    v=mx@mesh.vertices[mesh.loops[li].vertex_index].co;n=(nm@mesh.corner_normals[li].vector).normalized()
    vv.append((v.x,v.z,-v.y));nn.append((n.x,n.z,-n.y))
   ss[mi].extend([idx,idx+1,idx+2])
 groups.append((vv,nn,ss))
out=Path(__file__).resolve().parent.parent/'Assets/Cabinet.meshbin'
out.parent.mkdir(parents=True,exist_ok=True)
with out.open('wb') as f:
 f.write(b'SBMS');f.write(struct.pack('<iii',1,len(materials),4))
 for m in materials:f.write(struct.pack('<6f',*m.diffuse_color,.25,.65))
 for vv,nn,ss in groups:
  f.write(struct.pack('<i',len(vv)))
  for v,n in zip(vv,nn):f.write(struct.pack('<6f',*(v+n)))
  for indices in ss:
   f.write(struct.pack('<i',len(indices)))
   if indices:f.write(struct.pack('<%di'%len(indices),*indices))
print('SIMPLE_MODEL',[(len(v),sum(len(x) for x in s)//3) for v,n,s in groups])
