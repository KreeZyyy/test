import bpy
from pathlib import Path
from mathutils import Vector
root=Path(__file__).resolve().parent.parent
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
materials=[]
for name,rgb in [('Orange',(.95,.45,.03)),('White',(.75,.76,.78)),('Yellow',(.8,.65,.03)),('Black',(.025,.025,.03)),('Metal',(.45,.48,.51)),('Red',(.8,.025,.02))]:
 m=bpy.data.materials.new(name);m.diffuse_color=(*rgb,1);m.use_nodes=True;bs=m.node_tree.nodes.get('Principled BSDF');bs.inputs['Base Color'].default_value=(*rgb,1);bs.inputs['Roughness'].default_value=.5;materials.append(m)
def box(role,loc,size):
 bpy.ops.mesh.primitive_cube_add(size=1,location=(loc[0],-loc[2],loc[1]));o=bpy.context.object;o.dimensions=(size[0],size[2],size[1]);bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.append(materials[role])
 radius=min(.0018,min(size)*.4)
 if role==0:radius=.0015
 if role==4:radius=.0005
 if size==(.0176,.052,.008):radius=.0015
 if size==(.006,.001,.0005):radius=.00015
 bevel=o.modifiers.new('Rounded APC-style edges','BEVEL');bevel.width=radius;bevel.segments=3
 bpy.context.view_layer.objects.active=o;bpy.ops.object.modifier_apply(modifier=bevel.name)
 for poly in o.data.polygons:poly.use_smooth=True
 normal=o.modifiers.new('Weighted corner normals','WEIGHTED_NORMAL');bpy.ops.object.modifier_apply(modifier=normal.name)
 return o
box(1,(0,0,.029),(.0176,.075,.056))
box(1,(0,0,.059),(.0176,.052,.008))
box(3,(0,0,.0635),(.013,.033,.001))
bpy.ops.object.empty_add(location=(0,-.064,-.005));pivot=bpy.context.object;pivot.name='Lever_OFF_Pivot'
lever=box(0,(0,0,0),(.012,.007,.009));lever.parent=pivot;lever.location=(0,-.0045,0)
import math
pivot.rotation_euler.x=math.radians(25)
box(5,(0,.023,.0645),(.01,.003,.001))
for side in [-1,1]:
 box(4,(0,side*.03,.0577),(.009,.009,.0015))
 box(3,(0,side*.03,.0586),(.006,.001,.0005))
for obj in bpy.context.scene.objects:
 if obj.type=='MESH' and obj.parent is None: obj.scale=(2.25,1.15,1.35);obj.location.x*=2.25;obj.location.y*=1.15;obj.location.z*=1.35
pivot.scale=(2.25,1.15,1.35);pivot.location.x*=2.25;pivot.location.y*=1.15;pivot.location.z*=1.35
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=24;scene.cycles.use_denoising=False
scene.render.resolution_x=256;scene.render.resolution_y=256;scene.render.resolution_percentage=100;scene.render.film_transparent=True
scene.world.color=(.4,.4,.4)
bpy.ops.object.camera_add(location=(.10,-.25,.14));camera=bpy.context.object;camera.rotation_euler=(Vector((0,-.03,0))-camera.location).to_track_quat('-Z','Y').to_euler();camera.data.type='ORTHO';camera.data.ortho_scale=.15;scene.camera=camera
for loc,power in [((.1,-.3,.4),40),((-.3,.1,.2),25)]:
 bpy.ops.object.light_add(type='AREA',location=loc);bpy.context.object.data.energy=power;bpy.context.object.data.size=.5
bpy.context.preferences.filepaths.save_version=0
bpy.ops.wm.save_as_mainfile(filepath=str(root/'Art/DinBreaker.blend'))
scene.render.filepath=str(root/'Assets/Icons/DinBreaker.png');bpy.ops.render.render(write_still=True)
