using System;
using System.Linq;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Electrical;
using UnityEngine;

namespace ModularSwitchboards
{
    internal static class ApcLeverGeometry
    {
        private static Mesh mesh;
        private static Material[] materials;
        private static MaterialPropertyBlock[] blocks;
        private static bool attempted;

        internal static bool TryGet(out Mesh result,out Material[] surface)
        {
            if(!attempted)
            {
                attempted=true;
                try
                {
                    var prefabs=WorldManager.Instance.SourcePrefabs.OfType<AreaPowerControl>();
                    var apc=prefabs.FirstOrDefault(p=>p.PrefabName=="StructureAreaPowerControl") ?? prefabs.FirstOrDefault();
                    var source=apc==null?null:apc.GetComponentsInChildren<MeshRenderer>(true).FirstOrDefault(r=>r.name=="MasterLever");
                    var original=source==null?null:source.GetComponent<MeshFilter>()?.sharedMesh;
                    if(original!=null)
                    {
                        CabinetGeometry.ReadNativeMesh(original,out var points,out var uv,out var triangles);
                        var matrix=apc.transform.worldToLocalMatrix*source.transform.localToWorldMatrix;
                        if(CabinetModel.FrontSign<0)matrix=Matrix4x4.Rotate(Quaternion.Euler(0,180,0))*matrix;
                        for(int i=0;i<points.Length;i++)points[i]=matrix.MultiplyPoint3x4(points[i]);
                        var bounds=new Bounds(points[0],Vector3.zero);foreach(var p in points)bounds.Encapsulate(p);
                        var size=bounds.size;
                        float scale=Mathf.Min(.013f/Mathf.Max(size.x,.00001f),Mathf.Min(.014f/Mathf.Max(size.y,.00001f),.014f/Mathf.Max(size.z,.00001f)));
                        for(int i=0;i<points.Length;i++)points[i]=(points[i]-bounds.center)*scale+new Vector3(0,0,size.z*scale*.5f);
                        mesh=new Mesh{name="Switchboards.NativeAPCMasterLever"};mesh.vertices=points;mesh.uv=uv;mesh.subMeshCount=triangles.Length;
                        for(int sub=0;sub<triangles.Length;sub++)
                        {
                            if(matrix.determinant<0)for(int j=0;j<triangles[sub].Length;j+=3){int swap=triangles[sub][j+1];triangles[sub][j+1]=triangles[sub][j+2];triangles[sub][j+2]=swap;}
                            mesh.SetTriangles(triangles[sub],sub);
                        }
                        mesh.RecalculateNormals();mesh.RecalculateTangents();mesh.RecalculateBounds();
                        materials=source.sharedMaterials;
                        blocks=new MaterialPropertyBlock[materials.Length];var global=new MaterialPropertyBlock();source.GetPropertyBlock(global);
                        for(int i=0;i<blocks.Length;i++){var block=new MaterialPropertyBlock();source.GetPropertyBlock(block,i);blocks[i]=block.isEmpty?global:block;}
                        Debug.Log("[Modular Switchboards] Native APC MasterLever reused: "+points.Length+" vertices; original UV and materials retained.");
                    }
                }
                catch(Exception ex){mesh=null;Debug.LogWarning("[Modular Switchboards] APC lever extraction: "+ex.Message);}
                if(mesh==null)Debug.LogWarning("[Modular Switchboards] Native APC lever unavailable; rounded prototype handle used.");
            }
            result=mesh;surface=materials;return mesh!=null;
        }
        internal static bool Restore(Renderer renderer)
        {
            if(mesh==null || renderer.GetComponent<MeshFilter>()?.sharedMesh!=mesh)return false;
            for(int i=0;i<blocks.Length;i++)renderer.SetPropertyBlock(blocks[i],i);
            return true;
        }
    }
}
