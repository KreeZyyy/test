using System.Collections.Generic;
using System.Linq;
using Assets.Scripts;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Motherboards;
using HarmonyLib;
using Rendering;
using Assets.Scripts.UI;
using UnityEngine;
using UnityEngine.Rendering;

namespace ModularSwitchboards
{
    internal static class DinRailModel
    {
        // TH35-style top-hat section, 35 mm high, 7.5 mm deep, 1 mm sheet.
        internal static Mesh Build(float length)
        {
            var vertices = new List<Vector3>();
            var indices = new List<int>();
            AddBox(vertices, indices, new Vector3(0,0,.0005f), new Vector3(length,.022f,.001f));
            foreach (float side in new[] {-1f,1f})
            {
                AddBox(vertices, indices, new Vector3(0,side*.0115f,.004f),new Vector3(length,.001f,.007f));
                AddBox(vertices, indices, new Vector3(0,side*.0145f,.007f),new Vector3(length,.006f,.001f));
            }
            var mesh = new Mesh { name = "Switchboards.DIN35" };
            mesh.SetVertices(vertices); mesh.subMeshCount=5;
            for (int i=0;i<5;i++) mesh.SetTriangles(i==4?indices.ToArray():new int[0],i);
            mesh.RecalculateNormals(); CabinetGeometry.ApplyNativeUv(mesh); mesh.RecalculateBounds();
            return mesh;
        }
        internal static void AddBox(List<Vector3> v,List<int> t,Vector3 center,Vector3 size)
        {
            // Separate vertices per face keep the thin sheet's edges crisp.
            var normals=new[]{Vector3.right,Vector3.left,Vector3.up,Vector3.down,Vector3.forward,Vector3.back};
            foreach(var normal in normals)
            {
                var u=Mathf.Abs(normal.y)>.5f?Vector3.right:Vector3.up;
                var w=Vector3.Cross(normal,u);
                int first=v.Count;
                foreach(var corner in new[]{-u-w,u-w,u+w,-u+w})
                    v.Add(center+Vector3.Scale(normal+corner,size)*.5f);
                t.AddRange(new[]{first,first+1,first+2,first,first+2,first+3});
            }
        }
        internal static void Install(DinRail rail, Transform storage)
        {
            foreach(var component in rail.GetComponentsInChildren<Renderer>(true)) Object.DestroyImmediate(component);
            foreach(var component in rail.GetComponentsInChildren<MeshFilter>(true)) Object.DestroyImmediate(component);
            foreach(var component in rail.GetComponentsInChildren<Collider>(true)) Object.DestroyImmediate(component);
            foreach(var component in rail.GetComponentsInChildren<Animator>(true)) Object.DestroyImmediate(component);
            rail.BaseAnimator=null;
            rail.Renderers=new List<ThingRenderer>();
            rail.Interactables=new List<Interactable>();rail.Slots=new List<Slot>();
            rail._staticColliders=new List<Collider>();rail._dynamicColliders=new List<Collider>();rail._selfColliders=new List<Collider>();
            rail.CustomNavMeshFilter=null;rail.structureRenderMode=StructureRenderMode.Standard;
            rail.ForceGridBounds.Clear();rail.BrokenBuildStates=new List<BrokenBuildState>();
            rail.StructureCollisionType=CollisionType.BlockCustom;
            rail.SelectionDisplay=SelectionHighlightMethod.Bounds;rail.UseCellPosition=false;
            rail.PaintableMaterial=null;rail.HasColorState=false;rail.MPBRenderers.Clear();
            var model=new GameObject("DinRailModel"){layer=rail.gameObject.layer};model.transform.SetParent(rail.transform,false);
            var mesh=Build(DinLayout.RailLength(DinLayout.CabinetInnerWidth));
            model.AddComponent<MeshFilter>().sharedMesh=mesh;
            var renderer=model.AddComponent<MeshRenderer>();renderer.sharedMaterials=CabinetGeometry.Materials;
            renderer.lightProbeUsage=LightProbeUsage.BlendProbes;renderer.reflectionProbeUsage=ReflectionProbeUsage.BlendProbes;
            renderer.shadowCastingMode=ShadowCastingMode.On;renderer.receiveShadows=true;
            var collider=model.AddComponent<BoxCollider>();collider.center=mesh.bounds.center;collider.size=mesh.bounds.size;
            rail.Bounds=mesh.bounds;rail.SurfaceArea=.025f;
            rail.GridBounds=new GridBounds(rail);
            rail.Thumbnail=CabinetIcons.Get("DinRail");rail.Thumbnails=new Sprite[0];
            var state=rail.BuildStates[0];state.Visualizer=renderer;state.StateMeshes=new List<Mesh>();state.RendererInstance=null;
            state.Colliders=new List<Collider>{collider};state.Interactables=new List<Interactable>();
            state.LinkedGameObjects=new List<GameObject>();state.RenderMode=BuildStateRenderMode.OnMyState;
            state.BlockAir=state.AlwaysBlockAir=state.BlockLight=state.BlockGravity=false;state.Thumbnail=rail.Thumbnail;
            AccessTools.Field(typeof(BuildState),"initialDrawData").SetValue(state,new DrawData{mesh=null,materials=new Material[0]});
            var blueprint=new GameObject("DinRailBlueprint"){layer=rail.gameObject.layer};blueprint.transform.SetParent(storage,false);
            var filter=blueprint.AddComponent<MeshFilter>();filter.sharedMesh=mesh;
            var br=blueprint.AddComponent<MeshRenderer>();br.sharedMaterial=CabinetGeometry.Materials[4];
            var wire=blueprint.AddComponent<Wireframe>();wire.BlueprintTransform=blueprint.transform;
            wire.BlueprintBounds=mesh.bounds;wire.BlueprintMeshFilter=filter;wire.BlueprintRenderer=br;
            blueprint.AddComponent<CabinetBlueprint>();
            rail.Blueprint=blueprint;rail.BlueprintOrientVector=Vector3.zero;
            var moduleOrigin = new GameObject("DinModuleBoard") { layer = rail.gameObject.layer };
            moduleOrigin.transform.SetParent(rail.transform, false);
            float halfSpan = (rail.ModuleCapacity - 1) * DinLayout.SlotPitch * .5f;
            moduleOrigin.transform.localPosition = new Vector3(-halfSpan, 0, .0065f);
            rail.ModuleOrigin = moduleOrigin.transform;
            rail.ModuleSurface = moduleOrigin.AddComponent<BoxCollider>();
            rail.ModuleSurface.center = new Vector3(halfSpan, 0, .002f);
            rail.ModuleSurface.size = new Vector3(rail.ModuleCapacity * DinLayout.SlotPitch, .105f, .001f);
            state.Colliders.Add(rail.ModuleSurface);
        }
        internal static void Refresh(Thing rail)
        {
            foreach(var renderer in rail.GetComponentsInChildren<MeshRenderer>(true))
            {
                if(renderer.name!="DinRailModel")continue;
                var block=new MaterialPropertyBlock();
                renderer.GetPropertyBlock(block,4);
                block.SetFloat(Thing.DiffuseIndexPropertyID,CabinetGeometry.PaletteIndices[4]);
                block.SetFloat(Thing.SmoothnessIndexPropertyID,rail.SmoothnessIndex);
                block.SetColor(Thing.EMISSION_COLOR,Color.black);renderer.SetPropertyBlock(block,4);
            }
        }
    }
}
