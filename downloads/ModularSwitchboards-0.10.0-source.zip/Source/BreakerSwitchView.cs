using UnityEngine;
using Assets.Scripts.Objects.Motherboards;

namespace ModularSwitchboards
{
    internal static class BreakerSwitchPose
    {
        internal static int IndicatorColor(bool on) => (int)(on ? ColorType.Green : ColorType.Red);
        internal static float LeverY(bool on) => on ? .005f : -.005f;
        internal static float LeverAngle(bool on) => on ? -25f : 25f;
    }

    // The native OnOff interactable owns the saved/networked state. This only renders it.
    public sealed class BreakerSwitchView : MonoBehaviour
    {
        public DinBreaker Owner;
        public Transform Lever;
        private bool initialized;
        private bool previous;

        private void LateUpdate()
        {
            if (Owner == null || Lever == null) return;
            bool on = Owner.OnOff;
            if (initialized && previous == on) return;
            Apply(on);
        }
        internal void Apply(bool on)
        {
            if (Lever == null) return;
            Lever.localPosition = new Vector3(0, BreakerSwitchPose.LeverY(on), .064f);
            Lever.localRotation = Quaternion.Euler(BreakerSwitchPose.LeverAngle(on), 0, 0);
            previous = on; initialized = true;
            if (Owner != null) DinBreakerModel.Refresh(Owner);
        }
    }
}
