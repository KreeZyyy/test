using System;
using System.Collections.Generic;
using Assets.Scripts.Objects;
using UnityEngine;

namespace ModularSwitchboards
{
    public sealed class OvenInputSupportState : MonoBehaviour
    {
        [NonSerialized] public Mesh InstanceMesh;
        private void OnDestroy(){if(InstanceMesh!=null)UnityEngine.Object.Destroy(InstanceMesh);}
    }

    // Model-only transition from the middle warning box to the top IN face.
    internal static class OvenInputSupport
    {
        internal const string RootName="OvenInputSupport";
        internal static void Install(SwitchboardCabinet cabinet)
        {
            var shell=cabinet.transform.Find("SwitchboardModel/CompletedShell");
            if(shell==null || shell.Find(OvenInputPanel.RootName)==null)return;
            var root=new GameObject(RootName){layer=cabinet.gameObject.layer};root.transform.SetParent(shell,false);
            root.AddComponent<MeshFilter>();root.AddComponent<OvenInputSupportState>();
            root.AddComponent<MeshRenderer>().sharedMaterials=CabinetGeometry.Materials;
            root.AddComponent<MeshCollider>();
            Fit(cabinet);CabinetRearSurface.Restore(root.GetComponent<MeshRenderer>());
            cabinet.BuildStates[1].Colliders.Add(root.GetComponent<MeshCollider>());
            CabinetModel.SetBounds(cabinet);
        }

        internal static void Fit(Structure cabinet)
        {
            var shell=cabinet.transform.Find("SwitchboardModel/CompletedShell");
            if(shell==null)return;
            var support=shell.Find(RootName);var panel=shell.Find(OvenInputPanel.RootName);var box=shell.Find("NativeApcRearBox");
            if(support==null||panel==null||box==null)return;
            var panelMesh=panel.GetComponent<MeshFilter>()?.sharedMesh;var boxMesh=box.GetComponent<MeshFilter>()?.sharedMesh;
            if(panelMesh==null||boxMesh==null)return;
            var top=CabinetWallMount.TransformedBounds(panelMesh.bounds,shell.worldToLocalMatrix*panel.localToWorldMatrix);
            var bottom=CabinetWallMount.TransformedBounds(boxMesh.bounds,shell.worldToLocalMatrix*box.localToWorldMatrix);
            float low=bottom.max.y-.0055f,high=panel.localPosition.y-.0005f;
            if(high<=low)return;
            float halfWidth=top.size.x*.5f;
            var corners=new[]{
                new Vector3(-halfWidth,low,bottom.min.z),new Vector3(halfWidth,low,bottom.min.z),
                new Vector3(halfWidth,low,bottom.max.z),new Vector3(-halfWidth,low,bottom.max.z),
                new Vector3(top.min.x,high,top.min.z),new Vector3(top.max.x,high,top.min.z),
                new Vector3(top.max.x,high,top.max.z),new Vector3(top.min.x,high,top.max.z)};
            var faces=new[]{new[]{0,3,2,1},new[]{0,1,5,4},new[]{1,2,6,5},new[]{2,3,7,6},new[]{3,0,4,7}};
            var vertices=new List<Vector3>();var indices=new List<int>();
            foreach(var face in faces)
            {
                int start=vertices.Count;foreach(int id in face)vertices.Add(corners[id]);
                indices.AddRange(new[]{start,start+2,start+1,start,start+3,start+2});
            }
            // Ensure exterior winding independent of face-list convention.
            var center=(corners[0]+corners[1]+corners[2]+corners[3]+corners[4]+corners[5]+corners[6]+corners[7])/8f;
            for(int i=0;i<indices.Count;i+=3)
            {
                var a=vertices[indices[i]];var b=vertices[indices[i+1]];var c=vertices[indices[i+2]];
                if(Vector3.Dot(Vector3.Cross(b-a,c-a),(a+b+c)/3f-center)<0f){int temp=indices[i+1];indices[i+1]=indices[i+2];indices[i+2]=temp;}
            }
            var state=support.GetComponent<OvenInputSupportState>();
            if(state.InstanceMesh==null)state.InstanceMesh=new Mesh{name="Switchboards.InputTransition"};
            var mesh=state.InstanceMesh;support.GetComponent<MeshFilter>().sharedMesh=mesh;mesh.Clear();mesh.SetVertices(vertices);mesh.subMeshCount=5;
            for(int i=0;i<5;i++)mesh.SetTriangles(i==CabinetRearSurface.Role?indices.ToArray():new int[0],i);
            mesh.RecalculateNormals();CabinetGeometry.ApplyNativeUv(mesh);CabinetRearSurface.ApplyUv(mesh);mesh.RecalculateBounds();
            var collider=support.GetComponent<MeshCollider>();collider.sharedMesh=null;collider.sharedMesh=mesh;
        }

        internal static void IncludeBounds(Structure cabinet,ref Bounds bounds)
        {
            var root=cabinet.transform.Find("SwitchboardModel/CompletedShell/"+RootName);
            var mesh=root==null?null:root.GetComponent<MeshFilter>()?.sharedMesh;
            if(mesh!=null)bounds.Encapsulate(CabinetWallMount.TransformedBounds(mesh.bounds,cabinet.transform.worldToLocalMatrix*root.localToWorldMatrix));
        }
    }
}
