using System;using System.Linq;using System.Collections.Generic;
using Assets.Scripts.GridSystem;using LibConstruct;using UnityEngine;
namespace ModularSwitchboards {
 public sealed class DoorDisplayLabel:DoorLabel {
  public const string PrefabId="StructureSwitchboardDoorDisplayLabel";
  internal static DoorSmartDisplay TargetDisplay(PlacementBoard board,Grid3 p){var host=board?.PrimaryHost as SwitchboardCabinet;return host?.DoorBoardFor(board)?.Structures.OfType<DoorSmartDisplay>().FirstOrDefault(d=>!d.IsBeingDestroyed&&!d.IsCursor&&d.IsStructureCompleted&&Same(board.WorldToGrid(d.transform.position),p));}
  private static bool Same(Grid3 a,Grid3 b)=>a.x==b.x&&a.y==b.y&&a.z==b.z;
  internal static bool Attached(DoorSmartDisplay display){var board=display.Cabinet?.DoorLabelsFor(display.Board);return board!=null&&board.Structures.OfType<DoorDisplayLabel>().Any(l=>!l.IsBeingDestroyed&&Same(board.WorldToGrid(l.transform.position),display.GetLocalGrid()));}
 }
    internal static class DoorDisplayLabelModel
    {
        private static Vector3 P(float x,float y,float z)=>new Vector3(.05f+x+(x>=0?.061f:-.061f),y,z);
        internal static Mesh Build()
        {
            var v=new List<Vector3>();var border=new List<int>();var face=new List<int>();
            for(int i=0;i<32;i++)
            {
                float a=i*Mathf.PI/16,b=(i+1)*Mathf.PI/16;
                var ia=P(.0285f*Mathf.Cos(a),.0285f*Mathf.Sin(a),-.0008f);var ib=P(.0285f*Mathf.Cos(b),.0285f*Mathf.Sin(b),-.0008f);
                var oa=P(.031f*Mathf.Cos(a),.031f*Mathf.Sin(a),-.0008f);var ob=P(.031f*Mathf.Cos(b),.031f*Mathf.Sin(b),-.0008f);
                var iaf=new Vector3(ia.x,ia.y,.0012f);var ibf=new Vector3(ib.x,ib.y,.0012f);var oaf=new Vector3(oa.x,oa.y,.0012f);var obf=new Vector3(ob.x,ob.y,.0012f);
                Quad(v,border,oa,ob,obf,oaf);Quad(v,border,ib,ia,iaf,ibf);Quad(v,border,iaf,oaf,obf,ibf);Quad(v,border,ib,ob,oa,ia);
            }
            DinRailModel.AddBox(v,border,new Vector3(.05f,.050f,0),new Vector3(.192f,.032f,.003f));
            DinRailModel.AddBox(v,face,new Vector3(.05f,.050f,.0018f),new Vector3(.180f,.027f,.001f));
            // Upper silhouette joins the nameplate to the ring without bridging its hole.
            for(int i=0;i<16;i++)
            {
                float a=i*Mathf.PI/16,b=(i+1)*Mathf.PI/16;
                float x1=.031f*Mathf.Cos(a),x2=.031f*Mathf.Cos(b);
                float y1=.031f*Mathf.Sin(a),y2=.031f*Mathf.Sin(b);
                var l=P(x1,y1,-.0008f);var r=P(x2,y2,-.0008f);
                var lt=P(x1,.035f,-.0008f);var rt=P(x2,.035f,-.0008f);
                var lf=P(x1,y1,.0012f);var rf=P(x2,y2,.0012f);
                var ltf=P(x1,.035f,.0012f);var rtf=P(x2,.035f,.0012f);
                Quad(v,border,rf,lf,ltf,rtf);Quad(v,border,l,r,rt,lt);
                Quad(v,border,r,l,lf,rf);Quad(v,border,lt,rt,rtf,ltf);
                if(i==0)Quad(v,border,l,lt,ltf,lf);
                if(i==15)Quad(v,border,rt,r,rf,rtf);
            }
            var mesh=new Mesh{name="Smart Display Label — widened button ring"};mesh.SetVertices(v);mesh.subMeshCount=5;
            for(int i=0;i<5;i++)mesh.SetTriangles(i==0?border.ToArray():i==1?face.ToArray():new int[0],i);
            mesh.RecalculateNormals();mesh.RecalculateBounds();return mesh;
        }
        private static void Quad(List<Vector3> v,List<int> t,Vector3 a,Vector3 b,Vector3 c,Vector3 d){int p=v.Count;v.AddRange(new[]{a,b,c,d});t.AddRange(new[]{p,p+1,p+2,p,p+2,p+3});}
    }
 public sealed class DoorDisplayLabelView:MonoBehaviour {
  private DoorDisplayLabel owner;private TextMesh text;
  private void LateUpdate(){if(owner==null||owner.gameObject!=gameObject||text==null){owner=GetComponent<DoorDisplayLabel>();text=transform.Find("DisplayLabelText")?.GetComponent<TextMesh>();}if(owner==null||text==null)return;string value=owner.CustomName;if(string.IsNullOrWhiteSpace(value)||value=="Smart Display Label")value="DISPLAY";value=value.Replace('\r',' ').Replace('\n',' ');var info=new System.Globalization.StringInfo(value);if(info.LengthInTextElements>48)value=info.SubstringByTextElements(0,47)+"…";text.text=value;text.transform.localScale=Vector3.one;var size=text.GetComponent<MeshRenderer>().localBounds.size;text.transform.localScale=Vector3.one*Mathf.Min(.170f/Mathf.Max(.0001f,size.x),.015f/Mathf.Max(.0001f,size.y));DepthLabelText.Apply(text);}
  internal static void Install(DoorDisplayLabel label){Font font=null;foreach(var name in new[]{"LegacyRuntime.ttf","Arial.ttf"}){try{font=Resources.GetBuiltinResource<Font>(name);}catch(Exception){}if(font!=null)break;}if(font==null)font=Resources.FindObjectsOfTypeAll<Font>().FirstOrDefault();if(font==null)throw new InvalidOperationException("Display label font unavailable.");var go=new GameObject("DisplayLabelText"){layer=label.gameObject.layer};go.transform.SetParent(label.transform,false);go.transform.localPosition=new Vector3(.05f,.050f,.0032f);go.transform.localRotation=Quaternion.Euler(0,180,0);var text=go.AddComponent<TextMesh>();text.font=font;text.fontSize=96;text.fontStyle=FontStyle.Bold;text.characterSize=.01f;text.anchor=TextAnchor.MiddleCenter;text.alignment=TextAlignment.Center;text.richText=false;text.color=Color.black;text.text="DISPLAY";DepthLabelText.Apply(text);label.gameObject.AddComponent<DoorDisplayLabelView>();}
 }
}
