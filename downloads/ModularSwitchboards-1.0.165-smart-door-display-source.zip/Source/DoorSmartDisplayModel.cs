using System;using System.Linq;using System.Collections.Generic;
using LibConstruct;using Assets.Scripts;using Assets.Scripts.Objects;using Assets.Scripts.Objects.Electrical;using Assets.Scripts.Objects.Motherboards;using Assets.Scripts.UI;using HarmonyLib;using Rendering;using UnityEngine;
namespace ModularSwitchboards {
 internal static class DoorSmartDisplayModel {
  internal static Bounds BodyBounds=>new Bounds(new Vector3(.05f,0,-.012f),new Vector3(.172f,.060f,.044f));
  internal static void SetBounds(DoorSmartDisplay display){display.ThingTransform=display.transform;display.Bounds=BodyBounds;display.GridBounds=new GridBounds(display);}
  internal static void Install(DoorSmartDisplay display,LogicDisplay source,Transform storage){
   var screenBounds=CabinetWallMount.TransformedBounds(source.ScreenMesh.GetComponent<MeshFilter>().sharedMesh.bounds,source.transform.worldToLocalMatrix*source.ScreenMesh.transform.localToWorldMatrix);
   var nativeBody=source.GetComponentsInChildren<MeshRenderer>(true).First(r=>r!=source.ScreenMesh&&r.GetComponent<MeshFilter>()?.sharedMesh!=null&&r.name==source.PrefabName);
   var bezel=NativeMeshCrop.Read(nativeBody.GetComponent<MeshFilter>().sharedMesh,source.transform.worldToLocalMatrix*nativeBody.transform.localToWorldMatrix,new Bounds(screenBounds.center+new Vector3(0,0,.006f),new Vector3(.51f,.18f,.045f)),"DoorSmartDisplay.NativeBezel",LedBezelGeometry.KeepTriangle);
   if(bezel==null)throw new InvalidOperationException("Door display native bezel extraction empty.");
   foreach(var animator in display.GetComponentsInChildren<Animator>(true))UnityEngine.Object.DestroyImmediate(animator);
   foreach(var hit in display.GetComponentsInChildren<Collider>(true))UnityEngine.Object.DestroyImmediate(hit);
   foreach(var renderer in display.GetComponentsInChildren<MeshRenderer>(true))if(renderer!=display.ScreenMesh){var filter=renderer.GetComponent<MeshFilter>();if(filter!=null)UnityEngine.Object.DestroyImmediate(filter);UnityEngine.Object.DestroyImmediate(renderer);}
   var children=new List<Transform>();foreach(Transform child in display.transform)children.Add(child);
   var screen=new GameObject("DoorDisplayNativeScreen"){layer=display.gameObject.layer};screen.transform.SetParent(display.transform,false);foreach(var child in children)child.SetParent(screen.transform,false);
   float scale=.150f/screenBounds.size.x;screen.transform.localScale=Vector3.one*scale;screen.transform.localPosition=new Vector3(.05f,0,.003f)-screenBounds.center*scale;
   var bezelGo=new GameObject("NativeLEDBezel"){layer=display.gameObject.layer};bezelGo.transform.SetParent(screen.transform,false);bezelGo.AddComponent<MeshFilter>().sharedMesh=bezel;NativePortSurface.Capture(nativeBody,bezelGo.AddComponent<MeshRenderer>());NativePortSurface.Capture(source.ScreenMesh,display.ScreenMesh);
   // Only the original native screen and bezel are visible on the door.
   // The empty mount owns a selection collider; it adds no pedestal geometry.
   var body=new GameObject("DoorSmartDisplayMount"){layer=display.gameObject.layer};body.transform.SetParent(display.transform,false);var rendererBody=bezelGo.GetComponent<MeshRenderer>();
   var terminalV=new List<Vector3>();var terminalN=new List<Vector3>();var terminalT=new List<int>();RoundedGeometry.Box(terminalV,terminalN,terminalT,new Vector3(.05f,.025f,-.017f),new Vector3(.022f,.018f,.028f),.001f);var terminalMesh=new Mesh{name="DoorDisplay.DATA.IN"};terminalMesh.SetVertices(terminalV);terminalMesh.SetNormals(terminalN);terminalMesh.SetTriangles(terminalT,0);terminalMesh.RecalculateBounds();var terminal=new GameObject("DisplayDataTerminal"){layer=display.gameObject.layer};terminal.transform.SetParent(display.transform,false);terminal.AddComponent<MeshFilter>().sharedMesh=terminalMesh;terminal.AddComponent<MeshRenderer>().sharedMaterials=CabinetGeometry.Materials;
   var hitBody=body.AddComponent<BoxCollider>();hitBody.center=BodyBounds.center;hitBody.size=BodyBounds.size;
   display.Renderers=new List<ThingRenderer>();display._staticColliders=new List<Collider>();display._dynamicColliders=new List<Collider>();display._selfColliders=new List<Collider>();display.BaseAnimator=null;display.OnOffButton=null;display.Slots=new List<Slot>();display.OpenEnds=new List<Connection>();display.UseCellPosition=false;display.CustomNavMeshFilter=null;display.StructureCollisionType=CollisionType.BlockCustom;display.SelectionDisplay=SelectionHighlightMethod.Bounds;display.CustomColor=GameManager.GetColorSwatch((int)ColorType.White);display.PaintableMaterial=display.CustomColor.Normal;display.MPBRenderers.Clear();display.UsedPower=source.UsedPower;display.InputNetwork1=null;display.OutputNetwork1=null;display.UpgradePrefab=null;
   display.Interactables=display.Interactables.Where(i=>i.Action==InteractableType.OnOff||i.Action==InteractableType.Powered||i.Action==InteractableType.Mode).ToList();foreach(var i in display.Interactables){i.Parent=display;i.Collider=null;i.Animator=null;i.FakeCollider=null;i.ParentInteractableIndex=-1;}
   SmartPrefabState.Configure(display);
   var state=display.BuildStates[0];state.Visualizer=rendererBody;state.StateMeshes=new List<Mesh>();state.RendererInstance=null;state.Colliders=new List<Collider>{hitBody};state.Interactables=display.Interactables;state.LinkedGameObjects=new List<GameObject>();state.RenderMode=BuildStateRenderMode.OnMyState;state.BlockAir=state.AlwaysBlockAir=state.BlockLight=state.BlockGravity=false;
   AccessTools.Field(typeof(BuildState),"initialDrawData").SetValue(state,new DrawData{mesh=null,materials=new Material[0]});PrefabAudioOwner.Rebind(display);SetBounds(display);
   var bp=new GameObject("DoorSmartDisplayBlueprint"){layer=display.gameObject.layer};bp.transform.SetParent(storage,false);var previewMesh=ModelBlueprint.Build(display.transform);var previewFilter=bp.AddComponent<MeshFilter>();previewFilter.sharedMesh=previewMesh;var previewRenderer=bp.AddComponent<MeshRenderer>();previewRenderer.sharedMaterial=CabinetGeometry.Materials[4];var wire=bp.AddComponent<Wireframe>();wire.BlueprintTransform=bp.transform;wire.BlueprintBounds=previewMesh.bounds;wire.BlueprintMeshFilter=previewFilter;wire.BlueprintRenderer=previewRenderer;bp.AddComponent<CabinetBlueprint>();display.Blueprint=bp;display.BlueprintOrientVector=Vector3.zero;FittedModelCollider.Install(display,previewMesh);
  }
 }
}
