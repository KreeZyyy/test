using System.Collections.Generic;
using System.Linq;
using Assets.Scripts;
using Assets.Scripts.Util;
using Assets.Scripts.Objects.Electrical;
using System.Xml.Serialization;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Networking;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Structures;
using Assets.Scripts.Localization2;
using LibConstruct;
using UnityEngine;

namespace ModularSwitchboards
{
    public sealed class SwitchboardCabinetSaveData : StructureSaveData
    {
        [XmlElement] public PlacementBoardHostSaveData RailBoard;
    }

    // Retains the stock locker interactions; owns the LibConstruct mounting surface.
    public sealed class SwitchboardCabinet : Locker, IPlacementBoardHost
    {
        public Grid3[] PortBodyGrids;
        public override object GetLocalSmallGridBounds()
        {
            if(PortBodyGrids==null)return base.GetLocalSmallGridBounds();
            var grids=new HashSet<Grid3>(PortBodyGrids);
            foreach(var port in OpenEnds)
                if(port?.Transform!=null)grids.Add(transform.InverseTransformPoint(port.Transform.position).ToGrid(SmallGrid.SmallGridSize,SmallGrid.SmallGridOffset));
            return grids.ToArray();
        }
        public override bool IsConnected(Connection otherEnd)=>IsStructureCompleted && base.IsConnected(otherEnd);
        protected override void OnBuildStateUpdated(int newState,int previousState)
        {
            foreach(var port in OpenEnds)port.ConnectionType=newState==1?NetworkType.Power:NetworkType.None;
            base.OnBuildStateUpdated(newState,previousState);
            if(!IsCursor && GridController!=null && GameManager.GameState==GameState.Running)
            {
                if(newState!=1)
                    foreach(var network in ConnectedCableNetworks.ToArray())network.RemoveDevice(this);
                InitializeDataConnection();
                if(newState==1)InitializeDevice();
            }
        }
        public Transform RailOrigin;
        public BoxCollider RailSurface;
        private BoardRef<CabinetRailBoard> railBoard;
        public CabinetRailBoard RailBoard => railBoard?.Board;
        public bool CanFitRails => CurrentBuildStateIndex == 1 && IsOpen;

        public IEnumerable<PlacementBoard> GetPlacementBoards()
        {
            if (RailBoard != null) yield return RailBoard;
        }
        public IEnumerable<BoxCollider> CollidersForBoard(PlacementBoard board)
        {
            if (RailSurface != null) yield return RailSurface;
        }
        public void OnBoardStructureRegistered(PlacementBoard board, IPlacementBoardStructure structure) { }
        public void OnBoardStructureDeregistered(PlacementBoard board, IPlacementBoardStructure structure) { }

        public override void OnRegistered(Cell cell)
        {
            base.OnRegistered(cell);
            if (!IsCursor && RailOrigin != null)
                BoardHostHooks.OnRegisteredBoard(this, ref railBoard, RailOrigin);
        }
        public override void OnFinishedLoad()
        {
            base.OnFinishedLoad();
            if (!IsCursor && RailOrigin != null)
                BoardHostHooks.OnFinishedLoadBoard(this, ref railBoard, RailOrigin);
        }
        public override ThingSaveData SerializeSave()
        {
            ThingSaveData data = new SwitchboardCabinetSaveData();
            InitialiseSaveData(ref data);
            return data;
        }
        protected override void InitialiseSaveData(ref ThingSaveData data)
        {
            base.InitialiseSaveData(ref data);
            if (data is SwitchboardCabinetSaveData save && RailBoard != null)
                save.RailBoard = BoardHostHooks.SerializeBoard(this, RailBoard);
        }
        public override void DeserializeSave(ThingSaveData data)
        {
            base.DeserializeSave(data);
            // Old cabinet saves intentionally have no board and gain an empty one on load.
            BoardHostHooks.DeserializeBoard(this, (data as SwitchboardCabinetSaveData)?.RailBoard,
                out railBoard, RailOrigin);
        }
        public override void SerializeOnJoin(RocketBinaryWriter writer)
        {
            base.SerializeOnJoin(writer);
            BoardHostHooks.SerializeBoardOnJoin(writer, this, RailBoard);
        }
        public override void DeserializeOnJoin(RocketBinaryReader reader)
        {
            base.DeserializeOnJoin(reader);
            BoardHostHooks.DeserializeBoardOnJoin(reader, this, out railBoard, RailOrigin);
        }
        public override void OnDestroy()
        {
            BoardHostHooks.OnDestroyedBoard(this, railBoard);
            base.OnDestroy();
        }
        protected override CanConstructInfo CanDeconstruct()
        {
            return RailBoard != null && RailBoard.Structures.Count > 0
                ? CanConstructInfo.InvalidPlacement("Remove DIN rails first.") : base.CanDeconstruct();
        }
        public override DelayedActionInstance AttackWith(Attack attack, bool doAction = true)
        {
            if (RailBoard != null && RailBoard.Structures.Count > 0 &&
                (attack.SourceItem?.PrefabName == "ItemWrench" || attack.SourceItem?.PrefabName == "ItemDrill"))
                return null;
            return base.AttackWith(attack, doAction);
        }
        private float nextPortCheck;
        private void SyncExternalCableNetworks()
        {
            var live=new HashSet<Cable>();
            if(IsStructureCompleted)
                foreach(var port in OpenEnds)
                {
                    var cable=port.GetCable();if(cable==null || cable.CableNetwork==null)continue;
                    live.Add(cable);
                    if(cable.CableNetwork.GetDeviceRegistration(this)?.Contains(cable)!=true)
                        cable.CableNetwork.AddDevice(cable,this);
                }
            foreach(var network in ConnectedCableNetworks.ToArray())
            {
                var registration=network.GetDeviceRegistration(this);if(registration==null)continue;
                foreach(var cable in registration.ToArray())
                    if(!live.Contains(cable)||cable.CableNetwork!=network)network.RemoveDevice(cable,this);
            }
        }
        private void LateUpdate()
        {
            if (RailSurface != null) RailSurface.enabled = !IsCursor && CanFitRails;
            // Outside connectors can occupy separate cable cells. Keep native registration
            // current after cable placement/removal/network rebuilds without joining the nets.
            if(!IsCursor && GameManager.GameState==GameState.Running && Time.unscaledTime>=nextPortCheck)
            {
                nextPortCheck=Time.unscaledTime+.25f;SyncExternalCableNetworks();
            }
        }
    }

    public sealed class CabinetRailBoard : PlacementBoard
    {
        public override float GridSize => DinLayout.ModulePitch;
        public override IPlacementBoardStructure EquivalentStructure(Structure structure)
            => structure is DinRail && PrimaryHost is SwitchboardCabinet host && host.CanFitRails
                ? structure as IPlacementBoardStructure : null;
    }
}
