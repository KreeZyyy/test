using System;
using System.Collections.Generic;
using System.Linq;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Electrical;
using HarmonyLib;
using UnityEngine;
using UnityEngine.Rendering;
namespace ModularSwitchboards
{
    // Copy only native meter/rocker surfaces, preserving complete native vertex
    // streams and local transform chains. No fabricated screen, sockets or label.
    internal static class SmallNativeBatteryFace
    {
        private sealed class Surface
        {
            internal MeshRenderer Renderer;internal Vector3[] Points;internal int[][] Groups;
        }
        private sealed class Region
        {
            internal readonly List<Surface> Geometry=new List<Surface>();
            internal Transform Root;internal readonly Dictionary<MeshRenderer,MeshRenderer> Copies=new Dictionary<MeshRenderer,MeshRenderer>();internal Quaternion Rotation;internal Matrix4x4 Projection;
            internal Bounds Bounds;internal bool HasBounds;internal readonly Dictionary<Transform,Transform> Map=new Dictionary<Transform,Transform>();
        }
        internal static void Install(DinStationBattery owner,Battery source,Transform front,BoxCollider hit)
        {
            var field=AccessTools.Field(typeof(Battery),"displayRenderers");var originals=field.GetValue(source) as MeshRenderer[];
            if(originals==null||originals.Length==0||originals.Any(r=>r==null))throw new InvalidOperationException("Native small battery meter segments missing.");
            var surfaces=new List<Surface>();
            foreach(var renderer in source.GetComponentsInChildren<MeshRenderer>(true))
            {
                var mesh=renderer.GetComponent<MeshFilter>()?.sharedMesh;if(mesh==null)continue;
                CabinetGeometry.ReadNativeMesh(mesh,out var points,out _,out var groups);surfaces.Add(new Surface{Renderer=renderer,Points=points,Groups=groups});
            }
            var body=RootBounds(source,surfaces);var segmentSurfaces=originals.Select(r=>surfaces.First(s=>s.Renderer==r)).ToArray();
            var centers=segmentSurfaces.Select(s=>RootBounds(source,new[]{s}).center).ToArray();
            // Use the five-segment ROW to establish the original front plane.
            // A single segment's thin mesh axis can face sideways, allowing
            // internal construction geometry into the surrounding crop.
            var row=centers.Last()-centers.First();
            var normal=SmallBatteryFaceLayout.MeterNormal(row,RootBounds(source,segmentSurfaces).center-body.center);
            var panel=Create("OriginalSmallBatteryMeter",source,front,normal,Vector3.up);
            var nativeCore=ProjectedBounds(source,segmentSurfaces,panel.Projection);var crop=SmallBatteryFaceLayout.GaugeCrop(nativeCore);
            var copies=new MeshRenderer[originals.Length];
            for(int i=0;i<originals.Length;i++)copies[i]=CopySurface(source,segmentSurfaces[i],segmentSurfaces[i].Groups,panel,"NativeSmallChargeSegment"+i);
            int frameFaces=StaticFrame(source,FinalMeterSurfaces(source,surfaces),new HashSet<MeshRenderer>(originals),panel,crop);
            FitMeter(panel);field.SetValue(owner,copies);owner.NativeIndicatorCount=copies.Length;owner.Screen=panel.Root.gameObject;
            var native=source.SwitchOnOff??source.GetComponentsInChildren<Objects.SwitchOnOff>(true).FirstOrDefault();
            if(native!=null)Switch(owner,source,surfaces,front,hit,native,body.center);
            else LegacySwitch(owner,source,surfaces,front,hit,body.center,new HashSet<MeshRenderer>(originals));
            Debug.Log("[Modular Switchboards] Original small battery meter copied: segments="+copies.Length+", native surround triangles="+frameFaces+", no custom panel/label.");
        }
        private static IEnumerable<Surface> FinalMeterSurfaces(Battery source,IEnumerable<Surface> surfaces)
        {
            // Only use the completed native body. Earlier construction models
            // contain the circuit boards/coils seen in the failed146-149crop.
            var final=source.BuildStates.Last().Visualizer;
            var earlier=source.BuildStates.Take(source.BuildStates.Count-1)
                .Select(state=>state.Visualizer).Where(v=>v!=null&&v!=final).ToArray();
            foreach(var surface in surfaces)
            {
                var renderer=surface.Renderer;
                if(earlier.Any(v=>renderer==v||renderer.transform.IsChildOf(v.transform)))continue;
                if(final!=null&&(renderer==final||renderer.transform.IsChildOf(final.transform)))yield return surface;
            }
        }
        private static void FitMeter(Region panel)
        {
            var b=ProjectedBoundsForCopies(panel,panel.Geometry);var target=SmallBatteryFaceLayout.GaugeTarget;
            float scale=StationBatteryPanelLayout.Fit(b.size.x,b.size.y,b.size.z,target.size.x,target.size.y,target.size.z);
            panel.Root.localRotation=panel.Rotation;panel.Root.localScale=Vector3.one*scale;
            panel.Root.localPosition=new Vector3(target.center.x-b.center.x*scale,target.center.y-b.center.y*scale,
                BatterySwitchMount.Seat(StationBatteryPanelLayout.FaceZ,b.min.z,scale));
        }
        private static Region Create(string name,Battery source,Transform front,Vector3 normal,Vector3 up)
        {
            var go=new GameObject(name){layer=front.gameObject.layer};go.transform.SetParent(front,false);var rotation=Quaternion.Inverse(Quaternion.LookRotation(normal,Up(normal,up)));
            var r=new Region{Root=go.transform,Rotation=rotation,Projection=Matrix4x4.Rotate(rotation)};var native=new GameObject("NativeSourceFrame"){layer=front.gameObject.layer};native.transform.SetParent(go.transform,false);r.Map.Add(source.transform,native.transform);return r;
        }
        private static Transform Frame(Battery source,Transform original,Region region)
        {
            if(region.Map.TryGetValue(original,out var existing))return existing;
            var parent=Frame(source,original.parent,region);var go=new GameObject(original.name){layer=region.Root.gameObject.layer};go.transform.SetParent(parent,false);go.transform.localPosition=original.localPosition;go.transform.localRotation=original.localRotation;go.transform.localScale=original.localScale;region.Map.Add(original,go.transform);return go.transform;
        }
        private static MeshRenderer CopySurface(Battery source,Surface surface,int[][] selected,Region region,string name)
        {
            var old=surface.Renderer.GetComponent<MeshFilter>().sharedMesh;var indices=selected.SelectMany(g=>g).Distinct().ToArray();if(indices.Length==0)return null;
            var frame=Frame(source,surface.Renderer.transform,region);var go=frame.gameObject;
            bool complete=selected.Select(g=>g.Length).SequenceEqual(surface.Groups.Select(g=>g.Length));
            var mesh=complete?old:Subset(old,surface.Points,selected);go.AddComponent<MeshFilter>().sharedMesh=mesh;var renderer=go.AddComponent<MeshRenderer>();NativePortSurface.Capture(surface.Renderer,renderer);region.Copies.Add(surface.Renderer,renderer);region.Geometry.Add(new Surface{Renderer=renderer,Points=surface.Points,Groups=selected});
            var matrix=source.transform.worldToLocalMatrix*surface.Renderer.transform.localToWorldMatrix;
            foreach(int i in indices){var p=matrix.MultiplyPoint3x4(surface.Points[i]);if(!region.HasBounds){region.Bounds=new Bounds(p,Vector3.zero);region.HasBounds=true;}else region.Bounds.Encapsulate(p);}
            return renderer;
        }
        private static Mesh Subset(Mesh original,Vector3[] points,int[][] groups)
        {
            // Preserve all original shader inputs: UV0 alone is not sufficient
            // for native masked/painted display materials (UV1/color/tangents).
            var mesh=new Mesh{name="OriginalSmallBattery.NativeSurfaceRegion",indexFormat=original.indexFormat};mesh.SetVertexBufferParams(original.vertexCount,original.GetVertexAttributes());
            for(int stream=0;stream<original.vertexBufferCount;stream++)
            {
                int stride=original.GetVertexBufferStride(stream);if(stride!=mesh.GetVertexBufferStride(stream)||stride%4!=0)throw new InvalidOperationException("Native battery vertex layout cannot be copied losslessly.");
                using(var buffer=original.GetVertexBuffer(stream))
                {var raw=new uint[original.vertexCount*stride/4];buffer.GetData(raw);mesh.SetVertexBufferData(raw,0,0,raw.Length,stream,MeshUpdateFlags.DontRecalculateBounds|MeshUpdateFlags.DontValidateIndices);}
            }
            mesh.subMeshCount=groups.Length;for(int i=0;i<groups.Length;i++)mesh.SetTriangles(groups[i],i,false);
            var used=groups.SelectMany(g=>g).Distinct().ToArray();var b=new Bounds(points[used[0]],Vector3.zero);foreach(int i in used)b.Encapsulate(points[i]);mesh.bounds=b;return mesh;
        }
        private static int StaticFrame(Battery source,IEnumerable<Surface> surfaces,HashSet<MeshRenderer> moving,Region region,Bounds crop)
        {
            int count=0;var obsolete=new HashSet<Renderer>(source.BuildStates.Take(Math.Max(0,source.BuildStates.Count-1)).Select(s=>s.Visualizer));obsolete.Remove(source.BuildStates.Last().Visualizer);
            foreach(var surface in surfaces)
            {
                if(moving.Contains(surface.Renderer)||obsolete.Contains(surface.Renderer))continue;
                var matrix=region.Projection*source.transform.worldToLocalMatrix*surface.Renderer.transform.localToWorldMatrix;
                var projected=surface.Points.Select(matrix.MultiplyPoint3x4).ToArray();var groups=SmallBatteryFaceLayout.Select(projected,surface.Groups,crop);int triangles=groups.Sum(g=>g.Length)/3;
                if(triangles==0)continue;CopySurface(source,surface,groups,region,"NativeSmallFrameSurface");count+=triangles;
            }
            return count;
        }
        private static Bounds RootBounds(Battery source,IEnumerable<Surface> surfaces)
        {
            bool first=true;var b=new Bounds();foreach(var surface in surfaces)
            {var matrix=source.transform.worldToLocalMatrix*surface.Renderer.transform.localToWorldMatrix;foreach(int i in surface.Groups.SelectMany(g=>g).Distinct()){var p=matrix.MultiplyPoint3x4(surface.Points[i]);if(first){b=new Bounds(p,Vector3.zero);first=false;}else b.Encapsulate(p);}}return b;
        }
        private static Bounds ProjectedBounds(Battery source,IEnumerable<Surface> surfaces,Matrix4x4 projection)
        {
            var b=new Bounds();bool first=true;foreach(var surface in surfaces)
            {
                var matrix=projection*source.transform.worldToLocalMatrix*surface.Renderer.transform.localToWorldMatrix;
                foreach(int i in surface.Groups.SelectMany(g=>g).Distinct()){var p=matrix.MultiplyPoint3x4(surface.Points[i]);if(first){b=new Bounds(p,Vector3.zero);first=false;}else b.Encapsulate(p);}
            }
            return b;
        }
        private static Vector3 Normal(Battery source,MeshRenderer renderer,Vector3 body)
        {
            var mesh=renderer.GetComponent<MeshFilter>().sharedMesh;var size=mesh.bounds.size;var axis=size.x<=size.y&&size.x<=size.z?Vector3.right:size.y<=size.z?Vector3.up:Vector3.forward;
            var matrix=source.transform.worldToLocalMatrix*renderer.transform.localToWorldMatrix;var normal=matrix.inverse.transpose.MultiplyVector(axis).normalized;
            if(Vector3.Dot(normal,matrix.MultiplyPoint3x4(mesh.bounds.center)-body)<0)normal=-normal;return normal;
        }
        private static Vector3 Up(Vector3 normal,Vector3 preferred)
        {var up=preferred-normal*Vector3.Dot(preferred,normal);if(up.sqrMagnitude<.0001f){preferred=Mathf.Abs(normal.y)<.9f?Vector3.up:Vector3.forward;up=preferred-normal*Vector3.Dot(preferred,normal);}return up.normalized;}
        private static void Fit(Region region,Bounds target)
        {
            var b=CabinetWallMount.TransformedBounds(region.Bounds,region.Projection);float scale=StationBatteryPanelLayout.Fit(b.size.x,b.size.y,b.size.z,target.size.x,target.size.y,target.size.z);
            region.Root.localRotation=region.Rotation;region.Root.localScale=Vector3.one*scale;region.Root.localPosition=target.center-new Vector3(b.center.x,b.center.y,b.max.z)*scale;
        }
        private static Vector3 SwitchMountNormal(Battery source,MeshRenderer rocker,Vector3 body)
        {
            // A tilted rocker is not the mounting plane. Its thinnest mesh
            // axis can be the hinge edge, presenting the switch side-on.
            // The stock battery switch is on a vertical cabinet side: use
            // that cabinet plane, not the animated paddle's mesh bounds.
            var p=source.transform.InverseTransformPoint(rocker.bounds.center)-body;
            return (BatterySwitchMount.Axis(p.x,p.z)==0?Vector3.right:Vector3.forward)*BatterySwitchMount.Sign(p.x,p.z);
        }
        private static void FitSwitch(Region panel,Bounds mounting)
        {
            // Cabinet front view reverses local X: +90 about local Z is a
            // clockwise quarter-turn plus the requested180-degree correction. Rotate the whole
            // mounting parent; the native OFF/ON paddle poses stay untouched.
            panel.Rotation=Quaternion.AngleAxis(270f,Vector3.forward)*panel.Rotation;
            panel.Projection=Matrix4x4.Rotate(panel.Rotation);
            var surfaces=panel.Geometry;
            // Copies are already under a source-shaped transform chain.
            // Measure in the fitted parent's coordinates before applying TRS.
            var b=ProjectedBoundsForCopies(panel,surfaces);
            var target=SmallBatteryFaceLayout.SwitchTarget;
            float scale=StationBatteryPanelLayout.Fit(b.size.x,b.size.y,b.size.z,target.size.x,target.size.y,target.size.z);
            panel.Root.localRotation=panel.Rotation;panel.Root.localScale=Vector3.one*scale;
            // Seat the BACK of the original bezel on the DIN surface. The old
            // max.z alignment buried the rocker and frame inside the casing.
            panel.Root.localPosition=new Vector3(target.center.x-b.center.x*scale,
                target.center.y-b.center.y*scale,BatterySwitchMount.Seat(StationBatteryPanelLayout.FaceZ,mounting.min.z,scale));
        }
        private static Bounds MountingBounds(Region panel,HashSet<MeshRenderer> moving)
        {
            var parts=panel.Copies.Where(kv=>!moving.Contains(kv.Key)).Select(kv=>kv.Value).ToArray();
            if(parts.Length==0)parts=panel.Copies.Values.ToArray();
            return ProjectedBoundsForCopies(panel,panel.Geometry.Where(s=>parts.Contains(s.Renderer)));
        }
        private static Bounds ProjectedBoundsForCopies(Region panel,IEnumerable<Surface> surfaces)
        {
            var b=new Bounds();bool first=true;
            foreach(var surface in surfaces)
            {
                var matrix=panel.Projection*panel.Root.worldToLocalMatrix*surface.Renderer.transform.localToWorldMatrix;
                foreach(int i in surface.Groups.SelectMany(g=>g).Distinct())
                {var p=matrix.MultiplyPoint3x4(surface.Points[i]);if(first){b=new Bounds(p,Vector3.zero);first=false;}else b.Encapsulate(p);}
            }
            return b;
        }
        private static void Switch(DinStationBattery owner,Battery source,List<Surface> surfaces,Transform front,BoxCollider hit,Objects.SwitchOnOff native,Vector3 body)
        {
            var type=typeof(Objects.SwitchOnOff);var pivot=AccessTools.Field(type,"switchTransform").GetValue(native) as Transform;var rocker=AccessTools.Field(type,"switchRenderer").GetValue(native) as MeshRenderer;
            if(pivot==null||pivot==source.transform||rocker==null){LegacySwitch(owner,source,surfaces,front,hit,body,new HashSet<MeshRenderer>());return;}
            var normal=SwitchMountNormal(source,rocker,body);var panel=Create("OriginalSmallBatteryRedSwitch",source,front,normal,Vector3.up);
            var moving=surfaces.Where(s=>s.Renderer.transform.IsChildOf(pivot)||s.Renderer==rocker).ToArray();foreach(var surface in moving)CopySurface(source,surface,surface.Groups,panel,"NativeSmallSwitchPart");
            var crop=SmallBatteryFaceLayout.SwitchCrop(ProjectedBounds(source,moving,panel.Projection));StaticFrame(source,surfaces,new HashSet<MeshRenderer>(moving.Select(s=>s.Renderer)),panel,crop);
            var mounting=MountingBounds(panel,new HashSet<MeshRenderer>(moving.Select(m=>m.Renderer)));
            FitSwitch(panel,mounting);
            var driver=owner.gameObject.AddComponent<DinBatteryNativeSwitch>();foreach(string name in new[]{"offPosition","onPosition","off","on","onPowered","error"})AccessTools.Field(type,name).SetValue(driver,AccessTools.Field(type,name).GetValue(native));
            AccessTools.Field(type,"switchTransform").SetValue(driver,Frame(source,pivot,panel));
            AccessTools.Field(type,"switchRenderer").SetValue(driver,panel.Copies[rocker]);AccessTools.Field(type,"interactionTrigger").SetValue(driver,hit);driver.SetParentThing(owner);AccessTools.Field(typeof(Thing),"switchOnOff").SetValue(owner,driver);
        }
        private static void LegacySwitch(DinStationBattery owner,Battery source,List<Surface> surfaces,Transform front,BoxCollider hit,Vector3 body,HashSet<MeshRenderer> indicators)
        {
            var control=source.Interactables.Concat(source.BuildStates.SelectMany(s=>s.Interactables)).FirstOrDefault(c=>c.Action==InteractableType.OnOff&&c.Collider!=null);
            var point=control?.Collider.bounds.center??source.transform.position;var candidate=surfaces.Where(s=>!indicators.Contains(s.Renderer)&&(s.Renderer.name.IndexOf("switch",StringComparison.OrdinalIgnoreCase)>=0||s.Renderer.name.IndexOf("button",StringComparison.OrdinalIgnoreCase)>=0)).OrderBy(s=>(s.Renderer.bounds.center-point).sqrMagnitude).FirstOrDefault();
            if(candidate==null)throw new InvalidOperationException("Native small battery red switch mesh missing.");
            var normal=SwitchMountNormal(source,candidate.Renderer,body);var panel=Create("OriginalSmallBatteryLegacySwitch",source,front,normal,Vector3.up);CopySurface(source,candidate,candidate.Groups,panel,"NativeSmallRedSwitch");
            var crop=SmallBatteryFaceLayout.SwitchCrop(ProjectedBounds(source,new[]{candidate},panel.Projection));StaticFrame(source,surfaces,new HashSet<MeshRenderer>{candidate.Renderer},panel,crop);FitSwitch(panel,MountingBounds(panel,new HashSet<MeshRenderer>{candidate.Renderer}));
            var originalAnimator=control?.Animator??source.BaseAnimator;
            if(originalAnimator?.runtimeAnimatorController!=null)
            {
                var frame=Frame(source,originalAnimator.transform,panel);var animator=frame.gameObject.AddComponent<Animator>();animator.runtimeAnimatorController=originalAnimator.runtimeAnimatorController;animator.avatar=originalAnimator.avatar;animator.applyRootMotion=false;
                var view=frame.gameObject.AddComponent<SmallBatteryNativeAnimatorView>();view.Owner=owner;view.Animator=animator;
            }
            else Debug.LogWarning("[Modular Switchboards] Small battery native switch has no serialized animation controller; original mesh/materials retained.");
        }
    }
    public sealed class SmallBatteryNativeAnimatorView:MonoBehaviour
    {
        public DinStationBattery Owner;public Animator Animator;
        private bool ready,on,powered;private int mode,error;
        private void LateUpdate()
        {
            if(Owner==null||Animator==null)return;
            bool nextOn=Owner.OnOff,nextPower=Owner.Powered;int nextMode=Owner.Mode,nextError=Owner.Error;
            if(ready&&on==nextOn&&powered==nextPower&&mode==nextMode&&error==nextError)return;
            ready=true;on=nextOn;powered=nextPower;mode=nextMode;error=nextError;
            foreach(var parameter in Animator.parameters)
            {
                if(parameter.type!=AnimatorControllerParameterType.Int)continue;
                if(parameter.name=="OnOff")Animator.SetInteger(parameter.nameHash,on?1:0);
                else if(parameter.name=="Powered")Animator.SetInteger(parameter.nameHash,powered?1:0);
                else if(parameter.name=="Mode")Animator.SetInteger(parameter.nameHash,mode);
                else if(parameter.name=="Error")Animator.SetInteger(parameter.nameHash,error);
            }
        }
    }
}
