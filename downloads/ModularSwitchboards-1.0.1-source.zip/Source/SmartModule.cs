using System;
using System.Collections;
using System.Collections.Generic;
using Assets.Scripts.UI;
using HarmonyLib;
using System.Linq;
using System.Xml.Serialization;
using Assets.Scripts;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Networking;
using Assets.Scripts.Networks;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Electrical;
using Assets.Scripts.Objects.Pipes;
using Assets.Scripts.Objects.Items;
using Assets.Scripts.Objects.Motherboards;
using Cysharp.Threading.Tasks;
using LibConstruct;
using UnityEngine;
namespace ModularSwitchboards
{
    public sealed class SmartModuleSaveData:LogicBaseSaveData
    {
        [XmlElement]public PlacementBoardStructureSaveData RailBoard;
        [XmlElement]public int CodeError;
        [XmlElement]public ulong LastEditor;
    }
    // One IC housing device with an integrated native LED surface. Keep the
    // LogicDisplay base for its renderer, Mode/Setting/Color and existing saves;
    // the holder contract below owns chip execution, errors and stack access.
    public sealed class SmartModule:LogicDisplay,IPlacementBoardStructure,ICircuitHolder,IMemoryReadable,IMemoryWritable
    {
        public PlacementBoard Board{get;set;}
        public PlacementBoard.BoardCell[] BoardCells{get;set;}
        public int ModuleWidth=>DinSmartLayout.Slots;
        public SwitchboardCabinet Cabinet=>(Board?.PrimaryHost as DinRail)?.Board?.PrimaryHost as SwitchboardCabinet;
        public ProgrammableChip Chip=>Slots.Count==1?Slots[0].Get() as ProgrammableChip:null;
        public ulong LastEditedBy{get;set;}
        private CabinetWiring lastWiring;
        internal CabinetWiring AttachedWiring
        {
            get{var current=Cabinet?.Wiring;if(current!=null)lastWiring=current;return current!=null?current:lastWiring!=null?lastWiring:null;}
        }
        internal Cable BoundCable;
        internal CableNetwork BoundNetwork;
        private static readonly System.Reflection.FieldInfo NativeLines=AccessTools.Field(typeof(ProgrammableChip),"_LinesOfCode");
        private SmartRunState runStatus;
        private int statusErrorLine=-1;
        private string statusText;
        private char[] statusGlyphs;
        private static readonly System.Reflection.FieldInfo CompileErrorLine=AccessTools.Field(typeof(ProgrammableChip),"_compileErrorLineNumber");
        internal SmartRunState RunStatus=>!Powered||!OnOff?SmartRunState.Off:runStatus;
        private void RefreshRunStatus()
        {
            if(!NetworkManager.IsServer)return;
            var chip=Chip;int count=chip==null?0:(NativeLines?.GetValue(chip) as ICollection)?.Count??0;
            bool lua=SmartLuaRuntime.IsLua(chip);
            bool fault=chip!=null&&(chip.CompilationError||codeError!=0||!string.IsNullOrEmpty(lua?SmartLuaRuntime.Error(chip):chip.GetErrorCode()));
            var status=SmartRunStatus.Evaluate(Powered,OnOff,chip!=null,fault,chip!=null&&!string.IsNullOrWhiteSpace(chip.GetSourceCode().ToString()),chip!=null&&(lua?SmartLuaRuntime.Running(chip):chip.LineNumber>=0&&chip.LineNumber<count),WorldManager.IsGamePaused);
            int line=-1;
            if(fault&&chip!=null)
            {
                if(lua)line=SmartStatusDisplay.LuaLine(SmartLuaRuntime.Error(chip));
                else if(chip.CompilationError&&CompileErrorLine?.GetValue(chip) is ushort compileLine)line=compileLine;
                else if(!string.IsNullOrWhiteSpace(chip.GetErrorCode())&&int.TryParse(chip.ErrorLineNumberString,out var nativeLine))line=nativeLine;
            }
            if(status!=runStatus||line!=statusErrorLine){runStatus=status;statusErrorLine=line;NetworkUpdateFlags|=512;}
        }
        private void RefreshStatusDisplay()
        {
            // This is a housing status surface, not a second user-programmable LED.
            // Setting remains ordinary housing storage; it never supplies the glyphs.
            var state=RunStatus;
            var swatch=GameManager.GetColorSwatch((int)(state==SmartRunState.Fault?ColorType.Orange:ColorType.Green));
            if(swatch?.Emissive!=null)DigitOn=swatch.Emissive;
            var text=SmartStatusDisplay.Text(state,statusErrorLine);
            if(text!=statusText){statusText=text;statusGlyphs=text.ToCharArray();}
            SetDisplay(statusGlyphs);
        }
        public override void OnSettingChanged()
        {
            base.OnSettingChanged();
            if(DigitTransform!=null&&GameManager.GameState==GameState.Running)RefreshStatusDisplay();
        }
        public override void OnInteractableUpdated(Interactable interactable)
        {
            base.OnInteractableUpdated(interactable);
            if(DigitTransform!=null&&GameManager.GameState==GameState.Running)RefreshStatusDisplay();
        }
        public override PassiveTooltip GetPassiveTooltip(Collider collider)
        {
            var tip=base.GetPassiveTooltip(collider);var chip=Chip;bool lua=SmartLuaRuntime.IsLua(chip);string detail=chip==null?"":lua?SmartLuaRuntime.Error(chip):chip.GetErrorCode();
            string state=RunStatus==SmartRunState.Running?"IC10 running":RunStatus==SmartRunState.Fault?"IC10 error":!Powered?"No power":!OnOff?"OFF":chip==null?"No IC10 installed":"IC10 idle";
            if(lua)state=state.Replace("IC10","Lua");
            tip.Extended=state+(string.IsNullOrWhiteSpace(detail)?"":"\n"+detail.Trim());return tip;
        }
        public override void BuildUpdate(RocketBinaryWriter writer,ushort type){base.BuildUpdate(writer,type);if(Thing.IsNetworkUpdateRequired(512u,type)){writer.WriteByte((byte)runStatus);writer.WriteInt32(statusErrorLine);}}
        public override void ProcessUpdate(RocketBinaryReader reader,ushort type){base.ProcessUpdate(reader,type);if(Thing.IsNetworkUpdateRequired(512u,type)){runStatus=(SmartRunState)reader.ReadByte();statusErrorLine=reader.ReadInt32();}}
        private float nextLink;
        private int codeError;
        private float nextExecute;
        private float nextStatus;
        public override void Awake(){PrefabAudioOwner.PrepareInstance(this);base.Awake();BoardStructureHooks.Awake(this);}
        public override Grid3 GetLocalGrid()=>Board==null?default(Grid3):Board.WorldToGrid(transform.position);
        public override CanConstructInfo CanConstruct()
        {
            if(IsCursor){MountPlacement.AfterRaycast();MountBoardResolver.Resolve(CursorManager.Instance);}
            if(!(Board is DinModuleBoard board))return CanConstructInfo.InvalidPlacement("Aim at an available four-position span on a DIN rail.");
            var p=board.WorldToGrid(transform.position);
            if(IsCursor)
            {
                if(MountPlacement.TryLockedGrid(this,board,out var locked))p=locked;
                else p=new Grid3(DoorModuleLayout.SnapSlot(p.x,DinLayout.FirstModuleSlot*10,(DinLayout.FirstModuleSlot+((DinRail)board.PrimaryHost).ModuleCapacity-4)*10),0,0);
                PlacementBoard.CursorGrid=p;PlacementBoard.CursorRotation=0;transform.SetPositionAndRotation(board.GridToWorld(p),board.IndexToRotation(0));
            }
            return board.CanPlace(p,board.RotationToIndex(transform.rotation),4)?CanConstructInfo.ValidPlacement:CanConstructInfo.InvalidPlacement("Choose four free DIN positions.");
        }
        public override DelayedActionInstance AttackWith(Attack attack,bool doAction=true)
        {
            // Status glyph colours are controlled separately from housing paint.
            // Keep the native spray interaction and its normal consumption guards.
            if(IsPaintable&&attack.SourceItem is ISprayer sprayer)return ISprayer.DoSpray(this,sprayer,doAction);
            return base.AttackWith(attack,doAction);
        }
        protected override CanConstructInfo CanDeconstruct()
            =>Cabinet==null||!Cabinet.CanAccessModules?CanConstructInfo.InvalidPlacement("Open the cabinet and remove the cover first."):
              Chip!=null?CanConstructInfo.InvalidPlacement("Remove the IC10 first."):
              !ModuleDismantle.CanRefund(this)?CanConstructInfo.InvalidPlacement("Cable coil prefab unavailable."):CanConstructInfo.ValidPlacement;
        public override void OnDeregistered(){ModuleDismantle.Unlink(this);SmartModuleNetwork.Unbind(this);base.OnDeregistered();if(Board!=null)BoardStructureHooks.OnDeregistered(this);}
        public override void OnDestroy(){ModuleDismantle.Unlink(this);if(GameManager.RunSimulation)SmartLuaRuntime.Detach(Chip);SmartModuleNetwork.Unbind(this);base.OnDestroy();}
        public override void OnRegistered(Cell cell){base.OnRegistered(cell);}
        private void LateUpdate()
        {
            if(IsCursor)return;
            RefreshStatusDisplay();
            if(NetworkManager.IsServer&&SmartLuaRuntime.IsLua(Chip))SmartLuaRuntime.SetActivity(Chip,IsCursor||Cabinet==null||!Powered||!OnOff||WorldManager.IsGamePaused||GameManager.GameState!=GameState.Running);
            if(Cabinet!=null)lastWiring=Cabinet.Wiring;
            if(Cabinet==null){if(BoundNetwork!=null)SmartModuleNetwork.Unbind(this);return;}
            if(Time.unscaledTime>=nextLink){nextLink=Time.unscaledTime+.15f;SmartModuleNetwork.Refresh(this);}
            if(GameManager.RunSimulation&&Time.unscaledTime>=nextExecute){nextExecute=Time.unscaledTime+.5f;Execute();}
            if(Time.unscaledTime>=nextStatus){nextStatus=Time.unscaledTime+.1f;RefreshRunStatus();}
            foreach(var hit in BuildStates[0].Colliders)if(hit!=null)hit.enabled=Cabinet.IsOpen;
            if(Slots.Count==1&&Slots[0].Collider!=null)Slots[0].Collider.enabled=Cabinet.CanAccessModules;
        }
        public override void OnAddCableNetwork(CableNetwork network){}
        public override void OnRemoveCableNetwork(CableNetwork network){if(network==BoundNetwork)AssessPower(null,false);}
        public override bool PreventInteraction(out DelayedActionInstance failure,Interactable interactable,Interaction interaction)
        {
            if(interactable.Action==InteractableType.Slot1&&(Cabinet==null||!Cabinet.CanAccessModules))
            {failure=new DelayedActionInstance{Duration=0f}.Fail("Open the cabinet and remove the cover first.");return true;}
            return base.PreventInteraction(out failure,interactable,interaction);
        }
        public override DelayedActionInstance InteractWith(Interactable interactable,Interaction interaction,bool doAction=true)
        {
            if(interactable.Action==InteractableType.Slot1&&(Cabinet==null||!Cabinet.CanAccessModules))
                return new DelayedActionInstance{Duration=0f}.Fail("Open the cabinet and remove the cover first.");
            var result=base.InteractWith(interactable,interaction,doAction);
            if(interactable.Action==InteractableType.Slot1&&result!=null&&Chip!=null)
            {
                var error=Chip.GetErrorCode();
                result.ExtendedMessage=SmartChipTooltip.Once(result.ExtendedMessage,error);
                var originalState=result.GetStateMessage();
                var state=SmartChipTooltip.Once(originalState,error,result.ExtendedMessage);
                if(state!=originalState)
                {
                    result.ClearStateMessage();
                    if(!string.IsNullOrEmpty(state))result.AppendStateMessage(state.TrimEnd('\r','\n'));
                }
            }
            return result;
        }
        public override void OnChildEnterInventory(DynamicThing child){base.OnChildEnterInventory(child);if(GameManager.RunSimulation&&child is ProgrammableChip){Chip.Reset();ClearError();}}
        public override void OnChildExitInventory(DynamicThing child){if(GameManager.RunSimulation&&child is ProgrammableChip lua)SmartLuaRuntime.Detach(lua);base.OnChildExitInventory(child);if(GameManager.RunSimulation&&child is ProgrammableChip chip){chip.Reset();ClearError();}}
        public void ClearError()=>RaiseError(0);
        public void RaiseError(int state){codeError=state;if(GameManager.RunSimulation&&InteractError!=null)OnServer.Interact(InteractError,state==0?0:1);}
        public bool IsValidIndex(int index)=>index==int.MaxValue;
        public ILogicable GetLogicableFromIndex(int index,int networkIndex=int.MinValue)=>index==int.MaxValue?(networkIndex==int.MinValue?this:GetNetwork(networkIndex)):null;
        public ILogicable GetLogicableFromId(int id,int networkIndex=int.MinValue)
        {
            if(id==ReferenceId)return networkIndex==int.MinValue?this:GetNetwork(networkIndex);
            var device=Referencable.Find<Device>(id);
            return device!=null&&DataCableNetwork!=null&&DataCableNetwork.DataDeviceList.Contains(device)?networkIndex==int.MinValue?(ILogicable)device:device.GetNetwork(networkIndex):null;
        }
        public List<ILogicable> GetBatchOutput()=>DataCableNetwork==null?new List<ILogicable>():DataCableNetwork.DataDeviceList.OfType<ILogicable>().ToList();
        public List<LogicBinding> GetLogicBindings()=>new List<LogicBinding>{new LogicBinding("HOUSING")};
        public void SetDeviceLabel(int index,string label){}
        public void HasPut(){}
        public UniTask HaltAndCatchFire(){if(GameManager.RunSimulation)OnServer.Interact(InteractOnOff,0);return UniTask.CompletedTask;}
        public string GetSourceCode()=>Chip==null?"":Chip.GetSourceCode();
        public void SetSourceCode(string source){if(Chip!=null){Chip.SetSourceCode(source,this);Chip.SendUpdate();}}
        public void Execute()
        {
            if(!GameManager.RunSimulation||!NetworkManager.IsServer||IsCursor||!OnOff||!Powered||GameManager.GameState!=GameState.Running||WorldManager.IsGamePaused||Chip==null)return;
            if(SmartLuaRuntime.IsLua(Chip)){SmartLuaRuntime.Tick(Chip);return;}
            if(!Chip.CompilationError)Chip.Execute(128);
        }
        public override bool CanLogicRead(LogicType type)=>type!=LogicType.Mode&&type!=LogicType.Color&&(type==LogicType.LineNumber||base.CanLogicRead(type));
        public override bool CanLogicWrite(LogicType type)=>type!=LogicType.Mode&&type!=LogicType.Color&&(type==LogicType.LineNumber||base.CanLogicWrite(type));
        public override double GetLogicValue(LogicType type)=>type==LogicType.LineNumber?(Chip==null?-1:Chip.LineNumber):base.GetLogicValue(type);
        public override void SetLogicValue(LogicType type,double value){if(type==LogicType.Mode||type==LogicType.Color)return;if(type==LogicType.LineNumber){if(Chip!=null)Chip.LineNumber=(uint)value;}else base.SetLogicValue(type,value);}
        // Native housing stack contract: expose the installed chip's memory,
        // never a second independent memory buffer on the display.
        public double ReadMemory(int address)
        {
            var chip=Chip;if(chip==null)throw new NullReferenceException("No programmable chip installed.");
            return chip.ReadMemory(address);
        }
        public void WriteMemory(int address,double value)
        {
            var chip=Chip;if(chip==null)throw new NullReferenceException("No programmable chip installed.");
            chip.WriteMemory(address,value);
        }
        public void ClearMemory()
        {
            var chip=Chip;if(chip==null)throw new NullReferenceException("No programmable chip installed.");
            chip.ClearMemory();
        }
        public int GetStackSize()=>Chip?.GetStackSize()??0;
        public override bool CanLogicRead(LogicSlotType type,int slotId)
            =>slotId>=0&&slotId<Slots.Count&&(type==LogicSlotType.LineNumber||base.CanLogicRead(type,slotId));
        public override double GetLogicValue(LogicSlotType type,int slotId)
        {
            if(slotId<0||slotId>=Slots.Count)return double.NaN;
            if(type==LogicSlotType.LineNumber&&Slots[slotId].Get() is ILogicable chip)return chip.GetLogicValue(LogicType.LineNumber);
            return base.GetLogicValue(type,slotId);
        }
        public override ThingSaveData SerializeSave(){ThingSaveData data=new SmartModuleSaveData();InitialiseSaveData(ref data);return data;}
        protected override void InitialiseSaveData(ref ThingSaveData data){base.InitialiseSaveData(ref data);if(data is SmartModuleSaveData save){if(Board!=null)save.RailBoard=BoardStructureHooks.SerializeSave(this);save.CodeError=codeError;save.LastEditor=LastEditedBy;}}
        public override void DeserializeSave(ThingSaveData data){base.DeserializeSave(data);if(data is SmartModuleSaveData save){codeError=save.CodeError;LastEditedBy=save.LastEditor;if(save.RailBoard!=null)BoardStructureHooks.DeserializeSave(this,save.RailBoard);}else if(data is DinBreakerSaveData old){OnOff=true;if(old.RailBoard!=null)BoardStructureHooks.DeserializeSave(this,old.RailBoard);}}
        public override void SerializeOnJoin(RocketBinaryWriter writer){base.SerializeOnJoin(writer);BoardStructureHooks.SerializeOnJoin(writer,this);writer.WriteInt32(codeError);writer.WriteByte((byte)RunStatus);writer.WriteInt32(statusErrorLine);}
        public override void DeserializeOnJoin(RocketBinaryReader reader){base.DeserializeOnJoin(reader);BoardStructureHooks.DeserializeOnJoin(reader,this);codeError=reader.ReadInt32();runStatus=(SmartRunState)reader.ReadByte();statusErrorLine=reader.ReadInt32();}
    }
}
