from pathlib import Path
import json,struct,math
r=Path(__file__).resolve().parents[2];src=json.loads((r/'Art/SmallTransformer-reference.json').read_text());prov=json.loads((r/'Art/TransformerParts-provenance.json').read_text());count=0
for name,report in prov.items():
 part=src['parts'][0] if name!='Dial'else next(p for p in src['parts']if p['path']==src['needlePath'])
 b=(r/'Assets/Transformer'/f'{name}.meshbin').read_bytes();nv,ni=struct.unpack_from('<ii',b);assert len(b)==8+nv*20+ni*4
 data=[struct.unpack_from('<5f',b,8+i*20)for i in range(nv)];ids=struct.unpack_from('<'+'i'*ni,b,8+nv*20);source_ids=report['sourceIndices'];assert [source_ids[i]for i in ids]==report['sourceTriangles'];count+=ni
 for i,source_index in enumerate(source_ids):
  assert abs(data[i][3]-part['uv'][source_index]['x'])<1e-7 and abs(data[i][4]-part['uv'][source_index]['y'])<1e-7;count+=2
 # Preserve every source edge length under one UNIFORM scale: all corners,
 # bevels, cross-section and full winding depth survive the conversion.
 for a,b,c in zip(ids[::3],ids[1::3],ids[2::3]):
  for first,last in [(a,b),(b,c),(c,a)]:
   p=part['vertices'][source_ids[first]];q=part['vertices'][source_ids[last]]
   native=math.sqrt(sum((p[k]-q[k])**2 for k in 'xyz'))*.195
   target=math.dist(data[first][:3],data[last][:3]);assert abs(native-target)<3e-8,(name,native,target);count+=1
 assert all(math.isfinite(v)for row in data for v in row)
assert prov['Winding']['triangles']==180 and prov['Dial']['triangles']==96 and prov['RangeArc']['triangles']==11
assert (r/'Assets/Transformer/Atlas.png').read_bytes()==(r/'Art/TransformerReferenceAtlas.png').read_bytes()
print(f'{count} exact exported topology/UV/uniform edge-scale checks passed; winding180/dial96/range11 triangles; atlas unchanged.')

side=json.loads((r/'Art/TransformerSideCover.json').read_text());raw=(r/'Assets/Transformer/SideCover.meshbin').read_bytes();nv,ni=struct.unpack_from('<ii',raw);assert nv==222 and ni==148*3
values=[struct.unpack_from('<5f',raw,8+i*20)for i in range(nv)];ids=struct.unpack_from('<'+'i'*ni,raw,8+nv*20);source_ids=side['sourceIndices'];part=src['parts'][0];assert[source_ids[i]for i in ids]==side['sourceTriangles']
for i,k in enumerate(source_ids):assert abs(values[i][3]-part['uv'][k]['x'])<1e-7 and abs(values[i][4]-part['uv'][k]['y'])<1e-7
for a,b,c in zip(ids[::3],ids[1::3],ids[2::3]):
 for i,k in[(a,b),(b,c),(c,a)]:
  p=part['vertices'][source_ids[i]];q=part['vertices'][source_ids[k]];assert abs(math.sqrt(sum((p[c]-q[c])**2 for c in 'xyz'))*.245-math.dist(values[i][:3],values[k][:3]))<3e-8
print('Exact 222-vertex/148-triangle side cover with warning/four bolts preserves source UVs, topology and all uniform-scaled edge lengths.')

bands=json.loads((r/'Art/TransformerWindingBands.json').read_text());raw=(r/'Assets/Transformer/WindingBands.meshbin').read_bytes();nv,ni=struct.unpack_from('<ii',raw);assert nv==72 and ni==120
values=[struct.unpack_from('<5f',raw,8+i*20)for i in range(nv)];ids=struct.unpack_from('<'+'i'*ni,raw,8+nv*20);source_ids=bands['sourceIndices'];assert[source_ids[i]for i in ids]==bands['sourceTriangles']
for i,k in enumerate(source_ids):assert abs(values[i][3]-part['uv'][k]['x'])<1e-7 and abs(values[i][4]-part['uv'][k]['y'])<1e-7
for a,b,c in zip(ids[::3],ids[1::3],ids[2::3]):
 for i,k in[(a,b),(b,c),(c,a)]:
  p=part['vertices'][source_ids[i]];q=part['vertices'][source_ids[k]];assert abs(math.sqrt(sum((p[c]-q[c])**2 for c in 'xyz'))*.195-math.dist(values[i][:3],values[k][:3]))<3e-8
print('Exact original upper/lower winding bands: 72 vertices, 40 triangles, unchanged UVs and uniformly scaled depth/profile passed.')
