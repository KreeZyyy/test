using System;
using System.Linq;
using Assets.Scripts.Networks;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Pipes;
using Assets.Scripts.Localization2;
namespace ModularSwitchboards
{
    // Placement probes advertise the finished port type without changing any
    // live endpoint. Unfinished structures stay electrically disconnected.
    internal static class CabinetPlacement
    {
        private static Connection Probe(SwitchboardCabinet owner,Connection port)
            =>new Connection(owner){Transform=port.Transform,ConnectionRole=port.ConnectionRole,ConnectionType=NetworkType.Power};
        internal static CanConstructInfo Check(SwitchboardCabinet owner)
        {
            if(owner.GridController==null)return CanConstructInfo.ValidPlacement;
            foreach(var port in owner.OpenEnds.Where(p=>p?.Transform!=null))
            {
                var grid=owner.GridController.WorldToLocalGrid(port.Transform.position,SmallGrid.SmallGridSize,SmallGrid.SmallGridOffset);
                var device=owner.GridController.GetSmallCell(grid)?.Device;
                if(device==null||device==owner)continue;
                if(device is INetworkedPipe pipe&&!pipe.ProhibitConnection(owner))continue;
                bool connected;
                if(device is SwitchboardCabinet cabinet)
                {
                    // A frame already reserves its future cable access. Match the
                    // native facing-cell test even while its real ports are None.
                    var facing=owner.GridController.WorldToLocalGrid(port.Transform.position+port.Transform.forward*SmallGrid.SmallGridSize,SmallGrid.SmallGridSize,SmallGrid.SmallGridOffset);
                    connected=cabinet.OpenEnds.Any(other=>other?.Transform!=null&&owner.GridController.WorldToLocalGrid(other.Transform.position,SmallGrid.SmallGridSize,SmallGrid.SmallGridOffset)==facing);
                }
                else connected=device.IsConnected(Probe(owner,port));
                if(connected)return CanConstructInfo.InvalidPlacement(GameStrings.PlacementBlockedByAdjacentDevice.AsString(device.DisplayName));
            }
            return CanConstructInfo.ValidPlacement;
        }
        internal sealed class PreviewScope
        {
            internal Connection[] Ports;
            internal NetworkType[] Types;
            internal void Restore(){if(Ports==null)return;for(int i=0;i<Ports.Length;i++)Ports[i].ConnectionType=Types[i];Ports=null;}
        }
        // Native WillJoinNetwork owns the Span buffer and original endpoint
        // references. Expose power only on its unregistered construction cursor,
        // then restore immediately, including exceptions. Real frames never change.
        internal static void BeginPreview(SmallGrid __instance,out PreviewScope __state)
        {
            __state=null;
            if(!(__instance is SwitchboardCabinet owner)||!owner.IsCursor)return;
            var ports=owner.OpenEnds.Where(p=>p!=null).ToArray();
            __state=new PreviewScope{Ports=ports,Types=ports.Select(p=>p.ConnectionType).ToArray()};
            foreach(var port in ports)port.ConnectionType=NetworkType.Power;
        }
        internal static void EndPreview(PreviewScope __state)=>__state?.Restore();
        internal static Exception FinishPreview(Exception __exception,PreviewScope __state){__state?.Restore();return __exception;}
    }
}
