using System.Collections.Generic;
using System.Linq;
using Assets.Scripts;
using Assets.Scripts.Util;
using Assets.Scripts.Inventory;
using Assets.Scripts.Objects.Electrical;
using Assets.Scripts.Networks;
using Assets.Scripts.Objects.Pipes;
using System.Xml.Serialization;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Networking;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Structures;
using Assets.Scripts.Localization2;
using LibConstruct;
using UnityEngine;

namespace ModularSwitchboards
{
    public sealed class SwitchboardCabinetSaveData : StructureSaveData
    {
        [XmlElement] public PlacementBoardHostSaveData RailBoard;
        [XmlArray] public CabinetWireSaveData[] Wires;
        [XmlElement] public int CoverSchema;
        [XmlElement] public PlacementBoardHostSaveData CoverBoard;
        [XmlElement] public PlacementBoardHostSaveData DoorBoard;
        [XmlElement] public PlacementBoardHostSaveData BridgeBoard;
        [XmlElement] public PlacementBoardHostSaveData DoorLabels;
        [XmlElement] public PlacementBoardHostSaveData RightDoorBoard,RightDoorLabels,RightBridgeBoard;
    }

    // Retains the stock locker interactions; owns the LibConstruct mounting surface.
    public sealed class SwitchboardCabinet : Locker, IPlacementBoardHost
    {
        private CabinetWiring wiring;
        internal CabinetWiring Wiring
        {
            get {if(wiring==null){wiring=GetComponent<CabinetWiring>();if(wiring==null)wiring=gameObject.AddComponent<CabinetWiring>();wiring.Owner=this;}return wiring;}
        }
        public override CanConstructInfo CanConstruct()
        {
            var result=base.CanConstruct();
            return result.CanConstruct?CabinetPlacement.Check(this):result;
        }
        public override bool IsPowerProvider=>true;
        public override bool IsPowerInputOutput=>true;
        public override float GetGeneratedPower(CableNetwork network)=>Wiring.Power.Generated(network);
        public override float GetUsedPower(CableNetwork network)=>Wiring.Power.Used(network);
        public override void UsePower(CableNetwork network,float value)=>Wiring.Power.Use(network,value);
        public override void ReceivePower(CableNetwork network,float value)=>Wiring.Power.Receive(network,value);
        public override bool AllowSetPower(CableNetwork network)=>Wiring.Power.AllowsPower(network);
        public override bool IsProviderToDevice(Device other,ref List<long> evaluated)=>Wiring.Power.IsProviderTo(this,other,ref evaluated);
        public Grid3[] PortBodyGrids;
        public Connection InputConnection => OpenEnds?.FirstOrDefault(p=>p.ConnectionRole==ConnectionRole.Input);
        public Connection Output1Connection => OpenEnds?.FirstOrDefault(p=>p.ConnectionRole==ConnectionRole.Output);
        public Connection Output3Connection=>CabinetPorts.Combiner(PrefabName)?null:OpenEnds?.FirstOrDefault(p=>p.ConnectionRole==ConnectionRole.Waste);
        public Connection Output2Connection => CabinetPorts.Combiner(PrefabName)?null:OpenEnds?.FirstOrDefault(p=>p.ConnectionRole==ConnectionRole.Output2);
        internal IEnumerable<Connection> InputPorts=>(OpenEnds??new List<Connection>()).Where(p=>CabinetPorts.IsInputRole(PrefabName,p.ConnectionRole));
        internal Connection InputPort(int contact)=>OpenEnds?.FirstOrDefault(p=>p.ConnectionRole==CabinetPorts.InputRole(contact));
        internal IEnumerable<int> InputContacts=>CabinetPorts.InputContacts(PrefabName);
        public override DelayedActionInstance InteractWith(Interactable interactable,Interaction interaction,bool doAction=true)
            =>base.InteractWith(CabinetDoorHandles.Canonical(this,interactable),interaction,doAction);
        public override PassiveTooltip GetPassiveTooltip(Collider hitCollider)
        {
            if(hitCollider!=null && IsStructureCompleted)
            {
                var third=Output3Connection;if(third!=null&&third.Collider==hitCollider){var tip=new PassiveTooltip(toDefault:true).Populate(third);tip.Title="Output 3";return tip;}
                var wireTarget=hitCollider.GetComponent<CabinetWireTarget>();
                if(wireTarget!=null)return new PassiveTooltip(toDefault:true){Title=Wiring.ContactName(wireTarget.End)};
                var terminal=hitCollider.GetComponent<CabinetTerminalBlock>();
                if(terminal!=null && terminal.Owner==this && terminal.TerminalCollider==hitCollider && terminal.ExternalConnection!=null)
                    {var tip=new PassiveTooltip(toDefault:true).Populate(terminal.ExternalConnection);if(CabinetPorts.Combiner(PrefabName))tip.Title=CabinetPorts.RoleLabel(PrefabName,terminal.ExternalRole);else if(terminal.ExternalConnection==Output3Connection)tip.Title="Output 3";return tip;}
            }
            if(CabinetPorts.Combiner(PrefabName)&&hitCollider!=null)
            {
                var connection=OpenEnds?.FirstOrDefault(p=>p.Collider==hitCollider);
                if(connection!=null){var tip=new PassiveTooltip(toDefault:true).Populate(connection);tip.Title=CabinetPorts.RoleLabel(PrefabName,connection.ConnectionRole);return tip;}
            }
            return base.GetPassiveTooltip(hitCollider);
        }
        private void PrepareInputConnection()
        {
            foreach(var port in OpenEnds)
            {
                port.Parent=this;
                port.ConnectionType=IsStructureCompleted?NetworkType.Power:NetworkType.None;
                port.Validate();
            }
        }
        public override object GetLocalSmallGridBounds()
        {
            if(PortBodyGrids==null)return base.GetLocalSmallGridBounds();
            var grids=new HashSet<Grid3>(PortBodyGrids);
            foreach(var port in OpenEnds)
                if(port?.Transform!=null)
                {
                    // Native cable traversal looks for the device at the other end of its connector.
                    // Register the T junction itself, without reserving the empty rectangle around it.
                    grids.Add(transform.InverseTransformPoint(port.Transform.position+port.Transform.forward*SmallGrid.SmallGridSize).ToGrid(SmallGrid.SmallGridSize,SmallGrid.SmallGridOffset));
                }
            // Connection.LocalGrid is where the cable lives, not occupied device body.
            // Reserving it makes Cable.CanConstruct reject this cabinet before highlighting.
            foreach(var port in OpenEnds)
                if(port?.Transform!=null)grids.Remove(transform.InverseTransformPoint(port.Transform.position).ToGrid(SmallGrid.SmallGridSize,SmallGrid.SmallGridOffset));
            return grids.ToArray();
        }
        public override bool IsConnected(Connection otherEnd)=>IsStructureCompleted && base.IsConnected(otherEnd);
        protected override void OnBuildStateUpdated(int newState,int previousState)
        {
            foreach(var port in OpenEnds)port.ConnectionType=newState>=1?NetworkType.Power:NetworkType.None;
            base.OnBuildStateUpdated(newState,previousState);
            if(!IsCursor && GridController!=null && GameManager.GameState==GameState.Running)
            {
                if(newState<1)
                    foreach(var network in ConnectedCableNetworks.ToArray())network.RemoveDevice(this);
                InitializeDataConnection();
                if(newState>=1)InitializeDevice();
            }
        }
        public Transform RailOrigin;
        public BoxCollider RailSurface;
        public BoxCollider[] RailRowSurfaces;
        private BoardRef<CabinetRailBoard> railBoard;
        public CabinetRailBoard RailBoard => railBoard?.Board;
        // Housing opening .388 x .488; leave 1 mm per side.
        // Prefab dimensions, not save data: existing covers adopt their cabinet's profile.
        public float InnerCoverWidth=.386f,InnerCoverHeight=.486f,InnerCoverDepth=.1015f,InnerCoverThickness=.002f;
        internal InnerCoverLayout.Panel CoverProfile=>new InnerCoverLayout.Panel(CabinetShape.Medium(PrefabName)?.774f:InnerCoverWidth,CabinetShape.Medium(PrefabName)?.974f:InnerCoverHeight,InnerCoverDepth,InnerCoverThickness);
        public Transform CoverOrigin;
        public BoxCollider CoverSurface;
        private BoardRef<CabinetCoverBoard> coverBoard;
        public CabinetCoverBoard CoverBoard => coverBoard?.Board;
        public Transform DoorOrigin;
        public BoxCollider DoorSurface;
        public BoxCollider DoorLabelSurface;
        private BoardRef<DoorLabelBoard> doorLabels;
        public DoorLabelBoard DoorLabels=>doorLabels?.Board;
        private BoardRef<SwitchboardDoorBoard> doorBoard;
        public SwitchboardDoorBoard DoorBoard=>doorBoard?.Board;
        public Transform BridgeOrigin;
        public BoxCollider BridgeSurface;
        private BoardRef<SwitchboardBridgeBoard> bridgeBoard;
        public SwitchboardBridgeBoard BridgeBoard=>bridgeBoard?.Board;
        public Transform RightDoorOrigin,RightBridgeOrigin;
        public BoxCollider RightDoorSurface,RightDoorLabelSurface,RightBridgeSurface;
        private BoardRef<SwitchboardDoorBoard> rightDoorBoard;
        private BoardRef<DoorLabelBoard> rightDoorLabels;
        private BoardRef<SwitchboardBridgeBoard> rightBridgeBoard;
        public SwitchboardDoorBoard RightDoorBoard=>rightDoorBoard?.Board;
        public DoorLabelBoard RightDoorLabels=>rightDoorLabels?.Board;
        public SwitchboardBridgeBoard RightBridgeBoard=>rightBridgeBoard?.Board;
        internal bool IsRightBoard(PlacementBoard board)=>board!=null&&(board==RightDoorBoard||board==RightDoorLabels||board==RightBridgeBoard);
        internal SwitchboardDoorBoard DoorBoardFor(PlacementBoard board)=>IsRightBoard(board)?RightDoorBoard:DoorBoard;
        internal DoorLabelBoard DoorLabelsFor(PlacementBoard board)=>IsRightBoard(board)?RightDoorLabels:DoorLabels;
        internal IEnumerable<PlacementBoard> DoorBoards=>new PlacementBoard[]{DoorBoard,BridgeBoard,RightDoorBoard,RightBridgeBoard}.Where(b=>b!=null);
        public bool HasInnerCover => CurrentBuildStateIndex==2 || CoverBoard?.Structures.OfType<InnerCoverModule>().Any(c=>!c.IsBeingDestroyed)==true;
        public bool CanAccessModules => CurrentBuildStateIndex>=1&&IsOpen;
        public bool CanFitRails => CurrentBuildStateIndex == 1 && IsOpen && !HasInnerCover;

        public IEnumerable<PlacementBoard> GetPlacementBoards()
        {
            if (RailBoard != null) yield return RailBoard;
            if (CoverBoard != null) yield return CoverBoard;
            if (DoorBoard != null) yield return DoorBoard;
            if(DoorLabels!=null)yield return DoorLabels;
            if(BridgeBoard!=null)yield return BridgeBoard;
            if(RightDoorBoard!=null)yield return RightDoorBoard;if(RightDoorLabels!=null)yield return RightDoorLabels;if(RightBridgeBoard!=null)yield return RightBridgeBoard;
        }
        public IEnumerable<BoxCollider> CollidersForBoard(PlacementBoard board)
        {
            if(board==RightDoorLabels&&RightDoorLabels!=null){if(RightDoorLabelSurface!=null)yield return RightDoorLabelSurface;yield break;}
            if(board==RightBridgeBoard&&RightBridgeBoard!=null){if(RightBridgeSurface!=null)yield return RightBridgeSurface;yield break;}
            if(board==RightDoorBoard&&RightDoorBoard!=null){if(RightDoorSurface!=null)yield return RightDoorSurface;yield break;}
            if(board is DoorLabelBoard){if(DoorLabelSurface!=null)yield return DoorLabelSurface;}
            else if(board is SwitchboardBridgeBoard){if(BridgeSurface!=null)yield return BridgeSurface;}
            else if(board is SwitchboardDoorBoard){if(DoorSurface!=null)yield return DoorSurface;}
            else if (board is CabinetCoverBoard) { if(CoverSurface!=null)yield return CoverSurface; }
            else if(board is CabinetRailBoard&&RailRowSurfaces!=null){foreach(var hit in RailRowSurfaces)if(hit!=null)yield return hit;}
            else if (RailSurface != null) yield return RailSurface;
        }
        public void OnBoardStructureRegistered(PlacementBoard board, IPlacementBoardStructure structure) { }
        public void OnBoardStructureDeregistered(PlacementBoard board, IPlacementBoardStructure structure) { }

        public override void OnRegistered(Cell cell)
        {
            var ready=Wiring;
            PrepareInputConnection();
            base.OnRegistered(cell);
            if(!IsCursor && InputConnection!=null)
                Debug.Log("[Modular Switchboards] Cabinet IN ready: role="+InputConnection.ConnectionRole+
                    "; type="+InputConnection.ConnectionType+"; localGrid="+InputConnection.GetLocalGrid()+
                    "; facingGrid="+InputConnection.GetFacingGrid()+"; completed="+IsStructureCompleted);
            if (!IsCursor && RailOrigin != null)
                BoardHostHooks.OnRegisteredBoard(this, ref railBoard, RailOrigin);
            if(!IsCursor&&CoverOrigin!=null)BoardHostHooks.OnRegisteredBoard(this,ref coverBoard,CoverOrigin);
            if(!IsCursor&&DoorOrigin!=null)BoardHostHooks.OnRegisteredBoard(this,ref doorBoard,DoorOrigin);
            if(!IsCursor&&DoorOrigin!=null)BoardHostHooks.OnRegisteredBoard(this,ref doorLabels,DoorOrigin);
            if(!IsCursor&&BridgeOrigin!=null)BoardHostHooks.OnRegisteredBoard(this,ref bridgeBoard,BridgeOrigin);
            if(!IsCursor&&RightDoorOrigin!=null){BoardHostHooks.OnRegisteredBoard(this,ref rightDoorBoard,RightDoorOrigin);BoardHostHooks.OnRegisteredBoard(this,ref rightDoorLabels,RightDoorOrigin);}
            if(!IsCursor&&RightBridgeOrigin!=null)BoardHostHooks.OnRegisteredBoard(this,ref rightBridgeBoard,RightBridgeOrigin);
        }
        public override void OnFinishedLoad()
        {
            var ready=Wiring;
            PrepareInputConnection();
            base.OnFinishedLoad();
            if (!IsCursor && RailOrigin != null)
                BoardHostHooks.OnFinishedLoadBoard(this, ref railBoard, RailOrigin);
            if(!IsCursor&&CoverOrigin!=null)BoardHostHooks.OnFinishedLoadBoard(this,ref coverBoard,CoverOrigin);
            if(!IsCursor&&DoorOrigin!=null)BoardHostHooks.OnFinishedLoadBoard(this,ref doorBoard,DoorOrigin);
            if(!IsCursor&&DoorOrigin!=null)BoardHostHooks.OnFinishedLoadBoard(this,ref doorLabels,DoorOrigin);
            if(!IsCursor&&BridgeOrigin!=null)BoardHostHooks.OnFinishedLoadBoard(this,ref bridgeBoard,BridgeOrigin);
            if(!IsCursor&&RightDoorOrigin!=null){BoardHostHooks.OnFinishedLoadBoard(this,ref rightDoorBoard,RightDoorOrigin);BoardHostHooks.OnFinishedLoadBoard(this,ref rightDoorLabels,RightDoorOrigin);}
            if(!IsCursor&&RightBridgeOrigin!=null)BoardHostHooks.OnFinishedLoadBoard(this,ref rightBridgeBoard,RightBridgeOrigin);
        }
        public override ThingSaveData SerializeSave()
        {
            ThingSaveData data = new SwitchboardCabinetSaveData();
            InitialiseSaveData(ref data);
            return data;
        }
        protected override void InitialiseSaveData(ref ThingSaveData data)
        {
            base.InitialiseSaveData(ref data);
            if(data is SwitchboardCabinetSaveData wireSave){wireSave.Wires=Wiring.Save();wireSave.CoverSchema=1;}
            if (data is SwitchboardCabinetSaveData save && RailBoard != null)
                save.RailBoard = BoardHostHooks.SerializeBoard(this, RailBoard);
            if(data is SwitchboardCabinetSaveData coverSave&&CoverBoard!=null)coverSave.CoverBoard=BoardHostHooks.SerializeBoard(this,CoverBoard);
            if(data is SwitchboardCabinetSaveData doorSave&&DoorBoard!=null)doorSave.DoorBoard=BoardHostHooks.SerializeBoard(this,DoorBoard);
            if(data is SwitchboardCabinetSaveData labelSave&&DoorLabels!=null)labelSave.DoorLabels=BoardHostHooks.SerializeBoard(this,DoorLabels);
            if(data is SwitchboardCabinetSaveData bridgeSave&&BridgeBoard!=null)bridgeSave.BridgeBoard=BoardHostHooks.SerializeBoard(this,BridgeBoard);
            if(data is SwitchboardCabinetSaveData medium){if(RightDoorBoard!=null)medium.RightDoorBoard=BoardHostHooks.SerializeBoard(this,RightDoorBoard);if(RightDoorLabels!=null)medium.RightDoorLabels=BoardHostHooks.SerializeBoard(this,RightDoorLabels);if(RightBridgeBoard!=null)medium.RightBridgeBoard=BoardHostHooks.SerializeBoard(this,RightBridgeBoard);}
        }
        public override void DeserializeSave(ThingSaveData data)
        {
            base.DeserializeSave(data);
            Wiring.Load((data as SwitchboardCabinetSaveData)?.Wires);
            // Old cabinet saves intentionally have no board and gain an empty one on load.
            BoardHostHooks.DeserializeBoard(this, (data as SwitchboardCabinetSaveData)?.RailBoard,
                out railBoard, RailOrigin);
            BoardHostHooks.DeserializeBoard(this,(data as SwitchboardCabinetSaveData)?.CoverBoard,out coverBoard,CoverOrigin);
            BoardHostHooks.DeserializeBoard(this,(data as SwitchboardCabinetSaveData)?.DoorBoard,out doorBoard,DoorOrigin);
            BoardHostHooks.DeserializeBoard(this,(data as SwitchboardCabinetSaveData)?.BridgeBoard,out bridgeBoard,BridgeOrigin);
            BoardHostHooks.DeserializeBoard(this,(data as SwitchboardCabinetSaveData)?.DoorLabels,out doorLabels,DoorOrigin);
            if(CabinetShape.Medium(PrefabName)){var save=data as SwitchboardCabinetSaveData;BoardHostHooks.DeserializeBoard(this,save?.RightDoorBoard,out rightDoorBoard,RightDoorOrigin);BoardHostHooks.DeserializeBoard(this,save?.RightDoorLabels,out rightDoorLabels,RightDoorOrigin);BoardHostHooks.DeserializeBoard(this,save?.RightBridgeBoard,out rightBridgeBoard,RightBridgeOrigin);}
        }
        public override void SerializeOnJoin(RocketBinaryWriter writer)
        {
            base.SerializeOnJoin(writer);
            BoardHostHooks.SerializeBoardOnJoin(writer, this, RailBoard);
            Wiring.Write(writer);
            BoardHostHooks.SerializeBoardOnJoin(writer,this,CoverBoard);
            BoardHostHooks.SerializeBoardOnJoin(writer,this,DoorBoard);
            BoardHostHooks.SerializeBoardOnJoin(writer,this,BridgeBoard);
            BoardHostHooks.SerializeBoardOnJoin(writer,this,DoorLabels);
            if(CabinetShape.Medium(PrefabName)){BoardHostHooks.SerializeBoardOnJoin(writer,this,RightDoorBoard);BoardHostHooks.SerializeBoardOnJoin(writer,this,RightDoorLabels);BoardHostHooks.SerializeBoardOnJoin(writer,this,RightBridgeBoard);}
        }
        public override void DeserializeOnJoin(RocketBinaryReader reader)
        {
            base.DeserializeOnJoin(reader);
            BoardHostHooks.DeserializeBoardOnJoin(reader, this, out railBoard, RailOrigin);
            Wiring.Read(reader);
            BoardHostHooks.DeserializeBoardOnJoin(reader,this,out coverBoard,CoverOrigin);
            BoardHostHooks.DeserializeBoardOnJoin(reader,this,out doorBoard,DoorOrigin);
            BoardHostHooks.DeserializeBoardOnJoin(reader,this,out bridgeBoard,BridgeOrigin);
            BoardHostHooks.DeserializeBoardOnJoin(reader,this,out doorLabels,DoorOrigin);
            if(CabinetShape.Medium(PrefabName)){BoardHostHooks.DeserializeBoardOnJoin(reader,this,out rightDoorBoard,RightDoorOrigin);BoardHostHooks.DeserializeBoardOnJoin(reader,this,out rightDoorLabels,RightDoorOrigin);BoardHostHooks.DeserializeBoardOnJoin(reader,this,out rightBridgeBoard,RightBridgeOrigin);}
        }
        public override void BuildUpdate(RocketBinaryWriter writer,ushort networkUpdateType)
        {base.BuildUpdate(writer,networkUpdateType);if(Thing.IsNetworkUpdateRequired(CabinetWiring.UpdateFlag,networkUpdateType))Wiring.Write(writer);}
        public override void ProcessUpdate(RocketBinaryReader reader,ushort networkUpdateType)
        {base.ProcessUpdate(reader,networkUpdateType);if(Thing.IsNetworkUpdateRequired(CabinetWiring.UpdateFlag,networkUpdateType))Wiring.Read(reader);}
        public override void OnDestroy()
        {
            wiring?.Power.StopOwnPower();
            BoardHostLifetime.Release(this,ref railBoard);
            BoardHostLifetime.Release(this,ref coverBoard);
            BoardHostLifetime.Release(this,ref doorBoard);
            BoardHostLifetime.Release(this,ref bridgeBoard);
            BoardHostLifetime.Release(this,ref doorLabels);
            BoardHostLifetime.Release(this,ref rightDoorBoard);BoardHostLifetime.Release(this,ref rightDoorLabels);BoardHostLifetime.Release(this,ref rightBridgeBoard);
            base.OnDestroy();
        }
        protected override CanConstructInfo CanDeconstruct()
        {
            if(CurrentBuildStateIndex==2)return IsOpen?CanConstructInfo.ValidPlacement:CanConstructInfo.InvalidPlacement("Open the cabinet first.");
            if((BridgeBoard?.Structures.Count??0)+(RightBridgeBoard?.Structures.Count??0)>0)return CanConstructInfo.InvalidPlacement("Remove the door terminal bridge first.");
            if((DoorLabels?.Structures.Count??0)+(RightDoorLabels?.Structures.Count??0)>0)return CanConstructInfo.InvalidPlacement("Remove door labels first.");
            if((DoorBoard?.Structures.Count??0)+(RightDoorBoard?.Structures.Count??0)>0)return CanConstructInfo.InvalidPlacement("Remove door modules first.");
            if(HasInnerCover)return CanConstructInfo.InvalidPlacement("Remove the inner cover first.");
            return Wiring.HasAnyWires?CanConstructInfo.InvalidPlacement("Remove internal wires first."):RailBoard != null && RailBoard.Structures.Count > 0
                ? CanConstructInfo.InvalidPlacement("Remove DIN rails first.") : base.CanDeconstruct();
        }
        public override DelayedActionInstance AttackWith(Attack attack, bool doAction = true)
        {
            if(attack.SourceItem is Assets.Scripts.Objects.Items.Labeller)
            {
                var plate=transform.Find("SwitchboardModel/CompletedShell/DoorHinge/CabinetNameplate");
                if(plate==null)return null;
                var p=plate.InverseTransformPoint(attack.Position);
                if(Mathf.Abs(p.x)>.067f||Mathf.Abs(p.y)>.021f||Mathf.Abs(p.z)>.012f)return null;
            }
            if(SwitchboardCoverMount.TryAttack(this,attack,doAction,out var coverAction))return coverAction;
            if(attack.SourceItem?.PrefabName=="ItemWrench"&&CurrentBuildStateIndex==2)
            {
                if(!IsOpen)return new DelayedActionInstance{Duration=0}.Fail("Open the cabinet first.");
                return base.AttackWith(attack,doAction);
            }
            if(HasInnerCover&&(attack.SourceItem?.PrefabName=="ItemWrench"||attack.SourceItem?.PrefabName=="ItemDrill"))return null;
            if(Wiring.TryAttack(attack,doAction,out var wireAction))return wireAction;
            if(Wiring.HasAnyWires && (attack.SourceItem?.PrefabName=="ItemWrench"||attack.SourceItem?.PrefabName=="ItemDrill"))return null;
            if (RailBoard != null && RailBoard.Structures.Count > 0 &&
                (attack.SourceItem?.PrefabName == "ItemWrench" || attack.SourceItem?.PrefabName == "ItemDrill"))
                return null;
            return base.AttackWith(attack, doAction);
        }
        private float nextPortCheck;
        private void SyncExternalCableNetworks()
        {
            var live=new HashSet<Cable>();
            if(IsStructureCompleted)
                foreach(var port in OpenEnds)
                {
                    var cable=port.GetCable();if(cable==null || cable.CableNetwork==null)continue;
                    live.Add(cable);
                    if(cable.CableNetwork.GetDeviceRegistration(this)?.Contains(cable)!=true)
                        cable.CableNetwork.AddDevice(cable,this);
                }
            // Cable removal/replacement can change the inherited Device.PowerCable cache.
            if(PowerCable!=live.FirstOrDefault())InitializeDataConnection();
            foreach(var network in ConnectedCableNetworks.ToArray())
            {
                var registration=network.GetDeviceRegistration(this);if(registration==null)continue;
                foreach(var cable in registration.ToArray())
                    if(!live.Contains(cable)||cable.CableNetwork!=network)network.RemoveDevice(cable,this);
            }
        }
        private void LateUpdate()
        {
            if(!IsCursor && GameManager.GameState==GameState.Running)Wiring.Tick();
            if(BridgeSurface!=null){BridgeSurface.enabled=!IsCursor&&CanFitRails;if(BridgeSurface.enabled)Thing._colliderLookup[BridgeSurface]=this;}
            bool placingDoorLabel=BoardPlacementInput.Wants(PlacementSurfaceKind.DoorLabel);
            if(DoorLabelSurface!=null){DoorLabelSurface.enabled=!IsCursor&&IsStructureCompleted&&placingDoorLabel;if(DoorLabelSurface.enabled)Thing._colliderLookup[DoorLabelSurface]=this;}
            if(DoorSurface!=null){DoorSurface.enabled=!IsCursor&&IsStructureCompleted&&!placingDoorLabel;if(DoorSurface.enabled)Thing._colliderLookup[DoorSurface]=this;}
            if(RightBridgeSurface!=null){RightBridgeSurface.enabled=!IsCursor&&CanFitRails;if(RightBridgeSurface.enabled)Thing._colliderLookup[RightBridgeSurface]=this;}
            if(RightDoorSurface!=null){RightDoorSurface.enabled=!IsCursor&&IsStructureCompleted&&!placingDoorLabel;if(RightDoorSurface.enabled)Thing._colliderLookup[RightDoorSurface]=this;}
            if(RightDoorLabelSurface!=null){RightDoorLabelSurface.enabled=!IsCursor&&IsStructureCompleted&&placingDoorLabel;if(RightDoorLabelSurface.enabled)Thing._colliderLookup[RightDoorLabelSurface]=this;}
            RailPlacementSurfaces.Refresh(this);
            if(CoverSurface!=null)CoverSurface.enabled=false;
            if(CoverSurface!=null&&CoverSurface.enabled)Thing._colliderLookup[CoverSurface]=this;
            // Outside connectors can occupy separate cable cells. Keep native registration
            // current after cable placement/removal/network rebuilds without joining the nets.
            if(!IsCursor && GameManager.GameState==GameState.Running && Time.unscaledTime>=nextPortCheck)
            {
                nextPortCheck=Time.unscaledTime+.25f;SyncExternalCableNetworks();
            }
        }
    }

    public sealed class CabinetRailBoard : PlacementBoard
    {
        public override float GridSize => DinLayout.ModulePitch;
        public override IPlacementBoardStructure EquivalentStructure(Structure structure)
            => structure is DinRail && PrimaryHost is SwitchboardCabinet host && host.CanFitRails
                ? structure as IPlacementBoardStructure : null;
    }
}
