from pathlib import Path
p=Path(__file__).resolve().parents[2]
s=(p/"Source/DinRailModel.cs").read_text();a=s.index("        internal static void Resize");b=s.index("        internal static void Refresh",a)
f=Path(__file__).parent/"Resize.cs";t=f.with_suffix(".new");t.write_text("using System;using System.Linq;using UnityEngine;namespace ModularSwitchboards{static partial class DinRailModel{"+s[a:b]+"}}")

t.replace(f)
