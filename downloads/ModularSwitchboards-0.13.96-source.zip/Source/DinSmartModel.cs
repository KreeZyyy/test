using Assets.Scripts.GridSystem;
using Assets.Scripts.Objects;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class DinSmartModel
    {
        internal static void Install(DinBreaker module)
        {
            var model=module.transform.Find("DinBreakerModel");
            var mesh=DinBreakerModel.Build(DinSmartLayout.Width,DinSmartLayout.CenterX);
            model.GetComponent<MeshFilter>().sharedMesh=mesh;
            var hit=model.GetComponent<BoxCollider>();hit.center=mesh.bounds.center;hit.size=mesh.bounds.size;
            foreach(string name in new[]{"BreakerLever","BreakerControl","BreakerIndicator"})
            {
                var child=model.Find(name);if(child!=null)child.localPosition+=Vector3.right*DinSmartLayout.CenterX;
            }
            var view=module.GetComponent<BreakerSwitchView>();if(view!=null)view.CenterX=DinSmartLayout.CenterX;
            var bounds=mesh.bounds;
            bounds.Encapsulate(new Bounds(new Vector3(DinSmartLayout.CenterX,0,.069f),new Vector3(.0176f,.047f,.044f)));
            var scale=DinBreakerModel.VisualScale;
            module.Bounds=new Bounds(Vector3.Scale(bounds.center,scale),Vector3.Scale(bounds.size,scale));
            module.GridBounds=new GridBounds(module);module.SurfaceArea=.016f*DinSmartLayout.Slots;
            module.Thumbnail=CabinetIcons.Get("DinSmart");module.BuildStates[0].Thumbnail=module.Thumbnail;
            // Shared breaker renderer/interactables remain; final blueprint is
            // regenerated after this install, including the centred switch.
            SmartNativeReferences.Capture();
        }
    }
}
