using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;

namespace ScriptedScreensLiteGeminiAI;

public sealed class JobService : IDisposable
{
    private readonly object gate = new object();
    private readonly Settings settings;
    private readonly IAiProvider provider;
    private readonly ConversationStore memory;
    private readonly AudioStore audio;
    private readonly Dictionary<string, JobResult> jobs = new Dictionary<string, JobResult>();
    private readonly Dictionary<string, DateTime> sourceTimes = new Dictionary<string, DateTime>();
    private readonly Queue<DateTime> requestTimes = new Queue<DateTime>();
    private readonly HashSet<Task> tasks = new HashSet<Task>();
    private readonly CancellationTokenSource stop = new CancellationTokenSource();
    private readonly SemaphoreSlim workers;
    private int pending;
    private bool disposed;

    public JobService(Settings settings, IAiProvider provider, ConversationStore memory, AudioStore audio)
    {
        this.settings = settings; this.provider = provider; this.memory = memory; this.audio = audio;
        workers = new SemaphoreSlim(settings.MaxConcurrent);
    }
    public string Submit(AskRequest request)
    {
        request.Validate(settings);
        lock (gate)
        {
            if (disposed) throw new AiException(503, "AI service is stopping.");
            Cleanup();
            if (pending >= settings.MaxPending || jobs.Count >= settings.MaxJobs) throw new AiException(429, "AI queue is full. Retry later.");
            var now = DateTime.UtcNow;
            if (sourceTimes.TryGetValue(request.SourceRefId, out var last) && now.Subtract(last).TotalSeconds < settings.CooldownSeconds)
                throw new AiException(429, "Device cooldown is active.");
            while (requestTimes.Count > 0 && now.Subtract(requestTimes.Peek()).TotalSeconds >= 60) requestTimes.Dequeue();
            if (requestTimes.Count >= settings.RequestsPerMinute) throw new AiException(429, "Server request limit reached. Retry later.");
            ConversationStore.Lease? lease = request.Remember ? memory.Reserve(request.ConversationKey) : null;
            string id = Guid.NewGuid().ToString("N");
            var job = new JobResult { Id = id, SourceRefId = request.SourceRefId, ConversationId = request.ConversationKey };
            jobs.Add(id, job);
            pending++;
            sourceTimes[request.SourceRefId] = now;
            requestTimes.Enqueue(now);
            // Snapshot the request: callers cannot mutate its preferences after acceptance.
            var snapshot = JObject.FromObject(request).ToObject<AskRequest>()!;
            Task task = Task.Run(() => Run(snapshot, job, lease));
            tasks.Add(task);
            _ = task.ContinueWith(t => { lock (gate) tasks.Remove(t); }, TaskScheduler.Default);
            return id;
        }
    }
    private async Task Run(AskRequest request, JobResult job, ConversationStore.Lease? lease)
    {
        bool acquired = false;
        string finalState = "error";
        using var timeout = CancellationTokenSource.CreateLinkedTokenSource(stop.Token);
        timeout.CancelAfter(TimeSpan.FromSeconds(settings.RequestTimeoutSeconds * 2 + 10));
        try
        {
            await workers.WaitAsync(timeout.Token).ConfigureAwait(false);
            acquired = true;
            lock (gate) job.State = "running";
            string full = await provider.TextAsync(request, lease?.Context ?? Array.Empty<Turn>(), timeout.Token).ConfigureAwait(false);
            if (string.IsNullOrWhiteSpace(full)) throw new AiException(502, "AI returned no text.");
            string text = TextLimits.Cut(full, settings.MaxReplyChars);
            lock (gate) { job.Text = text; job.ReplyTruncated = full.Length > text.Length; }
            if (lease != null)
            {
                try { lease.Append(request.Question, text); }
                catch (AiException ex) { lock (gate) job.MemoryError = ex.Message; }
            }
            if (request.Speak && settings.EnableTts)
            {
                if (text.Length > settings.MaxSpeechChars)
                { lock (gate) job.VoiceError = "Reply is longer than the speech limit. Ask for a shorter reply."; }
                else
                {
                    try
                    {
                        byte[] wav = await provider.SpeechAsync(text, request, timeout.Token).ConfigureAwait(false);
                        WaveAudio.ValidateWav(wav);
                        var clip = audio.Save(wav);
                        lock (gate) { job.AudioUrl = clip.Url; job.AudioExpiresUtc = clip.ExpiresUtc; }
                    }
                    catch (Exception ex)
                    {
                        lock (gate) job.VoiceError = ex is AiException safe ? safe.Message : "TTS failed or timed out; text is available.";
                    }
                }
            }
            finalState = "done";
        }
        catch (Exception ex)
        {
            lock (gate) { job.Error = ex is AiException safe ? safe.Message : "AI request failed or timed out."; }
        }
        finally
        {
            lease?.Dispose();
            if (acquired) workers.Release();
            lock (gate) { pending--; job.FinishedUtc = DateTime.UtcNow; job.State = finalState; }
        }
    }
    public JObject Get(string id)
    {
        lock (gate)
        {
            Cleanup();
            if (!jobs.TryGetValue(id, out var job)) throw new AiException(404, "Job not found or expired.");
            return JObject.FromObject(job);
        }
    }
    public object ListConversations() => memory.List();
    public void Reset(AskRequest identity)
    {
        identity.Question = "reset";
        identity.Validate(settings);
        memory.Delete(identity.ConversationKey);
    }
    public void Cleanup()
    {
        lock (gate)
        {
            DateTime now = DateTime.UtcNow;
            foreach (string id in jobs.Where(p => p.Value.FinishedUtc.HasValue && now.Subtract(p.Value.FinishedUtc.Value).TotalSeconds > settings.JobTtlSeconds)
                                       .Select(p => p.Key).ToArray()) jobs.Remove(id);
            foreach (string source in sourceTimes.Where(p => now.Subtract(p.Value).TotalSeconds > 60).Select(p => p.Key).ToArray()) sourceTimes.Remove(source);
        }
    }
    public void Dispose()
    {
        Task[] running;
        lock (gate) { if (disposed) return; disposed = true; stop.Cancel(); running = tasks.ToArray(); }
        try { Task.WaitAll(running, 3000); } catch { }
        // Semaphore/token are intentionally not disposed while a cancelled provider may still unwind.
    }
}
