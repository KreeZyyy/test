using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using Newtonsoft.Json;

namespace ScriptedScreensLiteGeminiAI;

public static class TextLimits
{
    public static string Cut(string value, int max)
    {
        if (value.Length <= max) return value;
        int length = max;
        if (length > 0 && char.IsHighSurrogate(value[length - 1])) length--;
        return value.Substring(0, length);
    }
    public static List<Turn> Context(IEnumerable<Turn> turns, int byteBudget)
    {
        var result = new List<Turn>();
        foreach (var turn in turns.Reverse())
        {
            int size = Encoding.UTF8.GetByteCount(turn.Question) + Encoding.UTF8.GetByteCount(turn.Reply);
            if (size > byteBudget) break; // Send a contiguous recent history, never disconnected old turns.
            byteBudget -= size;
            result.Insert(0, new Turn { Question = turn.Question, Reply = turn.Reply });
        }
        return result;
    }
    internal static string Hash(string value)
    {
        using var sha = SHA256.Create();
        return string.Concat(sha.ComputeHash(Encoding.UTF8.GetBytes(value)).Select(b => b.ToString("x2")));
    }
}

public sealed class ConversationStore
{
    private sealed class Entry
    {
        internal Conversation Data = new Conversation();
        internal bool Busy;
    }
    private readonly object gate = new object();
    private readonly Dictionary<string, Entry> entries = new Dictionary<string, Entry>(StringComparer.Ordinal);
    private readonly Settings settings;
    private readonly string directory;

    public ConversationStore(Settings settings)
    {
        this.settings = settings;
        directory = Path.Combine(settings.DataDirectory, "worlds", TextLimits.Hash(settings.WorldId), "conversations");
        Directory.CreateDirectory(directory);
        var files = Directory.GetFiles(directory, "*.json");
        if (files.Length > settings.MaxConversations)
            throw new AiException(500, "Existing memory exceeds MaxConversations. Raise the limit before starting.");
        foreach (string file in files)
        {
            try
            {
                if (new FileInfo(file).Length > 2 * 1024 * 1024) throw new InvalidDataException();
                var conversation = JsonConvert.DeserializeObject<Conversation>(File.ReadAllText(file, Encoding.UTF8));
                if (conversation == null || conversation.Id == null ||
                    !Regex.IsMatch(conversation.Id, "^[a-zA-Z0-9][a-zA-Z0-9_.:-]{0,63}$") ||
                    conversation.Turns == null || conversation.Turns.Count > 50 ||
                    Path.GetFileNameWithoutExtension(file) != TextLimits.Hash(conversation.Id) ||
                    conversation.Turns.Any(t => t == null || t.Question == null || t.Reply == null ||
                                                t.Question.Length > 8000 || t.Reply.Length > 16000))
                    throw new InvalidDataException();
                conversation.Turns = conversation.Turns.Skip(Math.Max(0, conversation.Turns.Count - settings.HistoryTurns)).ToList();
                entries.Add(conversation.Id, new Entry { Data = conversation });
            }
            catch { throw new AiException(500, "A conversation file is invalid. Restore it from backup or move it out of the conversations folder."); }
        }
    }
    public Lease Reserve(string id)
    {
        lock (gate)
        {
            bool created = false;
            if (!entries.TryGetValue(id, out var entry))
            {
                if (entries.Count >= settings.MaxConversations)
                    throw new AiException(409, "Conversation memory is full. Delete a conversation or use remember=false.");
                entry = new Entry { Data = new Conversation { Id = id } };
                entries.Add(id, entry);
                created = true;
            }
            if (entry.Busy) throw new AiException(409, "This conversation already has a pending request.");
            entry.Busy = true;
            return new Lease(this, id, TextLimits.Context(entry.Data.Turns, settings.ContextUtf8Bytes), created);
        }
    }
    public object[] List()
    {
        lock (gate) return entries.Select(p => (object)new { id = p.Key, turns = p.Value.Data.Turns.Count, busy = p.Value.Busy }).ToArray();
    }
    public void Delete(string id)
    {
        lock (gate)
        {
            if (!entries.TryGetValue(id, out var entry)) return;
            if (entry.Busy) throw new AiException(409, "Cannot delete a conversation with a pending request.");
            try { File.Delete(Path.Combine(directory, TextLimits.Hash(id) + ".json")); }
            catch { throw new AiException(500, "Conversation could not be deleted from disk."); }
            entries.Remove(id);
        }
    }
    private void Append(string id, string question, string reply)
    {
        lock (gate)
        {
            var entry = entries[id];
            var turns = entry.Data.Turns.Concat(new[] { new Turn { Question = question, Reply = reply } }).ToList();
            turns = turns.Skip(Math.Max(0, turns.Count - settings.HistoryTurns)).ToList();
            var updated = new Conversation { Id = id, Turns = turns };
            string path = Path.Combine(directory, TextLimits.Hash(id) + ".json");
            string temp = path + "." + Guid.NewGuid().ToString("N") + ".tmp";
            try
            {
                using (var stream = new FileStream(temp, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                {
                    byte[] data = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(updated));
                    stream.Write(data, 0, data.Length);
                    stream.Flush(true);
                }
                if (File.Exists(path)) File.Replace(temp, path, null);
                else File.Move(temp, path);
                entry.Data = updated;
            }
            catch { throw new AiException(500, "Text is ready, but conversation memory could not be saved."); }
            finally { try { if (File.Exists(temp)) File.Delete(temp); } catch { } }
        }
    }
    public sealed class Lease : IDisposable
    {
        private ConversationStore? owner;
        private readonly string id;
        private readonly bool created;
        public IReadOnlyList<Turn> Context { get; }
        internal Lease(ConversationStore owner, string id, List<Turn> context, bool created)
        { this.owner = owner; this.id = id; this.created = created; Context = context; }
        public void Append(string question, string reply) => owner!.Append(id, question, reply);
        public void Dispose()
        {
            var store = owner;
            if (store == null) return;
            owner = null;
            lock (store.gate)
            {
                var entry = store.entries[id];
                entry.Busy = false;
                if (created && entry.Data.Turns.Count == 0) store.entries.Remove(id);
            }
        }
    }
}

public sealed class AudioFile
{
    public string Path { get; set; } = "";
    public string Url { get; set; } = "";
    public DateTime ExpiresUtc { get; set; }
}
public sealed class AudioStore
{
    private readonly object gate = new object();
    private readonly Settings settings;
    private readonly string directory;
    public AudioStore(Settings settings)
    {
        this.settings = settings;
        directory = Path.Combine(settings.DataDirectory, "audio");
        Directory.CreateDirectory(directory);
        Cleanup();
    }
    public void Cleanup()
    {
        lock (gate)
        {
            foreach (string file in Directory.GetFiles(directory, "*.wav"))
            {
                if (File.GetLastWriteTimeUtc(file).AddSeconds(settings.AudioTtlSeconds) < DateTime.UtcNow)
                    try { File.Delete(file); } catch { }
            }
        }
    }
    public AudioFile Save(byte[] wav)
    {
        lock (gate)
        {
            Cleanup();
            if (wav.Length > settings.MaxAudioFileMegabytes * 1024 * 1024) throw new AiException(413, "Generated audio exceeds the file limit.");
            long used = Directory.GetFiles(directory, "*.wav").Sum(p => new FileInfo(p).Length);
            if (used + wav.Length > settings.MaxAudioMegabytes * 1024L * 1024)
                throw new AiException(507, "Audio cache is full; text remains available.");
            string name = Guid.NewGuid().ToString("N") + ".wav";
            string path = Path.Combine(directory, name);
            File.WriteAllBytes(path, wav);
            DateTime expiry = File.GetLastWriteTimeUtc(path).AddSeconds(settings.AudioTtlSeconds);
            return new AudioFile { Path = path, Url = settings.PublicMediaBaseUrl.TrimEnd('/') + "/audio/" + name, ExpiresUtc = expiry };
        }
    }
    public FileStream Open(string name)
    {
        lock (gate)
        {
            if (!Regex.IsMatch(name, "^[a-f0-9]{32}\\.wav$")) throw new AiException(404, "Audio not found.");
            string path = Path.Combine(directory, name);
            if (!File.Exists(path) || File.GetLastWriteTimeUtc(path).AddSeconds(settings.AudioTtlSeconds) < DateTime.UtcNow)
                throw new AiException(404, "Audio not found or expired.");
            return new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read | FileShare.Delete);
        }
    }
}

public static class WaveAudio
{
    public static byte[] FromPcm16(byte[] pcm, int rate = 24000)
    {
        if (pcm.Length == 0 || pcm.Length % 2 != 0 || rate < 8000 || rate > 48000)
            throw new AiException(502, "TTS returned invalid PCM audio.");
        using var stream = new MemoryStream();
        using var writer = new BinaryWriter(stream, Encoding.ASCII, true);
        writer.Write(Encoding.ASCII.GetBytes("RIFF")); writer.Write(pcm.Length + 36);
        writer.Write(Encoding.ASCII.GetBytes("WAVEfmt ")); writer.Write(16);
        writer.Write((short)1); writer.Write((short)1); writer.Write(rate); writer.Write(rate * 2);
        writer.Write((short)2); writer.Write((short)16);
        writer.Write(Encoding.ASCII.GetBytes("data")); writer.Write(pcm.Length); writer.Write(pcm);
        return stream.ToArray();
    }
    public static byte[] ValidateWav(byte[] wav)
    {
        if (wav.Length < 44 || Encoding.ASCII.GetString(wav, 0, 4) != "RIFF" || Encoding.ASCII.GetString(wav, 8, 4) != "WAVE")
            throw new AiException(502, "TTS returned invalid WAV audio.");
        bool format = false, data = false;
        int offset = 12;
        while (offset <= wav.Length - 8)
        {
            string chunk = Encoding.ASCII.GetString(wav, offset, 4);
            uint size = BitConverter.ToUInt32(wav, offset + 4);
            if (size > wav.Length - offset - 8) throw new AiException(502, "TTS returned truncated WAV audio.");
            if (chunk == "fmt ")
            {
                if (size < 16 || BitConverter.ToUInt16(wav, offset + 8) != 1 ||
                    BitConverter.ToUInt16(wav, offset + 10) != 1 || BitConverter.ToUInt16(wav, offset + 22) != 16)
                    throw new AiException(502, "TTS must return mono PCM16 WAV.");
                uint rate = BitConverter.ToUInt32(wav, offset + 12);
                if (rate < 8000 || rate > 48000) throw new AiException(502, "Unsupported WAV sample rate.");
                format = true;
            }
            if (chunk == "data") data = size > 0 && size % 2 == 0;
            offset += 8 + (int)size + ((int)size % 2);
        }
        if (!format || !data) throw new AiException(502, "WAV format or samples missing.");
        return wav;
    }
}
