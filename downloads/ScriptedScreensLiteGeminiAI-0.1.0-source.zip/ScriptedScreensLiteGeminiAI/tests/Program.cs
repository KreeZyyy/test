using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;
using ScriptedScreensLiteGeminiAI;

internal static class Program
{
    private static int passed;
    private static void Check(bool result, string name)
    { if (!result) throw new Exception("FAILED: " + name); passed++; Console.WriteLine("PASS " + name); }
    private static void Fails(Action action, int status, string name)
    {
        try { action(); throw new Exception("No expected error: " + name); }
        catch (AiException ex) { Check(ex.Status == status, name); }
    }
    private static Settings Config(string directory) => new Settings {
        DataDirectory = directory, BridgeToken = new string('t',32), ApiKey = "FAKE_TEST_KEY",
        CooldownSeconds = 0, WorldId = "test-world"
    };
    private static AskRequest Ask(string source = "123", string? conversation = null) => new AskRequest {
        Question = "Ahoj, jak se máš?", SourceRefId = source, ConversationId = conversation, Speak = false
    };
    private static async Task<JObject> Wait(JobService jobs, string id)
    {
        for (int i=0; i<500; i++)
        {
            JObject job = jobs.Get(id);
            if ((string?)job["state"] == "done" || (string?)job["state"] == "error") return job;
            await Task.Delay(10);
        }
        throw new Exception("Job did not complete");
    }
    private sealed class MockProvider : IAiProvider
    {
        public bool VoiceFailure;
        public bool TextFailure;
        public TaskCompletionSource<bool>? Release;
        public List<Turn> LastContext = new List<Turn>();
        public int Calls;
        public int Speaking;
        public async Task<string> TextAsync(AskRequest request, IReadOnlyList<Turn> context, CancellationToken cancellation)
        {
            Interlocked.Increment(ref Calls);
            if (Release != null) await Release.Task.WaitAsync(cancellation);
            if (TextFailure) throw new InvalidOperationException("SECRET_KEY_RAW_EXCEPTION");
            LastContext = context.ToList();
            return "Ahoj, jsem připraven.";
        }
        public Task<byte[]> SpeechAsync(string text, AskRequest request, CancellationToken cancellation)
        {
            Speaking++;
            if (VoiceFailure) throw new InvalidOperationException("SECRET_KEY_RAW_EXCEPTION");
            return Task.FromResult(WaveAudio.FromPcm16(new byte[] {0,0,1,0,2,0,3,0}));
        }
    }
    private sealed class CaptureHandler : HttpMessageHandler
    {
        public Func<HttpRequestMessage, string, string> Reply = (_,_) => "{}";
        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            string body = await request.Content!.ReadAsStringAsync(cancellationToken);
            return new HttpResponseMessage(HttpStatusCode.OK) { Content = new StringContent(Reply(request, body)) };
        }
    }
    private static int FreePort()
    {
        var listener = new System.Net.Sockets.TcpListener(IPAddress.Loopback,0);
        listener.Start(); int result = ((IPEndPoint)listener.LocalEndpoint).Port; listener.Stop(); return result;
    }
    private static async Task Main()
    {
        string directory = Path.Combine(Path.GetTempPath(), "geminiai-tests-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(directory);
        try
        {
            var s = Config(directory);
            s.Validate(); Check(true, "default Lite settings validate");
            var invalid = Config(directory); invalid.ApiPort = invalid.MediaPort;
            Fails(invalid.Validate,500,"ports cannot overlap");
            var request = Ask(); request.Validate(s); Check(true,"valid ReferenceId and preferences");
            var wrong = Ask(); wrong.SourceRefId = "../123";
            Fails(()=>wrong.Validate(s),400,"reject malformed origin");
            wrong = Ask(); wrong.ConversationId = "../../world";
            Fails(()=>wrong.Validate(s),400,"reject conversation path injection");
            wrong = Ask(); wrong.Model = "expensive-model";
            Fails(()=>wrong.Validate(s),400,"model overrides require administrator setting");
            wrong = Ask(); wrong.MaxOutputTokens = s.MaxOutputTokens+1;
            Fails(()=>wrong.Validate(s),400,"Lua cannot raise output cap");
            wrong = Ask(); wrong.Voice = "unknown";
            Fails(()=>wrong.Validate(s),400,"voice allowlist enforced");
            Check(TextLimits.Cut("A😀B",2)=="A","truncation never splits a surrogate pair");
            var context = TextLimits.Context(new[] {
                new Turn { Question="old",Reply="old" },new Turn { Question="čč",Reply="žž" },new Turn { Question="new",Reply="new" }},10);
            Check(context.Count==1 && context[0].Question=="new","context budget includes UTF-8 and preserves recent sequence");
            s.MaxConversations=2;
            var memory = new ConversationStore(s);
            using (var lease=memory.Reserve("device:123"))
            {
                Fails(()=>memory.Reserve("device:123"),409,"parallel same-conversation requests rejected");
                Fails(()=>memory.Delete("device:123"),409,"reset cannot race an active conversation");
                lease.Append("otázka","odpověď");
            }
            using (var lease=memory.Reserve("second")) lease.Append("another","reply");
            Fails(()=>memory.Reserve("third"),409,"25-style memory cap never evicts silently");
            var restored = new ConversationStore(s);
            using (var lease=restored.Reserve("device:123")) Check(lease.Context[0].Reply=="odpověď","history survives restart");
            restored.Delete("second");
            using (restored.Reserve("failed-new")) { }
            Check(restored.List().Length==1,"failed new conversations free their slot");
            var otherWorld = Config(directory); otherWorld.WorldId="other-world";
            Check(new ConversationStore(otherWorld).List().Length==0,"world memory namespaces do not mix");
            byte[] pcm={0,0,1,0,255,127,0,128};
            byte[] wav=WaveAudio.FromPcm16(pcm);
            Check(wav.Length==pcm.Length+44 && BitConverter.ToInt32(wav,24)==24000,"PCM16 gets a mono 24k WAV header");
            Check(WaveAudio.ValidateWav(wav)==wav,"valid WAV accepted");
            Fails(()=>WaveAudio.FromPcm16(new byte[]{0}),502,"odd PCM rejected");
            var badWav=(byte[])wav.Clone(); badWav[20]=3;
            Fails(()=>WaveAudio.ValidateWav(badWav),502,"non-PCM WAV rejected");
            var audio = new AudioStore(s);
            var clip=audio.Save(wav);
            Check(clip.Url.StartsWith(s.PublicMediaBaseUrl+"/audio/") && !clip.Url.Contains(s.BridgeToken),"media URL has independent capability, no bridge token");
            using (var file=audio.Open(Path.GetFileName(clip.Path))) Check(file.Length==wav.Length,"audio file available");
            Fails(()=>audio.Open("../../history.json"),404,"media path traversal rejected");
            File.SetLastWriteTimeUtc(clip.Path,DateTime.UtcNow.AddSeconds(-s.AudioTtlSeconds-1));
            Fails(()=>audio.Open(Path.GetFileName(clip.Path)),404,"expired audio cannot be downloaded");
            audio.Cleanup(); Check(!File.Exists(clip.Path),"expired audio removed from disk");
            var capture=new CaptureHandler(); using var http=new HttpClient(capture);
            using var google = new GeminiClient(s,http);
            capture.Reply=(message,body)=> {
                Check(message.RequestUri!.AbsoluteUri.EndsWith("gemini-3.1-flash-lite:generateContent"),"text REST endpoint uses configured model");
                Check(message.Headers.GetValues("x-goog-api-key").Single()==s.ApiKey && !message.RequestUri.Query.Contains(s.ApiKey),"Google key is a header, not URL");
                var payload=JObject.Parse(body);
                Check((string?)payload["contents"]![1]!["role"]=="model" && (string?)payload["contents"]![2]!["parts"]![0]!["text"]==request.Question,"conversation roles and current question serialized");
                return "{\"candidates\":[{\"content\":{\"parts\":[{\"thought\":true,\"text\":\"private thought\"},{\"text\":\"Ahoj\"}]}}]}";
            };
            Check(await google.TextAsync(request,new[]{new Turn {Question="old",Reply="reply"}},CancellationToken.None)=="Ahoj","thought text excluded from reply");
            request.Voice="Charon"; request.SpeechStyle="Czech, friendly";
            capture.Reply=(message,body)=> {
                var payload=JObject.Parse(body);
                Check(message.RequestUri!.AbsolutePath.EndsWith("/interactions") && (bool?)payload["store"]==false,"TTS uses stateless Interactions API");
                Check((string?)payload["generation_config"]!["speech_config"]![0]!["voice"]=="Charon" &&
                      (string?)payload["input"]![0]!["content"]![0]!["text"]=="Text k přečtení", "Lua voice and verbatim text passed to TTS");
                return new JObject { ["steps"]=new JArray(new JObject { ["type"]="model_output",["content"]=new JArray(new JObject {
                    ["type"]="audio",["mime_type"]="audio/wav",["data"]=Convert.ToBase64String(wav)})}) }.ToString();
            };
            Check((await google.SpeechAsync("Text k přečtení",request,CancellationToken.None)).SequenceEqual(wav),"Interactions audio decoded into WAV");
            s.TtsApi="generateContent"; s.TtsModel="gemini-3.1-flash-tts-preview";
            capture.Reply=(_,body)=> {
                var payload=JObject.Parse(body);
                Check((string?)payload["generationConfig"]!["responseModalities"]![0]=="AUDIO","legacy TTS audio modality selected");
                return new JObject { ["candidates"]=new JArray(new JObject {["content"]=new JObject {["parts"]=new JArray(new JObject {
                    ["inlineData"]=new JObject {["mimeType"]="audio/L16;codec=pcm;rate=24000",["data"]=Convert.ToBase64String(pcm)}})}})}.ToString();
            };
            Check((await google.SpeechAsync("Text",request,CancellationToken.None)).SequenceEqual(wav),"legacy raw PCM converted to WAV");
            var serviceConfig=Config(Path.Combine(directory,"jobs"));
            var provider=new MockProvider();
            var jobMemory=new ConversationStore(serviceConfig); var jobAudio=new AudioStore(serviceConfig);
            using var jobs=new JobService(serviceConfig,provider,jobMemory,jobAudio);
            var voiced=Ask(); voiced.Speak=true;
            var done=await Wait(jobs,jobs.Submit(voiced));
            Check((string?)done["state"]=="done" && (string?)done["source_ref_id"]=="123" && (string?)done["audio_url"]!=null,"job returns text and audio with original ReferenceId");
            await Wait(jobs,jobs.Submit(Ask()));
            Check(provider.LastContext.Count==1,"next job receives prior context");
            var noMemory=Ask("456"); noMemory.Remember=false;
            await Wait(jobs,jobs.Submit(noMemory));
            Check(provider.LastContext.Count==0 && ((object[])jobs.ListConversations()).Length==1,"remember=false stores no conversation");
            provider.VoiceFailure=true;
            done=await Wait(jobs,jobs.Submit(voiced));
            Check((string?)done["state"]=="done" && (string?)done["text"]!=null && (string?)done["audio_url"]==null &&
                  !done.ToString().Contains("SECRET_KEY"),"voice failures retain text and sanitize raw errors");
            provider.TextFailure=true;
            done=await Wait(jobs,jobs.Submit(Ask("789")));
            Check((string?)done["state"]=="error" && !done.ToString().Contains("SECRET_KEY"),"text errors sanitized");
            provider.TextFailure=false;
            provider.Release=new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);
            var blocking=Ask("999"); string blocked=jobs.Submit(blocking);
            Fails(()=>jobs.Submit(blocking),409,"pending request owns conversation lease");
            provider.Release.SetResult(true); await Wait(jobs,blocked); provider.Release=null;
            jobs.Reset(Ask()); Check(((object[])jobs.ListConversations()).Length==1,"reset deletes selected memory only");
            var queueConfig=Config(Path.Combine(directory,"queue")); queueConfig.MaxConcurrent=1;queueConfig.MaxPending=1;
            var queuedProvider=new MockProvider {Release=new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously)};
            using var queuedJobs=new JobService(queueConfig,queuedProvider,new ConversationStore(queueConfig),new AudioStore(queueConfig));
            string queued=queuedJobs.Submit(Ask());
            Fails(()=>queuedJobs.Submit(Ask("456")),429,"queue is bounded");
            queuedProvider.Release.SetResult(true);await Wait(queuedJobs,queued);
            var rateConfig=Config(Path.Combine(directory,"rate"));rateConfig.RequestsPerMinute=1;
            using var rateJobs=new JobService(rateConfig,new MockProvider(),new ConversationStore(rateConfig),new AudioStore(rateConfig));
            await Wait(rateJobs,rateJobs.Submit(Ask()));
            Fails(()=>rateJobs.Submit(Ask("456")),429,"shared rate cap enforced");
            serviceConfig.ApiPort=FreePort(); serviceConfig.MediaPort=FreePort();
            while(serviceConfig.MediaPort==serviceConfig.ApiPort)serviceConfig.MediaPort=FreePort();
            serviceConfig.PublicMediaBaseUrl="http://localhost:"+serviceConfig.MediaPort;
            using var apiHost=new ApiHost(serviceConfig,jobs,jobAudio);
            using var local=new HttpClient(new HttpClientHandler {UseProxy=false});
            var health=new HttpRequestMessage(HttpMethod.Get,$"http://localhost:{serviceConfig.ApiPort}/health");
            var healthResponse=await local.SendAsync(health);
            Check(healthResponse.StatusCode==HttpStatusCode.Unauthorized,"control API requires bridge token");
            health=new HttpRequestMessage(HttpMethod.Get,$"http://localhost:{serviceConfig.ApiPort}/health");
            health.Headers.Add("X-Station-Token",serviceConfig.BridgeToken);
            healthResponse=await local.SendAsync(health);
            Check(healthResponse.IsSuccessStatusCode,"authenticated loopback HTTP works");
            var fresh=jobAudio.Save(wav);
            var audioResponse=await local.GetAsync(fresh.Url);
            Check(audioResponse.IsSuccessStatusCode && (await audioResponse.Content.ReadAsByteArrayAsync()).SequenceEqual(wav),"public media serves WAV without API token");
            var rangeRequest=new HttpRequestMessage(HttpMethod.Get,fresh.Url);
            rangeRequest.Headers.Range=new System.Net.Http.Headers.RangeHeaderValue(0,3);
            var rangeResponse=await local.SendAsync(rangeRequest);
            Check(rangeResponse.StatusCode==HttpStatusCode.PartialContent && Encoding.ASCII.GetString(await rangeResponse.Content.ReadAsByteArrayAsync())=="RIFF","media byte ranges supported");
            var headResponse=await local.SendAsync(new HttpRequestMessage(HttpMethod.Head,fresh.Url));
            Check(headResponse.IsSuccessStatusCode && headResponse.Content.Headers.ContentLength==wav.Length &&
                  (await headResponse.Content.ReadAsByteArrayAsync()).Length==0,"HEAD reports length without samples");
            var apiOnMedia=await local.GetAsync($"http://localhost:{serviceConfig.MediaPort}/conversations");
            Check(apiOnMedia.StatusCode==HttpStatusCode.NotFound,"media port cannot expose chat or AI endpoints");
            var malformed=await local.PostAsync($"http://localhost:{serviceConfig.ApiPort}/ask",new StringContent("{}"));
            Check(malformed.StatusCode==HttpStatusCode.Unauthorized,"unauthenticated POST cannot create paid work");
            Console.WriteLine($"\n{passed} checks passed. No live Gemini call or key used.");
        }
        finally { try { Directory.Delete(directory,true); } catch { } }
    }
}
