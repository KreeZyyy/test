using System;using System.Collections.Generic;using System.Linq;using UnityEngine;using ModularSwitchboards;
namespace UnityEngine{
struct Vector2 {public float x,y;public Vector2(float x,float y){this.x=x;this.y=y;}public float magnitude=>MathF.Sqrt(x*x+y*y);public Vector2 normalized=>this*(1/magnitude);public static Vector2 operator+(Vector2 a,Vector2 b)=>new(a.x+b.x,a.y+b.y);public static Vector2 operator-(Vector2 a,Vector2 b)=>new(a.x-b.x,a.y-b.y);public static Vector2 operator*(Vector2 a,float b)=>new(a.x*b,a.y*b);}
struct Vector3 {public float x,y,z;public Vector3(float x,float y,float z){this.x=x;this.y=y;this.z=z;}public float sqrMagnitude=>x*x+y*y+z*z;public Vector3 normalized=>this*(1/MathF.Sqrt(sqrMagnitude));public static Vector3 up=>new(0,1,0);public static Vector3 down=>new(0,-1,0);public static Vector3 forward=>new(0,0,1);public static Vector3 back=>new(0,0,-1);public static Vector3 operator*(Vector3 a,float b)=>new(a.x*b,a.y*b,a.z*b);public static Vector3 operator-(Vector3 a,Vector3 b)=>new(a.x-b.x,a.y-b.y,a.z-b.z);public static Vector3 Cross(Vector3 a,Vector3 b)=>new(a.y*b.z-a.z*b.y,a.z*b.x-a.x*b.z,a.x*b.y-a.y*b.x);public static float Dot(Vector3 a,Vector3 b)=>a.x*b.x+a.y*b.y+a.z*b.z;}
struct Bounds{public Vector3 center,size;public Bounds(Vector3 c,Vector3 s){center=c;size=s;}}
}
static class Mathf {public const float PI=(float)Math.PI;public static float Sin(float x)=>MathF.Sin(x);public static float Cos(float x)=>MathF.Cos(x);public static float Min(float a,float b)=>Math.Min(a,b);}
class Program{static void Main(){int checks=0;foreach(float wallOffset in new[]{-.1f,0,.025f,.15f,.25f}){
var source=new[]{new Vector3(.119995f,-.035019f,.043765f),new Vector3(.119995f,-.035019f,-.020783f),new Vector3(.120010f,-.029243f,-.030782f),new Vector3(.120010f,.029243f,-.030782f),new Vector3(.119995f,.035019f,-.020783f),new Vector3(.119995f,.035019f,.043765f)};
var profiles=new[]{-.5f,0,.5f}.Select(x=>source.Select(v=>new Vector3(x+v.y,-.75f-(v.x-.258764267f),v.z-wallOffset)).ToArray()).ToArray();
            var layers=NativeLugSection.Layers(profiles);
            float wideHalf=layers.Max(layer=>layer.HalfWidth);
            float barTop=-1f*.5f+.004f,barBottom=barTop-.07f;
            float stemTop=-.116f;
            var outlines=layers.Select(layer=>MediumOutputHousing.Chamfer(MediumOutputHousing.Outline(layer.Centers,layer.Ends,layer.HalfWidth,barBottom+(wideHalf-layer.HalfWidth),barTop-(wideHalf-layer.HalfWidth),stemTop),.003f)).ToArray();
            var depths=layers.Select(layer=>layer.Depth).ToArray();
            var vertices=new List<Vector3>();var indices=new List<int>();int n=outlines[0].Count;
            for(int level=0;level<outlines.Length;level++)foreach(var v in outlines[level])vertices.Add(new Vector3(v.x,v.y,depths[level]));
            for(int level=0;level+1<outlines.Length;level++)for(int i=0;i<n;i++){int j=(i+1)%n,a=level*n+i,b=level*n+j;indices.AddRange(new[]{a,b,b+n,a,b+n,a+n});}
            for(int level=0;level<outlines.Length;level+=outlines.Length-1)
            {
                int start=vertices.Count;foreach(var v in outlines[level])vertices.Add(new Vector3(v.x,v.y,depths[level]));
                var cap=Triangulate(outlines[level]);for(int i=0;i<cap.Count;i+=3)indices.AddRange(level==0?new[]{start+cap[i],start+cap[i+2],start+cap[i+1]}:new[]{start+cap[i],start+cap[i+1],start+cap[i+2]});
            }

foreach(var ring in profiles)foreach(var contact in ring){if(!vertices.Any(v=>(v-contact).sqrMagnitude<1e-12f))throw new Exception("Generated corridor does not contain the exact native mating corner");checks++;}
foreach(var outline in new[]{outlines[0],outlines[outlines.Length-1]}){float area=0;for(int i=0;i<n;i++)area+=(outline[i].x*outline[(i+1)%n].y-outline[i].y*outline[(i+1)%n].x)*.5f;var cap=Triangulate(outline);float sum=0;for(int i=0;i<cap.Count;i+=3)sum+=Cross(outline[cap[i]],outline[cap[i+1]],outline[cap[i+2]])*.5f;if(Math.Abs(area-sum)>1e-6||area<=0)throw new Exception("cap area");}
var canonical=new Dictionary<(float,float,float),int>();var welded=new int[vertices.Count];for(int k=0;k<vertices.Count;k++){var p=vertices[k];var key=(p.x,p.y,p.z);if(!canonical.TryGetValue(key,out int id)){id=k;canonical[key]=id;}welded[k]=id;}var edges=new Dictionary<(int,int),int>();
for(int i=0;i<indices.Count;i+=3){int a=indices[i],b=indices[i+1],c=indices[i+2];var normal=Vector3.Cross(vertices[b]-vertices[a],vertices[c]-vertices[a]);if(normal.sqrMagnitude<1e-20)throw new Exception("degenerate triangle");if(i<n*12){int level=i/(n*6),edge=(i/6)%n;var u=outlines[level][edge];var v=outlines[level][(edge+1)%n];if(Vector3.Dot(normal,new Vector3(v.y-u.y,u.x-v.x,0))<=0)throw new Exception("side winding");}else if(normal.z*(i<n*12+(n-2)*3?-1:1)<=0)throw new Exception("cap winding");foreach(var e in new[]{(welded[a],welded[b]),(welded[b],welded[c]),(welded[c],welded[a])}){var key=e.Item1<e.Item2?e:(e.Item2,e.Item1);edges.TryGetValue(key,out int k);edges[key]=k+1;}checks++;}if(edges.Any(e=>e.Value!=2))throw new Exception("nonmanifold");
if(Environment.GetEnvironmentVariable("NATIVE_CORRIDOR_EXPORT")is string file&&wallOffset==0)System.IO.File.WriteAllText(file,System.Text.Json.JsonSerializer.Serialize(new{vertices=vertices.Select(v=>new[]{v.x,v.y,v.z}),triangles=indices,interfaces=profiles.Select(r=>r.Select(v=>new[]{v.x,v.y,v.z}))}));
}Console.WriteLine($"Exact native output interfaces: {checks} corner/triangle checks across five wall offsets, native seam vertices, watertight edges, winding and cap area passed.");}
        private static List<Vector2> ChamferOutline(Vector2[] corners,float radius)
        {
            var result=new List<Vector2>();
            for(int i=0;i<corners.Length;i++)
            {
                var p=corners[i];var before=corners[(i+corners.Length-1)%corners.Length];var after=corners[(i+1)%corners.Length];
                float r=Mathf.Min(radius,Mathf.Min((before-p).magnitude,(after-p).magnitude)*.25f);
                var a=p+(before-p).normalized*r;var b=p+(after-p).normalized*r;
                result.Add(a);result.Add(b);
            }
            return result;
        }
        private static float Cross(Vector2 a,Vector2 b,Vector2 c)=>(b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x);
        private static List<int> Triangulate(List<Vector2> p)
        {
            var remaining=Enumerable.Range(0,p.Count).ToList();var result=new List<int>();int guard=p.Count*p.Count;
            while(remaining.Count>3 && guard-->0)
            {
                bool clipped=false;
                for(int i=0;i<remaining.Count;i++)
                {
                    int a=remaining[(i+remaining.Count-1)%remaining.Count],b=remaining[i],c=remaining[(i+1)%remaining.Count];
                    if(Cross(p[a],p[b],p[c])<=1e-10f)continue;
                    bool occupied=remaining.Any(v=>v!=a&&v!=b&&v!=c&&Cross(p[a],p[b],p[v])>=-1e-10f&&Cross(p[b],p[c],p[v])>=-1e-10f&&Cross(p[c],p[a],p[v])>=-1e-10f);
                    if(occupied)continue;
                    result.AddRange(new[]{a,b,c});remaining.RemoveAt(i);clipped=true;break;
                }
                if(!clipped)throw new InvalidOperationException("Cannot triangulate output housing.");
            }
            if(remaining.Count!=3)throw new InvalidOperationException("Incomplete output housing cap.");
            result.AddRange(remaining);return result;
        }
}
