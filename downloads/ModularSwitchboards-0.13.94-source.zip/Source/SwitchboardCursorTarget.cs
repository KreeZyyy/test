using System.Collections.Generic;
using System.Linq;
using Assets.Scripts;
using Assets.Scripts.Inventory;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Items;
using UnityEngine;
namespace ModularSwitchboards
{
    // Native RaycastHit.transform can be the cabinet's rigidbody transform even
    // when the ray hit a separately mounted child Thing. Resolve the hit collider.
    internal static class SwitchboardCursorTarget
    {
        internal static void BeforeRaycast(){MountPlacement.BeforeRaycast();DoorLabelPlacementSurface.RefreshAll();}
        internal static void AfterRaycast(CursorManager __instance)
        {
            MountPlacement.AfterRaycast();
            MountBoardResolver.Resolve(__instance);
            var hit=__instance.CursorTargetCollider;
            if(hit==null)return;
            var target=hit.GetComponentInParent<Thing>();
            if(target is DoorLabel||target is SwitchboardLabel||target is DinBreaker part&&part.IsDoorPart)
            {
                if(!target.IsCursor&&target.GetComponentInParent<SwitchboardCabinet>()!=null)
                    __instance.FoundThing=target;
            }
        }
    }
    public sealed class DoorLabelPlacementSurface:MonoBehaviour
    {
        private static readonly HashSet<DoorLabelPlacementSurface> Live=new HashSet<DoorLabelPlacementSurface>();
        private void OnEnable()=>Live.Add(this);
        private void OnDisable()=>Live.Remove(this);
        private static void Apply(BoxCollider collider,bool enabled){if(collider!=null)collider.enabled=enabled;}
        internal static void RefreshAll()
        {

            foreach(var view in Live)
            {
                if(view==null)continue;
                var host=view.GetComponent<SwitchboardCabinet>();if(host==null)continue;
                RailPlacementSurfaces.Refresh(host);
                Apply(host.DoorLabelSurface,!host.IsCursor&&host.IsStructureCompleted&&BoardPlacementInput.Wants(PlacementSurfaceKind.DoorLabel));Apply(host.RightDoorLabelSurface,!host.IsCursor&&host.IsStructureCompleted&&BoardPlacementInput.Wants(PlacementSurfaceKind.DoorLabel));
                if(host.CoverBoard!=null)foreach(var cover in host.CoverBoard.Structures.OfType<InnerCoverModule>())
                {
                    bool placing=host.IsOpen&&BoardPlacementInput.Wants(PlacementSurfaceKind.DinLabel);
                    Apply(cover.LabelSurface,placing);Apply(cover.LowerLabelSurface,placing);Apply(cover.MiddleLabelSurface,placing&&CabinetShape.Medium(host.PrefabName));
                }
            }
        }
    }
}
