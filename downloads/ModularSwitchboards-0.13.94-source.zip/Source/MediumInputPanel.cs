using System.Collections.Generic;
using Assets.Scripts.Objects;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class MediumInputPanel
    {
        internal static void Install(SwitchboardCabinet cabinet)
        {
            var shell=cabinet.transform.Find("SwitchboardModel/CompletedShell");
            var root=new GameObject(OvenInputPanel.RootName){layer=cabinet.gameObject.layer};root.transform.SetParent(shell,false);
            var socket=NativeCableLayout.ReadForBody(CabinetLayout.InputCell(cabinet.PrefabName)-Vector3.up*SmallGrid.SmallGridSize,Vector3.up);
            var data=root.AddComponent<OvenInputPanelMetadata>();data.SocketPoint=socket.Point;data.SocketAxis=socket.Forward;
            data.CableCell=socket.CableCell.ToVector3();data.BodyCell=socket.BodyCell.ToVector3();data.VisualAnchorPoint=socket.ContactPoint;
            var front=cabinet.transform.InverseTransformDirection(shell.TransformDirection(Vector3.forward)).normalized;
            root.transform.rotation=cabinet.transform.rotation*Quaternion.LookRotation(socket.Forward,front);
            data.NativeStyleCollider=ExternalCablePorts.AttachNativeOutput(cabinet,root.transform);
            Align(cabinet);CabinetModel.SetBounds(cabinet);
        }
        internal static void Align(Structure cabinet)
        {
            var shell=cabinet.transform.Find("SwitchboardModel/CompletedShell");var panel=shell.Find(OvenInputPanel.RootName);if(panel==null)return;
            var data=panel.GetComponent<OvenInputPanelMetadata>();if(data==null)return;
            panel.position=cabinet.transform.TransformPoint(data.VisualAnchorPoint);OvenInputSupport.Fit(cabinet);
        }
    }
}
