using System;
using System.Collections.Generic;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class NativeMeshCrop
    {
        private struct Vertex {internal Vector3 P;internal Vector2 U;internal Vertex(Vector3 p,Vector2 u){P=p;U=u;}}
        internal static Mesh Outside(Mesh source,Bounds region,string name)=>Read(source,Matrix4x4.identity,region,name,null,true);
        internal static Mesh Read(Mesh source,Matrix4x4 frame,Bounds region,string name,Func<Vector3,Vector3,Vector3,bool> keepTriangle=null,bool outside=false)
        {
            CabinetGeometry.ReadNativeMesh(source,out var points,out var uv,out var triangles);
            var vertices=new List<Vector3>();var texcoords=new List<Vector2>();var subs=new List<int>[triangles.Length];
            for(int s=0;s<triangles.Length;s++)
            {
                subs[s]=new List<int>();
                for(int t=0;t<triangles[s].Length;t+=3)
                {
                    var polygon=new List<Vertex>();
                    for(int j=0;j<3;j++){int id=triangles[s][t+j];polygon.Add(new Vertex(frame.MultiplyPoint3x4(points[id]),uv[id]));}
                    if(keepTriangle!=null&&!keepTriangle(polygon[0].P,polygon[1].P,polygon[2].P))continue;
                    for(int axis=0;axis<3&&polygon.Count>0;axis++)
                    {
                        if(outside)Emit(Clip(polygon,axis,region.min[axis],false,true),vertices,texcoords,subs[s],frame.determinant<0);
                        polygon=Clip(polygon,axis,region.min[axis],true);
                        if(outside)Emit(Clip(polygon,axis,region.max[axis],true,true),vertices,texcoords,subs[s],frame.determinant<0);
                        polygon=Clip(polygon,axis,region.max[axis],false);
                    }
                    if(!outside)Emit(polygon,vertices,texcoords,subs[s],frame.determinant<0);
                }
            }
            if(vertices.Count==0)return null;
            var mesh=new Mesh{name=name};if(vertices.Count>65535)mesh.indexFormat=UnityEngine.Rendering.IndexFormat.UInt32;
            mesh.SetVertices(vertices);mesh.SetUVs(0,texcoords);mesh.subMeshCount=subs.Length;
            for(int s=0;s<subs.Length;s++)mesh.SetTriangles(subs[s],s);
            mesh.RecalculateNormals();mesh.RecalculateTangents();mesh.RecalculateBounds();return mesh;
        }
        private static void Emit(List<Vertex> polygon,List<Vector3> vertices,List<Vector2> uv,List<int> indices,bool mirrored)
        {
            for(int j=1;j+1<polygon.Count;j++)
            {
                var a=polygon[0];var b=polygon[j];var c=polygon[j+1];
                if(Vector3.Cross(b.P-a.P,c.P-a.P).sqrMagnitude<1e-16f)continue;
                int offset=vertices.Count;foreach(var v in new[]{a,b,c}){vertices.Add(v.P);uv.Add(v.U);}
                indices.Add(offset);indices.Add(offset+(mirrored?2:1));indices.Add(offset+(mirrored?1:2));
            }
        }
        private static List<Vertex> Clip(List<Vertex> input,int axis,float plane,bool above,bool strict=false)
        {
            var result=new List<Vertex>();if(input.Count==0)return result;
            Func<float,bool> inside=d=>above?(strict?d>0:d>=0):(strict?d<0:d<=0);
            var previous=input[input.Count-1];float pd=previous.P[axis]-plane;bool pin=inside(pd);
            foreach(var current in input)
            {
                float cd=current.P[axis]-plane;bool cin=inside(cd);
                if(pin!=cin){float t=pd/(pd-cd);result.Add(new Vertex(previous.P+(current.P-previous.P)*t,previous.U+(current.U-previous.U)*t));}
                if(cin)result.Add(current);previous=current;pd=cd;pin=cin;
            }
            return result;
        }
    }
}
