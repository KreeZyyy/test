using Assets.Scripts.Objects.Electrical;
using HarmonyLib;
namespace ModularSwitchboards
{
    internal static class SmartNativeDisplayText
    {
        private static readonly System.Reflection.FieldInfo DisplayString=AccessTools.Field(typeof(LogicDisplay),"_displayString");
        // Native OnSettingChanged / mode updates format this before the Smart
        // restores its status surface. Reuse the game's exact formats and units.
        internal static string Read(LogicDisplay display)
            =>DisplayString?.GetValue(display) is char[] text?new string(text):null;
    }
}
