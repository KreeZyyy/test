using System.Collections.Generic;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Objects;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class DinSmartModel
    {
        internal static void Install(DinBreaker module)
        {
            var model=module.transform.Find("DinBreakerModel");
            var mesh=DinBreakerModel.Build(DinSmartLayout.Width,DinSmartLayout.CenterX,plain:true);
            model.GetComponent<MeshFilter>().sharedMesh=mesh;
            var hit=model.GetComponent<BoxCollider>();hit.center=mesh.bounds.center;hit.size=mesh.bounds.size;
            var view=module.GetComponent<BreakerSwitchView>();if(view!=null)Object.DestroyImmediate(view);
            foreach(string name in new[]{"BreakerLever","BreakerControl","BreakerIndicator"})
            {
                var child=model.Find(name);if(child!=null)Object.DestroyImmediate(child.gameObject);
            }
            module.Interactables=new List<Interactable>();module.HasOnOffState=false;
            module.BuildStates[0].Interactables=module.Interactables;
            module.BuildStates[0].Colliders=new List<Collider>{hit};
            var bounds=mesh.bounds;
            var scale=DinBreakerModel.VisualScale;
            module.Bounds=new Bounds(Vector3.Scale(bounds.center,scale),Vector3.Scale(bounds.size,scale));
            module.GridBounds=new GridBounds(module);module.SurfaceArea=.016f*DinSmartLayout.Slots;
            module.Thumbnail=CabinetIcons.Get("DinSmart");module.BuildStates[0].Thumbnail=module.Thumbnail;
            // Final blueprint is regenerated after removing the complete switch assembly.
            SmartNativeReferences.Capture();
        }
    }
}
