using System.Collections.Generic;
using Assets.Scripts.Objects.Pipes;
using Assets.Scripts.Objects.Electrical;
namespace ModularSwitchboards
{
    internal static class SmartComputerDevices
    {
        internal static SmartModule Module(ICircuitHolder holder)
        {
            if(holder is SmartModule direct)return direct;
            try{return holder?.GetLogicableFromIndex(int.MaxValue) as SmartModule;}catch{return null;}
        }
        internal static bool SameModule(ICircuitHolder a,ICircuitHolder b)
        {var first=Module(a);var second=Module(b);return first!=null&&second!=null&&(ReferenceEquals(first,second)||first.ReferenceId!=0&&first.ReferenceId==second.ReferenceId);}
        private static bool Invalid(SmartModule smart)=>smart.IsCursor||smart.IsBeingDestroyed||smart.ReferenceId==0||smart.Cabinet==null||!smart.gameObject.activeInHierarchy;
        internal static void FilterLuaHolders(List<ICircuitHolder> holders,List<string> names)
        {
            if(holders==null||names==null||holders.Count!=names.Count)return;
            var instances=new HashSet<SmartModule>();var ids=new HashSet<long>();
            for(int i=0;i<holders.Count;i++)
                if(Module(holders[i]) is SmartModule smart&&(Invalid(smart)||SmartDeviceIdentity.Duplicate(smart,smart.ReferenceId,instances,ids)))
                {holders.RemoveAt(i);names.RemoveAt(i);i--;}
        }
        internal static void Filter(ref List<ILogicable> __result)
        {
            if(__result==null)return;
            var instances=new HashSet<SmartModule>();var ids=new HashSet<long>();
            __result.RemoveAll(item=>item is SmartModule smart&&(Invalid(smart)||SmartDeviceIdentity.Duplicate(smart,smart.ReferenceId,instances,ids)));
        }
    }
}
