using System;
using System.Reflection;
using System.Collections.Generic;
using Assets.Scripts.Objects;
using UnityEngine;

namespace ModularSwitchboards
{
    internal static class SwitchboardPrefabs
    {
        private static readonly HashSet<Thing> Replacing = new HashSet<Thing>();
        internal static bool AllowNativeDestroy(Thing __instance) => !Replacing.Contains(__instance);
        internal static T ReplaceComponent<T>(Structure original) where T:Structure
        {
            var replacement=original.gameObject.AddComponent<T>();
            // Copy Unity-serialized prefab data only. Runtime caches must belong to the new instance.
            for(var type=typeof(T).BaseType;type!=null && type!=typeof(MonoBehaviour);type=type.BaseType)
            {
                if(!type.IsInstanceOfType(original))continue;
                foreach(var field in type.GetFields(BindingFlags.Instance|BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.DeclaredOnly))
                {
                    if(field.IsInitOnly || field.IsNotSerialized || (!field.IsPublic && !field.IsDefined(typeof(SerializeField),true)))continue;
                    var value=field.GetValue(original);
                    field.SetValue(replacement,ReferenceEquals(value,original)?replacement:value);
                }
            }
            replacement.ThingTransform=replacement.transform;
            foreach(var interaction in replacement.Interactables) if(interaction!=null)interaction.Parent=replacement;
            foreach(var state in replacement.BuildStates)
                foreach(var interaction in state.Interactables) if(interaction!=null)interaction.Parent=replacement;
            PrefabAudioOwner.Rebind(replacement);
            // Remove stock animation scripts which referenced the replaced native component.
            foreach(var script in original.GetComponentsInChildren<MonoBehaviour>(true))
                if(script!=replacement && script!=original)UnityEngine.Object.DestroyImmediate(script);
            // Native Thing.OnDestroy deletes every child; keep the transferred hierarchy intact.
            Replacing.Add(original);
            try { UnityEngine.Object.DestroyImmediate(original); }
            finally { Replacing.Remove(original); }
            return replacement;
        }
    }
}
