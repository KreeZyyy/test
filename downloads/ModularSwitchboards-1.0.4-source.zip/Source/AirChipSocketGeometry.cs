using System;
using System.Collections.Generic;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class AirChipSocketGeometry
    {
        internal const float Width=.046f,Height=.051f;
        // Measured in the user's native AirConditioner Diagnostics export.
        // The IC socket is recessed at z=.11327..15576. The surrounding grey
        // panel/white cabinet are separate surfaces at z=.20526 and above.
        // Keep complete original triangles, rather than clipping a cube through
        // that surrounding housing and carrying its cut panels onto the DIN face.
        internal static bool Contains(Vector3 p)=>p.x>=-.006f&&p.x<=.126f&&p.y>=.703f&&p.y<=.846f&&p.z>=.111f&&p.z<=.158f;
        internal static List<int>[] Select(Vector3[] vertices,int[][] source)
        {
            var groups=new List<int>[source.Length];
            for(int role=0;role<source.Length;role++)
            {
                var selected=groups[role]=new List<int>();var triangles=source[role];
                for(int i=0;i<triangles.Length;i+=3)
                {
                    int a=triangles[i],b=triangles[i+1],c=triangles[i+2];
                    if(Contains(vertices[a])&&Contains(vertices[b])&&Contains(vertices[c]))selected.AddRange(new[]{a,b,c});
                }
            }
            return groups;
        }
        internal static Mesh Capture(Mesh source,Matrix4x4 toPrefab)
        {
            CabinetGeometry.ReadNativeMesh(source,out var native,out var uv,out var sourceGroups);
            var points=new Vector3[native.Length];for(int i=0;i<points.Length;i++)points[i]=toPrefab.MultiplyPoint3x4(native[i]);
            var selected=Select(points,sourceGroups);var mapping=new Dictionary<int,int>();
            var vertices=new List<Vector3>();var texcoords=new List<Vector2>();var groups=new List<int>[selected.Length];
            for(int role=0;role<selected.Length;role++)
            {
                var output=groups[role]=new List<int>();var input=selected[role];
                for(int i=0;i<input.Count;i+=3)
                {
                    for(int j=0;j<3;j++)
                    {
                        int id=input[i+(toPrefab.determinant<0&&j>0?3-j:j)];
                        if(!mapping.TryGetValue(id,out int mapped)){mapped=vertices.Count;mapping[id]=mapped;vertices.Add(points[id]);texcoords.Add(uv[id]);}
                        output.Add(mapped);
                    }
                }
            }
            if(vertices.Count==0)throw new InvalidOperationException("Native Air Conditioner IC10 socket geometry is missing.");
            var mesh=new Mesh{name="Smart.NativeAirIC10SocketOnly"};mesh.SetVertices(vertices);mesh.SetUVs(0,texcoords);mesh.subMeshCount=groups.Length;
            for(int role=0;role<groups.Length;role++)mesh.SetTriangles(groups[role],role);
            mesh.RecalculateNormals();mesh.RecalculateTangents();mesh.RecalculateBounds();return mesh;
        }
        internal static float Fit(Bounds socket)=>Mathf.Min(Width/socket.size.x,Height/socket.size.y);
    }
}
