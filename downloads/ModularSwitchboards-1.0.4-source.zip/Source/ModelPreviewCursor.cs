using Assets.Scripts;
using Assets.Scripts.Inventory;
using Assets.Scripts.Objects;
namespace ModularSwitchboards
{
    internal static class ModelPreviewCursor
    {
        internal static void AfterPlacement()
        {
            var cursor=InventoryManager.ConstructionCursor;
            if((cursor is DoorLabel||cursor is SwitchboardLabel)&&InventoryManager.ActiveHandSlot?.Get() is MultiConstructor labels&&labels.PrefabName==SwitchboardsMod.LabelKitName)
            {
                // Keep native validity color and visibility, but use the same
                // physical bounds as removal instead of the large mounting board.
                var selection=CursorManager.CursorSelectionTransform;
                if(selection!=null)
                {
                    selection.position=cursor.transform.TransformPoint(cursor.Bounds.center);
                    selection.rotation=cursor.transform.rotation;
                    selection.localScale=cursor.Bounds.size;
                }
                return;
            }
            if(!(cursor is DinBreaker)&&!(cursor is SmartModule))return;
            if(!(InventoryManager.ActiveHandSlot?.Get() is MultiConstructor)||cursor.Wireframe?.BlueprintRenderer==null||CursorManager.Instance==null)return;
            // Native PlacementMode still owns the model's green/red validity
            // colour. Hide only its extra bounds box (which adds 50 mm padding).
            // Native UI restores the highlighter on the next normal/placement frame.
            CursorManager.SetSelectionVisibility(false);
        }
    }
}
