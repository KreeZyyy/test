using System;
using System.Collections.Generic;
using System.Linq;
using Assets.Scripts.Objects;
using UnityEngine;

namespace ModularSwitchboards
{
    public sealed class OvenInputSupportState : MonoBehaviour
    {
        [NonSerialized] public Mesh InstanceMesh;
        private void OnDestroy(){if(InstanceMesh!=null)UnityEngine.Object.Destroy(InstanceMesh);}
    }

    // One continuous base body, rooted tunnel and upper IN transition mesh.
    internal static class OvenInputSupport
    {
        internal const string RootName="OvenInputSupport";
        internal static void Install(SwitchboardCabinet cabinet)
        {
            var shell=cabinet.transform.Find("SwitchboardModel/CompletedShell");
            if(shell==null || shell.Find(OvenInputPanel.RootName)==null)return;
            var root=new GameObject(RootName){layer=cabinet.gameObject.layer};root.transform.SetParent(shell,false);
            root.AddComponent<MeshFilter>();root.AddComponent<OvenInputSupportState>();
            root.AddComponent<MeshRenderer>().sharedMaterials=CabinetGeometry.Materials;
            root.AddComponent<MeshCollider>();
            Fit(cabinet);CabinetRearSurface.Restore(root.GetComponent<MeshRenderer>());
            cabinet.BuildStates[1].Colliders.Add(root.GetComponent<MeshCollider>());
            CabinetModel.SetBounds(cabinet);
        }

        internal static void Fit(Structure cabinet)
        {
            var shell=cabinet.transform.Find("SwitchboardModel/CompletedShell");
            if(shell==null)return;
            var support=shell.Find(RootName);var panel=shell.Find(OvenInputPanel.RootName);var box=shell.Find("NativeApcRearBox");
            if(support==null||panel==null||box==null)return;
            var panelMesh=panel.GetComponent<MeshFilter>()?.sharedMesh;var boxMesh=box.GetComponent<MeshFilter>()?.sharedMesh;
            bool medium=CabinetShape.Medium(cabinet.PrefabName);
            if((!medium&&panelMesh==null)||boxMesh==null)return;
            var top=CabinetLayout.MapBounds(cabinet.PrefabName,CabinetWallMount.TransformedBounds(medium?ExternalCablePorts.OutputJoinBounds:panelMesh.bounds,shell.worldToLocalMatrix*panel.localToWorldMatrix));
            var bottom=CabinetLayout.MapBounds(cabinet.PrefabName,NativeRearBox.BodyBounds(cabinet));
            float low=bottom.min.y,high=medium?top.center.y:panel.localPosition.y*CabinetLayout.YSign(cabinet.PrefabName)-.0005f;
            if(high<=low)return;
            var vertices=new List<Vector3>();var indices=new List<int>();
            var profile=medium?ApcLugCompletion.InterfaceProfile.Select(v=>CabinetLayout.Map(cabinet.PrefabName,(shell.worldToLocalMatrix*panel.localToWorldMatrix).MultiplyPoint3x4(v))).ToArray():null;
            BuildTransition(bottom,top,high,vertices,indices,medium,profile);
            // Match output corridor sheet-metal shading: each planar triangle owns
            // its normals, so the bevel does not smooth into the long flat sides.
            if(medium)FlattenFaces(vertices,indices);
            // The original panel closes the upper rim around its recessed socket.
            CabinetLayout.MapMesh(cabinet.PrefabName,vertices,indices);
            var state=support.GetComponent<OvenInputSupportState>();
            if(state.InstanceMesh==null)state.InstanceMesh=new Mesh{name="Switchboards.InputTransition"};
            var mesh=state.InstanceMesh;support.GetComponent<MeshFilter>().sharedMesh=mesh;mesh.Clear();mesh.SetVertices(vertices);mesh.subMeshCount=5;
            for(int i=0;i<5;i++)mesh.SetTriangles(i==CabinetRearSurface.Role?indices.ToArray():new int[0],i);
            mesh.RecalculateNormals();CabinetGeometry.ApplyNativeUv(mesh);CabinetRearSurface.ApplyUv(mesh);mesh.RecalculateBounds();
            var collider=support.GetComponent<MeshCollider>();collider.sharedMesh=null;collider.sharedMesh=mesh;
        }

        internal static void BuildTransition(Bounds bottom,Bounds top,float high,List<Vector3> vertices,List<int> indices,bool nativeBevel=false,Vector3[] nativeInterface=null)
        {
            float low=bottom.min.y;
            var baseOutline=Outline(bottom.min.x,bottom.max.x,bottom.min.z,bottom.max.z,.004f);
            var exact=nativeInterface==null?null:NativeLugSection.OrderXZ(nativeInterface);
            var tunnelOutline=exact!=null?exact.Select(v=>new Vector2(v.x,v.z)).ToList():nativeBevel?InputBevel(top):Outline(top.min.x,top.max.x,top.min.z,top.max.z,.004f);
            float shoulder=bottom.max.y;
            // Two vertical extrusions with a planar Boolean union at their join.
            // Do not bridge corresponding corners: the footprints overlap only partly.
            AddWalls(baseOutline,low,shoulder,vertices,indices);
            if(exact!=null)AddInterfaceWalls(exact,shoulder,vertices,indices);else AddWalls(tunnelOutline,shoulder,high,vertices,indices);
            AddCap(baseOutline,low,false,vertices,indices);
            foreach(var piece in Difference(baseOutline,tunnelOutline))AddCap(piece,shoulder,true,vertices,indices);
            foreach(var piece in Difference(tunnelOutline,baseOutline))AddCap(piece,shoulder,false,vertices,indices);
        }

        internal static void FlattenFaces(List<Vector3> vertices,List<int> indices)
        {
            var flat=indices.Select(i=>vertices[i]).ToArray();
            vertices.Clear();vertices.AddRange(flat);
            for(int i=0;i<indices.Count;i++)indices[i]=i;
        }

        private static void AddInterfaceWalls(Vector3[] ring,float low,List<Vector3> vertices,List<int> indices)
        {
            int start=vertices.Count,n=ring.Length;
            foreach(var p in ring)vertices.Add(new Vector3(p.x,low,p.z));vertices.AddRange(ring);
            for(int i=0;i<n;i++){int a=start+i,b=start+(i+1)%n;indices.AddRange(new[]{a,b+n,b,a,a+n,b+n});}
        }
        internal static List<Vector2> InputBevel(Bounds top)
        {
            float xmin=top.min.x,xmax=top.max.x,zmin=top.min.z,zmax=top.max.z;
            // Same native APC front bevel depth and slope used by the output corridors.
            float depth=Mathf.Min(.010f,Mathf.Min((zmax-zmin)*.3f,(xmax-xmin)*.5f*.4f/.5776f));
            float inset=depth*.5776f;
            return new List<Vector2>{new Vector2(xmin+inset,zmin),new Vector2(xmax-inset,zmin),
                new Vector2(xmax,zmin+depth),new Vector2(xmax,zmax),new Vector2(xmin,zmax),new Vector2(xmin,zmin+depth)};
        }

        private static List<Vector2> Outline(float xmin,float xmax,float zmin,float zmax,float radius)
        {
            radius=Mathf.Min(radius,Mathf.Min(xmax-xmin,zmax-zmin)*.25f);
            var result=new List<Vector2>();
            for(int corner=0;corner<4;corner++)
            {
                float x=(corner==0||corner==3)?xmax-radius:xmin+radius;
                float z=corner<2?zmax-radius:zmin+radius;
                for(int part=0;part<=6;part++)
                {
                    float angle=(corner*90f+part*15f)*Mathf.Deg2Rad;
                    result.Add(new Vector2(x+radius*Mathf.Cos(angle),z+radius*Mathf.Sin(angle)));
                }
            }
            return result;
        }

        private static void AddWalls(List<Vector2> outline,float low,float high,List<Vector3> vertices,List<int> indices)
        {
            int start=vertices.Count,n=outline.Count;
            foreach(float y in new[]{low,high})foreach(var p in outline)vertices.Add(new Vector3(p.x,y,p.y));
            for(int i=0;i<n;i++)
            {
                int a=start+i,b=start+(i+1)%n;
                indices.AddRange(new[]{a,b+n,b,a,a+n,b+n});
            }
        }

        private static float Side(Vector2 p,Vector2 a,Vector2 b)=>(b.x-a.x)*(p.y-a.y)-(b.y-a.y)*(p.x-a.x);

        private static List<Vector2> Clip(List<Vector2> polygon,Vector2 a,Vector2 b,bool inside)
        {
            var result=new List<Vector2>();
            for(int i=0;i<polygon.Count;i++)
            {
                var p=polygon[i];var q=polygon[(i+1)%polygon.Count];
                float dp=Side(p,a,b),dq=Side(q,a,b);
                bool pin=inside?dp>=0:dp<=0,qin=inside?dq>=0:dq<=0;
                if(pin)result.Add(p);
                if(pin!=qin)
                {
                    float t=dp/(dp-dq);
                    result.Add(new Vector2(p.x+(q.x-p.x)*t,p.y+(q.y-p.y)*t));
                }
            }
            return result;
        }

        // Partition A minus convex B into convex, nonoverlapping pieces.
        private static List<List<Vector2>> Difference(List<Vector2> a,List<Vector2> b)
        {
            var pieces=new List<List<Vector2>>();var remaining=a;
            for(int i=0;i<b.Count && remaining.Count>=3;i++)
            {
                var outside=Clip(remaining,b[i],b[(i+1)%b.Count],false);
                if(outside.Count>=3)pieces.Add(outside);
                remaining=Clip(remaining,b[i],b[(i+1)%b.Count],true);
            }
            return pieces;
        }

        private static void AddCap(List<Vector2> polygon,float y,bool up,List<Vector3> vertices,List<int> indices)
        {
            // Separate cap vertices preserve a crisp, flat shoulder normal.
            int start=vertices.Count;
            foreach(var p in polygon)vertices.Add(new Vector3(p.x,y,p.y));
            for(int i=1;i+1<polygon.Count;i++)
            {
                if(Mathf.Abs(Side(polygon[i+1],polygon[0],polygon[i]))<1e-12f)continue;
                if(up)indices.AddRange(new[]{start,start+i+1,start+i});
                else indices.AddRange(new[]{start,start+i,start+i+1});
            }
        }

        internal static void IncludeBounds(Structure cabinet,ref Bounds bounds)
        {
            var root=cabinet.transform.Find("SwitchboardModel/CompletedShell/"+RootName);
            var mesh=root==null?null:root.GetComponent<MeshFilter>()?.sharedMesh;
            if(mesh!=null)bounds.Encapsulate(CabinetWallMount.TransformedBounds(mesh.bounds,cabinet.transform.worldToLocalMatrix*root.localToWorldMatrix));
        }
    }
}
