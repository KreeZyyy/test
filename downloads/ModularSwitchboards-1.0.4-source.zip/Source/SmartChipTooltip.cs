using System;
using System.Collections.Generic;
namespace ModularSwitchboards
{
    internal static class SmartChipTooltip
    {
        // Only deduplicate the installed chip's exact error lines, not unrelated
        // slot instructions, warnings or other devices' tooltips.
        internal static string Once(string text,string error,string alreadyShown=null)
        {
            if(string.IsNullOrEmpty(text)||string.IsNullOrWhiteSpace(error))return text;
            var errorLines=new HashSet<string>(error.Replace("\r","").Split('\n'),StringComparer.Ordinal);
            errorLines.Remove("");
            var seen=new HashSet<string>(StringComparer.Ordinal);
            if(alreadyShown!=null)foreach(var line in alreadyShown.Replace("\r","").Split('\n'))
                if(errorLines.Contains(line.Trim()))seen.Add(line.Trim());
            var output=new List<string>();bool changed=false;
            foreach(var line in text.Replace("\r","").Split('\n'))
            {
                var key=line.Trim();
                if(errorLines.Contains(key)&&!seen.Add(key)){changed=true;continue;}
                output.Add(line);
            }
            return changed?string.Join("\n",output):text;
        }
    }
}
