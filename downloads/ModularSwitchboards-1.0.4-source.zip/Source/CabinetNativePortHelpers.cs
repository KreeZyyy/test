using System;
using System.Linq;
using Assets.Scripts.Inventory;
using Assets.Scripts.Objects;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class CabinetNativePortHelpers
    {
        // Same native HelperIndicators table used by InventoryManager for APCs.
        // Only replace the cursor's renderer; real connections retain their type.
        internal static InventoryManager.HelperArrow Select(InventoryManager manager,ConnectionRole role)
        {
            var arrows=manager.HelperIndicators;
            var exact=arrows.FirstOrDefault(p=>p.ConnectionRole==role&&p.ConnectionType==NetworkType.PowerAndData&&p.Prefab!=null);
            if(exact!=null)return exact;
            var primary=role==ConnectionRole.Input||role==ConnectionRole.Input2?ConnectionRole.Input:ConnectionRole.Output;
            return arrows.FirstOrDefault(p=>p.ConnectionRole==primary&&p.ConnectionType==NetworkType.PowerAndData&&p.Prefab!=null);
        }
        internal static void AfterCursorCreated(InventoryManager __instance,Thing prefab)
        {
            if(!(prefab is SwitchboardCabinet))return;
            var cursor=InventoryManager.GetStructureCursor(prefab.name) as SwitchboardCabinet;
            if(cursor==null||!cursor.IsCursor)return;
            foreach(var port in cursor.OpenEnds)
            {
                var native=Select(__instance,port.ConnectionRole);
                var old=port.HelperRenderer;
                if(native==null||old==null)
                {
                    Debug.LogError("[Modular Switchboards] Native PowerAndData helper unavailable for "+port.ConnectionRole+"; keeping original helper.");
                    continue;
                }
                var replacement=UnityEngine.Object.Instantiate(native.Prefab,old.transform.position,old.transform.rotation);
                replacement.transform.SetParent(old.transform.parent,true);
                replacement.transform.localScale=old.transform.localScale;
                replacement.tag=old.gameObject.tag;
                var renderer=replacement.GetComponent<Renderer>();
                if(renderer==null){UnityEngine.Object.DestroyImmediate(replacement);Debug.LogError("[Modular Switchboards] Native helper has no root renderer.");continue;}
                port.HelperRenderer=renderer;
                UnityEngine.Object.DestroyImmediate(old.gameObject);
            }
        }
    }
}
