namespace ModularSwitchboards
{
    internal static class DinSmartLayout
    {
        internal const int Slots=4;
        internal const int BuildKits=10;
        internal static float CenterX=>(Slots-1)*DinLayout.SlotPitch*.5f/DinBreakerModel.VisualScale.x;
        internal static float Width=>.0176f+(Slots-1)*DinLayout.SlotPitch/DinBreakerModel.VisualScale.x;
    }
}
