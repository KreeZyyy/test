using System.Collections.Generic;
using System.Linq;
using Assets.Scripts.Objects;
using Assets.Scripts.Sound;
namespace ModularSwitchboards
{
    internal static class PrefabAudioOwner
    {
        internal static void PrepareInstance(Structure instance)
        {
            // Registration/Unity cloning happens after template authoring. Make
            // each runtime instance own its events before native Awake builds
            // the lookup and schedules state sounds. Preserve aliasing within
            // this instance, but never runtime event state across instances.
            var copies=new Dictionary<GameAudioEvent,GameAudioEvent>();
            System.Func<GameAudioEvent,GameAudioEvent> copy=source=>
            {
                if(source==null)return null;
                if(copies.TryGetValue(source,out var existing))return existing;
                var result=new GameAudioEvent{Name=source.Name,NameHash=source.NameHash,Channel=source.Channel,Parent=instance,ClipsData=source.ClipsData,StopIfInvalid=source.StopIfInvalid,
                    Conditions=new List<SoundEffectCondition>(source.Conditions),BuildStateConditions=new List<int>(source.BuildStateConditions)};
                copies.Add(source,result);return result;
            };
            instance.AudioEvents=instance.AudioEvents.Where(e=>e!=null).Select(copy).ToList();
            var interactions=new HashSet<Interactable>(instance.Interactables.Where(i=>i!=null));
            foreach(var state in instance.BuildStates)foreach(var interaction in state.Interactables)if(interaction!=null)interactions.Add(interaction);
            foreach(var interaction in interactions)interaction.AssociatedAudioEvents=interaction.AssociatedAudioEvents.Where(e=>e!=null).Select(copy).ToList();
        }
        internal static void Rebind(Structure replacement)
        {
            // Unity remaps references when cloning a prefab, but replacing its
            // Thing component is our operation. Events must not retain that
            // soon-to-be-destroyed component as their state/audio owner.
            foreach(var audio in replacement.AudioEvents)
                if(audio!=null)audio.Parent=replacement;
            foreach(var interaction in replacement.Interactables)
                if(interaction!=null)
                    foreach(var audio in interaction.AssociatedAudioEvents)
                        if(audio!=null)audio.Parent=replacement;
            foreach(var state in replacement.BuildStates)
                foreach(var interaction in state.Interactables)
                    if(interaction!=null)
                        foreach(var audio in interaction.AssociatedAudioEvents)
                            if(audio!=null)audio.Parent=replacement;
        }
    }
}
