using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace ModularSwitchboards
{
    internal static class ApcLugCompletion
    {
        internal static Vector3[] InterfaceProfile;
        // Native rear interface: two chamfered back corners, flat front face.
        internal static Bounds JoinBounds(Matrix4x4 frame)
        {
            var bounds=new Bounds();bounds.SetMinMax(new Vector3(.119995f,-.035019f,-.030782f),new Vector3(.120011f,.035019f,.043765f));
            return CabinetWallMount.TransformedBounds(bounds,frame);
        }
        internal static Mesh Build(Vector3[] native,Matrix4x4 frame)
        {
            Vector3 Find(float x,float y,float z)
            {
                var target=new Vector3(x,y,z);var point=native.OrderBy(p=>(p-target).sqrMagnitude).First();
                if((point-target).sqrMagnitude>1e-6f)throw new InvalidOperationException("APC connector completion anchor differs from reference: "+target);
                return point;
            }
            var a=Find(.119995f,-.035019f,.043765f);
            var b=Find(.119995f,-.035019f,-.020783f);
            var c=Find(.120010f,-.029243f,-.030782f);
            var d=Find(.120010f,.029243f,-.030782f);
            var e=Find(.119995f,.035019f,-.020783f);
            var f=Find(.119995f,.035019f,.043765f);
            var g=Find(.191156f,.035019f,.043760f);
            var h=Find(.2f,.028964f,.050479f);
            var j=Find(.2f,-.028964f,.050479f);
            var k=Find(.191156f,-.035019f,.043760f);
            var points=new List<Vector3>();var indices=new List<int>();
            void Triangle(Vector3 p,Vector3 q,Vector3 r)
            {int n=points.Count;points.AddRange(new[]{frame.MultiplyPoint3x4(p),frame.MultiplyPoint3x4(q),frame.MultiplyPoint3x4(r)});indices.AddRange(new[]{n,n+1,n+2});}
            // Close the stock opening into the APC base without covering its mouth.
            var root=new[]{a,b,c,d,e,f};InterfaceProfile=root.Select(frame.MultiplyPoint3x4).ToArray();var center=root.Aggregate(Vector3.zero,(sum,p)=>sum+p)/root.Length;
            for(int i=0;i<root.Length;i++)Triangle(center,root[(i+1)%root.Length],root[i]);
            // Stock APC supplies these front walls from its central housing.
            Triangle(a,k,g);Triangle(a,g,f);
            Triangle(k,j,h);Triangle(k,h,g);
            var mesh=new Mesh{name="Switchboards.CompletedApcLugWalls"};mesh.SetVertices(points);mesh.subMeshCount=5;
            for(int i=0;i<5;i++)mesh.SetTriangles(i==CabinetRearSurface.Role?indices.ToArray():new int[0],i);
            mesh.RecalculateNormals();CabinetGeometry.ApplyNativeUv(mesh);CabinetRearSurface.ApplyUv(mesh);mesh.RecalculateBounds();return mesh;
        }
    }
}
