using System;
using System.Text;
using System.Globalization;
using System.Text.RegularExpressions;
namespace ModularSwitchboards
{
    internal static class SmartStatusDisplay
    {
        internal static string Text(SmartRunState state,int line,string customText=null)
        {
            if(state==SmartRunState.Off)return "";
            if(state==SmartRunState.Running)return string.IsNullOrWhiteSpace(customText)?"RUN":customText;
            if(state==SmartRunState.Fault)return line<0?"ERR":line>999?"ERR---":"ERR"+line.ToString(CultureInfo.InvariantCulture);
            return "IDLE";
        }
        internal static string Fit(string text,int maxPixels,Func<char,int> width,bool clipText=true)
        {
            var result=new StringBuilder();int used=0;
            foreach(var ch in text)
            {
                int pixels=width(ch);if(pixels<0)continue;
                if(used+pixels>maxPixels){if(!clipText)return "OVR";break;}
                used+=pixels;result.Append(ch);
            }
            return result.Length==0?"RUN":result.ToString();
        }
        internal static int LuaLine(string detail)
        {
            if(string.IsNullOrWhiteSpace(detail))return -1;
            var match=Regex.Match(detail,@"(?:\]:|\bline\s+)(\d+)",RegexOptions.IgnoreCase);
            return match.Success&&int.TryParse(match.Groups[1].Value,NumberStyles.None,CultureInfo.InvariantCulture,out var line)?line:-1;
        }
    }
}
