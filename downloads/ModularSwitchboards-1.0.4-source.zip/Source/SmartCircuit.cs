using System.Collections.Generic;
using System.Linq;
namespace ModularSwitchboards
{
    internal static class SmartCircuit
    {
        // A single-input consumer shares its feeder's data network. It never
        // inserts an IN -> OUT edge into the protective power circuit.
        internal static int Selection(long id,IEnumerable<CabinetWireSaveData> wires,IEnumerable<long> conducting,IEnumerable<long> protective)
        {
            var graph=wires.ToArray();var closed=conducting.ToArray();var protection=protective.ToArray();
            var input=new CabinetWireEnd(0,0);var tap=new CabinetWireEnd(id,0);
            var topology=closed.Concat(protection).Distinct().ToArray();
            bool supplied=WireCircuit.Reachable(input,tap,graph,topology);
            bool behind=protection.Any(p=>WireCircuit.Reachable(input,new CabinetWireEnd(p,0),graph,topology)&&
                WireCircuit.Reachable(new CabinetWireEnd(p,1),tap,graph,topology));
            if(supplied&&!behind)return AnalyserCircuit.Input;
            // Follow the feeder shared by IN and an external output, including
            // neutral door bridges. An open upstream protector must not migrate
            // a downstream consumer into the cabinet's Input network.
            var feeds=graph.Where(w=>w.To.Equals(tap)).Select(w=>w.From).ToArray();
            int outputs=0;
            foreach(int i in new[]{1,2,3})if(feeds.Any(f=>WireCircuit.Reachable(f,new CabinetWireEnd(0,i),graph,closed)))outputs|=i==3?8:1<<(i-1);
            return outputs;
        }
    }
}
