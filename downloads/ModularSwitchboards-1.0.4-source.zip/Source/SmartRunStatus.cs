namespace ModularSwitchboards
{
    internal enum SmartRunState:byte { Off,Running,Fault,Idle }
    internal static class SmartRunStatus
    {
        internal static SmartRunState Evaluate(bool powered,bool on,bool chip,bool fault,bool program,bool inRange,bool paused)
        {
            if(!powered||!on)return SmartRunState.Off;
            if(!chip)return SmartRunState.Idle;
            if(fault)return SmartRunState.Fault;
            return program&&inRange&&!paused?SmartRunState.Running:SmartRunState.Idle;
        }
    }
}
