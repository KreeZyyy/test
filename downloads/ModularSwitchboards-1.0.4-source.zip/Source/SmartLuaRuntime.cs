using System;
using System.Reflection;
using Assets.Scripts.Objects.Electrical;
using HarmonyLib;
using UnityEngine;
namespace ModularSwitchboards
{
    // Optional adapter for the supplied StationeersLua 1.0 runtime. No third-party
    // DLL is shipped or required by the ordinary IC10 path.
    internal static class SmartLuaRuntime
    {
        private static Type manager;
        private static MethodInfo tick,activity,error,active,snapshot;
        private static FieldInfo saving;
        private static Harmony harmony;
        private static bool editorHooked,reported;
        internal static void Configure(Harmony patches){harmony=patches;Ensure();}
        internal static void TryInitialize()=>Ensure();
        private static void Ensure()
        {
            if(manager!=null)return;
            manager=AccessTools.TypeByName("StationeersLua.LuaChipRuntimeManager");
            if(manager==null)return;
            tick=AccessTools.Method(manager,"TickServerSide",new[]{typeof(ProgrammableChip),typeof(double)});
            activity=AccessTools.Method(manager,"UpdateActivityState",new[]{typeof(long),typeof(bool)});
            error=AccessTools.Method(manager,"GetChipErrorTooltip",new[]{typeof(long)});
            active=AccessTools.Method(manager,"HasActiveRuntime",new[]{typeof(long)});
            snapshot=AccessTools.Method(manager,"TrySnapshotAndDisposeRuntime",new[]{typeof(long)});
            saving=AccessTools.Field(manager,"SaveInProgress");
            var net=AccessTools.TypeByName("StationeersLua.Net.LuaNetManager");
            var sort=net==null?null:AccessTools.Method(net,"SortCircuitHolderDisplayData");
            if(sort!=null&&harmony!=null&&!editorHooked)
            {
                harmony.Patch(sort,prefix:new HarmonyMethod(typeof(SmartComputerDevices),nameof(SmartComputerDevices.FilterLuaHolders)));
                var rack=AccessTools.TypeByName("StationeersLua.Patches.ProgrammableChipMotherboardLuaRackPatch");
                var rebuild=rack==null?null:AccessTools.Method(rack,"RebuildDeviceList");
                if(rebuild!=null)harmony.Patch(rebuild,postfix:new HarmonyMethod(typeof(SmartEditorDropdown),nameof(SmartEditorDropdown.AfterLuaRebuild)));
                editorHooked=true;
            }
            Debug.Log("[Modular Switchboards] Optional StationeersLua runtime: "+(tick!=null&&activity!=null&&error!=null&&active!=null&&snapshot!=null&&saving!=null?"ready":"unsupported API; Lua execution disabled"));
        }
        internal static bool IsLua(ProgrammableChip chip)=>chip!=null&&chip.PrefabName!=null&&chip.PrefabName.StartsWith("ItemIntegratedCircuitLua",StringComparison.Ordinal);
        internal static bool Ready{get{Ensure();return tick!=null&&activity!=null&&error!=null&&active!=null&&snapshot!=null&&saving!=null;}}
        internal static bool Saving=>Ready&&(bool)saving.GetValue(null);
        internal static string Error(ProgrammableChip chip)
        {
            if(!IsLua(chip))return "";
            if(!Ready)return "StationeersLua runtime is unavailable or incompatible.";
            try{return (string)error.Invoke(null,new object[]{chip.ReferenceId})??"";}catch(Exception e){Report(e);return "StationeersLua status unavailable.";}
        }
        internal static bool Running(ProgrammableChip chip)
        {if(!Ready||Saving)return false;try{return (bool)active.Invoke(null,new object[]{chip.ReferenceId});}catch(Exception e){Report(e);return false;}}
        internal static void SetActivity(ProgrammableChip chip,bool inactive)
        {if(!IsLua(chip)||!Ready||Saving)return;try{activity.Invoke(null,new object[]{chip.ReferenceId,inactive});}catch(Exception e){Report(e);}}
        internal static void Tick(ProgrammableChip chip)
        {if(!IsLua(chip)||!Ready||Saving)return;try{tick.Invoke(null,new object[]{chip,.5d});}catch(Exception e){Report(e);}}
        internal static void Detach(ProgrammableChip chip)
        {if(!IsLua(chip)||!Ready||Saving)return;try{snapshot.Invoke(null,new object[]{chip.ReferenceId});}catch(Exception e){Report(e);}}
        private static void Report(Exception exception)
        {if(reported)return;reported=true;Debug.LogError("[Modular Switchboards] StationeersLua integration: "+(exception.InnerException??exception).Message);}
    }
}
