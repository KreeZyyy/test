using System;
using System.Collections.Generic;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class MediumOutputHousing
    {
        internal static List<Vector2> Chamfer(Vector2[] corners,float radius)
        {
            var result=new List<Vector2>();
            for(int i=0;i<corners.Length;i++)
            {
                // The six connector corners must remain exact. A chamfer here
                // cuts into the mating face and leaves visible notches.
                if(i==0||i==1||i==4||i==5||i==8||i==9){result.Add(corners[i]);continue;}
                var p=corners[i];var before=corners[(i+corners.Length-1)%corners.Length];var after=corners[(i+1)%corners.Length];
                float r=Mathf.Min(radius,Mathf.Min((before-p).magnitude,(after-p).magnitude)*.25f);
                result.Add(p+(before-p).normalized*r);result.Add(p+(after-p).normalized*r);
            }
            return result;
        }
        // A continuous comb outline: three socket legs, one crossbar and the rear feed stem.
        internal static Vector2[] Outline(float[] x,float[] bottom,float half,float barBottom,float barTop,float stemTop)
        {
            if(x.Length!=3||bottom.Length!=3||half<=.003f||barTop<=barBottom||stemTop<=barTop||
                x[1]-x[0]<=2*half||x[2]-x[1]<=2*half||Array.Exists(bottom,y=>y>=barBottom))
                throw new InvalidOperationException("Invalid Medium downward output housing dimensions.");
            return new[]{new Vector2(x[0]-half,bottom[0]),new Vector2(x[0]+half,bottom[0]),new Vector2(x[0]+half,barBottom),
                new Vector2(x[1]-half,barBottom),new Vector2(x[1]-half,bottom[1]),new Vector2(x[1]+half,bottom[1]),new Vector2(x[1]+half,barBottom),
                new Vector2(x[2]-half,barBottom),new Vector2(x[2]-half,bottom[2]),new Vector2(x[2]+half,bottom[2]),new Vector2(x[2]+half,barTop),
                new Vector2(half,barTop),new Vector2(half,stemTop),new Vector2(-half,stemTop),new Vector2(-half,barTop),new Vector2(x[0]-half,barTop)};
        }
    }
}
