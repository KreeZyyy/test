using Assets.Scripts.Inventory;
using Assets.Scripts.Objects;
namespace ModularSwitchboards
{
    internal static class MountPlacementTool
    {
        internal static bool Allows(Structure cursor)=>Matches(InventoryManager.ActiveHandSlot?.Get(),cursor,
            InventoryManager.Instance!=null&&InventoryManager.IsAuthoringMode);
        internal static bool Matches(Thing tool,Structure cursor,bool authoring)
        {
            string kit;
            if(cursor is SwitchboardLabel||cursor is DoorLabel)kit=SwitchboardsMod.LabelKitName;
            else if(cursor is InnerCoverModule)kit=SwitchboardsMod.CoverKitName;
            else if(cursor is SmartModule)kit=SwitchboardsMod.SmartKitName;
            else if(cursor is DinRail)kit=SwitchboardsMod.RailKitName;
            else if(cursor is DinBreaker module)kit=module.IsDoorPart?SwitchboardsMod.DoorKitName:SwitchboardsMod.BreakerKitName;
            else return false;
            // Authoring uses the same real construction cursor and board rules.
            return tool!=null&&(authoring||tool is MultiConstructor&&tool.PrefabName==kit);
        }
    }
}
