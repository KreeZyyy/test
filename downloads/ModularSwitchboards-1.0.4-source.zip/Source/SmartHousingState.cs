using Assets.Scripts.Objects;
namespace ModularSwitchboards
{
    internal static class SmartHousingState
    {
        internal static void AfterCacheStates(Thing __instance)
        {
            // Keep the native cached Color interaction for LED lifecycle calls,
            // but this housing uses custom paint, not writable LED Color state.
            // OnServer.SetCustomColor rejects paints while HasColorState is true.
            if(__instance is SmartModule)
            {
                __instance.HasColorState=false;
                // Expose the original LED formats plus the automatic RUN option.
                __instance.HasModeState=true;
            }
        }
    }
}
