using System.Linq;
using Assets.Scripts.Objects;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class RailPlacementSurfaces
    {
        internal static float RowY(int gridRow)=>gridRow*DinLayout.ModulePitch*.1f;
        internal static void Install(SwitchboardCabinet host,Transform origin)
        {
            host.RailRowSurfaces=CabinetShape.Rows(host.PrefabName).Select(row=>
            {
                var go=new GameObject("RailRowSurface"+row){layer=host.gameObject.layer};go.transform.SetParent(origin,false);
                var hit=go.AddComponent<BoxCollider>();hit.center=new Vector3(0,RowY(row),.002f);
                hit.size=new Vector3(CabinetShape.RailWidth(host.PrefabName),.035f,.003f);hit.enabled=false;
                // Placement-only colliders are deliberately outside BuildState.Colliders,
                // just like the dedicated label surfaces.
                return hit;
            }).ToArray();
        }
        internal static void Refresh(SwitchboardCabinet host)
        {
            bool active=!host.IsCursor&&host.CanFitRails&&BoardPlacementInput.Wants(PlacementSurfaceKind.DinRail);
            if(host.RailRowSurfaces!=null)foreach(var hit in host.RailRowSurfaces)if(hit!=null)
            {hit.enabled=active;if(active)Thing._colliderLookup[hit]=host;}
            if(host.RailSurface!=null)host.RailSurface.enabled=!host.IsCursor&&host.CanFitRails&&!active;
        }
    }
}
