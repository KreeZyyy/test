using System;
using System.Linq;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class NativeLugSection
    {
        internal sealed class Layer
        {
            internal float Depth,HalfWidth;
            internal float[] Centers,Ends;
        }
        internal static Layer[] Layers(Vector3[][] profiles)
        {
            if(profiles.Length!=3||profiles.Any(r=>r==null||r.Length!=6))throw new InvalidOperationException("Native connector interface is incomplete.");
            var groups=profiles.Select(r=>r.GroupBy(v=>(int)Math.Round(v.z/.00005f)).OrderBy(g=>g.Key).Select(g=>g.OrderBy(v=>v.x).ToArray()).ToArray()).ToArray();
            if(groups.Any(g=>g.Length!=3||g.Any(pair=>pair.Length!=2)))throw new InvalidOperationException("Native connector profile does not have three bevel levels.");
            return Enumerable.Range(0,3).Select(i=>new Layer{
                Depth=groups.Average(g=>(g[i][0].z+g[i][1].z)*.5f),
                HalfWidth=groups.Average(g=>(g[i][1].x-g[i][0].x)*.5f),
                Centers=groups.Select(g=>(g[i][0].x+g[i][1].x)*.5f).ToArray(),
                Ends=groups.Select(g=>(g[i][0].y+g[i][1].y)*.5f).ToArray()}).ToArray();
        }
        internal static Vector3[] OrderXZ(Vector3[] ring)
        {
            var result=ring.ToArray();float area=0;
            for(int i=0;i<result.Length;i++){var a=result[i];var b=result[(i+1)%result.Length];area+=a.x*b.z-a.z*b.x;}
            if(area<0)Array.Reverse(result);return result;
        }
    }
}
