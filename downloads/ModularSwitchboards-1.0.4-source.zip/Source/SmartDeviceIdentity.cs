using System.Collections.Generic;
namespace ModularSwitchboards
{
    internal static class SmartDeviceIdentity
    {
        // Names are editable and never identify a device. Zero IDs (templates
        // and cursors) cannot be used to collapse different instances.
        internal static bool Duplicate<T>(T item,long id,HashSet<T> instances,HashSet<long> ids) where T:class
        {
            bool sameInstance=!instances.Add(item);
            bool sameId=id!=0&&!ids.Add(id);
            return sameInstance||sameId;
        }
    }
}
