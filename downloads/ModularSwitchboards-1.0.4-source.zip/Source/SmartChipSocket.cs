using System;
using System.Linq;
using Assets.Scripts;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Electrical;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class SmartChipSocket
    {
        internal static void Install(SmartModule module,Vector3 target)
        {
            var air=WorldManager.Instance.SourcePrefabs.OfType<AirConditioner>().First(p=>p.PrefabName=="StructureAirConditioner");
            var slot=air.Slots[0];var pose=air.transform.worldToLocalMatrix*slot.Location.localToWorldMatrix;
            var renderer=air.GetComponentsInChildren<MeshRenderer>(true).First(r=>r.name==air.PrefabName&&r.GetComponent<MeshFilter>()?.sharedMesh!=null);
            var selected=AirChipSocketGeometry.Capture(renderer.GetComponent<MeshFilter>().sharedMesh,air.transform.worldToLocalMatrix*renderer.transform.localToWorldMatrix);
            var socket=selected.bounds;float fit=AirChipSocketGeometry.Fit(socket);var centre=socket.center;
            // Keep the exact native holder/chip relationship. Only the socket's
            // rim seats almost flush with the fascia; no surrounding Air Conditioner panels.
            target.z=.0736f-socket.size.z*.5f*fit;
            var holder=new GameObject("NativeAirChipSocket"){layer=module.gameObject.layer};holder.transform.SetParent(module.transform,false);holder.transform.localPosition=target-centre*fit;holder.transform.localScale=Vector3.one*fit;
            var part=new GameObject("OriginalSocketFrame"){layer=module.gameObject.layer};part.transform.SetParent(holder.transform,false);part.AddComponent<MeshFilter>().sharedMesh=selected;NativePortSurface.Capture(renderer,part.AddComponent<MeshRenderer>());
            Debug.Log("[Modular Switchboards] Smart IC10 socket only: size="+Vector3.Scale(socket.size,Vector3.one*fit)+" scale="+fit);
            // Model the pocket first, as with the Battery Backup, then attach
            // the functional slot using the very same native seating transform.
            float nativeRear=socket.min.z;
            var chip=WorldManager.Instance.SourcePrefabs.OfType<ProgrammableChip>().FirstOrDefault(p=>slot.SpecificTypePrefabHashes==null||slot.SpecificTypePrefabHashes.Length==0||slot.SpecificTypePrefabHashes.Contains(p.PrefabHash));
            if(chip!=null)foreach(var f in chip.GetComponentsInChildren<MeshFilter>(true))if(f.sharedMesh!=null)
                nativeRear=Mathf.Min(nativeRear,CabinetWallMount.TransformedBounds(f.sharedMesh.bounds,pose*chip.transform.worldToLocalMatrix*f.transform.localToWorldMatrix).min.z);
            float rear=target.z+(nativeRear-centre.z)*fit-.0004f;
            var body=module.transform.Find("DinBreakerModel");var filter=body.GetComponent<MeshFilter>();var old=filter.sharedMesh;
            var scale=body.localScale;float width=socket.size.x*fit,height=socket.size.y*fit;
            float front=.0745f;rear=Mathf.Max(rear,.004f);
            var cavity=new Bounds(new Vector3(target.x/scale.x,target.y/scale.y,(rear+front)*.5f/scale.z),new Vector3(width/scale.x,height/scale.y,(front-rear)/scale.z));
            filter.sharedMesh=SmartSocketPocket.Cut(old,cavity,.002607f/scale.x,.002607f/scale.y);UnityEngine.Object.DestroyImmediate(old);
            var location=new GameObject("NativeIC10Location"){layer=module.gameObject.layer};location.transform.SetParent(module.transform,false);location.transform.localPosition=target+(pose.MultiplyPoint3x4(Vector3.zero)-centre)*fit;location.transform.localRotation=pose.rotation;location.transform.localScale=pose.lossyScale*fit;
            var actionRoot=new GameObject("ChipInsertionHitbox"){layer=module.gameObject.layer};actionRoot.transform.SetParent(module.transform,false);actionRoot.transform.localPosition=target;
            var hit=actionRoot.AddComponent<BoxCollider>();hit.size=new Vector3(.048f,.052f,socket.size.z*fit+.006f);
            var action=new Interactable{Parent=module,Action=InteractableType.Slot1,Collider=hit,JoinInProgressSync=true,CanKeyInteract=true,KeyMap="PrimaryAction"};
            var copy=new Slot{Parent=module,StringKey=slot.StringKey,StringHash=slot.StringHash,Type=slot.Type,SpecificTypePrefabHashes=(int[])(slot.SpecificTypePrefabHashes??new int[0]).Clone(),Location=location.transform,RealWorldScale=slot.RealWorldScale,ScaleMultiplier=slot.ScaleMultiplier,HidesOccupant=false,OccupantCastsShadows=slot.OccupantCastsShadows,UseInternalAtmosphere=slot.UseInternalAtmosphere,IsSwappable=slot.IsSwappable,AllowDragging=slot.AllowDragging,IsInteractable=slot.IsInteractable,Size=slot.Size,Action=InteractableType.Slot1,Collider=hit,Interactable=action};
            module.Slots.Add(copy);module.Interactables.Add(action);module.BuildStates[0].Colliders.Add(hit);module.BuildStates[0].Interactables=module.Interactables;
        }
    }
}
