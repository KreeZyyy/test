using System.Linq;
using Assets.Scripts.Objects.Electrical;
namespace ModularSwitchboards
{
    internal static class SmartDisplayModes
    {
        internal const int Number=0,String=10;
        internal static readonly int AutoRun=LogicDisplay.DisplayModeStrings.Length;
        // Preserve every native LED mode number. The extra mode only restores RUN.
        internal static readonly string[] Names=LogicDisplay.DisplayModeStrings.Concat(new[]{"Automatic RUN"}).ToArray();
    }
}
