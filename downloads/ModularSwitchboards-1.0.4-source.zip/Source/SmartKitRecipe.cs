using Assets.Scripts;
using Assets.Scripts.Objects;
using Reagents;
namespace ModularSwitchboards
{
    internal static class SmartKitRecipe
    {
        internal static WorldManager.RecipeData Create()=>new WorldManager.RecipeData
        {
            PrefabName=SwitchboardsMod.SmartKitName,RecipeTier=MachineTier.TierOne,Output=1f,
            Recipe=new Recipe{Iron=2,Copper=1,Electrum=1,Time=3f,Energy=400f}
        };
    }
}
