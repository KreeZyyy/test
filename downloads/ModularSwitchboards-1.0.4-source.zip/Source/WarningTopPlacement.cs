namespace ModularSwitchboards
{
    internal static class WarningTopPlacement
    {
        internal static float Y(float currentY,float originalDoorTop,float targetDoorTop)
            =>currentY+targetDoorTop-originalDoorTop;
    }
}
