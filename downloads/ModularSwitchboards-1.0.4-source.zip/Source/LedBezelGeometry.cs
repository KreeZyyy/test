using UnityEngine;
namespace ModularSwitchboards
{
    internal static class LedBezelGeometry
    {
        // The original LED's separate ten-triangle switch pedestal, measured
        // in ConsoleLED5 Diagnostics. This is not part of the display bezel.
        private static bool ButtonMount(Vector3 p)=>p.x>=-.049f&&p.x<=.057f&&p.y>=-.0201f&&p.y<=-.0046f&&p.z>=.133f&&p.z<=.201f;
        internal static bool KeepTriangle(Vector3 a,Vector3 b,Vector3 c)=>!(ButtonMount(a)&&ButtonMount(b)&&ButtonMount(c));
    }
}
