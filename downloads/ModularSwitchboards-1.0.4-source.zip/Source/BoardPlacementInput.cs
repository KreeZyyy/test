using Assets.Scripts;
using Assets.Scripts.Inventory;
using Assets.Scripts.Objects;
namespace ModularSwitchboards
{
    internal enum PlacementSurfaceKind{DoorLabel,DinLabel,DinRail}
    internal static class BoardPlacementInput
    {
        internal static bool Wants(PlacementSurfaceKind kind)
        {
            if(GameManager.IsBatchMode||InventoryManager.CurrentMode!=InventoryManager.Mode.Placement)return false;
            var cursor=InventoryManager.ConstructionCursor;
            if(!MountPlacementTool.Allows(cursor))return false;
            switch(kind)
            {
                case PlacementSurfaceKind.DinRail:return cursor is DinRail;
                case PlacementSurfaceKind.DoorLabel:return cursor is DoorLabel;
                case PlacementSurfaceKind.DinLabel:return cursor is SwitchboardLabel;
                default:return false;
            }
        }
    }
}
