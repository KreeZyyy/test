"""Render the actual embedded cabinet meshes using the same transforms as MediumGeometry."""
import bpy,struct,math
from pathlib import Path
from mathutils import Vector
root=Path(__file__).resolve().parents[1]
f=open(root/'Assets/Cabinet.meshbin','rb');assert f.read(4)==b'SBMS';ver,mc,count=struct.unpack('<iii',f.read(12))
palette=[struct.unpack('<6f',f.read(24)) for _ in range(mc)];meshes=[]
for k in range(count):
 n=struct.unpack('<i',f.read(4))[0];verts=[struct.unpack('<6f',f.read(24))[:3] for _ in range(n)];faces=[];roles=[]
 for role in range(mc):
  n=struct.unpack('<i',f.read(4))[0];tri=struct.unpack('<'+'i'*n,f.read(n*4))
  faces.extend(tuple(tri[i:i+3])for i in range(0,n,3));roles.extend([role]*(n//3))
 meshes.append((verts,faces,roles))
for kind in ['MediumCabinet','MediumFrame']:
 bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
 mats=[]
 for i,values in enumerate(palette):
  m=bpy.data.materials.new(str(i));m.use_nodes=True;node=m.node_tree.nodes.get('Principled BSDF');node.inputs['Base Color'].default_value=values[:4];node.inputs['Roughness'].default_value=.72;mats.append(m)
 def add(k,name,xscale,yscale,dx=0,mirror=False):
  v,faces,roles=meshes[k];pts=[(-(p[0]*xscale*(-1 if mirror else 1)+dx),-p[2],p[1]*yscale)for p in v]
  # Unity to Blender mapping reverses handedness; mirror restores it.
  faces=[tuple(face if mirror else reversed(face))for face in faces]
  mesh=bpy.data.meshes.new(name);mesh.from_pydata(pts,[],faces);mesh.update();ob=bpy.data.objects.new(name,mesh);bpy.context.collection.objects.link(ob)
  for m in mats:mesh.materials.append(m)
  for poly,r in zip(mesh.polygons,roles):poly.material_index=r
  return ob
 add(0,'Frame',2,2)
 if kind=='MediumCabinet':
  add(1,'Housing',2,2);add(2,'Interior',2,2)
  for mirror in [False,True]:
   ob=add(3,'RightDoor'if mirror else'LeftDoor',1,2,.4 if mirror else-.4,mirror);ob.location.y=-.187
 scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=32;scene.cycles.use_denoising=False
 scene.render.resolution_x=384;scene.render.resolution_y=384;scene.render.resolution_percentage=100;scene.render.film_transparent=True
 scene.world.color=(.35,.35,.35)
 for loc,power,size in [((-2,-3,4),400,3),((3,-1,2),200,3),((0,3,3),250,2)]:
  bpy.ops.object.light_add(type='AREA',location=loc);light=bpy.context.object;light.data.energy=power;light.data.shape='DISK';light.data.size=size;light.rotation_euler=(-light.location).to_track_quat('-Z','Y').to_euler()
 bpy.ops.object.camera_add(location=(-1.3,-2.5,1.2));cam=bpy.context.object;cam.rotation_euler=(Vector((0,-.07,0))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=1.38;scene.camera=cam
 scene.view_settings.view_transform='Standard';scene.render.image_settings.file_format='PNG';scene.render.image_settings.color_mode='RGBA'
 scene.render.filepath=str(root/'Assets/Icons'/f'{kind}.png');bpy.ops.render.render(write_still=True)
