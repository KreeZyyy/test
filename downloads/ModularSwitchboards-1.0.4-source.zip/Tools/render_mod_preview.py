"""Render our own mod-list art from the shipped cabinet and module geometry."""
import bpy,struct,json,math,os
from pathlib import Path
from mathutils import Vector
root=Path(__file__).resolve().parents[1]
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
def mat(name,rgb,emission=False):
 m=bpy.data.materials.new(name);m.diffuse_color=(*rgb,1);m.use_nodes=True;n=m.node_tree.nodes.get('Principled BSDF');n.inputs['Base Color'].default_value=(*rgb,1);n.inputs['Roughness'].default_value=.68
 if emission:n.inputs['Emission Color'].default_value=(*rgb,1);n.inputs['Emission Strength'].default_value=1
 return m
white=mat('Ceramic white',(.74,.80,.79));dark=mat('Graphite',(.025,.04,.047));metal=mat('Metal',(.24,.30,.31));gold=mat('Contacts',(.65,.43,.08));green=mat('Circuit green',(.08,.58,.37));ink=mat('Text',(.90,.96,.95),True);teal=mat('Accent',(.08,.72,.55),True);grey=mat('Secondary text',(.48,.64,.65),True)
f=open(root/'Assets/Cabinet.meshbin','rb');assert f.read(4)==b'SBMS';version,mc,count=struct.unpack('<iii',f.read(12));palette=[struct.unpack('<6f',f.read(24))for _ in range(mc)];mats=[mat('Cabinet '+str(i),p[:3])for i,p in enumerate(palette)];meshes=[]
for _ in range(count):
 n=struct.unpack('<i',f.read(4))[0];v=[struct.unpack('<6f',f.read(24))[:3]for _ in range(n)];faces=[];roles=[]
 for role in range(mc):
  n=struct.unpack('<i',f.read(4))[0];tri=struct.unpack('<'+'i'*n,f.read(n*4));faces.extend(tuple(tri[i:i+3])for i in range(0,n,3));roles.extend([role]*(n//3))
 meshes.append((v,faces,roles))
def model(name,pts,faces,materials,roles=None):
 me=bpy.data.meshes.new(name);me.from_pydata(pts,[],faces);me.update();ob=bpy.data.objects.new(name,me);bpy.context.collection.objects.link(ob)
 for m in materials:me.materials.append(m)
 if roles:
  for p,r in zip(me.polygons,roles):p.material_index=r
 return ob
def cabinet(x,z,s,medium=False,closed=True):
 def part(k,dx=0,mirror=False):
  v,faces,roles=meshes[k];xs=2 if medium and k!=3 else 1;ys=2 if medium else 1
  pts=[(x-(p[0]*xs*(-1 if mirror else 1)+dx)*s,-p[2]*s-(.187*s if k==3 else 0),z+p[1]*ys*s)for p in v]
  return model('Cabinet',pts,[tuple(t if mirror else reversed(t))for t in faces],mats,roles)
 for k in [0,1,2]:part(k)
 if closed:
  if medium:part(3,-.4);part(3,.4,True)
  else:part(3)
cabinet(2.05,.05,2.65,True,False)
# The open cabinet is the single product focus.
geo=json.loads((root/'Art/CatalogGeometry.json').read_text());geo['breakerLever']=json.loads((root/'Art/LeverIconGeometry.json').read_text())
def module(parts,x,z,scale):
 for part in parts:
  d=geo[part];pts=[(x-p[0]*2.25*scale,-.65-(p[2]+(.0675 if part=='breakerLever' else 0))*1.15*scale,z+p[1]*1.35*scale)for p in d['vertices']];faces=[];roles=[]
  for role,indices in d['triangles'].items():
   faces.extend(tuple(reversed(indices[i:i+3]))for i in range(0,len(indices),3));roles.extend([(4 if part=='batteryBay' and int(role)==1 else {0:3,1:0,2:2,3:1,4:2}.get(int(role),1))]*(len(indices)//3))
  model(part,pts,faces,[white,dark,metal,green,gold],roles)
module(['breakerBody','breakerLever'],1.38,.5,6)
module(['batteryBody','batteryBay'],2.2,.5,6)
module(['analyserBody','analyserFront'],1.8,-.45,6)
# DIN rails, set inside the open cabinet.
for z in [.5,-.45]:
 bpy.ops.mesh.primitive_cube_add(size=1,location=(2.05,-.24,z));ob=bpy.context.object;ob.scale=(1.8,.08,.08);ob.data.materials.append(metal)
def text(value,x,z,size,material):
 cu=bpy.data.curves.new('Label','FONT');cu.body=value;cu.size=size;cu.extrude=0;ob=bpy.data.objects.new('Label',cu);bpy.context.collection.objects.link(ob);ob.location=(x,-2,z);ob.rotation_euler=(math.pi/2,0,0);cu.materials.append(material)
text('MODULAR',-3.85,1.15,.55,ink);text('SWITCHBOARDS',-3.85,.53,.43,ink)
text('BUILD. WIRE. CONTROL.',-3.82,-.05,.18,teal)
text('DIN RAILS  /  PROTECTION  /  SMART CONTROL',-3.82,-.55,.108,grey)
text('by KreeZy',-3.82,-1.42,.20,ink)
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=96;scene.cycles.use_denoising=False;scene.world.color=(.025,.04,.05);scene.view_settings.view_transform='Standard';scene.render.film_transparent=False
for loc,power,size in [((-3,-4,5),650,5),((4,-3,2),450,4),((1,2,4),600,3)]:
 bpy.ops.object.light_add(type='AREA',location=loc);o=bpy.context.object;o.data.energy=power;o.data.size=size;o.rotation_euler=(-o.location).to_track_quat('-Z','Y').to_euler()
bpy.ops.object.camera_add(location=(0,-9,0));cam=bpy.context.object;cam.rotation_euler=(Vector((0,0,0))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=8.6;scene.camera=cam
scene.render.image_settings.file_format='PNG';scene.render.image_settings.color_mode='RGB';scene.render.resolution_percentage=100
out=root/'ModularSwitchboards/About';out.mkdir(parents=True,exist_ok=True)
for name,w,h in [('Preview.png',1600,900),('thumb.png',640,360)]:
 scene.render.resolution_x=w;scene.render.resolution_y=h;scene.render.filepath=str(out/name);bpy.ops.render.render(write_still=True)
