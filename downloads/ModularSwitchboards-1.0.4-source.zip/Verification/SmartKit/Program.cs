using System;using ModularSwitchboards;using Assets.Scripts.Objects;
namespace Assets.Scripts{public enum MachineTier{TierOne}public class WorldManager{public class RecipeData{public string PrefabName;public MachineTier RecipeTier;public float Output;public Reagents.Recipe Recipe;}}}
namespace Reagents{public class Recipe{public float Iron,Copper,Electrum,Time,Energy;}}
namespace Assets.Scripts.Objects{public class Thing{public string PrefabName;}public class Structure:Thing{}public class MultiConstructor:Thing{}public class Slot{public Thing Get()=>null;}}
namespace Assets.Scripts.Inventory{public class InventoryManager{public static Slot ActiveHandSlot;public static InventoryManager Instance;public static bool IsAuthoringMode;}}
namespace ModularSwitchboards{
 static class SwitchboardsMod{public const string SmartKitName="smartkit",BreakerKitName="regular",RailKitName="rail",CoverKitName="cover",LabelKitName="label",DoorKitName="door";}
 class SmartModule:Structure{}class DinBreaker:Structure{public bool IsDoorPart;}class DinRail:Structure{}class SwitchboardLabel:Structure{}class DoorLabel:Structure{}class InnerCoverModule:Structure{}
 class DinModuleBoard{public bool Free=true;public int Width;public bool CanPlace(int p,int r,int width){Width=width;return Free;}}
}
class Request{public Structure StructurePrefab;public Thing Constructor;public object Board;public int Position,Rotation;}
class Program{
 static int n;static void Check(bool b){n++;if(!b)throw new Exception("Smart kit check "+n);}
 static void Main(){var smart=new SmartModule();var regular=new MultiConstructor{PrefabName=SwitchboardsMod.BreakerKitName};var kit=new MultiConstructor{PrefabName=SwitchboardsMod.SmartKitName};
 Check(MountPlacementTool.Matches(kit,smart,false));Check(!MountPlacementTool.Matches(regular,smart,false));Check(!MountPlacementTool.Matches(kit,new DinBreaker(),false));Check(MountPlacementTool.Matches(regular,new DinBreaker(),false));Check(!MountPlacementTool.Matches(null,smart,true));Check(MountPlacementTool.Matches(new Thing(),smart,true));
 var board=new DinModuleBoard();var request=new Request{StructurePrefab=smart,Constructor=kit,Board=board};Check(Authority.Allows(request)&&board.Width==4);request.Constructor=regular;Check(!Authority.Allows(request));request.Constructor=kit;board.Free=false;Check(!Authority.Allows(request));board.Free=true;request.Board=null;Check(!Authority.Allows(request));
 var recipe=SmartKitRecipe.Create();Check(recipe.PrefabName==kit.PrefabName&&recipe.Output==1);Check(recipe.Recipe.Iron==2&&recipe.Recipe.Copper==1&&recipe.Recipe.Electrum==1);Check(recipe.Recipe.Iron*10==20&&recipe.Recipe.Copper*10==10&&recipe.Recipe.Electrum*10==10);Check(recipe.RecipeTier==Assets.Scripts.MachineTier.TierOne&&recipe.Recipe.Time>0&&recipe.Recipe.Energy>0);
 Console.WriteLine(n+" Smart kit checks passed: wrong kits rejected by cursor and authority, four-slot placement retained, separate recipe includes electrum.");}
}
