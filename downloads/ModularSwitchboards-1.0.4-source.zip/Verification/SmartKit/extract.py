from pathlib import Path
root=Path(__file__).resolve().parents[2]
s=(root/'Source/SwitchboardsMod.cs').read_text();a=s.index('            if(__0.StructurePrefab is SmartModule)');b=s.index('            if (__0.StructurePrefab is DinBreaker module)',a)
(Path(__file__).resolve().parent/'Authority.cs').write_text('using ModularSwitchboards;\nusing static ModularSwitchboards.SwitchboardsMod;\nusing Assets.Scripts.Objects;\nclass Authority{public static bool Allows(Request __0){'+s[a:b]+'return false;}}')
