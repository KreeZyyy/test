using ModularSwitchboards;
using static ModularSwitchboards.SwitchboardsMod;
using Assets.Scripts.Objects;
class Authority{public static bool Allows(Request __0){            if(__0.StructurePrefab is SmartModule)
                return __0.Constructor!=null&&__0.Constructor.PrefabName==SmartKitName&&
                    __0.Board is DinModuleBoard smartBoard&&smartBoard.CanPlace(__0.Position,__0.Rotation,4);
return false;}}