using System;using System.IO;using System.Collections.Generic;using UnityEngine;using Assets.Scripts.Objects;namespace ModularSwitchboards{static class ApcWarning{        private static Mesh NativeMesh(Renderer renderer)
        {
            if(renderer is SkinnedMeshRenderer skinned) return skinned.sharedMesh;
            return renderer.GetComponent<MeshFilter>()?.sharedMesh;
        }

        [Serializable] private sealed class MeshDump { public string Name; public Vector3[] Vertices; public Vector2[] Uv; public PartDump[] Parts; }
        [Serializable] private sealed class PartDump { public string Material; public int MaterialId; public int[] Triangles; }
        internal static void ExportReference(Thing source,string fileName)
        {
            var directory=Path.Combine(Application.persistentDataPath,"ModularSwitchboards","Diagnostics");
            Directory.CreateDirectory(directory);
            int count=DumpGeometry(source,directory,fileName);
            Debug.Log("[Modular Switchboards] Smart native geometry exported: "+source.PrefabName+"; "+count+" meshes; "+Path.Combine(directory,fileName));
        }
        private static int DumpGeometry(Thing apc,string directory,string fileName="APC-geometry.json")
        {
            var meshes=new List<MeshDump>();
            foreach(var renderer in apc.GetComponentsInChildren<Renderer>(true))
            {
                var mesh=NativeMesh(renderer);if(mesh==null) continue;
                try
                {
                    CabinetGeometry.ReadNativeMesh(mesh,out var vertices,out var uv,out var triangles);
                    for(int i=0;i<vertices.Length;i++) vertices[i]=apc.transform.InverseTransformPoint(renderer.transform.TransformPoint(vertices[i]));
                    var materials=renderer.sharedMaterials;
                    var parts=new List<PartDump>();
                    for(int sub=0;sub<triangles.Length && sub<materials.Length;sub++)
                        parts.Add(new PartDump { Material=materials[sub]==null?"null":materials[sub].name,MaterialId=materials[sub]==null?0:materials[sub].GetInstanceID(),Triangles=triangles[sub] });
                    meshes.Add(new MeshDump { Name=renderer.name,Vertices=vertices,Uv=uv,Parts=parts.ToArray() });
                }
                catch(Exception ex){Debug.LogWarning("[Modular Switchboards] APC mesh diagnostic: "+ex.Message);}
            }
            File.WriteAllText(Path.Combine(directory,fileName),GeometryJson(meshes));
            return meshes.Count;
        }

        private static string GeometryJson(List<MeshDump> meshes)
        {
            var text=new System.Text.StringBuilder("{\"Meshes\":[");
            for(int i=0;i<meshes.Count;i++)
            {
                if(i>0) text.Append(',');var mesh=meshes[i];
                text.Append("{\"Name\":").Append(Quote(mesh.Name)).Append(",\"Vertices\":[");
                for(int j=0;j<mesh.Vertices.Length;j++)
                {if(j>0)text.Append(',');var v=mesh.Vertices[j];text.Append("{\"x\":").Append(Number(v.x)).Append(",\"y\":").Append(Number(v.y)).Append(",\"z\":").Append(Number(v.z)).Append('}');}
                text.Append("],\"Uv\":[");
                for(int j=0;j<mesh.Uv.Length;j++)
                {if(j>0)text.Append(',');var v=mesh.Uv[j];text.Append("{\"x\":").Append(Number(v.x)).Append(",\"y\":").Append(Number(v.y)).Append('}');}
                text.Append("],\"Parts\":[");
                for(int j=0;j<mesh.Parts.Length;j++)
                {
                    if(j>0)text.Append(',');var part=mesh.Parts[j];text.Append("{\"Material\":").Append(Quote(part.Material)).Append(",\"MaterialId\":").Append(part.MaterialId).Append(",\"Triangles\":[");
                    for(int k=0;k<part.Triangles.Length;k++){if(k>0)text.Append(',');text.Append(part.Triangles[k]);}
                    text.Append("]}");
                }
                text.Append("]}");
            }
            return text.Append("]}").ToString();
        }
        private static string Number(float value)=>value.ToString("R",System.Globalization.CultureInfo.InvariantCulture);
        private static string Quote(string value)=>"\""+value.Replace("\\","\\\\").Replace("\"","\\\"").Replace("\r","\\r").Replace("\n","\\n")+"\"";

}}