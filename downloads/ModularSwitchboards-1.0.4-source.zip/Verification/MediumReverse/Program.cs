using System;using System.Linq;using System.Collections.Generic;using UnityEngine;using ModularSwitchboards;
namespace UnityEngine{
struct Vector3 {public float x,y,z;public Vector3(float x,float y,float z){this.x=x;this.y=y;this.z=z;}public static Vector3 down=>new(0,-1,0);public static Vector3 up=>new(0,1,0);public static Vector3 operator+(Vector3 a,Vector3 b)=>new(a.x+b.x,a.y+b.y,a.z+b.z);public static Vector3 operator-(Vector3 a,Vector3 b)=>new(a.x-b.x,a.y-b.y,a.z-b.z);public static Vector3 operator-(Vector3 a)=>new(-a.x,-a.y,-a.z);public static Vector3 operator*(Vector3 a,float b)=>new(a.x*b,a.y*b,a.z*b);public static float Dot(Vector3 a,Vector3 b)=>a.x*b.x+a.y*b.y+a.z*b.z;public Grid3 ToGrid(float size,float offset)=>new(new Vector3((float)Math.Round((x-offset-size/2)/size)*size+offset+size/2,(float)Math.Round((y-offset-size/2)/size)*size+offset+size/2,(float)Math.Round((z-offset-size/2)/size)*size+offset+size/2));}
}
struct Grid3{public Vector3 p;public Grid3(Vector3 p){this.p=p;}public Vector3 ToVector3()=>p;}
static class SmallGrid{public const float SmallGridSize=.5f,SmallGridOffset=.25f;}
static class NativeCableLayout{
 internal struct Socket{internal Vector3 Point,Forward,ContactPoint;internal Grid3 CableCell,BodyCell;}
 internal static Socket Current;
 internal static Socket Read(Vector3 cell,Vector3 axis)=>Current;
        internal static Socket ReadForBody(Vector3 deviceBodyCell,Vector3 outward)
        {
            var socket=Read(deviceBodyCell+outward*SmallGrid.SmallGridSize,outward);
            var body=deviceBodyCell.ToGrid(SmallGrid.SmallGridSize,SmallGrid.SmallGridOffset);
            var shift=body.ToVector3()-socket.BodyCell.ToVector3();
            socket.Point+=shift;
            socket.CableCell=socket.Point.ToGrid(SmallGrid.SmallGridSize,SmallGrid.SmallGridOffset);
            socket.BodyCell=body;
            if(Vector3.Dot(socket.Forward,-outward)<.99f)
                throw new InvalidOperationException("Native socket faces away from the intended device body cell.");
            // The mouth sits on the shared face between the cable and body cells.
            // A Connection.Transform may identify a cell centre, not the visible end.
            socket.ContactPoint=(socket.Point+body.ToVector3())*.5f;
            return socket;
        }

}

namespace UnityEngine{struct Bounds{public Vector3 center,size;public Bounds(Vector3 c,Vector3 s){center=c;size=s;}}}
namespace Assets.Scripts.Objects{enum ConnectionRole{Input,Output,Output2,Waste}}
namespace ModularSwitchboards{static class SwitchboardsMod{public const string CabinetName="small",ReverseCabinetName="reverse",MediumCabinetName="medium",MediumReverseCabinetName="mediumreverse";}static class DinLayout{public const float CabinetInnerWidth=.35f,SlotPitch=.045f;public static int FullModuleCount(float w)=>(int)Math.Round(w/.045f);}}
class Program{static int n;static void Check(bool b,string m){n++;if(!b)throw new Exception(m);}static void Near(float x,float y,string m)=>Check(Math.Abs(x-y)<1e-6,m);static void Main(){
foreach(string name in new[]{"small","reverse","medium","mediumreverse"}){bool medium=name.StartsWith("medium"),reverse=name.EndsWith("reverse");float sign=reverse?-1:1;Check(CabinetShape.Medium(name)==medium,"Medium classification");Check(CabinetLayout.Reversed(name)==reverse,"Reverse classification");Near(CabinetShape.Width(name),medium?.8f:.4f,"width");Near(CabinetShape.Height(name),medium?1:.5f,"height");Check(CabinetShape.FrameKits(name)==(medium?3:1)&&CabinetShape.PlasticSheets(name)==(medium?5:2),"cost");Check(CabinetShape.Rows(name).SequenceEqual(medium?new[]{-150,0,150}:new[]{-60,60}),"DIN rows rotated");Check(CabinetShape.OutputCount(name)==(medium?3:2),"output count");
var input=CabinetLayout.Map(name,CabinetShape.Terminal(name,0));Near(input.y,CabinetShape.TerminalY(name)*sign,"Internal input side");Near(CabinetLayout.InputCell(name).y,(medium?1:.5f)*sign,"Input cable cell");Near(CabinetLayout.InputOutward(name).y,sign,"Input direction");
for(int i=0;i<CabinetShape.OutputCount(name);i++){var terminal=CabinetLayout.Map(name,CabinetShape.Terminal(name,i+1));Near(terminal.y,-CabinetShape.TerminalY(name)*sign,"Output terminal side");if(medium)Near(terminal.x,(1-i)*.23f,"internal left-center-right order");foreach(float leftSign in new[]{-1f,1f}){var left=new Vector3(leftSign,0,0);var body=OutputPlacement.Body(name,i,left,.5f);var axis=OutputPlacement.Outward(name,i,left);Near(body.y,-.5f*sign,"Output body cell");if(medium){Near(axis.y,-sign,"Output axis");Near(body.x,(1-i)*leftSign*.5f,"External output order");}
foreach(float pivot in new[]{-.5f,-.25f,0,.25f,.5f}){var raw=new Vector3(pivot,pivot,pivot);NativeCableLayout.Current=new(){Point=raw+axis*.5f,Forward=-axis,BodyCell=new(raw)};var socket=NativeCableLayout.ReadForBody(body,axis);var face=body+axis*.25f;Near(socket.ContactPoint.x,face.x,"output face x");Near(socket.ContactPoint.y,face.y,"output face y");Near(socket.Point.y,body.y+axis.y*.5f,"output cable cell");}}}
if(medium)foreach(float pivot in new[]{-.5f,0,.5f}){var axis=CabinetLayout.InputOutward(name);var body=CabinetLayout.InputCell(name)-axis*.5f;var raw=new Vector3(pivot,pivot,pivot);NativeCableLayout.Current=new(){Point=raw+axis*.5f,Forward=-axis,BodyCell=new(raw)};var socket=NativeCableLayout.ReadForBody(body,axis);Near(socket.ContactPoint.y,.75f*sign,"Input shared face");Near(socket.Point.y,sign,"Input native cable cell");}
var v=new List<Vector3>{new(-1,-2,0),new(1,-2,0),new(0,2,0)};var t=new List<int>{0,1,2};CabinetLayout.MapMesh(name,v,t);Check(t.SequenceEqual(reverse?new[]{0,2,1}:new[]{0,1,2}),"Mirrored winding");Near(v[0].y,-2*sign,"Mesh mirror");CabinetLayout.MapMesh(name,v,t);Near(v[0].y,-2,"Mirror roundtrip");Check(t.SequenceEqual(new[]{0,1,2}),"Winding roundtrip");
}
Console.WriteLine($"Medium Reverse: {n} production profile/layout/native-grid checks passed across four variants, body/cable/contact faces, internal/external output order, dimensions/costs/rows and mirrored winding.");}}
