using System;using ModularSwitchboards;
namespace ModularSwitchboards{static class SwitchboardsMod{public const string SmartKitName="smartkit",DoorKitName="door",CoverKitName="coverkit",RailKitName="railkit",BreakerKitName="breakerkit",CoverName="cover",RailName="rail";}}
class Program{
 static int n;static void Check(bool v){n++;if(!v)throw new Exception("Smart name migration check "+n);}
 static void Main(){const string id="StructureDinSmartModule";
 Check(SwitchboardNames.Default(id)=="Smart Core Module");
 foreach(var old in new[]{"Smart Module","DIN Smart Module"})Check(SwitchboardNames.Migrate(id,old)=="Smart Core Module");
 foreach(var custom in new[]{"Smart Core Module","Air handling PLC","DIN Smart Module 2","",null})Check(SwitchboardNames.Migrate(id,custom)==custom);
 Check(SwitchboardNames.Migrate("OtherDevice","DIN Smart Module")=="DIN Smart Module");
 Check(SwitchboardNames.Default(SwitchboardsMod.SmartKitName)=="Kit (DIN Smart Modules)");
 Console.WriteLine(n+" Smart Core name checks passed: old defaults migrated, custom names and prefab identity retained, shared Smart kit unchanged.");}
}
