using System;using UnityEngine;using ModularSwitchboards;
namespace UnityEngine{
struct Vector3 {public float x,y,z;public Vector3(float x,float y,float z){this.x=x;this.y=y;this.z=z;}public static Vector3 down=>new(0,-1,0);public static Vector3 operator+(Vector3 a,Vector3 b)=>new(a.x+b.x,a.y+b.y,a.z+b.z);public static Vector3 operator-(Vector3 a,Vector3 b)=>new(a.x-b.x,a.y-b.y,a.z-b.z);public static Vector3 operator-(Vector3 a)=>new(-a.x,-a.y,-a.z);public static Vector3 operator*(Vector3 a,float b)=>new(a.x*b,a.y*b,a.z*b);public static float Dot(Vector3 a,Vector3 b)=>a.x*b.x+a.y*b.y+a.z*b.z;public Grid3 ToGrid(float size,float offset)=>new(new Vector3((float)Math.Round((x-offset-size/2)/size)*size+offset+size/2,(float)Math.Round((y-offset-size/2)/size)*size+offset+size/2,(float)Math.Round((z-offset-size/2)/size)*size+offset+size/2));}
}
struct Grid3{public Vector3 p;public Grid3(Vector3 p){this.p=p;}public Vector3 ToVector3()=>p;}
static class SmallGrid{public const float SmallGridSize=.5f,SmallGridOffset=.25f;}
static class NativeCableLayout{
 internal struct Socket{internal Vector3 Point,Forward,ContactPoint;internal Grid3 CableCell,BodyCell;}
 internal static Socket Current;
 internal static Socket Read(Vector3 cell,Vector3 axis)=>Current;
        internal static Socket ReadForBody(Vector3 deviceBodyCell,Vector3 outward)
        {
            var socket=Read(deviceBodyCell+outward*SmallGrid.SmallGridSize,outward);
            var body=deviceBodyCell.ToGrid(SmallGrid.SmallGridSize,SmallGrid.SmallGridOffset);
            var shift=body.ToVector3()-socket.BodyCell.ToVector3();
            socket.Point+=shift;
            socket.CableCell=socket.Point.ToGrid(SmallGrid.SmallGridSize,SmallGrid.SmallGridOffset);
            socket.BodyCell=body;
            if(Vector3.Dot(socket.Forward,-outward)<.99f)
                throw new InvalidOperationException("Native socket faces away from the intended device body cell.");
            // The mouth sits on the shared face between the cable and body cells.
            // A Connection.Transform may identify a cell centre, not the visible end.
            socket.ContactPoint=(socket.Point+body.ToVector3())*.5f;
            return socket;
        }

}
class Program{static void Main(){int count=0;foreach(float row in new[]{-.5f,.5f}){var body=new Vector3(0,row,0);foreach(float x in new[]{-.5f,0f,.5f})foreach(float y in new[]{-.5f,0f,.5f})foreach(float z in new[]{-.5f,0f,.5f})foreach(float side in new[]{-1f,1f}){var outward=new Vector3(side,0,0);var rawBody=new Vector3(x,y,z);NativeCableLayout.Current=new(){Point=rawBody+outward*.5f,Forward=-outward,BodyCell=new(rawBody)};var socket=NativeCableLayout.ReadForBody(body,outward);var expected=body+outward*.25f;var d=socket.ContactPoint-expected;if(Vector3.Dot(d,d)>1e-10)throw new Exception("physical mouth misplaced");d=socket.Point-(body+outward*.5f);if(Vector3.Dot(d,d)>1e-10)throw new Exception("logical cell misplaced");if(Math.Abs(socket.ContactPoint.y)-.0351f<=.116f)throw new Exception("bar overlaps central rear box");count++;}}foreach(float sign in new[]{-1f,1f})foreach(float pivot in new[]{-.5f,0,.5f}){var cells=new System.Collections.Generic.HashSet<float>();for(int i=0;i<3;i++){var left=new Vector3(sign,0,0);var body=OutputPlacement.Body("medium",i,left,.5f);if(Math.Abs(body.x-(1-i)*sign*.5f)>1e-6)throw new Exception("Outputs not ordered 1 2 3");var axis=OutputPlacement.Outward("medium",i,left);if(axis.y!=-1||axis.x!=0)throw new Exception("Medium port not downward");var raw=new Vector3(pivot,pivot,pivot);NativeCableLayout.Current=new(){Point=raw+axis*.5f,Forward=-axis,BodyCell=new(raw)};var socket=NativeCableLayout.ReadForBody(body,axis);if(Math.Abs(socket.Point.y+1)>1e-6||Math.Abs(socket.ContactPoint.y+.75f)>1e-6||!cells.Add(socket.Point.x))throw new Exception("Medium native row or duplicate");count++;}}
foreach(float pivot in new[]{-.5f,-.25f,0,.25f,.5f}){var body=new Vector3(0,.5f,0);var axis=new Vector3(0,1,0);var raw=new Vector3(pivot,pivot,pivot);NativeCableLayout.Current=new(){Point=raw+axis*.5f,Forward=-axis,BodyCell=new(raw)};var input=NativeCableLayout.ReadForBody(body,axis);if(Math.Abs(input.Point.y-1)>1e-6||Math.Abs(input.ContactPoint.y-.75f)>1e-6||Math.Abs(input.ContactPoint.x)>1e-6)throw new Exception("Medium input not on actual shared cable-grid face");count++;}
Console.WriteLine($"Production ReadForBody passed {count} pivot-offset cases: fixed device row, separate cable cells, shared-face apertures and vertical clearance.");}}

namespace ModularSwitchboards{static class CabinetShape{public static bool Medium(string n)=>n=="medium";}static class CabinetLayout{public static Vector3 Map(string n,Vector3 v)=>new(v.x,n=="reverse"?-v.y:v.y,v.z);public static Vector3 OutputBodyCell(string n,float g)=>new(0,n=="reverse"?g:-g,0);}}
