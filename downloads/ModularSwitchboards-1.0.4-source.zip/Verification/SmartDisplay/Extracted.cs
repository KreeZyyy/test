using System;using System.Xml.Serialization;using Assets.Scripts.Objects.Electrical;
namespace ModularSwitchboards{
    public sealed class SmartModuleSaveData:LogicBaseSaveData
    {
        [XmlElement]public PlacementBoardStructureSaveData RailBoard;
        [XmlElement]public int CodeError;
        [XmlElement]public ulong LastEditor;
        [XmlElement]public bool CustomDisplayText;
        [XmlElement]public int DisplayColor=(int)ColorType.Green;
    }
public partial class SmartModule:LogicDisplay {
public PlacementBoard Board; public ulong LastEditedBy; private int codeError;
private SmartRunState runStatus; private int statusErrorLine=-1;
private bool customDisplayText;private int displayColor=(int)ColorType.Green; private string statusText; private char[] statusGlyphs;
public ProgrammableChip Chip; internal SmartRunState RunStatus=>!Powered||!OnOff?SmartRunState.Off:runStatus;
internal void Render(SmartRunState state,int line=-1){runStatus=state;statusErrorLine=line;RefreshStatusDisplay();}
public void ClearError(){}
public bool HasCustom=>customDisplayText;
        private void RefreshStatusDisplay()
        {
            // Fault status always owns the surface. During healthy execution the
            // chip may replace RUN with packed ASCII text written to Setting.
            var state=RunStatus;
            bool custom=state==SmartRunState.Running&&customDisplayText&&Mode!=SmartDisplayModes.AutoRun;
            var swatch=GameManager.GetColorSwatch(state==SmartRunState.Fault?(int)ColorType.Orange:custom?displayColor:(int)ColorType.Green);
            if(swatch?.Emissive!=null)DigitOn=swatch.Emissive;
            var text=SmartStatusDisplay.Text(state,statusErrorLine,custom?SmartNativeDisplayText.Read(this):null);
            if(custom)
                text=SmartStatusDisplay.Fit(text,(int)(MaxPixelWidth/GameManager.DigitPixel),ch=>{var glyph=GameManager.GetDigitMesh(ch);return glyph==null?-1:glyph.PixelWidth+1;},Mode==SmartDisplayModes.String);
            if(text!=statusText){statusText=text;statusGlyphs=text.ToCharArray();}
            SetDisplay(statusGlyphs);
        }
        private void SetCustomDisplayText(bool enabled)
        {
            if(customDisplayText==enabled)return;
            customDisplayText=enabled;
            if(NetworkManager.IsServer)NetworkUpdateFlags|=512;
        }
        public override void BuildUpdate(RocketBinaryWriter writer,ushort type){base.BuildUpdate(writer,type);if(Thing.IsNetworkUpdateRequired(512u,type)){writer.WriteByte((byte)runStatus);writer.WriteInt32(statusErrorLine);writer.WriteBoolean(customDisplayText);writer.WriteInt32(displayColor);}}
        public override void ProcessUpdate(RocketBinaryReader reader,ushort type){base.ProcessUpdate(reader,type);if(Thing.IsNetworkUpdateRequired(512u,type)){runStatus=(SmartRunState)reader.ReadByte();statusErrorLine=reader.ReadInt32();customDisplayText=reader.ReadBoolean();displayColor=reader.ReadInt32();}}
        public override bool CanLogicRead(LogicType type)=>type==LogicType.Color||type==LogicType.Mode||type==LogicType.LineNumber||base.CanLogicRead(type);
        public override bool CanLogicWrite(LogicType type)=>type==LogicType.Color||type==LogicType.Mode||type==LogicType.LineNumber||base.CanLogicWrite(type);
        public override double GetLogicValue(LogicType type)=>type==LogicType.Color?displayColor:type==LogicType.LineNumber?(Chip==null?-1:Chip.LineNumber):base.GetLogicValue(type);
        public override void SetLogicValue(LogicType type,double value)
        {
            if(type==LogicType.Color)
            {
                if(!double.IsNaN(value)&&!double.IsInfinity(value)&&value>=int.MinValue&&value<=int.MaxValue&&GameManager.IsValidColor((int)value))
                {
                    displayColor=(int)value;
                    if(NetworkManager.IsServer)NetworkUpdateFlags|=512;
                }
                return;
            }
            if(type==LogicType.Mode&&value==SmartDisplayModes.AutoRun)SetCustomDisplayText(false);
            if(type==LogicType.Setting)SetCustomDisplayText(true);
            if(type==LogicType.LineNumber){if(Chip!=null)Chip.LineNumber=(uint)value;}
            else base.SetLogicValue(type,value);
        }
        public void SetSourceCode(string source){if(Chip!=null){SetCustomDisplayText(false);Chip.SetSourceCode(source,this);Chip.SendUpdate();}}
        public override void OnChildEnterInventory(DynamicThing child){base.OnChildEnterInventory(child);if(GameManager.RunSimulation&&child is ProgrammableChip){SetCustomDisplayText(false);Chip.Reset();ClearError();}}        public override ThingSaveData SerializeSave(){ThingSaveData data=new SmartModuleSaveData();InitialiseSaveData(ref data);return data;}
        protected override void InitialiseSaveData(ref ThingSaveData data){base.InitialiseSaveData(ref data);if(data is SmartModuleSaveData save){if(Board!=null)save.RailBoard=BoardStructureHooks.SerializeSave(this);save.CodeError=codeError;save.LastEditor=LastEditedBy;save.CustomDisplayText=customDisplayText;save.DisplayColor=displayColor;}}
        public override void DeserializeSave(ThingSaveData data){base.DeserializeSave(data);if(data is SmartModuleSaveData save){codeError=save.CodeError;LastEditedBy=save.LastEditor;customDisplayText=save.CustomDisplayText;displayColor=GameManager.IsValidColor(save.DisplayColor)?save.DisplayColor:(int)ColorType.Green;if(save.RailBoard!=null)BoardStructureHooks.DeserializeSave(this,save.RailBoard);}else if(data is DinBreakerSaveData old){OnOff=true;if(old.RailBoard!=null)BoardStructureHooks.DeserializeSave(this,old.RailBoard);}}
        public override void SerializeOnJoin(RocketBinaryWriter writer){base.SerializeOnJoin(writer);BoardStructureHooks.SerializeOnJoin(writer,this);writer.WriteInt32(codeError);writer.WriteByte((byte)RunStatus);writer.WriteInt32(statusErrorLine);writer.WriteBoolean(customDisplayText);writer.WriteInt32(displayColor);}
        public override void DeserializeOnJoin(RocketBinaryReader reader){base.DeserializeOnJoin(reader);BoardStructureHooks.DeserializeOnJoin(reader,this);codeError=reader.ReadInt32();runStatus=(SmartRunState)reader.ReadByte();statusErrorLine=reader.ReadInt32();customDisplayText=reader.ReadBoolean();displayColor=reader.ReadInt32();}
}}