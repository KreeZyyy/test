using System;using System.Linq;using System.IO;using System.Globalization;using System.Xml.Serialization;using ModularSwitchboards;using Assets.Scripts.Objects.Electrical;
class Program{
 static int n;static void Check(bool v,string why){n++;if(!v)throw new Exception(why);}
 static double Pack(string s){long v=0;foreach(char c in s)v=(v<<8)|(byte)c;return v;}
 static void Main(){
 var m=new SmartModule{Board=new(){Id=23},Powered=true,OnOff=true};
 m.Setting=12345;m.Render(SmartRunState.Running);Check(m.Drawn=="RUN","legacy Setting incorrectly displayed without explicit write");
 Check(m.CanLogicRead(LogicType.Mode)&&m.CanLogicWrite(LogicType.Mode)&&m.CanLogicWrite(LogicType.Color),"Mode/Color contract");
 m.SetLogicValue(LogicType.Mode,0);m.Render(SmartRunState.Running);Check(m.Drawn=="RUN","mode alone should not display stale Setting");
 m.SetLogicValue(LogicType.Setting,42.5);m.Render(SmartRunState.Running);Check(m.Drawn=="42.5"&&m.DigitOn==ColorType.Green,"number not displayed green");
 m.SetLogicValue(LogicType.Setting,0);m.Render(SmartRunState.Running);Check(m.Drawn=="0","numeric zero is not RUN");
 m.SetLogicValue(LogicType.Mode,10);m.SetLogicValue(LogicType.Setting,Pack("HELLO"));m.Render(SmartRunState.Running);Check(m.Drawn=="HELLO","STR/Lua packed text not displayed");
 m.Render(SmartRunState.Fault,4);Check(m.Drawn=="ERR4"&&m.DigitOn==ColorType.Orange,"error did not override text");
 m.SetLogicValue(LogicType.Setting,Pack("WORLD"));m.Render(SmartRunState.Fault,4398);Check(m.Drawn=="ERR---","program hid long error row");
 m.Render(SmartRunState.Running);Check(m.Drawn=="WORLD"&&m.DigitOn==ColorType.Green,"value did not recover after error");
 m.Powered=false;m.Render(SmartRunState.Running);Check(m.Drawn=="","power off did not blank text");m.Powered=true;
 var saved=m.SerializeSave();var ser=new XmlSerializer(typeof(SmartModuleSaveData));var xml=new StringWriter();ser.Serialize(xml,saved);var loaded=new SmartModule{Powered=true};loaded.DeserializeSave((ThingSaveData)ser.Deserialize(new StringReader(xml.ToString())));loaded.Render(SmartRunState.Running);
 Check(loaded.Drawn=="WORLD"&&loaded.Board.Id==23&&loaded.HasCustom,"save lost custom text/mount");
 var oldXml=xml.ToString().Replace("<CustomDisplayText>true</CustomDisplayText>","");var old=new SmartModule{Powered=true};old.DeserializeSave((ThingSaveData)ser.Deserialize(new StringReader(oldXml)));old.Render(SmartRunState.Running);Check(old.Drawn=="RUN","old save enabled custom display");
 using(var stream=new MemoryStream()){
 var w=new RocketBinaryWriter(stream);m.SerializeOnJoin(w);w.WriteInt32(123456);stream.Position=0;var r=new RocketBinaryReader(stream);var client=new SmartModule{Powered=true};client.DeserializeOnJoin(r);client.Render(SmartRunState.Running);Check(client.Drawn=="WORLD"&&r.ReadInt32()==123456,"join lost custom flag/value or framing");}
 using(var stream=new MemoryStream()){
 var w=new RocketBinaryWriter(stream);m.BuildUpdate(w,512);w.WriteInt32(123456);stream.Position=0;var r=new RocketBinaryReader(stream);var client=new SmartModule{Powered=true};client.ProcessUpdate(r,512);client.Render(SmartRunState.Running);Check(client.Drawn=="WORLD"&&r.ReadInt32()==123456,"live update flag/value or framing");}
 m.SetLogicValue(LogicType.Mode,SmartDisplayModes.AutoRun);m.Render(SmartRunState.Running);Check(m.Drawn=="RUN"&&!m.HasCustom,"Automatic RUN mode did not reset RUN");
 m.SetLogicValue(LogicType.Mode,0);m.SetLogicValue(LogicType.Setting,-12.5);m.Render(SmartRunState.Running);Check(m.Drawn=="-12.5","negative number lost");
 m.SetLogicValue(LogicType.Mode,10);m.SetLogicValue(LogicType.Setting,Pack("WWWWWW"));m.Render(SmartRunState.Running);Check(m.Drawn=="WWWW","wide glyph text overflow");
 m.SetLogicValue(LogicType.Setting,double.NaN);m.Render(SmartRunState.Running);Check(m.Drawn=="RUN","invalid packed value crashed/drew garbage");
 m.SetLogicValue(LogicType.Setting,Pack("HELLO"));m.Chip=new ProgrammableChip();m.SetSourceCode("new program");m.Render(SmartRunState.Running);Check(m.Drawn=="RUN","new program inherited old custom text");
 m.Render(SmartRunState.Idle);Check(m.Drawn=="IDLE","idle state changed");
 m.SetLogicValue(LogicType.Mode,4);m.SetLogicValue(LogicType.Setting,23);m.Render(SmartRunState.Running);Check(m.Drawn=="23°C","native unit format was not reused");
 m.SetLogicValue(LogicType.Mode,1);m.SetLogicValue(LogicType.Setting,0.5);m.Render(SmartRunState.Running);Check(m.Drawn=="50%","native percent format was not reused");
 m.SetLogicValue(LogicType.Color,2);m.Render(SmartRunState.Running);Check(m.DigitOn==ColorType.Blue&&m.GetLogicValue(LogicType.Color)==2,"custom LED color failed");
 m.Render(SmartRunState.Fault,1);Check(m.DigitOn==ColorType.Orange&&m.Drawn=="ERR1","custom Color hid fault");m.Render(SmartRunState.Running);Check(m.DigitOn==ColorType.Blue,"custom Color not restored");
 var coloured=(SmartModuleSaveData)m.SerializeSave();Check(coloured.DisplayColor==2,"display Color not saved");
 m.SetLogicValue(LogicType.Setting,Pack("HELLO"));m.OnChildEnterInventory(m.Chip);m.Render(SmartRunState.Running);Check(m.Drawn=="RUN","replacement chip inherited text");
 using(var stream=new MemoryStream()){
 m.SetLogicValue(LogicType.Mode,0);m.SetLogicValue(LogicType.Setting,42);m.SetLogicValue(LogicType.Color,2);m.Render(SmartRunState.Running);
 var writer=new RocketBinaryWriter(stream);m.BuildUpdate(writer,512);stream.Position=0;var client=new SmartModule{Powered=true};client.ProcessUpdate(new RocketBinaryReader(stream),512);client.Render(SmartRunState.Running);Check(client.DigitOn==ColorType.Blue&&client.Drawn=="42","custom colour not replicated");
 }
 Check(SmartDisplayModes.Names.Take(LogicDisplay.DisplayModeStrings.Length).SequenceEqual(LogicDisplay.DisplayModeStrings),"native LED mode indices changed");
 Check(SmartDisplayModes.Names.Length==18&&SmartDisplayModes.String==10&&SmartDisplayModes.Number==0,"F1 mode table");
 Console.WriteLine(n+" integrated Smart display checks passed: numbers, zero, text, error priority/recovery, old/new saves, network/join framing and clipping.");
 }
}
namespace ModularSwitchboards{
 public class ThingSaveData{public bool OnOff;public int Mode;}
 public class LogicBaseSaveData:ThingSaveData{public double Setting;}
 public class PlacementBoardStructureSaveData{public int Id;}
 public class PlacementBoard{public int Id;}
 public class DinBreakerSaveData:ThingSaveData{public PlacementBoardStructureSaveData RailBoard;}
 public enum LogicType{Mode,Color,Setting,LineNumber}
 public enum ColorType{Green,Orange,Blue}
 public static class NetworkManager{public static bool IsServer=true;}
 public static class GameManager{public static bool RunSimulation=true;public static bool IsValidColor(int c)=>c>=0&&c<=2;public static float DigitPixel=1;public static Swatch GetColorSwatch(int c)=>new(){Emissive=(ColorType)c};public static Glyph GetDigitMesh(char c)=>new(){PixelWidth=c=='W'?6:4};}
 public class Swatch{public ColorType Emissive;}
 public class Glyph{public int PixelWidth;}
 public class DynamicThing{}
 public class ProgrammableChip:DynamicThing{public uint LineNumber;public void SetSourceCode(string code,SmartModule holder){}public void SendUpdate(){}public void Reset(){}public static string UnpackAscii6(double value,bool signed){ulong v=(ulong)value;string s="";while(v>0){s=(char)(v&255)+s;v>>=8;}return s;}}
 public static class NativeFormat{public static string ToStringDisplay(this double v,int digits,int exp)=>v.ToString("G6",CultureInfo.InvariantCulture);}
 public static class Thing{public static bool IsNetworkUpdateRequired(uint f,ushort t)=>(t&f)!=0;}
 public class RocketBinaryWriter:BinaryWriter{public RocketBinaryWriter(Stream s):base(s){}public void WriteInt32(int v)=>Write(v);public void WriteByte(byte b)=>Write(b);public void WriteBoolean(bool b)=>Write(b);}
 public class RocketBinaryReader:BinaryReader{public RocketBinaryReader(Stream s):base(s){}}
 public static class BoardStructureHooks{
 public static PlacementBoardStructureSaveData SerializeSave(SmartModule m)=>new(){Id=m.Board.Id};
 public static void DeserializeSave(SmartModule m,PlacementBoardStructureSaveData d)=>m.Board=new(){Id=d.Id};
 public static void SerializeOnJoin(RocketBinaryWriter w,SmartModule m)=>w.WriteInt32(m.Board.Id);
 public static void DeserializeOnJoin(RocketBinaryReader r,SmartModule m)=>m.Board=new(){Id=r.ReadInt32()};}
}
