using System;using System.Globalization;using ModularSwitchboards;
namespace Assets.Scripts.Objects.Electrical{ public class LogicDisplay{
 public static string[] DisplayModeStrings={"Default","Percent","Power","Kelvin","Celsius","Meters","Credits","Seconds","Minutes","Days","String","Fahrenheit","Litres","Mol","Pa","Newtons","Degrees"};
 private char[] _displayString;public bool OnOff=true,Powered;public double Setting;public int Mode,StandardDigitMax=99999,ExpDigits=2,NetworkUpdateFlags;public float MaxPixelWidth=30;public string Drawn;public ColorType DigitOn;
 public virtual void OnChildEnterInventory(DynamicThing child){}
 public virtual bool CanLogicRead(LogicType t)=>t!=LogicType.LineNumber;public virtual bool CanLogicWrite(LogicType t)=>t!=LogicType.LineNumber;
 public virtual double GetLogicValue(LogicType t)=>t==LogicType.Setting?Setting:Mode;
 public virtual void SetLogicValue(LogicType t,double v){if(t==LogicType.Setting)Setting=v;if(t==LogicType.Mode)Mode=(int)v;Format();}
 public void SetDisplay(char[] text)=>Drawn=new string(text);
 private void Format(){_displayString=(Mode==10?(!double.IsNaN(Setting)&&Setting>=0&&Setting<281474976710656d?ProgrammableChip.UnpackAscii6(Setting,true):""):Mode==1?(Setting*100).ToString(CultureInfo.InvariantCulture)+"%":Mode==4?Setting.ToString(CultureInfo.InvariantCulture)+"°C":Setting.ToString("G6",CultureInfo.InvariantCulture)).ToCharArray();}
 public virtual void BuildUpdate(RocketBinaryWriter w,ushort type){w.Write(Setting);w.Write(Mode);}
 public virtual void ProcessUpdate(RocketBinaryReader r,ushort type){Setting=r.ReadDouble();Mode=r.ReadInt32();Format();}
 public virtual ThingSaveData SerializeSave()=>null;
 protected virtual void InitialiseSaveData(ref ThingSaveData d){d.OnOff=OnOff;d.Mode=Mode;((LogicBaseSaveData)d).Setting=Setting;}
 public virtual void DeserializeSave(ThingSaveData d){OnOff=d.OnOff;Mode=d.Mode;if(d is LogicBaseSaveData b)Setting=b.Setting;Format();}
 public virtual void SerializeOnJoin(RocketBinaryWriter w){w.Write(Setting);w.Write(Mode);w.Write(OnOff);}
 public virtual void DeserializeOnJoin(RocketBinaryReader r){Setting=r.ReadDouble();Mode=r.ReadInt32();OnOff=r.ReadBoolean();Format();}}
}
namespace HarmonyLib{static class AccessTools{public static System.Reflection.FieldInfo Field(Type t,string name)=>t.GetField(name,System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic);}}