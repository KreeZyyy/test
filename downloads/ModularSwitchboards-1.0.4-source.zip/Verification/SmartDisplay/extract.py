from pathlib import Path
r=Path(__file__).resolve().parents[2];s=(r/'Source/SmartModule.cs').read_text()
def span(a,b): return s[s.index(a):s.index(b,s.index(a))]
dto=span('    public sealed class SmartModuleSaveData','    // One IC')
methods=span('        private void RefreshStatusDisplay()','        public override void OnSettingChanged()')+span('        private void SetCustomDisplayText(','        public override PassiveTooltip')+span('        public override void BuildUpdate(','        private float nextLink;')+span('        public override bool CanLogicRead(LogicType','        // Native housing stack contract:')+span('        public void SetSourceCode(', '        public void Execute()')+'\n'.join(line for line in s.splitlines() if line.strip().startswith('public override void OnChildEnterInventory('))+s[s.index('        public override ThingSaveData SerializeSave()'):s.rindex('    }')]
fields='''public partial class SmartModule:LogicDisplay {
public PlacementBoard Board; public ulong LastEditedBy; private int codeError;
private SmartRunState runStatus; private int statusErrorLine=-1;
private bool customDisplayText;private int displayColor=(int)ColorType.Green; private string statusText; private char[] statusGlyphs;
public ProgrammableChip Chip; internal SmartRunState RunStatus=>!Powered||!OnOff?SmartRunState.Off:runStatus;
internal void Render(SmartRunState state,int line=-1){runStatus=state;statusErrorLine=line;RefreshStatusDisplay();}
public void ClearError(){}
public bool HasCustom=>customDisplayText;
'''
(Path(__file__).parent/'Extracted.cs').write_text('using System;using System.Xml.Serialization;using Assets.Scripts.Objects.Electrical;\nnamespace ModularSwitchboards{\n'+dto+fields+methods+'}}')
