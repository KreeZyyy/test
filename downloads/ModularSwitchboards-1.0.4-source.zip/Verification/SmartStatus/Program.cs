using System;
using ModularSwitchboards;
class Program{
 static int checks;static void Check(bool b){checks++;if(!b)throw new Exception("Status check "+checks);}
 static void Main(){
 Check(SmartStatusDisplay.Text(SmartRunState.Running,-1)=="RUN");
 Check(SmartStatusDisplay.Text(SmartRunState.Fault,4)=="ERR4");
 Check(SmartStatusDisplay.Text(SmartRunState.Fault,0)=="ERR0");
 Check(SmartStatusDisplay.Text(SmartRunState.Fault,127)=="ERR127");
 Check(SmartStatusDisplay.Text(SmartRunState.Fault,999)=="ERR999");
 Check(SmartStatusDisplay.Text(SmartRunState.Fault,1000)=="ERR---");
 Check(SmartStatusDisplay.Text(SmartRunState.Fault,4398)=="ERR---");
 Check(SmartStatusDisplay.Text(SmartRunState.Fault,int.MaxValue)=="ERR---");
 Check(SmartStatusDisplay.LuaLine("Compile error: [string \"script\"]:4398: syntax error")==4398);
 Check(SmartStatusDisplay.Text(SmartRunState.Fault,-1)=="ERR");
 Check(SmartStatusDisplay.Text(SmartRunState.Off,4)=="");
 Check(SmartStatusDisplay.Text(SmartRunState.Idle,-1)=="IDLE");
 Check(SmartStatusDisplay.LuaLine("Compile error: [string \"script\"]:12: syntax error near 'db'")==12);
 Check(SmartStatusDisplay.LuaLine("runtime error (line 7)")==7);
 Check(SmartStatusDisplay.LuaLine("38 bytes; runtime unavailable")==-1);
 Check(SmartStatusDisplay.LuaLine(null)==-1);
 Check(SmartRunStatus.Evaluate(false,true,true,true,true,true,false)==SmartRunState.Off);
 Check(SmartRunStatus.Evaluate(true,true,true,true,true,true,false)==SmartRunState.Fault);
 Check(SmartRunStatus.Evaluate(true,true,true,false,true,true,false)==SmartRunState.Running);
 Check(SmartRunStatus.Evaluate(true,true,false,false,false,false,false)==SmartRunState.Idle);
 Check(SmartStatusDisplay.Text(SmartRunState.Running,-1,"HELLO")=="HELLO");
 Check(SmartStatusDisplay.Text(SmartRunState.Running,-1,"")=="RUN");
 Check(SmartStatusDisplay.Text(SmartRunState.Running,-1,"   ")=="RUN");
 Check(SmartStatusDisplay.Text(SmartRunState.Fault,4,"HELLO")=="ERR4");
 Check(SmartStatusDisplay.Text(SmartRunState.Fault,4398,"HELLO")=="ERR---");
 Check(SmartStatusDisplay.Text(SmartRunState.Off,-1,"HELLO")=="");
 Check(SmartStatusDisplay.Text(SmartRunState.Idle,-1,"HELLO")=="IDLE");
 Check(SmartStatusDisplay.Text(SmartRunState.Running,-1,"ABCDEFG")=="ABCDEFG");
 Check(SmartStatusDisplay.Text(SmartRunState.Running,-1,"23°C")=="23°C");
 Check(SmartStatusDisplay.Fit("WWWWWW",30,c=>7)=="WWWW");
 Check(SmartStatusDisplay.Fit("HELLO",30,c=>5)=="HELLO");
 Check(SmartStatusDisplay.Fit("123456789",30,c=>5,false)=="OVR");
 Console.WriteLine(checks+" housing status display checks passed: RUN/ERR/row/idle/power and optional Lua line parsing.");
 }
}
