using System;
using System.Linq;
using System.Collections.Generic;
using Assets.Scripts.Networks;
using Assets.Scripts.Objects.Electrical;
using Assets.Scripts.Objects.Pipes;
using ModularSwitchboards;
static class Program {
 static int checks;
 static void Check(bool v,string why){checks++;if(!v)throw new Exception(why);}
 static CabinetWireSaveData W(long a,int p,long b,int q)=>new(){From=new(a,p),To=new(b,q)};
 static void Main(){
 var cab=new Cabinet();var module=new SmartModule{ReferenceId=10,Cabinet=cab};cab.Wiring=new CabinetWiring{Owner=cab};var w=cab.Wiring;
 var a=cab.InputConnection.cable;var b=cab.Output1Connection.cable;var c=cab.Output2Connection.cable;var d=cab.Output3Connection.cable;
 foreach(var cable in new[]{a,b,c,d})cable.CableNetwork=new CableNetwork();
 var protector=new Breaker{ReferenceId=20,Conducting=true};w.Breakers=new[]{protector};
 for(int output=1;output<=3;output++){
  w.CircuitWires=new[]{W(0,0,20,0),W(20,1,10,0),W(20,1,0,output)};
  var expected=new[]{b,c,d}[output-1];SmartModuleNetwork.Refresh(module);
  Check(module.BoundCable==expected,"wrong output cable "+output);
  Check(expected.CableNetwork.DataDeviceList.Contains(module),"computer cannot discover Smart on output "+output);
  Check(!a.CableNetwork.DataDeviceList.Contains(module),"Smart leaked to Input");
  Check(new[]{b,c,d}.Where(x=>x!=expected).All(x=>!x.CableNetwork.DataDeviceList.Contains(module)),"Smart leaked into another output");
  Check(module.DataCable==expected&&module.PowerCable==expected&&module.PowerCables.Single()==expected&&module.DataCables.Single()==expected,"native connection arrays disagree");
 }
 w.CircuitWires=new[]{W(0,0,10,0),W(0,0,20,0),W(20,1,0,2)};SmartModuleNetwork.Refresh(module);Check(module.BoundCable==a,"before protection should bind Input");
 w.CircuitWires=new[]{W(0,0,20,0),W(20,1,10,0),W(20,1,0,2)};SmartModuleNetwork.Refresh(module);Check(module.BoundCable==c,"after protection should bind Output2");
 protector.Conducting=false;SmartModuleNetwork.Refresh(module);Check(module.BoundCable==c,"upstream trip must not migrate to Input");
 c.CableNetwork.RemoveDevice(module);SmartModuleNetwork.Refresh(module);Check(c.CableNetwork.DataDeviceList.Contains(module),"native re-registration missing after device list rebuild");
 var old=c.CableNetwork; c.CableNetwork=new CableNetwork();SmartModuleNetwork.Refresh(module);Check(module.BoundNetwork==c.CableNetwork&&!old.DataDeviceList.Contains(module)&&c.CableNetwork.DataDeviceList.Contains(module),"same cable network rebuild not handled");
 w.CircuitWires=new[]{W(0,0,20,0),W(20,1,10,0),W(20,1,0,1),W(20,1,0,2)};SmartModuleNetwork.Refresh(module);Check(module.BoundNetwork==null&&new[]{a,b,c,d}.All(x=>!x.CableNetwork.DataDeviceList.Contains(module)),"ambiguous output networks must detach");
 b.CableNetwork=c.CableNetwork;SmartModuleNetwork.Refresh(module);Check(module.BoundNetwork==b.CableNetwork,"same native output network should remain valid");
 w.CircuitWires=Array.Empty<CabinetWireSaveData>();SmartModuleNetwork.Refresh(module);Check(module.BoundNetwork==null&&module.DataCable==null&&module.PowerCable==null&&module.DataCables.Length==0&&module.PowerCables.Length==0,"unwired module retained network");
 w.CircuitWires=new[]{W(0,0,20,0),W(20,1,10,0)};SmartModuleNetwork.Refresh(module);Check(module.BoundNetwork==null,"protected dangling IN invented an external branch");
 w.CircuitWires=new[]{W(0,0,10,0)};SmartModuleNetwork.Refresh(module);Check(module.BoundCable==a,"single direct Input tap must work without OUT");
 Check(!WireCircuit.Reachable(new(10,0),new(10,1),w.CircuitWires,w.Breakers.Where(x=>x.Conducting).Select(x=>x.ReferenceId)),"Smart became a pass-through device");
 w.CircuitWires=new[]{W(0,0,20,0),W(20,1,30,2),W(30,2,30,3),W(30,3,10,0),W(30,3,0,3)};SmartModuleNetwork.Refresh(module);Check(module.BoundCable==d,"IN branch through neutral bridge selected wrong output");
 Check(module.OutputNetwork1==null,"consumer exposes a nonexistent OUT network");
 w.CircuitWires=Array.Empty<CabinetWireSaveData>();SmartModuleNetwork.Refresh(module);
 Check(module.PowerClears>0,"unlink did not clear native power state");SmartModuleNetwork.Unbind(module);SmartModuleNetwork.Unbind(module);
 var bound=module.BoundNetwork;
 w.CircuitWires=new[]{W(0,0,10,0)};SmartModuleNetwork.Refresh(module);bound=module.BoundNetwork;
 bound.DeviceList.Add(module);bound.DeviceList.Add(module);
 SmartModuleNetwork.Refresh(module);
 Check(bound.DeviceList.Count(x=>ReferenceEquals(x,module))==1,"duplicate Smart registration survived refresh");
 Check(bound.GetDeviceRegistration(module)?.Contains(module.BoundCable)==true,"deduplication lost cable registration");
 Check(bound.Refreshes==1,"computer was not notified after duplicate cleanup");
 SmartModuleNetwork.Refresh(module);Check(bound.Refreshes==1,"clean network repeatedly notified");
 Console.WriteLine(checks+" Smart network checks passed: native computer visibility, Input/3 Outputs, protection, isolation, ambiguity, rebuild and unlink.");
 }
}
namespace HarmonyLib { static class AccessTools {public static System.Reflection.PropertyInfo Property(Type t,string n)=>t.GetProperty(n);} }
namespace Assets.Scripts.Objects.Electrical {class Cable {public CableNetwork CableNetwork;}}
namespace Assets.Scripts.Objects.Pipes {class Device {public Cable DataCable;public Cable PowerCable{get;private set;}public Cable[] PowerCables{get;private set;}=Array.Empty<Cable>();public Cable[] DataCables{get;private set;}=Array.Empty<Cable>(); public CableNetwork InputNetwork1,OutputNetwork1;}}
namespace Assets.Scripts.Networks {class CableNetwork {public List<Device> DataDeviceList=new();public List<Device> DeviceList=>DataDeviceList;public int Refreshes;public void DirtyPowerAndDataDeviceLists(){}public void RefreshNetworkDevice(Device device){Refreshes++;}public Dictionary<Device,HashSet<Cable>> Registered=new();public HashSet<Cable> GetDeviceRegistration(Device module)=>Registered.GetValueOrDefault(module);public void AddDevice(Cable cable,Device module){Registered[module]=new(){cable};if(module.DataCables.Contains(cable)&&!DataDeviceList.Contains(module))DataDeviceList.Add(module);}public void RemoveDevice(Device module){Registered.Remove(module);DataDeviceList.Remove(module);if(module is SmartModule s)s.PowerClears++;}}}
namespace ModularSwitchboards {
 class SmartModule:Device {public long ReferenceId;public Cabinet Cabinet;public Cable BoundCable;public CableNetwork BoundNetwork;public int PowerClears;}
 class Breaker {public long ReferenceId;public bool Conducting,IsAnalyserModule,IsBatteryModule,IsDoorPart;}
 class Port {public Cable cable=new();public Cable GetCable()=>cable;}
 class Cabinet {public bool IsCursor,IsStructureCompleted=true;public object GridController=new();public Port InputConnection=new(),Output1Connection=new(),Output2Connection=new(),Output3Connection=new();public CabinetWiring Wiring;}
 partial class CabinetWiring {public Cabinet Owner;public IEnumerable<Breaker> Breakers=Array.Empty<Breaker>();public IEnumerable<CabinetWireSaveData> CircuitWires=Array.Empty<CabinetWireSaveData>();public IEnumerable<long> SmartIds=>new long[]{10};}
}
