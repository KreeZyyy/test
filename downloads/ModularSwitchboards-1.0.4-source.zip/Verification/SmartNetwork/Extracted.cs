using System.Linq;
namespace ModularSwitchboards {
internal partial class CabinetWiring {
        internal Assets.Scripts.Objects.Electrical.Cable SmartCable(SmartModule module)
        {
            if(Owner==null||Owner.IsCursor||!Owner.IsStructureCompleted||Owner.GridController==null)return null;
            var modules=Breakers.ToArray();
            int selection=SmartCircuit.Selection(module.ReferenceId,CircuitWires,
                modules.Where(b=>b.Conducting).Select(b=>b.ReferenceId),
                modules.Where(b=>!b.IsAnalyserModule&&!b.IsBatteryModule&&!b.IsDoorPart).Select(b=>b.ReferenceId));
            if(selection==AnalyserCircuit.Input)return Owner.InputConnection?.GetCable();
            if(selection==0)return null;
            var cables=new[]{Owner.Output1Connection,Owner.Output2Connection,Owner.Output3Connection}
                .Select((port,i)=>new{port,bit=i==2?8:1<<i}).Where(p=>(selection&p.bit)!=0)
                .Select(p=>p.port?.GetCable()).ToArray();
            // Register the real device on exactly one native network. Never bridge
            // unrelated output data networks through the internal module.
            if(cables.Select(c=>c?.CableNetwork).Distinct().Count()!=1)return null;
            return cables.FirstOrDefault(c=>c!=null&&c.CableNetwork!=null);
        }

}}
