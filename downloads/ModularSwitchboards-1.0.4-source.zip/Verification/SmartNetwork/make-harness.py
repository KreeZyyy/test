from pathlib import Path
root=Path(__file__).resolve().parents[2]
s=(root/'Source/CabinetWiring.cs').read_text()
a=s.index('        internal Assets.Scripts.Objects.Electrical.Cable SmartCable(')
b=s.index('        private IEnumerable<CabinetWireSaveData>',a)
header='''using System.Linq;
namespace ModularSwitchboards {
internal partial class CabinetWiring {
'''
(root/'Verification/SmartNetwork/Extracted.cs').write_text(header+s[a:b]+'}}\n')
