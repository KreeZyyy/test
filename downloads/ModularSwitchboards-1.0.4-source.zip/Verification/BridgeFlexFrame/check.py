"""Checks production-generated flex centre lines against the real frame/housing triangles.
Run Wiring with BRIDGE_FLEX_EXPORT first, then pass that JSON path here.
Contact lead intervals at either end are excluded; terminal bodies bury those leads.
"""
import numpy as np,struct,json,sys
from pathlib import Path
root=Path(__file__).resolve().parents[2]
f=open(root/'Assets/Cabinet.meshbin','rb');assert f.read(4)==b'SBMS';ver,mc,n=struct.unpack('<iii',f.read(12));f.read(mc*24);triangles=[]
for k in range(2):
 count=struct.unpack('<i',f.read(4))[0];v=np.frombuffer(f.read(count*24),dtype='<f4').reshape(-1,6)[:,:3].copy();v[:,:2]*=2
 for role in range(mc):
  count=struct.unpack('<i',f.read(4))[0];ids=np.frombuffer(f.read(count*4),dtype='<i4');triangles.extend(v[ids.reshape(-1,3)])
t=np.array(triangles);e1=t[:,1]-t[:,0];e2=t[:,2]-t[:,0]
def hit(a,b):
 direction=b-a;h=np.cross(direction,e2);det=np.einsum('ij,ij->i',e1,h);ok=np.abs(det)>1e-10;inv=np.divide(1,det,out=np.zeros_like(det),where=ok);s=a-t[:,0];u=inv*np.einsum('ij,ij->i',s,h);q=np.cross(s,e1);v=inv*np.einsum('j,ij->i',direction,q);distance=inv*np.einsum('ij,ij->i',e2,q)
 return np.any(ok&(u>=0)&(v>=0)&(u+v<=1)&(distance>1e-5)&(distance<.99999))
cases=json.loads(Path(sys.argv[1]).read_text());checks=0
# Both centre line and axis offsets at the actual cable radius. This samples
# the tube envelope; it does not replace a Unity mesh collision/visual check.
shifts=[np.zeros(3),*[np.eye(3)[k]*sign*.0024 for k in range(3) for sign in [-1,1]]]
for case in cases:
 points=np.array(case['Points'])
 for i in range(2,len(points)-1):
  for shift in shifts:
   assert not hit(points[i]+shift,points[i+1]+shift),f"Frame crossing: {case['Right']}/{case['Angle']}/{i}"
   checks+=1
# Read actual Door mesh (index3), stretch/mirror/rotate exactly as MediumGeometry.
f=open(root/'Assets/Cabinet.meshbin','rb');f.read(4);ver,mc,n=struct.unpack('<iii',f.read(12));f.read(mc*24)
for k in range(4):
 count=struct.unpack('<i',f.read(4))[0];verts=np.frombuffer(f.read(count*24),dtype='<f4').reshape(-1,6)[:,:3].copy();groups=[]
 for role in range(mc):
  count=struct.unpack('<i',f.read(4))[0];groups.append(np.frombuffer(f.read(count*4),dtype='<i4'))
for case in cases:
 m=1 if case['Right'] else -1;a=m*case['Angle']*np.pi/180;c=np.cos(a);s=np.sin(a)
 v=verts.copy();v[:,1]*=2
 if m==1:v[:,0]*=-1
 v=v@np.array([[c,0,-s],[0,1,0],[s,0,c]])+np.array([m*.4,0,.187])
 t=np.concatenate([v[g.reshape(-1,3)] for g in groups]);e1=t[:,1]-t[:,0];e2=t[:,2]-t[:,0]
 points=np.array(case['Points'])
 for i in range(len(points)-1):
  for shift in shifts:
   assert not hit(points[i]+shift,points[i+1]+shift),f"Door crossing: {case['Right']}/{case['Angle']}/{i}"
   checks+=1
print(f'Medium bridge: {len(cases)} mirrored poses, {checks} centre/envelope segment checks clear against actual frame and moving door triangles. First two fixed lead segments near the terminal are excluded from frame check; live visual verification remains necessary.')
