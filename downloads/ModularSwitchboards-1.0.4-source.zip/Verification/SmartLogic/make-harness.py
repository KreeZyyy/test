from pathlib import Path
p=Path(__file__).resolve().parents[2];s=(p/'Source/SmartModule.cs').read_text()
a=s.index('    public sealed class SmartModuleSaveData');b=s.index('    // The real native',a)
dto=s[a:b]
methods=s[s.index('        public bool IsValidIndex'):s.index('\n    }\n}',s.index('        public bool IsValidIndex'))]
header='''using System;using System.Linq;using System.Collections.Generic;using System.Xml.Serialization;
namespace ModularSwitchboards {
'''
fields='''public partial class SmartModule:LogicDisplay {
public PlacementBoard Board;public ulong LastEditedBy;private int codeError;
public Chip Chip;public bool IsCursor;public long ReferenceId;
public void TestError(int n){codeError=n;}public int TestError()=>codeError;
'''
(p/'Verification/SmartLogic/Extracted.cs').write_text(header+dto+fields+methods+'}}')
# Real dynamic class and native base are compile checked by the production build.
assert 'SmartModule:LogicDisplay,IPlacementBoardStructure,ICircuitHolder' in s
registry=(p/'Source/SwitchboardsMod.cs').read_text()
assert 'Mod.AddSaveDataType<SmartModuleSaveData>()' in registry
