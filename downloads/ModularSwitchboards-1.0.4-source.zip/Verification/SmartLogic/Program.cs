using System;using System.IO;using System.Linq;using System.Collections.Generic;using System.Xml.Serialization;using ModularSwitchboards;
static class Program {
 static int n;static void Check(bool v,string why){n++;if(!v)throw new Exception(why);}
 static void Main(){
 var smart=new SmartModule{ReferenceId=10,Chip=new Chip(),OnOff=true,Powered=true};
 Check(ReferenceEquals(smart.GetLogicableFromIndex(int.MaxValue),smart),"db must be the actual display-owning module");
 foreach(var type in new[]{LogicType.Setting,LogicType.Mode,LogicType.Color,LogicType.On}){Check(smart.CanLogicRead(type)&&smart.CanLogicWrite(type),"native LED logic unavailable");smart.SetLogicValue(type,42);Check(smart.GetLogicValue(type)==42,"native LED logic not forwarded");}
 smart.SetLogicValue(LogicType.LineNumber,7);Check(smart.Chip.LineNumber==7&&smart.GetLogicValue(LogicType.LineNumber)==7,"chip line not forwarded");
 Check(smart.IsValidIndex(int.MaxValue)&&!smart.IsValidIndex(0),"invented physical selector bindings");
 smart.DataCableNetwork=new();var local=new Device();var other=new Device();Referencable.Items[20]=local;Referencable.Items[30]=other;smart.DataCableNetwork.DataDeviceList.Add(local);
 Check(ReferenceEquals(smart.GetLogicableFromId(20),local)&&smart.GetLogicableFromId(30)==null,"IC10 can reach another branch");
 Check(ReferenceEquals(smart.GetLogicableFromId(10),smart),"direct self ID not available");Check(smart.GetBatchOutput().SequenceEqual(new[]{local}),"batch escaped selected branch");
 smart.SetSourceCode("s db Setting 42");Check(smart.GetSourceCode()=="s db Setting 42"&&smart.Chip.Sends==1,"native chip program/import not forwarded");
 smart.Execute();Check(smart.Chip.Executions==1&&smart.Chip.LastBudget==128,"native IC10 execution not scheduled");
 foreach(int guard in Enumerable.Range(0,6)){
 GameManager.RunSimulation=true;GameManager.GameState=GameState.Running;WorldManager.IsGamePaused=false;smart.IsCursor=false;smart.OnOff=true;smart.Powered=true;smart.Chip.CompilationError=false;
 switch(guard){case 0:GameManager.RunSimulation=false;break;case 1:WorldManager.IsGamePaused=true;break;case 2:smart.Powered=false;break;case 3:smart.OnOff=false;break;case 4:smart.Chip.CompilationError=true;break;case 5:smart.IsCursor=true;break;}
 smart.Execute();Check(smart.Chip.Executions==1,"chip execution bypassed guard "+guard);
 }
 GameManager.RunSimulation=true;WorldManager.IsGamePaused=false;smart.IsCursor=false;
 smart.Board=new(){Id=101,X=30};smart.LastEditedBy=1234567890123;smart.TestError(12);smart.Setting=-123.125;smart.Mode=10;smart.Color=3;smart.OnOff=false;
 var data=smart.SerializeSave();Check(data is SmartModuleSaveData,"wrong dynamic save type");
 var serializer=new XmlSerializer(typeof(World),new[]{typeof(SmartModuleSaveData)});var sw=new StringWriter();serializer.Serialize(sw,new World{Items=new[]{data}});var saved=(World)serializer.Deserialize(new StringReader(sw.ToString()));
 var restored=new SmartModule();restored.DeserializeSave(saved.Items.Single());
 Check(restored.Setting==smart.Setting&&restored.Mode==10&&restored.Color==3&&!restored.OnOff,"native base LED state lost");
 Check(restored.Board.Id==101&&restored.Board.X==30&&restored.LastEditedBy==smart.LastEditedBy&&restored.TestError()==12,"Smart mount/editor/error lost");
 var legacy=new SmartModule();legacy.DeserializeSave(new DinBreakerSaveData{RailBoard=new(){Id=55,X=20}});Check(legacy.Board.Id==55&&legacy.Board.X==20&&legacy.OnOff,".97 mount migration failed");
 using var stream=new MemoryStream();var writer=new RocketBinaryWriter(stream);smart.SerializeOnJoin(writer);writer.WriteInt32(0x12345678);stream.Position=0;var reader=new RocketBinaryReader(stream);var joined=new SmartModule();joined.DeserializeOnJoin(reader);
 Check(joined.Setting==smart.Setting&&joined.Mode==smart.Mode&&joined.Color==smart.Color&&joined.OnOff==smart.OnOff&&joined.Board.Id==101&&joined.Board.X==30&&joined.TestError()==12,"join framing lost native state/mount");Check(reader.ReadInt32()==0x12345678,"Smart join overreads following device");
 Console.WriteLine(n+" Smart logic/persistence checks passed: db/native LED forwarding, branch-scoped IC10, execution guards, native save chaining, XML, legacy mounting and join framing (native base/slot fixture).");
 }
}
public class World {public ThingSaveData[] Items;}
namespace ModularSwitchboards {
 public class ThingSaveData {public int Mode,Color;public bool OnOff;}
 public class LogicBaseSaveData:ThingSaveData {public double Setting;}
 public class PlacementBoardStructureSaveData {public long Id;public int X;}
 public class PlacementBoard {public long Id;public int X;}
 public class DinBreakerSaveData:ThingSaveData {public PlacementBoardStructureSaveData RailBoard;}
 public static class BoardStructureHooks {
 public static PlacementBoardStructureSaveData SerializeSave(SmartModule m)=>new(){Id=m.Board.Id,X=m.Board.X};
 public static void DeserializeSave(SmartModule m,PlacementBoardStructureSaveData s){m.Board=new(){Id=s.Id,X=s.X};}
 public static void SerializeOnJoin(RocketBinaryWriter w,SmartModule m){w.WriteInt32((int)m.Board.Id);w.WriteInt32(m.Board.X);}
 public static void DeserializeOnJoin(RocketBinaryReader r,SmartModule m){m.Board=new(){Id=r.ReadInt32(),X=r.ReadInt32()};}
 }
 public class RocketBinaryWriter:BinaryWriter {public RocketBinaryWriter(Stream s):base(s){}public void WriteInt32(int v)=>Write(v);}
 public class RocketBinaryReader:BinaryReader {public RocketBinaryReader(Stream s):base(s){}}
 public interface ILogicable {}
 public enum LogicType {Setting,Mode,Color,On,LineNumber}
 public class Device:ILogicable {public ILogicable GetNetwork(int i)=>this;}
 public class CableNetwork {public List<Device> DataDeviceList=new();}
 public class LogicBinding {public LogicBinding(string name){}}
 public class UniTask {public static UniTask CompletedTask=>new();}
 public static class GameManager {public static bool RunSimulation=true;public static GameState GameState=GameState.Running;}
 public enum GameState {None,Running}
 public static class WorldManager {public static bool IsGamePaused;}
 public static class Referencable {public static Dictionary<int,Device> Items=new();public static T Find<T>(int id)where T:class=>Items.GetValueOrDefault(id) as T;}
 public static class OnServer {public static void Interact(object i,int s){}}
 public class Chip {public uint LineNumber;public bool CompilationError;public int Sends,Executions,LastBudget;string code="";public string GetSourceCode()=>code;public void SetSourceCode(string s,SmartModule m){code=s;}public void SendUpdate(){Sends++;}public void Execute(int n){Executions++;LastBudget=n;}}
 public class LogicDisplay:Device {
 public bool OnOff,Powered;public int Mode,Color;public double Setting;public CableNetwork DataCableNetwork;public object InteractOnOff=new();readonly Dictionary<LogicType,double> values=new();
 public virtual bool CanLogicRead(LogicType t)=>t!=LogicType.LineNumber;public virtual bool CanLogicWrite(LogicType t)=>t!=LogicType.LineNumber;
 public virtual double GetLogicValue(LogicType t)=>values.GetValueOrDefault(t);public virtual void SetLogicValue(LogicType t,double n){values[t]=n;}
 public virtual ThingSaveData SerializeSave(){ThingSaveData d=new LogicBaseSaveData();InitialiseSaveData(ref d);return d;}
 protected virtual void InitialiseSaveData(ref ThingSaveData d){d.OnOff=OnOff;d.Mode=Mode;d.Color=Color;if(d is LogicBaseSaveData l)l.Setting=Setting;}
 public virtual void DeserializeSave(ThingSaveData d){OnOff=d.OnOff;Mode=d.Mode;Color=d.Color;if(d is LogicBaseSaveData l)Setting=l.Setting;}
 public virtual void SerializeOnJoin(RocketBinaryWriter w){w.Write(Setting);w.Write(Mode);w.Write(Color);w.Write(OnOff);}
 public virtual void DeserializeOnJoin(RocketBinaryReader r){Setting=r.ReadDouble();Mode=r.ReadInt32();Color=r.ReadInt32();OnOff=r.ReadBoolean();}
 }
}
