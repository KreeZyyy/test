using System;using System.Linq;using System.Collections.Generic;using System.Xml.Serialization;
namespace ModularSwitchboards {
    public sealed class SmartModuleSaveData:LogicBaseSaveData
    {
        [XmlElement]public PlacementBoardStructureSaveData RailBoard;
        [XmlElement]public int CodeError;
        [XmlElement]public ulong LastEditor;
    }
public partial class SmartModule:LogicDisplay {
public PlacementBoard Board;public ulong LastEditedBy;private int codeError;
public Chip Chip;public bool IsCursor;public long ReferenceId;
public void TestError(int n){codeError=n;}public int TestError()=>codeError;
        public bool IsValidIndex(int index)=>index==int.MaxValue;
        public ILogicable GetLogicableFromIndex(int index,int networkIndex=int.MinValue)=>index==int.MaxValue?this:null;
        public ILogicable GetLogicableFromId(int id,int networkIndex=int.MinValue)
        {
            if(id==ReferenceId)return this;
            var device=Referencable.Find<Device>(id);
            return device!=null&&DataCableNetwork!=null&&DataCableNetwork.DataDeviceList.Contains(device)?networkIndex==int.MinValue?(ILogicable)device:device.GetNetwork(networkIndex):null;
        }
        public List<ILogicable> GetBatchOutput()=>DataCableNetwork==null?new List<ILogicable>():DataCableNetwork.DataDeviceList.OfType<ILogicable>().ToList();
        public List<LogicBinding> GetLogicBindings()=>new List<LogicBinding>{new LogicBinding("DEVICE")};
        public void SetDeviceLabel(int index,string label){}
        public void HasPut(){}
        public UniTask HaltAndCatchFire(){if(GameManager.RunSimulation)OnServer.Interact(InteractOnOff,0);return UniTask.CompletedTask;}
        public string GetSourceCode()=>Chip==null?"":Chip.GetSourceCode();
        public void SetSourceCode(string source){if(Chip!=null){Chip.SetSourceCode(source,this);Chip.SendUpdate();}}
        public void Execute(){if(GameManager.RunSimulation&&!IsCursor&&OnOff&&Powered&&GameManager.GameState==GameState.Running&&!WorldManager.IsGamePaused&&Chip!=null&&!Chip.CompilationError)Chip.Execute(128);}
        public override bool CanLogicRead(LogicType type)=>type==LogicType.LineNumber||base.CanLogicRead(type);
        public override bool CanLogicWrite(LogicType type)=>type==LogicType.LineNumber||base.CanLogicWrite(type);
        public override double GetLogicValue(LogicType type)=>type==LogicType.LineNumber?(Chip==null?0:Chip.LineNumber):base.GetLogicValue(type);
        public override void SetLogicValue(LogicType type,double value){if(type==LogicType.LineNumber){if(Chip!=null)Chip.LineNumber=(uint)value;}else base.SetLogicValue(type,value);}
        public override ThingSaveData SerializeSave(){ThingSaveData data=new SmartModuleSaveData();InitialiseSaveData(ref data);return data;}
        protected override void InitialiseSaveData(ref ThingSaveData data){base.InitialiseSaveData(ref data);if(data is SmartModuleSaveData save){if(Board!=null)save.RailBoard=BoardStructureHooks.SerializeSave(this);save.CodeError=codeError;save.LastEditor=LastEditedBy;}}
        public override void DeserializeSave(ThingSaveData data){base.DeserializeSave(data);if(data is SmartModuleSaveData save){codeError=save.CodeError;LastEditedBy=save.LastEditor;if(save.RailBoard!=null)BoardStructureHooks.DeserializeSave(this,save.RailBoard);}else if(data is DinBreakerSaveData old){OnOff=true;if(old.RailBoard!=null)BoardStructureHooks.DeserializeSave(this,old.RailBoard);}}
        public override void SerializeOnJoin(RocketBinaryWriter writer){base.SerializeOnJoin(writer);BoardStructureHooks.SerializeOnJoin(writer,this);writer.WriteInt32(codeError);}
        public override void DeserializeOnJoin(RocketBinaryReader reader){base.DeserializeOnJoin(reader);BoardStructureHooks.DeserializeOnJoin(reader,this);codeError=reader.ReadInt32();}}}