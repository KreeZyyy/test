using System;using System.IO;using System.Linq;using System.Collections.Generic;using System.Text.Json;using UnityEngine;using ModularSwitchboards;
static class Program {
 static int n;static void Check(bool ok,string why){n++;if(!ok)throw new Exception(why);}
 static Mesh Load(JsonElement part)=>new(){vertices=part.GetProperty("Vertices").EnumerateArray().Select(p=>new Vector3(p.GetProperty("x").GetSingle(),p.GetProperty("y").GetSingle(),p.GetProperty("z").GetSingle())).ToArray(),uv=part.GetProperty("Uv").EnumerateArray().Select(p=>new Vector2(p.GetProperty("x").GetSingle(),p.GetProperty("y").GetSingle())).ToArray(),groups=part.GetProperty("Parts").EnumerateArray().Select(p=>p.GetProperty("Triangles").EnumerateArray().Select(i=>i.GetInt32()).ToArray()).ToArray()};
 static void Main(string[] args){
 var source=new Mesh{vertices=new[]{new Vector3(-1,-1,0),new Vector3(1,-1,0),new Vector3(0,1,0)},uv=new[]{new Vector2(0,0),new Vector2(1,0),new Vector2(.5f,1)},groups=new[]{new[]{0,1,2},Array.Empty<int>()}};
 var clip=new Bounds(new(0,0,0),new(1,1,1));var crop=NativeMeshCrop.Read(source,new Matrix4x4(1),clip,"crop");
 Check(crop!=null&&crop.vertices.Length>0&&crop.groups.Length==2,"clipping lost polygon/submeshes");
 foreach(var p in crop.vertices)Check(Math.Abs(p.x)<=.500001&&Math.Abs(p.y)<=.500001,"clipped vertex escaped region");
 for(int i=0;i<crop.vertices.Length;i++){var p=crop.vertices[i];var uv=crop.uv[i];Check(Math.Abs(uv.x-(p.x+1)/2)<1e-6&&Math.Abs(uv.y-(p.y+1)/2)<1e-6,"cut UV was not interpolated");}
 Check(source.vertices.Length==3&&source.groups[0].SequenceEqual(new[]{0,1,2}),"source mesh modified");
 var mirror=NativeMeshCrop.Read(source,new Matrix4x4(-1),clip,"mirror");for(int t=0;t<mirror.groups[0].Length;t+=3){var ids=mirror.groups[0];var a=mirror.vertices[ids[t]];var b=mirror.vertices[ids[t+1]];var c=mirror.vertices[ids[t+2]];Check(Vector3.Cross(b-a,c-a).z>0,"mirrored winding reversed");}
 using var native=JsonDocument.Parse(File.ReadAllText(args[0]));var parts=native.RootElement.GetProperty("Meshes").EnumerateArray().ToArray();
 var body=Load(parts.Single(p=>p.GetProperty("Name").GetString()=="StructureConsoleLED5"));var screen=Load(parts.Single(p=>p.GetProperty("Name").GetString()=="Screen"));var center=screen.bounds.center;
 var bezel=NativeMeshCrop.Read(body,new Matrix4x4(1),new Bounds(new(center.x,center.y,center.z+.006f),new(.51f,.18f,.045f)),"native bezel",LedBezelGeometry.KeepTriangle);Check(bezel!=null,"actual native LED bezel empty");
 int removed=0;foreach(var group in body.groups)for(int t=0;t<group.Length;t+=3)if(!LedBezelGeometry.KeepTriangle(body.vertices[group[t]],body.vertices[group[t+1]],body.vertices[group[t+2]]))removed++;
 Check(removed==10,"original switch pedestal not removed exactly");
 var nativeFace=new List<object>();var all=new List<Vector3>();
 foreach(var pair in new[]{(Name:"bezel",Mesh:bezel),(Name:"screen",Mesh:screen)}){
 var points=pair.Mesh.vertices.Select(v=>SmartModuleModel.DisplayCenter+(v-center)*SmartModuleModel.DisplayScale).ToArray();all.AddRange(points);
 if(pair.Name=="screen")Check(points.All(p=>p.z>=.074299f),"recessed pixel screen hidden behind fascia");
 else Check(points.Max(p=>p.z)>.0736f&&points.Max(p=>p.z)<=.0774f,"LED bezel protrudes more than 3.8 mm above fascia");
 Check(points.All(p=>p.x>=.028f&&p.x<=.1414f&&Math.Abs(p.y)<.035f),"LED overlaps chip region or casing edge");
 nativeFace.Add(new{name=pair.Name,vertices=points.Select(v=>new[]{v.x,v.y,v.z}),triangles=pair.Mesh.groups});
 }
 Check(all.Max(p=>p.x)-all.Min(p=>p.x)<.103f,"native LED frame wider than red area");
 Check(SmartModuleModel.ChipCenter.x+.020f<all.Min(p=>p.x),"chip and LED areas overlap");
 using var airDoc=JsonDocument.Parse(File.ReadAllText(args[2]));var air=Load(airDoc.RootElement.GetProperty("Meshes").EnumerateArray().Single(p=>p.GetProperty("Name").GetString()=="StructureAirConditioner"));
 var original=air.vertices.ToArray();var originalUv=air.uv.ToArray();var socket=AirChipSocketGeometry.Capture(air,new Matrix4x4(1));
 Check(socket.groups.Sum(g=>g.Length)/3==166,"actual socket triangles lost or extra Air panels retained");
 Check(socket.vertices.All(AirChipSocketGeometry.Contains),"white/grey Air housing survived socket extraction");
 Check(socket.vertices.Length<air.vertices.Length&&socket.bounds.size.x<.130f&&socket.bounds.size.y<.140f,"unused Air housing vertices inflate socket bounds");
 for(int i=0;i<socket.vertices.Length;i++)Check(air.vertices.Select((v,k)=>(v,k)).Any(x=>Math.Abs(x.v.x-socket.vertices[i].x)<1e-7&&Math.Abs(x.v.y-socket.vertices[i].y)<1e-7&&Math.Abs(x.v.z-socket.vertices[i].z)<1e-7&&Math.Abs(air.uv[x.k].x-socket.uv[i].x)<1e-7&&Math.Abs(air.uv[x.k].y-socket.uv[i].y)<1e-7),"socket vertex or native UV invented/changed");
 Check(air.vertices.SequenceEqual(original)&&air.uv.SequenceEqual(originalUv),"original Air model modified");
 float fit=AirChipSocketGeometry.Fit(socket.bounds);var target=SmartModuleModel.ChipCenter;target.z=.0736f-socket.bounds.size.z*.5f*fit;
 var socketPoints=socket.vertices.Select(v=>target+(v-socket.bounds.center)*fit).ToArray();
 Check(Math.Abs(socket.bounds.size.x*fit-.046f)<1e-6&&socket.bounds.size.y*fit<=.051001f,"socket does not use enlarged right-side area");
 Check(socketPoints.All(p=>p.x>=-.0198f&&p.x<=.032001f&&Math.Abs(p.y)<.030375f&&p.z<=.074101f),"socket crosses casing edge or fascia");
 Check(all.Min(p=>p.x)-socketPoints.Max(p=>p.x)>.003f,"socket overlaps LED frame");
 nativeFace.Add(new{name="socket",vertices=socketPoints.Select(v=>new[]{v.x,v.y,v.z}),triangles=socket.groups});
 using var casingDoc=JsonDocument.Parse(File.ReadAllText(args.Length>3?args[3]:Path.Combine(AppContext.BaseDirectory,"CasingFixture.json")));var casingRoot=casingDoc.RootElement.GetProperty("smartBody");var casing=new Mesh{vertices=casingRoot.GetProperty("vertices").EnumerateArray().Select(p=>new Vector3(p[0].GetSingle(),p[1].GetSingle(),p[2].GetSingle())).ToArray(),groups=Enumerable.Range(0,5).Select(i=>casingRoot.GetProperty("triangles").GetProperty(i.ToString()).EnumerateArray().Select(j=>j.GetInt32()).ToArray()).ToArray()};casing.uv=casing.vertices.Select(p=>new Vector2(p.x,p.y)).ToArray();
 float rear=target.z+(socket.bounds.min.z-socket.bounds.center.z)*fit-.0004f,front=.0745f;
 var cavity=new Bounds(new Vector3(target.x/2.25f,0,(rear+front)*.5f/1.15f),new Vector3((socket.bounds.size.x*fit)/2.25f,(socket.bounds.size.y*fit)/1.35f,(front-rear)/1.15f));
 var pocket=SmartSocketPocket.Cut(casing,cavity,.002607f/2.25f,.002607f/1.35f);
 Check(pocket.groups.Length==5,"pocket changed body material roles");
 Check(Math.Abs(pocket.bounds.min.x-casing.bounds.min.x)<1e-6&&Math.Abs(pocket.bounds.max.x-casing.bounds.max.x)<1e-6&&Math.Abs(pocket.bounds.max.z-casing.bounds.max.z)<1e-6,"pocket changed outer casing dimensions");
 float Ray(float x,float y){float result=float.NegativeInfinity;foreach(var group in pocket.groups)for(int t=0;t<group.Length;t+=3){var a=pocket.vertices[group[t]];var b=pocket.vertices[group[t+1]];var c=pocket.vertices[group[t+2]];float den=(b.y-c.y)*(a.x-c.x)+(c.x-b.x)*(a.y-c.y);if(Math.Abs(den)<1e-12)continue;float u=((b.y-c.y)*(x-c.x)+(c.x-b.x)*(y-c.y))/den;float v=((c.y-a.y)*(x-c.x)+(a.x-c.x)*(y-c.y))/den;float w=1-u-v;if(u>=-1e-6&&v>=-1e-6&&w>=-1e-6)result=Math.Max(result,u*a.z+v*b.z+w*c.z);}return result;}
 foreach(float dx in new[]{-.018f,0,.018f})foreach(float dy in new[]{-.018f,0,.018f})Check(Math.Abs(Ray((target.x+dx)/2.25f,dy/1.35f)-cavity.min.z)<1e-6,"original casing face still blocks IC10 pocket");
 Check(Math.Abs(Ray(.085f/2.25f,0)-casing.bounds.max.z)<1e-6,"IC10 pocket damaged display side of fascia");
 Check(socketPoints.Min(p=>p.z)>rear&&socketPoints.Max(p=>p.z)<=.074101f,"socket and modeled pocket are not seated together");
 // Corners must be a continuation of the face, not the old rectangular void.
 foreach(float sx in new[]{-1f,1f})foreach(float sy in new[]{-1f,1f}){
 float x=(target.x+sx*(socket.bounds.size.x*fit*.5f-.0002f))/2.25f;
 float y=sy*(socket.bounds.size.y*fit*.5f-.0002f)/1.35f;
 Check(Math.Abs(Ray(x,y)-casing.bounds.max.z)<1e-6,"socket corner does not join fascia");
 }
 Check(Math.Abs(socketPoints.Max(p=>p.z)-casing.bounds.max.z*1.15f)<1e-6,"socket rim is not flush with module face");
 var added=pocket.vertices.Length-80;
 Check(pocket.vertices.Take(added).Select((p,i)=>Math.Abs(p.x-pocket.uv[i].x)<1e-6&&Math.Abs(p.y-pocket.uv[i].y)<1e-6).All(v=>v),"pocket cut altered casing UVs");
 foreach(var ids in pocket.groups)for(int i=0;i<ids.Length;i+=3)Check(Vector3.Cross(pocket.vertices[ids[i+1]]-pocket.vertices[ids[i]],pocket.vertices[ids[i+2]]-pocket.vertices[ids[i]]).sqrMagnitude>1e-16f,"degenerate pocket triangle");
 File.WriteAllText(args.Length>4?args[4]:Path.Combine(Path.GetTempPath(),"SmartPocketGeometry.json"),JsonSerializer.Serialize(new{smartBody=new{vertices=pocket.vertices.Select(p=>new[]{p.x,p.y,p.z}),triangles=pocket.groups.Select((g,i)=>(g,i)).ToDictionary(p=>p.i.ToString(),p=>p.g)}}));
 File.WriteAllText(args[1],JsonSerializer.Serialize(nativeFace));
 Console.WriteLine(n+" native Smart face checks passed: actual LED, 166 original IC socket triangles only, UV/material groups preserved, surrounding Air panels excluded, enlarged fit and LED/casing clearance.");
 }
}
namespace UnityEngine {
 public struct Vector2 {public float x,y;public Vector2(float x,float y){this.x=x;this.y=y;}public static Vector2 operator +(Vector2 a,Vector2 b)=>new(a.x+b.x,a.y+b.y);public static Vector2 operator -(Vector2 a,Vector2 b)=>new(a.x-b.x,a.y-b.y);public static Vector2 operator *(Vector2 a,float b)=>new(a.x*b,a.y*b);}
 public struct Vector3 {public float x,y,z;public Vector3(float x,float y,float z){this.x=x;this.y=y;this.z=z;}public float this[int i]=>i==0?x:i==1?y:z;public float sqrMagnitude=>x*x+y*y+z*z;public static Vector3 operator +(Vector3 a,Vector3 b)=>new(a.x+b.x,a.y+b.y,a.z+b.z);public static Vector3 operator -(Vector3 a,Vector3 b)=>new(a.x-b.x,a.y-b.y,a.z-b.z);public static Vector3 operator *(Vector3 a,float b)=>new(a.x*b,a.y*b,a.z*b);public static Vector3 Cross(Vector3 a,Vector3 b)=>new(a.y*b.z-a.z*b.y,a.z*b.x-a.x*b.z,a.x*b.y-a.y*b.x);}
 public struct Bounds {public Vector3 center,size;public Bounds(Vector3 c,Vector3 s){center=c;size=s;}public Vector3 min=>center-size*.5f;public Vector3 max=>center+size*.5f;}
 public struct Matrix4x4 {public static Matrix4x4 identity=>new(1);float scale;public Matrix4x4(float x){scale=x;}public float determinant=>scale;public Vector3 MultiplyPoint3x4(Vector3 p)=>new(p.x*scale,p.y,p.z);}
 public class Mesh {public string name;public Rendering.IndexFormat indexFormat;public Vector3[] vertices;public Vector2[] uv;public int[][] groups;public int subMeshCount{get=>groups.Length;set=>groups=new int[value][];}public void SetVertices(List<Vector3> v){vertices=v.ToArray();}public void SetUVs(int i,List<Vector2> v){uv=v.ToArray();}public void SetTriangles(List<int> t,int i){groups[i]=t.ToArray();}public int[] GetTriangles(int i)=>groups[i];public void RecalculateNormals(){}public void RecalculateTangents(){}public void RecalculateBounds(){}public Bounds bounds{get{var a=new Vector3(vertices.Min(p=>p.x),vertices.Min(p=>p.y),vertices.Min(p=>p.z));var b=new Vector3(vertices.Max(p=>p.x),vertices.Max(p=>p.y),vertices.Max(p=>p.z));return new((a+b)*.5f,b-a);}}}
}
namespace UnityEngine.Rendering {public enum IndexFormat {UInt32}}
namespace ModularSwitchboards {static class CabinetGeometry {public static void ReadNativeMesh(Mesh m,out Vector3[] p,out Vector2[] uv,out int[][] groups){p=m.vertices;uv=m.uv;groups=m.groups;}}}

namespace UnityEngine {public static class Mathf {public static float Min(float a,float b)=>Math.Min(a,b);}}
