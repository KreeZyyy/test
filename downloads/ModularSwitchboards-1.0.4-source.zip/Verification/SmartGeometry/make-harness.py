from pathlib import Path
p=Path(__file__).resolve().parents[2];s=(p/'Source/SmartModuleModel.cs').read_text();a=s.index('        internal const float DisplayScale');b=s.index('        internal static void Install',a)
(p/'Verification/SmartGeometry/Layout.cs').write_text('using UnityEngine;namespace ModularSwitchboards{static class SmartModuleModel{'+s[a:b]+'}}')
