from pathlib import Path
import re
root=Path(__file__).resolve().parents[2]
source=(root/'Source/SwitchboardsMod.cs').read_text()
registered=set(re.findall(r'Mod.AddSaveDataType<([A-Za-z0-9_]+)>',source))
declared=set()
for f in (root/'Source').glob('*.cs'):
 declared.update(re.findall(r'class\s+(\w+)\s*:\s*(?:StructureSaveData|LogicBaseSaveData)',f.read_text()))
assert declared <= registered, 'Unregistered save types: '+str(declared-registered)
print('All '+str(len(declared))+' custom save types registered before Harmony setup.')
s=(root/'Source/DoorLabel.cs').read_text();a=s.index('    public sealed class DoorLabelSaveData');b=s.index('    public sealed class DoorLabelBoard',a)
(Path(__file__).parent/'SaveData.cs').write_text('using System.Xml.Serialization;using Assets.Scripts.Objects;using LibConstruct;namespace ModularSwitchboards{'+s[a:b]+'}')

s=(root/'Source/SwitchboardCabinet.cs').read_text();a=s.index('    public sealed class SwitchboardCabinetSaveData');b=s.index('    // Retains the stock locker',a)
(Path(__file__).parent/'CabinetSaveData.cs').write_text('using System.Xml.Serialization;using Assets.Scripts.Objects;using LibConstruct;namespace ModularSwitchboards{'+s[a:b]+'}')
