using System;
using ModularSwitchboards;
class Program{
 static int n;static void Check(string actual,string expected){n++;if(actual!=expected)throw new Exception($"Check {n}: {actual}");}
 static void Main(){const string err="Error <color=red>InvalidInteger</color> at line 1";
 Check(SmartChipTooltip.Once("Slot info\n"+err+"\n"+err,err+"\n"),"Slot info\n"+err);
 Check(SmartChipTooltip.Once(err,err,err),"");
 Check(SmartChipTooltip.Once(err+"\nOther warning",err,err),"Other warning");
 Check(SmartChipTooltip.Once("Slot info\r\n"+err+"\r\n",err),"Slot info\r\n"+err+"\r\n");
 Check(SmartChipTooltip.Once("Other\nOther",err),"Other\nOther");
 Check(SmartChipTooltip.Once(err+"\nDifferent line 2",err),err+"\nDifferent line 2");
 Check(SmartChipTooltip.Once(null,err),null);
 Check(SmartChipTooltip.Once("text",""),"text");
 Check(SmartChipTooltip.Once("Lua detail\nLua detail",null),"Lua detail\nLua detail");
 Console.WriteLine(n+" chip tooltip checks passed: duplicate error removed, cross-message duplicate removed, other warnings and single errors preserved.");}
}
