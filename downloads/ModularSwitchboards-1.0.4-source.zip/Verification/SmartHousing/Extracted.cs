using System;
partial class SmartModule{        public double ReadMemory(int address)
        {
            var chip=Chip;if(chip==null)throw new NullReferenceException("No programmable chip installed.");
            return chip.ReadMemory(address);
        }
        public void WriteMemory(int address,double value)
        {
            var chip=Chip;if(chip==null)throw new NullReferenceException("No programmable chip installed.");
            chip.WriteMemory(address,value);
        }
        public void ClearMemory()
        {
            var chip=Chip;if(chip==null)throw new NullReferenceException("No programmable chip installed.");
            chip.ClearMemory();
        }
        public int GetStackSize()=>Chip?.GetStackSize()??0;
}