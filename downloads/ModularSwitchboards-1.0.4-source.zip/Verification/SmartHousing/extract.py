from pathlib import Path
root=Path(__file__).resolve().parents[2]
s=(root/'Source/SmartModule.cs').read_text()
a=s.index('        public double ReadMemory(')
b=s.index('        public override bool CanLogicRead(LogicSlotType',a)
(Path(__file__).resolve().parent/'Extracted.cs').write_text('using System;\npartial class SmartModule{'+s[a:b]+'}')
