using System;
partial class SmartModule{public Chip Chip;}
class Chip{
 readonly double[] memory=new double[512];public double ReadMemory(int a)=>memory[a];
 public void WriteMemory(int a,double v)=>memory[a]=v;public void ClearMemory()=>Array.Clear(memory);public int GetStackSize()=>memory.Length;
}
class Program{
 static int checks;static void Check(bool b){checks++;if(!b)throw new Exception("Housing contract failed");}
 static void Missing(Action a){try{a();throw new Exception("Missing chip accepted");}catch(NullReferenceException){checks++;}}
 static void Main(){var module=new SmartModule();Check(module.GetStackSize()==0);Missing(()=>module.ReadMemory(0));Missing(()=>module.WriteMemory(0,1));Missing(()=>module.ClearMemory());
 var chip=new Chip();module.Chip=chip;Check(module.GetStackSize()==512);module.WriteMemory(511,42);Check(chip.ReadMemory(511)==42);chip.WriteMemory(0,17);Check(module.ReadMemory(0)==17);module.ClearMemory();Check(chip.ReadMemory(0)==0&&chip.ReadMemory(511)==0);
 var replacement=new Chip();replacement.WriteMemory(0,99);module.Chip=replacement;Check(module.ReadMemory(0)==99);Check(chip.ReadMemory(0)==0);
 try{module.ReadMemory(512);throw new Exception("Bounds bypassed");}catch(IndexOutOfRangeException){checks++;}
 Console.WriteLine($"{checks} housing memory contract checks passed: installed chip memory, replacement, absent chip and bounds.");}
}
