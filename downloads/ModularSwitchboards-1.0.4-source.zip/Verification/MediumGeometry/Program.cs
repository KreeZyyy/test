using System;using System.IO;using System.Linq;using System.Reflection;using ModularSwitchboards;using UnityEngine;
namespace Assets.Scripts.Objects{public class Structure{public bool IsOpen;}}
namespace UnityEngine{
public class DefaultExecutionOrder:Attribute{public DefaultExecutionOrder(int n){}}
public class MonoBehaviour{}
public struct Vector3{public float x,y,z;public Vector3(float x,float y,float z){this.x=x;this.y=y;this.z=z;}}
public struct Quaternion{public float angle;public static Quaternion Euler(float x,float y,float z)=>new(){angle=y};}
public class Transform{public Quaternion localRotation;}
public static class Time{public static float deltaTime=.1f;}
public static class Mathf{public static float MoveTowards(float a,float b,float d)=>Math.Abs(b-a)<=d?b:a+Math.Sign(b-a)*d;}
public static class Object{public static Mesh Instantiate(Mesh m)=>new(){name=m.name,vertices=m.vertices.ToArray(),tri=m.tri.Select(t=>t.ToArray()).ToArray()};}
public class Mesh{public string name;public Vector3[] vertices;public int[][] tri;public int subMeshCount=>tri.Length;public int[] GetTriangles(int s)=>tri[s].ToArray();public void SetTriangles(int[] a,int s)=>tri[s]=a;public void RecalculateNormals(){}public void RecalculateTangents(){}public void RecalculateBounds(){}}
}
class Program{
static int n;static void Check(bool b,string msg){n++;if(!b)throw new Exception(msg);}static void Near(float a,float b)=>Check(Math.Abs(a-b)<.000001f,$"{a} != {b}");
static void Main(){using var r=new BinaryReader(File.OpenRead(Path.Combine(AppContext.BaseDirectory,"Cabinet.meshbin")));r.ReadBytes(4);Check(r.ReadInt32()==1,"mesh version");int mats=r.ReadInt32(),count=r.ReadInt32();r.ReadBytes(mats*24);var meshes=new Mesh[count];for(int k=0;k<count;k++){var m=new Mesh{name="source",vertices=new Vector3[r.ReadInt32()],tri=new int[mats][]};for(int v=0;v<m.vertices.Length;v++){m.vertices[v]=new(r.ReadSingle(),r.ReadSingle(),r.ReadSingle());r.ReadBytes(12);}for(int s=0;s<mats;s++){m.tri[s]=new int[r.ReadInt32()];for(int i=0;i<m.tri[s].Length;i++)m.tri[s][i]=r.ReadInt32();}meshes[k]=m;}
for(int k=0;k<count;k++)foreach(bool mirror in new[]{false,true}){var src=meshes[k];var orig=src.vertices.ToArray();var stretched=MediumGeometry.Stretch(src,k==3?1:2,2,mirror);for(int v=0;v<orig.Length;v++){Near(stretched.vertices[v].x,orig[v].x*(k==3?1:2)*(mirror?-1:1));Near(stretched.vertices[v].y,orig[v].y*2);Near(stretched.vertices[v].z,orig[v].z);Near(src.vertices[v].x,orig[v].x);Near(src.vertices[v].y,orig[v].y);}for(int s=0;s<mats;s++)for(int i=0;i<src.tri[s].Length;i+=3){Check(stretched.tri[s][i]==src.tri[s][i],"first index");Check(stretched.tri[s][i+1]==src.tri[s][i+(mirror?2:1)],"mirrored winding");Check(stretched.tri[s][i+2]==src.tri[s][i+(mirror?1:2)],"mirrored winding");}}
float top=meshes[3].vertices.Max(v=>v.y);Near(top,.25f);Near(top-.17f,.08f);foreach(float offset in new[]{-.02f,0,.01f})foreach(float signHalfHeight in new[]{.015f,.025f,.035f}){float oldTop=offset+.17f+signHalfHeight;float y=WarningTopPlacement.Y(offset,top,top*2);Near(y-offset,.25f);Near(top-oldTop,top*2-(y+.17f+signHalfHeight));}
var door=new CabinetDoor{Owner=new(){IsOpen=true},Hinge=new(),RightHinge=new()};var update=typeof(CabinetDoor).GetMethod("LateUpdate",BindingFlags.NonPublic|BindingFlags.Instance);update.Invoke(door,null);Near(door.Hinge.localRotation.angle,-110);Near(door.RightHinge.localRotation.angle,110);door.Owner.IsOpen=false;for(int i=0;i<5;i++){update.Invoke(door,null);Near(door.Hinge.localRotation.angle,-door.RightHinge.localRotation.angle);}Near(door.Hinge.localRotation.angle,0);var closed=new CabinetDoor{Owner=new(){IsOpen=false},Hinge=new(),RightHinge=new()};update.Invoke(closed,null);Near(closed.Hinge.localRotation.angle,0);Near(closed.RightHinge.localRotation.angle,0);
Console.WriteLine($"Medium mesh/door production fixture: {n} checks, source immutability, mirror winding and native open/closed opposite hinges passed. Unity renderer remains untested.");}}
