using System.Linq;using System;using System.Collections.Generic;using ModularSwitchboards;using Assets.Scripts.Objects;using Assets.Scripts.Sound;
class Program
{
 static int n;static void Check(bool b,string s){n++;if(!b)throw new Exception(s);}
 static void Main(){
 var old=new Thing();var source=new Thing();var sourceEvent=new GameAudioEvent{Parent=source};source.AudioEvents.Add(sourceEvent);
 var shared=new GameAudioEvent{Parent=old};var interactionOnly=new GameAudioEvent{Parent=null};var buildOnly=new GameAudioEvent{Parent=old};
 var replacement=new Structure();replacement.AudioEvents.AddRange(new[]{shared,null});replacement.Interactables.Add(new Interactable{AssociatedAudioEvents=new(){shared,interactionOnly,null}});replacement.Interactables.Add(null);
 replacement.BuildStates.Add(new BuildState{Interactables=new(){new Interactable{AssociatedAudioEvents=new(){buildOnly}},replacement.Interactables[0],null}});
 old.Destroyed=true;bool reproduced=false;try{_=shared.IsValid;}catch(NullReferenceException){reproduced=true;}
 Check(reproduced,"native audio condition did not reproduce destroyed owner failure");
 PrefabAudioOwner.Rebind(replacement);
 foreach(var e in new[]{shared,interactionOnly,buildOnly}){Check(ReferenceEquals(e.Parent,replacement),"audio owner was not rebound");Check(!e.IsValid,"sound condition reads wrong instance state");}
 replacement.On=true;foreach(var e in new[]{shared,interactionOnly,buildOnly}){Check(e.IsValid,"live sound condition lost");e.Trigger();}
 Check(replacement.Played==3,"native sound triggering suppressed");Check(sourceEvent.Parent==source&&source.Played==0,"source prefab audio changed");
 Check(ReferenceEquals(shared,replacement.Interactables[0].AssociatedAudioEvents[0]),"shared event identity lost");
 PrefabAudioOwner.Rebind(replacement);Check(shared.IsValid,"rebinding is not idempotent");
 // Runtime clone/deserialization can lose nested event owners after template repair.
 var templateEvent=new GameAudioEvent{Parent=null,Name="Power",NameHash=7,Channel=2,ClipsData=new object(),StopIfInvalid=true};templateEvent.Conditions.Add(new SoundEffectCondition());templateEvent.BuildStateConditions.Add(0);
 Structure Runtime(){var o=new Structure();o.AudioEvents.Add(templateEvent);o.Interactables.Add(new Interactable{AssociatedAudioEvents=new(){templateEvent,null}});o.BuildStates.Add(new BuildState{Interactables=new(){o.Interactables[0]}});return o;}
 var first=Runtime();var second=Runtime();PrefabAudioOwner.PrepareInstance(first);PrefabAudioOwner.PrepareInstance(second);
 var firstEvent=first.AudioEvents[0];var secondEvent=second.AudioEvents[0];
 Check(firstEvent.Parent==first&&secondEvent.Parent==second,"runtime owners not repaired");
 Check(!ReferenceEquals(firstEvent,secondEvent)&&!ReferenceEquals(firstEvent,templateEvent),"runtime events shared across instances");
 Check(ReferenceEquals(firstEvent,first.Interactables[0].AssociatedAudioEvents.Single()),"instance event aliases not preserved or null entry survived");
 Check(firstEvent.Name=="Power"&&firstEvent.NameHash==7&&firstEvent.Channel==2&&firstEvent.StopIfInvalid&&ReferenceEquals(firstEvent.ClipsData,templateEvent.ClipsData),"native sound settings changed");
 Check(!ReferenceEquals(firstEvent.Conditions,secondEvent.Conditions)&&firstEvent.Conditions.Count==1&&firstEvent.BuildStateConditions.Single()==0,"condition lists lost or shared");
 first.On=true;second.On=false;Check(firstEvent.IsValid&&!secondEvent.IsValid,"two runtime instances read each other's states");firstEvent.Trigger();Check(first.Played==1&&second.Played==0,"wrong runtime instance played sound");
 Check(templateEvent.Parent==null,"runtime preparation mutated source event owner");
 first.On=false;Check(!firstEvent.IsValid,"power OFF condition failed");first.On=true;firstEvent.Trigger();Check(first.Played==2,"power ON sound failed after cycle");
 Console.WriteLine(n+" prefab audio owner checks passed: destroyed owner reproduced, global/interaction/build-only events rebound, live conditions and sound triggers retained, source isolated.");
 }
}
namespace Assets.Scripts.Sound {public class SoundEffectCondition {}public class GameAudioEvent {public string Name;public int NameHash,Channel;public object ClipsData;public bool StopIfInvalid;public List<SoundEffectCondition> Conditions=new();public List<int> BuildStateConditions=new();public Thing Parent;public bool IsValid{get{if(Parent==null||Parent.Destroyed)throw new NullReferenceException();return Parent.On;}}public void Trigger(){if(IsValid)Parent.Played++;}}}
namespace Assets.Scripts.Objects {
 public class Thing {public bool Destroyed,On;public int Played;public List<GameAudioEvent> AudioEvents=new();public List<Interactable> Interactables=new();public List<BuildState> BuildStates=new();}
 public class Structure:Thing {}
 public class Interactable {public List<GameAudioEvent> AssociatedAudioEvents=new();}
 public class BuildState {public List<Interactable> Interactables=new();}
}
