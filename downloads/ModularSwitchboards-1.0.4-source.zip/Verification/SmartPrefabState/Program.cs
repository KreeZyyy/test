using System;using System.Linq;using System.Collections.Generic;using Assets.Scripts.Objects;using ModularSwitchboards;
class Program
{
 static int checks;static void Check(bool ok,string message){checks++;if(!ok)throw new Exception(message);}
 static Thing Prefab()=>new Thing();
 static void Main()
 {
  var broken=Prefab();bool reproduced=false;
  try{broken.Interactables.Single(i=>i.Action==InteractableType.OnOff).State=1;}
  catch(NullReferenceException){reproduced=true;}
  Check(reproduced,"pre-Awake native LED setter failure was not reproduced");
  var source=Prefab();var clone=Prefab();SmartPrefabState.Configure(clone);
  Check(clone.OnOff&&!clone.Powered,"new prefab must start ON but unpowered");
  Check(clone.Callbacks==0&&clone.SoundEvents==0&&clone.NetworkUpdates==0,"prefab defaults invoked live callbacks");
  Check(clone.CacheCalls==1,"native interaction lookup cache not initialized");
  Check(source.Callbacks==0&&source.CacheCalls==0,"original native prefab was modified");
  clone.InteractPowered.State=1;
  Check(clone.OnOff&&clone.Powered&&clone.Lit,"live LED no longer reacts to power");
  clone.InteractOnOff.State=0;Check(!clone.OnOff&&!clone.Lit,"live OFF no longer reaches native display");
  clone.InteractOnOff.State=1;Check(clone.Lit,"live ON no longer reaches native display");
  Check(clone.Callbacks==3&&clone.SoundEvents==3&&clone.NetworkUpdates==3,"runtime setter callbacks suppressed");
  var invalid=Prefab();invalid.Interactables.RemoveAll(i=>i.Action==InteractableType.Powered);bool rejected=false;
  try{SmartPrefabState.Configure(invalid);}catch(InvalidOperationException){rejected=true;}
  Check(rejected&&invalid.Callbacks==0,"missing native role failed unclearly or partially initialized");
  Console.WriteLine(checks+" Smart prefab lifecycle checks passed: exact pre-Awake crash reproduced, silent serialized defaults, native caches, source isolation and live LED/network callbacks preserved.");
 }
}
namespace HarmonyLib {static class AccessTools{public static System.Reflection.FieldInfo Field(Type t,string n)=>t.GetField(n,System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic);}}
namespace Assets.Scripts.Objects
{
 public enum InteractableType{OnOff,Powered}
 public class Interactable
 {
  private int _state;public Thing Parent;public InteractableType Action;
  // Models the native setter's immediate callbacks. These were absent from
  // the earlier plain-state fixture and caused the reported startup failure.
  public int State{get=>_state;set{_state=value;Parent.Changed(this);Parent.SoundEvents++;Parent.NetworkUpdates++;}}
 }
 public class Thing
 {
  public List<Interactable> Interactables;Interactable on,powered;
  public int Callbacks,SoundEvents,NetworkUpdates,CacheCalls;public bool Lit;
  public Thing(){Interactables=new(){new(){Parent=this,Action=InteractableType.OnOff},new(){Parent=this,Action=InteractableType.Powered}};}
  public bool OnOff=>on.State==1;public bool Powered=>powered.State==1;
  public Interactable InteractOnOff=>on;public Interactable InteractPowered=>powered;
  public void CacheStates(bool cacheInteractables=false){CacheCalls++;if(cacheInteractables){on=Interactables.Find(i=>i.Action==InteractableType.OnOff);powered=Interactables.Find(i=>i.Action==InteractableType.Powered);}}
  public void Changed(Interactable value){Callbacks++;Lit=value.State==1&&OnOff&&Powered;}
 }
}
