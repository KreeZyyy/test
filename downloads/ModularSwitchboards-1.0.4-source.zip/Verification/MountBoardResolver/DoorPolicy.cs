using System;using System.Linq;using Assets.Scripts;using Assets.Scripts.GridSystem;using LibConstruct;namespace ModularSwitchboards{static class DoorModules{        internal static bool CanPlace(PlacementBoard board,Grid3 p,int rotation,bool bridge=false)
        {
            if(!(board?.PrimaryHost is SwitchboardCabinet host)||!host.IsStructureCompleted)return false;
            if(bridge)
            {
                if(!(board is SwitchboardBridgeBoard)||!host.CanFitRails)return false;
                return (p.x==0&&p.y%10==0&&p.y>=CabinetShape.MinBridgeY(host.PrefabName)&&p.y<=CabinetShape.MaxBridgeY(host.PrefabName)&&p.z==0&&rotation==0)&&!board.Structures.OfType<DinBreaker>().Any(m=>board.WorldToGrid(m.transform.position).y==p.y);
            }
            return board is SwitchboardDoorBoard&&(p.x%10==0&&p.y%10==0&&System.Math.Abs(p.x)<=10&&p.y>=CabinetShape.MinDoorY(host.PrefabName)&&p.y<=10&&p.z==0&&rotation==0)&&!board.Structures.OfType<DinBreaker>().Any(m=>{var q=board.WorldToGrid(m.transform.position);return q.x==p.x&&q.y==p.y;});
        }
        internal static CanConstructInfo CanConstruct(DinBreaker part)
        {
            if(part.IsCursor&&part.IsDoorBridge){MountPlacement.AfterRaycast();MountBoardResolver.Resolve(CursorManager.Instance);}
            var board=part.Board;
            if(board==null||!(board.PrimaryHost is SwitchboardCabinet host)||!(part.IsDoorBridge?board is SwitchboardBridgeBoard:board is SwitchboardDoorBoard)||(part.IsCursor&&PlacementBoard.CursorBoard!=board))return CanConstructInfo.InvalidPlacement(part.IsDoorBridge?"Aim at the mounting plate beside a door hinge.":"Aim at the outside of a cabinet door.");
            var p=board.WorldToGrid(part.transform.position);
            if(part.IsCursor)
            {
                if(MountPlacement.TryLockedGrid(part,board,out var locked))p=locked;
                else p=part.IsDoorBridge?new Grid3(0,DoorModuleLayout.SnapSlot(p.y,CabinetShape.MinBridgeY(host.PrefabName),CabinetShape.MaxBridgeY(host.PrefabName)),0):new Grid3(DoorModuleLayout.SnapSlot(p.x,-10,10),DoorModuleLayout.SnapSlot(p.y,CabinetShape.MinDoorY(host.PrefabName),10),0);
                PlacementBoard.CursorGrid=p;PlacementBoard.CursorRotation=0;part.transform.SetPositionAndRotation(board.GridToWorld(p),board.IndexToRotation(0));
            }
            return CanPlace(board,p,board.RotationToIndex(part.transform.rotation),part.IsDoorBridge)?CanConstructInfo.ValidPlacement:CanConstructInfo.InvalidPlacement("Choose a free door position; the terminal bridge fits only beside the hinge.");
        }
}}