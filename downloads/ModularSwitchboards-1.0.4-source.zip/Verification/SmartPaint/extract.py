from pathlib import Path
p=Path(__file__).resolve().parents[2]/'Source/SmartModule.cs'
s=p.read_text();a=s.index('        public override DelayedActionInstance AttackWith(');b=s.index('        protected override CanConstructInfo CanDeconstruct()',a)
(Path(__file__).resolve().parent/'Extracted.cs').write_text('partial class SmartModule:NativeDisplay{'+s[a:b]+'}')
