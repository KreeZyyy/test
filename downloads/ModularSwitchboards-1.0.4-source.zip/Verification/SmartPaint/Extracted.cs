partial class SmartModule:NativeDisplay{        public override DelayedActionInstance AttackWith(Attack attack,bool doAction=true)
        {
            // Status glyph colours are controlled separately from housing paint.
            // Keep the native spray interaction and its normal consumption guards.
            if(IsPaintable&&attack.SourceItem is ISprayer sprayer)return ISprayer.DoSpray(this,sprayer,doAction);
            return base.AttackWith(attack,doAction);
        }
}