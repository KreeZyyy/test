using System;using System.Linq;using ModularSwitchboards;
class Program
{
 static int n;static void Check(bool v,string m){n++;if(!v)throw new Exception(m);}
 static CabinetWireSaveData W(long a,int p,long b,int q)=>new(){From=new(a,p),To=new(b,q)};
 static bool Path(CabinetWireSaveData[] wires,long[] closed,int output)=>WireCircuit.Reachable(new(0,0),new(0,output),SmartContactorCircuit.Through(wires,closed),Array.Empty<long>());
 static void Main()
 {
  var wires=new[]{W(0,0,10,0),W(10,1,0,1),W(0,0,20,0),W(20,1,0,2)};
  Check(!Path(wires,Array.Empty<long>(),1)&&!Path(wires,Array.Empty<long>(),2),"open outputs leak power");
  Check(Path(wires,new long[]{10},1)&&!Path(wires,new long[]{10},2),"d0 affects d1 branch");
  Check(!Path(wires,new long[]{20},1)&&Path(wires,new long[]{20},2),"d1 affects d0 branch");
  Check(Path(wires,new long[]{10,20},1)&&Path(wires,new long[]{10,20},2),"both closed does not supply both");
  Check(SmartContactorCircuit.Through(wires,new long[]{10}).All(w=>(w.From.Owner==0||w.From.Contact<2)&&(w.To.Owner==0||w.To.Contact<2)),"side bus synthesized a DATA wire");
  Check(!Path(new[]{W(10,1,0,1)},new long[]{10},1),"side bus injects supply without main IN");
  Console.WriteLine(n+" Smart Output physical circuit checks passed: independent channels, OFF/ON, no DATA wire or side-bus power transfer.");
 }
}
