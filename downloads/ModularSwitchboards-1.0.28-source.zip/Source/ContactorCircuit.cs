using System.Collections.Generic;
using System.Linq;
namespace ModularSwitchboards
{
    internal static class ContactorCircuit
    {
        internal const int CoilPin=2;
        internal static HashSet<long> Resolve(IEnumerable<CabinetWireSaveData> wires,IEnumerable<long> fixedClosed,IEnumerable<long> ids,IEnumerable<long> previous,bool inputLive,IEnumerable<long> liveCells)
        {
            var graph=wires.ToArray();var fixedIds=fixedClosed.ToArray();var all=ids.Distinct().ToArray();var cells=liveCells.ToArray();
            var closed=new HashSet<long>(previous.Where(all.Contains));
            System.Func<long,bool> powered=id=>
                inputLive&&WireCircuit.Reachable(new CabinetWireEnd(0,0),new CabinetWireEnd(id,CoilPin),graph,fixedIds.Concat(closed))||
                cells.Any(cell=>WireCircuit.Reachable(new CabinetWireEnd(cell,1),new CabinetWireEnd(id,CoilPin),graph,fixedIds.Concat(closed)));
            // Release invalid held circuits first, then pick up newly powered coils.
            // A saved ON state must not supply a coil after its source disappears.
            for(int n=0;n<=all.Length;n++){var off=closed.Where(id=>!powered(id)).ToArray();if(off.Length==0)break;foreach(var id in off)closed.Remove(id);}
            for(int n=0;n<=all.Length;n++){var on=all.Where(id=>!closed.Contains(id)&&powered(id)).ToArray();if(on.Length==0)break;foreach(var id in on)closed.Add(id);}
            return closed;
        }
    }
}
