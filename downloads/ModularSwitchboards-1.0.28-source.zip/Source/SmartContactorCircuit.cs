using System.Collections.Generic;using System.Linq;
namespace ModularSwitchboards
{
    internal static class SmartContactorCircuit
    {
        internal static IEnumerable<CabinetWireSaveData> Through(IEnumerable<CabinetWireSaveData> wires,IEnumerable<long> closed)
            =>wires.Concat(closed.Select(id=>new CabinetWireSaveData{From=new CabinetWireEnd(id,0),To=new CabinetWireEnd(id,1)}));
    }
}
