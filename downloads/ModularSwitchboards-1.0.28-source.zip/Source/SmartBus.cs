using System.Collections.Generic;
using System.Linq;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Networks;
using Assets.Scripts.Objects;
using LibConstruct;
namespace ModularSwitchboards
{
    internal readonly struct SmartBusPart
    {
        internal readonly long Id;internal readonly int X,Width;internal readonly bool Core,Extension;
        internal SmartBusPart(long id,int x,int width,bool core,bool extension){Id=id;X=x;Width=width;Core=core;Extension=extension;}
    }
    internal static class SmartBusLayout
    {
        // Cabinet front view reverses grid X: visual left is increasing grid X.
        internal static long CoreAtLowerGridX(int x,int width,IEnumerable<SmartBusPart> parts)
        {
            var items=parts.ToArray();var seen=new HashSet<long>();int next=x;
            while(true)
            {
                var adjacent=items.Where(p=>p.Width>0&&p.X+p.Width==next).ToArray();
                if(adjacent.Length!=1)return 0;
                var part=adjacent[0];if(part.Id<=0||part.Width<=0||!seen.Add(part.Id))return 0;
                if(part.Core)return part.Id;
                if(!part.Extension)return 0;
                next=part.X;
            }
        }
    }
    internal static class SmartBus
    {
        private static SmartBusPart[] Parts(PlacementBoard board)=>DinParts.On(board).Where(p=>!p.IsBeingDestroyed&&!p.IsCursor)
            .Select(p=>new SmartBusPart(p.ReferenceId,board.WorldToGrid(p.transform.position).x/10,DinParts.Width(p),p is SmartModule,p is SmartContactor||p is DinBreaker d&&d.IsSmartOutputModule)).ToArray();
        internal static SmartModule Core(DinModuleBoard board,Grid3 position,int width=1)
        {
            if(board==null||position.y!=0||position.z!=0||position.x%10!=0)return null;
            long id=SmartBusLayout.CoreAtLowerGridX(position.x/10,width,Parts(board));
            return id==0?null:board.Structures.OfType<SmartModule>().FirstOrDefault(m=>m.ReferenceId==id&&!m.IsBeingDestroyed);
        }
        internal static SmartModule Core(DinBreaker extension)=>extension.IsSmartOutputModule?Core(extension.Board as DinModuleBoard,extension.GetLocalGrid(),extension.ModuleWidth):null;
        internal static SmartModule Core(SmartContactor output)=>Core(output.Board as DinModuleBoard,output.GetLocalGrid(),1);
        internal static IEnumerable<Structure> Extensions(SmartModule core)=>core.Board==null?Enumerable.Empty<Structure>():DinParts.On(core.Board)
            .Where(p=>(p is SmartContactor||p is DinBreaker d&&d.IsSmartOutputModule)&&!p.IsBeingDestroyed&&Core(p is IPlacementBoardStructure mounted?mounted.Board as DinModuleBoard:null,core.Board.WorldToGrid(p.transform.position),DinParts.Width(p))==core).OrderBy(p=>core.Board.WorldToGrid(p.transform.position).x);
        internal static IEnumerable<SmartContactor> PowerOutputs(SmartModule core)=>Extensions(core).OfType<SmartContactor>();
        internal static IEnumerable<SmartContactor> AddressedOutputs(SmartModule core)=>PowerOutputs(core).Where(o=>SmartOutputAddresses.Valid(o.OutputAddress)&&OutputAt(core,o.OutputAddress)==o);
        internal static SmartContactor OutputAt(SmartModule core,int address)
        {
            if(!SmartOutputAddresses.Valid(address))return null;
            var matches=PowerOutputs(core).Where(o=>o.OutputAddress==address).Take(2).ToArray();return matches.Length==1?matches[0]:null;
        }
        internal static void AssignAddresses(SmartModule core)
        {
            if(core==null||!Assets.Scripts.GameManager.RunSimulation||PlacementBoard.Loading)return;
            var outputs=PowerOutputs(core).ToArray();var assigned=SmartOutputAddresses.Resolve(outputs.Select(o=>new KeyValuePair<long,int>(o.ReferenceId,o.OutputAddress)));
            foreach(var output in outputs)output.SetOutputAddress(assigned[output.ReferenceId]);
        }
        internal static IEnumerable<DinBreaker> Outputs(SmartModule core)=>core.Board==null?Enumerable.Empty<DinBreaker>():core.Board.Structures.OfType<DinBreaker>()
            .Where(m=>m.IsSmartOutputModule&&!m.IsBeingDestroyed&&Core(m)==core).OrderBy(m=>m.GetLocalGrid().x);
        internal static CableNetwork NetworkAt(SmartModule core,int index)
        {
            if(index<0)return null;
            var output=Outputs(core).Skip(index).FirstOrDefault();
            return output==null?null:core.Cabinet?.Wiring.SmartCable(output.ReferenceId)?.CableNetwork;
        }
        internal static CableNetwork[] Networks(SmartModule core)=>Outputs(core).Select(m=>core.Cabinet?.Wiring.SmartCable(m.ReferenceId)?.CableNetwork)
            .Where(n=>n!=null).Distinct().ToArray();
        internal static Grid3? NextPosition(DinModuleBoard board,Grid3 aimed,SmartModule preferred=null,bool powerOutput=false)
        {
            if(board==null)return null;
            var candidates=board.Structures.OfType<SmartModule>().Where(c=>!c.IsBeingDestroyed&&!c.IsCursor&&(preferred==null||c==preferred))
                .Select(c=>{var outputs=Extensions(c).ToArray();int x=outputs.Length==0?c.GetLocalGrid().x+DinSmartLayout.Slots*10:outputs.Max(o=>board.WorldToGrid(o.transform.position).x+DinParts.Width(o)*10);return new Grid3(x,0,0);})
                .Where(p=>powerOutput?CanPlacePowerOutput(board,p,0):CanPlace(board,p,0)).OrderBy(p=>System.Math.Abs(p.x-aimed.x)).ToArray();
            return candidates.Length==0?(Grid3?)null:candidates[0];
        }
        internal static bool CanPlace(DinModuleBoard board,Grid3 position,int rotation)
            =>rotation==0&&board.CanPlace(position,rotation,1)&&Core(board,position)!=null;
        internal static bool CanPlacePowerOutput(DinModuleBoard board,Grid3 position,int rotation)
            =>CanPlace(board,position,rotation)&&Core(board,position) is SmartModule core&&PowerOutputs(core).Count()<SmartOutputAddresses.Count;
        internal static bool HasLeftNeighbour(Structure part,int width)
            =>part is IPlacementBoardStructure mounted&&mounted.Board!=null&&Parts(mounted.Board).Any(p=>p.Extension&&p.X==mounted.Board.WorldToGrid(part.transform.position).x/10+width);
    }
}
