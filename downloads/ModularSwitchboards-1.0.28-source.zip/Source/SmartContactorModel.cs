using System;using System.Collections.Generic;using System.Linq;
using Assets.Scripts;using Assets.Scripts.Objects;using Assets.Scripts.Objects.Pipes;using Assets.Scripts.Objects.Motherboards;using Assets.Scripts.UI;using HarmonyLib;using Rendering;using UnityEngine;using UnityEngine.Rendering;
namespace ModularSwitchboards
{
    internal static class SmartContactorModel
    {
        internal static void Install(SmartContactor module,Transform storage)
        {
            foreach(var renderer in module.GetComponentsInChildren<Renderer>(true))UnityEngine.Object.DestroyImmediate(renderer);
            foreach(var filter in module.GetComponentsInChildren<MeshFilter>(true))UnityEngine.Object.DestroyImmediate(filter);
            foreach(var hit in module.GetComponentsInChildren<Collider>(true))UnityEngine.Object.DestroyImmediate(hit);
            foreach(var animator in module.GetComponentsInChildren<Animator>(true))UnityEngine.Object.DestroyImmediate(animator);
            module.BaseAnimator=null;module.Slots=new List<Slot>();module.OpenEnds=new List<Connection>();module.UseCellPosition=false;
            module.Renderers=new List<ThingRenderer>();module._staticColliders=new List<Collider>();module._dynamicColliders=new List<Collider>();module._selfColliders=new List<Collider>();module.CustomNavMeshFilter=null;module.ForceGridBounds.Clear();module.BrokenBuildStates=new List<BrokenBuildState>();
            module.StructureCollisionType=CollisionType.BlockCustom;module.SelectionDisplay=SelectionHighlightMethod.Bounds;
            module.CustomColor=GameManager.GetColorSwatch((int)Assets.Scripts.Objects.Motherboards.ColorType.White);module.PaintableMaterial=module.CustomColor.Normal;module.HasColorState=false;module.MPBRenderers.Clear();module.UsedPower=5f;
            module.Interactables=module.Interactables.Where(i=>i.Action==InteractableType.OnOff||i.Action==InteractableType.Powered).ToList();
            foreach(var i in module.Interactables){i.Parent=module;i.Collider=null;i.Animator=null;i.FakeCollider=null;i.ParentInteractableIndex=-1;}
            SmartPrefabState.Configure(module,false);
            var model=new GameObject("DinBreakerModel"){layer=module.gameObject.layer};model.transform.SetParent(module.transform,false);model.transform.localScale=DinBreakerModel.VisualScale;
            var body=DinBreakerModel.Build(plain:true);
            var v=new List<Vector3>(body.vertices);var n=new List<Vector3>(body.normals);var g=new List<int>[5];for(int i=0;i<5;i++)g[i]=new List<int>(body.GetTriangles(i));
            RoundedGeometry.Box(v,n,g[4],new Vector3(0,0,.0642f),new Vector3(.009f,.022f,.0007f),.0004f);
            RoundedGeometry.Box(v,n,g[4],new Vector3(0,-.022f,.0642f),new Vector3(.010f,.004f,.0007f),.0002f);
            RoundedGeometry.Box(v,n,g[4],new Vector3(0,.015f,.0642f),new Vector3(.0105f,.006f,.0007f),.0002f);
            RoundedGeometry.Box(v,n,g[4],new Vector3(0,.022f,.0642f),new Vector3(.010f,.005f,.0007f),.0002f);
            var mesh=new Mesh{name="DIN.SmartContactor.Body"};mesh.SetVertices(v);mesh.SetNormals(n);mesh.subMeshCount=5;for(int i=0;i<5;i++)mesh.SetTriangles(g[i],i);CabinetGeometry.ApplyNativeUv(mesh);mesh.RecalculateBounds();UnityEngine.Object.DestroyImmediate(body);
            model.AddComponent<MeshFilter>().sharedMesh=mesh;var mr=model.AddComponent<MeshRenderer>();mr.sharedMaterials=CabinetGeometry.Materials;
            var collider=model.AddComponent<BoxCollider>();collider.center=mesh.bounds.center;collider.size=mesh.bounds.size;
            var state=module.BuildStates[0];state.Visualizer=mr;state.StateMeshes=new List<Mesh>();state.RendererInstance=null;state.Colliders=new List<Collider>{collider};state.Interactables=module.Interactables;state.LinkedGameObjects=new List<GameObject>();state.RenderMode=BuildStateRenderMode.OnMyState;
            AccessTools.Field(typeof(BuildState),"initialDrawData").SetValue(state,new DrawData{mesh=null,materials=new Material[0]});
            module.Thumbnail=CabinetIcons.Get("DinSmartContactor");module.Thumbnails=new Sprite[0];state.Thumbnail=module.Thumbnail;
            module.Bounds=new Bounds(Vector3.Scale(mesh.bounds.center,DinBreakerModel.VisualScale),Vector3.Scale(mesh.bounds.size,DinBreakerModel.VisualScale));module.GridBounds=new GridBounds(module);module.SurfaceArea=.016f;
            Font font=null;foreach(var name in new[]{"LegacyRuntime.ttf","Arial.ttf"}){try{font=Resources.GetBuiltinResource<Font>(name);}catch(Exception){}if(font!=null)break;}
            if(font!=null)
            {
                // Front-view right is negative model X.
                Label(model.transform,module.gameObject.layer,font,"IN",0,.022f,.0027f);
                Label(model.transform,module.gameObject.layer,font,"OUT",0,-.022f,.0035f);
                var text=Label(model.transform,module.gameObject.layer,font,"OFF",0,0,.006f);
                var view=module.gameObject.AddComponent<SmartContactorView>();view.StateText=text;
                view.AddressText=Label(model.transform,module.gameObject.layer,font,"d-",.0026f,.015f,.0033f);
            }
            // Functional screwdriver target; visual styling remains provisional.
            var screw=GameObject.CreatePrimitive(PrimitiveType.Cylinder);screw.name="OutputAddressScrew";screw.layer=module.gameObject.layer;screw.transform.SetParent(model.transform,false);
            screw.transform.localPosition=new Vector3(-.0027f,.015f,.0652f);screw.transform.localRotation=Quaternion.Euler(90,0,0);screw.transform.localScale=new Vector3(.0032f,.0003f,.0032f);
            UnityEngine.Object.DestroyImmediate(screw.GetComponent<Collider>());screw.GetComponent<MeshRenderer>().sharedMaterial=SmartOutputElectronics.Material("AddressScrew",new Color(.28f,.30f,.30f));
            var controlRoot=new GameObject("OutputAddressTarget"){layer=module.gameObject.layer};controlRoot.transform.SetParent(model.transform,false);var addressHit=controlRoot.AddComponent<BoxCollider>();addressHit.center=new Vector3(-.0027f,.015f,.0652f);addressHit.size=new Vector3(.005f,.006f,.005f);
            var addressControl=new Interactable{Parent=module,Action=InteractableType.Mode,Collider=addressHit,JoinInProgressSync=true,CanKeyInteract=true,KeyMap="PrimaryAction"};
            module.Interactables.Add(addressControl);state.Interactables=module.Interactables;state.Colliders.Add(addressHit);
            module.CacheStates(true);
            var bp=new GameObject("SmartContactorBlueprint"){layer=module.gameObject.layer};bp.transform.SetParent(storage,false);var ghost=ModelBlueprint.Build(module.transform);var f=bp.AddComponent<MeshFilter>();f.sharedMesh=ghost;var rr=bp.AddComponent<MeshRenderer>();rr.sharedMaterial=CabinetGeometry.Materials[4];var wire=bp.AddComponent<Wireframe>();wire.BlueprintTransform=bp.transform;wire.BlueprintBounds=ghost.bounds;wire.BlueprintMeshFilter=f;wire.BlueprintRenderer=rr;bp.AddComponent<CabinetBlueprint>();module.Blueprint=bp;module.BlueprintOrientVector=Vector3.zero;
        }
        private static TextMesh Label(Transform model,int layer,Font font,string value,float x,float y,float width)
        {
            var go=new GameObject("SmartContactorLabel."+value){layer=layer};go.transform.SetParent(model,false);go.transform.localPosition=new Vector3(x,y,.065f);go.transform.localRotation=Quaternion.Euler(0,180,0);
            var text=go.AddComponent<TextMesh>();text.font=font;text.fontSize=64;text.characterSize=.002f;text.anchor=TextAnchor.MiddleCenter;text.alignment=TextAlignment.Center;text.text=value;text.color=Color.black;
            var size=go.GetComponent<MeshRenderer>().localBounds.size;go.transform.localScale=Vector3.one*Mathf.Min(width/Mathf.Max(.0001f,size.x),.004f/Mathf.Max(.0001f,size.y));DepthLabelText.Apply(text);return text;
        }
    }
    public sealed class SmartContactorView:MonoBehaviour
    {
        public TextMesh StateText,AddressText;private SmartContactor owner;private bool last,painted;private int lastAddress=-2;
        private void LateUpdate(){if(owner==null)owner=GetComponent<SmartContactor>();if(owner==null||StateText==null)return;bool closed=owner.Conducting;if(!painted||last!=closed){StateText.text=closed?"ON":"OFF";last=closed;painted=true;}if(AddressText!=null&&lastAddress!=owner.OutputAddress){lastAddress=owner.OutputAddress;AddressText.text=SmartOutputAddresses.Valid(lastAddress)?"d"+lastAddress:"d-";}}
    }
}
