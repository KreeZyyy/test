# Station Assistant — první prototyp

Vlastní mod pro StationeersLaunchPad a Lua panel pro ScriptedScreens. Napíšeš otázku, dostaneš českou odpověď a místní mod ji přehraje syntetickým hlasem. Hlas je generovaný AI. Výchozí poskytovatel je OpenAI; API má samostatné placené účtování.

**Stav:** mod se úspěšně sestavil proti dodaným knihovnám BepInEx, LaunchPadu a Unity (bez chyb a varování). Ověřena je také síťová logika s náhradou API, dekódování PCM a chování Lua panelu. Načtení do Stationeers, skutečné API a zvuk ve hře zatím nejsou ověřené. Instalační ZIP je v `dist/StationAssistant-0.1.0.zip`.

## Co umí tato verze

- Samostatné otázky a odpovědi v češtině, hlas lze vypnout před odesláním.
- Asynchronní požadavky: čekání na AI nezablokuje herní hlavní vlákno.
- Odpověď zůstane dostupná i při chybě hlasové služby.
- Osobní 2D hlas přehrávaný Unity, slyšitelný i ve vakuu.
- Jeden požadavek současně, krátký interval mezi požadavky, omezená délka vstupu/výstupu.

Zatím nečte senzory, neovládá zařízení, nemá mikrofon ani paměť předchozích otázek. Vector není nutný pro první panel; běžné prvky ScriptedScreens usnadní ověření celého spojení. Výraznější vzhled přes Vector můžeme přidat následně.

## Sestavení na Windows

1. Nainstaluj .NET SDK 8. Hra musí mít StationeersLaunchPad, StationeersLua, ScriptedScreens a IC10Editor.
2. Zkopíruj `Stationeers.User.props.example` do `Stationeers.User.props` a nastav cesty. `LaunchPadDirectory` je složka obsahující **StationeersMods.Interface.dll**, `StationeersDirectory` složka s `rocketstation_Data` a `BepInEx`.
3. V kořeni repozitáře spusť:

   ```powershell
   dotnet build StationAssistant.csproj -c Release
   ./scripts/package.ps1
   ```

4. Výstup `dist/StationAssistant` zkopíruj do složky `mods` ve svých uživatelských datech Stationeers (typicky `Documents/My Games/Stationeers/mods`). Nepřepisuj soubory jiných modů. Aktivuj nový mod v seznamu modů světa a restartuj hru.

Používáme stejný vstupní bod `StationeersMod` / `ModBehaviour.OnLoaded` jako Vector. Skutečnou kompatibilitu je potřeba ověřit proti tvé verzi LaunchPadu a herních DLL. Build cíleně skončí s chybou, pokud herní knihovny chybějí.

## Nastavení a první spuštění

1. V místním nastavení modu **Station Assistant** vyplň `Online AI / ApiKey`. Klíč nikdy nevkládej do Lua, chatu, Git repozitáře ani screenshotu. Místní konfigurační soubor obsahuje tento klíč, proto ho nesdílej.
2. Zkopíruj **Bridge / Token** do `TOKEN` na začátku `scripts/assistant.lua`. Jde o zvláštní místní přístupový token, nikoliv OpenAI klíč. Sdílení tohoto tokenu umožňuje lokálnímu uživateli spouštět placené dotazy. `Bridge / Port` a port v Lua musí být shodné; výchozí je 18765.
3. Na hostiteli v konfiguraci StationeersLua povol:

   ```ini
   [Features]
   AllowHttp = true
   AllowHttpLocalhost = true
   ```

4. Po změně konfigurace restartuj hru. Vlož Lua chip do ScriptedScreens konzole/počítače a nahraj `scripts/assistant.lua` přes IC10Editor.
5. Napiš „Ahoj, řekni mi jednu krátkou radu pro začátečníka.“ a klikni **Odeslat**. Ověř zobrazení odpovědi i slyšitelný český hlas. Zkus vypnout hlas a odeslat druhou otázku.

API klíč zůstává v C# modu. Panel posílá jen text otázky a volbu hlasu na `127.0.0.1`; mod volá `https://api.openai.com/v1/chat/completions` a `/audio/speech`. Poskytovatel dostává otázku a text odpovědi pro syntézu. Použité modely (`gpt-4.1-mini`, `gpt-4o-mini-tts`) a hlas (`alloy`) jsou nastavitelné. Pro PCM přehrávání musí hlasová služba vracet mono signed PCM16 little-endian při 24 kHz.

První verze je pro **singleplayer nebo místní session host**. V multiplayeru běží Lua na hostiteli: `127.0.0.1` tedy znamená počítač hostitele a hlas se přehraje tam. Připojení klienti vlastní hlas nedostanou. Headless server tento mod nespouští. Nikdy nepřepisuj listener na veřejné rozhraní kvůli multiplayeru.

## Diagnostika

- Panel hlásí HTTP nedostupné: zkontroluj oba přepínače `[Features]` na hostiteli.
- Spojení s modem selhalo: ověř aktivaci modu, restart, port a herní/BepInEx log.
- Neplatný bridge token: zkopíruj aktuální `Bridge.Token` a znovu nahraj Lua.
- API klíč nebyl přijat: oprav klíč v místním nastavení, restartuj. Nikdy neposílej klíč do chatu.
- HTTP 429: zkontroluj API kredit/limity; také vyčkej po předchozím dotazu.
- Text funguje, hlas ne: ověř oprávnění k hlasovému modelu, hlas, herní hlasitost a log. Text se zachová.
- Listener na Windows skončí s přístupem odepřeným: jde o HTTP.sys URL oprávnění. Zjisti skutečný chybový kód v logu; případnou rezervaci povol jen pro `http://127.0.0.1:18765/` a konkrétního uživatele. Nespouštěj kvůli tomu celou hru jako správce.

## Ověření bez hry a placeného API

```powershell
dotnet run --project tests/CoreTests.csproj
```

Kontroluje požadavky, autentizaci, text/hlas, chyby, PCM, místní listener, asynchronní dokončení a omezení opakovaných dotazů. Používá náhradu OpenAI HTTP služby; nic neúčtuje.

Lua UI lze otestovat pomocí Pythonu a `lupa==2.6`:

```sh
python -m pip install lupa==2.6
python tests/test_ui.py
```

V připraveném cloudovém prostředí:

```sh
DOTNET_CLI_HOME=/workspace/tooling/dotnet-home /workspace/tooling/dotnet/dotnet run --project tests/CoreTests.csproj
PYTHONPATH=/workspace/tooling/python python tests/test_ui.py
python /workspace/tooling/check_lua.py scripts
```

To nenahrazuje herní test: po instalaci musí fungovat panel, odpověď i skutečné přehrání. Před publikováním modu je potřeba provést právě tento test.
