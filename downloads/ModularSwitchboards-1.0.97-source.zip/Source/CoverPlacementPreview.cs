using System;
using System.Linq;
using UnityEngine;
using UnityEngine.Rendering;
namespace ModularSwitchboards
{
    internal static class CoverPlacementPreview
    {
        internal static bool Apply(GameObject cursor,CoverMemory state)
        {
            var filter=cursor.GetComponent<MeshFilter>();var renderer=cursor.GetComponent<MeshRenderer>();var shader=Shader.Find("Hidden/Internal-Colored");
            if(filter==null||renderer==null||shader==null||!shader.isSupported)return false;
            var labels=state.Labels.Select(l=>{float x=-state.HalfSpan+l.X*.00045f+(l.Width-1)*DinLayout.SlotPitch*.5f,y=.0525f+l.Y*.00045f,w=l.Width*DinLayout.SlotPitch-.0068f;return new CoverIconRect(x-w*.5f,x+w*.5f,y-.0075f,y+.0075f);}).ToArray();
            var holes=state.Retained.ToArray();var body=InnerCoverLayout.Cells(holes,state.Profile);
            var cells=InnerCoverLayout.Cells(holes.Concat(labels.Select(r=>new WireRect(r.Left,r.Right,r.Bottom,r.Top))),state.Profile);var frames=new Mesh[CoverPreviewPhase.Count];
            for(int i=0;i<frames.Length;i++)
            {
                // Only this hatch mesh changes phase. Static edges/text are separate.
                var data=CoverPreviewGeometry.Build(Array.Empty<InnerCoverLayout.Cell>(),cells,Array.Empty<CoverIconRect>(),CoverPreviewPhase.Offset(i));
                var mesh=new Mesh{name="Switchboards.CoverPlacement.AnimatedHatch."+i,indexFormat=IndexFormat.UInt32};
                mesh.SetVertices(data.Vertices);mesh.SetTriangles(data.Triangles[0],0);mesh.RecalculateBounds();frames[i]=mesh;
            }
            var colour=Color.green;colour.a=.2f;var material=new Material(shader){name="Switchboards.CoverPreview.HatchOnly",color=colour};
            material.SetInt("_SrcBlend",(int)BlendMode.SrcAlpha);material.SetInt("_DstBlend",(int)BlendMode.OneMinusSrcAlpha);material.SetInt("_Cull",(int)CullMode.Off);material.SetInt("_ZWrite",0);
            renderer.sharedMaterial=material;renderer.shadowCastingMode=ShadowCastingMode.Off;renderer.receiveShadows=false;filter.sharedMesh=frames[0];
            var animation=cursor.AddComponent<CoverPreviewAnimation>();animation.Filter=filter;animation.Frames=frames;animation.OwnedMaterial=material;
            var dataStatic=CoverPreviewGeometry.Build(body,Array.Empty<InnerCoverLayout.Cell>(),labels);
            var overlay=new Mesh{name="Switchboards.CoverPreview.StaticEdgesAndLabels",indexFormat=IndexFormat.UInt32};overlay.SetVertices(dataStatic.Vertices);overlay.subMeshCount=2;overlay.SetTriangles(dataStatic.Triangles[1],0);overlay.SetTriangles(dataStatic.Triangles[2],1);overlay.RecalculateBounds();
            var edgeObject=new GameObject("StaticEdgesAndLabels"){layer=cursor.layer};edgeObject.transform.SetParent(cursor.transform,false);edgeObject.AddComponent<MeshFilter>().sharedMesh=overlay;
            var overlayRenderer=edgeObject.AddComponent<MeshRenderer>();var overlayMaterials=new[]{Ink(shader,.85f),Ink(shader,.95f)};overlayRenderer.sharedMaterials=overlayMaterials;overlayRenderer.shadowCastingMode=ShadowCastingMode.Off;overlayRenderer.receiveShadows=false;
            animation.OwnedOverlay=overlay;animation.OverlayMaterials=overlayMaterials;
            foreach(var label in state.Labels){var root=new GameObject("PlacementLabel"){layer=cursor.layer};root.transform.SetParent(cursor.transform,false);root.transform.localPosition=new Vector3(-state.HalfSpan+label.X*.00045f,.0525f+label.Y*.00045f,.003f);PortableCoverVisual.Text(root.transform,label,true);}
            return true;
        }
        private static Material Ink(Shader shader,float alpha)
        {
            var colour=Color.green;colour.a=alpha;var material=new Material(shader){name="Switchboards.CoverPreview.StaticInk",color=colour};
            material.SetInt("_SrcBlend",(int)BlendMode.SrcAlpha);material.SetInt("_DstBlend",(int)BlendMode.OneMinusSrcAlpha);material.SetInt("_Cull",(int)CullMode.Off);material.SetInt("_ZWrite",0);return material;
        }
    }
    internal sealed class CoverPreviewAnimation:MonoBehaviour
    {
        internal MeshFilter Filter;internal Mesh[] Frames;internal Material OwnedMaterial;internal Mesh OwnedOverlay;internal Material[] OverlayMaterials;private int current=-1;
        private void LateUpdate()
        {
            if(Filter==null||Frames==null||Frames.Length==0)return;
            int frame=CoverPreviewPhase.Frame(Time.unscaledTime);if(frame==current)return;Filter.sharedMesh=Frames[frame];current=frame;
        }
        private void OnDestroy(){if(Frames!=null)foreach(var mesh in Frames)if(mesh!=null)Destroy(mesh);if(OwnedMaterial!=null)Destroy(OwnedMaterial);if(OwnedOverlay!=null)Destroy(OwnedOverlay);if(OverlayMaterials!=null)foreach(var material in OverlayMaterials)if(material!=null)Destroy(material);}
    }
    internal static class PlacementLabelText
    {
        private static readonly System.Collections.Generic.Dictionary<Font,Material> materials=new System.Collections.Generic.Dictionary<Font,Material>();
        internal static Material For(Font font)
        {
            if(!materials.TryGetValue(font,out var material)){material=new Material(DepthLabelText.For(font)){name="Switchboards.PlacementLabel.Green",color=Color.green};material.EnableKeyword("_EMISSION");material.SetColor("_EmissionColor",Color.green);materials[font]=material;}
            material.mainTexture=font.material.mainTexture;return material;
        }
    }
}
