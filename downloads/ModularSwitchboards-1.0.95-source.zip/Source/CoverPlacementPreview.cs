using System.Linq;
using UnityEngine;
using UnityEngine.Rendering;
namespace ModularSwitchboards
{
    internal static class CoverPlacementPreview
    {
        internal static bool Apply(GameObject cursor,CoverMemory state)
        {
            var filter=cursor.GetComponent<MeshFilter>();var renderer=cursor.GetComponent<MeshRenderer>();var shader=Shader.Find("Hidden/Internal-Colored");
            if(filter==null||renderer==null||shader==null||!shader.isSupported)return false;
            var labels=state.Labels.Select(l=>{float x=-state.HalfSpan+l.X*.00045f+(l.Width-1)*DinLayout.SlotPitch*.5f,y=.0525f+l.Y*.00045f,w=l.Width*DinLayout.SlotPitch-.0068f;return new CoverIconRect(x-w*.5f,x+w*.5f,y-.0075f,y+.0075f);}).ToArray();
            var holes=state.Retained.ToArray();var body=InnerCoverLayout.Cells(holes,state.Profile);
            var hatch=InnerCoverLayout.Cells(holes.Concat(labels.Select(r=>new WireRect(r.Left,r.Right,r.Bottom,r.Top))),state.Profile);
            var data=CoverPreviewGeometry.Build(body,hatch,labels);var mesh=new Mesh{name="Switchboards.CoverPlacement.HatchAndEdges",indexFormat=IndexFormat.UInt32};
            mesh.SetVertices(data.Vertices);mesh.subMeshCount=3;for(int i=0;i<3;i++)mesh.SetTriangles(data.Triangles[i],i);mesh.RecalculateBounds();
            var materials=new[]{Material(shader,.18f),Material(shader,.85f),Material(shader,.95f)};renderer.sharedMaterials=materials;renderer.shadowCastingMode=ShadowCastingMode.Off;renderer.receiveShadows=false;filter.sharedMesh=mesh;
            var lifetime=cursor.AddComponent<PlacementOutlineLifetime>();lifetime.Owned=mesh;lifetime.OwnedMaterial=materials[0];lifetime.ExtraMaterials=new[]{materials[1],materials[2]};
            foreach(var label in state.Labels){var root=new GameObject("PlacementLabel"){layer=cursor.layer};root.transform.SetParent(cursor.transform,false);root.transform.localPosition=new Vector3(-state.HalfSpan+label.X*.00045f,.0525f+label.Y*.00045f,.003f);PortableCoverVisual.Text(root.transform,label,true);}
            return true;
        }
        private static Material Material(Shader shader,float alpha)
        {
            var colour=Color.green;colour.a=alpha;var material=new Material(shader){name="Switchboards.CoverPreview.Green",color=colour};
            material.SetInt("_SrcBlend",(int)BlendMode.SrcAlpha);material.SetInt("_DstBlend",(int)BlendMode.OneMinusSrcAlpha);material.SetInt("_Cull",(int)CullMode.Off);material.SetInt("_ZWrite",0);return material;
        }
    }
    internal static class PlacementLabelText
    {
        private static readonly System.Collections.Generic.Dictionary<Font,Material> materials=new System.Collections.Generic.Dictionary<Font,Material>();
        internal static Material For(Font font)
        {
            if(!materials.TryGetValue(font,out var material)){material=new Material(DepthLabelText.For(font)){name="Switchboards.PlacementLabel.Green",color=Color.green};material.EnableKeyword("_EMISSION");material.SetColor("_EmissionColor",Color.green);materials[font]=material;}
            material.mainTexture=font.material.mainTexture;return material;
        }
    }
}
