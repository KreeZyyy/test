using System;
using System.Collections.Generic;
using UnityEngine;
namespace ModularSwitchboards
{
    internal sealed class CoverPreviewGeometry
    {
        internal readonly List<Vector3> Vertices=new List<Vector3>();
        internal readonly List<int>[] Triangles={new List<int>(),new List<int>(),new List<int>()};
        internal static CoverPreviewGeometry Build(IList<InnerCoverLayout.Cell> body,IList<InnerCoverLayout.Cell> hatch,IList<CoverIconRect> labels)
        {
            var result=new CoverPreviewGeometry();const float pitch=.025f,width=.002f;
            foreach(var c in hatch)
            {
                for(int k=(int)Math.Floor((c.Bottom-c.Right)/pitch)-1;k<=(int)Math.Ceiling((c.Top-c.Left)/pitch)+1;k++)
                {
                    var polygon=new List<Vector3>{new Vector3(c.Left,c.Bottom,0),new Vector3(c.Right,c.Bottom,0),new Vector3(c.Right,c.Top,0),new Vector3(c.Left,c.Top,0)};
                    polygon=Clip(polygon,k*pitch-width*.707107f,true);polygon=Clip(polygon,k*pitch+width*.707107f,false);
                    result.Polygon(polygon,0);
                }
            }
            foreach(var c in body)
            {
                if(c.West)result.Ribbon(c.Left,c.Bottom,c.Left,c.Top,.0018f,.0005f,1);
                if(c.East)result.Ribbon(c.Right,c.Bottom,c.Right,c.Top,.0018f,.0005f,1);
                if(c.South)result.Ribbon(c.Left,c.Bottom,c.Right,c.Bottom,.0018f,.0005f,1);
                if(c.North)result.Ribbon(c.Left,c.Top,c.Right,c.Top,.0018f,.0005f,1);
            }
            foreach(var r in labels)
            {
                result.Ribbon(r.Left,r.Bottom,r.Right,r.Bottom,.0014f,.003f,2);result.Ribbon(r.Left,r.Top,r.Right,r.Top,.0014f,.003f,2);
                result.Ribbon(r.Left,r.Bottom,r.Left,r.Top,.0014f,.003f,2);result.Ribbon(r.Right,r.Bottom,r.Right,r.Top,.0014f,.003f,2);
            }
            return result;
        }
        private static List<Vector3> Clip(List<Vector3> polygon,float offset,bool positive)
        {
            var output=new List<Vector3>();if(polygon.Count==0)return output;
            var a=polygon[polygon.Count-1];float da=a.y-a.x-offset;
            foreach(var b in polygon)
            {
                float db=b.y-b.x-offset;bool ina=positive?da>=0:da<=0,inb=positive?db>=0:db<=0;
                if(ina!=inb){float t=da/(da-db);output.Add(new Vector3(a.x+(b.x-a.x)*t,a.y+(b.y-a.y)*t,0));}
                if(inb)output.Add(b);a=b;da=db;
            }
            return output;
        }
        private void Ribbon(float ax,float ay,float bx,float by,float width,float z,int group)
        {
            float dx=bx-ax,dy=by-ay,length=(float)Math.Sqrt(dx*dx+dy*dy);if(length<.000001f)return;
            float nx=-dy/length*width*.5f,ny=dx/length*width*.5f;
            Polygon(new[]{new Vector3(ax+nx,ay+ny,z),new Vector3(bx+nx,by+ny,z),new Vector3(bx-nx,by-ny,z),new Vector3(ax-nx,ay-ny,z)},group);
        }
        private void Polygon(IList<Vector3> points,int group)
        {
            if(points.Count<3)return;int start=Vertices.Count;foreach(var p in points)Vertices.Add(p);
            for(int i=1;i<points.Count-1;i++){Triangles[group].Add(start);Triangles[group].Add(start+i);Triangles[group].Add(start+i+1);}
        }
    }
}
