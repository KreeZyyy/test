using UnityEngine;
using UnityEngine.Rendering;
namespace ModularSwitchboards
{
    internal static class PlacementOutline
    {
        internal static bool Apply(GameObject cursor)
        {
            var filter=cursor.GetComponent<MeshFilter>();var source=filter?.sharedMesh;var renderer=cursor.GetComponent<MeshRenderer>();
            var shader=Shader.Find("Hidden/Internal-Colored"); // Same shader as native Wireframe.CreateLineMaterial.
            if(source==null||renderer==null||shader==null||!shader.isSupported)return false;
            var mesh=new Mesh{name="Switchboards.PlacementOutline",indexFormat=source.indexFormat};
            var vertices=source.vertices;mesh.vertices=vertices;mesh.SetIndices(PlacementOutlineGeometry.Build(vertices,source.triangles),MeshTopology.Lines,0);mesh.RecalculateBounds();
            var material=new Material(shader){name="Switchboards.PlacementOutline.Lines"};
            material.SetInt("_SrcBlend",(int)BlendMode.SrcAlpha);material.SetInt("_DstBlend",(int)BlendMode.OneMinusSrcAlpha);
            material.SetInt("_Cull",(int)CullMode.Off);material.SetInt("_ZWrite",0);
            renderer.sharedMaterial=material;renderer.shadowCastingMode=ShadowCastingMode.Off;renderer.receiveShadows=false;
            filter.sharedMesh=mesh;var lifetime=cursor.AddComponent<PlacementOutlineLifetime>();lifetime.Owned=mesh;lifetime.OwnedMaterial=material;
            return true;
        }
    }
    internal sealed class PlacementOutlineLifetime:MonoBehaviour
    {
        internal Mesh Owned;internal Material OwnedMaterial;internal Material[] ExtraMaterials;
        private void OnDestroy(){if(Owned!=null)Destroy(Owned);if(OwnedMaterial!=null)Destroy(OwnedMaterial);if(ExtraMaterials!=null)foreach(var material in ExtraMaterials)if(material!=null)Destroy(material);}
    }
}
