using System.Collections.Generic;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class CabinetLayout
    {
        internal static bool Reversed(string prefab)=>prefab==SwitchboardsMod.ReverseCabinetName;
        internal static float YSign(string prefab)=>Reversed(prefab)?-1f:1f;
        internal static Vector3 Map(string prefab,Vector3 point)=>new Vector3(point.x,point.y*YSign(prefab),point.z);
        internal static Bounds MapBounds(string prefab,Bounds bounds)=>new Bounds(Map(prefab,bounds.center),bounds.size);
        internal static Vector3 InputCell(string prefab)=>Map(prefab,new Vector3(0,.5f,0));
        internal static Vector3 InputOutward(string prefab)=>Map(prefab,Vector3.up);
        internal static Vector3 OutputBodyCell(string prefab,float gridSize)=>Map(prefab,Vector3.down*gridSize);
        // Reflection changes handedness: reverse every triangle as well as Y.
        // Work on per-instance generated geometry, never a shared source mesh.
        internal static void MapMesh(string prefab,List<Vector3> vertices,List<int> indices)
        {
            if(!Reversed(prefab))return;
            for(int i=0;i<vertices.Count;i++)vertices[i]=Map(prefab,vertices[i]);
            for(int i=0;i<indices.Count;i+=3){int t=indices[i+1];indices[i+1]=indices[i+2];indices[i+2]=t;}
        }
    }
}
