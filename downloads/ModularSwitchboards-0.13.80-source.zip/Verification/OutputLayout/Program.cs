using System;
struct Vector3 {public float x,y,z;public Vector3(float x,float y,float z){this.x=x;this.y=y;this.z=z;}public static Vector3 operator+(Vector3 a,Vector3 b)=>new(a.x+b.x,a.y+b.y,a.z+b.z);public static Vector3 operator-(Vector3 a,Vector3 b)=>new(a.x-b.x,a.y-b.y,a.z-b.z);public static Vector3 operator-(Vector3 a)=>new(-a.x,-a.y,-a.z);public static Vector3 operator*(Vector3 a,float b)=>new(a.x*b,a.y*b,a.z*b);public static float Dot(Vector3 a,Vector3 b)=>a.x*b.x+a.y*b.y+a.z*b.z;public Grid3 ToGrid(float size,float offset)=>new(new Vector3((float)Math.Round((x-offset-size/2)/size)*size+offset+size/2,(float)Math.Round((y-offset-size/2)/size)*size+offset+size/2,(float)Math.Round((z-offset-size/2)/size)*size+offset+size/2));}
struct Grid3{public Vector3 p;public Grid3(Vector3 p){this.p=p;}public Vector3 ToVector3()=>p;}
static class SmallGrid{public const float SmallGridSize=.5f,SmallGridOffset=.25f;}
static class NativeCableLayout{
 internal struct Socket{internal Vector3 Point,Forward,ContactPoint;internal Grid3 CableCell,BodyCell;}
 internal static Socket Current;
 internal static Socket Read(Vector3 cell,Vector3 axis)=>Current;
        internal static Socket ReadForBody(Vector3 deviceBodyCell,Vector3 outward)
        {
            var socket=Read(deviceBodyCell+outward*SmallGrid.SmallGridSize,outward);
            var body=deviceBodyCell.ToGrid(SmallGrid.SmallGridSize,SmallGrid.SmallGridOffset);
            var shift=body.ToVector3()-socket.BodyCell.ToVector3();
            socket.Point+=shift;
            socket.CableCell=socket.Point.ToGrid(SmallGrid.SmallGridSize,SmallGrid.SmallGridOffset);
            socket.BodyCell=body;
            if(Vector3.Dot(socket.Forward,-outward)<.99f)
                throw new InvalidOperationException("Native socket faces away from the intended device body cell.");
            // The mouth sits on the shared face between the cable and body cells.
            // A Connection.Transform may identify a cell centre, not the visible end.
            socket.ContactPoint=(socket.Point+body.ToVector3())*.5f;
            return socket;
        }

}
class Program{static void Main(){int count=0;foreach(float row in new[]{-.5f,.5f}){var body=new Vector3(0,row,0);foreach(float x in new[]{-.5f,0f,.5f})foreach(float y in new[]{-.5f,0f,.5f})foreach(float z in new[]{-.5f,0f,.5f})foreach(float side in new[]{-1f,1f}){var outward=new Vector3(side,0,0);var rawBody=new Vector3(x,y,z);NativeCableLayout.Current=new(){Point=rawBody+outward*.5f,Forward=-outward,BodyCell=new(rawBody)};var socket=NativeCableLayout.ReadForBody(body,outward);var expected=body+outward*.25f;var d=socket.ContactPoint-expected;if(Vector3.Dot(d,d)>1e-10)throw new Exception("physical mouth misplaced");d=socket.Point-(body+outward*.5f);if(Vector3.Dot(d,d)>1e-10)throw new Exception("logical cell misplaced");if(Math.Abs(socket.ContactPoint.y)-.0351f<=.116f)throw new Exception("bar overlaps central rear box");count++;}}Console.WriteLine($"Production ReadForBody passed {count} pivot-offset cases: fixed device row, separate cable cells, shared-face apertures and vertical clearance.");}}
