using System.Xml.Serialization;using Assets.Scripts.Objects;using LibConstruct;namespace ModularSwitchboards{    public sealed class SwitchboardCabinetSaveData : StructureSaveData
    {
        [XmlElement] public PlacementBoardHostSaveData RailBoard;
        [XmlArray] public CabinetWireSaveData[] Wires;
        [XmlElement] public int CoverSchema;
        [XmlElement] public PlacementBoardHostSaveData CoverBoard;
        [XmlElement] public PlacementBoardHostSaveData DoorBoard;
        [XmlElement] public PlacementBoardHostSaveData BridgeBoard;
        [XmlElement] public PlacementBoardHostSaveData DoorLabels;
    }

}