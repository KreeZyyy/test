import bpy
from pathlib import Path
from mathutils import Vector
root=Path(__file__).resolve().parent.parent
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
metal=bpy.data.materials.new('GalvanizedSteel');metal.diffuse_color=(.52,.55,.58,1);metal.use_nodes=True
p=metal.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(.52,.55,.58,1);p.inputs['Metallic'].default_value=.2;p.inputs['Roughness'].default_value=.85
channel=metal.copy();channel.name='MatteDarkChannel';channel.diffuse_color=(.22,.24,.26,1)
channel.node_tree.nodes.get('Principled BSDF').inputs['Base Color'].default_value=(.22,.24,.26,1)
length=.324
# Same five sheet segments as the runtime TH35 mesh, coordinates converted to Blender.
def box(name,loc,size,material=metal):
 bpy.ops.mesh.primitive_cube_add(size=1,location=(loc[0],-loc[2],loc[1]));o=bpy.context.object;o.name=name;o.dimensions=(size[0],size[2],size[1]);bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.append(material)
box('DIN35_Web',(0,0,.0005),(length,.022,.001),channel)
for s in [-1,1]:
 box('DIN35_Sidewall',(0,s*.0115,.004),(length,.001,.007))
 box('DIN35_Flange',(0,s*.0145,.007),(length,.006,.001))
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=24;scene.cycles.use_denoising=False
scene.render.resolution_x=256;scene.render.resolution_y=256;scene.render.resolution_percentage=100;scene.render.film_transparent=True
scene.world.color=(.4,.4,.4)
bpy.ops.object.camera_add(location=(.26,-.38,.28));camera=bpy.context.object;camera.rotation_euler=(Vector((0,0,0))-camera.location).to_track_quat('-Z','Y').to_euler();camera.data.type='ORTHO';camera.data.ortho_scale=.38;scene.camera=camera
for loc,power in [((.1,-.3,.4),40),((-.3,.1,.2),25)]:
 bpy.ops.object.light_add(type='AREA',location=loc);bpy.context.object.data.energy=power;bpy.context.object.data.size=.5
bpy.context.preferences.filepaths.save_version=0
bpy.ops.wm.save_as_mainfile(filepath=str(root/'Art/DinRail.blend'))
scene.render.filepath=str(root/'Assets/Icons/DinRail.png');bpy.ops.render.render(write_still=True)
