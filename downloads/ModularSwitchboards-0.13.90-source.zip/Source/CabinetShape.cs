using System;
using System.Linq;
using Assets.Scripts.Objects;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class CabinetShape
    {
        internal static bool Medium(string name)=>name==SwitchboardsMod.MediumCabinetName;
        internal static int FrameKits(string name)=>Medium(name)?3:1;
        internal static int PlasticSheets(string name)=>Medium(name)?5:2;
        internal static float Width(string name)=>Medium(name)?.8f:.4f;
        internal static float Height(string name)=>Medium(name)?1f:.5f;
        internal static float OffsetY(string name)=>0;
        internal static float RailWidth(string name)=>Medium(name)?.65f:DinLayout.CabinetInnerWidth;
        internal static float BridgeInset(string name)=>Medium(name)?.073f:.023f;
        internal static float InnerWidth(string name)=>Width(name)-.05f;
        internal static int[] Rows(string name)=>Medium(name)?new[]{-150,0,150}:new[]{-60,60};
        internal static int SnapRow(string name,int value)=>Rows(name).OrderBy(y=>Math.Abs(y-value)).First();
        internal static float HalfSpan(string name)=>(DinLayout.FullModuleCount(RailWidth(name))-1)*DinLayout.SlotPitch*.5f;
        internal static int OutputCount(string name)=>Medium(name)?3:2;
        internal static ConnectionRole OutputRole(int index)=>index==0?ConnectionRole.Output:index==1?ConnectionRole.Output2:ConnectionRole.Waste;
        internal static int MinDoorY(string name)=>Medium(name)?-20:-10;
        internal static int MinBridgeY(string name)=>Medium(name)?-190:-90;
        internal static int MaxBridgeY(string name)=>Medium(name)?180:80;
        internal static float TerminalY(string name)=>Medium(name)?.44f:.211f;
        internal static Vector3 Terminal(string name,int index)
            =>index==0?new Vector3(0,TerminalY(name),.014f):new Vector3(Medium(name)?(index==1?.23f:index==2?0:-.23f):(index==1?.108f:-.108f),-TerminalY(name),.014f);
    }
}
