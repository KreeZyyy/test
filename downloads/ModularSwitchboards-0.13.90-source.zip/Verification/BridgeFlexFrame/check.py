"""Checks production-generated flex centre lines against the real frame/housing triangles.
Run Wiring with BRIDGE_FLEX_EXPORT first, then pass that JSON path here.
Contact lead intervals at either end are excluded; terminal bodies bury those leads.
"""
import numpy as np,struct,json,sys
from pathlib import Path
root=Path(__file__).resolve().parents[2]
f=open(root/'Assets/Cabinet.meshbin','rb');assert f.read(4)==b'SBMS';ver,mc,n=struct.unpack('<iii',f.read(12));f.read(mc*24);triangles=[]
for k in range(2):
 count=struct.unpack('<i',f.read(4))[0];v=np.frombuffer(f.read(count*24),dtype='<f4').reshape(-1,6)[:,:3].copy();v[:,:2]*=2
 for role in range(mc):
  count=struct.unpack('<i',f.read(4))[0];ids=np.frombuffer(f.read(count*4),dtype='<i4');triangles.extend(v[ids.reshape(-1,3)])
t=np.array(triangles);e1=t[:,1]-t[:,0];e2=t[:,2]-t[:,0]
def hit(a,b):
 direction=b-a;h=np.cross(direction,e2);det=np.einsum('ij,ij->i',e1,h);ok=np.abs(det)>1e-10;inv=np.divide(1,det,out=np.zeros_like(det),where=ok);s=a-t[:,0];u=inv*np.einsum('ij,ij->i',s,h);q=np.cross(s,e1);v=inv*np.einsum('j,ij->i',direction,q);distance=inv*np.einsum('ij,ij->i',e2,q)
 return np.any(ok&(u>=0)&(v>=0)&(u+v<=1)&(distance>1e-5)&(distance<.99999))
cases=json.loads(Path(sys.argv[1]).read_text());checks=0
for case in cases:
 points=np.array(case['Points'])
 for i in range(3,len(points)-4):
  assert not hit(points[i],points[i+1]),f"Hidden flex middle: leaf={case['Right']} angle={case['Angle']} segment={i}"
  checks+=1
print(f'Actual Medium frame/housing: {len(cases)} leaf/angle poses, {checks} production flex middle segments do not cross frame triangles. Contact leads and full tube thickness need live visual verification.')
