using System;using System.Linq;using System.Collections.Generic;using UnityEngine;namespace ModularSwitchboards{static class OvenInputSupport{        internal static void BuildTransition(Bounds bottom,Bounds top,float high,List<Vector3> vertices,List<int> indices,bool nativeBevel=false,Vector3[] nativeInterface=null)
        {
            float low=bottom.min.y;
            var baseOutline=Outline(bottom.min.x,bottom.max.x,bottom.min.z,bottom.max.z,.004f);
            var exact=nativeInterface==null?null:NativeLugSection.OrderXZ(nativeInterface);
            var tunnelOutline=exact!=null?exact.Select(v=>new Vector2(v.x,v.z)).ToList():nativeBevel?InputBevel(top):Outline(top.min.x,top.max.x,top.min.z,top.max.z,.004f);
            float shoulder=bottom.max.y;
            // Two vertical extrusions with a planar Boolean union at their join.
            // Do not bridge corresponding corners: the footprints overlap only partly.
            AddWalls(baseOutline,low,shoulder,vertices,indices);
            if(exact!=null)AddInterfaceWalls(exact,shoulder,vertices,indices);else AddWalls(tunnelOutline,shoulder,high,vertices,indices);
            AddCap(baseOutline,low,false,vertices,indices);
            foreach(var piece in Difference(baseOutline,tunnelOutline))AddCap(piece,shoulder,true,vertices,indices);
            foreach(var piece in Difference(tunnelOutline,baseOutline))AddCap(piece,shoulder,false,vertices,indices);
        }

        private static void AddInterfaceWalls(Vector3[] ring,float low,List<Vector3> vertices,List<int> indices)
        {
            int start=vertices.Count,n=ring.Length;
            foreach(var p in ring)vertices.Add(new Vector3(p.x,low,p.z));vertices.AddRange(ring);
            for(int i=0;i<n;i++){int a=start+i,b=start+(i+1)%n;indices.AddRange(new[]{a,b+n,b,a,a+n,b+n});}
        }
        internal static List<Vector2> InputBevel(Bounds top)
        {
            float xmin=top.min.x,xmax=top.max.x,zmin=top.min.z,zmax=top.max.z;
            // Same native APC front bevel depth and slope used by the output corridors.
            float depth=Mathf.Min(.010f,Mathf.Min((zmax-zmin)*.3f,(xmax-xmin)*.5f*.4f/.5776f));
            float inset=depth*.5776f;
            return new List<Vector2>{new Vector2(xmin+inset,zmin),new Vector2(xmax-inset,zmin),
                new Vector2(xmax,zmin+depth),new Vector2(xmax,zmax),new Vector2(xmin,zmax),new Vector2(xmin,zmin+depth)};
        }

        private static List<Vector2> Outline(float xmin,float xmax,float zmin,float zmax,float radius)
        {
            radius=Mathf.Min(radius,Mathf.Min(xmax-xmin,zmax-zmin)*.25f);
            var result=new List<Vector2>();
            for(int corner=0;corner<4;corner++)
            {
                float x=(corner==0||corner==3)?xmax-radius:xmin+radius;
                float z=corner<2?zmax-radius:zmin+radius;
                for(int part=0;part<=6;part++)
                {
                    float angle=(corner*90f+part*15f)*Mathf.Deg2Rad;
                    result.Add(new Vector2(x+radius*Mathf.Cos(angle),z+radius*Mathf.Sin(angle)));
                }
            }
            return result;
        }

        private static void AddWalls(List<Vector2> outline,float low,float high,List<Vector3> vertices,List<int> indices)
        {
            int start=vertices.Count,n=outline.Count;
            foreach(float y in new[]{low,high})foreach(var p in outline)vertices.Add(new Vector3(p.x,y,p.y));
            for(int i=0;i<n;i++)
            {
                int a=start+i,b=start+(i+1)%n;
                indices.AddRange(new[]{a,b+n,b,a,a+n,b+n});
            }
        }

        private static float Side(Vector2 p,Vector2 a,Vector2 b)=>(b.x-a.x)*(p.y-a.y)-(b.y-a.y)*(p.x-a.x);

        private static List<Vector2> Clip(List<Vector2> polygon,Vector2 a,Vector2 b,bool inside)
        {
            var result=new List<Vector2>();
            for(int i=0;i<polygon.Count;i++)
            {
                var p=polygon[i];var q=polygon[(i+1)%polygon.Count];
                float dp=Side(p,a,b),dq=Side(q,a,b);
                bool pin=inside?dp>=0:dp<=0,qin=inside?dq>=0:dq<=0;
                if(pin)result.Add(p);
                if(pin!=qin)
                {
                    float t=dp/(dp-dq);
                    result.Add(new Vector2(p.x+(q.x-p.x)*t,p.y+(q.y-p.y)*t));
                }
            }
            return result;
        }

        // Partition A minus convex B into convex, nonoverlapping pieces.
        private static List<List<Vector2>> Difference(List<Vector2> a,List<Vector2> b)
        {
            var pieces=new List<List<Vector2>>();var remaining=a;
            for(int i=0;i<b.Count && remaining.Count>=3;i++)
            {
                var outside=Clip(remaining,b[i],b[(i+1)%b.Count],false);
                if(outside.Count>=3)pieces.Add(outside);
                remaining=Clip(remaining,b[i],b[(i+1)%b.Count],true);
            }
            return pieces;
        }

        private static void AddCap(List<Vector2> polygon,float y,bool up,List<Vector3> vertices,List<int> indices)
        {
            // Separate cap vertices preserve a crisp, flat shoulder normal.
            int start=vertices.Count;
            foreach(var p in polygon)vertices.Add(new Vector3(p.x,y,p.y));
            for(int i=1;i+1<polygon.Count;i++)
            {
                if(Mathf.Abs(Side(polygon[i+1],polygon[0],polygon[i]))<1e-12f)continue;
                if(up)indices.AddRange(new[]{start,start+i+1,start+i});
                else indices.AddRange(new[]{start,start+i,start+i+1});
            }
        }

}}