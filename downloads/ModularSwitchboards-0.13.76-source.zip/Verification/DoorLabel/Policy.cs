using System;using System.Linq;using Assets.Scripts.GridSystem;using LibConstruct; namespace ModularSwitchboards{public partial class DoorLabel{        internal static DinBreaker Target(PlacementBoard board,Grid3 p,bool emergency=false)
        {
            var host=board?.PrimaryHost as SwitchboardCabinet;
            return host?.DoorBoard?.Structures.OfType<DinBreaker>().FirstOrDefault(m=>!m.IsBeingDestroyed&&m.IsStructureCompleted&&!m.IsCursor&&(emergency?m.IsDoorStop:m.IsDoorLed||m.IsDoorRoundSwitch)&&Same(host.DoorBoard.WorldToGrid(m.transform.position),p));
        }
        private static bool Same(Grid3 a,Grid3 b)=>a.x==b.x&&a.y==b.y&&a.z==b.z;
        internal static bool CanPlace(PlacementBoard board,Grid3 p,int rotation,bool emergency=false)
            =>board is DoorLabelBoard&&board.PrimaryHost is SwitchboardCabinet host&&host.IsStructureCompleted&&DoorModuleLayout.Fits(p.x,p.y,p.z,rotation)&&Target(board,p,emergency)!=null&&!board.Structures.OfType<DoorLabel>().Any(l=>Same(board.WorldToGrid(l.transform.position),p));
        internal static bool Attached(DinBreaker owner)
        {
            var host=CabinetWiring.CabinetOf(owner);var board=host?.DoorLabels;
            if(board==null||owner.Board!=host.DoorBoard)return false;
            var p=owner.Board.WorldToGrid(owner.transform.position);
            return board.Structures.OfType<DoorLabel>().Any(l=>!l.IsBeingDestroyed&&Same(board.WorldToGrid(l.transform.position),p));
        }
}}