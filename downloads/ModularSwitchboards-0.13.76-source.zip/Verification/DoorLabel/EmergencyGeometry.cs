using System.Collections.Generic;using UnityEngine;namespace ModularSwitchboards{    internal static class EmergencyStopLabelModel
    {
        internal const float Inner=.0213f,Outer=.039f;
        internal static Mesh Build()
        {
            var v=new List<Vector3>();var t=new List<int>();
            for(int i=0;i<64;i++)
            {
                float a=i*Mathf.PI/32,b=(i+1)*Mathf.PI/32;
                var ia=new Vector3(Inner*Mathf.Cos(a),Inner*Mathf.Sin(a),-.0008f);var ib=new Vector3(Inner*Mathf.Cos(b),Inner*Mathf.Sin(b),-.0008f);
                var oa=new Vector3(Outer*Mathf.Cos(a),Outer*Mathf.Sin(a),-.0008f);var ob=new Vector3(Outer*Mathf.Cos(b),Outer*Mathf.Sin(b),-.0008f);
                var iaf=new Vector3(ia.x,ia.y,.0012f);var ibf=new Vector3(ib.x,ib.y,.0012f);var oaf=new Vector3(oa.x,oa.y,.0012f);var obf=new Vector3(ob.x,ob.y,.0012f);
                Quad(v,t,oa,ob,obf,oaf);Quad(v,t,ib,ia,iaf,ibf);Quad(v,t,iaf,oaf,obf,ibf);Quad(v,t,ib,ob,oa,ia);
            }
            var mesh=new Mesh{name="Emergency Stop label ring"};mesh.SetVertices(v);mesh.subMeshCount=5;
            for(int i=0;i<5;i++)mesh.SetTriangles(i==1?t.ToArray():new int[0],i);
            mesh.RecalculateNormals();mesh.RecalculateBounds();return mesh;
        }
        private static void Quad(List<Vector3> v,List<int> t,Vector3 a,Vector3 b,Vector3 c,Vector3 d){int p=v.Count;v.AddRange(new[]{a,b,c,d});t.AddRange(new[]{p,p+1,p+2,p,p+2,p+3});}
}}