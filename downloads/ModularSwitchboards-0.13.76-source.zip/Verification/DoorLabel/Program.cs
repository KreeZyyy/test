using System;using System.Linq;using System.Collections.Generic;using ModularSwitchboards;using UnityEngine;using LibConstruct;using Assets.Scripts.GridSystem;
namespace UnityEngine{
 public struct Vector3{public float x,y,z;public Vector3(float x,float y,float z){this.x=x;this.y=y;this.z=z;}public static Vector3 right=>new(1,0,0);public static Vector3 left=>new(-1,0,0);public static Vector3 up=>new(0,1,0);public static Vector3 down=>new(0,-1,0);public static Vector3 forward=>new(0,0,1);public static Vector3 back=>new(0,0,-1);public static Vector3 operator +(Vector3 a,Vector3 b)=>new(a.x+b.x,a.y+b.y,a.z+b.z);public static Vector3 operator -(Vector3 a,Vector3 b)=>new(a.x-b.x,a.y-b.y,a.z-b.z);public static Vector3 operator -(Vector3 a)=>new(-a.x,-a.y,-a.z);public static Vector3 operator *(Vector3 a,float b)=>new(a.x*b,a.y*b,a.z*b);public static Vector3 Scale(Vector3 a,Vector3 b)=>new(a.x*b.x,a.y*b.y,a.z*b.z);public static Vector3 Cross(Vector3 a,Vector3 b)=>new(a.y*b.z-a.z*b.y,a.z*b.x-a.x*b.z,a.x*b.y-a.y*b.x);}
 public static class Mathf{public const float PI=(float)Math.PI;public static float Cos(float v)=>(float)Math.Cos(v);public static float Sin(float v)=>(float)Math.Sin(v);public static float Abs(float v)=>Math.Abs(v);}
 public class Mesh{public string name;public Vector3[] vertices;public int subMeshCount;public Dictionary<int,int[]> triangles=new();public void SetVertices(List<Vector3> v)=>vertices=v.ToArray();public void SetTriangles(int[] t,int i)=>triangles[i]=t;public void RecalculateNormals(){}public void RecalculateBounds(){}}
 public class Transform{public Vector3 position;}
}
namespace Assets.Scripts.GridSystem{public struct Grid3{public int x,y,z;public Grid3(int x,int y,int z){this.x=x;this.y=y;this.z=z;}}}
namespace LibConstruct{public class PlacementBoard{public object PrimaryHost;public List<object> Structures=new();public Grid3 WorldToGrid(Vector3 p)=>new((int)Math.Round(p.x*100),(int)Math.Round((p.y-DoorModuleLayout.GridOffsetY)*100),0);}}
namespace ModularSwitchboards{
 public class DoorLabelBoard:PlacementBoard{}
 public class SwitchboardCabinet{public bool IsStructureCompleted=true;public PlacementBoard DoorBoard;public DoorLabelBoard DoorLabels;}
 public class DinBreaker{public bool IsBeingDestroyed,IsDoorLed,IsDoorRoundSwitch,IsDoorStop,IsCursor;public bool IsStructureCompleted=true;public PlacementBoard Board;public Transform transform=new();}
 public partial class DoorLabel{public bool IsBeingDestroyed;public Transform transform=new();}
 public static class CabinetWiring{public static SwitchboardCabinet CabinetOf(DinBreaker owner)=>owner.Board?.PrimaryHost as SwitchboardCabinet;}
}
class Program{
 static int checks;static void Check(bool ok,string message){checks++;if(!ok)throw new Exception(message);}
 static void Main(){
 var host=new SwitchboardCabinet();host.DoorBoard=new(){PrimaryHost=host};host.DoorLabels=new(){PrimaryHost=host};var board=host.DoorLabels;
 var module=new DinBreaker{IsDoorLed=true,Board=host.DoorBoard};module.transform.position=new Vector3(0,DoorModuleLayout.GridOffsetY,0);host.DoorBoard.Structures.Add(module);
 Check(DoorLabel.CanPlace(board,new(0,0,0),0),"LED accepts one label");Check(!DoorLabel.CanPlace(board,new(10,0,0),0),"Empty position rejected");
 var label=new DoorLabel();label.transform.position=module.transform.position;board.Structures.Add(label);Check(!DoorLabel.CanPlace(board,new(0,0,0),0),"Duplicate label rejected");Check(DoorLabel.Attached(module),"Parent removal blocked while labelled");board.Structures.Clear();Check(!DoorLabel.Attached(module),"Removing label unlocks module removal");
 module.IsDoorLed=false;module.IsDoorRoundSwitch=true;Check(DoorLabel.Target(board,new(0,0,0))==module&&DoorLabel.CanPlace(board,new(0,0,0),0),"Same prefab fits round selector");module.IsDoorRoundSwitch=false;Check(!DoorLabel.CanPlace(board,new(0,0,0),0),"Main/STOP/bridge rejected");module.IsDoorLed=true;module.IsBeingDestroyed=true;Check(!DoorLabel.CanPlace(board,new(0,0,0),0),"Destroyed target rejected");module.IsBeingDestroyed=false;module.IsStructureCompleted=false;Check(!DoorLabel.CanPlace(board,new(0,0,0),0),"Incomplete module rejected");module.IsStructureCompleted=true;module.IsCursor=true;Check(!DoorLabel.CanPlace(board,new(0,0,0),0),"Cursor module rejected");module.IsCursor=false;host.IsStructureCompleted=false;Check(!DoorLabel.CanPlace(board,new(0,0,0),0),"Incomplete cabinet rejected");host.IsStructureCompleted=true;
 Check(!DoorLabel.CanPlace(host.DoorBoard,new(0,0,0),0)&&!DoorLabel.CanPlace(null,new(0,0,0),0),"Wrong/missing board rejected");Check(!DoorLabel.CanPlace(board,new(0,0,0),1),"Wrong rotation rejected");
 foreach(int x in new[]{-10,0,10})foreach(int y in new[]{-10,0,10}){Check(DoorModuleLayout.Fits(x,y,0,0),"Same nine grid positions");float top=y*.01f+DoorModuleLayout.GridOffsetY+.05f;Check(top<.14f,"Label clears warning bottom");}
 var mesh=DoorLabelModel.Build();Check(mesh.subMeshCount==5&&mesh.triangles[0].Length>0&&mesh.triangles[1].Length==36,"Black holder and white plate");
 foreach(var v in mesh.vertices)Check(Math.Abs(v.x)<=.0221f&&v.y>=-.0201f&&v.y<=.0501f&&v.z>=-.0016f&&v.z<=.0024f,"Mesh fits label bounds");
 foreach(var indices in mesh.triangles.Values)for(int i=0;i<indices.Length;i+=3){var a=mesh.vertices[indices[i]];var b=mesh.vertices[indices[i+1]];var c=mesh.vertices[indices[i+2]];var n=Vector3.Cross(b-a,c-a);Check(n.x*n.x+n.y*n.y+n.z*n.z>1e-18,"No degenerate faces");}
 bool HasFront(float x,float y){foreach(var list in mesh.triangles.Values)for(int i=0;i<list.Length;i+=3){var a=mesh.vertices[list[i]];var b=mesh.vertices[list[i+1]];var c=mesh.vertices[list[i+2]];float det=(b.y-c.y)*(a.x-c.x)+(c.x-b.x)*(a.y-c.y);if(Math.Abs(det)<1e-12)continue;float u=((b.y-c.y)*(x-c.x)+(c.x-b.x)*(y-c.y))/det,w=((c.y-a.y)*(x-c.x)+(a.x-c.x)*(y-c.y))/det;if(u>=0&&w>=0&&u+w<=1)return true;}return false;}
 Check(!HasFront(0,0)&&!HasFront(.0155f,0),"Opening leaves LED/selector face unobstructed");Check(HasFront(.017f,0)&&HasFront(0,.034f),"Ring and nameplate are physical surfaces");
 Check(HasFront(.014f,.016f)&&HasFront(0,.019f),"Continuous black shoulders connect ring to nameplate");
 Check(!HasFront(.0155f,0)&&HasFront(.0159f,0),"Ring underlaps 16 mm bezel by 0.2 mm to hide background seams");

 module.IsDoorLed=false;module.IsDoorRoundSwitch=false;module.IsDoorStop=true;module.transform.position=new Vector3(0,DoorModuleLayout.GridOffsetY,0);
 Check(DoorLabel.CanPlace(board,new(0,0,0),0,true),"Emergency ring fits STOP");Check(!DoorLabel.CanPlace(board,new(0,0,0),0),"Ordinary Door Label rejects STOP");
 label.transform.position=module.transform.position;board.Structures.Add(label);Check(!DoorLabel.CanPlace(board,new(0,0,0),0,true)&&DoorLabel.Attached(module),"Emergency duplicate and parent removal blocked");board.Structures.Clear();
 module.IsDoorStop=false;module.IsDoorLed=true;Check(!DoorLabel.CanPlace(board,new(0,0,0),0,true),"Emergency ring rejects LED");module.IsDoorLed=false;module.IsDoorRoundSwitch=true;Check(!DoorLabel.CanPlace(board,new(0,0,0),0,true),"Emergency ring rejects selector");module.IsDoorRoundSwitch=false;Check(!DoorLabel.CanPlace(board,new(0,0,0),0,true),"Emergency ring rejects main/bridge");
 var emergency=EmergencyStopLabelModel.Build();Check(emergency.subMeshCount==5&&emergency.triangles[1].Length>0,"Yellow ring submesh");
 foreach(var v in emergency.vertices){float radius=(float)Math.Sqrt(v.x*v.x+v.y*v.y);Check(radius>=.02129f&&radius<=.03901f,"Ring leaves red button radius 21 mm clear");Check(.1f+DoorModuleLayout.GridOffsetY+v.y<.14f,"Emergency label clears warning in upper row");}
 foreach(var indices in emergency.triangles.Values)for(int i=0;i<indices.Length;i+=3){var a=emergency.vertices[indices[i]];var b=emergency.vertices[indices[i+1]];var c=emergency.vertices[indices[i+2]];var n=Vector3.Cross(b-a,c-a);Check(n.x*n.x+n.y*n.y+n.z*n.z>1e-18,"Emergency ring faces nondegenerate");}
 if(Environment.GetEnvironmentVariable("EMERGENCY_LABEL_EXPORT")is string ep)System.IO.File.WriteAllText(ep,System.Text.Json.JsonSerializer.Serialize(new{vertices=emergency.vertices.Select(v=>new[]{v.x,v.y,v.z}),triangles=emergency.triangles}));
 if(Environment.GetEnvironmentVariable("DOOR_LABEL_EXPORT")is string path)System.IO.File.WriteAllText(path,System.Text.Json.JsonSerializer.Serialize(new{vertices=mesh.vertices.Select(v=>new[]{v.x,v.y,v.z}),triangles=mesh.triangles}));
 Console.WriteLine($"Door label: {checks} production placement/geometry/layout checks passed.");
 }
}
