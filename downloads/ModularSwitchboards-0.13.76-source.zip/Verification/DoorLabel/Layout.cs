using System;namespace ModularSwitchboards{static class DoorModuleLayout{        internal const float GridOffsetY=-.025f;
        // Snap geometrically first; occupancy must never move the selection.
        internal static int SnapSlot(int value,int min,int max)=>Math.Max(min,Math.Min(max,(int)Math.Round(value/10d,MidpointRounding.ToEven)*10));
        internal const float Pitch=.10f,Spacing=.024f;
        internal static bool Fits(int x,int y,int z,int rotation)=>x%10==0&&y%10==0&&Math.Abs(x)<=10&&Math.Abs(y)<=10&&z==0&&rotation==0;
}}