using System.Collections.Generic;using UnityEngine;namespace ModularSwitchboards{static class DinRailModel{        internal static void AddBox(List<Vector3> v,List<int> t,Vector3 center,Vector3 size)
        {
            // Separate vertices per face keep the thin sheet's edges crisp.
            var normals=new[]{Vector3.right,Vector3.left,Vector3.up,Vector3.down,Vector3.forward,Vector3.back};
            foreach(var normal in normals)
            {
                var u=Mathf.Abs(normal.y)>.5f?Vector3.right:Vector3.up;
                var w=Vector3.Cross(normal,u);
                int first=v.Count;
                foreach(var corner in new[]{-u-w,u-w,u+w,-u+w})
                    v.Add(center+Vector3.Scale(normal+corner,size)*.5f);
                t.AddRange(new[]{first,first+1,first+2,first,first+2,first+3});
            }
        }
}}