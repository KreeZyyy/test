using System;using System.Collections.Generic;using UnityEngine;using ModularSwitchboards;
namespace UnityEngine.Rendering{public enum BlendMode{Zero,One}public enum RenderQueue{AlphaTest=2450}public enum ShadowCastingMode{On,Off}}
namespace UnityEngine{
 public class Shader{public bool isSupported=true;public static bool Available=true;public static Shader Find(string n)=>Available?new():null;}
 public struct Color{public float r,g,b,a;public static Color black=>new(){a=1};}
 public class Material{public Material(Shader s){}public string name;public Color color;public object mainTexture;public int renderQueue;public Dictionary<string,float> Values=new();public Dictionary<string,string> Tags=new();public HashSet<string> Keywords=new();public void SetFloat(string n,float v)=>Values[n]=v;public void SetInt(string n,int v)=>Values[n]=v;public void SetOverrideTag(string n,string v)=>Tags[n]=v;public void EnableKeyword(string n)=>Keywords.Add(n);public void DisableKeyword(string n)=>Keywords.Remove(n);}
 public class Font{public Material material=new(new());}
 public class MeshRenderer{public Material sharedMaterial;public Rendering.ShadowCastingMode shadowCastingMode;public bool receiveShadows=true;}
 public class TextMesh{public Font font;public MeshRenderer Renderer=new();public T GetComponent<T>()where T:class=>Renderer as T;}
}
class Program{static int n;static void Check(bool ok,string m){n++;if(!ok)throw new Exception(m);}static void Main(){
 var atlas=new object();var font=new Font();font.material.mainTexture=atlas;var original=font.material;var ink=DepthLabelText.For(font);
 Check(!ReferenceEquals(ink,original),"never mutate shared native font material");Check(original.Values.Count==0&&original.Keywords.Count==0&&original.mainTexture==atlas,"global font remains untouched");
 Check(ReferenceEquals(ink.mainTexture,atlas),"glyph alpha atlas retained");Check(ink.color.r==0&&ink.color.g==0&&ink.color.b==0&&ink.color.a==1,"opaque black ink");Check(ink.Keywords.Contains("_ALPHATEST_ON")&&!ink.Keywords.Contains("_ALPHABLEND_ON"),"glyph transparency uses depth-tested cutout");Check(ink.Values["_ZWrite"]==1&&ink.renderQueue==2450,"opaque geometry depth precedes glyph fragments");
 Check(ReferenceEquals(DepthLabelText.For(font),ink),"reuse private material instead of per-frame allocation");
 var newAtlas=new object();font.material.mainTexture=newAtlas;Check(DepthLabelText.For(font).mainTexture==newAtlas,"dynamic atlas rebuild refreshed");
 var other=new Font();var otherAtlas=new object();other.material.mainTexture=otherAtlas;var otherInk=DepthLabelText.For(other);Check(!ReferenceEquals(otherInk,ink)&&otherInk.mainTexture==otherAtlas&&ink.mainTexture==newAtlas,"different fonts isolated");
 var text=new TextMesh{font=font};DepthLabelText.Apply(text);Check(text.Renderer.sharedMaterial==ink,"text renderer uses private ink");Check(!text.Renderer.receiveShadows&&text.Renderer.shadowCastingMode==UnityEngine.Rendering.ShadowCastingMode.Off,"text quads do not cast rectangular shadows");
 Shader.Available=false;bool failed=false;try{DepthLabelText.For(new Font());}catch(InvalidOperationException){failed=true;}Check(failed,"missing depth shader fails explicitly instead of returning overlay material");
 Console.WriteLine(n+" production depth text material checks passed (GPU occlusion requires game verification).");
}}
