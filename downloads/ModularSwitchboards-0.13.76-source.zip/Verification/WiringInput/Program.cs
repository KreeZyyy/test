using System;using UnityEngine;using Assets.Scripts;using Assets.Scripts.Inventory;using Assets.Scripts.Objects;using Assets.Scripts.Objects.Items;using ModularSwitchboards;
namespace UnityEngine
{
 public class Object{} public struct Vector3{}public struct Color{public static Color red,green;}public class Collider{}
 public class GameObject{public bool activeSelf=true;public void SetActive(bool active)=>activeSelf=active;}
}
namespace Assets.Scripts
{
 public static class GameManager{public static bool IsBatchMode;}
 public static class KeyManager{public static bool Primary,Secondary;public static bool GetMouseDown(string name)=>name=="Primary"?Primary:Secondary;}
 public class CursorManager{public static CursorManager Instance=new();public static Thing CursorThing;public static Hit CursorHit;public Collider CursorTargetCollider;public struct Hit{public Vector3 point;}}
 public struct PassiveTooltip{public Color color;public PassiveTooltip(Thing.DelayedActionInstance a,string s,Thing t){color=default;}}
}
namespace Assets.Scripts.Objects
{
 public class Thing{public long ReferenceId=123;public class DelayedActionInstance{public bool IsDisabled;}}
 public class DynamicThing:Thing{public Human RootParentHuman=new();public int EndCalls;public void OnPrimaryUseEnd()=>EndCalls++;}
 public class Human:Thing{}
 public class Structure:Thing{public GameObject gameObject=new();}
 public class Slot{public DynamicThing Item;public DynamicThing Get()=>Item;}
 public struct Attack{public Vector3 Position;public Attack(Slot a,Slot b,Vector3 pos,Thing owner,float completed,Collider hit,bool destroy,bool copy){Position=pos;}}
}
namespace Assets.Scripts.Objects.Items{public class WireCutter:DynamicThing{}public class Coil:DynamicThing{}public class OtherTool:DynamicThing{}}
namespace Assets.Scripts.Inventory
{
 public class SlotDisplay{public Slot Slot=new();public int SlotId;}
 public class Panel{public bool IsVisible=true;public void SetVisible(bool v)=>IsVisible=v;}
 public class Tip{public int Calls;public void HandleToolTipDisplay(PassiveTooltip t)=>Calls++;}
 public class InventoryManager
 {
  public enum Mode{Normal,Placement}public static Mode CurrentMode;public static Structure ConstructionCursor;public static Slot ActiveHandSlot;
  public SlotDisplay ActiveHand=new(){SlotId=0},InactiveHand=new(){SlotId=1};public Panel ConstructionPanel=new();public Tip TooltipRef=new();public object ActionCoroutine;public int Stops,Clears;
  public void StopCoroutine(object c)=>Stops++;public void ClearCursor()=>Clears++;
 }
}
namespace ModularSwitchboards
{
 public class SwitchboardCabinet:Structure{public bool IsOpen=true,IsStructureCompleted=true;public CabinetWiring Wiring=new();}
 public class DinBreaker:Thing{public SwitchboardCabinet Host;}
 public class Board{public object PrimaryHost;}
 public class DinRail:Thing{public Board Board;}
 public class CabinetWiring
 {
  public bool Inside=true,Disabled;public int Queries;public static bool IsCoil(DynamicThing i)=>i is Coil;
  public bool ContainsInteractionPoint(Vector3 p)=>Inside;
  public bool TryAttack(Attack a,bool mutate,out Thing.DelayedActionInstance action){if(mutate)throw new Exception("Client mutated graph directly");Queries++;action=new(){IsDisabled=Disabled};return true;}
  public static SwitchboardCabinet CabinetOf(DinBreaker b)=>b.Host;
 }
}
static class OnServer
{
 public static int Calls;public static bool Destroy;
 public static void AttackWith(Thing actor,byte active,byte other,long target,Vector3 position,float complete,bool destroy,bool copy){Calls++;Destroy=destroy;if(actor==null||complete!=1)throw new Exception("Malformed authority command");}
}
class Program
{
 static int checks;static void Check(bool v,string name){checks++;if(!v)throw new Exception(name);}
 static void Main()
 {
  var inventory=new InventoryManager();InventoryManager.ActiveHandSlot=inventory.ActiveHand.Slot;var cabinet=new SwitchboardCabinet();CursorManager.CursorThing=cabinet;
  var coil=new Coil();inventory.ActiveHand.Slot.Item=coil;inventory.InactiveHand.Slot.Item=null;
  Check(!CabinetWiringInput.ModePrefix(inventory),"coil alone not handled");Check(OnServer.Calls==0&&cabinet.Wiring.Queries==1,"hover sent a command");
  KeyManager.Primary=true;Check(!CabinetWiringInput.ModePrefix(inventory)&&OnServer.Calls==1&&!OnServer.Destroy,"one click did not send one authority command");KeyManager.Primary=false;CabinetWiringInput.ModePrefix(inventory);Check(OnServer.Calls==1,"held button repeated");
  KeyManager.Secondary=true;CabinetWiringInput.ModePrefix(inventory);Check(OnServer.Calls==2&&OnServer.Destroy,"coil right click did not cancel");KeyManager.Secondary=false;
  inventory.ActiveHand.Slot.Item=new WireCutter();KeyManager.Primary=true;CabinetWiringInput.ModePrefix(inventory);Check(OnServer.Calls==3&&!OnServer.Destroy,"cutters alone not handled by primary click");KeyManager.Primary=false;
  cabinet.Wiring.Disabled=true;KeyManager.Primary=true;CabinetWiringInput.ModePrefix(inventory);Check(OnServer.Calls==3,"disabled action sent");KeyManager.Primary=false;cabinet.Wiring.Disabled=false;
  inventory.ActiveHand.Slot.Item=new OtherTool();Check(CabinetWiringInput.ModePrefix(inventory),"unrelated tool intercepted");
  inventory.ActiveHand.Slot.Item=coil;cabinet.IsOpen=false;Check(CabinetWiringInput.ModePrefix(inventory),"closed cabinet intercepted");cabinet.IsOpen=true;cabinet.Wiring.Inside=false;Check(CabinetWiringInput.ModePrefix(inventory),"outside cabinet intercepted");cabinet.Wiring.Inside=true;
  var ghost=new Structure();InventoryManager.ConstructionCursor=ghost;InventoryManager.CurrentMode=InventoryManager.Mode.Placement;
  inventory.ActionCoroutine=new object();CabinetWiringInput.ModePrefix(inventory);Check(!ghost.gameObject.activeSelf&&!inventory.ConstructionPanel.IsVisible,"construction preview not suppressed");Check(inventory.ActionCoroutine==null&&inventory.Stops==1&&coil.EndCalls==1,"existing construction action not cancelled");
  CursorManager.CursorThing=new Thing();Check(CabinetWiringInput.ModePrefix(inventory)&&ghost.gameObject.activeSelf&&inventory.ConstructionPanel.IsVisible,"outside construction not restored");
  CursorManager.CursorThing=new DinBreaker{Host=cabinet};Check(!CabinetWiringInput.ModePrefix(inventory),"breaker target not handled");CursorManager.CursorThing=new DinRail{Board=new(){PrimaryHost=cabinet}};Check(!CabinetWiringInput.ModePrefix(inventory),"rail target not handled");
  coil.RootParentHuman=null;Check(CabinetWiringInput.ModePrefix(inventory),"unowned item handled");coil.RootParentHuman=new();GameManager.IsBatchMode=true;Check(CabinetWiringInput.ModePrefix(inventory),"server attempted local UI");
  Console.WriteLine($"Production input hook passed {checks} checks: coil only, cutters only, click versus hold, cancellation, authority dispatch, scoped native construction and non-target cases.");
 }
}
