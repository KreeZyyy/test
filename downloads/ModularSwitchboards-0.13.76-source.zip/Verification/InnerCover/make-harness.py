from pathlib import Path
p=Path(__file__).resolve().parents[2];q=p/'Verification/InnerCover'
s=(p/'Source/CabinetInnerCover.cs').read_text();a=s.index('        internal static Mesh Build');b=s.index('        private void OnDestroy',a);build=s[a:b]
s=(p/'Source/SwitchboardCabinet.cs').read_text();dto=s[s.index('    public sealed class SwitchboardCabinetSaveData'):s.index('    // Retains')];a=s.index('        public bool HasInnerCover');b=s.index('        public IEnumerable<PlacementBoard>',a);props=s[a:b];a=s.index('        protected override CanConstructInfo CanDeconstruct');b=s.index('        private float nextPortCheck',a);guards=s[a:b]
s=(p/'Source/SwitchboardsMod.cs').read_text();a=s.index('        private static void MigrateCabinetSave');b=s.index('        // Validate on the authority',a);migrate=s[a:b].replace('private static void MigrateCabinetSave','internal static void MigrateCabinetSave')
(q/'Extracted.cs').write_text('using System;using System.Linq;using System.Collections.Generic;using System.Xml.Serialization;using UnityEngine;namespace ModularSwitchboards{static class CabinetInnerCover{'+build+'}'+dto+'partial class SwitchboardCabinet{'+props+guards+'}static class Migration{public const string CabinetName="cabinet";'+migrate+'}}')

f=q/"Extracted.cs";s=f.read_text();src=(p/"Source/InnerCoverModule.cs").read_text();a=src.index("        internal static bool CanPlace");b=src.index("        public override void Awake",a);f.write_text(s[:-1]+"partial class InnerCoverModule{"+src[a:b]+"}}")
