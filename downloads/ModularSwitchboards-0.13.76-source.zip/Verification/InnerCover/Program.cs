using System;
using System.Linq;
using System.Collections.Generic;
using System.IO;
using System.Xml.Serialization;
using ModularSwitchboards;
using UnityEngine;
namespace UnityEngine{
 public struct Vector3{public float x,y,z;public Vector3(float a,float b,float c){x=a;y=b;z=c;}public static Vector3 operator -(Vector3 a,Vector3 b)=>new(a.x-b.x,a.y-b.y,a.z-b.z);public static Vector3 Cross(Vector3 a,Vector3 b)=>new(a.y*b.z-a.z*b.y,a.z*b.x-a.x*b.z,a.x*b.y-a.y*b.x);public static float Dot(Vector3 a,Vector3 b)=>a.x*b.x+a.y*b.y+a.z*b.z;public static Vector3 forward=>new(0,0,1);public static Vector3 back=>new(0,0,-1);public static Vector3 left=>new(-1,0,0);public static Vector3 right=>new(1,0,0);public static Vector3 up=>new(0,1,0);public static Vector3 down=>new(0,-1,0);}
 public class Mesh{public string name;public List<Vector3> V,N;public Dictionary<int,int[]> T=new();public int subMeshCount;public void SetVertices(List<Vector3> v){V=v;}public void SetNormals(List<Vector3> n){N=n;}public void SetTriangles(int[] t,int s,bool other=false){T[s]=t;}public void RecalculateBounds(){}}
 public static class Debug{public static void Log(string s){}}
}
namespace ModularSwitchboards{
 static class SwitchboardCoverMount{internal static bool TryAttack(SwitchboardCabinet host,Attack attack,bool action,out DelayedActionInstance result){result=null;return false;}}
 static class CabinetGeometry{internal static void ApplyNativeUv(Mesh m){}}
 public class ThingSaveData{}public class StructureSaveData:ThingSaveData{public int CurrentBuildState;}
 public class PlacementBoardHostSaveData{public long BoardId;}
 class CanConstructInfo{public bool CanConstruct;public static CanConstructInfo ValidPlacement=>new(){CanConstruct=true};public static CanConstructInfo InvalidPlacement(string why)=>new();}
 class DynamicThing{public string PrefabName;}
 struct Attack{public DynamicThing SourceItem;}
 class DelayedActionInstance{public float Duration;public bool Failed;public DelayedActionInstance Fail(string message){Failed=true;return this;}}
 class Structure{public string PrefabName;protected virtual CanConstructInfo CanDeconstruct()=>CanConstructInfo.ValidPlacement;public virtual DelayedActionInstance AttackWith(Attack a,bool action=true)=>new();}
 class FakeWiring{public bool HasAnyWires;public bool TryAttack(Attack a,bool d,out DelayedActionInstance result){result=null;return false;}}
 class FakeBoard{public List<object> Structures=new();}
 class PlacementBoard:FakeBoard{public object PrimaryHost;}
 class CabinetCoverBoard:PlacementBoard{}
 struct Grid3{public int x,y,z;public Grid3(int a,int b,int c){x=a;y=b;z=c;}}
 partial class InnerCoverModule{public bool IsBeingDestroyed;}
 partial class SwitchboardCabinet:Structure{public int CurrentBuildStateIndex;public bool IsOpen=true;public FakeWiring Wiring=new();public FakeBoard RailBoard=new();public FakeBoard CoverBoard=new();public FakeBoard DoorBoard=new();public FakeBoard BridgeBoard=new();public bool RemoveAllowed()=>CanDeconstruct().CanConstruct;}
}
class Program{
 static int checks;static void Check(bool ok,string m){checks++;if(!ok)throw new Exception(m);}
 static string Key(Vector3 p)=>$"{MathF.Round(p.x,6)},{MathF.Round(p.y,6)},{MathF.Round(p.z,6)}";
 static void Verify(WireRect[] holes,InnerCoverLayout.Panel? dimensions=null){
 var profile=dimensions??InnerCoverLayout.Small;
 var mesh=CabinetInnerCover.Build(holes,profile);
 Check(mesh.V.All(v=>Math.Abs(Math.Abs(v.z-profile.Depth)-profile.Sheet/2)<1e-6),"Mesh ignores cabinet depth/thickness");
 Check(Math.Abs(mesh.V.Max(v=>v.x)-profile.Width/2)<1e-6&&Math.Abs(mesh.V.Min(v=>v.y)+profile.Height/2)<1e-6,"Mesh ignores cabinet dimensions");var triangles=mesh.T[0];var edges=new Dictionary<string,int>();
 for(int i=0;i<triangles.Length;i+=3){int ai=triangles[i],bi=triangles[i+1],ci=triangles[i+2];var a=mesh.V[ai];var b=mesh.V[bi];var c=mesh.V[ci];var cross=Vector3.Cross(b-a,c-a);Check(Vector3.Dot(cross,mesh.N[ai])>0,"Invalid normal or zero-area cover triangle");foreach(var pair in new[]{(a,b),(b,c),(c,a)}){string x=Key(pair.Item1),y=Key(pair.Item2),key=string.CompareOrdinal(x,y)<0?x+"/"+y:y+"/"+x;edges[key]=edges.GetValueOrDefault(key)+1;}}
 Check(edges.Values.All(v=>v==2),"Cover mesh is not closed/watertight");
 var cells=InnerCoverLayout.Cells(holes,profile);
 var rng=new Random(128);for(int i=0;i<5000;i++){
 float x=(float)(rng.NextDouble()*2-1)*profile.Width/2,y=(float)(rng.NextDouble()*2-1)*profile.Height/2;
 if(holes.Any(h=>Math.Abs(x-h.Left)<2e-6||Math.Abs(x-h.Right)<2e-6||Math.Abs(y-h.Top)<2e-6||Math.Abs(y-h.Bottom)<2e-6))continue;
 bool expected=!holes.Any(h=>x>h.Left&&x<h.Right&&y>h.Bottom&&y<h.Top);
 int hits=cells.Count(c=>x>c.Left&&x<c.Right&&y>c.Bottom&&y<c.Top);Check(hits==(expected?1:0),"A cover opening is filled or a solid area is missing/overlapping");
 }
 foreach(var h in holes){float x=(h.Left+h.Right)/2,y=(h.Bottom+h.Top)/2;if(Math.Abs(x)<profile.Width/2&&Math.Abs(y)<profile.Height/2)Check(!cells.Any(c=>x>c.Left&&x<c.Right&&y>c.Bottom&&y<c.Top),"Module center covered");}
 }
 static void Main(){
 if(Environment.GetEnvironmentVariable("CATALOG_COVER_EXPORT") is string exportPath){var mesh=CabinetInnerCover.Build(Array.Empty<WireRect>());File.WriteAllText(exportPath,System.Text.Json.JsonSerializer.Serialize(new{vertices=mesh.V.Select(v=>new[]{v.x,v.y,v.z}),triangles=mesh.T}));}

 Verify(Array.Empty<WireRect>());
 var full=Enumerable.Range(0,2).SelectMany(row=>Enumerable.Range(0,8).Select(col=>InnerCoverLayout.Window(-.14175f+col*.0405f,row==0?.108f:-.108f,1,false))).ToArray();Verify(full);Verify(full.Concat(new[]{DoorModuleLayout.HarnessWindow}).ToArray());
 var mixed=new[]{InnerCoverLayout.Window(-.14175f,.108f,1,false),InnerCoverLayout.Window(-.10125f,.108f,2,true),InnerCoverLayout.Window(.02025f,.108f,3,false),InnerCoverLayout.Window(-.10125f,-.108f,3,false),InnerCoverLayout.Window(.02025f,-.108f,2,true)};Verify(mixed);
 Verify(new[]{new WireRect(-.2f,-.1f,-.3f,.04f),new WireRect(-.15f,.03f,-.03f,.08f)});
 Verify(full.Select((w,i)=>new WireRect(w.Left,w.Right,w.Bottom+(i%3)*1e-8f,w.Top+(i%3)*1e-8f)).ToArray());
 Check(InnerCoverLayout.Plane-InnerCoverLayout.Thickness/2>.014f+.018f+(.0577f+.0015f/2)*1.15f,"Cover exposes terminal screw heads");
 Check(InnerCoverLayout.Plane+InnerCoverLayout.Thickness/2<.014f+.018f+(.0635f-.001f/2)*1.15f,"Cover stands proud of module face");
 foreach(int slots in new[]{1,2,3}){var w=InnerCoverLayout.Window(0,0,slots,slots==2);float blackFace=(.0176f+(slots-1)*.0405f/2.25f-.0046f)*2.25f;Check(w.Right-w.Left>blackFace,"Window clips module face");Check(w.Right-w.Left>.0396f+(slots-1)*.0405f,"Window crops coloured module shoulder");Check(w.Right-w.Left<slots*.0405f,"Window removes panel between slots");Check(w.Top>.052f*1.35f/2&&w.Top<.039f,"Window crops coloured front or exposes full terminal");}
 // Future cabinet profiles: 12 columns / 3 rows, and one narrow row.
 var larger=new InnerCoverLayout.Panel(.52f,.70f,.11f,.003f);
 Verify(Enumerable.Range(0,3).SelectMany(row=>Enumerable.Range(0,12).Select(col=>InnerCoverLayout.Window(-.22275f+col*.0405f,(row-1)*.18f,1,false))).ToArray(),larger);
 Verify(new[]{InnerCoverLayout.Window(-.06075f,0,2,true),InnerCoverLayout.Window(.0405f,0,3,false)},new InnerCoverLayout.Panel(.25f,.16f,.102f,.0015f));
 Check(larger.Signature!=InnerCoverLayout.Small.Signature,"Changing cabinet profile won't invalidate mesh cache");
 var withDoors=new SwitchboardCabinet{PrefabName="cabinet",CurrentBuildStateIndex=1};withDoors.DoorBoard.Structures.Add(1);Check(!withDoors.RemoveAllowed(),"Door module lost on cabinet dismantle");withDoors.DoorBoard.Structures.Clear();withDoors.BridgeBoard.Structures.Add(1);Check(!withDoors.RemoveAllowed(),"Bridge lost on cabinet dismantle");
 var cabinet=new SwitchboardCabinet{PrefabName="cabinet",IsOpen=true};cabinet.Wiring.HasAnyWires=true;cabinet.RailBoard.Structures.Add(1);
 cabinet.CurrentBuildStateIndex=1;Check(cabinet.CanAccessModules&&cabinet.CanFitRails&&!cabinet.HasInnerCover&&!cabinet.RemoveAllowed(),"Uncovered state gates wrong");Check(cabinet.AttackWith(new(){SourceItem=new(){PrefabName="ItemWrench"}})==null,"Cabinet still accepts wrench cover construction");
 cabinet.CurrentBuildStateIndex=2;Check(cabinet.HasInnerCover&&cabinet.CanAccessModules&&!cabinet.CanFitRails&&cabinet.RemoveAllowed(),"Covered state must keep module controls but block fitting; wrench removal must allow wired modules");Check(cabinet.AttackWith(new(){SourceItem=new(){PrefabName="ItemWrench"}})!=null,"Cover removal is blocked by installed modules");
 cabinet.IsOpen=false;Check(!cabinet.CanAccessModules&&!cabinet.CanFitRails&&!cabinet.RemoveAllowed()&&cabinet.AttackWith(new(){SourceItem=new(){PrefabName="ItemWrench"}}).Failed,"Closed cabinet allowed cover work");cabinet.IsOpen=true;cabinet.CurrentBuildStateIndex=0;Check(!cabinet.CanAccessModules&&!cabinet.CanFitRails,"Bare frame allows module access");
 var legacy=new SwitchboardCabinetSaveData{CurrentBuildState=2};Migration.MigrateCabinetSave(cabinet,legacy);Check(legacy.CurrentBuildState==1,"Old stage2 silently gained a cover");
 cabinet.CurrentBuildStateIndex=1;
 var coverBoard=new CabinetCoverBoard{PrimaryHost=cabinet};
 Check(InnerCoverModule.CanPlace(coverBoard,new Grid3(0,0,0),0),"Cover placement rejected on open completed empty cover board");
 foreach(var g in new[]{new Grid3(1,0,0),new Grid3(0,60,0),new Grid3(0,0,1)})Check(!InnerCoverModule.CanPlace(coverBoard,g,0),"Forged cover position accepted");
 Check(!InnerCoverModule.CanPlace(coverBoard,new Grid3(0,0,0),1),"Rotated cover accepted");
 Check(!InnerCoverModule.CanPlace(new PlacementBoard{PrimaryHost=cabinet},new Grid3(0,0,0),0),"Cover accepted on rail board");
 coverBoard.Structures.Add(new InnerCoverModule());Check(!InnerCoverModule.CanPlace(coverBoard,new Grid3(0,0,0),0),"Duplicate cover accepted");coverBoard.Structures.Clear();
 cabinet.IsOpen=false;Check(!InnerCoverModule.CanPlace(coverBoard,new Grid3(0,0,0),0),"Closed cabinet accepts cover");cabinet.IsOpen=true;
 cabinet.CoverBoard.Structures.Add(new InnerCoverModule());Check(cabinet.HasInnerCover&&!cabinet.CanFitRails&&cabinet.CanAccessModules&&!cabinet.RemoveAllowed(),"Kit cover bypassed module/editing/demolition gates");
 foreach(string tool in new[]{"ItemWrench","ItemDrill"})Check(cabinet.AttackWith(new(){SourceItem=new(){PrefabName=tool}})==null,"Shell dismantled through kit cover");
 cabinet.CoverBoard.Structures.Clear();Check(!cabinet.HasInnerCover&&cabinet.CanFitRails,"Cover removal did not restore editing");
 cabinet.CurrentBuildStateIndex=2;Check(!InnerCoverModule.CanPlace(coverBoard,new Grid3(0,0,0),0),"Legacy cover allows duplicate kit cover");
 var covered=new SwitchboardCabinetSaveData{CurrentBuildState=2,CoverSchema=1,CoverBoard=new(){BoardId=951},Wires=new[]{new CabinetWireSaveData{ColorIndex=7}}};var xml=new XmlSerializer(typeof(SwitchboardCabinetSaveData));var writer=new StringWriter();xml.Serialize(writer,covered);var restored=(SwitchboardCabinetSaveData)xml.Deserialize(new StringReader(writer.ToString()));Migration.MigrateCabinetSave(cabinet,restored);Check(restored.CurrentBuildState==2&&restored.CoverSchema==1&&restored.Wires[0].ColorIndex==7&&restored.CoverBoard.BoardId==951,"Covered save lost state or wire color");
 Console.WriteLine($"Cover production geometry/state/save checks passed: {checks} checks; empty/full/mixed/clipped/overlapping/noisy layouts watertight, module windows clear, recessed face and terminal clearance, editing/operation gates, kit placement/authority guards, separate cover board, old/new save migration.");
 }
}
