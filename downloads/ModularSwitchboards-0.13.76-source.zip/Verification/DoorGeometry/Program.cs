using System;using System.Collections.Generic;using System.Linq;using UnityEngine;using ModularSwitchboards;
namespace UnityEngine{
 public struct Vector3{public float x,y,z;public Vector3(float x,float y,float z){this.x=x;this.y=y;this.z=z;}}
 public static class Mathf{public const float PI=(float)Math.PI;public static float Cos(float x)=>(float)Math.Cos(x);public static float Sin(float x)=>(float)Math.Sin(x);}
 public class Mesh{public string name;public Vector3[] vertices,normals;public int[] triangles;public void SetVertices(List<Vector3> v)=>vertices=v.ToArray();public void SetNormals(List<Vector3> n)=>normals=n.ToArray();public void SetTriangles(List<int> t,int slot)=>triangles=t.ToArray();public void RecalculateBounds(){}}
}
class Program{
 static int count;static void Check(bool b,string s){count++;if(!b)throw new Exception(s);}
 static Vector3 Sub(Vector3 a,Vector3 b)=>new(a.x-b.x,a.y-b.y,a.z-b.z);
 static Vector3 Cross(Vector3 a,Vector3 b)=>new(a.y*b.z-a.z*b.y,a.z*b.x-a.x*b.z,a.x*b.y-a.y*b.x);
 static float Dot(Vector3 a,Vector3 b)=>a.x*b.x+a.y*b.y+a.z*b.z;
 static void Main(){
 foreach(var spec in new[]{(.021f,.016f,.030f),(.026f,-.002f,.003f),(.012f,.0038f,.009f),(.016f,-.002f,.004f),(.009f,.005f,.019f)}){
  var m=DoorModuleGeometry.Cylinder(spec.Item1,spec.Item2,spec.Item3);Check(m.vertices.Length==m.normals.Length&&m.vertices.Length==320,"Normals/vertices incomplete");Check(m.triangles.Length==384,"Topology changed");
  foreach(var n in m.normals)Check(Math.Abs(Dot(n,n)-1)<1e-5,"Non-unit normal");
  foreach(var v in m.vertices)Check(v.z>=spec.Item2&&v.z<=spec.Item3&&v.x*v.x+v.y*v.y<=spec.Item1*spec.Item1+1e-8,"Cylinder dimensions changed");
  for(int i=0;i<32;i++){
   int p=i*10;
   for(int j=0;j<4;j++){var n=m.normals[p+j];var v=m.vertices[p+j];Check(n.z==0&&Math.Abs(n.x-v.x/spec.Item1)<1e-5&&Math.Abs(n.y-v.y/spec.Item1)<1e-5,"Side not smoothly radial");}
   for(int j=4;j<10;j++){var n=m.normals[p+j];Check(n.x==0&&n.y==0&&n.z==(j<7?-1:1),"Cap normal leaks side shading");}
   var next=m.normals[((i+1)%32)*10];Check(Math.Abs(next.x-m.normals[p+1].x)+Math.Abs(next.y-m.normals[p+1].y)<1e-5,"Side seam has discontinuous normals");
  }
  for(int i=0;i<m.triangles.Length;i+=3){var a=m.triangles[i];var b=m.triangles[i+1];var c=m.triangles[i+2];var cross=Cross(Sub(m.vertices[b],m.vertices[a]),Sub(m.vertices[c],m.vertices[a]));Check(Dot(cross,m.normals[a])>0,"Winding or degenerate face");}
  // Uniform cap normals give equal diffuse response for every fan triangle,
  // under head-on as well as oblique illumination (the reported radial stripes).
  foreach(var light in new[]{new Vector3(0,0,1),new Vector3(.5f,.2f,.8f),new Vector3(-.7f,.3f,.4f)})
   foreach(int i in Enumerable.Range(0,32))for(int j=7;j<10;j++)Check(Dot(m.normals[i*10+j],light)==light.z,"Front cap develops radial lighting stripes");
 }
 var guard=DoorModuleGeometry.StopGuard();
 Check(guard.vertices.Length==guard.normals.Length,"Guard missing normals");
 Check(DoorModuleGeometry.GuardFront>.030f,"Hood does not stand above released mushroom");
 Check(DoorModuleGeometry.GuardOuter*2<.1f,"Guard overlaps adjacent grid position");
 var edges=new Dictionary<string,int>();
 string PointKey(Vector3 v)=>$"{Math.Round(v.x,6)},{Math.Round(v.y,6)},{Math.Round(v.z,6)}";
 foreach(var n in guard.normals)Check(Math.Abs(Dot(n,n)-1)<1e-5,"Guard non-unit normal");
 foreach(var v in guard.vertices){float r=(float)Math.Sqrt(v.x*v.x+v.y*v.y);Check(r>=DoorModuleGeometry.GuardInner-1e-6&&r<=DoorModuleGeometry.GuardOuter+1e-6,"Guard blocks button aperture");Check(v.y>=-DoorModuleGeometry.GuardOuter*.5001f,"Bottom access opening filled");Check(v.z>=DoorModuleGeometry.GuardBack&&v.z<=DoorModuleGeometry.GuardFront,"Hood outside planned depth");}
 for(int i=0;i<guard.triangles.Length;i+=3){
  var ids=new[]{guard.triangles[i],guard.triangles[i+1],guard.triangles[i+2]};var a=guard.vertices[ids[0]];var b=guard.vertices[ids[1]];var c=guard.vertices[ids[2]];
  var normal=Cross(Sub(b,a),Sub(c,a));Check(Dot(normal,guard.normals[ids[0]])>0,"Guard back-facing or degenerate triangle");
  for(int j=0;j<3;j++){string x=PointKey(guard.vertices[ids[j]]),y=PointKey(guard.vertices[ids[(j+1)%3]]);string key=string.CompareOrdinal(x,y)<0?x+"|"+y:y+"|"+x;edges.TryGetValue(key,out int before);edges[key]=before+1;}
 }
 Check(edges.Values.All(n=>n==2),"Guard is not a closed solid mesh");
 Check(DoorModuleGeometry.GuardInner*Math.Cos(Math.PI/48)>.021,"Guard hits red mushroom at either latch depth");
 var destination=Environment.GetCommandLineArgs().Skip(1).FirstOrDefault();if(destination!=null)System.IO.File.WriteAllText(destination,System.Text.Json.JsonSerializer.Serialize(new{vertices=guard.vertices.Select(v=>new[]{v.x,v.y,v.z}),normals=guard.normals.Select(v=>new[]{v.x,v.y,v.z}),triangles=guard.triangles}));
 Console.WriteLine($"Door cylinder geometry: {count} production checks passed; flat caps, smooth radial sides, correct winding/dimensions and uniform oblique lighting; raised guard is a closed solid with a clear aperture/bottom opening.");
 }
}
