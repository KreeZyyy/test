import json,collections
from pathlib import Path
tri=json.loads(Path(__file__).with_name("native-lug-fixture.json").read_text())["triangles"]
v=[p for t in tri for p in t]
# Match the production completion anchors to the original native vertices.
def find(x,y,z):return min(v,key=lambda p:sum((a-b)**2 for a,b in zip(p,(x,y,z))))
a=find(.119995,-.035019,.043765);b=find(.119995,-.035019,-.020783);c=find(.120010,-.029243,-.030782);d=find(.120010,.029243,-.030782);e=find(.119995,.035019,-.020783);f=find(.119995,.035019,.043765)
g=find(.191156,.035019,.043760);h=find(.2,.028964,.050479);j=find(.2,-.028964,.050479);k=find(.191156,-.035019,.043760)
root=[a,b,c,d,e,f];center=[sum(p[i]for p in root)/6 for i in range(3)]
patch=[[center,root[(i+1)%6],root[i]]for i in range(6)]+[[a,k,g],[a,g,f],[k,j,h],[k,h,g]]
assert len(tri)==124
# The shared mouth stays uncapped: completion is at the root and front only.
assert all(max(p[0]for p in t)<=.200001 for t in patch)
for decimals in [5,6]:
 edges=collections.Counter()
 for t in tri+patch:
  keys=[tuple(round(x,decimals)for x in p)for p in t]
  for u,w in zip(keys,keys[1:]+keys[:1]):edges[tuple(sorted((u,w)))]+=1
 boundary=[e for e,n in edges.items()if n!=2]
 assert not boundary,(decimals,len(boundary))
for t in patch:
 a,b,c=t;u=[b[k]-a[k]for k in range(3)];w=[c[k]-a[k]for k in range(3)];n=[u[1]*w[2]-u[2]*w[1],u[2]*w[0]-u[0]*w[2],u[0]*w[1]-u[1]*w[0]]
 assert sum(x*x for x in n)>1e-20
print('APC completion passed: 124 untouched native triangles + 10 new gray wall triangles; no open/nonmanifold edges at 1 and 10 micron weld precision; mouth untouched.')
orientation=collections.Counter()
for t in tri+patch:
 keys=[tuple(round(x,6)for x in p)for p in t]
 for u,w in zip(keys,keys[1:]+keys[:1]):
  edge=tuple(sorted((u,w)));orientation[edge]+=1 if u<w else -1
assert all(n==0 for n in orientation.values()),'Inconsistent boundary winding'
print('Completion winding also matches the existing native surfaces.')
