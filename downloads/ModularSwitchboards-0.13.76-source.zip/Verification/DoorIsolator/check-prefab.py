from pathlib import Path
import re
root=Path(__file__).resolve().parents[2]
setup=(root/'Source/DoorModules.cs').read_text().split('internal static void Install(DinBreaker part,Transform storage)',1)[1].split('public sealed class',1)[0]
assert not re.search(r'\bpart\.OnOff\b',setup), 'Prefab installer accesses uninitialized native OnOff'
registration=(root/'Source/SwitchboardsMod.cs').read_text()
assert not re.search(r'\bdoorIsolator\.OnOff\b',registration), 'Registration accesses native state before initialization'
assert 'DoorIsolatorView.SetInitialPose(handle.transform)' in setup
print('Prefab regression: production installer and registration never access native OnOff during setup.')
