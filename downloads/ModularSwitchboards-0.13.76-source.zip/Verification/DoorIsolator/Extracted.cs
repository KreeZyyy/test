using Assets.Scripts.Objects; namespace ModularSwitchboards { public partial class DinBreaker {         public bool Conducting=>!IsBeingDestroyed&&(IsDoorStop?!OnOff:(IsDoorBridge||IsDoorLed||IsBatteryModule||IsAnalyserModule|| (IsFuseHolder?!Tripped&&Slots.Count==1&&Slots[0].Get() is MultiConstructor kit&&kit.Quantity==1&&System.Array.IndexOf(AllowedFuseKits,kit.PrefabHash)>=0:OnOff)));
        internal void Trip()
        {
            if(!GameManager.RunSimulation||IsDoorBridge||IsDoorLed||IsDoorStop||IsDoorIsolator||IsBatteryModule||IsAnalyserModule||!Conducting)return;
            if(IsFuseHolder){var kit=Slots[0].Get() as MultiConstructor;if(kit!=null)kit.RemoveQuantity(1);}
            else {OnOff=false;}
            Tripped=true;NetworkUpdateFlags|=ModuleUpdate;
            if(IsFuseHolder){fuseBurnSequence=unchecked(fuseBurnSequence+1);DinFuseAudio.Play(this);}
        }
 } }