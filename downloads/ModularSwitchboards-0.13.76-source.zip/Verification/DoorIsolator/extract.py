from pathlib import Path
root=Path(__file__).resolve().parents[2]
s=(root/'Source/DinBreaker.cs').read_text()
a=s.index('        public bool Conducting=>');b=s.index('        public PlacementBoard Board',a)
(Path(__file__).parent/'Extracted.cs').write_text('using Assets.Scripts.Objects; namespace ModularSwitchboards { public partial class DinBreaker { '+s[a:b]+' } }')
