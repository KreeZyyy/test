using System;
using System.Linq;
using ModularSwitchboards;
using UnityEngine;
class InteractableAnimComponent {protected float time=1;public void SetTime(float value)=>time=value;}
class ApcOnOffAnimComponent:InteractableAnimComponent{}
static class Defines {public static class Sounds {public const int ApcOn=11,ApcOff=12;}}
namespace UnityEngine {
 public class MonoBehaviour{}
 public class Transform {public Vector3 localPosition;public Quaternion localRotation;}
 public struct Vector3 {public float x,y,z;public Vector3(float a,float b,float c){x=a;y=b;z=c;}public static Vector3 zero=>new(0,0,0);}
 public struct Quaternion {public float x;public static Quaternion Euler(float x,float y,float z)=>new(){x=x};}
 public static class Time {public static float deltaTime;}
 public static class Mathf {public static float Max(float a,float b)=>Math.Max(a,b);public static float MoveTowards(float a,float b,float step)=>Math.Abs(b-a)<=step?b:a+Math.Sign(b-a)*step;}
 public static class Debug {public static void Log(string s){}public static void LogWarning(string s){}}
}
namespace Assets.Scripts.GridSystem {enum GameState{Running,Loading}}
namespace Assets.Scripts {static class GameManager {public static bool IsBatchMode;public static GridSystem.GameState GameState=GridSystem.GameState.Running;}}
namespace Assets.Scripts.Sound {class AudioManager{}}
namespace Assets.Scripts.Util {static class Singleton<T> where T:new(){public static T Instance=new();}}
namespace Assets.Scripts.Objects.Motherboards {enum ColorType{Green,Red}}
namespace Assets.Scripts.Objects.Electrical {class AreaPowerControl {public string PrefabName="StructureAreaPowerControl";public ApcOnOffAnimComponent Animation=new();public T[] GetComponentsInChildren<T>(bool all)=>new[]{(T)(object)Animation};}}
namespace ModularSwitchboards {
 class WorldManager {public static WorldManager Instance=new();public object[] SourcePrefabs=Array.Empty<object>();}
 public class DinBreaker {public bool OnOff,IsFuseHolder,IsBatteryModule,IsAnalyserModule;public int Calls,LastHash;public void PlayPooledAudioSound(int hash,Vector3 pos){Calls++;LastHash=hash;}}
 static class DinBreakerModel {public static void Refresh(DinBreaker b){}}
}
class Program {
 static int checks;
 static void Check(bool condition,string reason){checks++;if(!condition)throw new Exception(reason);}
 static BreakerSwitchView View(DinBreaker owner)=>new(){Owner=owner,Lever=new()};
 static void Main(){
 var apc=new Assets.Scripts.Objects.Electrical.AreaPowerControl();apc.Animation.SetTime(.8f);WorldManager.Instance.SourcePrefabs=new object[]{apc};
 Check(BreakerSwitchAudio.Duration()==.8f,"reads native serialized duration rather than base default");
 var b=new DinBreaker();var v=View(b);v.Tick(false,0);Check(b.Calls==0,"initial load silent");
 v.Tick(true,.2f);Check(b.Calls==1&&b.LastHash==Defines.Sounds.ApcOn,"on sound at animation start");Check(v.Lever.localRotation.x==135,"native linear quarter progress");
 v.Tick(true,.2f);Check(b.Calls==1&&v.Lever.localRotation.x==90,"no per-frame replay");
 v.Tick(false,.2f);Check(b.Calls==2&&b.LastHash==Defines.Sounds.ApcOff,"off on reversal");Check(v.Lever.localRotation.x==135,"reversal preserves native speed");
 v.Tick(false,.2f);Check(v.Lever.localRotation.x==180,"returns to off");v.Tick(true,.8f);Check(v.Lever.localRotation.x==0,"full travel exact native duration");
 int count=b.Calls;v.Apply(false);Check(b.Calls==count,"explicit restore silent");
 var joined=new DinBreaker{OnOff=true};View(joined).Tick(true,.1f);Check(joined.Calls==0,"join on silent");
 Assets.Scripts.GameManager.IsBatchMode=true;v.Tick(false,0);v.Tick(true,0);Check(b.Calls==count,"dedicated silent");Assets.Scripts.GameManager.IsBatchMode=false;
 Assets.Scripts.GameManager.GameState=Assets.Scripts.GridSystem.GameState.Loading;v.Tick(false,0);Check(b.Calls==count,"loading silent");Assets.Scripts.GameManager.GameState=Assets.Scripts.GridSystem.GameState.Running;
 Assets.Scripts.Util.Singleton<Assets.Scripts.Sound.AudioManager>.Instance=null;v.Tick(true,0);Check(b.Calls==count,"missing audio manager safe");Assets.Scripts.Util.Singleton<Assets.Scripts.Sound.AudioManager>.Instance=new();
 foreach(var type in new[]{0,1,2}){var other=new DinBreaker{IsFuseHolder=type==0,IsBatteryModule=type==1,IsAnalyserModule=type==2};BreakerSwitchAudio.Play(other,true);Check(other.Calls==0,"non-breaker silent");}
 var durationField=typeof(BreakerSwitchAudio).GetField("nativeDuration",System.Reflection.BindingFlags.Static|System.Reflection.BindingFlags.NonPublic);
 durationField.SetValue(null,null);apc.Animation.SetTime(0);var instant=new DinBreaker();var instantView=View(instant);instantView.Tick(false,0);instantView.Tick(true,0);Check(instant.Calls==0&&instantView.Lever.localRotation.x==0,"native zero duration skips animation and sound");
 durationField.SetValue(null,null);WorldManager.Instance.SourcePrefabs=Array.Empty<object>();Check(BreakerSwitchAudio.Duration()==.22f,"missing prefab fallback");apc.Animation.SetTime(.6f);WorldManager.Instance.SourcePrefabs=new object[]{apc};Check(BreakerSwitchAudio.Duration()==.6f,"retry after early unavailable prefab");
 Console.WriteLine(checks+" native breaker timing/audio checks passed.");
 }
}
