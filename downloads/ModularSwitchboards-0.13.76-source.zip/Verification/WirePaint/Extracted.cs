using UnityEngine;namespace ModularSwitchboards{public sealed partial class CabinetWiring{        private int WireAt(Vector3 world,float radius=.012f)
        {
            float best=radius*radius;int found=-1;
            for(int i=0;i<wires.Count;i++){var frame=IsDoorWire(wires[i])?DoorFrame:Shell;if(frame==null)continue;var p=Point(frame.InverseTransformPoint(world));var path=Expand(wires[i].Points);for(int j=1;j<path.Length;j++){float distance=WireRouting.SegmentDistanceSquared(p,p,path[j-1],path[j]);if(distance<best){best=distance;found=i;}}}return found;
        }
        internal bool ContainsInteractionPoint(Vector3 world)
        {
            if(Shell==null)return false;var p=Shell.InverseTransformPoint(world);
            if(Mathf.Abs(p.x)<.19f&&Mathf.Abs(p.y)<.24f&&p.z>=0&&p.z<.16f)return true;
            if(DoorFrame==null)return false;var q=DoorFrame.InverseTransformPoint(world);return Mathf.Abs(q.x)<.19f&&Mathf.Abs(q.y)<.23f&&q.z>=-.003f&&q.z<.09f;
        }
}}