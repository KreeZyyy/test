from pathlib import Path
import json,struct,math,collections
root=Path(__file__).resolve().parents[2];checks=0
def check(ok,message):
 global checks
 checks+=1
 assert ok,message
source=json.loads((root/'Art/LabelKit/source.json').read_text());rail=json.loads((root/'Art/RailKit/source.json').read_text());check(source['shell']==rail['shell'],'Original crate shell changed')
counts=collections.Counter(p['metadata'].get('labelVariant','DIN')for p in source['layout']);check(counts=={'DIN':36,'DoorLabel':8,'EmergencyStopLabel':8},'Crate does not include every label family')
audit=source['supportAudit'];check(audit['grounded_count']==52 and not audit['ungrounded'],'Floating contents')
b=(root/'Assets/LabelKit/Model.meshbin').read_bytes();check(b[:4]==b'MKIT','Wrong asset signature');nv,ni=struct.unpack_from('<ii',b,4);check(len(b)==12+nv*32+ni*4 and ni%3==0,'Truncated mesh')
for i in range(nv):
 p=struct.unpack_from('<8f',b,12+i*32);check(all(math.isfinite(v)for v in p),'Nonfinite vertex');check(abs(sum(v*v for v in p[3:6])-1)<.001,'Invalid normal')
for idx in struct.unpack_from('<'+'i'*ni,b,12+nv*32):check(0<=idx<nv,'Invalid index')
check(source['contents']['triangles'].get('11')is not None,'Yellow rings absent from atlas roles')
print(f'Label crate: {checks} checks passed; {nv} vertices, {ni//3} triangles; DIN36/Door8/Emergency8, original shell, grounded pile.')
