using System.Xml.Serialization;using Assets.Scripts.Objects;using LibConstruct;namespace ModularSwitchboards{    public sealed class DoorLabelSaveData:StructureSaveData
    {
        [XmlElement] public PlacementBoardStructureSaveData Mount;
    }
}