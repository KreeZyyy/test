using System;
using System.Collections.Generic;
using System.Linq;
using ModularSwitchboards;
using Assets.Scripts.Networks;
static class AnalyserHarness
{
 static void Check(bool v,string m){if(!v)throw new Exception(m);}
 static CabinetWireSaveData W(long a,int ap,long b,int bp)=>new(){From=new(a,ap),To=new(b,bp)};
 internal static void Run()
 {
  int selectionChecks=0;
  void Select(List<CabinetWireSaveData> graph,long[] closed,long[] protect,int expected,string reason){selectionChecks++;Check(AnalyserCircuit.Selection(10,graph,closed,protect)==expected,reason);}
  var direct=new List<CabinetWireSaveData>{W(0,0,10,0),W(10,1,0,1)};
  Select(direct,new long[]{10},Array.Empty<long>(),1,"direct path defaults Output1");
  direct[1]=W(10,1,0,2);Select(direct,new long[]{10},Array.Empty<long>(),2,"direct path defaults Output2");
  var before=new List<CabinetWireSaveData>{W(0,0,10,0),W(10,1,30,0),W(30,1,0,1)};
  Select(before,new long[]{10,30},new long[]{30},AnalyserCircuit.Input,"IN analyzer breaker OUT reads Input");
  Select(before,new long[]{10},new long[]{30},AnalyserCircuit.Input,"open downstream breaker does not change Input side");
  var after=new List<CabinetWireSaveData>{W(0,0,30,0),W(30,1,10,0),W(10,1,0,2)};
  Select(after,new long[]{10,30},new long[]{30},2,"IN breaker analyzer OUT reads Output2");
  Select(after,new long[]{10},new long[]{30},2,"open upstream breaker still reads downstream network");
  var series=new List<CabinetWireSaveData>{W(0,0,20,0),W(20,1,10,0),W(10,1,30,0),W(30,1,0,1)};
  Select(series,new long[]{10,20,30},new long[]{30},AnalyserCircuit.Input,"other sensors do not count as protection");
  var between=new List<CabinetWireSaveData>{W(0,0,20,0),W(20,1,10,0),W(10,1,30,0),W(30,1,0,1)};
  Select(between,new long[]{10,20,30},new long[]{20,30},1,"between protections selects output side");
  Select(between,new long[]{10,20},new long[]{20,30},0,"disconnected output path must not fall back to Input");
  Select(new(){W(0,0,10,0)},new long[]{10},Array.Empty<long>(),AnalyserCircuit.Input,"unprotected IN-only measurement tap");
  Select(new(){W(0,0,30,0),W(30,1,10,0)},new long[]{10,30},new long[]{30},0,"tap behind protection needs an output connection");
  Select(new(),new long[]{10},Array.Empty<long>(),0,"unwired does not invent network");
  Select(new(){W(10,1,0,1)},new long[]{10},Array.Empty<long>(),1,"OUT-only native network sensor remains supported");
  Select(new(){W(0,0,10,0),W(10,1,0,1),W(10,1,0,2)},new long[]{10},Array.Empty<long>(),3,"ambiguous outputs preserved for network identity guard");
  Console.WriteLine(selectionChecks+" automatic analyzer topology selection checks passed.");
  var first=new DinBreaker{ReferenceId=10,IsAnalyserModule=true,RatedWatts=0};
  var second=new DinBreaker{ReferenceId=20,IsAnalyserModule=true,RatedWatts=0};
  var wires=new List<CabinetWireSaveData>{W(0,0,10,0),W(10,1,0,1),W(0,0,20,0),W(20,1,0,2)};
  Check(first.Conducting&&second.Conducting,"Analyser must conduct regardless of OnOff");
  Check(AnalyserCircuit.Output(10,wires,new long[]{10,20})==1&&AnalyserCircuit.Output(20,wires,new long[]{10,20})==2,"Two analysers selected wrong outputs");
  wires.RemoveAt(1);wires.Add(W(10,1,30,0));wires.Add(W(30,1,0,1));
  Check(AnalyserCircuit.Output(10,wires,new long[]{10,20,30})==1,"Downstream closed breaker not followed");
  Check(AnalyserCircuit.Output(10,wires,new long[]{10,20})==0,"Open downstream breaker passed sensor path");
  wires.Clear();wires.Add(W(10,1,20,0));wires.Add(W(20,1,0,2));
  Check(AnalyserCircuit.Output(10,wires,new long[]{10,20})==2&&AnalyserCircuit.Output(20,wires,new long[]{10,20})==2,"Series analysers do not resolve same output");
  Check(AnalyserCircuit.Output(99,wires,new long[]{10,20})==0,"Unwired sensor selected a network");
  var cabinet=new SwitchboardCabinet();var input=new CableNetwork{PotentialLoad=10000};var one=new CableNetwork{RequiredLoad=3000};var two=new CableNetwork{RequiredLoad=7000};
  cabinet.InputConnection.cable.CableNetwork=input;cabinet.Output1Connection.cable.CableNetwork=one;cabinet.Output2Connection.cable.CableNetwork=two;
  wires=new(){W(0,0,10,0),W(10,1,0,1),W(0,0,20,0),W(20,1,0,2)};
  var power=new CabinetWiringPower();power.Refresh(cabinet,wires,new[]{first,second});
  Check(power.Generated(one)==3000&&power.Generated(two)==7000,"Sensor changed power allocation");
  power.Use(one,3000);power.Use(two,7000);Check(power.DrainTrips().Length==0,"Zero-rated sensor incorrectly trips");
  var battery=new DinBreaker{ReferenceId=40,IsBatteryModule=true};
  power=new CabinetWiringPower();power.Refresh(cabinet,wires,new[]{first,second,battery});
  power.Use(one,3000);power.Use(two,7000);Check(power.DrainTrips().Length==0,"Battery power path incorrectly trips sensor");
  var protective=new DinBreaker{ReferenceId=30,OnOff=true,RatedWatts=2000};wires=new(){W(0,0,30,0),W(30,1,10,0),W(10,1,0,1)};
  power=new CabinetWiringPower();power.Refresh(cabinet,wires,new[]{first,protective});power.Use(one,3000);
  Check(power.DrainTrips().SequenceEqual(new long[]{30}),"Sensor suppresses upstream breaker trip");
  Console.WriteLine("Analyzer wiring: two independent outputs, downstream switch isolation, series sensors, unwired sensors, unchanged power budget, no false sensor trips with/without battery, upstream overload protection passed.");
 }
}
