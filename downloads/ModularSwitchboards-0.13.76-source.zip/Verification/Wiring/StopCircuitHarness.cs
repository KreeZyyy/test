using System;using System.Linq;using System.Collections.Generic;using ModularSwitchboards;using Assets.Scripts.Networks;
static class StopCircuitHarness
{
 static void Check(bool b,string s){if(!b)throw new Exception(s);}
 static CabinetWireSaveData W(long a,int x,long b,int y)=>new(){From=new(a,x),To=new(b,y)};
 internal static void Run()
 {
  var c=new SwitchboardCabinet();var input=new CableNetwork{PotentialLoad=100000};var first=new CableNetwork{RequiredLoad=50000};var second=new CableNetwork{RequiredLoad=10000};
  c.InputConnection.cable.CableNetwork=input;c.Output1Connection.cable.CableNetwork=first;c.Output2Connection.cable.CableNetwork=second;
  var stop=new DinBreaker{ReferenceId=30,IsDoorStop=true};var led=new DinBreaker{ReferenceId=31,IsDoorLed=true};var bridgeA=new DinBreaker{ReferenceId=900,IsDoorBridge=true};var bridgeB=new DinBreaker{ReferenceId=901,IsDoorBridge=true};var all=new[]{stop,led,bridgeA,bridgeB};
  var wires=new List<CabinetWireSaveData>{W(0,0,900,2),W(900,3,30,0),W(30,1,31,0),W(31,1,901,3),W(901,2,0,1),W(0,0,0,2)};
  var power=new CabinetWiringPower();power.Refresh(c,wires,all);Check(power.Generated(first)>0&&power.Generated(second)>0,"Released stop passes both paths");power.Use(first,50000);Check(!power.DrainTrips().Contains(30),"TOTAL STOP is not an overload breaker");
  var through=DoorModuleLayout.Through(wires,new long[]{900,901});Check(DoorModuleLayout.Energized(31,through,all.Where(m=>m.Conducting).Select(m=>m.ReferenceId),true,Array.Empty<long>()),"LED after released stop lights");
  stop.OnOff=true;power.Refresh(c,wires,all);Check(power.Generated(first)==0&&power.Generated(second)>0,"Latched stop isolates only its wired path");Check(!DoorModuleLayout.Energized(31,through,all.Where(m=>m.Conducting).Select(m=>m.ReferenceId),true,Array.Empty<long>()),"LED after latched stop goes dark");
  // Repeated refreshes/power restoration must never reset the mechanical latch.
  for(int i=0;i<10;i++){input.PotentialLoad=i%2==0?0:100000;power.Refresh(c,wires,all);Check(stop.OnOff&&power.Generated(first)==0,"Power cycle reset stop latch");}
  input.PotentialLoad=100000;stop.OnOff=false;power.Refresh(c,wires,all);Check(power.Generated(first)>0,"Manual reset restores current");
  Console.WriteLine("TOTAL STOP circuit passed: through two neutral bridges, LED, 50 kW load, branch isolation, power cycling and reset.");
 }
}
