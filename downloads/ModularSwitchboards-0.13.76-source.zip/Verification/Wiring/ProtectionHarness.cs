using System;
using System.Collections.Generic;
using System.Linq;
using ModularSwitchboards;
using Assets.Scripts.Networks;
static class ProtectionHarness
{
 static void Check(bool value,string message){if(!value)throw new Exception(message);}
 static CabinetWireSaveData Wire(long a,int ap,long b,int bp)=>new(){From=new(a,ap),To=new(b,bp)};
 internal static void Run()
 {
  var c=new SwitchboardCabinet();var input=new CableNetwork{PotentialLoad=100000};var one=new CableNetwork{RequiredLoad=50000};var two=new CableNetwork{RequiredLoad=50000};
  c.InputConnection.cable.CableNetwork=input;c.Output1Connection.cable.CableNetwork=one;c.Output2Connection.cable.CableNetwork=two;
  var a=new DinBreaker{ReferenceId=10,OnOff=true,RatedWatts=4000};var b=new DinBreaker{ReferenceId=20,OnOff=true,RatedWatts=20000};
  var modules=new[]{a,b};var wires=new List<CabinetWireSaveData>{Wire(0,0,10,0),Wire(10,1,0,1),Wire(0,0,20,0),Wire(20,1,0,2)};
  var p=new CabinetWiringPower();p.Refresh(c,wires,modules);Check(p.DrainTrips().Length==0,"Advertised budget/demand trips unloaded breaker");
  p.Use(one,4000);p.Use(two,20000);Check(p.DrainTrips().Length==0,"Exact rated actual load trips");
  p.Use(one,4001);Check(p.DrainTrips().SequenceEqual(new long[]{10}),"Overload failed or tripped other branch");
  a.OnOff=false;p.Refresh(c,wires,modules);Check(p.Generated(one)==0&&p.Generated(two)>0,"Tripped branch didn't isolate");
  p.Use(one,50000);Check(p.DrainTrips().Length==0,"Late output callback trips disconnected module");
  a.IsFuseHolder=true;a.FusePresent=false;p.Refresh(c,wires,modules);Check(p.Generated(one)==0,"Empty fuse passes power");
  a.FusePresent=true;p.Refresh(c,wires,modules);Check(p.Generated(one)>0,"Valid fuse doesn't conduct");p.Use(one,4001);Check(p.DrainTrips().Contains(10),"Fuse overload not signalled");
  // One upstream device must carry the sum of both output branches.
  var common=new DinBreaker{ReferenceId=30,OnOff=true,RatedWatts=24000};wires.RemoveAt(0);wires.RemoveAt(1);wires.Add(Wire(0,0,30,0));wires.Add(Wire(30,1,10,0));wires.Add(Wire(30,1,20,0));
  a.IsFuseHolder=false;a.OnOff=true;a.RatedWatts=100000;b.RatedWatts=100000;p=new CabinetWiringPower();p.Refresh(c,wires,new[]{a,b,common});
  p.Use(one,12000);p.Use(two,12000);Check(p.DrainTrips().Length==0,"Shared exact sum trips");p.Use(two,12001);Check(p.DrainTrips().SequenceEqual(new long[]{30}),"Shared upstream load sum wrong");
  p=new CabinetWiringPower();p.Refresh(c,wires,new[]{a,b,common});p.Use(one,12000);p.ObserveIdle(one);p.Use(two,24000);Check(p.DrainTrips().Length==0,"Idle provider retained stale branch load");
  p.Receive(input,p.Used(input));Check(p.Used(input)==0,"Protection changed energy debt repayment");
  Console.WriteLine("Production module protection passed: actual delivery only, exact threshold, isolated outputs, empty fuse, shared upstream sum, late callbacks and energy accounting.");
 }
}
