using UnityEngine;namespace ModularSwitchboards {static class Thing{public const int DiffuseIndexPropertyID=1,EMISSION_COLOR=2;}public enum ColorType{Red=5,Blue=7,Yellow=9,White=4}class CabinetWiring{        internal static bool IsWireVisual(string name)=>name=="InternalWire"||name=="WireContact"||name=="WireRoutePreview";
        internal void Color(MeshRenderer renderer,ColorType color)
        {
            // Per-material blocks override renderer-wide blocks. Write at slot 0,
            // so a stale cabinet color can never mask this wire's own color.
            var block=new MaterialPropertyBlock();renderer.GetPropertyBlock(block,0);
            block.SetFloat(Thing.DiffuseIndexPropertyID,(int)color);block.SetColor(Thing.EMISSION_COLOR,UnityEngine.Color.black);
            renderer.SetPropertyBlock(block,0);
        }
}}