using System;
using System.Collections.Generic;
using ModularSwitchboards;
namespace UnityEngine{
 public struct Color{public static Color black=>new();}
 public class MaterialPropertyBlock{
  internal Dictionary<int,float> data=new();public void SetFloat(int id,float v){data[id]=v;}public void SetColor(int id,Color v){data[id]=0;}internal MaterialPropertyBlock Clone(){var x=new MaterialPropertyBlock();foreach(var v in data)x.data[v.Key]=v.Value;return x;}
 }
 public class MeshRenderer{
  public string name;private MaterialPropertyBlock global=new();private Dictionary<int,MaterialPropertyBlock> blocks=new();
  public void GetPropertyBlock(MaterialPropertyBlock b){b.data=new(global.data);}public void SetPropertyBlock(MaterialPropertyBlock b){global=b.Clone();}
  public void GetPropertyBlock(MaterialPropertyBlock b,int role){b.data=blocks.TryGetValue(role,out var x)?new(x.data):new();}public void SetPropertyBlock(MaterialPropertyBlock b,int role){blocks[role]=b.Clone();}
  public float Effective(int property)=>blocks.TryGetValue(0,out var b)&&b.data.TryGetValue(property,out var value)?value:global.data.GetValueOrDefault(property,-1);
 }
}
class Program{
 static void Check(bool p,string m){if(!p)throw new Exception(m);}
 static void CabinetPaint(UnityEngine.MeshRenderer r,int color){if(CabinetWiring.IsWireVisual(r.name))return;var b=new UnityEngine.MaterialPropertyBlock();b.SetFloat(1,color);r.SetPropertyBlock(b,0);}
 static void Main(){
 var renderer=new UnityEngine.MeshRenderer{name="InternalWire"};var stale=new UnityEngine.MaterialPropertyBlock();stale.SetFloat(1,9);renderer.SetPropertyBlock(stale,0);
 var oldWireColor=new UnityEngine.MaterialPropertyBlock();oldWireColor.SetFloat(1,7);renderer.SetPropertyBlock(oldWireColor);Check(renderer.Effective(1)==9,"Regression fixture must reproduce material-level cabinet color masking wire color");
 var wiring=new CabinetWiring();wiring.Color(renderer,ColorType.Blue);Check(renderer.Effective(1)==7,"Own wire paint did not override stale cabinet color");
 CabinetPaint(renderer,4);Check(renderer.Effective(1)==7,"Cabinet paint changed wire");
 wiring.Color(renderer,ColorType.Yellow);Check(renderer.Effective(1)==9,"Wire hover not visible");wiring.Color(renderer,ColorType.Blue);Check(renderer.Effective(1)==7,"Hover lost saved wire color");
 foreach(string name in new[]{"WireContact","WireRoutePreview"}){var r=new UnityEngine.MeshRenderer{name=name};wiring.Color(r,ColorType.Yellow);CabinetPaint(r,7);Check(r.Effective(1)==9,"Cabinet paint changed wiring UI visual");}
 var housing=new UnityEngine.MeshRenderer{name="Housing"};CabinetPaint(housing,7);Check(housing.Effective(1)==7,"Cabinet itself no longer paints");
 Check(!CabinetWiring.IsWireVisual("DinBreakerModel")&&!CabinetWiring.IsWireVisual("NativeAnalyserFront"),"Module renderers misclassified as wires");
 Console.WriteLine("Production wire color helper and exclusion predicate passed: old mask bug reproduced, stale material override restored, cabinet paint isolated, hover restored, contact/preview protected, cabinet still paints.");
 }
}
