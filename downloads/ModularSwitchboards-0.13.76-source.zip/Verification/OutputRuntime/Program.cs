using System;
class CabinetOutputCasing{public bool FitFailed;}
class Transform{public CabinetOutputCasing State=new();public Transform Find(string path)=>this;public T GetComponent<T>()where T:class=>State as T;}
class Structure{public bool IsCursor;public Transform transform=new();}
static class Debug{public static int Errors;public static void LogError(string s){Errors++;}}
static class CabinetPowerOutputs{const string CasingName="OutputTCasing";public static int Calls;public static bool Throw;static void Fit(Structure c){Calls++;if(Throw)throw new Exception("simulated missing mesh");}
        internal static void TryFit(Structure cabinet)
        {
            if(cabinet.IsCursor)return;
            var casing=cabinet.transform.Find("SwitchboardModel/CompletedShell/"+CasingName);
            var state=casing==null?null:casing.GetComponent<CabinetOutputCasing>();
            if(state==null||state.FitFailed)return;
            try {Fit(cabinet);}
            catch(Exception ex)
            {
                state.FitFailed=true;
                Debug.LogError("[Modular Switchboards] Output MODEL wall fit paused after one failure; existing model retained: "+ex);
            }
        }
}
class Program{static void Main(){var cursor=new Structure{IsCursor=true,transform=null};CabinetPowerOutputs.TryFit(cursor);if(CabinetPowerOutputs.Calls!=0)throw new Exception("cursor accessed stripped scene");var healthy=new Structure();CabinetPowerOutputs.TryFit(healthy);if(CabinetPowerOutputs.Calls!=1||healthy.transform.State.FitFailed)throw new Exception("healthy fit skipped");CabinetPowerOutputs.Throw=true;var broken=new Structure();for(int i=0;i<100;i++)CabinetPowerOutputs.TryFit(broken);if(CabinetPowerOutputs.Calls!=2||Debug.Errors!=1||!broken.transform.State.FitFailed)throw new Exception("error spam not stopped");Console.WriteLine("Production runtime wrapper passed: stripped cursor skipped, normal fit runs, 100 repeated failed updates produce one attempt/log.");}}
