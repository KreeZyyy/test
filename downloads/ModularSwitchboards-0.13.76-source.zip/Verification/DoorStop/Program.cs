using System;using ModularSwitchboards;using Assets.Scripts.Objects;using UnityEngine;
namespace UnityEngine{
 public class GameObject{public Transform transform;public GameObject(){transform=new Transform{gameObject=this};}}
 public struct Vector3{public float x,y,z;public Vector3(float x,float y,float z){this.x=x;this.y=y;this.z=z;}}
 public struct Quaternion{public float z;public static Quaternion Euler(float x,float y,float z)=>new(){z=z};}
 public static class Time{public static float deltaTime=.016f;}
 public static class Mathf{public static float Max(float x,float y)=>Math.Max(x,y);public static float MoveTowards(float a,float b,float d)=>Math.Abs(b-a)<=d?b:a+Math.Sign(b-a)*d;}
 public class Transform{public GameObject gameObject;public Transform parent,child;public Vector3 localPosition;public Quaternion localRotation;public Transform Find(string name)=>child;}
 public class MonoBehaviour{public GameObject gameObject;public Transform transform=>gameObject.transform;public DinBreaker actual;public T GetComponent<T>() where T:class=>actual as T;}
}
namespace Assets.Scripts.Objects{public class Thing{public class DelayedActionInstance{public float Duration;public string ActionMessage;public bool Success;public DelayedActionInstance Fail(string s){Success=false;return this;}public DelayedActionInstance Succeed(){Success=true;return this;}}}public class Interactable{public DinBreaker Parent;}}
namespace Assets.Scripts.Networking{public static class OnServer{public static int Calls,Last;public static bool Apply=true;public static void Interact(Interactable c,int state){Calls++;Last=state;if(Apply)c.Parent.OnOff=state==1;}}}
namespace ModularSwitchboards{public class Board{public object PrimaryHost;}public class SwitchboardCabinet{public bool IsStructureCompleted=true;}public class DinBreaker{public bool IsCursor,IsBeingDestroyed,IsStructureCompleted=true,OnOff;public Board Board;public GameObject gameObject=new();}}
class Program{
 static int n;static void Check(bool ok,string text){n++;if(!ok)throw new Exception(text);}
 static void Tick(DoorStopView view)=>typeof(DoorStopView).GetMethod("LateUpdate",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).Invoke(view,null);
 static void Main(){
 var host=new SwitchboardCabinet();var part=new DinBreaker{Board=new(){PrimaryHost=host}};var control=new Interactable{Parent=part};
 var preview=DoorStopControl.Interact(part,control,false);Check(preview.Success&&preview.Duration==0&&!part.OnOff&&Assets.Scripts.Networking.OnServer.Calls==0,"Ready preview cannot press latch");
 DoorStopControl.Interact(part,control,true);Check(part.OnOff&&Assets.Scripts.Networking.OnServer.Last==1,"Press latches through native network interaction");
 for(int i=0;i<20;i++){var hold=DoorStopControl.Interact(part,control,false);Check(hold.Success&&hold.Duration==1.2f&&part.OnOff,"Cancelled reset previews remain latched");}
 Check(DoorStopControl.ActionName(true).Contains("reset")&&DoorStopControl.ActionName(false).Contains("Press"),"Different ready/reset prompts");
 DoorStopControl.Interact(part,control,true);Check(!part.OnOff&&Assets.Scripts.Networking.OnServer.Last==0,"Completed reset closes contact");
 Assets.Scripts.Networking.OnServer.Apply=false;DoorStopControl.Interact(part,control,true);Check(!part.OnOff&&Assets.Scripts.Networking.OnServer.Last==1,"Client sends press instead of local mutation");Assets.Scripts.Networking.OnServer.Apply=true;
 foreach(int invalid in new[]{0,1,2,3,4}){part.IsCursor=invalid==0;part.IsBeingDestroyed=invalid==1;part.IsStructureCompleted=invalid!=2;host.IsStructureCompleted=invalid!=3;if(invalid==4)part.Board=null;int before=Assets.Scripts.Networking.OnServer.Calls;Check(!DoorStopControl.Interact(part,control,true).Success&&before==Assets.Scripts.Networking.OnServer.Calls,"Uninstalled/cursor/destroyed/incomplete cannot interact");part.IsCursor=part.IsBeingDestroyed=false;part.IsStructureCompleted=host.IsStructureCompleted=true;part.Board=new(){PrimaryHost=host};}
 var button=new GameObject().transform;button.parent=part.gameObject.transform;part.gameObject.transform.child=button;var view=new DoorStopView{gameObject=part.gameObject,actual=part};
 Tick(view);Check(button.localPosition.z==0,"Fresh ready button raised");part.OnOff=true;for(int i=0;i<30;i++)Tick(view);Check(button.localPosition.z==-.009f,"Pressed button remains down");
 var loaded=new DoorStopView{gameObject=part.gameObject,actual=part};Tick(loaded);Check(button.localPosition.z==-.009f,"Already latched save/join pose does not reset");
 part.OnOff=false;Tick(view);Check(button.localPosition.z<0&&button.localRotation.z<0,"Reset turns and lifts mushroom");for(int i=0;i<30;i++)Tick(view);Check(button.localPosition.z==0&&button.localRotation.z==0,"Reset ends raised");
 var another=new DinBreaker{Board=part.Board,OnOff=true};var ownButton=new GameObject().transform;ownButton.parent=another.gameObject.transform;another.gameObject.transform.child=ownButton;var clone=new DoorStopView{gameObject=another.gameObject,actual=another,Owner=part,Button=button};Tick(clone);Check(clone.Owner==another&&clone.Button==ownButton&&ownButton.localPosition.z==-.009f&&button.localPosition.z==0,"Clone repairs copied owner/model without affecting source");
 Console.WriteLine($"TOTAL STOP: {n} production control/pose checks passed.");
 }
}
