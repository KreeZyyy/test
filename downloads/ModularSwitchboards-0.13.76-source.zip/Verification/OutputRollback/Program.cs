using System;using System.Collections.Generic;using System.Linq;
class Connection{}
class Collider{}
class GameObject{public bool deleted;}
class Transform{public GameObject gameObject=new();public Dictionary<string,Transform> nodes=new();public Transform Find(string path)=>nodes.TryGetValue(path,out var node)&&!node.gameObject.deleted?node:null;}
class BuildState{public List<Collider> Colliders=new();public List<GameObject> LinkedGameObjects=new();}
class SwitchboardCabinet{public Transform transform=new();public BuildState[] BuildStates={new(),new()};public List<Connection> OpenEnds=new(){new Connection()};}
static class CabinetModel{public static int BoundsUpdates;public static void SetBounds(SwitchboardCabinet c){BoundsUpdates++;}}
static class Debug{public static void LogError(string s){}}
namespace UnityEngine{static class Object{public static void DestroyImmediate(GameObject go){go.deleted=true;}}}
static class CabinetPowerOutputs{const string RootName="Outputs",CasingName="Casing";public static int FailAt;
static void Install(SwitchboardCabinet c){if(FailAt==0)throw new Exception("before model");var root=new Transform();c.transform.nodes[RootName]=root;c.BuildStates[1].LinkedGameObjects.Add(root.gameObject);c.BuildStates[1].Colliders.Add(new());c.OpenEnds.Add(new());if(FailAt==1)throw new Exception("after port");c.transform.nodes["SwitchboardModel/CompletedShell/"+CasingName]=new();c.BuildStates[1].Colliders.Add(new());if(FailAt==2)throw new Exception("after casing");}
        internal static bool TryInstall(SwitchboardCabinet cabinet)
        {
            var colliders=new List<Collider>(cabinet.BuildStates[1].Colliders);
            var linked=new List<GameObject>(cabinet.BuildStates[1].LinkedGameObjects);
            var ports=new List<Connection>(cabinet.OpenEnds);
            try {Install(cabinet);return true;}
            catch(Exception ex)
            {
                cabinet.OpenEnds=ports;
                var outputs=cabinet.transform.Find(RootName);
                if(outputs!=null)UnityEngine.Object.DestroyImmediate(outputs.gameObject);
                var casing=cabinet.transform.Find("SwitchboardModel/CompletedShell/"+CasingName);
                if(casing!=null)UnityEngine.Object.DestroyImmediate(casing.gameObject);
                cabinet.BuildStates[1].Colliders=colliders;cabinet.BuildStates[1].LinkedGameObjects=linked;
                CabinetModel.SetBounds(cabinet);
                Debug.LogError("[Modular Switchboards] Lower output MODEL unavailable; cabinet, Input and DIN registration preserved: "+ex);
                return false;
            }
        }

}
class Program{static void Main(){for(int stage=0;stage<=3;stage++){var c=new SwitchboardCabinet();var hit=new Collider();var linked=new GameObject();c.BuildStates[1].Colliders.Add(hit);c.BuildStates[1].LinkedGameObjects.Add(linked);CabinetPowerOutputs.FailAt=stage;bool ok=CabinetPowerOutputs.TryInstall(c);if(stage<3){if(ok||c.BuildStates[1].Colliders.Count!=1||c.BuildStates[1].Colliders[0]!=hit||c.BuildStates[1].LinkedGameObjects.Count!=1||c.BuildStates[1].LinkedGameObjects[0]!=linked||c.transform.Find("Outputs")!=null||c.transform.Find("SwitchboardModel/CompletedShell/Casing")!=null||c.OpenEnds.Count!=1)throw new Exception("rollback failed");}else if(!ok)throw new Exception("success swallowed");}Console.WriteLine("Production model installation wrapper passed 3 injected failures and success: cleanup and original state lists preserved.");}}
