using System;using System.Collections.Generic;using System.Linq;
using UnityEngine;using ModularSwitchboards;using Assets.Scripts;using Assets.Scripts.Objects;using Assets.Scripts.Objects.Electrical;
namespace UnityEngine {
 public struct Vector3 {public float x,y,z;public Vector3(float x,float y,float z){this.x=x;this.y=y;this.z=z;}public static Vector3 up=>new(0,1,0);public static Vector3 forward=>new(0,0,1);public float sqrMagnitude=>x*x+y*y+z*z;public static Vector3 operator-(Vector3 a,Vector3 b)=>new(a.x-b.x,a.y-b.y,a.z-b.z);public static Vector3 operator+(Vector3 a,Vector3 b)=>new(a.x+b.x,a.y+b.y,a.z+b.z);public static float Dot(Vector3 a,Vector3 b)=>a.x*b.x+a.y*b.y+a.z*b.z;public string ToString(string format)=>$"{x},{y},{z}";}
 public struct Quaternion {public Vector3 forward;public static Quaternion LookRotation(Vector3 f,Vector3 up)=>new(){forward=f};}
 public class Component {public GameObject gameObject;public Transform transform=>gameObject.transform;}
 public class GameObject {public string name;public int layer;public Transform transform;private Dictionary<Type,object> components=new();public GameObject(string name){this.name=name;transform=new Transform{gameObject=this};}public T AddComponent<T>()where T:new(){var t=new T();components[typeof(T)]=t;if(t is Component c)c.gameObject=this;return t;}public T GetComponent<T>()where T:class=>components.TryGetValue(typeof(T),out var o)?o as T:null;}
 public class Transform {public GameObject gameObject;public Transform parent;public List<Transform> children=new();public Vector3 localPosition;public Quaternion localRotation;public Vector3 position=>parent==null?localPosition:parent.position+localPosition;public void SetParent(Transform p,bool preserve){parent=p;p.children.Add(this);}public Transform Find(string path){var t=this;foreach(var part in path.Split('/')){t=t.children.FirstOrDefault(c=>c.gameObject.name==part);if(t==null)return null;}return t;}public T GetComponent<T>()where T:class=>gameObject.GetComponent<T>();}
 public class Collider:Component{}public class BoxCollider:Collider{public Vector3 center,size;}
 public static class Debug {public static void Log(string s){} }
}
namespace Assets.Scripts {public class WorldManager {public static WorldManager Instance=new();public List<object> SourcePrefabs=new();}}
namespace Assets.Scripts.Objects {public enum NetworkType{None=0,Power=1,Data=2}public enum ConnectionRole{Input,Output}public class Connection{public SwitchboardCabinet Parent;public Transform Transform;public Collider Collider;public NetworkType ConnectionType;public ConnectionRole ConnectionRole;public bool IsValid;public Connection(SwitchboardCabinet p){Parent=p;}public void Validate(){IsValid=Parent!=null&&Transform!=null;}}}
namespace Assets.Scripts.Objects.Electrical {public class AreaPowerControl{public int SmallCollisionType=731;}}
namespace ModularSwitchboards {
 public class BuildState{public List<Collider> Colliders=new();}
 public class SwitchboardCabinet:Component{public bool IsStructureCompleted;public int SmallCollisionType;public float UsedPower=99;public List<Connection> OpenEnds=new();public BuildState[] BuildStates={new(),new()};}
 public class OvenInputPanelMetadata:Component{public Vector3 SocketPoint,SocketAxis;public bool FunctionalConnection;}
 public static class OvenInputPanel{public const string RootName="OvenInputPanel";}
 public static class NativeCableLayout{public struct Socket{public Vector3 Point,Forward;public string CableCell,BodyCell;}public static Socket Current=new(){Point=new(0,.25f,0),Forward=new(0,-1,0),CableCell="cable",BodyCell="body"};public static Socket Read(Vector3 cell,Vector3 outward)=>Current;}
}
class Program {
 static void Assert(bool condition,string message){if(!condition)throw new Exception(message);}
 static SwitchboardCabinet Make(bool completed){var c=new GameObject("Cabinet").AddComponent<SwitchboardCabinet>();c.IsStructureCompleted=completed;var p=c.transform;foreach(var name in new[]{"SwitchboardModel","CompletedShell",OvenInputPanel.RootName}){var g=new GameObject(name);g.transform.SetParent(p,false);p=g.transform;}var d=p.gameObject.AddComponent<OvenInputPanelMetadata>();d.SocketPoint=NativeCableLayout.Current.Point;d.SocketAxis=NativeCableLayout.Current.Forward;return c;}
 static void Main(){WorldManager.Instance.SourcePrefabs.Add(new AreaPowerControl());
 foreach(bool completed in new[]{false,true}){
  var c=Make(completed);CabinetPowerInput.Install(c);Assert(c.OpenEnds.Count==1,"one port");var input=c.OpenEnds[0];Assert(input.ConnectionRole==ConnectionRole.Input&&input.Parent==c&&input.IsValid,"input owner/role");Assert(input.ConnectionType==(completed?NetworkType.Power:NetworkType.None),"build-state activation");Assert(c.UsedPower==0&&c.SmallCollisionType==731,"zero load/native collision mask");Assert(c.BuildStates[1].Colliders.Contains(input.Collider)&&c.BuildStates[0].Colliders.Count==0,"completed-only collider");
  var shell=c.transform.Find("SwitchboardModel");var panel=shell.Find("CompletedShell/"+OvenInputPanel.RootName);var anchor=input.Transform.position;shell.localPosition=new(0,0,.17f);Assert((input.Transform.position-anchor).sqrMagnitude==0,"wall fit moved logical endpoint");Assert(input.Collider.transform.parent==panel,"hitbox must follow socket visual");Assert(panel.GetComponent<OvenInputPanelMetadata>().FunctionalConnection,"functional marker");
  try{CabinetPowerInput.Install(c);throw new Exception("duplicate accepted");}catch(InvalidOperationException){}Assert(c.OpenEnds.Count==1,"duplicate mutated ports");
 }
 var mismatch=Make(true);mismatch.transform.Find("SwitchboardModel/CompletedShell/"+OvenInputPanel.RootName).GetComponent<OvenInputPanelMetadata>().SocketPoint=new(2,3,4);try{CabinetPowerInput.Install(mismatch);throw new Exception("bad metadata accepted");}catch(InvalidOperationException){}Assert(mismatch.OpenEnds.Count==0&&mismatch.transform.Find(CabinetPowerInput.RootName)==null,"failed validation mutated cabinet");
 Console.WriteLine("Production IN installation passed: single Input, completed/build state, owner, collision mask, zero idle load, grid anchor independent of wall fit, socket hitbox, duplicate and metadata guards. Unity/network simulation remains untested.");
 }
}
