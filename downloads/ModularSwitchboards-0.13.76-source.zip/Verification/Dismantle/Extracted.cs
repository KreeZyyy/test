using System;using System.Linq;using Assets.Scripts;using Assets.Scripts.Objects;using UnityEngine;namespace ModularSwitchboards{partial class CabinetWiring{        internal void RefundAndRemoveBreaker(long id,Vector3 position,Slot destination)
        {
            if(!GameManager.RunSimulation)return;
            int units=wires.Where(w=>w.From.Owner==id||w.To.Owner==id).Sum(w=>w.CableUnits);
            if(units>0)
            {
                var prefab=Prefab.Find<Item>("ItemCableCoil");
                if(prefab==null)throw new InvalidOperationException("Cable coil prefab unavailable during module demolition");
                OnServer.CreateOrStack(prefab,units,position,Quaternion.identity,destination);
            }
            RemoveBreaker(id);
        }
        internal void RemoveBreaker(long id)
        {
            if(wires.RemoveAll(w=>w.From.Owner==id||w.To.Owner==id)>0)Changed();
            foreach(var actor in pending.Where(p=>p.Value.Owner==id).Select(p=>p.Key).ToArray()){pending.Remove(actor);pendingUntil.Remove(actor);Owner.NetworkUpdateFlags|=UpdateFlag;}
            topology=null;
        }
}}