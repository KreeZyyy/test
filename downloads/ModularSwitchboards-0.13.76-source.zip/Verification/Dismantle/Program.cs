using System;
using System.Linq;
using System.Collections.Generic;
using Assets.Scripts;
using Assets.Scripts.Objects;
using UnityEngine;
using ModularSwitchboards;
namespace UnityEngine{public struct Vector3{public float x,y,z;}public struct Quaternion{public static Quaternion identity=>new();}}
namespace Assets.Scripts{static class GameManager{public static bool RunSimulation=true;}static class Prefab{public static bool Available=true;public static T Find<T>(string name)where T:new()=>Available?new T():default;}}
namespace Assets.Scripts.Objects{class Structure{}class Item{}class Slot{}class ConstructionEventInstance{public Vector3 Position;public Slot OtherHandSlot;}}
static class OnServer{public static int Units,Calls;public static Slot Hand;public static void CreateOrStack(Item item,int units,Vector3 p,Quaternion q,Slot slot){Units+=units;Calls++;Hand=slot;}}
namespace ModularSwitchboards{
 class DinBreaker:Structure{public long ReferenceId;public Cabinet Host;}
 class Cabinet{public CabinetWiring Wiring;public ushort NetworkUpdateFlags;}
 partial class CabinetWiring{
  internal readonly List<CabinetWireSaveData> wires=new();internal readonly Dictionary<long,CabinetWireEnd> pending=new();internal readonly Dictionary<long,float> pendingUntil=new();internal string topology;internal int changes;internal const ushort UpdateFlag=32768;
  internal Cabinet Owner;internal static Cabinet CabinetOf(DinBreaker m)=>m.Host;internal bool HasWires(long id)=>wires.Any(w=>w.From.Owner==id||w.To.Owner==id);private void Changed(){changes++;Owner.NetworkUpdateFlags|=UpdateFlag;}
 }
}
class Program{
 static CabinetWireSaveData W(long a,int ap,long b,int bp)=>new(){From=new(a,ap),To=new(b,bp),CableUnits=1};
 static void Check(bool b,string m){if(!b)throw new Exception(m);}
 static void Main(){
 var cabinet=new Cabinet();var wiring=new CabinetWiring{Owner=cabinet};cabinet.Wiring=wiring;
 var module=new DinBreaker{ReferenceId=10,Host=cabinet};var hand=new Slot();var action=new ConstructionEventInstance{OtherHandSlot=hand};
 wiring.wires.AddRange(new[]{W(0,0,10,0),W(10,1,0,1),W(0,0,20,0),W(20,1,0,2)});wiring.pending[99]=new(10,0);wiring.pendingUntil[99]=10;
 Check(ModuleDismantle.CanRefund(module),"Available cable prefab blocks demolition");Prefab.Available=false;Check(!ModuleDismantle.CanRefund(module),"Missing refund prefab accepted");Prefab.Available=true;
 GameManager.RunSimulation=false;ModuleDismantle.Refund(module,action,false);Check(OnServer.Calls==0&&wiring.wires.Count==4,"Client spawned/deleted wire");GameManager.RunSimulation=true;
 ModuleDismantle.Refund(module,action,true);Check(OnServer.Calls==0&&wiring.wires.Count==4,"Damage refunded wire");
 ModuleDismantle.Refund(new Structure(),action,false);Check(OnServer.Calls==0,"Non-module refunded wire");
 ModuleDismantle.Refund(module,action,false);
 Check(OnServer.Units==2&&OnServer.Calls==1&&OnServer.Hand==hand,"Wrong cable refund or destination");
 Check(wiring.wires.Count==2&&wiring.wires.All(w=>w.From.Owner!=10&&w.To.Owner!=10),"Connected wires remain");
 Check(!wiring.pending.ContainsKey(99)&&!wiring.pendingUntil.ContainsKey(99)&&wiring.changes==1,"Pending selection or topology update missing");
 Check(WireCircuit.Reachable(new(0,0),new(0,2),wiring.wires,new long[]{20}),"Other output damaged");
 ModuleDismantle.Refund(module,action,false);wiring.RemoveBreaker(10);Check(OnServer.Units==2&&OnServer.Calls==1,"Duplicate destruction/deregistration refunded twice");
 Console.WriteLine("Production demolition hook/cleanup passed: authority only, damage skipped, two cable units refunded once to other hand, only attached wires removed, pending selection cleared, other output intact, repeated cleanup idempotent.");
 }
}
