using System.Xml.Serialization;namespace ModularSwitchboards{    public sealed class DinBreakerSaveData : StructureSaveData
    {
        [XmlElement] public PlacementBoardStructureSaveData RailBoard;
        [XmlElement] public bool Tripped;
        [XmlElement] public int BodyPaintVersion;
    }

static class Migration{public const string CabinetName="cabinet",BreakerKitName="kit";        internal static void MigrateBreakerName(Thing __instance, ThingSaveData __0)
        {
            // Previously modules had fixed white casings, while the hidden native
            // color could come from the locker template. Migrate old saves once.
            if(__instance is DinBreaker && __0 is DinBreakerSaveData paintSave && paintSave.BodyPaintVersion<1)
                __0.CustomColorIndex=(int)Assets.Scripts.Objects.Motherboards.ColorType.White;

            if(__instance.PrefabName==CabinetName && (__0.CustomName=="Switchboard Cabinet" || __0.CustomName=="Switchboard")) __0.CustomName="Switchboard Small";
            if(DinModuleCatalog.Specs.TryGetValue(__instance.PrefabName,out var spec)&&(__0.CustomName=="DIN Breaker 1P"||__0.CustomName=="DIN Breaker")) __0.CustomName=spec.Title;
            // Migrate only the old default titles; preserve player custom names.
            if((__instance.PrefabName=="StructureDinBatteryBackup"&&__0.CustomName=="DIN Battery Backup (2 slots)")||
                (__instance.PrefabName=="StructureDinCableAnalyser"&&__0.CustomName=="DIN Cable Analyzer (3 slots)"))
                __0.CustomName=DinModuleCatalog.Specs[__instance.PrefabName].Title;
            if(__instance.PrefabName==BreakerKitName && (__0.CustomName=="Kit (DIN Breaker 1P)"||__0.CustomName=="Kit (DIN Breaker)")) __0.CustomName="Kit (DIN Modules)";
        }

}}