using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Serialization;
using ModularSwitchboards;
namespace Assets.Scripts.Objects.Motherboards {public enum ColorType {White=4,Red=8}}
namespace ModularSwitchboards {
 public class Thing {public string PrefabName;}
 public class DinBreaker:Thing{}
 public class ThingSaveData {public int CustomColorIndex;public string CustomName;}
 public class StructureSaveData:ThingSaveData{}
 public class PlacementBoardStructureSaveData{}
 static class DinModuleCatalog {
  internal sealed class Spec {public string Title;}
  internal static Dictionary<string,Spec> Specs=new(){["StructureDinBatteryBackup"]=new(){Title="DIN Battery Backup"},["StructureDinCableAnalyser"]=new(){Title="DIN Cable Analyzer"}};
 }
}
class Program {
 static void Check(bool pass,string message){if(!pass)throw new Exception(message);}
 static void Main(){
 var xml=new XmlSerializer(typeof(DinBreakerSaveData));
 var old=(DinBreakerSaveData)xml.Deserialize(new StringReader("<DinBreakerSaveData><CustomColorIndex>9</CustomColorIndex><CustomName>My branch</CustomName><Tripped>true</Tripped></DinBreakerSaveData>"));
 Check(old.BodyPaintVersion==0,"Old save must default to paint schema zero");
 var module=new DinBreaker{PrefabName="StructureDinCableAnalyser"};Migration.MigrateBreakerName(module,old);
 Check(old.CustomColorIndex==4&&old.CustomName=="My branch"&&old.Tripped,"Old module paint migration damaged saved state");
 var painted=new DinBreakerSaveData{BodyPaintVersion=1,CustomColorIndex=8,CustomName="My red circuit",Tripped=true};
 var writer=new StringWriter();xml.Serialize(writer,painted);var restored=(DinBreakerSaveData)xml.Deserialize(new StringReader(writer.ToString()));Migration.MigrateBreakerName(module,restored);
 Check(restored.BodyPaintVersion==1&&restored.CustomColorIndex==8&&restored.CustomName==painted.CustomName&&restored.Tripped,"Saved paint does not round-trip");
 var cabinet=new Thing{PrefabName="cabinet"};var cabinetSave=new DinBreakerSaveData{CustomColorIndex=8,BodyPaintVersion=0};Migration.MigrateBreakerName(cabinet,cabinetSave);Check(cabinetSave.CustomColorIndex==8,"Module migration recolored cabinet");
 var battery=new DinBreaker{PrefabName="StructureDinBatteryBackup"};var batterySave=new DinBreakerSaveData{CustomName="DIN Battery Backup (2 slots)",CustomColorIndex=8,BodyPaintVersion=1};Migration.MigrateBreakerName(battery,batterySave);Check(batterySave.CustomName=="DIN Battery Backup"&&batterySave.CustomColorIndex==8,"Title migration lost paint");
 Console.WriteLine("Production save DTO and migration passed: old saves white, painted saves preserve color/name/trip state, cabinet color untouched, default-title migration preserves new paint.");
 }
}
