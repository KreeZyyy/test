using System.Linq;using Assets.Scripts.Objects.Electrical;using Assets.Scripts.Objects;using Assets.Scripts;using Assets.Scripts.Networking;using System.Xml.Serialization;using LibConstruct;
namespace ModularSwitchboards {
    public sealed class DinBreakerSaveData : StructureSaveData
    {
        [XmlElement] public PlacementBoardStructureSaveData RailBoard;
        [XmlElement] public bool Tripped;
        [XmlElement] public int BodyPaintVersion;
    }


partial class DinBreaker {
        internal void Trip()
        {
            if(!GameManager.RunSimulation||IsBatteryModule||IsAnalyserModule||!Conducting)return;
            if(IsFuseHolder){var kit=Slots[0].Get() as MultiConstructor;if(kit!=null)kit.RemoveQuantity(1);}
            else {OnOff=false;}
            Tripped=true;NetworkUpdateFlags|=ModuleUpdate;
            if(IsFuseHolder){fuseBurnSequence=unchecked(fuseBurnSequence+1);DinFuseAudio.Play(this);}
        }
        public override void BuildUpdate(RocketBinaryWriter writer,ushort flags){base.BuildUpdate(writer,flags);if(Thing.IsNetworkUpdateRequired(ModuleUpdate,flags)){writer.WriteBoolean(Tripped);writer.WriteBoolean(!IsFuseHolder&&OnOff);writer.WriteInt32(fuseBurnSequence);}}
        public override void ProcessUpdate(RocketBinaryReader reader,ushort flags)
        {
            base.ProcessUpdate(reader,flags);
            if(Thing.IsNetworkUpdateRequired(ModuleUpdate,flags))
            {
                Tripped=reader.ReadBoolean();bool on=reader.ReadBoolean();if(!IsFuseHolder)OnOff=on;
                int incoming=reader.ReadInt32();
                uint advance=unchecked((uint)(incoming-fuseBurnSequence));
                // Duplicate/older updates must not replay a burn. This also notices
                // a new cartridge burning when both snapshots already say Tripped.
                if(advance!=0&&advance<0x80000000u)
                {
                    fuseBurnSequence=incoming;
                    if(!GameManager.RunSimulation)DinFuseAudio.Play(this);
                }
            }
        }
        public override ThingSaveData SerializeSave()
        {
            ThingSaveData data = new DinBreakerSaveData();
            InitialiseSaveData(ref data);
            return data;
        }
        protected override void InitialiseSaveData(ref ThingSaveData data)
        {
            base.InitialiseSaveData(ref data);
            if (data is DinBreakerSaveData save){save.Tripped=Tripped;save.BodyPaintVersion=1;if(Board!=null)save.RailBoard=BoardStructureHooks.SerializeSave(this);}
        }
        public override void DeserializeSave(ThingSaveData data)
        {
            base.DeserializeSave(data);
            if (data is DinBreakerSaveData save){Tripped=save.Tripped;if(save.RailBoard!=null)BoardStructureHooks.DeserializeSave(this,save.RailBoard);}
        }
        public override void SerializeOnJoin(RocketBinaryWriter writer)
        {
            base.SerializeOnJoin(writer);
            BoardStructureHooks.SerializeOnJoin(writer, this);writer.WriteBoolean(Tripped);writer.WriteInt32(fuseBurnSequence);
        }
        public override void DeserializeOnJoin(RocketBinaryReader reader)
        {
            base.DeserializeOnJoin(reader);
            BoardStructureHooks.DeserializeOnJoin(reader, this);Tripped=reader.ReadBoolean();fuseBurnSequence=reader.ReadInt32();
        }
        public override DelayedActionInstance HandleSwitch(Interaction interaction,int slot,DelayedActionInstance result,bool doAction=true,bool force=false)
        {
            if(IsBatteryModule&&(!(Board?.PrimaryHost is DinRail batteryRail)||!batteryRail.CanAccessModules))return result.Fail("Open the cabinet first.");
            if(!IsFuseHolder||slot!=0)return base.HandleSwitch(interaction,slot,result,doAction,force);
            if(!(Board?.PrimaryHost is DinRail rail)||!rail.CanAccessModules)return result.Fail("Open the cabinet first.");
            var source=interaction.SourceSlot;var destination=Slots[0];
            if(Tripped)
            {
                result.ActionMessage="Remove blown fuse";
                if(doAction&&GameManager.RunSimulation)
                {
                    // The cartridge was already consumed on blowing. Its broken
                    // model remains until this explicit removal, with no usable refund.
                    if(destination.Get()!=null)return result.Fail("Remove the remaining cartridge first.");
                    Tripped=false;NetworkUpdateFlags|=ModuleUpdate;
                }
                return result.Succeed();
            }
            if(destination.Get()!=null)
            {
                if(source?.Get()==null)return base.HandleSwitch(interaction,slot,result,doAction,force);
                if(!(source.Get() is MultiConstructor held)||!(destination.Get() is MultiConstructor installed)||
                    installed.Quantity!=1||held==installed||!held.CanStack(installed))
                    return result.Fail("Use an empty hand or hold the same Cable Fuse kit to remove the fuse.");
                if(held.Quantity>=held.MaxQuantity)return result.Fail("The fuse stack in your hand is full.");
                result.ActionMessage="Take fuse into stack";
                if(doAction&&GameManager.RunSimulation)
                {
                    // Native merge handles quantity replication, slot exit and destruction
                    // of the consumed one-unit stack. Never manufacture a refund item.
                    int before=held.Quantity;held.Merge(installed);
                    if(held.Quantity!=before+1)return result.Fail("Could not merge the fuse into your stack.");
                }
                return result.Succeed();
            }
            if(!(source?.Get() is MultiConstructor kit)||kit.Quantity<1||System.Array.IndexOf(AllowedFuseKits,kit.PrefabHash)<0)
                return result.Fail("Hold the matching Cable Fuse kit; one unit will be inserted.");
            result.ActionMessage="Insert one fuse";
            if(doAction&&GameManager.RunSimulation)
            {
                if(kit.Quantity==1){OnServer.MoveToSlot(kit,destination);if(destination.Get()!=kit)return result.Fail("Fuse slot is unavailable.");}
                else
                {
                    var one=kit.SplitStack(1,destination);
                    if(one==null){kit.AddQuantity(1);return result.Fail("Could not create the fuse cartridge.");}
                    if(destination.Get()!=one)OnServer.MoveToSlot(one,destination);
                    if(destination.Get()!=one){kit.AddQuantity(1);OnServer.Destroy(one);return result.Fail("Fuse slot is unavailable.");}
                }
            }
            return result.Succeed();
        }

}
static class DinModuleAccess {
        internal static bool SlotName(Slot slot,ref string __result)
        {
            if(!(slot?.Parent is DinBreaker module)||!module.IsFuseHolder)return true;
            __result="Cable Fuse";return false;
        }
        internal static bool CanEnter(Thing __instance,Slot destinationSlot,ref CanEnterResult __result)
        {
            if(!(destinationSlot?.Parent is DinBreaker module)||!module.IsFuseHolder)return true;
            if((!LibConstruct.PlacementBoard.Loading&&(module.Tripped||!(module.Board?.PrimaryHost is DinRail rail)||!rail.CanAccessModules))||!(__instance is MultiConstructor kit)||kit.Quantity!=1||!module.AllowedFuseKits.Contains(kit.PrefabHash))
            {__result=CanEnterResult.Fail("Open the cabinet and insert one unit of the matching Cable Fuse kit.");return false;}
            return true;
        }

}}