from pathlib import Path
import re
source=(Path(__file__).resolve().parents[2]/'Source/CabinetWiring.cs').read_text()
plate=re.search(r'bool show=(.*?),tools=',source).group(1)
door=re.search(r'doorVisualRoot.gameObject.SetActive\((.*?)\);',source).group(1)
def evaluate(expr,opened,covered):
 return eval(expr.replace('Owner.IsOpen',str(opened)).replace('Owner.HasInnerCover',str(covered)).replace('&&',' and ').replace('!','not '))
for opened in (False,True):
 for covered in (False,True):
  assert evaluate(plate,opened,covered)==(opened and not covered)
  assert evaluate(door,opened,covered)==opened
assert 'visualRoot.gameObject.SetActive(show)' in source
assert 'tools=show&&LocalTools()' in source
print('8 production wire-root visibility checks passed; plate editing remains cover-gated.')
