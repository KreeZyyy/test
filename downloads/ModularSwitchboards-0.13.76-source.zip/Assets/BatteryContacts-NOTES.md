#0.12.83: live native holder

Visible holder no longer uses BatterySocket.meshbin. NativeApcHolder crops the original live APC index lists via NativeHolderSelection; copies every vertex stream with the original VertexAttributeDescriptors/offsets/strides and original vertex count/IDs; verifies all copied stream bytes after setting indices; reuses original renderer materials and global/per-slot property blocks. Normals/tangents/UV/color channels are never rebuilt for the visible mesh. Raw source vertices remain in original mesh coordinates. An inverse-VisualScale mounting transform followed by original renderer rotation and uniform fit preserves native physical proportions.

CPU-generated positions are used only for module bounds and construction blueprint. The BS02 resource remains embedded only in the verification project as an independent preserved fixture of134original triangles, not as the visible in-game mesh. The source fixture's1971vertices/3900indices are independently compared against selected134triangles while retaining source vertex IDs. Prior whole-holder geometry in Source/BatterySocketModel and separate surface replacements were removed. Full original APC mesh/materials are never modified.

Original reference SHA256:9fbc7208f82984751f879ee86ab237a6480d1734bf2b125c7cda74a1634288ac.
