"""Measure actual visible-content coverage of the crate floor from above."""
from pathlib import Path
import bpy,json
from mathutils import Vector
from mathutils.bvhtree import BVHTree
root=Path(__file__).resolve().parents[1];s=json.loads((root/'Art/ModuleKit/source.json').read_text())['contents'];t=[tuple(ts[i:i+3])for ts in s['triangles'].values()for i in range(0,len(ts),3)];tree=BVHTree.FromPolygons(s['vertices'],t,all_triangles=True)
hits=0;total=0
for ix in range(81):
 for iz in range(81):
  x=-.2+ix*.005;z=-.2+iz*.005
  if abs(x)+abs(z)>.37:continue
  total+=1
  if tree.ray_cast(Vector((x,1,z)),Vector((0,-1,0)))[0]is not None:hits+=1
r={'floor_samples':total,'content_samples':hits,'coverage_fraction':hits/total};print(r);(root/'Art/ModuleKit/coverage-audit.json').write_text(json.dumps(r,indent=2))
