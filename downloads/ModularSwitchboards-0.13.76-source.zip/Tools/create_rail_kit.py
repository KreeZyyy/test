"""Rebuild supported decorative contents, corresponding mesh and icon."""
from pathlib import Path
import subprocess,sys
root=Path(__file__).resolve().parents[1]
subprocess.run([sys.executable,str(root/'Tools/build_kit_pile.py'),'RailKit'],check=True)
