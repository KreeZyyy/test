"""Extract only the two native console cartons and their printed geometry.
Reference and component selection are retained; no runtime source-mod lookup.
"""
from pathlib import Path
import json,struct,math,shutil
from PIL import Image
r=Path(__file__).resolve().parents[1]
folder=r/'Art/ConsoleCartons';folder.mkdir(exist_ok=True)
d=json.loads((folder/'reference.json').read_text());part=d['parts'][0]
components=json.loads((folder/'components.json').read_text())
raw=(folder/'vertex-0-stream-0.bin').read_bytes()
atlas=Image.open(r/"Assets/ConsoleCartons/Surface.png").convert("RGB")
rows=[]
selected=[2,20,21,7,8,11,12,13,14,15,16,17,18,19,*range(38,61)]
for ci in selected:
 for role,ids in components[ci]['triangles']:
  assert role==0
  pts=[tuple(part['vertices'][i][k]for k in ['x','y','z'])for i in ids]
  a,b,c=pts;ab=[b[i]-a[i]for i in range(3)];ac=[c[i]-a[i]for i in range(3)]
  cross=[ab[1]*ac[2]-ab[2]*ac[1],ab[2]*ac[0]-ab[0]*ac[2],ab[0]*ac[1]-ab[1]*ac[0]]
  if sum(v*v for v in cross)<1e-18:continue
  for i,p in zip(ids,pts):
   n=struct.unpack_from('<4e',raw,i*36+12)[:3];length=math.sqrt(sum(x*x for x in n));n=[x/length for x in n]
   uv=struct.unpack_from('<2e',raw,i*36+20)
   # Only support/base parts change swatches; carton print/UV stay exact.
   if ci in [14,15,58,59,60]:
    rgb=atlas.getpixel((int(uv[0]*1024)%1024,int((1-uv[1])*1024)%1024))
    shade=max(rgb);u=.875 if shade<40 else .625 if shade<52 else .375 if shade<65 else .125
    uv=(u,.875)
   elif ci in [12,13,55,56,57]:
    rgb=atlas.getpixel((int(uv[0]*1024)%1024,int((1-uv[1])*1024)%1024))
    uv=(.125 if max(rgb)>110 else .625,.625)
   rows.append([*p,*n,*uv])
out={'source':'Native ItemKitModularConsole local metres, scale 1:1','components':selected,'vertices':rows}
(folder/'cartons.json').write_text(json.dumps(out))
# Generated literals preserve source float32 positions and half-float normals/UV.
lines=['using System.Collections.Generic;using UnityEngine;namespace ModularSwitchboards{internal static class ConsoleCartons{',
'internal static readonly float[] Data=new float[]{']
for row in rows:lines.append(','.join(format(x,'.9g')+'f'for x in row)+',')
lines+=['};internal static int Append(List<Vector3> v,List<Vector3> n,List<int>[] t){int first=v.Count;for(int i=0;i<Data.Length;i+=8){t[2].Add(v.Count);v.Add(new Vector3(Data[i],Data[i+1],Data[i+2]));n.Add(new Vector3(Data[i+3],Data[i+4],Data[i+5]));}return first;}',
'internal static void ApplyUv(Mesh mesh,int first){var uv=new List<Vector2>();for(int i=0;i<first;i++)uv.Add(new Vector2(.5f,.5f));for(int i=0;i<Data.Length;i+=8)uv.Add(new Vector2(Data[i+6],Data[i+7]));while(uv.Count<mesh.vertices.Length)uv.Add(new Vector2(.5f,.5f));mesh.SetUVs(0,uv);}}}']
(r/'Source/ConsoleCartons.cs').write_text('\n'.join(lines))
print('Copied',len(rows)//3,'carton triangles with native coordinates, normals and UV.')
