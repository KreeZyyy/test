"""Layered face-up modules plus Cable Analyzer; fixed offline layout with full clearance."""
from pathlib import Path
import json,subprocess,sys,random
from kit_layout import rotate,add,bounds,obb,separate,inside
root=Path(__file__).resolve().parents[1];f=root/'Art/ModuleKit/source.json';data=json.loads(f.read_text())
packed=json.loads((root/'Art/ModuleKit/packed-contents.json').read_text());pv=packed['vertices']
def group(x):return 0 if x<-.106 else 1 if x<.005 else 2
parts={}
for groupid in range(3):
 ids=[i for i,p in enumerate(pv)if group(p[0])==groupid];mapping={old:i for i,old in enumerate(ids)}
 center=[sum(pair)*.5 for pair in bounds([pv[i]for i in ids])]
 points=[[q*.66 for q in rotate([pv[i][k]-center[k]for k in range(3)],[-75,0,0])]for i in ids]
 ts={}
 for role,indices in packed['triangles'].items():
  ts[role]=[mapping[j]for j in indices if group(pv[j][0])==groupid]
 parts[groupid]={'vertices':points,'triangles':ts}
# Add the original production Analyzer body and display/lightning face, not the yellow native casing.
geo=json.loads((root/'Art/CatalogGeometry.json').read_text());front=geo['analyserFront'];ts=front['triangles']['0'];components=[]
for i in range(0,len(ts),3):
 points={tuple(round(v,6)for v in front['vertices'][j])for j in ts[i:i+3]};hits=[k for k,c in enumerate(components)if points&c[0]]
 if not hits:components.append((points,{i//3}))
 else:
  n=hits[0];components[n][0].update(points);components[n][1].add(i//3)
  for k in reversed(hits[1:]):components[n][0].update(components[k][0]);components[n][1].update(components[k][1]);components.pop(k)
lightning=next(c[1]for c in components if len(c[1])==20)
an={'vertices':[],'triangles':{str(k):[]for k in range(9)}}
for name in ['analyserBody','analyserFront']:
 d=geo[name];offset=len(an['vertices']);an['vertices'].extend([[p[k]*[2.25,1.35,1.15][k]*2.45*.66 for k in range(3)]for p in d['vertices']])
 for role,indices in d['triangles'].items():
  for i in range(0,len(indices),3):
   r=int(role)if name=='analyserBody'else 7 if int(role)==2 else 8 if i//3 in lightning else 5
   an['triangles'][str(r)].extend(offset+j for j in indices[i:i+3])
center=[sum(b)*.5 for b in bounds(an['vertices'])];an['vertices']=[rotate([p[k]-center[k]for k in range(3)],[-90,0,0])for p in an['vertices']];parts[3]=an
# Populate decorative fuses with matching production cartridges and caps.
fuse_center=[sum(pair)*.5 for pair in bounds([pv[i]for i,p in enumerate(pv)if group(p[0])==1])]
fuse=parts[1]
for name,role in [('fuseCartridge','15'),('fuseCaps','1')]:
 d=geo[name];offset=len(fuse['vertices'])
 for p in d['vertices']:
  q=[p[k]*[2.25,1.35,1.15][k]*2.45 for k in range(3)];q=add(rotate(q,[-15,0,0]),[-.049,.195,-.08]);fuse['vertices'].append([v*.66 for v in rotate([q[k]-fuse_center[k]for k in range(3)],[-75,0,0])])
 for indices in d['triangles'].values():fuse['triangles'].setdefault(role,[]).extend(offset+j for j in indices)
specs=[(0,r)for r in [0,1,2,3,4,1]]+[(1,r)for r in range(5)]+[(2,None),(3,None)]
# Broad and narrow types interleaved while falling, not separated by family.
order=[6,0,7,1,11,12,8,2,9,3,10,4,5];inputs=[]
for index in order:
 groupid,rating=specs[index];part=parts[groupid];tri={}
 for role,ts in part['triangles'].items():
  mapped=str(10+rating)if rating is not None and ((groupid==0 and role=='5')or(groupid==1 and role=='15'))else role
  tri.setdefault(mapped,[]).extend(ts)
 inputs.append({'name':['Breaker','FuseHolder','BatteryBackup','CableAnalyzer'][groupid]+str(index),'mesh':{'vertices':[[v*(.90 if groupid==3 else .99) for v in p]for p in part['vertices']],'triangles':tri},'metadata':{'type':groupid,'ratingKW':None if rating is None else [1,5,50,100,500][rating]}})
(root/'Art/ModuleKit/pile-input.json').write_text(json.dumps({'kind':'ModuleKit','seed':1317,'parts':inputs}))
print('Prepared 13 module parts with rating colours and matching decorative fuses.')
