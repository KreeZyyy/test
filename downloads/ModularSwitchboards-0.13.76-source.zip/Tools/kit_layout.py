"""Offline rigid layout helpers; conservative wall/corner and full OBB separation."""
import math,itertools
def rotate(p,angles):
 x,y,z=p;rx,ry,rz=[math.radians(a)for a in angles]
 y,z=y*math.cos(rx)-z*math.sin(rx),y*math.sin(rx)+z*math.cos(rx)
 x,z=x*math.cos(ry)+z*math.sin(ry),-x*math.sin(ry)+z*math.cos(ry)
 return [x*math.cos(rz)-y*math.sin(rz),x*math.sin(rz)+y*math.cos(rz),z]
def add(a,b):return [x+y for x,y in zip(a,b)]
def dot(a,b):return sum(x*y for x,y in zip(a,b))
def cross(a,b):return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]
def bounds(points):return [(min(p[k]for p in points),max(p[k]for p in points))for k in range(3)]
def obb(points,angles,shift):
 corners=[add(rotate(c,angles),shift)for c in itertools.product(*bounds(points))]
 axes=[rotate(v,angles)for v in [[1,0,0],[0,1,0],[0,0,1]]]
 return {'corners':corners,'axes':axes}
def separate(a,b,gap=.0015):
 axes=a['axes']+b['axes']+[cross(x,y)for x in a['axes']for y in b['axes']]
 for axis in axes:
  mag=math.sqrt(dot(axis,axis))
  if mag<1e-8:continue
  x=[dot(p,axis)/mag for p in a['corners']];y=[dot(p,axis)/mag for p in b['corners']]
  if max(x)+gap<=min(y)or max(y)+gap<=min(x):return True
 return False
def inside(points):
 # Safely inset from the crate's interior walls and its chamfered corners.
 return all(abs(p[0])<=.210 and abs(p[2])<=.210 and abs(p[0])+abs(p[2])<=.380 and p[1]>=.072 for p in points)


def clear_above_rim(body):
 # Convex OBB intersection with y<=rim: test corners plus edge/rim crossings.
 # This proves the below-rim part stays inside the conservative interior polygon.
 corners=body['corners'];rim=.370
 points=[p for p in corners if p[1]<=rim]
 for i,a in enumerate(corners):
  for j,b in enumerate(corners):
   if j<=i or bin(i^j).count('1')!=1:continue
   if (a[1]-rim)*(b[1]-rim)>=0:continue
   t=(rim-a[1])/(b[1]-a[1]);points.append([a[k]+t*(b[k]-a[k])for k in range(3)])
 if not inside(points):return False
 return all(abs(p[0])<=.310 and abs(p[2])<=.310 for p in corners)
