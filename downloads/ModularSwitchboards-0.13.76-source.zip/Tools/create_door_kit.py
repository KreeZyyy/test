"""Reuse the DIN crate shell and door-icon geometry, then settle visible contents."""
import bpy,json,math,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1];folder=root/'Art/DoorKit';folder.mkdir(exist_ok=True);(root/'Assets/DoorKit').mkdir(exist_ok=True)
script=(root/'Tools/render_door_icons.py').read_text();prefix=script[:script.index("names=(")];body=script[script.index(' bpy.ops.object.select_all',script.index('for name in names:')):script.index(' s=bpy.context.scene;')]
exec(prefix)
shell=json.loads((root/'Art/RailKit/source.json').read_text())['shell'];parts=[]
for name in ('DoorIsolator','DoorStop','DoorBridge','DoorRoundSwitch','DoorLed','DoorLedBlue','DoorLedWhite','DoorLedRed'):
 exec('\n'.join(line[1:] for line in body.splitlines()))
 v=[];ts={}
 for obj in list(bpy.context.scene.objects):
  if obj.type not in ('MESH','CURVE'):continue
  # Keep the decorative parts low-poly, like their in-game models.
  for modifier in list(obj.modifiers):obj.modifiers.remove(modifier)
  deps=bpy.context.evaluated_depsgraph_get();evaluated=obj.evaluated_get(deps);mesh=evaluated.to_mesh();mesh.calc_loop_triangles();offset=len(v)
  factor=1.25 if name=='DoorBridge' else 2.2
  for vertex in mesh.vertices:
   point=obj.matrix_world@vertex.co;v.append([point.x*factor,point.z*factor,-point.y*factor])
  rgb=tuple(obj.data.materials[0].diffuse_color[:3]);r,g,b=rgb
  role=0 if max(rgb)<.1 else 11 if r>.5 and g>.3 and b<.1 else 13 if r>g*2 and r>b*2 else 15 if b>r*2 and b>g*2 else 10 if g>r*2 and g>b*2 else 1 if min(rgb)>.75 else 4
  if name=='DoorIsolator' and 'grip' in obj.name:role=16
  for triangle in mesh.loop_triangles:ts.setdefault(str(role),[]).extend(offset+i for i in triangle.vertices)
  evaluated.to_mesh_clear()
 low=min(p[1] for p in v)
 for p in v:p[1]-=low
 for copy in range({'DoorLed':2,'DoorLedBlue':1,'DoorLedWhite':2,'DoorLedRed':1,'DoorRoundSwitch':6}.get(name,3)):parts.append({'name':name+str(copy),'mesh':{'vertices':v,'triangles':ts},'metadata':{'doorVariant':name}})
(folder/'source.json').write_text(json.dumps({'shell':shell,'contents':{'vertices':[],'triangles':{}}}))
(folder/'pile-input.json').write_text(json.dumps({'kind':'ModuleKit','seed':1363,'parts':parts}))
print('Door crate: reused shell; generated',len(parts),'decorative pieces from seven door variants.')
