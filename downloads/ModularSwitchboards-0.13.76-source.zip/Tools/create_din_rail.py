import bpy,json
from pathlib import Path
from mathutils import Vector
root=Path(__file__).resolve().parent.parent
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
metal=bpy.data.materials.new('GalvanizedSteel');metal.diffuse_color=(.34,.36,.38,1);metal.use_nodes=True
p=metal.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(.34,.36,.38,1);p.inputs['Metallic'].default_value=.2;p.inputs['Roughness'].default_value=.85
# Exported from the actual C# Build(.324f), so the icon has identical holes and profile.
geometry=json.loads((root/'Art/DinRail.previewmesh.json').read_text())
vertices=[(x,-z,y) for x,y,z in geometry['vertices']]
indices=geometry['triangles'];faces=[tuple(indices[i:i+3]) for i in range(0,len(indices),3)]
mesh=bpy.data.meshes.new('Perforated_TH35_15');mesh.from_pydata(vertices,[],faces);mesh.update()
rail=bpy.data.objects.new('DIN_Rail_Actual_Runtime_Geometry',mesh);bpy.context.collection.objects.link(rail);rail.data.materials.append(metal)
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=128;scene.cycles.use_denoising=False
scene.render.resolution_x=256;scene.render.resolution_y=256;scene.render.resolution_percentage=100;scene.render.film_transparent=True
scene.world.color=(.4,.4,.4)
scene.view_settings.exposure=-2
bpy.ops.object.camera_add(location=(.26,-.38,.28));camera=bpy.context.object;camera.rotation_euler=(Vector((0,0,0))-camera.location).to_track_quat('-Z','Y').to_euler();camera.data.type='ORTHO';camera.data.ortho_scale=.38;scene.camera=camera
for loc,power in [((.1,-.3,.4),40),((-.3,.1,.2),25)]:
 bpy.ops.object.light_add(type='AREA',location=loc);bpy.context.object.data.energy=power;bpy.context.object.data.size=.5
bpy.context.preferences.filepaths.save_version=0
bpy.ops.wm.save_as_mainfile(filepath=str(root/'Art/DinRail.blend'))
scene.render.filepath=str(root/'Assets/Icons/DinRail.png');bpy.ops.render.render(write_still=True)
