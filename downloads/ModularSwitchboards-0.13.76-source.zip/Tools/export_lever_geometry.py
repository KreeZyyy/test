"""Re-export the original APC lever topology for the catalog ON pose. Requires numpy.
Runtime ApcLeverGeometry still reads the installed game mesh and original textures.
"""
from pathlib import Path
import json,numpy as np
p=Path(__file__).resolve().parents[1]
a=json.loads((p/"Art/ApcLeverReference.json").read_text())
v=np.array([[v[k]for k in 'xyz']for v in a['vertices']]);t=np.array(a['surfaces'][0]['triangles']).reshape(-1,3);cs=np.cross(v[t[:,1]]-v[t[:,0]],v[t[:,2]]-v[t[:,0]]);face=cs[np.argmax((cs**2).sum(1))];face/=np.linalg.norm(face)
if face[2]<0:face=-face
right=np.array([1.,0,0])-face*face[0];right/=np.linalg.norm(right);up=np.cross(face,right);basis=np.array([right,up,face]);q=v@basis.T;pivot=np.array([.069,0,.18])@basis.T
low=q.min(0);high=q.max(0);fit=np.array([.012/(high[0]-low[0]),.021/max(abs(low[1]-pivot[1]),abs(high[1]-pivot[1])),.00125/max(abs(low[2]-pivot[2]),abs(high[2]-pivot[2]))]);q=(q-np.array([(low[0]+high[0])/2,pivot[1],pivot[2]]))*fit
(p/'Art/LeverIconGeometry.json').write_text(json.dumps({'vertices':q.tolist(),'triangles':{'0':t.flatten().tolist()},'provenance':'284 original APC vertices; original triangle topology; ApcLeverGeometry basis and FitFlap dimensions; reference spindle at APC-local (0.069,0,0.18). ON pose.'}))
