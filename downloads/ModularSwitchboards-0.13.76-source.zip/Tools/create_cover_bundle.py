"""Full-size cover stack with a fastener crate and straps around the complete bundle.
Usage: blender ... --python create_cover_bundle.py -- <crate-scale>
"""
import bpy,json,math,random,sys
from pathlib import Path
from mathutils import Matrix,Vector
r=Path(__file__).resolve().parents[1];rng=random.Random(1328)
args=sys.argv[sys.argv.index('--')+1:];scale=float(args[0])
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
cover=json.loads((r/'Art/CoverIconGeometry.json').read_text())
source=json.loads((r/'Art/ModuleKit/source.json').read_text())['shell']
shell=dict(source);shell['vertices']=[[p[0]*scale+.015,p[1]*scale+.016,p[2]*scale]for p in source['vertices']]
contents={'vertices':[],'triangles':{}}
def export(v,t,role):
 offset=len(contents['vertices']);contents['vertices'].extend([list(p)for p in v]);contents['triangles'].setdefault(str(role),[]).extend(offset+i for i in t)
def solid(name,position,size,role,rotation=None):
 bpy.ops.mesh.primitive_cube_add(size=1,location=position);o=bpy.context.object;o.name=name;o.dimensions=size
 bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
 if rotation is not None:o.rotation_euler=rotation
 mod=o.modifiers.new('Soft edges','BEVEL');mod.width=min(.0006,min(size)*.2);mod.segments=2;bpy.context.view_layer.objects.active=o;bpy.ops.object.modifier_apply(modifier=mod.name)
 o.data.calc_loop_triangles();export([o.matrix_world@v.co for v in o.data.vertices],[i for t in o.data.loop_triangles for i in t.vertices],role)
def cylinder(position,radius,depth,role,rotation):
 bpy.ops.mesh.primitive_cylinder_add(vertices=8,radius=radius,depth=depth,location=position,rotation=rotation);o=bpy.context.object;o.data.calc_loop_triangles()
 export([o.matrix_world@v.co for v in o.data.vertices],[i for t in o.data.loop_triangles for i in t.vertices],role)
for layer,degrees in enumerate([-3,2,-1,4,0]):
 rot=Matrix.Rotation(math.radians(degrees),3,'Y')
 pts=[rot@Vector((p[0],p[2]-.100499995,-p[1]))+Vector(((layer%3-1)*.002,layer*.0035,(layer%2)*.002))for p in cover['vertices']]
 export(pts,[i for ts in cover['triangles'].values()for i in ts],1)
# Screws lie in a compact staggered pile within the copied crate.
for layer in range(10):
 for row in range(4):
  for col in range(5):
   x=.015+((col-2)*.072+rng.uniform(-.006,.006))*scale
   z=((row-1.5)*.095+rng.uniform(-.008,.008))*scale
   y=.016+(.09436+layer*.025)*scale
   yaw=rng.uniform(-math.pi,math.pi);direction=Vector((math.cos(yaw),0,math.sin(yaw)))
   length=rng.uniform(.085,.120)*scale;radius=.009*scale
   rot=Vector((0,0,1)).rotation_difference(direction).to_euler()
   centre=Vector((x,y,z));cylinder(centre,radius,length,4,rot)
   head=centre+direction*(length*.5);cylinder(head,.021*scale,.010*scale,4,rot)
   # Recessed slot on the outward head face.
   end=head+direction*(.0053*scale)
   solid('Screw slot',end,(.002*scale,.026*scale,.003*scale),0,(0,-yaw,0))
# Actual mesh cross-section hull supplies taut straps over the open crate rim,
# around the entire five-panel stack, and back underneath.
def hull_at(x):
 points=[]
 for d in [shell,contents]:
  v=d['vertices']
  for ts in d['triangles'].values():
   for i in range(0,len(ts),3):
    tri=ts[i:i+3]
    for edge in range(3):
     a=v[tri[edge]];b=v[tri[(edge+1)%3]]
     if (a[0]<=x<=b[0]or b[0]<=x<=a[0])and abs(b[0]-a[0])>1e-9:
      f=(x-a[0])/(b[0]-a[0]);y=a[1]+(b[1]-a[1])*f;z=a[2]+(b[2]-a[2])*f
      points.extend((round(y+dy,8),round(z+dz,8))for dy in [-.0018,.0018]for dz in [-.0018,.0018])
 points=sorted(set(points))
 def turn(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
 lo=[]
 for p in points:
  while len(lo)>1 and turn(lo[-2],lo[-1],p)<=0:lo.pop()
  lo.append(p)
 hi=[]
 for p in reversed(points):
  while len(hi)>1 and turn(hi[-2],hi[-1],p)<=0:hi.pop()
  hi.append(p)
 return lo[:-1]+hi[:-1]
for x in [-.060,.090]:
 hull=hull_at(x)
 for a,b in zip(hull,hull[1:]+hull[:1]):
  dy=b[0]-a[0];dz=b[1]-a[1];length=math.hypot(dy,dz)
  if length<.00005:continue
  solid('Binding strap',(x,(a[0]+b[0])*.5,(a[1]+b[1])*.5),(.016,length,.002),4,(math.atan2(dz,dy),0,0))
out=r/'Art/CoverKit';out.mkdir(exist_ok=True)
(out/'source.json').write_text(json.dumps({'shell':shell,'contents':contents,'layout':{'cover_count':5,'cover_scale':1,'angles_degrees':[-3,2,-1,4,0],'crate_scale':scale,'screw_count':200,'binding_straps':2}}))
(out/'layout.json').write_text(json.dumps({'cover_count':5,'crate_scale':scale,'screw_count':200,'screw_layers':10,'seed':1328},indent=2))
print('Authored five full-size covers, crate scale',scale,'and 200 fasteners.')
