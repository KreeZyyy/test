"""Extract unchanged production control mesh methods into the geometry harness."""
from pathlib import Path
root=Path(__file__).resolve().parents[1]
def method(text,marker):
 start=text.index(marker);brace=text.index('{',start);depth=1;end=brace+1
 while depth:
  depth+=(text[end]=='{')-(text[end]=='}');end+=1
 return text[start:end]
control=method((root/'Source/DinBreakerModel.cs').read_text(),'internal static Mesh ControlMesh(')
box=method((root/'Source/DinRailModel.cs').read_text(),'internal static void AddBox(')
(root/'Verification/FuseGeometry/ControlExtracted.cs').write_text('using System.Collections.Generic;using UnityEngine;namespace ModularSwitchboards {static partial class DinBreakerModel{'+control+'}static class DinRailModel{'+box+'}}')
f=root/'Verification/FuseGeometry/Program.cs';s=f.read_text()
if 'Vector3 operator -(Vector3 a)' not in s:s=s.replace('public static Vector3 one=>','public static Vector3 operator -(Vector3 a)=>new(-a.x,-a.y,-a.z);public static Vector3 Scale(Vector3 a,Vector3 b)=>new(a.x*b.x,a.y*b.y,a.z*b.z);public static Vector3 one=>')
if 'SetTriangles(int[]' not in s:s=s.replace('public int subMeshCount;','public void RecalculateNormals(){}public void SetTriangles(int[] t,int sub)=>T[sub]=t;public int subMeshCount;')
if '["breakerIndicator"]' not in s:s=s.replace('["breakerBody"]=Geometry(DinBreakerModel.Build()),','["breakerBody"]=Geometry(DinBreakerModel.Build()),["breakerIndicator"]=Geometry(DinBreakerModel.ControlMesh("BreakerIndicator",new Vector3(0,.0245f,.0645f),new Vector3(.01f,.003f,.001f))),')
f.write_text(s)
