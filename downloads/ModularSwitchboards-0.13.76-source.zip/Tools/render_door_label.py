import bpy,json
from pathlib import Path
from mathutils import Vector
root=Path(__file__).resolve().parents[1];data=json.loads((root/'Art/DoorLabel.json').read_text())
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
def mat(name,color):
 m=bpy.data.materials.new(name);m.diffuse_color=(*color,1);m.use_nodes=True;m.node_tree.nodes['Principled BSDF'].inputs['Base Color'].default_value=(*color,1);m.node_tree.nodes['Principled BSDF'].inputs['Roughness'].default_value=.6;return m
black=mat('Holder',(.025,.025,.025));white=mat('Name insert',(.88,.88,.85))
for role,indices in data['triangles'].items():
 if not indices:continue
 mesh=bpy.data.meshes.new('Door label');mesh.from_pydata(data['vertices'],[],[indices[i:i+3] for i in range(0,len(indices),3)]);mesh.update();obj=bpy.data.objects.new('Door label',mesh);bpy.context.collection.objects.link(obj);mesh.materials.append(white if role=='1' else black)
bpy.ops.object.text_add(location=(0,.034,.0032));text=bpy.context.object;text.data.body='LABEL';text.data.align_x='CENTER';text.data.align_y='CENTER';text.data.size=.007;text.data.materials.append(black)
s=bpy.context.scene;s.render.engine='CYCLES';s.cycles.samples=32;s.cycles.use_denoising=False;s.render.resolution_x=s.render.resolution_y=256;s.render.resolution_percentage=100;s.render.film_transparent=True;s.world.color=(.3,.3,.3);s.view_settings.view_transform='Standard'
c=Vector((0,.015,0));bpy.ops.object.camera_add(location=(.06,-.025,.18));cam=bpy.context.object;cam.rotation_euler=(c-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=.092;s.camera=cam
bpy.ops.object.light_add(type='AREA',location=(-.1,.1,.2));bpy.context.object.data.energy=.45;bpy.context.object.data.size=.3
s.render.filepath=str(root/'Assets/Icons/DoorLabel.png');bpy.ops.render.render(write_still=True)
