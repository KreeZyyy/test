from pathlib import Path
import subprocess
p=Path(__file__).resolve().parents[1]
def method(text, marker):
 start=text.index(marker);brace=text.index('{',start);level=1;end=brace+1
 while level:
  if text[end]=='{':level+=1
  elif text[end]=='}':level-=1
  end+=1
 return text[start:end]
assert method((p/'Source/DinBreakerModel.cs').read_text(),'internal static Mesh Build(')==method((p/'Verification/FuseGeometry/BreakerBodyExtracted.cs').read_text(),'internal static Mesh Build('), 'Regenerate the production casing extraction before rendering icons.'
f=p/'Verification/FuseGeometry/Program.cs' ;s=f.read_text();marker=' static void Main(){'
block='''
 if(Environment.GetEnvironmentVariable("CATALOG_ICON_EXPORT")=="1"){
 object Geometry(Mesh mesh)=>new{vertices=mesh.V.Select(p=>new[]{p.x,p.y,p.z}),triangles=mesh.T};
 var pieces=new Dictionary<string,object>{["fuseBody"]=Geometry(DinFuseModel.Housing()),["fuseClamps"]=Geometry(DinFuseModel.Contacts()),["fuseCartridge"]=Geometry(DinFuseModel.Cartridge(false)),["fuseCaps"]=Geometry(DinFuseModel.Caps()),["batteryBody"]=Geometry(DinBatteryModel.Build()),["batteryBay"]=Geometry(BatterySocketModel.Build()),["analyserBody"]=Geometry(DinBreakerModel.Build(.0176f+2*.0405f/2.25f,.0405f/2.25f,plain:true))};
 using(var doc=JsonDocument.Parse(File.ReadAllText(Path.Combine(AppContext.BaseDirectory,"AnalyserFixture.json")))){
 var av=doc.RootElement.GetProperty("vertices").EnumerateArray().Select(v=>new Vector3(v.GetProperty("x").GetSingle(),v.GetProperty("y").GetSingle(),v.GetProperty("z").GetSingle())).ToArray();
 var groups=doc.RootElement.GetProperty("groups").EnumerateArray().Select(g=>g.EnumerateArray().Select(i=>i.GetInt32()).ToArray()).ToArray();
 pieces["analyserFront"]=new{vertices=av.Select(v=>new[]{.0405f/2.25f+(v.z+.000874f)*.398f/2.25f,(v.x-.002003f)*.398f/1.35f,.0645f+(v.y-.1674507f)*.398f/1.15f}),triangles=AnalyserFrontSelection.Select(av,groups).Select((t,i)=>(t,i)).ToDictionary(x=>x.i,x=>x.t)};
 }
 File.WriteAllText(Environment.GetEnvironmentVariable("CATALOG_ICON_PATH"),JsonSerializer.Serialize(pieces));
 }
'''
# Keep exporter in the verification harness so geometry comes from tested production builders.
if 'CATALOG_ICON_EXPORT' not in s:f.write_text(s.replace(marker,marker+block))
