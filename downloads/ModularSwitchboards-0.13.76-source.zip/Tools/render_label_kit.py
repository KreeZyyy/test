import bpy,json
from pathlib import Path
from mathutils import Vector
root=Path(__file__).resolve().parents[1];data=json.loads((root/'Art/LabelKit/model.json').read_text())
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
v=[(-p[0],-p[2],p[1])for p in data['vertices']];t=data['triangles']['0'];me=bpy.data.meshes.new('Switchboards.LabelKitModel');me.from_pydata(v,[],[tuple(reversed(t[i:i+3]))for i in range(0,len(t),3)]);me.update()
for poly in me.polygons:poly.use_smooth=True
me.normals_split_custom_set_from_vertices([(-n[0],-n[2],n[1])for n in data['normals']]);uv=me.uv_layers.new()
for loop in me.loops:uv.data[loop.index].uv=data['uv'][loop.vertex_index]
ob=bpy.data.objects.new('LabelKit',me);bpy.context.collection.objects.link(ob)
m=bpy.data.materials.new('Switchboards.ModuleKit.Material');m.use_nodes=True;n=m.node_tree.nodes.get('Principled BSDF');n.inputs['Roughness'].default_value=.5;tex=m.node_tree.nodes.new('ShaderNodeTexImage');tex.image=bpy.data.images.load(str(root/'Assets/ModuleKit/Surface.png'));m.node_tree.links.new(tex.outputs['Color'],n.inputs['Base Color']);me.materials.append(m)
lo=Vector([min(p[i]for p in v)for i in range(3)]);hi=Vector([max(p[i]for p in v)for i in range(3)]);c=(lo+hi)/2;size=hi-lo;scale=max(size.x,size.z,size.y*.65)*1.35
s=bpy.context.scene;s.render.engine='CYCLES';s.cycles.samples=64;s.cycles.use_denoising=False;s.render.resolution_x=256;s.render.resolution_y=256;s.render.resolution_percentage=100;s.render.film_transparent=True;s.world.color=(.2,.2,.2);s.view_settings.view_transform='Standard'
bpy.ops.object.camera_add(location=c+Vector((.48,-2.8,3.2))*scale);cam=bpy.context.object;cam.rotation_euler=(c-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=scale;s.camera=cam
for off,power in [((1,-3,4),240),((-3,-1,2),80)]:
 bpy.ops.object.light_add(type='AREA',location=c+Vector(off)*scale);l=bpy.context.object;l.data.energy=power*scale**2;l.data.size=5*scale;l.rotation_euler=(c-l.location).to_track_quat('-Z','Y').to_euler()
s.render.filepath=str(root/'Assets/Icons/KitLabels.png');bpy.ops.render.render(write_still=True)
