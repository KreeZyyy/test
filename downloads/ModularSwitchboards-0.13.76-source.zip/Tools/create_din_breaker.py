import bpy
from pathlib import Path
from mathutils import Vector
root=Path(__file__).resolve().parent.parent
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
materials=[]
for name,rgb in [('YellowFlap',(.95,.76,.04)),('White',(.75,.76,.78)),('Yellow',(.8,.65,.03)),('Black',(.025,.025,.03)),('Metal',(.45,.48,.51)),('Red',(.8,.025,.02))]:
 m=bpy.data.materials.new(name);m.diffuse_color=(*rgb,1);m.use_nodes=True;bs=m.node_tree.nodes.get('Principled BSDF');bs.inputs['Base Color'].default_value=(*rgb,1);bs.inputs['Roughness'].default_value=.5;materials.append(m)
def box(role,loc,size):
 bpy.ops.mesh.primitive_cube_add(size=1,location=(loc[0],-loc[2],loc[1]));o=bpy.context.object;o.dimensions=(size[0],size[2],size[1]);bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.append(materials[role])
 radius=min(.0018,min(size)*.4)
 if role==0:radius=.0015
 if role==4:radius=.0005
 if size==(.0176,.052,.008):radius=.0015
 if size==(.006,.001,.0005):radius=.00015
 bevel=o.modifiers.new('Rounded APC-style edges','BEVEL');bevel.width=radius;bevel.segments=3
 bpy.context.view_layer.objects.active=o;bpy.ops.object.modifier_apply(modifier=bevel.name)
 for poly in o.data.polygons:poly.use_smooth=True
 normal=o.modifiers.new('Weighted corner normals','WEIGHTED_NORMAL');bpy.ops.object.modifier_apply(modifier=normal.name)
 return o
box(1,(0,0,.029),(.0176,.075,.056))
box(1,(0,0,.059),(.0176,.052,.008))
box(3,(0,0,.0635),(.013,.045,.001))
# Current OFF flap: native-style flat plate, its own yellow spindle and grey bearings.
box(0,(0,-.0105,.0675),(.012,.021,.0025))
box(3,(0,-.003,.0689),(.007,.0018,.0003))
import math
bpy.ops.mesh.primitive_cylinder_add(vertices=32,radius=.0011,depth=.012,location=(0,-.0675,0),rotation=(0,math.pi/2,0))
axle=bpy.context.object;axle.name='Yellow_Flap_Spindle';axle.data.materials.append(materials[0])
for poly in axle.data.polygons:poly.use_smooth=True
for side in [-1,1]:
 box(4,(side*.0073,0,.0667),(.0022,.0042,.0048))
bpy.ops.object.text_add(location=(0,-.0689,-.015),rotation=(math.pi/2,0,0))
text=bpy.context.object;text.name='NativeStyle_OFF_Reference';text.data.body='OFF';text.data.align_x='CENTER';text.data.align_y='CENTER';text.data.size=.0035;text.data.materials.append(materials[1])
box(5,(0,.0245,.0645),(.01,.003,.001))
for side in [-1,1]:
 box(4,(0,side*.03,.0577),(.009,.009,.0015))
 box(3,(0,side*.03,.0586),(.006,.001,.0005))
for obj in bpy.context.scene.objects:
 if obj.type in {'MESH','FONT'} and obj.parent is None: obj.scale=(2.25,1.15,1.35);obj.location.x*=2.25;obj.location.y*=1.15;obj.location.z*=1.35
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=128;scene.cycles.use_denoising=False
scene.render.resolution_x=256;scene.render.resolution_y=256;scene.render.resolution_percentage=100;scene.render.film_transparent=True
scene.world.color=(.4,.4,.4)
scene.view_settings.exposure=-1.5
bpy.ops.object.camera_add(location=(.10,-.25,.14));camera=bpy.context.object;camera.rotation_euler=(Vector((0,-.03,0))-camera.location).to_track_quat('-Z','Y').to_euler();camera.data.type='ORTHO';camera.data.ortho_scale=.15;scene.camera=camera
for loc,power in [((.1,-.3,.4),40),((-.3,.1,.2),25)]:
 bpy.ops.object.light_add(type='AREA',location=loc);bpy.context.object.data.energy=power;bpy.context.object.data.size=.5
bpy.context.preferences.filepaths.save_version=0
bpy.ops.wm.save_as_mainfile(filepath=str(root/'Art/DinBreaker.blend'))
scene.render.filepath=str(root/'Assets/Icons/DinBreaker.png');bpy.ops.render.render(write_still=True)
