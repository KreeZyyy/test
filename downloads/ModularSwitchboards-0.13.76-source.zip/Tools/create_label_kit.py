"""Same DIN crate with supported, scattered blank label plates in three widths."""
from pathlib import Path
import json,random,subprocess,sys
root=Path(__file__).resolve().parents[1];folder=root/'Art/LabelKit';folder.mkdir(exist_ok=True)
shell=json.loads((root/'Art/RailKit/source.json').read_text())['shell']
parts=[];widths=[.10,.18,.26]*12;random.Random(1335).shuffle(widths)
for i,width in enumerate(widths):
 v=[];ts={}
 def quad(role,a,b,c,d):
  j=len(v);v.extend([a,b,c,d]);ts.setdefault(str(role),[]).extend([j,j+1,j+2,j,j+2,j+3])
 def box(role,x0,x1,y0,y1,z0,z1):
  quad(role,[x0,y0,z0],[x0,y0,z1],[x0,y1,z1],[x0,y1,z0]);quad(role,[x1,y0,z1],[x1,y0,z0],[x1,y1,z0],[x1,y1,z1]);quad(role,[x0,y0,z1],[x0,y0,z0],[x1,y0,z0],[x1,y0,z1]);quad(role,[x0,y1,z0],[x0,y1,z1],[x1,y1,z1],[x1,y1,z0]);quad(role,[x1,y0,z0],[x0,y0,z0],[x0,y1,z0],[x1,y1,z0]);quad(role,[x0,y0,z1],[x1,y0,z1],[x1,y1,z1],[x0,y1,z1])
 box(0,-width/2,width/2,0,.015,-.034,.034);box(1,-width/2+.003,width/2-.003,.015,.016,-.030,.030)
 parts.append({'name':'Label'+str(i),'mesh':{'vertices':v,'triangles':ts},'metadata':{'width':width}})
# Actual mounted holder and emergency ring meshes, laid face-up in the crate.
for variant,scale,copies in [('DoorLabel',2.0,8),('EmergencyStopLabel',1.5,8)]:
 data=json.loads((root/'Art'/f'{variant}.json').read_text())
 vertices=[[v[0]*scale,v[2]*scale,-v[1]*scale]for v in data['vertices']]
 low=min(v[1]for v in vertices)
 for v in vertices:v[1]-=low
 triangles={}
 for role,indices in data['triangles'].items():
  if indices:triangles.setdefault('11' if variant=='EmergencyStopLabel' else role,[]).extend(indices)
 for copy in range(copies):parts.append({'name':variant+str(copy),'mesh':{'vertices':vertices,'triangles':triangles},'metadata':{'labelVariant':variant}})
(folder/'source.json').write_text(json.dumps({'shell':shell,'contents':{'vertices':[],'triangles':{}}}));(folder/'pile-input.json').write_text(json.dumps({'kind':'LabelKit','seed':1335,'parts':parts}))
def blender(script,*args):subprocess.run(['blender','-b','-t','2','--python-exit-code','1','--python',str(root/'Tools'/script),'--',*map(str,args)],check=True)
blender('settle_kit.py',folder/'pile-input.json',folder/'pile-settled.json');blender('check_settled_support.py',folder/'pile-settled.json',folder/'support-audit.json');subprocess.run([sys.executable,str(root/'Tools/bake_kit_contents.py'),'LabelKit'],check=True);blender('render_label_kit.py')
