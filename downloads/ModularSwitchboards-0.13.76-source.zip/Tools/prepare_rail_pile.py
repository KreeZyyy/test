"""Same preserved crate as the module kit; original perforated DIN rail contents.
Decorative bundles of four different lengths. Run before render_rail_kit.py.
"""
from pathlib import Path
import json,subprocess,sys,math,random
from kit_layout import rotate,add,bounds,obb,separate,inside,clear_above_rim
root=Path(__file__).resolve().parents[1]
shell=json.loads((root/'Art/ModuleKit/source.json').read_text())['shell']
v=[];tri=[]
def quad(a,b,c,d):
 i=len(v);v.extend([a,b,c,d]);tri.extend([i,i+1,i+2,i,i+2,i+3])
def box(x0,x1,y0,y1,z0,z1):
 if x1-x0<1e-8 or y1-y0<1e-8 or z1-z0<1e-8:return
 quad([x0,y0,z0],[x0,y0,z1],[x0,y1,z1],[x0,y1,z0])
 quad([x1,y0,z1],[x1,y0,z0],[x1,y1,z0],[x1,y1,z1])
 quad([x0,y0,z1],[x0,y0,z0],[x1,y0,z0],[x1,y0,z1])
 quad([x0,y1,z0],[x0,y1,z1],[x1,y1,z1],[x1,y1,z0])
 quad([x1,y0,z0],[x0,y0,z0],[x0,y1,z0],[x1,y1,z0])
 quad([x0,y0,z1],[x1,y0,z1],[x1,y1,z1],[x0,y1,z1])
def rail(length,y,z):
 left=-.215;right=left+length
 # A thin perforated web, upright sides and outward lips: open TH35 section.
 slots=max(2,round(length/.060));pitch=length/slots;edge=left
 for i in range(slots):
  center=left+(i+.5)*pitch;a=center-.011;b=center+.011
  box(edge,a,y,y+.002,z-.018,z+.018)
  box(a,b,y,y+.002,z-.018,z-.004)
  box(a,b,y,y+.002,z+.004,z+.018)
  edge=b
 box(edge,right,y,y+.002,z-.018,z+.018)
 for side in [-1,1]:
  c=z+side*.019
  box(left,right,y,y+.027,c-.001,c+.001)
  c=z+side*.024
  box(left,right,y+.025,y+.027,c-.006,c+.006)
lengths=[.430,.200,.350,.275]*6;random.Random(1317).shuffle(lengths);parts=[]
for i,length in enumerate(lengths):
 v=[];tri=[];rail(length,0,0);pivot=-.215+length/2
 parts.append({'name':'Rail'+str(i),'length':length,'mesh':{'vertices':[[p[0]-pivot,p[1],p[2]]for p in v],'triangles':{'4':tri}},'metadata':{'length':length}})
(root/'Art/RailKit/pile-input.json').write_text(json.dumps({'kind':'RailKit','seed':1317,'parts':parts}))
print('Prepared 24 mixed-length rail parts.')
