using Assets.Scripts;
using Assets.Scripts.GridSystem;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class DinFuseSparks
    {
        internal static void Emit(DinBreaker module)
        {
            if(!module.IsFuseHolder||GameManager.GameState!=GameState.Running||GameManager.IsBatchMode)return;
            var cabinet=CabinetWiring.CabinetOf(module);
            if(cabinet==null||!cabinet.IsOpen)return;
            var world=WorldManager.Instance;
            if(world==null||world.Sparker==null)return;
            var model=module.transform.Find("DinBreakerModel");
            // Centre of the actual cartridge, including board rotation and visual scale.
            var position=model!=null?model.TransformPoint(new Vector3(0,0,.046f)):module.ThingTransformPosition;
            var emit=new ParticleSystem.EmitParams{position=position};
            // Exact shared native emitter/count used by CableRuptured.Awake.
            world.Sparker.Emit(emit,100);
        }
    }
}
