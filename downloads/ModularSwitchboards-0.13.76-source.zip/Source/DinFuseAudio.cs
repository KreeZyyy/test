using Assets.Scripts;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Objects.Electrical;
using Assets.Scripts.Sound;
using Assets.Scripts.Util;
namespace ModularSwitchboards
{
    internal static class DinFuseAudio
    {
        internal static void Play(DinBreaker module)
        {
            // Same local playback path as vanilla CableRuptured.Awake.
            // Trip is drained on the main thread by the cabinet's LateUpdate.
            if(!module.IsFuseHolder||GameManager.GameState!=GameState.Running||GameManager.IsBatchMode)return;
            DinFuseSparks.Emit(module);
            var audio=Singleton<AudioManager>.Instance;
            if(audio!=null)audio.PlayAudioClipsData(CableRuptured.CableSparkHash,module.ThingTransformPosition);
        }
    }
}
