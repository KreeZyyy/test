using System.Collections.Generic;
using Assets.Scripts.GridSystem;
namespace ModularSwitchboards
{
    internal static class MountSnap
    {
        // Candidate geometry/support is separate from occupancy: never skip a
        // nearest occupied cell to show a farther green one.
        internal static bool TryNearest(Grid3 raw,IEnumerable<Grid3> candidates,out Grid3 result)
        {
            result=raw;bool found=false;double best=double.MaxValue;
            foreach(var p in candidates)
            {
                double x=(double)p.x-raw.x,y=(double)p.y-raw.y,z=(double)p.z-raw.z;
                double distance=x*x+y*y+z*z;
                if(!found||distance<best){found=true;best=distance;result=p;}
            }
            return found;
        }
    }
}
