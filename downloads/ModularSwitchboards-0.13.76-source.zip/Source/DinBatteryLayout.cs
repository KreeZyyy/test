namespace ModularSwitchboards
{
    internal static class DinBatteryLayout
    {
        internal const int Slots=2;
        internal static float CenterX=>DinLayout.SlotPitch*(Slots-1)*.5f/DinBreakerModel.VisualScale.x;
        internal static float Width=>.0176f+(Slots-1)*DinLayout.SlotPitch/DinBreakerModel.VisualScale.x;
    }
}
