using System;
using System.Collections.Generic;
using System.Linq;
using Assets.Scripts;
using Assets.Scripts.Objects.Electrical;
using UnityEngine;

namespace ModularSwitchboards
{
    internal static class NativeRearBox
    {
        private const string RootName = "NativeApcRearBox";
        // Native export: central cover, warning and bolts fit inside +/-125 mm.
        // Cable lugs are at about +/-250 mm and are deliberately excluded.
        private const float NativeMountPlane = .043764770f;
        private static Mesh cached;
        private static MeshRenderer sourceRenderer;

        internal static void Install(SwitchboardCabinet cabinet)
        {
            try
            {
                if(cached==null) Capture();
                var root=new GameObject(RootName){layer=cabinet.gameObject.layer};
                root.transform.SetParent(cabinet.transform.Find("SwitchboardModel/CompletedShell"),false);
                root.transform.localPosition=new Vector3(0,0,-CabinetRearDepth.NominalDepth-NativeMountPlane);
                root.AddComponent<MeshFilter>().sharedMesh=cached;
                var renderer=root.AddComponent<MeshRenderer>();
                NativePortSurface.Capture(sourceRenderer,renderer);
                renderer.lightProbeUsage=sourceRenderer.lightProbeUsage;
                renderer.reflectionProbeUsage=sourceRenderer.reflectionProbeUsage;
                renderer.shadowCastingMode=sourceRenderer.shadowCastingMode;
                renderer.receiveShadows=sourceRenderer.receiveShadows;
                var collider=root.AddComponent<MeshCollider>();collider.sharedMesh=cached;
                cabinet.BuildStates[1].Colliders.Add(collider);
                CabinetModel.SetBounds(cabinet);
                Debug.Log("[Modular Switchboards] Native rear APC box installed: original size, UV warning, bolts and materials; no cable connectors.");
            }
            catch(Exception ex)
            {
                Debug.LogError("[Modular Switchboards] Native rear APC box unavailable; cabinet preserved: "+ex);
            }
        }

        private static void Capture()
        {
            var apc=WorldManager.Instance.SourcePrefabs.OfType<AreaPowerControl>()
                .First(p=>p.PrefabName=="StructureAreaPowerControl");
            sourceRenderer=apc.GetComponentsInChildren<MeshRenderer>(true).First(r=>r.name==apc.PrefabName);
            var original=sourceRenderer.GetComponent<MeshFilter>().sharedMesh;
            CabinetGeometry.ReadNativeMesh(original,out var points,out var uv,out var groups);
            var matrix=Matrix4x4.Rotate(CabinetModel.FrontSign<0f?Quaternion.Euler(0,180f,0):Quaternion.identity)
                * apc.transform.worldToLocalMatrix * sourceRenderer.transform.localToWorldMatrix;
            for(int i=0;i<points.Length;i++)points[i]=matrix.MultiplyPoint3x4(points[i]);
            var remap=new Dictionary<int,int>();var vertices=new List<Vector3>();var texcoords=new List<Vector2>();
            var triangles=new List<int>[groups.Length];
            for(int s=0;s<groups.Length;s++)
            {
                triangles[s]=new List<int>();
                for(int i=0;i<groups[s].Length;i+=3)
                {
                    int a=groups[s][i],b=groups[s][i+1],c=groups[s][i+2];
                    if(!Inside(points[a])||!Inside(points[b])||!Inside(points[c]))continue;
                    // Keep the bolted cover, warning and bolts. The underlying
                    // base body is now generated continuously with the tunnel.
                    if(points[a].z>-.04764f || points[b].z>-.04764f || points[c].z>-.04764f)continue;
                    foreach(int old in new[]{a,b,c})
                    {
                        if(!remap.TryGetValue(old,out var index))
                        {
                            index=vertices.Count;remap.Add(old,index);vertices.Add(points[old]);texcoords.Add(uv[old]);
                        }
                        triangles[s].Add(index);
                    }
                }
            }
            if(vertices.Count<100)throw new InvalidOperationException("Native rear box selection unexpectedly empty");
            // No old body or side socket caps: replaced by the integrated body.
            var mesh=new Mesh{name="Switchboards.NativeApcRearBox"};mesh.SetVertices(vertices);mesh.SetUVs(0,texcoords);mesh.subMeshCount=groups.Length;
            for(int s=0;s<groups.Length;s++)mesh.SetTriangles(triangles[s],s);
            mesh.RecalculateNormals();mesh.RecalculateTangents();mesh.RecalculateBounds();
            if(mesh.bounds.size.x>.251f||mesh.bounds.size.y>.251f||mesh.bounds.max.z>.04378f)
                throw new InvalidOperationException("Native rear box selection includes unrelated geometry");
            cached=mesh;
        }

        private static bool Inside(Vector3 p)
        {
            return Mathf.Abs(p.x)<=.125f && Mathf.Abs(p.y)<=.125f && p.z<=.04378f && p.z>=-.060f;
        }

        internal static Bounds BodyBounds(Assets.Scripts.Objects.Structure cabinet)
        {
            var root=cabinet.transform.Find("SwitchboardModel/CompletedShell/"+RootName);
            var shell=root.parent;
            var native=new Bounds(new Vector3(0,0,(-.04764769f+.04376477f)*.5f),new Vector3(.24f,.24f,.09141246f));
            return CabinetWallMount.TransformedBounds(native,shell.worldToLocalMatrix*root.localToWorldMatrix);
        }

        internal static void IncludeBounds(Assets.Scripts.Objects.Structure cabinet,ref Bounds bounds)
        {
            var root=cabinet.transform.Find("SwitchboardModel/CompletedShell/"+RootName);
            var mesh=root==null?null:root.GetComponent<MeshFilter>()?.sharedMesh;
            if(mesh!=null)bounds.Encapsulate(CabinetWallMount.TransformedBounds(mesh.bounds,
                cabinet.transform.worldToLocalMatrix*root.localToWorldMatrix));
        }
    }
}
