using System;
using System.Collections.Generic;
using System.Linq;
namespace ModularSwitchboards
{
    internal static class InnerCoverLayout
    {
        // Cabinet-local: below the DIN front (.1056), above terminal screw heads (.0997).
        // Internal wire renderers/colliders are disabled while the cover is fitted.
        internal const float HalfWidth=.193f,HalfHeight=.243f,Plane=.1015f,Thickness=.002f;
        // Each cabinet supplies its own dimensions. Module coordinates determine
        // openings directly: no fixed row count, row pitch or slot count here.
        internal readonly struct Panel
        {
            internal readonly float Width,Height,Depth,Sheet;
            internal Panel(float width,float height,float depth,float sheet)
            {
                if(float.IsNaN(width)||float.IsInfinity(width)||width<=0||float.IsNaN(height)||float.IsInfinity(height)||height<=0||
                   float.IsNaN(depth)||float.IsInfinity(depth)||float.IsNaN(sheet)||float.IsInfinity(sheet)||sheet<=0)
                    throw new ArgumentOutOfRangeException("Invalid inner cover dimensions.");
                Width=width;Height=height;Depth=depth;Sheet=sheet;
            }
            internal string Signature=>string.Join(":",new[]{Width,Height,Depth,Sheet}.Select(v=>v.ToString("R",System.Globalization.CultureInfo.InvariantCulture)));
        }
        internal static Panel Small=>new Panel(HalfWidth*2,HalfHeight*2,Plane,Thickness);
        internal struct Cell
        {
            internal float Left,Right,Bottom,Top;
            internal bool West,East,South,North;
        }
        internal static WireRect Window(float centerX,float centerY,int slots,bool battery)
        {
            float half=(DinLayout.ModuleHalfWidth*2+(slots-1)*DinLayout.SlotPitch+.0006f)*.5f;
            // Expose the complete coloured front shoulder, leaving terminal heads covered.
            float height=.052f*1.35f*.5f+.0005f;
            return new WireRect(centerX-half,centerX+half,centerY-height,centerY+height);
        }
        internal static List<Cell> Cells(IEnumerable<WireRect> windows)=>Cells(windows,Small);
        internal static List<Cell> Cells(IEnumerable<WireRect> windows,Panel panel)
        {
            float HalfWidth=panel.Width*.5f,HalfHeight=panel.Height*.5f;
            var holes=windows.Select(w=>new WireRect(Math.Max(-HalfWidth,(float)Math.Round(w.Left,6)),Math.Min(HalfWidth,(float)Math.Round(w.Right,6)),Math.Max(-HalfHeight,(float)Math.Round(w.Bottom,6)),Math.Min(HalfHeight,(float)Math.Round(w.Top,6))))
                .Where(w=>w.Left<w.Right&&w.Bottom<w.Top).ToArray();
            var xs=new SortedSet<float>{-HalfWidth,HalfWidth};var ys=new SortedSet<float>{-HalfHeight,HalfHeight};
            foreach(var w in holes){xs.Add(w.Left);xs.Add(w.Right);ys.Add(w.Bottom);ys.Add(w.Top);}
            var x=xs.ToArray();var y=ys.ToArray();var filled=new bool[x.Length-1,y.Length-1];
            for(int i=0;i<x.Length-1;i++)for(int j=0;j<y.Length-1;j++)
                filled[i,j]=!holes.Any(w=>(x[i]+x[i+1])*.5f>w.Left&&(x[i]+x[i+1])*.5f<w.Right&&(y[j]+y[j+1])*.5f>w.Bottom&&(y[j]+y[j+1])*.5f<w.Top);
            var cells=new List<Cell>();
            for(int i=0;i<x.Length-1;i++)for(int j=0;j<y.Length-1;j++)if(filled[i,j])
                cells.Add(new Cell{Left=x[i],Right=x[i+1],Bottom=y[j],Top=y[j+1],West=i==0||!filled[i-1,j],East=i==x.Length-2||!filled[i+1,j],South=j==0||!filled[i,j-1],North=j==y.Length-2||!filled[i,j+1]});
            return cells;
        }
    }
}
