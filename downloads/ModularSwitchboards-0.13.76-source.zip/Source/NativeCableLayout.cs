using System;
using System.Linq;
using System.Collections.Generic;
using Assets.Scripts;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Electrical;
using Assets.Scripts.Util;
using UnityEngine;

namespace ModularSwitchboards
{
    internal static class NativeCableLayout
    {
        private static readonly HashSet<string> LoggedTemplates=new HashSet<string>();
        internal struct Socket
        {
            internal Vector3 Point,Forward,ContactPoint;
            internal Grid3 CableCell,BodyCell;
        }
        internal static Socket Read(Vector3 cableCell,Vector3 outward)
        {
            var cables=WorldManager.Instance.SourcePrefabs.OfType<Cable>()
                .Where(c=>c.CableType!=Cable.Type.superHeavy && c.OpenEnds!=null && c.OpenEnds.Count==2 && c.OpenEnds.All(e=>e?.Transform!=null) && c.OpenEnds.Any(e=>(e.ConnectionType&NetworkType.Power)!=0) &&
                    (c.IsStraight || (c.PrefabName!=null && c.PrefabName.IndexOf("Straight",StringComparison.OrdinalIgnoreCase)>=0)))
                .GroupBy(c=>c.CableType).Select(group=>group.OrderBy(c=>c.StraightUnitLength<=0?int.MaxValue:c.StraightUnitLength).ThenBy(c=>c.PrefabName,StringComparer.Ordinal).First()).ToArray();
            if(cables.Length==0)throw new InvalidOperationException("Native straight cable prefab unavailable");
            Socket? result=null;
            foreach(var cable in cables)
            {
                var socket=Read(cable,cableCell,outward);
                if(result.HasValue && (result.Value.CableCell!=socket.CableCell || result.Value.BodyCell!=socket.BodyCell))
                    throw new InvalidOperationException("Native straight cable variants use different socket grids: "+cable.PrefabName);
                result=socket;
            }
            return result.Value;
        }
        // Place a reciprocal native socket relative to an explicit device body cell.
        // Source prefab pivots are not guaranteed to coincide with that cell.
        internal static Socket ReadForBody(Vector3 deviceBodyCell,Vector3 outward)
        {
            var socket=Read(deviceBodyCell+outward*SmallGrid.SmallGridSize,outward);
            var body=deviceBodyCell.ToGrid(SmallGrid.SmallGridSize,SmallGrid.SmallGridOffset);
            var shift=body.ToVector3()-socket.BodyCell.ToVector3();
            socket.Point+=shift;
            socket.CableCell=socket.Point.ToGrid(SmallGrid.SmallGridSize,SmallGrid.SmallGridOffset);
            socket.BodyCell=body;
            if(Vector3.Dot(socket.Forward,-outward)<.99f)
                throw new InvalidOperationException("Native socket faces away from the intended device body cell.");
            // The mouth sits on the shared face between the cable and body cells.
            // A Connection.Transform may identify a cell centre, not the visible end.
            socket.ContactPoint=(socket.Point+body.ToVector3())*.5f;
            return socket;
        }

        internal static Socket Read(Cable cable,Vector3 cableCell,Vector3 outward)
        {
            var ends=cable.OpenEnds.Select(c=>new {
                Point=cable.transform.InverseTransformPoint(c.Transform.position),
                Forward=cable.transform.InverseTransformDirection(c.Transform.forward)}).ToArray();
            if(LoggedTemplates.Add(cable.PrefabName))Debug.Log("[Modular Switchboards] Native cable graph "+cable.PrefabName+"; type="+cable.CableType+"; length="+cable.StraightUnitLength+"; end0="+ends[0].Point+" axis0="+ends[0].Forward+"; end1="+ends[1].Point+" axis1="+ends[1].Forward);
            var axis=ends[1].Point-ends[0].Point;
            if(axis.sqrMagnitude<.0001f)axis=ends[0].Forward;
            axis.Normalize();
            // Preserve the cable mesh's thin wall-facing axis while turning its length.
            var normal=new[]{Vector3.right,Vector3.up,Vector3.forward}
                .Where(a=>Math.Abs(Vector3.Dot(a,axis))<.01f)
                .OrderBy(a=>Math.Abs(a.x)*cable.Bounds.size.x+Math.Abs(a.y)*cable.Bounds.size.y+Math.Abs(a.z)*cable.Bounds.size.z).First();
            var rotation=Quaternion.LookRotation(outward,Vector3.forward)*Quaternion.Inverse(Quaternion.LookRotation(axis,normal));
            var inward=ends.Select(e=>new{Point=rotation*e.Point,Forward=rotation*e.Forward})
                .OrderBy(e=>Vector3.Dot(e.Point,outward)).ThenByDescending(e=>Vector3.Dot(e.Forward,outward)).First();
            var body=(cableCell+inward.Point).ToGrid(SmallGrid.SmallGridSize,SmallGrid.SmallGridOffset);
            var local=(cableCell+inward.Point+inward.Forward*SmallGrid.SmallGridSize).ToGrid(SmallGrid.SmallGridSize,SmallGrid.SmallGridOffset);
            var direction=(body.ToVector3()-local.ToVector3());
            if(Math.Abs(direction.magnitude-SmallGrid.SmallGridSize)>.001f || Vector3.Dot(direction.normalized,-inward.Forward)<.99f)
                throw new InvalidOperationException("Native cable end does not form a reciprocal socket: "+cable.PrefabName);
            return new Socket{Point=local.ToVector3(),Forward=direction.normalized,ContactPoint=cableCell+inward.Point,CableCell=local,BodyCell=body};
        }
    }
}
