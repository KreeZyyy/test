using System;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using LibConstruct;
using UnityEngine;

namespace ModularSwitchboards
{
    internal static class LibConstructDependency
    {
        // Keep API resolution in a separate method so missing dependencies produce
        // a useful message rather than preventing the entry point from being JITted.
        internal static void Validate()
        {
            try { ValidateApi(); }
            catch (Exception ex)
            {
                throw new InvalidOperationException(
                    "Enable LibConstructReloaded (Workshop 3751750326) before Modular Switchboards. " +
                    "Use its LibConstruct.dll; do not install a second copy in this mod.", ex);
            }
        }

        [MethodImpl(MethodImplOptions.NoInlining)]
        private static void ValidateApi()
        {
            var assembly = typeof(PlacementBoard).Assembly;
            if (AppDomain.CurrentDomain.GetAssemblies().Count(a =>
                a.GetName().Name == assembly.GetName().Name) != 1)
                throw new InvalidOperationException("Multiple LibConstruct assemblies are loaded.");
            if (!typeof(IPlacementBoardHost).IsInterface ||
                !typeof(IPlacementBoardStructure).IsInterface ||
                typeof(BoardHostHooks).GetMethod("OnFinishedLoadBoard") == null)
                throw new InvalidOperationException("Unsupported LibConstruct board API.");
            Debug.Log("[Modular Switchboards] LibConstruct API resolved: " + assembly.FullName);
        }

        internal static void RequireInitialized()
        {
            var assembly = AppDomain.CurrentDomain.GetAssemblies().SingleOrDefault(a =>
                a.GetName().Name == "LibConstruct");
            var entry = assembly?.GetType("LibConstruct.LibConstructMod");
            if (entry?.GetField("MOD", BindingFlags.Public | BindingFlags.Static)?.GetValue(null) == null)
                throw new InvalidOperationException("LibConstruct has not initialized. Load LibConstructReloaded before Modular Switchboards.");
        }
    }
}
