using Assets.Scripts;
using Assets.Scripts.Objects;
namespace ModularSwitchboards
{
    internal static class ModuleDismantle
    {
        internal static bool CanRefund(DinBreaker module)
            =>CabinetWiring.CabinetOf(module)?.Wiring.HasWires(module.ReferenceId)!=true||Prefab.Find<Item>("ItemCableCoil")!=null;
        // Native Structure calls this only after the actual deconstruction tool
        // succeeds. Hover/preview/cancel and damage do not refund any cables.
        internal static void Refund(Structure __instance,ConstructionEventInstance __0,bool __1)
        {
            if(!GameManager.RunSimulation||__1||!(__instance is DinBreaker module))return;
            CabinetWiring.CabinetOf(module)?.Wiring.RefundAndRemoveBreaker(module.ReferenceId,__0.Position,__0.OtherHandSlot);
        }
    }
}
