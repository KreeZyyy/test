using System;
using Assets.Scripts.Objects.Motherboards;

namespace ModularSwitchboards
{
    internal static class DinModuleColours
    {
        // ColorType is byte-backed in Stationeers. Never unbox Enum.Parse to int.
        internal static int Index(float watts)
        {
            switch(DinModuleCatalog.Colour(watts))
            {
                case "Green":return (int)ColorType.Green;
                case "Yellow":return (int)ColorType.Yellow;
                case "Orange":return (int)ColorType.Orange;
                case "Red":return (int)ColorType.Red;
                case "Purple":return (int)ColorType.Purple;
                default:throw new InvalidOperationException("Unknown DIN module colour.");
            }
        }
    }
}
