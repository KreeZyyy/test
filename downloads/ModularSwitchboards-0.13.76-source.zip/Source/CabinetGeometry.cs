using System;
using System.IO;
using Assets.Scripts;
using Assets.Scripts.Objects.Motherboards;
using UnityEngine;
using UnityEngine.Rendering;

namespace ModularSwitchboards
{
    internal static class CabinetGeometry
    {
        internal static Mesh[] Meshes;
        internal static Material[] Materials;
        internal static int[] PaletteIndices;
        internal const int PaintableMaterialIndex = 0;

        private static Vector2 panelUv = new Vector2(.5f,.5f);
        private static Vector2 panelEdgeA, panelEdgeB;

        internal static void MapFromApc(Assets.Scripts.Objects.Electrical.AreaPowerControl apc)
        {
            if (apc == null) throw new InvalidOperationException("APC prefab unavailable for material mapping.");
            float largest = 0f;
            foreach (var renderer in apc.GetComponentsInChildren<MeshRenderer>(true))
            {
                var filter = renderer.GetComponent<MeshFilter>();
                if (filter == null || filter.sharedMesh == null) continue;
                var mesh = filter.sharedMesh;
                Vector3[] vertices; Vector2[] uv; int[][] subTriangles;
                try { ReadNativeMesh(mesh, out vertices, out uv, out subTriangles); }
                catch (Exception ex) { Debug.LogWarning("[Modular Switchboards] APC UV read: " + ex.Message); continue; }
                if (uv.Length != vertices.Length) continue;
                var materials = renderer.sharedMaterials;
                for (int sub = 0; sub < mesh.subMeshCount && sub < materials.Length; sub++)
                {
                    if (materials[sub] == null || (materials[sub] != apc.PaintableMaterial && !(materials[sub].mainTexture is Texture2DArray))) continue;
                    var triangles = subTriangles[sub];
                    for (int j = 0; j < triangles.Length; j += 3)
                    {
                        int a=triangles[j], b=triangles[j+1], c=triangles[j+2];
                        var u=uv[b]-uv[a]; var v=uv[c]-uv[a];
                        if (Mathf.Abs(u.x*v.y-u.y*v.x) < .000001f) continue;
                        float area = Vector3.Cross(vertices[b]-vertices[a],vertices[c]-vertices[a]).sqrMagnitude;
                        if (area <= largest) continue;
                        largest=area; panelUv=(uv[a]+uv[b]+uv[c])/3f;
                        // A conservative inset entirely within a real native painted-panel triangle.
                        panelEdgeA=u*.08f;panelEdgeB=v*.08f;
                    }
                }
            }
            if (largest == 0f)
                throw new InvalidOperationException("APC painted mesh has no readable UVs; refusing guessed atlas coordinates.");
            Debug.Log("[Modular Switchboards] APC painted panel UV anchor="+panelUv+"; native textures retained unchanged.");
        }

        // Read imported non-readable meshes from their native GPU buffers without modifying APC assets.
        internal static void ReadNativeMesh(Mesh mesh, out Vector3[] vertices, out Vector2[] uv, out int[][] triangles)
        {
            triangles = new int[mesh.subMeshCount][];
            if (mesh.isReadable)
            {
                vertices=mesh.vertices;uv=mesh.uv;
                for(int i=0;i<triangles.Length;i++) triangles[i]=mesh.GetTriangles(i);
                return;
            }
            vertices = new Vector3[mesh.vertexCount]; uv = new Vector2[mesh.vertexCount];
            foreach (var attribute in new[] { VertexAttribute.Position, VertexAttribute.TexCoord0 })
            {
                var format=mesh.GetVertexAttributeFormat(attribute);
                if (format != VertexAttributeFormat.Float32 && format != VertexAttributeFormat.Float16)
                    throw new InvalidOperationException("Unsupported native vertex format " + attribute + ": " + format);
                int size=format==VertexAttributeFormat.Float32?4:2;
                int stream=mesh.GetVertexAttributeStream(attribute), stride=mesh.GetVertexBufferStride(stream);
                int offset=mesh.GetVertexAttributeOffset(attribute);
                using(var buffer=mesh.GetVertexBuffer(stream))
                {
                    var data=new uint[buffer.count*buffer.stride/4];buffer.GetData(data);
                    var bytes=new byte[data.Length*4];Buffer.BlockCopy(data,0,bytes,0,bytes.Length);
                    for(int i=0;i<mesh.vertexCount;i++)
                    {
                        int start=i*stride+offset;
                        float x=ReadFloat(bytes,start,size),y=ReadFloat(bytes,start+size,size);
                        if(attribute==VertexAttribute.Position) vertices[i]=new Vector3(x,y,ReadFloat(bytes,start+size*2,size));
                        else uv[i]=new Vector2(x,y);
                    }
                }
            }
            using(var buffer=mesh.GetIndexBuffer())
            {
                bool wide=mesh.indexFormat==IndexFormat.UInt32;
                var bytes=new byte[buffer.count*buffer.stride];
                if(wide) { var raw=new uint[bytes.Length/4];buffer.GetData(raw);Buffer.BlockCopy(raw,0,bytes,0,bytes.Length); }
                else { var raw=new ushort[bytes.Length/2];buffer.GetData(raw);Buffer.BlockCopy(raw,0,bytes,0,bytes.Length); }
                for(int sub=0;sub<triangles.Length;sub++)
                {
                    var desc=mesh.GetSubMesh(sub);var indices=new int[desc.indexCount];
                    for(int j=0;j<indices.Length;j++)
                    {
                        int address=(desc.indexStart+j)*(wide?4:2);
                        indices[j]=(wide?(int)BitConverter.ToUInt32(bytes,address):BitConverter.ToUInt16(bytes,address))+desc.baseVertex;
                    }
                    triangles[sub]=indices;
                }
            }
        }

        private static float ReadFloat(byte[] bytes,int start,int size)
        {
            if(size==4) return BitConverter.ToSingle(bytes,start);
            int h=BitConverter.ToUInt16(bytes,start), sign=(h>>15)==0?1:-1, exponent=(h>>10)&31, mantissa=h&1023;
            if(exponent==31) throw new InvalidDataException("Non-finite native half vertex.");
            return sign*(exponent==0 ? mantissa*(float)Math.Pow(2,-24) : (1f+mantissa/1024f)*(float)Math.Pow(2,exponent-15));
        }

        internal static void ApplyNativeUv(Mesh mesh)
        {
            var points=mesh.vertices;var normals=mesh.normals;var uv=new Vector2[points.Length];
            for(int i=0;i<points.Length;i++)
            {
                var n=normals[i];var v=points[i];
                var planar=Mathf.Abs(n.z)>.7f?new Vector2(v.x,v.y):Mathf.Abs(n.x)>.7f?new Vector2(v.z,v.y):new Vector2(v.x,v.z);
                uv[i]=panelUv+panelEdgeA*Mathf.Clamp(planar.x/.5f,-.5f,.5f)+panelEdgeB*Mathf.Clamp(planar.y/.5f,-.5f,.5f);
            }
            mesh.uv=uv;mesh.RecalculateTangents();
        }

        internal static void EnsureLoaded()
        {
            if (Meshes != null) return;
            var template = GameManager.GetTextureArrayColorMaterial();
            if (template == null || template.shader == null || !template.shader.isSupported)
                throw new InvalidOperationException("Native game paint material unavailable.");

            using (var stream = typeof(CabinetGeometry).Assembly.GetManifestResourceStream("ModularSwitchboards.Cabinet.meshbin"))
            {
                if (stream == null) throw new InvalidOperationException("Embedded cabinet mesh missing.");
                using (var reader = new BinaryReader(stream))
                {
                    if (new string(reader.ReadChars(4)) != "SBMS" || reader.ReadInt32() != 1)
                        throw new InvalidDataException("Unsupported cabinet format.");
                    int materialCount = reader.ReadInt32(), meshCount = reader.ReadInt32();
                    if (materialCount != 5 || meshCount != 4) throw new InvalidDataException("Expected simple cabinet geometry.");
                    var materials = new Material[materialCount];
                    var colorIndices = new[] { (int)ColorType.Gray, (int)ColorType.White, (int)ColorType.Yellow, (int)ColorType.Black, (int)ColorType.Gray };
                    for (int i = 0; i < materialCount; i++)
                    {
                        var color = new Color(reader.ReadSingle(), reader.ReadSingle(), reader.ReadSingle(), reader.ReadSingle());
                        reader.ReadSingle(); reader.ReadSingle();
                        // Retain every native diffuse/normal/surface texture and shader setting.
                        // UVs below sample an inset of a native APC panel, not an arbitrary atlas point.
                        var material = new Material(template) { name = "Switchboards.ApcSurface." + i };
                        materials[i] = material;
                    }
                    float rearDepth = CabinetRearDepth.Measure();
                    var meshes = new Mesh[meshCount];
                    for (int i = 0; i < meshCount; i++)
                    {
                        int count = reader.ReadInt32();
                        if (count < 3 || count > 65535) throw new InvalidDataException("Invalid vertex count.");
                        var vertices = new Vector3[count]; var normals = new Vector3[count];
                        for (int v = 0; v < count; v++)
                        {
                            vertices[v] = new Vector3(reader.ReadSingle(), reader.ReadSingle(), reader.ReadSingle());
                            normals[v] = new Vector3(reader.ReadSingle(), reader.ReadSingle(), reader.ReadSingle());
                        }
                        if (i == 1) CabinetRearDepth.Fit(vertices, normals, rearDepth);
                        var mesh = new Mesh { name = "Switchboards.Simple." + new[] { "Frame", "Housing", "Interior", "Door" }[i] };
                        mesh.vertices = vertices; mesh.normals = normals;
                        mesh.subMeshCount = materialCount;
                        for (int m = 0; m < materialCount; m++)
                        {
                            int n = reader.ReadInt32();
                            if (n < 0 || n > count * 3 || n % 3 != 0) throw new InvalidDataException("Invalid triangle count.");
                            var indices = new int[n];
                            for (int j = 0; j < n; j++)
                            {
                                indices[j] = reader.ReadInt32();
                                if (indices[j] < 0 || indices[j] >= count) throw new InvalidDataException("Invalid index.");
                            }
                            mesh.SetTriangles(indices, m, false);
                        }
                        ApplyNativeUv(mesh);
                        if (i == 1) CabinetRearSurface.ApplyUv(mesh);
                        mesh.RecalculateBounds(); meshes[i] = mesh;
                    }
                    if (stream.Position != stream.Length) throw new InvalidDataException("Trailing geometry data.");
                    Materials = materials; PaletteIndices = colorIndices; Meshes = meshes;
                }
            }
            Debug.Log("[Modular Switchboards] Native APC panel textures retained; shader " + template.shader.name);
        }
    }
}
