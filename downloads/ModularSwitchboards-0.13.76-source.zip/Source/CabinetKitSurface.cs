using System;
using System.IO;
using UnityEngine;
namespace ModularSwitchboards
{
    // Private materials for our authored carton, webbing and frame.
    internal static class CabinetKitSurface
    {
        internal const string RendererName="Switchboards.CabinetPackage";
        private static Material[] materials;
        internal static Material[] Materials
        {
            get
            {
                if(materials!=null)return materials;
                var shader=Shader.Find("Standard");
                if(shader==null||!shader.isSupported)shader=Shader.Find("StandardInstanced");
                if(shader==null||!shader.isSupported)throw new InvalidOperationException("Cabinet package shader unavailable");
                var colours=new[]{new Color(.070f,.075f,.072f),new Color(.78f,.83f,.80f),
                    new Color(.51f,.43f,.29f),new Color(.28f,.22f,.13f),new Color(.43f,.48f,.49f)};
                Texture2D texture;
                using(var stream=typeof(CabinetKitSurface).Assembly.GetManifestResourceStream("ModularSwitchboards.ConsoleCartons.Surface.png"))
                using(var bytes=new MemoryStream())
                {
                    if(stream==null)throw new InvalidDataException("Copied console carton texture missing");
                    stream.CopyTo(bytes);texture=new Texture2D(2,2,TextureFormat.RGBA32,true,false);
                    if(!ImageConversion.LoadImage(texture,bytes.ToArray(),true))throw new InvalidDataException("Copied console carton texture invalid");
                    texture.name="Switchboards.CopiedConsoleCartons";texture.wrapMode=TextureWrapMode.Repeat;
                }
                materials=new Material[colours.Length];
                for(int i=0;i<materials.Length;i++)
                {
                    var m=new Material(shader){name="Switchboards.CabinetPackage.Surface"+i,color=colours[i]};
                    if(i==2){m.mainTexture=texture;m.color=Color.white;}
                    m.SetFloat("_Glossiness",i==4?.26f:.08f);m.SetFloat("_Metallic",i==4?.45f:0f);materials[i]=m;
                }
                return materials;
            }
        }
        internal static void Refresh(MeshRenderer renderer)
        {
            renderer.SetPropertyBlock(null);
            for(int i=0;i<renderer.sharedMaterials.Length;i++)renderer.SetPropertyBlock(null,i);
            var current=renderer.sharedMaterials;
            for(int i=0;i<Materials.Length;i++)current[i]=Materials[i];
            renderer.sharedMaterials=current;
        }
    }
}
