using System;
using System.Collections.Generic;
using System.Linq;

namespace ModularSwitchboards
{
    // Bounded, cheap candidates for the mostly empty door sheet. Only use a
    // simple lane when its complete centreline is physically clear and also
    // avoids visual crossing/stacking. Dense layouts retain the grid router.
    internal static class WireLaneRoutes
    {
        internal static float Score(WirePoint[] path)
        {
            float length=0;for(int i=1;i<path.Length;i++)length+=(float)Math.Sqrt((path[i]-path[i-1]).Squared);
            float turn=0;
            for(int i=1;i<path.Length-1;i++)
            {
                var a=path[i]-path[i-1];var b=path[i+1]-path[i];double divisor=Math.Sqrt(a.Squared*b.Squared);
                if(divisor>1e-12)turn+=(float)(Math.Acos(Math.Max(-1,Math.Min(1,WirePoint.Dot(a,b)/divisor)))/(Math.PI*.5));
            }
            return length+turn*.018f;
        }
        internal static WirePoint[] Find(WirePoint start,WirePoint end,IList<WireRect> blocks,IList<WirePoint[]> occupied,int arrival,int departure)
        {
            var geometry=new WireRouting.Geometry(blocks,occupied,false);WirePoint[] best=null;float score=float.PositiveInfinity;
            Action<WirePoint[]> offer=raw=>
            {
                var path=new List<WirePoint>();foreach(var p in raw)if(path.Count==0||(p-path[path.Count-1]).Squared>1e-12f)path.Add(p);
                if(path.Count<2)return;
                var array=path.ToArray();float candidate=Score(array);if(candidate>=score||WireRouting.SelfIntersects(array))return;
                for(int i=1;i<array.Length;i++)
                {
                    var a=array[i-1];var b=array[i];var d=b-a;int direction=Math.Abs(d.X)>=Math.Abs(d.Y)?(d.X>0?0:2):(d.Y>0?1:3);
                    if(i==1&&departure>=0&&direction==(departure+2)%4||i==array.Length-1&&arrival>=0&&direction!=arrival)return;
                    if(Math.Abs(a.X)>WireRouting.HalfWidth||Math.Abs(b.X)>WireRouting.HalfWidth||Math.Abs(a.Y)>WireRouting.HalfHeight||Math.Abs(b.Y)>WireRouting.HalfHeight)return;
                    if(!geometry.Clear(a,b)||WireRouting.ProjectedCrossings(a,b,occupied,false)>0||WireRouting.ProjectedCrowding(a,b,occupied,false)>.01f)return;
                }
                best=array;score=candidate;
            };
            offer(new[]{start,new WirePoint(end.X,start.Y,start.Z),end});
            offer(new[]{start,new WirePoint(start.X,end.Y,start.Z),end});
            // Adjacent tracks have a 9 mm pitch (> 6.4 mm required clearance).
            var xs=new HashSet<float>();var ys=new HashSet<float>();
            foreach(float offset in new[]{-.027f,-.018f,-.009f,0,.009f,.018f,.027f})
            {xs.Add(start.X+offset);xs.Add(end.X+offset);ys.Add(start.Y+offset);ys.Add(end.Y+offset);}
            foreach(float x in xs.OrderBy(x=>Math.Abs(x-start.X)+Math.Abs(x-end.X)))offer(new[]{start,new WirePoint(x,start.Y,start.Z),new WirePoint(x,end.Y,start.Z),end});
            foreach(float y in ys.OrderBy(y=>Math.Abs(y-start.Y)+Math.Abs(y-end.Y)))offer(new[]{start,new WirePoint(start.X,y,start.Z),new WirePoint(end.X,y,start.Z),end});
            return best;
        }
    }
}
