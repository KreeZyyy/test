using System.Collections.Generic;
using UnityEngine;

namespace ModularSwitchboards
{
    // Raised paint geometry on the two faces of the moving flap; no overlay font.
    internal static class BreakerLettering
    {
        internal static Mesh Build(bool on,float centerY,float z)
        {
            string word=on?"ON":"OFF";const float cellX=.00055f,cellY=.00065f;
            var vertices=new List<Vector3>();var normals=new List<Vector3>();var triangles=new List<int>();
            float sign=on?1f:-1f,width=(word.Length*6-1)*cellX;
            for(int letter=0;letter<word.Length;letter++)
            {
                string[] rows=word[letter]=='O'?new[]{"01110","10001","10001","10001","10001","10001","01110"}:
                    word[letter]=='N'?new[]{"10001","11001","11001","10101","10011","10011","10001"}:
                    new[]{"11111","10000","10000","11110","10000","10000","10000"};
                for(int row=0;row<7;row++)for(int col=0;col<5;col++)
                {
                    if(rows[row][col]!='1')continue;
                    float left=-width*.5f+(letter*6+col)*cellX,right=left+cellX;
                    float top=centerY+sign*(3.5f-row)*cellY,bottom=top-sign*cellY;
                    int first=vertices.Count;
                    vertices.AddRange(new[]{new Vector3(left,bottom,z),new Vector3(right,bottom,z),new Vector3(right,top,z),new Vector3(left,top,z)});
                    var normal=new Vector3(0,0,sign);normals.AddRange(new[]{normal,normal,normal,normal});
                    triangles.AddRange(new[]{first,first+1,first+2,first,first+2,first+3});
                }
            }
            var mesh=new Mesh{name=on?"Switchboards.ON":"Switchboards.OFF"};mesh.SetVertices(vertices);mesh.SetNormals(normals);mesh.SetTriangles(triangles,0);CabinetGeometry.ApplyNativeUv(mesh);mesh.RecalculateBounds();return mesh;
        }
    }
}
