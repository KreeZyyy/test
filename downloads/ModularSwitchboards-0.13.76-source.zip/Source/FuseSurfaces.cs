using System;
using UnityEngine;

namespace ModularSwitchboards
{
    // Fuse caps and contacts deliberately share the exact same plain white surface.
    internal static class FuseSurfaces
    {
        private static Material[] white;
        internal static Material[] White=>white??(white=CreateWhite());
        private static Material[] CreateWhite()
        {
            var shader=Shader.Find("StandardInstanced");
            if(shader==null||!shader.isSupported)throw new InvalidOperationException("Native StandardInstanced shader unavailable for fuse surfaces");
            var material=new Material(shader){name="Switchboards.Fuse.White"};
            material.SetTexture("_MainTex",Texture2D.whiteTexture);
            material.SetColor("_Color",Color.white);material.SetColor("_EmissionColor",Color.black);
            material.SetFloat("_Metallic",0f);material.SetFloat("_Glossiness",.20f);
            return new[]{material,material,material,material,material};
        }
    }
}
