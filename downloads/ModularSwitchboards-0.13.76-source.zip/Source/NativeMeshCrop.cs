using System;
using System.Collections.Generic;
using UnityEngine;

namespace ModularSwitchboards
{
    // Clip triangles, rather than dropping whole faces at a connector/body boundary.
    // Original UVs are interpolated at cuts; no atlas coordinates are invented.
    internal static class NativeMeshCrop
    {
        private struct Vertex {internal Vector3 P;internal Vector2 U;internal Vertex(Vector3 p,Vector2 u){P=p;U=u;}}
        internal static Mesh Read(Mesh source,Matrix4x4 frame,Bounds region,string name)
        {
            CabinetGeometry.ReadNativeMesh(source,out var points,out var uv,out var triangles);
            var vertices=new List<Vector3>();var texcoords=new List<Vector2>();var subs=new List<int>[triangles.Length];
            for(int s=0;s<triangles.Length;s++)
            {
                subs[s]=new List<int>();
                for(int t=0;t<triangles[s].Length;t+=3)
                {
                    var polygon=new List<Vertex>();
                    for(int j=0;j<3;j++){int id=triangles[s][t+j];polygon.Add(new Vertex(frame.MultiplyPoint3x4(points[id]),uv[id]));}
                    for(int axis=0;axis<3 && polygon.Count>0;axis++)
                    {
                        polygon=Clip(polygon,axis,region.min[axis],true);
                        polygon=Clip(polygon,axis,region.max[axis],false);
                    }
                    for(int j=1;j+1<polygon.Count;j++)
                    {
                        var a=polygon[0];var b=polygon[j];var c=polygon[j+1];
                        if(Vector3.Cross(b.P-a.P,c.P-a.P).sqrMagnitude<1e-16f)continue;
                        int offset=vertices.Count;
                        foreach(var v in new[]{a,b,c}){vertices.Add(v.P);texcoords.Add(v.U);}
                        subs[s].Add(offset);subs[s].Add(offset+(frame.determinant<0?2:1));subs[s].Add(offset+(frame.determinant<0?1:2));
                    }
                }
            }
            if(vertices.Count==0)return null;
            var mesh=new Mesh{name=name};if(vertices.Count>65535)mesh.indexFormat=UnityEngine.Rendering.IndexFormat.UInt32;
            mesh.SetVertices(vertices);mesh.SetUVs(0,texcoords);mesh.subMeshCount=subs.Length;
            for(int s=0;s<subs.Length;s++)mesh.SetTriangles(subs[s],s);
            mesh.RecalculateNormals();mesh.RecalculateTangents();mesh.RecalculateBounds();return mesh;
        }
        private static List<Vertex> Clip(List<Vertex> input,int axis,float plane,bool above)
        {
            var result=new List<Vertex>();if(input.Count==0)return result;
            var previous=input[input.Count-1];float pd=previous.P[axis]-plane;bool pin=above?pd>=0:pd<=0;
            foreach(var current in input)
            {
                float cd=current.P[axis]-plane;bool cin=above?cd>=0:cd<=0;
                if(pin!=cin)
                {
                    float t=pd/(pd-cd);
                    result.Add(new Vertex(previous.P+(current.P-previous.P)*t,previous.U+(current.U-previous.U)*t));
                }
                if(cin)result.Add(current);
                previous=current;pd=cd;pin=cin;
            }
            return result;
        }
    }
}
