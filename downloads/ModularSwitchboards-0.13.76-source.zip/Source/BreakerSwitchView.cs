using UnityEngine;
using Assets.Scripts.Objects.Motherboards;

namespace ModularSwitchboards
{
    internal static class BreakerSwitchPose
    {
        internal static int IndicatorColor(bool on) => (int)(on ? ColorType.Green : ColorType.Red);
        internal static float LeverAngle(bool on) => on ? 0f : 180f;
    }

    // Native OnOff owns saved/networked state. Animate only the visual, around a fixed spindle.
    public sealed class BreakerSwitchView : MonoBehaviour
    {
        public DinBreaker Owner;
        public Transform Lever;
        private bool initialized;
        private bool previous;
        private float angle;
        private float duration;

        private void LateUpdate()
        {
            if (Owner == null || Lever == null) return;
            Tick(Owner.OnOff, Time.deltaTime);
        }
        internal void Tick(bool on, float deltaTime)
        {
            if (!initialized) { Apply(on); return; }
            if (previous != on)
            {
                previous=on;
                if(duration>0f)BreakerSwitchAudio.Play(Owner,on);
                Refresh(on);
            }
            float target=BreakerSwitchPose.LeverAngle(on);
            angle=duration>0f?Mathf.MoveTowards(angle,target,180f*Mathf.Max(0f,deltaTime)/duration):target;
            Pose();
        }
        internal void Apply(bool on)
        {
            if (Lever == null) return;
            angle=BreakerSwitchPose.LeverAngle(on);
            duration=BreakerSwitchAudio.Duration();
            previous=on; initialized=true;
            Pose(); Refresh(on);
        }
        private void Pose()
        {
            Lever.localPosition=new Vector3(0,0,.0675f);
            Lever.localRotation=Quaternion.Euler(angle,0,0);
        }
        private void Refresh(bool on)
        {
            if(Owner!=null) DinBreakerModel.Refresh(Owner);
        }
    }
}
