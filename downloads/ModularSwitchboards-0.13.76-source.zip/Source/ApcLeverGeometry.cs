using System;
using System.Linq;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Electrical;
using UnityEngine;

namespace ModularSwitchboards
{
    internal static class ApcLeverGeometry
    {
        private static Mesh mesh;
        private static Material[] materials;
        private static MaterialPropertyBlock[] blocks;
        private static bool attempted;

        internal static bool TryGet(out Mesh result,out Material[] surface)
        {
            if(!attempted)
            {
                attempted=true;
                try
                {
                    var prefabs=WorldManager.Instance.SourcePrefabs.OfType<AreaPowerControl>();
                    var apc=prefabs.FirstOrDefault(p=>p.PrefabName=="StructureAreaPowerControl") ?? prefabs.FirstOrDefault();
                    var source=apc==null?null:apc.GetComponentsInChildren<MeshRenderer>(true).FirstOrDefault(r=>r.name=="MasterLever");
                    var original=source==null?null:source.GetComponent<MeshFilter>()?.sharedMesh;
                    if(original!=null)
                    {
                        CabinetGeometry.ReadNativeMesh(original,out var points,out var uv,out var triangles);
                        var matrix=apc.transform.worldToLocalMatrix*source.transform.localToWorldMatrix;
                        if(CabinetModel.FrontSign<0)matrix=Matrix4x4.Rotate(Quaternion.Euler(0,180,0))*matrix;
                        for(int i=0;i<points.Length;i++)points[i]=matrix.MultiplyPoint3x4(points[i]);
                        // Recover the broad face of the actual APC flap instead of treating its
                        // depth as a projecting handle. Neutralize its baked prefab pose.
                        Vector3 face=Vector3.forward;float largest=0f;
                        foreach(var indices in triangles)
                            for(int j=0;j<indices.Length;j+=3)
                            {
                                var cross=Vector3.Cross(points[indices[j+1]]-points[indices[j]],points[indices[j+2]]-points[indices[j]]);
                                if(cross.sqrMagnitude>largest){largest=cross.sqrMagnitude;face=cross.normalized;}
                            }
                        if(Vector3.Dot(face,Vector3.forward)<0)face=-face;
                        var right=Vector3.ProjectOnPlane(Vector3.right,face).normalized;
                        if(right.sqrMagnitude<.5f)throw new InvalidOperationException("APC flap face has no horizontal spindle axis");
                        var up=Vector3.Cross(face,right).normalized;
                        for(int i=0;i<points.Length;i++)
                            points[i]=new Vector3(Vector3.Dot(points[i],right),Vector3.Dot(points[i],up),Vector3.Dot(points[i],face));
                        var nativePivot=matrix.MultiplyPoint3x4(Vector3.zero);
                        nativePivot=new Vector3(Vector3.Dot(nativePivot,right),Vector3.Dot(nativePivot,up),Vector3.Dot(nativePivot,face));
                        FitFlap(points,nativePivot);
                        mesh=new Mesh{name="Switchboards.NativeAPCMasterLever"};mesh.vertices=points;mesh.uv=uv;mesh.subMeshCount=triangles.Length;
                        for(int sub=0;sub<triangles.Length;sub++)
                        {
                            if(matrix.determinant<0)for(int j=0;j<triangles[sub].Length;j+=3){int swap=triangles[sub][j+1];triangles[sub][j+1]=triangles[sub][j+2];triangles[sub][j+2]=swap;}
                            mesh.SetTriangles(triangles[sub],sub);
                        }
                        mesh.RecalculateNormals();mesh.RecalculateTangents();mesh.RecalculateBounds();
                        materials=source.sharedMaterials;
                        blocks=new MaterialPropertyBlock[materials.Length];var global=new MaterialPropertyBlock();source.GetPropertyBlock(global);
                        for(int i=0;i<blocks.Length;i++){var block=new MaterialPropertyBlock();source.GetPropertyBlock(block,i);blocks[i]=block.isEmpty?global:block;}
                        Debug.Log("[Modular Switchboards] Native APC MasterLever reused: "+points.Length+" vertices; native transform spindle preserved, flap reach 21 mm; original UV and materials retained.");
                    }
                }
                catch(Exception ex){mesh=null;Debug.LogWarning("[Modular Switchboards] APC lever extraction: "+ex.Message);}
                if(mesh==null)Debug.LogWarning("[Modular Switchboards] Native APC lever unavailable; rounded prototype handle used.");
            }
            result=mesh;surface=materials;return mesh!=null;
        }
        internal static void FitFlap(Vector3[] points,Vector3 pivot)
        {
            var bounds=new Bounds(points[0],Vector3.zero);foreach(var point in points)bounds.Encapsulate(point);
            var size=bounds.size;
            float reach=Mathf.Max(Mathf.Abs(bounds.min.y-pivot.y),Mathf.Abs(bounds.max.y-pivot.y));
            float thickness=Mathf.Max(Mathf.Abs(bounds.min.z-pivot.z),Mathf.Abs(bounds.max.z-pivot.z));
            var fit=new Vector3(.012f/Mathf.Max(size.x,.00001f),.021f/Mathf.Max(reach,.00001f),.00125f/Mathf.Max(thickness,.00001f));
            bool flip=bounds.center.y<pivot.y;
            for(int i=0;i<points.Length;i++)
            {
                // Preserve the native animation origin, NOT a mesh bounding-box edge.
                // A 180-degree turn about X neutralizes a downward source pose without
                // reflecting UVs/winding. Every point on the spindle stays at y=z=0.
                var p=points[i]-new Vector3(bounds.center.x,pivot.y,pivot.z);
                if(flip){p.y=-p.y;p.z=-p.z;}
                points[i]=Vector3.Scale(p,fit);
            }
        }
        internal static bool Paint(Renderer renderer,float watts)
        {
            if(!Restore(renderer))return false;
            renderer.sharedMaterials=LeverTextures.For(materials,DinModuleCatalog.Colour(watts));
            return true;
        }
        internal static bool Restore(Renderer renderer)
        {
            if(mesh==null || renderer.GetComponent<MeshFilter>()?.sharedMesh!=mesh)return false;
            for(int i=0;i<blocks.Length;i++)renderer.SetPropertyBlock(blocks[i],i);
            return true;
        }
    }
}
