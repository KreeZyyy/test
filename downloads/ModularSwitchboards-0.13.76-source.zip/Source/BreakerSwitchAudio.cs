using System;
using System.Linq;
using System.Reflection;
using Assets.Scripts;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Objects.Electrical;
using Assets.Scripts.Sound;
using Assets.Scripts.Util;
using UnityEngine;

namespace ModularSwitchboards
{
    internal static class BreakerSwitchAudio
    {
        private static readonly FieldInfo TimeField=typeof(InteractableAnimComponent).GetField("time",BindingFlags.Instance|BindingFlags.NonPublic);
        private static float? nativeDuration;
        private static bool warned;

        internal static float Duration()
        {
            if(nativeDuration.HasValue)return nativeDuration.Value;
            try
            {
                var apc=WorldManager.Instance?.SourcePrefabs.OfType<AreaPowerControl>().FirstOrDefault(p=>p.PrefabName=="StructureAreaPowerControl");
                var animation=apc?.GetComponentsInChildren<ApcOnOffAnimComponent>(true).FirstOrDefault();
                if(animation!=null&&TimeField?.GetValue(animation) is float value&&!float.IsNaN(value)&&!float.IsInfinity(value)&&value>=0)
                {
                    nativeDuration=value;
                    Debug.Log("[Modular Switchboards] Native APC lever animation duration: "+value+" s.");
                    return value;
                }
            }
            catch(Exception ex)
            {
                if(!warned)Debug.LogWarning("[Modular Switchboards] APC animation timing unavailable: "+ex.Message);
            }
            if(!warned)Debug.LogWarning("[Modular Switchboards] APC animation timing unavailable; using 0.22 s fallback.");
            warned=true;
            return .22f;
        }

        internal static void Play(DinBreaker module,bool on)
        {
            if(module==null||module.IsFuseHolder||module.IsBatteryModule||module.IsAnalyserModule||GameManager.IsBatchMode||GameManager.GameState!=GameState.Running)return;
            if(Singleton<AudioManager>.Instance==null)return;
            // Native ApcOnOffAnimComponent plays these clips before Animate begins.
            module.PlayPooledAudioSound(on?Defines.Sounds.ApcOn:Defines.Sounds.ApcOff,Vector3.zero);
        }
    }
}
