using System;
using System.Collections.Generic;
using System.Linq;
using Assets.Scripts.Objects.Electrical;
using UnityEngine;
using UnityEngine.Rendering;
using Object = UnityEngine.Object;

namespace ModularSwitchboards
{
    internal static class ApcWarningGeometry
    {
        private sealed class Face
        {
            internal int A,B,C,Sub;
            internal Color32 Color;
            internal Bounds Bounds;
        }
        private static Mesh warning;
        private static Material[] materials;
        private static MaterialPropertyBlock[] blocks;
        private static ShadowCastingMode shadowMode;
        private static LightProbeUsage lightProbes;
        private static ReflectionProbeUsage reflectionProbes;
        private static bool receiveShadows;

        internal static bool Install(AreaPowerControl apc,Transform door)
        {
            if(warning==null)
            {
                foreach(var source in apc.GetComponentsInChildren<MeshRenderer>(true)
                    .Where(r=>r.name.IndexOf("door",StringComparison.OrdinalIgnoreCase)>=0 && r.name.IndexOf("destroy",StringComparison.OrdinalIgnoreCase)<0))
                {
                    try { if(Extract(apc,source)) break; }
                    catch(Exception ex){ Debug.LogWarning("[Modular Switchboards] Native warning geometry read: "+ex.Message); }
                }
            }
            if(warning==null) return false;
            var obj=new GameObject("NativeApcWarning") {layer=door.gameObject.layer};obj.transform.SetParent(door,false);
            obj.AddComponent<MeshFilter>().sharedMesh=warning;
            var renderer=obj.AddComponent<MeshRenderer>();renderer.sharedMaterials=materials;
            renderer.shadowCastingMode=shadowMode;renderer.lightProbeUsage=lightProbes;renderer.reflectionProbeUsage=reflectionProbes;
            renderer.receiveShadows=receiveShadows;renderer.probeAnchor=obj.transform;
            Restore(renderer);
            return true;
        }
        internal static bool Restore(Renderer renderer)
        {
            if(warning==null || renderer.GetComponent<MeshFilter>()?.sharedMesh!=warning) return false;
            for(int i=0;i<blocks.Length;i++) renderer.SetPropertyBlock(blocks[i],i);
            return true;
        }
        private static bool Extract(AreaPowerControl apc,MeshRenderer source)
        {
            var mesh=source.GetComponent<MeshFilter>()?.sharedMesh;if(mesh==null) return false;
            CabinetGeometry.ReadNativeMesh(mesh,out var points,out var uv,out var triangles);
            var transform=apc.transform.worldToLocalMatrix*source.transform.localToWorldMatrix;
            for(int i=0;i<points.Length;i++) points[i]=transform.MultiplyPoint3x4(points[i]);
            var mats=source.sharedMaterials;var faces=new List<Face>();
            for(int sub=0;sub<triangles.Length && sub<mats.Length;sub++)
            {
                var mat=mats[sub];if(mat==null || mat.mainTexture==null) continue;
                Texture2D image=null;
                try
                {
                    image=ApcWarning.Snapshot(mat.mainTexture,0);var pixels=image.GetPixels32();
                    var st=mat.mainTextureScale;var offset=mat.mainTextureOffset;
                    var tint=mat.HasProperty("_Color")?mat.GetColor("_Color"):Color.white;
                    for(int j=0;j<triangles[sub].Length;j+=3)
                    {
                        int a=triangles[sub][j],b=triangles[sub][j+1],c=triangles[sub][j+2];
                        var t=(uv[a]+uv[b]+uv[c])/3f;
                        float u=Mathf.Repeat(t.x*st.x+offset.x,1f),v=Mathf.Repeat(t.y*st.y+offset.y,1f);
                        var pixel=pixels[Mathf.Min(image.height-1,(int)(v*image.height))*image.width+Mathf.Min(image.width-1,(int)(u*image.width))];
                        pixel.r=(byte)Mathf.Clamp(pixel.r*tint.r,0f,255f);pixel.g=(byte)Mathf.Clamp(pixel.g*tint.g,0f,255f);pixel.b=(byte)Mathf.Clamp(pixel.b*tint.b,0f,255f);
                        var bounds=new Bounds(points[a],Vector3.zero);bounds.Encapsulate(points[b]);bounds.Encapsulate(points[c]);
                        if(transform.determinant<0f){int swap=b;b=c;c=swap;}
                        faces.Add(new Face{A=a,B=b,C=c,Sub=sub,Color=pixel,Bounds=bounds});
                    }
                }
                finally{if(image!=null) Object.DestroyImmediate(image);}
            }
            var chosen=SelectSign(faces,points,apc.Bounds.center.y);
            if(chosen==null) return false;
            var all=BoundsOf(chosen);

            float scale=.65f; // Original APC contour and bolt, reduced to reserve door space for future controls.
            var vertices=new List<Vector3>();var texcoords=new List<Vector2>();var indices=new List<int>[mats.Length];
            for(int i=0;i<indices.Length;i++) indices[i]=new List<int>();
            foreach(var face in chosen)
                foreach(int index in new[]{face.A,face.B,face.C})
                {
                    var point=(points[index]-all.center)*scale;
                    vertices.Add(point+new Vector3(.20f,.17f,.016f));texcoords.Add(uv[index]);indices[face.Sub].Add(vertices.Count-1);
                }
            var result=new Mesh{name="Switchboards.NativeApcWarningGeometry"};result.SetVertices(vertices);result.SetUVs(0,texcoords);result.subMeshCount=mats.Length;
            for(int i=0;i<indices.Length;i++) result.SetTriangles(indices[i],i,false);
            result.RecalculateNormals();result.RecalculateBounds();
            var normals=result.normals;var tangents=new Vector4[normals.Length];
            for(int i=0;i<normals.Length;i++)
            {var t=Vector3.Cross(Mathf.Abs(normals[i].y)<.9f?Vector3.up:Vector3.right,normals[i]).normalized;tangents[i]=new Vector4(t.x,t.y,t.z,1f);}
            result.tangents=tangents;
            var properties=new MaterialPropertyBlock[mats.Length];var global=new MaterialPropertyBlock();source.GetPropertyBlock(global);
            for(int i=0;i<properties.Length;i++){var block=new MaterialPropertyBlock();source.GetPropertyBlock(block,i);properties[i]=block.isEmpty?global:block;}
            warning=result;materials=mats;blocks=properties;
            shadowMode=source.shadowCastingMode;lightProbes=source.lightProbeUsage;reflectionProbes=source.reflectionProbeUsage;receiveShadows=source.receiveShadows;
            Debug.Log("[Modular Switchboards] Native APC warning geometry reused: faces="+chosen.Count+", source bounds="+all+"; original UVs and materials retained.");
            return true;
        }
        private static List<Face> SelectSign(List<Face> faces,Vector3[] points,float centerY)
        {
            var yellow=faces.Where(f=>Yellow(f.Color)).ToList();
            Debug.Log("[Modular Switchboards] APC Door geometry: "+faces.Count+" faces, "+yellow.Count+" yellow faces.");
            var clusters=new List<List<Face>>();
            while(yellow.Count>0)
            {
                var cluster=new List<Face>{yellow[0]};yellow.RemoveAt(0);
                for(int next=0;next<cluster.Count;next++)
                {
                    var near=cluster[next].Bounds;near.Expand(.001f);
                    for(int i=yellow.Count-1;i>=0;i--)
                        if(near.Intersects(yellow[i].Bounds)){cluster.Add(yellow[i]);yellow.RemoveAt(i);}
                }
                clusters.Add(cluster);
            }
            foreach(var cluster in clusters.OrderByDescending(c=>Area(BoundsOf(c))))
            {
                var bounds=BoundsOf(cluster);var size=bounds.size;
                if(size.x<.008f || size.y<.008f || size.x>.20f || size.y>.20f || size.z>.025f || size.x/size.y<.6f || size.x/size.y>1.6f) continue;
                // The sign is on the lower half of the front of the native door.
                if(bounds.center.y>centerY+.01f) continue;
                var search=bounds;search.Expand(new Vector3(size.x*.35f,size.y*.35f,.012f));
                var black=faces.Where(f=>Black(f.Color) && search.Contains(points[f.A]) && search.Contains(points[f.B]) && search.Contains(points[f.C])).ToList();
                if(black.Count<2) continue;
                return cluster.Concat(black).ToList();
            }
            return null;
        }
        private static bool Yellow(Color32 c)=>c.r>105 && c.g>85 && c.b<Mathf.Min(c.r,c.g)*.6f && c.r<c.g*1.8f && c.g<c.r*1.4f;
        private static bool Black(Color32 c)=>c.r<95 && c.g<95 && c.b<95;
        private static float Area(Bounds b)=>b.size.x*b.size.y;
        private static Bounds BoundsOf(List<Face> faces)
        {var bounds=faces[0].Bounds;foreach(var face in faces) bounds.Encapsulate(face.Bounds);return bounds;}
    }
}
