using System;
using System.Collections.Generic;
using System.Linq;
using Assets.Scripts;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Electrical;
using Assets.Scripts.Localization2;
using Assets.Scripts.UI;
using Assets.Scripts.UI.HelperHints.Extensions;
using Assets.Scripts.Util;
using UnityEngine;
using UnityEngine.Rendering;
using Rendering;
namespace ModularSwitchboards
{
    internal static class DinAnalyserLayout
    {
        internal const int Slots=3;
        internal static float CenterX=>DinLayout.SlotPitch/DinBreakerModel.VisualScale.x;
        internal static float Width=>.0176f+2*DinLayout.SlotPitch/DinBreakerModel.VisualScale.x;
        internal const float Fit=.398f,Seat=.0645f;
        internal static readonly Vector3 SourceCenter=new Vector3(.002003f,.1674507f,-.000874f);
        internal static readonly Quaternion Rotation=Quaternion.LookRotation(Vector3.right,Vector3.forward);
        internal static Vector3 Map(Vector3 source)
        {
            var p=Rotation*(source-SourceCenter)*Fit;
            return new Vector3(CenterX+p.x/DinBreakerModel.VisualScale.x,p.y/DinBreakerModel.VisualScale.y,Seat+p.z/DinBreakerModel.VisualScale.z);
        }
    }
    internal static class DinAnalyserModel
    {
        private static Mesh native,preview;
        private static MeshRenderer original;
        private static Matrix4x4 toFrame;
        private static void Capture()
        {
            if(native!=null)return;
            var source=WorldManager.Instance.SourcePrefabs.OfType<CableAnalyser>().First();
            original=source.GetComponentsInChildren<MeshRenderer>(true).First(r=>r.GetComponent<MeshFilter>()?.sharedMesh!=null);
            var mesh=original.GetComponent<MeshFilter>().sharedMesh;
            toFrame=source.transform.worldToLocalMatrix*original.transform.localToWorldMatrix;
            CabinetGeometry.ReadNativeMesh(mesh,out var positions,out var uv,out var groups);
            var frame=positions.Select(p=>toFrame.MultiplyPoint3x4(p)).ToArray();
            var selected=AnalyserFrontSelection.Select(frame,groups);
            var copy=new Mesh{name="Switchboards.NativeAnalyserFront.AllChannels",indexFormat=mesh.indexFormat};
            copy.SetVertexBufferParams(mesh.vertexCount,mesh.GetVertexAttributes());
            foreach(var attribute in mesh.GetVertexAttributes())
                if(copy.GetVertexAttributeOffset(attribute.attribute)!=mesh.GetVertexAttributeOffset(attribute.attribute)||copy.GetVertexAttributeStream(attribute.attribute)!=mesh.GetVertexAttributeStream(attribute.attribute))
                    throw new InvalidOperationException("Analyser vertex layout mismatch");
            var streams=new List<uint[]>();
            for(int stream=0;stream<mesh.vertexBufferCount;stream++)
            {
                if(copy.GetVertexBufferStride(stream)!=mesh.GetVertexBufferStride(stream))throw new InvalidOperationException("Analyser stride mismatch");
                using(var buffer=mesh.GetVertexBuffer(stream))
                {
                    int bytes=buffer.count*buffer.stride;if(bytes%4!=0)throw new InvalidOperationException("Unaligned analyser stream");
                    var data=new uint[bytes/4];buffer.GetData(data);streams.Add(data);
                    copy.SetVertexBufferData(data,0,0,data.Length,stream,MeshUpdateFlags.DontRecalculateBounds|MeshUpdateFlags.DontValidateIndices);
                }
            }
            copy.subMeshCount=selected.Length;
            for(int i=0;i<selected.Length;i++)copy.SetTriangles(selected[i],i,false);
            for(int stream=0;stream<streams.Count;stream++)using(var buffer=copy.GetVertexBuffer(stream))
            {
                var data=new uint[streams[stream].Length];buffer.GetData(data);
                if(!data.SequenceEqual(streams[stream]))throw new InvalidOperationException("Analyser vertex stream copy differs");
            }
            var all=selected.SelectMany(t=>t).ToArray();var bounds=new Bounds(positions[all[0]],Vector3.zero);
            foreach(int index in all)bounds.Encapsulate(positions[index]);copy.bounds=bounds;
            preview=new Mesh{name="Switchboards.AnalyserFront.BlueprintOnly"};
            var pv=new List<Vector3>();var pt=new List<int[]>();
            foreach(var role in selected){var list=new List<int>();foreach(int index in role){list.Add(pv.Count);pv.Add(DinAnalyserLayout.Map(frame[index]));}pt.Add(list.ToArray());}
            preview.SetVertices(pv);preview.subMeshCount=pt.Count;
            for(int i=0;i<pt.Count;i++)preview.SetTriangles(pt[i],i,false);
            preview.RecalculateBounds();native=copy;
            Debug.Log("[Modular Switchboards] Analyzer front: 68 bezel/lightning + 6 pane triangles; all native vertex streams verified; yellow plate excluded.");
        }
        internal static Mesh Build()=>DinBreakerModel.Build(DinAnalyserLayout.Width,DinAnalyserLayout.CenterX,plain:true);
        internal static void Install(DinBreaker module)
        {
            Capture();
            var model=module.transform.Find("DinBreakerModel");
            var view=module.GetComponent<BreakerSwitchView>();if(view!=null)UnityEngine.Object.DestroyImmediate(view);
            foreach(string name in new[]{"BreakerLever","BreakerIndicator","BreakerControl"})
            {var old=model.Find(name);if(old!=null)UnityEngine.Object.DestroyImmediate(old.gameObject);}
            var mesh=Build();model.GetComponent<MeshFilter>().sharedMesh=mesh;
            var body=model.GetComponent<BoxCollider>();body.center=mesh.bounds.center;body.size=mesh.bounds.size;
            var mount=new GameObject("OriginalAnalyserMount"){layer=module.gameObject.layer};mount.transform.SetParent(model,false);
            mount.transform.localPosition=DinAnalyserLayout.Map(toFrame.MultiplyPoint3x4(Vector3.zero));
            var scale=DinBreakerModel.VisualScale;mount.transform.localScale=new Vector3(1/scale.x,1/scale.y,1/scale.z);
            var face=new GameObject("NativeAnalyserFront"){layer=module.gameObject.layer};face.transform.SetParent(mount.transform,false);
            face.transform.localRotation=DinAnalyserLayout.Rotation*toFrame.rotation;face.transform.localScale=toFrame.lossyScale*DinAnalyserLayout.Fit;
            face.AddComponent<MeshFilter>().sharedMesh=native;
            var renderer=face.AddComponent<MeshRenderer>();renderer.sharedMaterials=original.sharedMaterials;
            var block=new MaterialPropertyBlock();original.GetPropertyBlock(block);renderer.SetPropertyBlock(block);
            for(int i=0;i<original.sharedMaterials.Length;i++){var local=new MaterialPropertyBlock();original.GetPropertyBlock(local,i);renderer.SetPropertyBlock(local.isEmpty?null:local,i);}
            renderer.lightProbeUsage=original.lightProbeUsage;renderer.reflectionProbeUsage=original.reflectionProbeUsage;
            renderer.shadowCastingMode=original.shadowCastingMode;renderer.receiveShadows=original.receiveShadows;
            var hit=model.gameObject.AddComponent<BoxCollider>();hit.center=preview.bounds.center;hit.size=preview.bounds.size+new Vector3(0,0,.001f);
            module.Interactables=new List<Interactable>();module.Slots=new List<Slot>();module.HasOnOffState=false;
            module.BuildStates[0].Interactables=module.Interactables;module.BuildStates[0].Colliders=new List<Collider>{body,hit};
            var total=mesh.bounds;total.Encapsulate(preview.bounds);
            module.Bounds=new Bounds(Vector3.Scale(total.center,scale),Vector3.Scale(total.size,scale));module.SurfaceArea=.016f*3;
            module.GridBounds=new GridBounds(module);
            module.Thumbnail=CabinetIcons.Get("DinAnalyser");module.Thumbnails=new Sprite[0];module.BuildStates[0].Thumbnail=module.Thumbnail;
            var ghost=module.Blueprint.GetComponent<MeshFilter>().sharedMesh;ghost.Clear();
            var pieces=Enumerable.Range(0,5).Select(i=>new CombineInstance{mesh=mesh,subMeshIndex=i,transform=Matrix4x4.Scale(scale)}).ToList();
            for(int i=0;i<preview.subMeshCount;i++)pieces.Add(new CombineInstance{mesh=preview,subMeshIndex=i,transform=Matrix4x4.Scale(scale)});
            ghost.CombineMeshes(pieces.ToArray(),true,true);ghost.RecalculateBounds();
            module.Blueprint.GetComponent<Wireframe>().BlueprintBounds=ghost.bounds;
        }
        internal static PassiveTooltip Tooltip(DinBreaker module,PassiveTooltip tooltip)
        {
            tooltip.Title=module.DisplayName;
            var cabinet=CabinetWiring.CabinetOf(module);
            if(cabinet==null){tooltip.Extended="Install on a DIN rail and wire to an output.";return tooltip;}
            var network=cabinet.Wiring.AnalysedNetwork(module,out var reason,out var source);
            if(source!=null)tooltip.Title+=" — "+source;
            if(network==null){tooltip.Extended=reason;return tooltip;}
            // Same three native CableAnalyser getters and localized tooltip strings.
            Assets.Scripts.UI.Tooltip.ToolTipStringBuilder.Clear();
            Assets.Scripts.UI.Tooltip.ToolTipStringBuilder.Append(GameStrings.CableAnalyserActual.AsString(network.CurrentLoad.ToStringPrefix("W","yellow")));
            Assets.Scripts.UI.Tooltip.ToolTipStringBuilder.AppendLine();
            Assets.Scripts.UI.Tooltip.ToolTipStringBuilder.Append(GameStrings.CableAnalyserRequired.AsString(network.RequiredLoad.ToStringPrefix("W","yellow")));
            Assets.Scripts.UI.Tooltip.ToolTipStringBuilder.AppendLine();
            Assets.Scripts.UI.Tooltip.ToolTipStringBuilder.Append(GameStrings.CableAnalyserPotential.AsString(network.PotentialLoad.ToStringPrefix("W","yellow")));
            tooltip.Extended=Assets.Scripts.UI.Tooltip.ToolTipStringBuilder.ToString();return tooltip;
        }
    }
}
