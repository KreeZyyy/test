using System;
using System.Collections.Generic;
using System.Linq;

namespace ModularSwitchboards
{
    // Pure geometry, also exercised without Unity. All coordinates are cabinet-local metres.
    public struct WirePoint
    {
        public float X,Y,Z;
        public WirePoint(float x,float y,float z){X=x;Y=y;Z=z;}
        public static WirePoint operator +(WirePoint a,WirePoint b)=>new WirePoint(a.X+b.X,a.Y+b.Y,a.Z+b.Z);
        public static WirePoint operator -(WirePoint a,WirePoint b)=>new WirePoint(a.X-b.X,a.Y-b.Y,a.Z-b.Z);
        public static WirePoint operator *(WirePoint a,float n)=>new WirePoint(a.X*n,a.Y*n,a.Z*n);
        public float Squared=>X*X+Y*Y+Z*Z;
        public static float Dot(WirePoint a,WirePoint b)=>a.X*b.X+a.Y*b.Y+a.Z*b.Z;
    }
    public struct WireRect
    {
        public float Left,Right,Bottom,Top;
        public WireRect(float l,float r,float b,float t){Left=l;Right=r;Bottom=b;Top=t;}
        public bool Contains(WirePoint p,float margin=0)=>p.X>=Left-margin&&p.X<=Right+margin&&p.Y>=Bottom-margin&&p.Y<=Top+margin;
    }
    internal static class WireRouting
    {
        internal const float Radius=.0024f,Clearance=.0064f,Step=.003f,Plane=.06535f;
        internal const float HalfWidth=.168f,HalfHeight=.228f;
        // Fan-out at IN is one deliberate electrical joint, not an accidental crossing.
        internal static bool InInputJoint(WirePoint p)=>Math.Abs(p.X)<.032f&&p.Y>.188f;
        internal static float SegmentDistanceSquared(WirePoint a,WirePoint b,WirePoint c,WirePoint d)
        {
            var u=b-a;var v=d-c;var w=a-c;float aa=u.Squared,bb=WirePoint.Dot(u,v),cc=v.Squared,dd=WirePoint.Dot(u,w),ee=WirePoint.Dot(v,w);
            if(aa<1e-12f&&cc<1e-12f)return w.Squared;
            float s=aa<1e-12f?0:Math.Max(0,Math.Min(1,(bb*ee-cc*dd)/Math.Max(1e-12f,aa*cc-bb*bb)));
            float t=cc<1e-12f?0:Math.Max(0,Math.Min(1,(bb*s+ee)/cc));
            s=aa<1e-12f?0:Math.Max(0,Math.Min(1,(bb*t-dd)/aa));
            t=cc<1e-12f?0:Math.Max(0,Math.Min(1,(bb*s+ee)/cc));
            return (a+u*s-c-v*t).Squared;
        }
        internal static bool SegmentHitsRect(WirePoint a,WirePoint b,WireRect r,float margin)
        {
            float lo=0,hi=1;
            return ClipAxis(a.X,b.X-a.X,r.Left-margin,r.Right+margin,ref lo,ref hi)&&
                ClipAxis(a.Y,b.Y-a.Y,r.Bottom-margin,r.Top+margin,ref lo,ref hi);
        }
        private static bool ClipAxis(float start,float delta,float min,float max,ref float lo,ref float hi)
        {
            if(Math.Abs(delta)<1e-9f)return start>=min&&start<=max;
            float p=(min-start)/delta,q=(max-start)/delta;if(p>q){float t=p;p=q;q=t;}lo=Math.Max(lo,p);hi=Math.Min(hi,q);return lo<=hi;
        }
        private static float BoundsDistanceSquared(WirePoint a,WirePoint b,WirePoint c,WirePoint d)
        {
            float x=Math.Max(0,Math.Max(Math.Min(a.X,b.X)-Math.Max(c.X,d.X),Math.Min(c.X,d.X)-Math.Max(a.X,b.X)));
            float y=Math.Max(0,Math.Max(Math.Min(a.Y,b.Y)-Math.Max(c.Y,d.Y),Math.Min(c.Y,d.Y)-Math.Max(a.Y,b.Y)));
            float z=Math.Max(0,Math.Max(Math.Min(a.Z,b.Z)-Math.Max(c.Z,d.Z),Math.Min(c.Z,d.Z)-Math.Max(a.Z,b.Z)));
            return x*x+y*y+z*z;
        }
        internal static bool Clear(WirePoint a,WirePoint b,IList<WireRect> blocks,IList<WirePoint[]> wires,bool inputJoint)
        {
            foreach(var r in blocks)if(SegmentHitsRect(a,b,r,Radius+.001f))return false;
            foreach(var wire in wires)for(int i=1;i<wire.Length;i++)
            {
                if(BoundsDistanceSquared(a,b,wire[i-1],wire[i])>=Clearance*Clearance)continue;
                // Shared IN wires may meet in the physical terminal joint, but their
                // portions outside that joint still require full 3D clearance.
                if(inputJoint&&wire.Length>0&&InInputJoint(wire[0]))
                {
                    var first=OutsideInputJoint(a,b);var second=OutsideInputJoint(wire[i-1],wire[i]);
                    for(int x=0;x<first.Length;x+=2)for(int y=0;y<second.Length;y+=2)
                        if(SegmentDistanceSquared(first[x],first[x+1],second[y],second[y+1])<Clearance*Clearance)return false;
                    continue;
                }
                if(SegmentDistanceSquared(a,b,wire[i-1],wire[i])<Clearance*Clearance)return false;
            }
            return true;
        }
        private static WirePoint[] OutsideInputJoint(WirePoint a,WirePoint b)
        {
            float enter=0,exit=1;float[] start={a.X,a.Y},delta={b.X-a.X,b.Y-a.Y},min={-.032f,.188f},max={.032f,.24f};
            for(int axis=0;axis<2;axis++)
            {
                if(Math.Abs(delta[axis])<1e-9f){if(start[axis]<min[axis]||start[axis]>max[axis])return new[]{a,b};}
                else
                {
                    float u=(min[axis]-start[axis])/delta[axis],v=(max[axis]-start[axis])/delta[axis];if(u>v){float t=u;u=v;v=t;}
                    enter=Math.Max(enter,u);exit=Math.Min(exit,v);if(enter>exit)return new[]{a,b};
                }
            }
            var outside=new List<WirePoint>();if(enter>0){outside.Add(a);outside.Add(a+(b-a)*enter);}if(exit<1){outside.Add(a+(b-a)*exit);outside.Add(b);}return outside.ToArray();
        }
        internal static bool SelfIntersects(IList<WirePoint> path)
        {
            for(int i=1;i<path.Count;i++)
            {
                float gap=0;
                for(int j=i+1;j<path.Count;j++)
                {
                    if(j>i+1)gap+=(float)Math.Sqrt((path[j-1]-path[j-2]).Squared);
                    if(gap<Radius*2)continue;
                    if(SegmentDistanceSquared(path[i-1],path[i],path[j-1],path[j])<Radius*Radius*4)return true;
                }
            }
            return false;
        }
        private struct Entry {internal int Node;internal float Score;internal Entry(int n,float s){Node=n;Score=s;}}
        internal static float ProjectedCrowding(WirePoint a,WirePoint b,IList<WirePoint[]> wires,bool inputJoint)
        {
            const float spacing=.008f;
            float nearest=spacing*spacing;
            Func<WirePoint,WirePoint> flat=p=>new WirePoint(p.X,p.Y,0);
            foreach(var wire in wires)for(int i=1;i<wire.Length;i++)
            {
                var c=wire[i-1];var d=wire[i];
                var aa=flat(a);var bb=flat(b);var cc=flat(c);var dd=flat(d);
                if(BoundsDistanceSquared(aa,bb,cc,dd)>=nearest)continue;
                if(inputJoint&&InInputJoint(wire[0]))
                {
                    var first=OutsideInputJoint(aa,bb);var second=OutsideInputJoint(cc,dd);
                    for(int x=0;x<first.Length;x+=2)for(int y=0;y<second.Length;y+=2)
                        nearest=Math.Min(nearest,SegmentDistanceSquared(first[x],first[x+1],second[y],second[y+1]));
                }
                else nearest=Math.Min(nearest,SegmentDistanceSquared(aa,bb,cc,dd));
            }
            // A per-distance preference, not a collision prohibition: another
            // depth layer is still available if side-by-side space is exhausted.
            return Math.Max(0,1-nearest/(spacing*spacing));
        }
        internal static int ProjectedCrossings(WirePoint a,WirePoint b,IList<WirePoint[]> wires,bool inputJoint)
        {
            int count=0;float ux=b.X-a.X,uy=b.Y-a.Y;
            foreach(var wire in wires)for(int i=1;i<wire.Length;i++)
            {
                var c=wire[i-1];var d=wire[i];float vx=d.X-c.X,vy=d.Y-c.Y;
                float den=ux*vy-uy*vx;if(Math.Abs(den)<1e-10f)continue;
                float px=c.X-a.X,py=c.Y-a.Y;
                float t=(px*vy-py*vx)/den,s=(px*uy-py*ux)/den;
                if(t<-.00001f||t>1.00001f||s<-.00001f||s>1.00001f)continue;
                if(inputJoint&&InInputJoint(wire[0])&&InInputJoint(a+(b-a)*t))continue;
                count++;
            }
            return count;
        }
        // Per-search spatial index. Long rounded wires can contain hundreds of
        // segments; each grid edge only needs geometry in its immediate vicinity.
        internal sealed class Geometry
        {
            private const float CellSize=.012f;
            private struct Segment {internal WirePoint A,B;internal bool Joint;internal WirePoint[] Tails;}
            private sealed class Cell {internal readonly List<int> Segments=new List<int>(),Rects=new List<int>();}
            private readonly Dictionary<long,Cell> cells=new Dictionary<long,Cell>();
            private readonly List<Segment> segments=new List<Segment>();
            private readonly IList<WireRect> blocks;
            private readonly int[] seenSegments,seenRects;
            private readonly bool inputJoint;
            private int stamp;
            private static readonly WireRect JointRect=new WireRect(-.032f,.032f,.188f,.24f);
            private static WirePoint Flat(WirePoint p)=>new WirePoint(p.X,p.Y,0);
            private static int Bin(float value)=>(int)Math.Floor(value/CellSize);
            private static long Key(int x,int y)=>((long)x<<32)|(uint)y;
            private void Add(float left,float right,float bottom,float top,int id,bool rect)
            {
                for(int x=Bin(left);x<=Bin(right);x++)for(int y=Bin(bottom);y<=Bin(top);y++)
                {long key=Key(x,y);if(!cells.TryGetValue(key,out var cell))cells[key]=cell=new Cell();if(rect)cell.Rects.Add(id);else cell.Segments.Add(id);}
            }
            internal Geometry(IList<WireRect> blocks,IList<WirePoint[]> wires,bool inputJoint)
            {
                this.blocks=blocks;this.inputJoint=inputJoint;
                for(int i=0;i<blocks.Count;i++){var b=blocks[i];float m=Radius+.001f;Add(b.Left-m,b.Right+m,b.Bottom-m,b.Top+m,i,true);}
                foreach(var wire in wires)for(int i=1;i<wire.Length;i++)
                {
                    var a=wire[i-1];var b=wire[i];bool joint=InInputJoint(wire[0]);int id=segments.Count;
                    segments.Add(new Segment{A=a,B=b,Joint=joint,Tails=inputJoint&&joint?OutsideInputJoint(a,b):null});
                    Add(Math.Min(a.X,b.X)-.008f,Math.Max(a.X,b.X)+.008f,Math.Min(a.Y,b.Y)-.008f,Math.Max(a.Y,b.Y)+.008f,id,false);
                }
                seenSegments=new int[segments.Count];seenRects=new int[blocks.Count];
            }
            private int NextStamp(){if(stamp==int.MaxValue){Array.Clear(seenSegments,0,seenSegments.Length);Array.Clear(seenRects,0,seenRects.Length);stamp=0;}return ++stamp;}
            internal bool Clear(WirePoint a,WirePoint b)
            {
                int visit=NextStamp();WirePoint[] outside=null;bool touchesJoint=inputJoint&&SegmentHitsRect(a,b,JointRect,0);
                for(int x=Bin(Math.Min(a.X,b.X));x<=Bin(Math.Max(a.X,b.X));x++)for(int y=Bin(Math.Min(a.Y,b.Y));y<=Bin(Math.Max(a.Y,b.Y));y++)
                {
                    if(!cells.TryGetValue(Key(x,y),out var cell))continue;
                    foreach(int id in cell.Rects){if(seenRects[id]==visit)continue;seenRects[id]=visit;if(SegmentHitsRect(a,b,blocks[id],Radius+.001f))return false;}
                    foreach(int id in cell.Segments)
                    {
                        if(seenSegments[id]==visit)continue;seenSegments[id]=visit;var segment=segments[id];
                        if(BoundsDistanceSquared(a,b,segment.A,segment.B)>=Clearance*Clearance)continue;
                        if(inputJoint&&segment.Joint)
                        {
                            if(touchesJoint)
                            {
                                if(outside==null)outside=OutsideInputJoint(a,b);
                                for(int i=0;i<outside.Length;i+=2)for(int j=0;j<segment.Tails.Length;j+=2)
                                    if(SegmentDistanceSquared(outside[i],outside[i+1],segment.Tails[j],segment.Tails[j+1])<Clearance*Clearance)return false;
                            }
                            else for(int j=0;j<segment.Tails.Length;j+=2)if(SegmentDistanceSquared(a,b,segment.Tails[j],segment.Tails[j+1])<Clearance*Clearance)return false;
                        }
                        else if(SegmentDistanceSquared(a,b,segment.A,segment.B)<Clearance*Clearance)return false;
                    }
                }
                return true;
            }
            private static void Near(WirePoint a,WirePoint b,WirePoint c,WirePoint d,ref float nearest)
            {if(BoundsDistanceSquared(a,b,c,d)<nearest)nearest=Math.Min(nearest,SegmentDistanceSquared(a,b,c,d));}
            internal float Visual(WirePoint a,WirePoint b,float spread)
            {
                int visit=NextStamp(),crossings=0;float nearest=.008f*.008f;var aa=Flat(a);var bb=Flat(b);WirePoint[] outside=null;
                bool touchesJoint=inputJoint&&SegmentHitsRect(a,b,JointRect,0);float ux=b.X-a.X,uy=b.Y-a.Y;
                for(int x=Bin(Math.Min(a.X,b.X));x<=Bin(Math.Max(a.X,b.X));x++)for(int y=Bin(Math.Min(a.Y,b.Y));y<=Bin(Math.Max(a.Y,b.Y));y++)
                {
                    if(!cells.TryGetValue(Key(x,y),out var cell))continue;
                    foreach(int id in cell.Segments)
                    {
                        if(seenSegments[id]==visit)continue;seenSegments[id]=visit;var segment=segments[id];var c=Flat(segment.A);var d=Flat(segment.B);
                        float vx=d.X-c.X,vy=d.Y-c.Y,den=ux*vy-uy*vx;
                        if(Math.Abs(den)>=1e-10f)
                        {
                            float px=c.X-a.X,py=c.Y-a.Y,t=(px*vy-py*vx)/den,u=(px*uy-py*ux)/den;
                            if(t>=-.00001f&&t<=1.00001f&&u>=-.00001f&&u<=1.00001f&&!(inputJoint&&segment.Joint&&InInputJoint(a+(b-a)*t)))crossings++;
                        }
                        if(inputJoint&&segment.Joint)
                        {
                            if(touchesJoint)
                            {
                                if(outside==null)outside=OutsideInputJoint(aa,bb);
                                for(int i=0;i<outside.Length;i+=2)for(int j=0;j<segment.Tails.Length;j+=2)Near(outside[i],outside[i+1],Flat(segment.Tails[j]),Flat(segment.Tails[j+1]),ref nearest);
                            }
                            else for(int j=0;j<segment.Tails.Length;j+=2)Near(aa,bb,Flat(segment.Tails[j]),Flat(segment.Tails[j+1]),ref nearest);
                        }
                        else Near(aa,bb,c,d,ref nearest);
                    }
                }
                return crossings*.12f+Math.Max(0,1-nearest/(.008f*.008f))*Step*8f*spread;
            }
        }
        private sealed class Heap
        {
            readonly List<Entry> list=new List<Entry>();
            internal int Count=>list.Count;
            internal void Push(int node,float score){var e=new Entry(node,score);int i=list.Count;list.Add(e);while(i>0){int p=(i-1)/2;if(list[p].Score<=score)break;list[i]=list[p];i=p;}list[i]=e;}
            internal Entry Pop(){var result=list[0];var last=list[list.Count-1];list.RemoveAt(list.Count-1);if(list.Count==0)return result;int i=0;while(i*2+1<list.Count){int c=i*2+1;if(c+1<list.Count&&list[c+1].Score<list[c].Score)c++;if(list[c].Score>=last.Score)break;list[i]=list[c];i=c;}list[i]=last;return result;}
        }
        internal static WirePoint[] Find(WirePoint start,WirePoint end,IList<WireRect> blocks,IList<WirePoint[]> wires,bool inputJoint,int goalDirection=-1,int startDirection=-1)
        {
            const int nx=113,ny=153; // 3 mm lattice, including the usable border.
            Func<int,int,WirePoint> point=(x,y)=>new WirePoint(-HalfWidth+x*Step,-HalfHeight+y*Step,start.Z);
            int sx=(int)Math.Round((start.X+HalfWidth)/Step),sy=(int)Math.Round((start.Y+HalfHeight)/Step);
            int ex=(int)Math.Round((end.X+HalfWidth)/Step),ey=(int)Math.Round((end.Y+HalfHeight)/Step);
            if(sx<0||sx>=nx||ex<0||ex>=nx||sy<0||sy>=ny||ey<0||ey>=ny)return null;
            var geometry=new Geometry(blocks,wires,inputJoint);
            if(!geometry.Clear(start,point(sx,sy))||!geometry.Clear(point(ex,ey),end))return null;
            var usable=new sbyte[nx*ny];
            int count=nx*ny*4;var cost=new float[count];var parent=new int[count];var closed=new bool[count];var crossings=new float[count];var edges=new sbyte[count];
            for(int i=0;i<count;i++){cost[i]=float.PositiveInfinity;parent[i]=-1;crossings[i]=-1;}
            var heap=new Heap();for(int dir=0;dir<4;dir++){if(startDirection>=0&&dir!=startDirection)continue;int node=(sy*nx+sx)*4+dir;cost[node]=0;heap.Push(node,0);}
            int[] dx={1,0,-1,0},dy={0,1,0,-1};int goal=-1;
            while(heap.Count>0)
            {
                int n=heap.Pop().Node;if(closed[n])continue;closed[n]=true;
                int cell=n/4,x=cell%nx,y=cell/nx,old=n%4;if(x==ex&&y==ey&&(goalDirection<0||old==goalDirection)){goal=n;break;}
                for(int dir=0;dir<4;dir++)
                {
                    if(dir==(old+2)%4)continue;int xx=x+dx[dir],yy=y+dy[dir];if(xx<0||xx>=nx||yy<0||yy>=ny)continue;
                    int nextCell=yy*nx+xx;int next=nextCell*4+dir;if(closed[next])continue;
                    if(usable[nextCell]==0)usable[nextCell]=(sbyte)(geometry.Clear(point(xx,yy),point(xx,yy))?1:-1);
                    if(usable[nextCell]<0)continue;
                    if(edges[next]==0)edges[next]=(sbyte)(geometry.Clear(point(x,y),point(xx,yy))?1:-1);
                    if(edges[next]<0)continue;
                    // A gentle per-metre lane bias, not a large fee at every 3 mm
                    // step. Prefer fewer bends and avoid visual crossovers between
                    // depth layers; physical 3D clearance remains a hard constraint.
                    float laneCost=(dir%2==0)?Math.Max(0,Math.Max(start.Y,end.Y)-point(x,y).Y)*.08f*Step:0;
                    if(crossings[next]<0)
                    {
                        var p=point(xx,yy);float near=Math.Min((p-start).Squared,(p-end).Squared);
                        // Fixed terminal leads must be allowed to join cleanly.
                        // Fade lateral preference over 12-32 mm from each end.
                        float spread=Math.Min(1,Math.Max(0,(near-.000144f)/.00088f));
                        crossings[next]=geometry.Visual(point(x,y),p,spread);
                    }
                    float candidate=cost[n]+Step+laneCost+crossings[next]+(dir==old?0:.018f);if(candidate>=cost[next])continue;
                    cost[next]=candidate;parent[next]=n;heap.Push(next,candidate+(Math.Abs(xx-ex)+Math.Abs(yy-ey))*Step);
                }
            }
            if(goal<0)return null;
            var result=new List<WirePoint>{end};for(int n=goal;n>=0;n=parent[n]){int cell=n/4;result.Add(point(cell%nx,cell/nx));}result.Add(start);result.Reverse();
            // Remove only exactly collinear vertices; never shortcut across a corner.
            var simple=new List<WirePoint>();foreach(var p in result){if(simple.Count>0&&(p-simple[simple.Count-1]).Squared<1e-12f)continue;while(simple.Count>=2){var a=simple[simple.Count-1]-simple[simple.Count-2];var b=p-simple[simple.Count-1];float cross=a.X*b.Y-a.Y*b.X;if(Math.Abs(cross)>1e-10f||WirePoint.Dot(a,b)<0)break;simple.RemoveAt(simple.Count-1);}simple.Add(p);}return simple.ToArray();
        }
    }
}
