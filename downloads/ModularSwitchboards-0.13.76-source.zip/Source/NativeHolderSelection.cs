using System.Collections.Generic;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class NativeHolderSelection
    {
        // Keep original vertex IDs/order. No welding, role guesses or UV rebuilding.
        internal static List<int>[] Select(Vector3[] frameVertices,int[][] source)
        {
            var selected=new List<int>[source.Length];
            for(int role=0;role<source.Length;role++)
            {
                selected[role]=new List<int>();var triangles=source[role];
                for(int i=0;i<triangles.Length;i+=3)
                {
                    int a=triangles[i],b=triangles[i+1],c=triangles[i+2];
                    if(ApcBatteryRegion.Contains(frameVertices[a])&&ApcBatteryRegion.Contains(frameVertices[b])&&ApcBatteryRegion.Contains(frameVertices[c]))
                        selected[role].AddRange(new[]{a,b,c});
                }
            }
            return selected;
        }
    }
}
