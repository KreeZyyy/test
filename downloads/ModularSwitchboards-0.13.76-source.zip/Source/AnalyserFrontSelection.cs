using System;
using System.Collections.Generic;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class AnalyserFrontSelection
    {
        // Measured from the user's StructureCableAnalysizer reference: the grey
        // bezel + lightning occupy 68 triangles; green pane occupies six.
        // Keep original indices. Exclude the yellow plate, cable mounts and bolts.
        internal static int[][] Select(Vector3[] v,int[][] groups)
        {
            if(groups.Length!=3)throw new InvalidOperationException("Unexpected Cable Analyzer material layout");
            var result=new int[groups.Length][];
            for(int role=0;role<groups.Length;role++)
            {
                var indices=new List<int>();
                for(int i=0;i<groups[role].Length;i+=3)
                {
                    bool keep=role==0||role==2;
                    for(int j=0;j<3&&keep;j++)
                    {
                        var p=v[groups[role][i+j]];
                        keep=p.y>=.16744f&&p.x>=-.0651f&&p.x<=.0691f&&p.z>=-.1312f&&p.z<=.1295f;
                    }
                    if(keep)indices.AddRange(new[]{groups[role][i],groups[role][i+1],groups[role][i+2]});
                }
                result[role]=indices.ToArray();
            }
            if(result[0].Length!=68*3||result[1].Length!=0||result[2].Length!=6*3)
                throw new InvalidOperationException("Cable Analyzer front differs from measured reference; refusing guessed geometry");
            return result;
        }
    }
}
