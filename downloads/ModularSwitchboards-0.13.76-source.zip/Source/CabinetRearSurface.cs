using System;
using System.Linq;
using Assets.Scripts;
using Assets.Scripts.Objects.Electrical;
using UnityEngine;

namespace ModularSwitchboards
{
    internal static class CabinetRearSurface
    {
        // Housing slot 1 is reserved for the integrated rear extrusion. Other
        // renderers retain their existing slot 1 (e.g. interior screw heads).
        internal const int Role = 1;
        private static Material nativeMaterial;
        private static MaterialPropertyBlock nativeBlock;

        internal static void ApplyUv(Mesh mesh)
        {
            // Triangle 15 of the exported APC main mesh: the broad grey side.
            // These are the actual native UVs, not an arbitrary palette shade.
            var a = new Vector2(.106437430f,.399473429f);
            var b = new Vector2(.108108371f,.411918551f);
            var c = new Vector2(.108108371f,.399473429f);
            var center = (a+b+c)/3f;
            var uv = mesh.uv; var vertices = mesh.vertices;
            foreach(int index in mesh.GetTriangles(Role))
            {
                var p = vertices[index];
                uv[index] = center + (b-a)*(.08f*Mathf.Clamp(p.x/.4f,-.5f,.5f))
                    + (c-a)*(.08f*Mathf.Clamp(p.y/.5f,-.5f,.5f));
            }
            mesh.uv=uv;mesh.RecalculateTangents();
        }

        internal static void Restore(MeshRenderer destination)
        {
            if(nativeMaterial==null)
            {
                var apc=WorldManager.Instance.SourcePrefabs.OfType<AreaPowerControl>()
                    .First(p=>p.PrefabName=="StructureAreaPowerControl");
                var source=apc.GetComponentsInChildren<MeshRenderer>(true).First(r=>r.name==apc.PrefabName);
                nativeMaterial=new Material(source.sharedMaterials[0]){name="Switchboards.NativeApcGreyRear"};
                nativeBlock=new MaterialPropertyBlock();source.GetPropertyBlock(nativeBlock,0);
                if(nativeBlock.isEmpty)source.GetPropertyBlock(nativeBlock);
                Debug.Log("[Modular Switchboards] Rear surface copies APC material, shader, textures and property block; native grey-side UV sample.");
            }
            var materials=destination.sharedMaterials;
            materials[Role]=nativeMaterial;destination.sharedMaterials=materials;
            destination.SetPropertyBlock(nativeBlock,Role);
        }
    }
}
