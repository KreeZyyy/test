using Assets.Scripts;
using Assets.Scripts.UI;
using UnityEngine;

namespace ModularSwitchboards
{
    // Runs when native cursor setup instantiates the independent blueprint.
    public sealed class CabinetBlueprint : MonoBehaviour
    {
        private void Awake()
        {
            var wireframe = GetComponent<Wireframe>();
            if (wireframe == null || wireframe.BlueprintRenderer == null) return;
            var cursor = CursorManager.Instance;
            var shader = cursor == null ? null : cursor.CursorShader;
            if (shader == null || !shader.isSupported)
            {
                Debug.LogWarning("[Modular Switchboards] Cursor shader unavailable; retaining native cabinet preview material.");
                return;
            }
            var material = new Material(shader) { color = Color.white };
            if (material.HasProperty("_Offset")) material.SetFloat("_Offset", -300f);
            if (material.HasProperty("_MainTex")) material.mainTexture = null;
            wireframe.BlueprintRenderer.sharedMaterial = material;
            Debug.Log("[Modular Switchboards] Native cursor shader applied: " + shader.name);
        }
    }
}
