using System.Collections.Generic;
using UnityEngine;

namespace ModularSwitchboards
{
    internal static class BatteryAperture
    {
        private struct Point
        {
            internal Vector3 P,N;
            internal Point(Vector3 p,Vector3 n){P=p;N=n;}
        }
        // Cut the hole out of one rounded surface. Joining separate rounded bars
        // adds bevels across the face and produces unwanted panel seams.
        internal static void Box(List<Vector3> vertices,List<Vector3> normals,List<int> indices,Vector3 center,Vector3 size,float radius,float holeX,float holeY,float cornerX=0,float cornerY=0)
        {
            var v=new List<Vector3>();var n=new List<Vector3>();var t=new List<int>();
            RoundedGeometry.Box(v,n,t,center,size,radius);
            for(int i=0;i<t.Count;i+=3)
            {
                var remaining=new List<Point>{new Point(v[t[i]],n[t[i]]),new Point(v[t[i+1]],n[t[i+1]]),new Point(v[t[i+2]],n[t[i+2]])};
                for(int plane=0;plane<(cornerX>0?8:4)&&remaining.Count>0;plane++)
                {
                    var outside=Clip(remaining,plane,center.x,holeX,holeY,cornerX,cornerY,true);
                    Emit(outside,vertices,normals,indices);
                    remaining=Clip(remaining,plane,center.x,holeX,holeY,cornerX,cornerY,false);
                }
            }
        }
        internal static void Walls(List<Vector3> vertices,List<Vector3> normals,List<int> indices,Vector3 center,Vector3 size,float holeX,float holeY,float cornerX=0,float cornerY=0)
        {
            float x=holeX*.5f,y=holeY*.5f,z=size.z*.5f;
            System.Action<Vector3,Vector3,Vector3,Vector3,Vector3> quad=(a,b,c,d,n)=>
            {
                int start=vertices.Count;vertices.AddRange(new[]{center+a,center+b,center+c,center+d});normals.AddRange(new[]{n,n,n,n});
                var cross=Vector3.Cross(b-a,c-a);float facing=cross.x*n.x+cross.y*n.y+cross.z*n.z;
                indices.AddRange(facing>0?new[]{start,start+1,start+2,start,start+2,start+3}:new[]{start,start+2,start+1,start,start+3,start+2});
            };
            if(cornerX>0&&cornerY>0)
            {
                var ring=new[]{new Vector3(-x+cornerX,-y,0),new Vector3(x-cornerX,-y,0),new Vector3(x,-y+cornerY,0),new Vector3(x,y-cornerY,0),new Vector3(x-cornerX,y,0),new Vector3(-x+cornerX,y,0),new Vector3(-x,y-cornerY,0),new Vector3(-x,-y+cornerY,0)};
                for(int i=0;i<ring.Length;i++)
                {
                    var a=ring[i];var b=ring[(i+1)%ring.Length];var e=b-a;
                    quad(a+new Vector3(0,0,-z),b+new Vector3(0,0,-z),b+new Vector3(0,0,z),a+new Vector3(0,0,z),new Vector3(-e.y,e.x,0).normalized);
                }
                return;
            }
            quad(new Vector3(-x,-y,-z),new Vector3(x,-y,-z),new Vector3(x,-y,z),new Vector3(-x,-y,z),Vector3.up);
            quad(new Vector3(-x,y,-z),new Vector3(x,y,-z),new Vector3(x,y,z),new Vector3(-x,y,z),Vector3.down);
            quad(new Vector3(-x,-y,-z),new Vector3(-x,y,-z),new Vector3(-x,y,z),new Vector3(-x,-y,z),Vector3.right);
            quad(new Vector3(x,-y,-z),new Vector3(x,y,-z),new Vector3(x,y,z),new Vector3(x,-y,z),Vector3.left);
        }
        private static float Distance(Point p,int plane,float x,float w,float h,float cx,float cy)
        {
            if(plane>=4)
            {
                float sx=(plane==4||plane==7)?1:-1,sy=(plane==4||plane==5)?1:-1;
                return sx*(p.P.x-x)/cx+sy*p.P.y/cy-(w/(2*cx)+h/(2*cy)-1);
            }
            switch(plane){case 0:return x-w*.5f-p.P.x;case 1:return p.P.x-x-w*.5f;case 2:return -h*.5f-p.P.y;default:return p.P.y-h*.5f;}
        }
        private static List<Point> Clip(List<Point> polygon,int plane,float x,float w,float h,float cx,float cy,bool outside)
        {
            var result=new List<Point>();if(polygon.Count==0)return result;
            var a=polygon[polygon.Count-1];float da=Distance(a,plane,x,w,h,cx,cy)*(outside?1:-1);
            foreach(var b in polygon)
            {
                float db=Distance(b,plane,x,w,h,cx,cy)*(outside?1:-1);
                if((da>=0)!=(db>=0))
                {
                    float f=da/(da-db);result.Add(new Point(a.P+(b.P-a.P)*f,(a.N+(b.N-a.N)*f).normalized));
                }
                if(db>=0)result.Add(b);a=b;da=db;
            }
            return result;
        }
        private static void Emit(List<Point> polygon,List<Vector3> vertices,List<Vector3> normals,List<int> indices)
        {
            for(int i=1;i+1<polygon.Count;i++)
            {
                var a=polygon[0];var b=polygon[i];var c=polygon[i+1];var cross=Vector3.Cross(b.P-a.P,c.P-a.P);
                if(cross.x*cross.x+cross.y*cross.y+cross.z*cross.z<1e-20f)continue;
                int start=vertices.Count;vertices.AddRange(new[]{a.P,b.P,c.P});normals.AddRange(new[]{a.N,b.N,c.N});indices.AddRange(new[]{start,start+1,start+2});
            }
        }
    }
}
