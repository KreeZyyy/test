using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;
namespace ModularSwitchboards
{
    // Private ink material: transparent atlas pixels are discarded and visible
    // glyph fragments use the scene depth buffer, including the moving door.
    internal static class DepthLabelText
    {
        private static readonly Dictionary<Font,Material> Materials=new Dictionary<Font,Material>();
        internal static Material For(Font font)
        {
            if(!Materials.TryGetValue(font,out var material))
            {
                var shader=Shader.Find("Standard");
                if(shader==null||!shader.isSupported)throw new InvalidOperationException("Depth label text shader unavailable");
                material=new Material(shader){name="Switchboards.DepthLabelInk",color=Color.black};
                material.SetFloat("_Mode",1f);material.SetOverrideTag("RenderType","TransparentCutout");
                material.SetFloat("_Cutoff",.2f);material.SetInt("_SrcBlend",(int)BlendMode.One);material.SetInt("_DstBlend",(int)BlendMode.Zero);
                material.SetInt("_ZWrite",1);material.renderQueue=(int)RenderQueue.AlphaTest;
                material.EnableKeyword("_ALPHATEST_ON");material.DisableKeyword("_ALPHABLEND_ON");material.DisableKeyword("_ALPHAPREMULTIPLY_ON");
                material.SetFloat("_Glossiness",0f);material.SetFloat("_Metallic",0f);material.SetFloat("_SpecularHighlights",0f);material.EnableKeyword("_SPECULARHIGHLIGHTS_OFF");
                Materials.Add(font,material);
            }
            // Unity can replace a dynamic font atlas when new glyphs are requested.
            material.mainTexture=font.material.mainTexture;
            return material;
        }
        internal static void Apply(TextMesh text)
        {
            var renderer=text.GetComponent<MeshRenderer>();renderer.sharedMaterial=For(text.font);
            renderer.shadowCastingMode=ShadowCastingMode.Off;renderer.receiveShadows=false;
        }
    }
}
