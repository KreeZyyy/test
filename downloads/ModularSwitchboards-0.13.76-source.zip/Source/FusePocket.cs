using System.Collections.Generic;
using UnityEngine;

namespace ModularSwitchboards
{
    // One closed chamfered insert: front rim, four sides and a solid rear floor.
    internal static class FusePocket
    {
        internal const float Rear=.032f,Front=.0638f;
        internal const float HalfX=.00575f,HalfY=.0212f;
        internal static void Add(List<Vector3> v,List<Vector3> n,List<int> t)
        {
            var outer=Ring(.00622f,.02195f,.00065f);
            var inner=Ring(HalfX,HalfY,.00065f);
            for(int i=0;i<8;i++)
            {
                int j=(i+1)%8;
                var outward=new Vector3((outer[i].x+outer[j].x)*.5f,(outer[i].y+outer[j].y)*.5f,0);
                Face(v,n,t,At(outer[i],Rear-.002f),At(outer[j],Rear-.002f),At(outer[j],Front),At(outer[i],Front),outward);
                Face(v,n,t,At(inner[i],Rear),At(inner[j],Rear),At(inner[j],Front),At(inner[i],Front),outward*-1f);
                Face(v,n,t,At(outer[i],Front),At(outer[j],Front),At(inner[j],Front),At(inner[i],Front),Vector3.forward);
                Triangle(v,n,t,new Vector3(0,0,Rear),At(inner[i],Rear),At(inner[j],Rear),Vector3.forward);
                Triangle(v,n,t,new Vector3(0,0,Rear-.002f),At(outer[i],Rear-.002f),At(outer[j],Rear-.002f),Vector3.back);
            }
        }
        private static Vector3[] Ring(float x,float y,float r)=>new[]{
            new Vector3(-x+r,-y,0),new Vector3(x-r,-y,0),new Vector3(x,-y+r,0),new Vector3(x,y-r,0),
            new Vector3(x-r,y,0),new Vector3(-x+r,y,0),new Vector3(-x,y-r,0),new Vector3(-x,-y+r,0)};
        private static Vector3 At(Vector3 p,float z)=>new Vector3(p.x,p.y,z);
        private static void Face(List<Vector3> v,List<Vector3> n,List<int> t,Vector3 a,Vector3 b,Vector3 c,Vector3 d,Vector3 outward)
        {Triangle(v,n,t,a,b,c,outward);Triangle(v,n,t,a,c,d,outward);}
        private static void Triangle(List<Vector3> v,List<Vector3> n,List<int> t,Vector3 a,Vector3 b,Vector3 c,Vector3 outward)
        {
            var cross=Vector3.Cross(b-a,c-a);
            if(cross.x*outward.x+cross.y*outward.y+cross.z*outward.z<0){var swap=b;b=c;c=swap;}
            int start=v.Count;v.AddRange(new[]{a,b,c});var normal=Vector3.Cross(b-a,c-a).normalized;
            n.AddRange(new[]{normal,normal,normal});t.AddRange(new[]{start,start+1,start+2});
        }
    }
}
