using System.Collections.Generic;
using UnityEngine;
namespace ModularSwitchboards
{
    // Private matte clones for cabinet sheet metal. Preserve paint/texture and
    // never change borrowed game materials, LED lenses, or module surfaces.
    internal static class CabinetMatteSurface
    {
        internal static bool IsPanel(string name)=>name=="Frame"||name=="Housing"||name=="Door"||name=="DoorReturnLip"||name=="Interior"||name=="InnerCoverModel";
        private static readonly Dictionary<Material,Material> Copies=new Dictionary<Material,Material>();
        private static readonly HashSet<Material> Owned=new HashSet<Material>();
        internal static void Apply(MeshRenderer renderer)
        {
            var materials=renderer.sharedMaterials;
            for(int i=0;i<materials.Length;i++)
            {
                var source=materials[i];if(source==null||Owned.Contains(source))continue;
                if(!Copies.TryGetValue(source,out var matte))
                {
                    matte=new Material(source){name="Switchboards.MattePanel."+source.name};
                    foreach(string property in new[]{"_Glossiness","_GlossMapScale","_Metallic","_SpecularHighlights","_GlossyReflections"})
                        if(matte.HasProperty(property))matte.SetFloat(property,0f);
                    matte.EnableKeyword("_SPECULARHIGHLIGHTS_OFF");matte.EnableKeyword("_GLOSSYREFLECTIONS_OFF");
                    Copies[source]=matte;Owned.Add(matte);
                }
                materials[i]=matte;
            }
            renderer.sharedMaterials=materials;
        }
    }
}
