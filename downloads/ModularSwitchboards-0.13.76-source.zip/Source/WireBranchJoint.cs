using System;
using System.Collections.Generic;
using System.Linq;
namespace ModularSwitchboards
{
    // Deliberate fork only in the original output's lead pocket.
    // Other wires and all device constraints remain hard obstacles.
    internal static class WireBranchJoint
    {
        internal static IEnumerable<WirePoint[]> Outside(WirePoint[] path,WireRect box)
        {
            for(int i=1;i<path.Length;i++)foreach(var segment in Outside(path[i-1],path[i],box))yield return segment;
        }
        private static IEnumerable<WirePoint[]> Outside(WirePoint a,WirePoint b,WireRect box)
        {
            float lo=0,hi=1,dx=b.X-a.X,dy=b.Y-a.Y;
            if(!Clip(-dx,a.X-box.Left,ref lo,ref hi)||!Clip(dx,box.Right-a.X,ref lo,ref hi)||
               !Clip(-dy,a.Y-box.Bottom,ref lo,ref hi)||!Clip(dy,box.Top-a.Y,ref lo,ref hi))
            {yield return new[]{a,b};yield break;}
            if(lo>0)yield return new[]{a,a+(b-a)*lo};
            if(hi<1)yield return new[]{a+(b-a)*hi,b};
        }
        private static bool Clip(float p,float q,ref float lo,ref float hi)
        {
            if(Math.Abs(p)<1e-12f)return q>=0;
            float t=q/p;if(p<0){if(t>hi)return false;lo=Math.Max(lo,t);}else{if(t<lo)return false;hi=Math.Min(hi,t);}return true;
        }
        internal static bool Clear(WirePoint a,WirePoint b,IList<WirePoint[]> shared,WireRect box)
        {
            if(shared.Count==0)return true;
            var occupied=shared.SelectMany(w=>Outside(w,box)).ToList();
            foreach(var segment in Outside(a,b,box))if(!WireRouting.Clear(segment[0],segment[1],new List<WireRect>(),occupied,false))return false;
            return true;
        }
    }
}
