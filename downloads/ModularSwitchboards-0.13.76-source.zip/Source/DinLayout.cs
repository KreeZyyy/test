namespace ModularSwitchboards
{
    // Shared dimensional rules; future cabinets can supply a different width/row layout.
    internal static class DinLayout
    {
        internal const float ModulePitch = .018f; // Existing cabinet rail-grid pitch, preserved for saves.
        internal const float SlotPitch = .0405f;
        internal const float ModuleHalfWidth = .0198f;
        internal const float ModuleHalfHeight = .050625f;
        internal const float CabinetInnerWidth = .35f;
        internal const float EndClearance = .01f;
        internal const int RowGridIndex = 60; // Grid3 uses tenths: 60 = six 18 mm steps.
        internal const int FirstModuleSlot=1; // Keep saved grid coordinates; leave the hinge-side slot empty.
        internal static int FullModuleCount(float width)=>(int)((width-2f*EndClearance)/SlotPitch);
        internal static int ModuleCount(float width) => FullModuleCount(width)-FirstModuleSlot;
        internal static float RailLength(float width) => ModuleCount(width) * SlotPitch;
        internal static int SnapRow(int y) => y >= 0 ? RowGridIndex : -RowGridIndex;
        internal static bool IsRailPosition(int x, int y, int z, int rotation)
            => x == 0 && (y == RowGridIndex || y == -RowGridIndex) && z == 0 && rotation == 0;
    }
}
