using System.Collections.Generic;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class DoorIsolatorGeometry
    {
        internal static Mesh Dish()
        {
            // Closed radial section: back plate, raised rim, flat recessed face.
            var r=new[]{0f,.0305f,.0305f,.027f,.027f,0f};
            var z=new[]{.006f,.006f,.014f,.014f,.008f,.008f};
            var v=new List<Vector3>();var n=new List<Vector3>();var t=new List<int>();
            for(int j=0;j<r.Length-1;j++)
            {
                float dr=r[j+1]-r[j],dz=z[j+1]-z[j],length=(float)System.Math.Sqrt(dr*dr+dz*dz);
                for(int i=0;i<32;i++)
                {
                    float a=i*Mathf.PI/16,b=(i+1)*Mathf.PI/16;
                    var na=new Vector3(dz/length*Mathf.Cos(a),dz/length*Mathf.Sin(a),-dr/length);
                    var nb=new Vector3(dz/length*Mathf.Cos(b),dz/length*Mathf.Sin(b),-dr/length);
                    int p=v.Count;
                    v.AddRange(new[]{new Vector3(r[j]*Mathf.Cos(a),r[j]*Mathf.Sin(a),z[j]),new Vector3(r[j]*Mathf.Cos(b),r[j]*Mathf.Sin(b),z[j]),new Vector3(r[j+1]*Mathf.Cos(b),r[j+1]*Mathf.Sin(b),z[j+1]),new Vector3(r[j+1]*Mathf.Cos(a),r[j+1]*Mathf.Sin(a),z[j+1])});
                    n.AddRange(new[]{na,nb,nb,na});
                    // Winding follows the radial section outward.
                    if(r[j]!=0)t.AddRange(new[]{p,p+1,p+2});
                    if(r[j+1]!=0)t.AddRange(new[]{p,p+2,p+3});
                }
            }
            var flatV=new List<Vector3>();var flatN=new List<Vector3>();var flatT=new List<int>();
            for(int k=0;k<t.Count;k+=3)
            {
                var a=v[t[k]];var b=v[t[k+1]];var c=v[t[k+2]];
                float ux=b.x-a.x,uy=b.y-a.y,uz=b.z-a.z,vx=c.x-a.x,vy=c.y-a.y,vz=c.z-a.z;
                var normal=new Vector3(uy*vz-uz*vy,uz*vx-ux*vz,ux*vy-uy*vx);float len=(float)System.Math.Sqrt(normal.x*normal.x+normal.y*normal.y+normal.z*normal.z);
                normal=new Vector3(normal.x/len,normal.y/len,normal.z/len);int offset=flatV.Count;
                flatV.AddRange(new[]{a,b,c});flatN.AddRange(new[]{normal,normal,normal});flatT.AddRange(new[]{offset,offset+1,offset+2});
            }
            return Finish("Rotary isolator recessed dish",flatV,flatN,flatT);
        }
        // Continuous rim; the white inserts sit on the inner flat face.
        private static float Surface(float radius)=>.008f;
        internal static Mesh Insert(bool on)
        {
            var v=new List<Vector3>();var n=new List<Vector3>();var t=new List<int>();
            float center=0;
            var radii=new[]{.0195f,.022f,.0262f};
            for(int j=0;j<2;j++)for(int i=0;i<64;i++)
            {
                float a=center+(i*360f/64)*Mathf.PI/180f,b=a+360f/64*Mathf.PI/180f;int p=v.Count;
                foreach(var pair in new[]{new[]{radii[j],a},new[]{radii[j+1],a},new[]{radii[j+1],b},new[]{radii[j],b}})
                    v.Add(new Vector3(pair[0]*Mathf.Cos(pair[1]),pair[0]*Mathf.Sin(pair[1]),Surface(pair[0])+.00035f));
                t.AddRange(new[]{p,p+1,p+2,p,p+2,p+3});
            }
            return SurfaceMesh("Rotary continuous white window backing insert",v,t);
        }
        internal static Mesh Mark(bool on)
        {
            var v=new List<Vector3>();var t=new List<int>();
            if(on)
            {
                foreach(var p in new[]{new[]{-.0008f,.0208f},new[]{.0008f,.0208f},new[]{.0008f,.0255f},new[]{-.0008f,.0255f}})
                    v.Add(new Vector3(p[0],p[1],Surface((float)System.Math.Sqrt(p[0]*p[0]+p[1]*p[1]))+.00065f));
                t.AddRange(new[]{0,1,2,0,2,3});
            }
            else for(int i=0;i<24;i++)
            {
                int offset=v.Count;
                foreach(var p in new[]{new[]{i*Mathf.PI/12,1f},new[]{i*Mathf.PI/12,.57f},new[]{(i+1)*Mathf.PI/12,.57f},new[]{(i+1)*Mathf.PI/12,1f}})
                {
                    float x=.0232f+Mathf.Cos(p[0])*.0021f*p[1],y=Mathf.Sin(p[0])*.0027f*p[1];
                    v.Add(new Vector3(x,y,Surface((float)System.Math.Sqrt(x*x+y*y))+.00065f));
                }
                // Elliptical annulus is traversed inner-to-outer with upward winding.
                t.AddRange(new[]{offset,offset+2,offset+1,offset,offset+3,offset+2});
            }
            return SurfaceMesh(on?"Rotary I mark":"Rotary 0 mark",v,t);
        }
        private static Mesh SurfaceMesh(string name,List<Vector3> positions,List<int> indices)
        {
            var v=new List<Vector3>();var n=new List<Vector3>();var t=new List<int>();
            for(int i=0;i<indices.Count;i+=3)
            {
                var a=positions[indices[i]];var b=positions[indices[i+1]];var c=positions[indices[i+2]];
                float ux=b.x-a.x,uy=b.y-a.y,uz=b.z-a.z,vx=c.x-a.x,vy=c.y-a.y,vz=c.z-a.z;
                var normal=new Vector3(uy*vz-uz*vy,uz*vx-ux*vz,ux*vy-uy*vx);float len=(float)System.Math.Sqrt(normal.x*normal.x+normal.y*normal.y+normal.z*normal.z);
                normal=new Vector3(normal.x/len,normal.y/len,normal.z/len);int p=v.Count;
                v.AddRange(new[]{a,b,c});n.AddRange(new[]{normal,normal,normal});t.AddRange(new[]{p,p+1,p+2});
            }
            return Finish(name,v,n,t);
        }
        // A single opening follows the pointer; all other fixed position marks
        // are hidden by this thin red shutter on the sloping bowl wall.
        internal const float WindowHalfAngle=18f;
        internal static Mesh WindowMask()
        {
            const int steps=72;
            var v=new List<Vector3>();var t=new List<int>();
            var radii=new[]{.019f,.022f,.027f};
            System.Func<float,float,float,Vector3> point=(r,a,offset)=>new Vector3(r*Mathf.Cos(a),r*Mathf.Sin(a),Surface(r)+offset);
            System.Action<Vector3,Vector3,Vector3,Vector3,bool> quad=(a,b,c,d,reverse)=>{
                int i=v.Count;v.AddRange(new[]{a,b,c,d});t.AddRange(reverse?new[]{i,i+2,i+1,i,i+3,i+2}:new[]{i,i+1,i+2,i,i+2,i+3});};
            float start=(90+WindowHalfAngle)*Mathf.PI/180f,span=(360-2*WindowHalfAngle)*Mathf.PI/180f;
            for(int k=0;k<steps;k++)
            {
                float a=start+span*k/steps,b=start+span*(k+1)/steps;
                for(int j=0;j<2;j++)
                {
                    float inner=radii[j],outer=radii[j+1];
                    quad(point(inner,a,.0038f),point(outer,a,.0038f),point(outer,b,.0038f),point(inner,b,.0038f),false);
                    quad(point(inner,a,.0018f),point(outer,a,.0018f),point(outer,b,.0018f),point(inner,b,.0018f),true);
                    if(k==0)quad(point(inner,a,.0018f),point(outer,a,.0018f),point(outer,a,.0038f),point(inner,a,.0038f),false);
                    if(k==steps-1)quad(point(inner,b,.0018f),point(outer,b,.0018f),point(outer,b,.0038f),point(inner,b,.0038f),true);
                }
                int center=v.Count;v.AddRange(new[]{point(0,a,.0038f),point(radii[0],a,.0038f),point(radii[0],b,.0038f),point(0,a,.0018f),point(radii[0],a,.0018f),point(radii[0],b,.0018f)});
                t.AddRange(new[]{center,center+1,center+2,center+3,center+5,center+4});
                quad(point(radii[2],a,.0018f),point(radii[2],b,.0018f),point(radii[2],b,.0038f),point(radii[2],a,.0038f),false);
            }
            // Fill the center up to the same front plane as the annular shutter.
            // Only the outer position window remains open; there is no inner step.
            for(int k=0;k<8;k++)
            {
                float a=(90-WindowHalfAngle+2*WindowHalfAngle*k/8)*Mathf.PI/180f,b=(90-WindowHalfAngle+2*WindowHalfAngle*(k+1)/8)*Mathf.PI/180f;
                int center=v.Count;v.AddRange(new[]{point(0,a,.0038f),point(radii[0],a,.0038f),point(radii[0],b,.0038f),point(0,a,.0018f),point(radii[0],a,.0018f),point(radii[0],b,.0018f)});
                t.AddRange(new[]{center,center+1,center+2,center+3,center+5,center+4});
                quad(point(radii[0],a,.0018f),point(radii[0],b,.0018f),point(radii[0],b,.0038f),point(radii[0],a,.0038f),false);
            }
            return SurfaceMesh("Rotary single-window red shutter",v,t);
        }
        internal static Mesh Grip()
        {
            // Asymmetric pointed handle, with a long lower grip and bevelled face.
            var x=new[]{0f,-.006f,-.006f,.006f,.006f};
            var y=new[]{.0185f,.012f,-.023f,-.023f,.012f};
            var v=new List<Vector3>();var n=new List<Vector3>();var t=new List<int>();
            System.Action<Vector3,Vector3,Vector3> tri=(a,b,c)=>{
                float ux=b.x-a.x,uy=b.y-a.y,uz=b.z-a.z,vx=c.x-a.x,vy=c.y-a.y,vz=c.z-a.z;
                var normal=new Vector3(uy*vz-uz*vy,uz*vx-ux*vz,ux*vy-uy*vx);float len=(float)System.Math.Sqrt(normal.x*normal.x+normal.y*normal.y+normal.z*normal.z);
                normal=new Vector3(normal.x/len,normal.y/len,normal.z/len);int p=v.Count;v.AddRange(new[]{a,b,c});n.AddRange(new[]{normal,normal,normal});t.AddRange(new[]{p,p+1,p+2});};
            for(int i=0;i<x.Length;i++)
            {
                int j=(i+1)%x.Length;
                var a=new Vector3(x[i],y[i],.0118f);var b=new Vector3(x[j],y[j],.0118f);
                var c=new Vector3(x[j],y[j],.018f);var d=new Vector3(x[i],y[i],.018f);
                var e=new Vector3(x[j],y[j],.020f);var f=new Vector3(x[i],y[i],.020f);
                tri(a,b,c);tri(a,c,d);tri(d,c,e);tri(d,e,f);
                tri(new Vector3(0,0,.020f),f,e);tri(new Vector3(0,0,.0118f),b,a);
            }
            return Finish("Rotary isolator simple pointer grip",v,n,t);
        }
        private static Mesh Finish(string name,List<Vector3> v,List<Vector3> n,List<int> t)
        {for(int i=0;i<v.Count;i++){var point=v[i];v[i]=new Vector3(point.x*.75f,point.y*.75f,point.z);}
            for(int i=0;i<n.Count;i++){var normal=n[i];float x=normal.x/.75f,y=normal.y/.75f,z=normal.z;float length=(float)System.Math.Sqrt(x*x+y*y+z*z);n[i]=new Vector3(x/length,y/length,z/length);}
            var mesh=new Mesh{name=name};mesh.SetVertices(v);mesh.SetNormals(n);mesh.SetTriangles(t,0);mesh.RecalculateBounds();return mesh;}
    }
}
