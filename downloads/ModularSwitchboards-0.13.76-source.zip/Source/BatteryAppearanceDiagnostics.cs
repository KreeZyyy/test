using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Assets.Scripts;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Electrical;
using UnityEngine;

namespace ModularSwitchboards
{
    // Bounded metadata only: no GPU mesh readback, textures or full vertex export.
    internal static class BatteryAppearanceDiagnostics
    {
        [Serializable] internal sealed class Report { public string version=SwitchboardsMod.Version; public List<Sample> samples=new List<Sample>(); }
        [Serializable] internal sealed class Sample
        {
            public string cell,slotKey,slotName,nativeKey,nativeName;public int frame,slotHash,nativeHash;public float charge;
            public bool sameCellMesh;public string liveUvHash,prefabUvHash;
            public List<Pose> transforms=new List<Pose>();public List<Surface> surfaces=new List<Surface>();public List<Hit> colliders=new List<Hit>();
        }
        [Serializable] internal sealed class Pose { public string label,path; public Vector3 position,scale,worldScale;public Quaternion rotation;public float determinant; }
        [Serializable] internal sealed class Hit {public string path,type;public bool enabled,trigger;public Vector3 center,size;}
        [Serializable] internal sealed class Surface
        {
            public string label,path,mesh,uvHash,shadowCasting;public bool enabled,active,readable,receiveShadows;public int meshId,vertices,submeshes,uvCount;public Vector2 uvMin,uvMax;public Vector3 localCenter,localSize,worldCenter,worldSize;
            public List<MaterialInfo> materials=new List<MaterialInfo>();
        }
        [Serializable] internal sealed class MaterialInfo
        {
            public int index,id,textureId;public string name,shader,texture,wrapMode;public string[] keywords;public bool instancing,globalEmpty,indexEmpty;public Vector2 textureScale,textureOffset;
            public List<ApcRearDiagnostics.Property> global,properties;
        }
        private static readonly HashSet<string> seen=new HashSet<string>();
        private static readonly Report report=new Report();
        private static string UvHash(Mesh mesh)
        {
            if(mesh==null||!mesh.isReadable)return "unreadable";
            var uv=mesh.uv;unchecked{uint hash=2166136261;foreach(var p in uv){hash=(hash^(uint)p.x.GetHashCode())*16777619;hash=(hash^(uint)p.y.GetHashCode())*16777619;}return hash.ToString("X8")+":"+uv.Length;}
        }
        private static string PathOf(Transform t) => t.parent==null?t.name:PathOf(t.parent)+"/"+t.name;
        private static void Inspect(Sample sample,Transform root,string label)
        {
            foreach(var t in root.GetComponentsInChildren<Transform>(true).Take(96))
                sample.transforms.Add(new Pose{label=label,path=PathOf(t),position=t.localPosition,rotation=t.localRotation,scale=t.localScale,worldScale=t.lossyScale,determinant=t.localToWorldMatrix.determinant});
            foreach(var renderer in root.GetComponentsInChildren<Renderer>(true).Take(48))
            {
                var filter=renderer.GetComponent<MeshFilter>();var mesh=filter==null?(renderer as SkinnedMeshRenderer)?.sharedMesh:filter.sharedMesh;
                var item=new Surface{label=label,path=PathOf(renderer.transform),enabled=renderer.enabled,active=renderer.gameObject.activeInHierarchy,mesh=mesh==null?"":mesh.name,
                    readable=mesh!=null&&mesh.isReadable,vertices=mesh==null?0:mesh.vertexCount,submeshes=mesh==null?0:mesh.subMeshCount,localCenter=mesh==null?Vector3.zero:mesh.bounds.center,localSize=mesh==null?Vector3.zero:mesh.bounds.size,worldCenter=renderer.bounds.center,worldSize=renderer.bounds.size};
                item.meshId=mesh==null?0:mesh.GetInstanceID();item.uvHash=UvHash(mesh);item.shadowCasting=renderer.shadowCastingMode.ToString();item.receiveShadows=renderer.receiveShadows;
                if(mesh!=null&&mesh.isReadable){var uv=mesh.uv;item.uvCount=uv.Length;if(uv.Length>0){item.uvMin=new Vector2(uv.Min(v=>v.x),uv.Min(v=>v.y));item.uvMax=new Vector2(uv.Max(v=>v.x),uv.Max(v=>v.y));}}
                var global=new MaterialPropertyBlock();renderer.GetPropertyBlock(global);var materials=renderer.sharedMaterials;
                for(int i=0;i<materials.Length;i++)
                {
                    var mat=materials[i];if(mat==null)continue;var block=new MaterialPropertyBlock();renderer.GetPropertyBlock(block,i);
                    item.materials.Add(new MaterialInfo{index=i,id=mat.GetInstanceID(),name=mat.name,shader=mat.shader==null?"":mat.shader.name,texture=mat.mainTexture==null?"":mat.mainTexture.name,
                        textureId=mat.mainTexture==null?0:mat.mainTexture.GetInstanceID(),wrapMode=mat.mainTexture==null?"":mat.mainTexture.wrapMode.ToString(),textureScale=mat.mainTextureScale,textureOffset=mat.mainTextureOffset,keywords=mat.shaderKeywords,instancing=mat.enableInstancing,
                        globalEmpty=global.isEmpty,indexEmpty=block.isEmpty,global=ApcRearDiagnostics.Properties(mat,global),properties=ApcRearDiagnostics.Properties(mat,block)});
                }
                sample.surfaces.Add(item);
            }
            foreach(var hit in root.GetComponentsInChildren<Collider>(true).Take(48))sample.colliders.Add(new Hit{path=PathOf(hit.transform),type=hit.GetType().Name,enabled=hit.enabled,trigger=hit.isTrigger,center=hit.bounds.center,size=hit.bounds.size});
        }
        internal static void Capture(DinBreaker owner)
        {
            if(owner==null||owner.Board==null||!owner.gameObject.activeInHierarchy)return;
            var cell=owner.Battery;string key=cell==null?"empty":cell.PrefabName;
            if(seen.Contains(key)||seen.Count>=8)return;
            seen.Add(key);
            try
            {
                var slot=owner.Slots[0];var apc=WorldManager.Instance.SourcePrefabs.OfType<AreaPowerControl>().First(p=>p.PrefabName=="StructureAreaPowerControl");var native=apc.BatterySlot;
                var sample=new Sample{cell=key,frame=Time.frameCount,charge=cell==null?0:cell.PowerRatio,slotKey=slot.StringKey,slotHash=slot.StringHash,slotName=slot.DisplayName,nativeKey=native.StringKey,nativeHash=native.StringHash,nativeName=native.DisplayName};
                Inspect(sample,owner.transform,"live module and cell");Inspect(sample,native.Location,"native APC slot location");
                if(cell!=null){var prefab=WorldManager.Instance.SourcePrefabs.FirstOrDefault(p=>p.PrefabHash==cell.PrefabHash);if(prefab!=null){Inspect(sample,prefab.transform,"original cell prefab");var live=cell.GetComponentInChildren<MeshFilter>(true);var original=prefab.GetComponentInChildren<MeshFilter>(true);sample.sameCellMesh=live!=null&&original!=null&&live.sharedMesh==original.sharedMesh;sample.liveUvHash=UvHash(live==null?null:live.sharedMesh);sample.prefabUvHash=UvHash(original==null?null:original.sharedMesh);}}
                report.samples.Add(sample);string path=System.IO.Path.Combine(Application.persistentDataPath,"ModularSwitchboards-battery-diagnostics.json");
                File.WriteAllText(path,DiagnosticJson.Serialize(report));Debug.Log("[Modular Switchboards] BATTERY DIAG saved: "+path+"; "+key);
            }
            catch(Exception ex){Debug.LogWarning("[Modular Switchboards] BATTERY DIAG failed: "+ex);}
        }
    }
}
