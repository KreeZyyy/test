using System;
using System.Linq;
using Assets.Scripts;
using Assets.Scripts.Objects.Electrical;
using UnityEngine;

namespace ModularSwitchboards
{
    // Geometry lives in the Housing mesh, rather than a separate rear GameObject.
    internal static class CabinetRearDepth
    {
        // Measured from the user's native APC export: outer rear plane to
        // grey/white body seam. The protruding lightning cover is excluded.
        internal const float NominalDepth = .086239442f;
        internal static float Measure()
        {
            Debug.Log("[Modular Switchboards] Integrated rear shell: measured APC depth=0.086239442 m; no connector or lightning-cover geometry.");
            return NominalDepth;
        }

        internal static void Fit(Vector3[] vertices, Vector3[] normals, float depth)
        {
            float scale = depth / NominalDepth;
            for (int i = 0; i < vertices.Length; i++)
            {
                // Existing housing geometry starts at z=0. Only the integrated rear
                // extrusion occupies negative z; its joint remains exactly at zero.
                if (vertices[i].z >= 0f) continue;
                vertices[i].z *= scale;
                var n = normals[i]; n.z /= scale; normals[i] = n.normalized;
            }
        }
    }
}
