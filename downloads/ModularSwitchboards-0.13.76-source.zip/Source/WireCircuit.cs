using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Serialization;

namespace ModularSwitchboards
{
    public sealed class CabinetWireEnd : IEquatable<CabinetWireEnd>
    {
        [XmlAttribute] public long Owner;
        [XmlAttribute] public int Contact;
        public CabinetWireEnd(){}
        public CabinetWireEnd(long owner,int contact){Owner=owner;Contact=contact;}
        public bool Equals(CabinetWireEnd other)=>other!=null&&Owner==other.Owner&&Contact==other.Contact;
        public override bool Equals(object obj)=>Equals(obj as CabinetWireEnd);
        public override int GetHashCode()=>Owner.GetHashCode()*397^Contact;
        public bool IsNeutral=>Owner!=0&&Contact>=2;
        public bool IsSource=>Owner==0?Contact==0:Contact%2==1;
        public int Capacity=>IsNeutral?1:Owner==0&&Contact==0?16:Owner!=0&&Contact%2==1?2:1;
        public override string ToString()=>IsNeutral?"Bridge "+(Contact==2?"plate":"door"):Owner==0?new[]{"Input","Output 1","Output 2"}[Contact]:"Module "+(Contact==0?"IN (top)":"OUT (bottom)");
    }
    public sealed class CabinetWireSaveData
    {
        [XmlElement] public CabinetWireEnd From,To;
        [XmlAttribute] public int InputSlot;
        [XmlAttribute] public int RouteVersion;
        [XmlAttribute] public int CableUnits=1;
        [XmlAttribute] public int ColorIndex=-1; // Legacy/default wires use native red.
        [XmlArray] public float[] Points;
    }
    internal static class WireCircuit
    {
        internal static IEnumerable<CabinetWireSaveData> Through(IEnumerable<CabinetWireSaveData> wires,IEnumerable<long> passages)
            =>wires.Concat((passages??Enumerable.Empty<long>()).SelectMany(id=>new[]{new CabinetWireSaveData{From=new CabinetWireEnd(id,2),To=new CabinetWireEnd(id,3)},new CabinetWireSaveData{From=new CabinetWireEnd(id,3),To=new CabinetWireEnd(id,2)}}));
        internal static bool Reachable(CabinetWireEnd from,CabinetWireEnd to,IEnumerable<CabinetWireSaveData> wires,IEnumerable<long> closedBreakers)
        {
            var edges=new Dictionary<CabinetWireEnd,List<CabinetWireEnd>>();
            Action<CabinetWireEnd,CabinetWireEnd> add=(a,b)=>{if(!edges.TryGetValue(a,out var list))edges[a]=list=new List<CabinetWireEnd>();list.Add(b);};
            foreach(var wire in wires){add(wire.From,wire.To);if(wire.From.IsNeutral&&wire.To.IsNeutral)add(wire.To,wire.From);}
            foreach(var breaker in closedBreakers)add(new CabinetWireEnd(breaker,0),new CabinetWireEnd(breaker,1));
            var seen=new HashSet<CabinetWireEnd>();var queue=new Queue<CabinetWireEnd>();queue.Enqueue(from);
            while(queue.Count>0){var n=queue.Dequeue();if(!seen.Add(n))continue;if(n.Equals(to))return true;if(edges.TryGetValue(n,out var list))foreach(var next in list)queue.Enqueue(next);}return false;
        }
        internal static bool CanConnect(CabinetWireEnd a,CabinetWireEnd b,IList<CabinetWireSaveData> wires,IEnumerable<long> breakers,out string reason,bool allowLegacyBypass=false,Func<CabinetWireEnd,int> capacity=null,IEnumerable<long> passages=null)
        {
            reason=null;
            if(a==null||b==null||a.Equals(b)){reason="Choose two different contacts.";return false;}
            if(!a.IsNeutral&&!b.IsNeutral&&a.IsSource==b.IsSource){reason="Connect a supply contact to an input contact.";return false;}
            Orient(a,b,out var from,out var to);
            if(!allowLegacyBypass&&from.Owner==0&&to.Owner==0){reason="Connect Input to a module's top contact first.";return false;}
            if(from.Owner!=0&&from.Owner==to.Owner){reason="Cannot wire a module back into itself.";return false;}
            foreach(var e in new[]{a,b})if(wires.Count(w=>w.From.Equals(e)||w.To.Equals(e))>=(capacity==null?e.Capacity:capacity(e))){reason="Contact occupied.";return false;}
            if(Reachable(to,from,Through(wires,passages),breakers)){reason="This connection would create a loop.";return false;}
            return true;
        }
        internal static void Orient(CabinetWireEnd a,CabinetWireEnd b,out CabinetWireEnd from,out CabinetWireEnd to)
        {
            if(a.IsNeutral&&b.IsNeutral){from=a;to=b;}
            else if(a.IsNeutral){from=b.IsSource?b:a;to=b.IsSource?a:b;}
            else if(b.IsNeutral){from=a.IsSource?a:b;to=a.IsSource?b:a;}
            else{from=a.IsSource?a:b;to=a.IsSource?b:a;}
        }
        // Share one native input budget. A second output must not advertise it a second time.
        internal static float[] Allocate(float available,float firstDemand,float secondDemand,bool first,bool second)
        {
            available=Finite(available);firstDemand=Finite(firstDemand);secondDemand=Finite(secondDemand);
            if(!first&&!second)return new float[2];if(!first)return new[]{0f,available};if(!second)return new[]{available,0f};
            float total=firstDemand+secondDemand;if(total<=0)return new[]{available*.5f,available*.5f};
            float one=available*(firstDemand/total);return new[]{one,available-one};
        }
        internal static float Finite(float value)=>float.IsNaN(value)||float.IsInfinity(value)?0:Math.Max(0,value);
    }
}
