using Assets.Scripts.Objects;
using Assets.Scripts.Networking;

namespace ModularSwitchboards
{
    // Native OnOff is deliberately inverted: OFF = released/closed, ON = latched/open.
    // A new control is therefore ready without resetting its saved state in Awake.
    internal static class DoorStopControl
    {
        internal const float ResetSeconds=1.2f;
        internal static string ActionName(bool pressed)=>pressed?"Hold to reset":"Press";
        internal static bool CanUse(DinBreaker owner)=>owner!=null&&!owner.IsCursor&&!owner.IsBeingDestroyed&&
            owner.IsStructureCompleted&&owner.Board?.PrimaryHost is SwitchboardCabinet host&&host.IsStructureCompleted;
        internal static Thing.DelayedActionInstance Interact(DinBreaker owner,Interactable control,bool doAction)
        {
            var result=new Thing.DelayedActionInstance{Duration=owner.OnOff?ResetSeconds:0f,ActionMessage=ActionName(owner.OnOff)};
            if(!CanUse(owner))return result.Fail("Install the TOTAL STOP on a completed door first.");
            // Use the game's client -> server interaction path, including native state
            // replication/save/join. Preview/cancelled holds must never change state.
            if(doAction)OnServer.Interact(control,owner.OnOff?0:1);
            return result.Succeed();
        }
    }
}
