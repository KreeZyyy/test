using Assets.Scripts;
using Assets.Scripts.Inventory;
using Assets.Scripts.Objects;
namespace ModularSwitchboards
{
    internal enum PlacementSurfaceKind{DoorLabel,DinLabel}
    internal static class BoardPlacementInput
    {
        internal static bool Wants(PlacementSurfaceKind kind)
        {
            if(GameManager.IsBatchMode||InventoryManager.CurrentMode!=InventoryManager.Mode.Placement||!(InventoryManager.ActiveHandSlot?.Get() is MultiConstructor kit))return false;
            var cursor=InventoryManager.ConstructionCursor;
            switch(kind)
            {
                case PlacementSurfaceKind.DoorLabel:return kit.PrefabName==SwitchboardsMod.LabelKitName&&cursor is DoorLabel;
                case PlacementSurfaceKind.DinLabel:return kit.PrefabName==SwitchboardsMod.LabelKitName&&cursor is SwitchboardLabel;
                default:return false;
            }
        }
    }
}
