using System.Collections;
using Assets.Scripts;
using Assets.Scripts.Inventory;
using Assets.Scripts.Objects;
using HarmonyLib;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class SwitchboardCoverInput
    {
        private static readonly System.Reflection.MethodInfo Wait=AccessTools.Method(typeof(InventoryManager),"WaitUntilDone",new[]{typeof(InventoryManager.DelegateEvent),typeof(Thing.DelayedActionInstance),typeof(int),typeof(int)});
        internal static bool PlacementPrefix(MultiConstructor multiConstructorItem)=>!SwitchboardCoverMount.IsKit(multiConstructorItem);
        internal static SwitchboardCabinet Target()
        {
            var hit=CursorManager.Instance?.CursorTargetCollider;
            var host=hit==null?null:hit.GetComponentInParent<SwitchboardCabinet>();
            if(host!=null)return host;
            if(CursorManager.CursorThing is SwitchboardCabinet cabinet)return cabinet;
            if(CursorManager.CursorThing is DinBreaker module)return CabinetWiring.CabinetOf(module);
            if(CursorManager.CursorThing is DinRail rail)return rail.Board?.PrimaryHost as SwitchboardCabinet;
            if(CursorManager.CursorThing is InnerCoverModule cover)return cover.Host;
            return null;
        }
        internal static bool Handle(InventoryManager inventory,DynamicThing active)
        {
            // This is a normal held-kit action. Do not create or show placement UI.
            if(InventoryManager.CurrentMode==InventoryManager.Mode.Placement)inventory.CancelPlacement();
            if(inventory.ConstructionPanel.IsVisible&&inventory.ConstructionPanel.Parent?.PrefabName==SwitchboardsMod.CoverKitName)inventory.ConstructionPanel.SetVisible(false);
            if(InventoryManager.ConstructionCursor is InnerCoverModule ghost){ghost.gameObject.SetActive(false);ghost.Board=null;InventoryManager.ConstructionCursor=null;}
            InventoryManager.CurrentMode=InventoryManager.Mode.Normal;
            var host=Target();if(host==null)return true;
            var point=CursorManager.CursorHit.point;
            var attack=new Attack(inventory.ActiveHand.Slot,inventory.InactiveHand.Slot,point,host,1f,CursorManager.Instance.CursorTargetCollider,false,false);
            SwitchboardCoverMount.TryAttack(host,attack,false,out var action);
            inventory.ClearCursor();
            inventory.TooltipRef.HandleToolTipDisplay(new PassiveTooltip(action,"Switchboard Cover",host){color=action.IsDisabled?Color.red:Color.green});
            if(KeyManager.GetMouseDown("Primary")&&!action.IsDisabled&&inventory.ActionCoroutine==null&&Wait!=null)
            {
                InventoryManager.DelegateEvent finish=()=>
                {
                    if(inventory.LastCompletedRatio<1f||InventoryManager.ActiveHandSlot?.Get()!=active||Target()!=host)return;
                    OnServer.AttackWith(active.RootParentHuman,(byte)inventory.ActiveHand.SlotId,(byte)inventory.InactiveHand.SlotId,host.ReferenceId,CursorManager.CursorHit.point,1f,false,false);
                };
                inventory.ActionCoroutine=inventory.StartCoroutine((IEnumerator)Wait.Invoke(inventory,new object[]{finish,action,action.ActionSoundHash,action.ActionCompleteSoundHash}));
            }
            return false;
        }
    }
}
