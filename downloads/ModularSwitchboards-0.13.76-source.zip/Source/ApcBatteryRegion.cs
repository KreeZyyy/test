using UnityEngine;

namespace ModularSwitchboards
{
    internal static class ApcBatteryRegion
    {
        // Preserve the APC proportions and seat its socket rim flush with the DIN
        // face. Fit both the aperture height and the available cell-rear depth.
        internal const float OpeningHeight=.06075f;
        internal const float NativeFront=.211f;
        internal const float NativeSocketFront=.1980004f;
        internal static float RearSource=.04753667f;
        internal static bool Contains(Vector3 p)=>p.x>=-.155f&&p.x<=-.040f&&p.y>=-.175f&&p.y<=-.060f&&p.z>=.125f&&p.z<=.212f;
        internal const float DinFace=.0635f;
        internal const float RimPlane=DinFace+.0005f;
        internal const float NativeSocketHeight=.10804666f;
        internal const float SizeIncrease=1.10f;
        internal static float FitScale(Vector3 size)=>SizeIncrease*Mathf.Min(OpeningHeight/size.x,(RimPlane*DinBreakerModel.VisualScale.z-.006f)/(NativeSocketFront-RearSource));
        internal static float SocketHeight=>NativeSocketHeight*FitScale(new Vector3(NativeSocketHeight,NativeSocketHeight,0));
        internal static float Front(float scale)=>DinFace;
        internal static float CellFront(float scale)=>RimPlane+(NativeFront-NativeSocketFront)*scale/DinBreakerModel.VisualScale.z;
        internal static Vector3 Map(Vector3 p,Vector3 center,float minDepth,float scale)
        {
            return new Vector3(DinBatteryLayout.CenterX+(p.x-center.x)*scale/DinBreakerModel.VisualScale.x,
                (p.y-center.y)*scale/DinBreakerModel.VisualScale.y,
                RimPlane+(p.z-NativeSocketFront)*scale/DinBreakerModel.VisualScale.z);
        }
    }
}
