using System.Collections.Generic;
using UnityEngine;

namespace ModularSwitchboards
{
    internal static class RoundedGeometry
    {
        internal static void Box(List<Vector3> vertices,List<Vector3> normals,List<int> indices,Vector3 center,Vector3 size,float radius)
        {
            var half=size*.5f;
            radius=Mathf.Min(radius,Mathf.Min(half.x,Mathf.Min(half.y,half.z))*.8f);
            var inner=half-Vector3.one*radius;
            foreach(var n in new[]{Vector3.right,Vector3.left,Vector3.up,Vector3.down,Vector3.forward,Vector3.back})
            {
                var u=Mathf.Abs(n.y)>.5f?Vector3.right:Vector3.up;
                var v=Vector3.Cross(n,u);
                float hn=Extent(n,half),hu=Extent(u,half),hv=Extent(v,half);
                var us=Samples(hu,radius);var vs=Samples(hv,radius);int start=vertices.Count;
                for(int j=0;j<vs.Length;j++)for(int i=0;i<us.Length;i++)
                {
                    var p=n*hn+u*us[i]+v*vs[j];
                    var q=new Vector3(Mathf.Clamp(p.x,-inner.x,inner.x),Mathf.Clamp(p.y,-inner.y,inner.y),Mathf.Clamp(p.z,-inner.z,inner.z));
                    var direction=(p-q).normalized;
                    vertices.Add(center+q+direction*radius);normals.Add(direction);
                }
                for(int j=0;j<vs.Length-1;j++)for(int i=0;i<us.Length-1;i++)
                {
                    int a=start+j*us.Length+i,b=a+1,c=b+us.Length,d=a+us.Length;
                    indices.AddRange(new[]{a,b,c,a,c,d});
                }
            }
        }
        // A rounded rectangular section with an independent XY corner radius and a
        // small rolled sheet edge. Thin necks retain the same silhouette as the casing.
        internal static void Panel(List<Vector3> vertices,List<Vector3> normals,List<int> indices,Vector3 center,Vector3 size,float radius)
        {
            radius=Mathf.Min(radius,Mathf.Min(size.x,size.y)*.49f);
            float bevel=Mathf.Min(.0015f,size.z*.2f);int start=vertices.Count;const int arc=12;int count=4*(arc+1);
            for(int ring=0;ring<8;ring++)
            {
                bool front=ring>=4;int step=front?7-ring:ring;float angle=step*Mathf.PI/6f;
                float side=Mathf.Sin(angle),face=Mathf.Cos(angle);
                float inset=bevel*(1f-side);float r=radius-inset;
                float z=front?size.z*.5f-bevel+bevel*face:-size.z*.5f+bevel-bevel*face;
                for(int corner=0;corner<4;corner++)for(int j=0;j<=arc;j++)
                {
                    float t=(corner*90f+j*90f/arc)*Mathf.Deg2Rad;
                    float sx=corner==0||corner==3?1f:-1f,sy=corner<2?1f:-1f;
                    var outward=new Vector3(Mathf.Cos(t),Mathf.Sin(t),0);
                    vertices.Add(center+new Vector3(sx*(size.x*.5f-radius)+outward.x*r,sy*(size.y*.5f-radius)+outward.y*r,z));
                    normals.Add(outward*side+Vector3.forward*(front?face:-face));
                }
            }
            for(int ring=0;ring<7;ring++)for(int j=0;j<count;j++)
            {
                int a=start+ring*count+j,b=start+ring*count+(j+1)%count,c=b+count,d=a+count;
                indices.AddRange(new[]{a,b,c,a,c,d});
            }
            for(int side=0;side<2;side++)
            {
                int cap=vertices.Count;var n=side==0?Vector3.back:Vector3.forward;
                vertices.Add(center+n*(size.z*.5f));normals.Add(n);
                int edge=vertices.Count;
                for(int j=0;j<count;j++){vertices.Add(vertices[start+(side==0?0:7)*count+j]);normals.Add(n);}
                for(int j=0;j<count;j++)
                {
                    int a=edge+j,b=edge+(j+1)%count;
                    if(side==0)indices.AddRange(new[]{cap,b,a});else indices.AddRange(new[]{cap,a,b});
                }
            }
        }
        private static float Extent(Vector3 axis,Vector3 half)=>Mathf.Abs(axis.x)*half.x+Mathf.Abs(axis.y)*half.y+Mathf.Abs(axis.z)*half.z;
        private static float[] Samples(float half,float radius)=>new[]{-half,-half+radius*.5f,-half+radius,half-radius,half-radius*.5f,half};
    }
}
