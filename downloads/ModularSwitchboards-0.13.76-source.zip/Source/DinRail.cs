using System.Linq;
using System.Collections.Generic;
using System.Xml.Serialization;
using Assets.Scripts;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Networking;
using Assets.Scripts.Objects;
using Assets.Scripts.Localization2;
using LibConstruct;
using UnityEngine;

namespace ModularSwitchboards
{
    public sealed class DinRailSaveData : StructureSaveData
    {
        [XmlElement] public PlacementBoardStructureSaveData RailBoard;
        [XmlElement] public PlacementBoardHostSaveData Modules;
    }

    public sealed class DinRail : Structure, IPlacementBoardStructure, IPlacementBoardHost
    {
        public Transform ModuleOrigin;
        public BoxCollider ModuleSurface;
        private BoardRef<DinModuleBoard> modules;
        private bool checkedCapacity;
        public DinModuleBoard Modules => modules?.Board;
        public int ModuleCapacity => DinLayout.ModuleCount(DinLayout.CabinetInnerWidth);
        public bool CanAccessModules => !IsCursor&&Board?.PrimaryHost is SwitchboardCabinet host&&host.CanAccessModules;
        public bool CanFitModules => !IsCursor && Board?.PrimaryHost is SwitchboardCabinet host && host.CanFitRails;
        public IEnumerable<PlacementBoard> GetPlacementBoards() { if (Modules != null) yield return Modules; }
        public IEnumerable<BoxCollider> CollidersForBoard(PlacementBoard board) { if (ModuleSurface != null) yield return ModuleSurface; }
        public void OnBoardStructureRegistered(PlacementBoard board, IPlacementBoardStructure structure) { }
        public void OnBoardStructureDeregistered(PlacementBoard board, IPlacementBoardStructure structure) { }
        public override void OnRegistered(Cell cell)
        {
            base.OnRegistered(cell);
            if (!IsCursor && ModuleOrigin != null) BoardHostHooks.OnRegisteredBoard(this, ref modules, ModuleOrigin);
        }
        public override void OnFinishedLoad()
        {
            base.OnFinishedLoad();
            if (!IsCursor && ModuleOrigin != null) BoardHostHooks.OnFinishedLoadBoard(this, ref modules, ModuleOrigin);
        }
        public override void OnDestroy()
        {
            BoardHostHooks.OnDestroyedBoard(this, modules);
            base.OnDestroy();
        }
        private void LateUpdate()
        {
            if (ModuleSurface != null) ModuleSurface.enabled = !IsCursor && CanFitModules;
            if (!checkedCapacity && !IsCursor && GameManager.RunSimulation && !PlacementBoard.Loading &&
                GameManager.GameState == GameState.Running && Modules != null && Board != null)
            {
                checkedCapacity=true;
                var overflow=Modules.Structures.OfType<DinBreaker>().Where(m=>
                    Modules.WorldToGrid(m.Transform.position).x / 10 >= DinLayout.FirstModuleSlot+ModuleCapacity).Cast<IPlacementBoardStructure>().ToList();
                if (overflow.Count>0)
                {
                    PlacementBoard.DeconstructToKits(Transform.position,overflow);
                    PlacementBoard.DestroyStructureList(overflow);
                    Debug.Log("[Modular Switchboards] Capacity migration: returned " + overflow.Count + " oversized-row modules as kits.");
                }
            }
        }
        public PlacementBoard Board { get; set; }
        public PlacementBoard.BoardCell[] BoardCells { get; set; }
        public override void Awake()
        {
            base.Awake();
            BoardStructureHooks.Awake(this);
            DinRailModel.Refresh(this);
        }
        public override Grid3 GetLocalGrid() => Board == null ? default(Grid3) : Board.WorldToGrid(Transform.position);

        internal static bool CanPlace(PlacementBoard board, Grid3 position, int rotation)
        {
            if (!(board is CabinetRailBoard) || !(board.PrimaryHost is SwitchboardCabinet host) || !host.CanFitRails)
                return false;
            if(host.Wiring.WouldBlockRail(board,position))return false;
            if (!DinLayout.IsRailPosition(position.x, position.y, position.z, rotation)) return false;
            return !board.Structures.OfType<DinRail>().Any(r =>
                board.WorldToGrid(r.Transform.position).y == position.y);
        }
        public override CanConstructInfo CanConstruct()
        {
            if (Board == null) return CanConstructInfo.InvalidPlacement("Open a completed switchboard cabinet.");
            var position = Board.WorldToGrid(Transform.position);
            if (IsCursor)
            {
                position = new Grid3(0, DinLayout.SnapRow(position.y), 0);
                PlacementBoard.CursorGrid = position;
                PlacementBoard.CursorRotation = 0;
                Transform.SetPositionAndRotation(Board.GridToWorld(position), Board.IndexToRotation(0));
            }
            return CanPlace(Board, position, Board.RotationToIndex(Transform.rotation))
                ? CanConstructInfo.ValidPlacement
                : CanConstructInfo.InvalidPlacement("Open the cabinet and choose an empty DIN row.");
        }
        protected override CanConstructInfo CanDeconstruct()
            => (Modules == null || Modules.Structures.Count == 0) && Board?.PrimaryHost is SwitchboardCabinet host && host.CanFitRails
                ? CanConstructInfo.ValidPlacement : CanConstructInfo.InvalidPlacement("Open the cabinet first.");
        public override DelayedActionInstance AttackWith(Attack attack, bool doAction = true)
        {
            if (!(Board?.PrimaryHost is SwitchboardCabinet host) || !host.CanFitRails ||
                (Modules != null && Modules.Structures.Count > 0)) return null;
            return base.AttackWith(attack, doAction);
        }
        public override void OnDeregistered()
        {
            base.OnDeregistered();
            if (Board != null) BoardStructureHooks.OnDeregistered(this);
        }
        public override ThingSaveData SerializeSave()
        {
            ThingSaveData data = new DinRailSaveData();
            InitialiseSaveData(ref data);
            return data;
        }
        protected override void InitialiseSaveData(ref ThingSaveData data)
        {
            base.InitialiseSaveData(ref data);
            if (data is DinRailSaveData save && Board != null)
                save.RailBoard = BoardStructureHooks.SerializeSave(this);
            if (data is DinRailSaveData moduleSave && Modules != null)
                moduleSave.Modules = BoardHostHooks.SerializeBoard(this, Modules);
        }
        public override void DeserializeSave(ThingSaveData data)
        {
            base.DeserializeSave(data);
            BoardHostHooks.DeserializeBoard(this, (data as DinRailSaveData)?.Modules, out modules, ModuleOrigin);
            if (data is DinRailSaveData save && save.RailBoard != null)
                BoardStructureHooks.DeserializeSave(this, save.RailBoard);
        }
        public override void SerializeOnJoin(RocketBinaryWriter writer)
        {
            base.SerializeOnJoin(writer);
            BoardStructureHooks.SerializeOnJoin(writer, this);
            BoardHostHooks.SerializeBoardOnJoin(writer, this, Modules);
        }
        public override void DeserializeOnJoin(RocketBinaryReader reader)
        {
            base.DeserializeOnJoin(reader);
            BoardStructureHooks.DeserializeOnJoin(reader, this);
            BoardHostHooks.DeserializeBoardOnJoin(reader, this, out modules, ModuleOrigin);
        }
    }
}
