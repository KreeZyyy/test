using System;
using System.Collections;
using System.Globalization;
using System.Reflection;
using System.Text;

namespace ModularSwitchboards
{
    // Unity's native serializer omitted the diagnostic collection fields at runtime.
    // This writer handles only our public-field DTOs, arrays, lists and primitives.
    internal static class DiagnosticJson
    {
        internal static string Serialize(object value)
        {
            var result = new StringBuilder(); Write(result,value); return result.ToString();
        }
        private static void Quote(StringBuilder output,string value)
        {
            output.Append('"');
            foreach(char c in value)
            {
                if(c=='"' || c=='\\')output.Append('\\').Append(c);
                else if(c<32)output.Append("\\u").Append(((int)c).ToString("x4"));
                else output.Append(c);
            }
            output.Append('"');
        }
        private static void Write(StringBuilder output,object value)
        {
            if(value==null){output.Append("null");return;}
            if(value is string text){Quote(output,text);return;}
            if(value is bool flag){output.Append(flag?"true":"false");return;}
            if(value is float single){output.Append(float.IsNaN(single)||float.IsInfinity(single)?"null":single.ToString("R",CultureInfo.InvariantCulture));return;}
            if(value is double number){output.Append(double.IsNaN(number)||double.IsInfinity(number)?"null":number.ToString("R",CultureInfo.InvariantCulture));return;}
            if(value.GetType().IsPrimitive){output.Append(Convert.ToString(value,CultureInfo.InvariantCulture));return;}
            if(value is IEnumerable values)
            {
                output.Append('[');bool first=true;
                foreach(var entry in values){if(!first)output.Append(',');first=false;Write(output,entry);}
                output.Append(']');return;
            }
            output.Append('{');bool initial=true;
            foreach(var field in value.GetType().GetFields(BindingFlags.Instance|BindingFlags.Public))
            {
                if(!initial)output.Append(',');initial=false;Quote(output,field.Name);output.Append(':');Write(output,field.GetValue(value));
            }
            output.Append('}');
        }
    }
}
