using System;
using System.Collections.Generic;
using System.Linq;
using Assets.Scripts.Objects;
using UnityEngine;

namespace ModularSwitchboards
{
    internal static class CabinetWallMount
    {
        internal const float Clearance=.0005f;
        internal static float BackOffset { get; private set; }

        internal static void MeasureNativeWall(float frontSign)
        {
            var walls=WorldManager.Instance.SourcePrefabs.OfType<Wall>()
                .Where(w=>w.PrefabName!=null && w.PrefabName.IndexOf("Flat",StringComparison.OrdinalIgnoreCase)>=0)
                .OrderBy(w=>w.PrefabName=="StructureWallFlat"?0:1).ThenBy(w=>w.PrefabName,StringComparer.Ordinal);
            foreach(var wall in walls)
            {
                if(wall.BuildStates==null || wall.BuildStates.Count==0) continue;
                float rear,front;
                if(!TryMeasure(wall,wall.BuildStates.Count-1,out rear,out front)) continue;
                float thickness=front-rear;
                if(thickness<0f || thickness>.5f) continue;
                // FaceMount snaps onto the native half-metre grid plane, not the mesh surface.
                float plane=Mathf.Round((front+rear)*.5f/SmallGrid.SmallGridSize)*SmallGrid.SmallGridSize;
                float surface=frontSign>0f?front-plane:plane-rear;
                if(surface<-.0001f || surface>.5f) continue;
                BackOffset=surface+Clearance;
                Debug.Log("[Modular Switchboards] Flat wall measured: "+wall.PrefabName+"; thickness="+thickness.ToString("F6")+
                    " m; rear="+rear.ToString("F6")+"; front="+front.ToString("F6")+"; grid plane="+plane.ToString("F6")+
                    "; cabinet back="+BackOffset.ToString("F6")+" m; clearance=0.000500 m; native wall mesh");
                return;
            }
            BackOffset=Clearance;
            Debug.LogWarning("[Modular Switchboards] Flat-wall template unavailable; mounting offset will be measured from the actual supporting wall.");
        }

        internal static bool TryMeasure(Wall wall,int stateIndex,out float rear,out float front)
        {
            rear=float.PositiveInfinity;front=float.NegativeInfinity;
            if(wall.BuildStates==null || stateIndex<0 || stateIndex>=wall.BuildStates.Count) return false;
            for(int i=0;i<=stateIndex;i++)
            {
                var state=wall.BuildStates[i];
                if(i!=stateIndex && state.RenderMode!=BuildStateRenderMode.OnMineAndPreviousStates) continue;
                var renderer=state.Visualizer;
                var mesh=renderer==null?state.InitialDrawData.mesh:renderer.GetComponent<MeshFilter>()?.sharedMesh;
                if(mesh==null) mesh=state.InitialDrawData.mesh;
                if(mesh==null) continue;
                var matrix=renderer==null?Matrix4x4.identity:wall.transform.worldToLocalMatrix*renderer.transform.localToWorldMatrix;
                float low,high;
                try
                {
                    CabinetGeometry.ReadNativeMesh(mesh,out var vertices,out var uv,out var triangles);
                    for(int v=0;v<vertices.Length;v++) vertices[v]=matrix.MultiplyPoint3x4(vertices[v]);
                    var bounds=new Bounds(vertices[0],Vector3.zero);foreach(var point in vertices) bounds.Encapsulate(point);
                    if(!TrySurface(vertices,triangles,bounds.center.x,bounds.center.y,out low,out high)) continue;
                }
                catch(Exception ex)
                {
                    var bounds=TransformedBounds(mesh.bounds,matrix);
                    low=bounds.min.z;high=bounds.max.z;
                    Debug.LogWarning("[Modular Switchboards] Wall surface uses native mesh bounds: "+ex.Message);
                }
                rear=Math.Min(rear,low);front=Math.Max(front,high);
            }
            return !float.IsInfinity(rear) && !float.IsInfinity(front);
        }

        private static bool TrySurface(Vector3[] points,int[][] groups,float x,float y,out float rear,out float front)
        {
            rear=float.PositiveInfinity;front=float.NegativeInfinity;
            foreach(var indices in groups)
                for(int i=0;i<indices.Length;i+=3)
                {
                    var a=points[indices[i]];var b=points[indices[i+1]];var c=points[indices[i+2]];
                    float denominator=(b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x);
                    if(Math.Abs(denominator)<.00000001f) continue;
                    float u=((x-a.x)*(c.y-a.y)-(y-a.y)*(c.x-a.x))/denominator;
                    float v=((b.x-a.x)*(y-a.y)-(b.y-a.y)*(x-a.x))/denominator;
                    if(u<-.00001f || v<-.00001f || u+v>1.00001f) continue;
                    float z=a.z+u*(b.z-a.z)+v*(c.z-a.z);
                    rear=Math.Min(rear,z);front=Math.Max(front,z);
                }
            return !float.IsInfinity(rear) && !float.IsInfinity(front);
        }

        internal static Bounds TransformedBounds(Bounds bounds,Matrix4x4 matrix)
        {
            var result=new Bounds(matrix.MultiplyPoint3x4(bounds.min),Vector3.zero);
            for(int x=0;x<2;x++) for(int y=0;y<2;y++) for(int z=0;z<2;z++)
                result.Encapsulate(matrix.MultiplyPoint3x4(new Vector3(x==0?bounds.min.x:bounds.max.x,y==0?bounds.min.y:bounds.max.y,z==0?bounds.min.z:bounds.max.z)));
            return result;
        }
    }
}
