using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Assets.Scripts;
using Assets.Scripts.Objects.Electrical;
using UnityEngine;
using UnityEngine.Rendering;

namespace ModularSwitchboards
{
    // Capture original data rather than calling the current depth heuristic exact.
    internal static class CableAnalyserDiagnostics
    {
        [Serializable] public sealed class Report
        {
            public string version = SwitchboardsMod.Version;
            public string prefab;
            public string gameAssembly=typeof(CableAnalyser).Assembly.FullName;
            public string measurement="CableAnalyser getters read CableNetwork.CurrentLoad, RequiredLoad and PotentialLoad. These are whole-network values, not branch readings. No display update method exists in CableAnalyser itself.";
            public List<Node> hierarchy=new List<Node>();
            public List<string> errors=new List<string>();
            public string coordinates = "Cable Analyzer original local coordinates; metres";
            public float frontSign;
            public string paintMaterial;
            public float diffuseIndex, smoothnessIndex;
            public List<Part> parts = new List<Part>();
            public List<Port> ports = new List<Port>();
            public List<TextureInfo> textures = new List<TextureInfo>();
        }
        [Serializable] public sealed class Part
        {
            public string path, mesh;
            public Vector3[] vertices;
            public Vector2[] uv;
            public Matrix4x4 meshToPrefab;
            public List<AttributeInfo> attributes=new List<AttributeInfo>();
            public List<StreamInfo> streams=new List<StreamInfo>();
            public List<Surface> surfaces = new List<Surface>();
            public List<Property> globalBlock = new List<Property>();
            public bool globalBlockEmpty;
        }
        [Serializable] public sealed class Surface
        {
            public int submesh;
            public int[] triangles;
            public Vector3 min, max;
            public string material, shader;
            public bool paintable, blockEmpty;
            public List<Property> properties = new List<Property>();
        }
        [Serializable] public sealed class Property
        {
            public string name, type, texture, blockTexture;
            public bool blockHasProperty;
            public float value, blockFloat;
            public Color color, blockColor;
            public Vector4 vector, blockVector;
        }
        [Serializable] public sealed class Port
        {
            public string role;
            public Vector3 position;
            public Vector3 colliderMin, colliderMax;
        }
        [Serializable] public sealed class TextureInfo
        {
            public string name, file, error;
            public int width, height;
        }
        [Serializable] public sealed class AttributeInfo { public string attribute,format; public int dimension,stream,offset; }
        [Serializable] public sealed class StreamInfo { public int stream,stride,bytes; public string base64,file,error; }
        [Serializable] public sealed class Node {
            public string path;public bool active;public Vector3 position,scale;public Quaternion rotation;
            public List<ComponentInfo> components=new List<ComponentInfo>();
        }
        [Serializable] public sealed class ComponentInfo {
            public string type;public List<FieldInfo> fields=new List<FieldInfo>();
        }
        [Serializable] public sealed class FieldInfo { public string name,type,value; }
        private static Node InspectNode(Transform transform,Transform root)
        {
            var node=new Node{path=PathOf(transform,root),active=transform.gameObject.activeSelf,
                position=transform.localPosition,rotation=transform.localRotation,scale=transform.localScale};
            foreach(var component in transform.GetComponents<Component>())
            {
                if(component==null)continue;
                var entry=new ComponentInfo{type=component.GetType().FullName};node.components.Add(entry);
                for(var type=component.GetType();type!=null&&type!=typeof(UnityEngine.Object);type=type.BaseType)
                foreach(var field in type.GetFields(System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.Public|System.Reflection.BindingFlags.NonPublic|System.Reflection.BindingFlags.DeclaredOnly))
                {
                    try {
                        var value=field.GetValue(component);string text=null;
                        if(value==null)text="null";
                        else if(value is Component other)text=PathOf(other.transform,root)+" :: "+other.GetType().FullName;
                        else if(value is GameObject go)text=PathOf(go.transform,root);
                        else if(value is UnityEngine.Object asset)text=asset.name+" :: "+asset.GetType().FullName;
                        else if(value is string||value.GetType().IsPrimitive||value.GetType().IsEnum||value is Vector2||value is Vector3||value is Color)text=Convert.ToString(value,System.Globalization.CultureInfo.InvariantCulture);
                        if(text!=null)entry.fields.Add(new FieldInfo{name=type.FullName+"."+field.Name,type=field.FieldType.FullName,value=text});
                    } catch(Exception ex){entry.fields.Add(new FieldInfo{name=field.Name,value="unavailable: "+ex.Message});}
                }
            }
            return node;
        }
        private static void CaptureStreams(Mesh mesh,Part part)
        {
            for(int stream=0;stream<mesh.vertexBufferCount;stream++)
            {
                var info=new StreamInfo{stream=stream,stride=mesh.GetVertexBufferStride(stream)};
                try {
                    using(var buffer=mesh.GetVertexBuffer(stream)){
                        info.bytes=buffer.count*buffer.stride;
                        if(info.bytes%4!=0)throw new InvalidOperationException("Unaligned stream");
                        var raw=new uint[info.bytes/4];buffer.GetData(raw);var bytes=new byte[info.bytes];
                        Buffer.BlockCopy(raw,0,bytes,0,bytes.Length);info.base64=Convert.ToBase64String(bytes);
                    }
                } catch(Exception ex){info.error=ex.Message;}
                part.streams.Add(info);
            }
        }
        private static bool captured;

        internal static void Capture()
        {
            if (captured) return;

            try
            {
                var apc = WorldManager.Instance.SourcePrefabs.OfType<CableAnalyser>().First();
                var frame = apc.transform.worldToLocalMatrix;
                var report = new Report { prefab=apc.PrefabName, frontSign=1f,
                    paintMaterial=apc.PaintableMaterial == null ? "" : apc.PaintableMaterial.name };
                report.smoothnessIndex = apc.SmoothnessIndex;
                report.diffuseIndex = apc.CustomColor == null ? -1 : apc.CustomColor.Index;
                foreach(var node in apc.GetComponentsInChildren<Transform>(true))report.hierarchy.Add(InspectNode(node,apc.transform));
                foreach (var renderer in apc.GetComponentsInChildren<MeshRenderer>(true))
                {
                    var mesh = renderer.GetComponent<MeshFilter>()?.sharedMesh;
                    if (mesh == null) continue;
                    try
                    {
                        CabinetGeometry.ReadNativeMesh(mesh,out var vertices,out var uv,out var groups);
                        var matrix = frame * renderer.transform.localToWorldMatrix;
                        for(int i=0;i<vertices.Length;i++) vertices[i]=matrix.MultiplyPoint3x4(vertices[i]);
                        var part = new Part {path=PathOf(renderer.transform,apc.transform),mesh=mesh.name,vertices=vertices,uv=uv,meshToPrefab=matrix};
                        foreach(var attribute in mesh.GetVertexAttributes())part.attributes.Add(new AttributeInfo {
                            attribute=attribute.attribute.ToString(),format=attribute.format.ToString(),dimension=attribute.dimension,
                            stream=mesh.GetVertexAttributeStream(attribute.attribute),offset=mesh.GetVertexAttributeOffset(attribute.attribute)});
                        CaptureStreams(mesh,part);
                        var global = new MaterialPropertyBlock(); renderer.GetPropertyBlock(global);
                        part.globalBlockEmpty=global.isEmpty;
                        var mats=renderer.sharedMaterials;
                        for(int i=0;i<groups.Length;i++)
                        {
                            var mat=i<mats.Length?mats[i]:null;
                            var block=new MaterialPropertyBlock();renderer.GetPropertyBlock(block,i);
                            var surface=new Surface {submesh=i,triangles=groups[i],material=mat==null?"":mat.name,
                                shader=mat==null||mat.shader==null?"":mat.shader.name,paintable=mat==apc.PaintableMaterial,blockEmpty=block.isEmpty};
                            if(groups[i].Length>0)
                            {
                                var bounds=new Bounds(vertices[groups[i][0]],Vector3.zero);
                                foreach(int index in groups[i]) bounds.Encapsulate(vertices[index]);
                                surface.min=bounds.min;surface.max=bounds.max;
                            }
                            if(mat!=null && mat.shader!=null)
                            {
                                surface.properties=Properties(mat,block);
                                if(i==0) part.globalBlock=Properties(mat,global);
                            }
                            part.surfaces.Add(surface);
                            Debug.Log("[Modular Switchboards] ANALYSER DIAG: "+part.path+" sub="+i+" material="+surface.material+
                                " paintable="+surface.paintable+" min="+surface.min.ToString("F6")+" max="+surface.max.ToString("F6"));
                        }
                        report.parts.Add(part);
                    }
                    catch(Exception ex) { report.errors.Add(renderer.name+": "+ex); Debug.LogWarning("[Modular Switchboards] ANALYSER DIAG mesh unavailable: "+renderer.name+": "+ex.Message); }
                }
                if(apc.OpenEnds!=null) foreach(var port in apc.OpenEnds)
                {
                    if(port?.Transform==null)continue;
                    var entry=new Port {role=port.ConnectionRole.ToString(),position=frame.MultiplyPoint3x4(port.Transform.position)};
                    if(port.Collider is BoxCollider box)
                    {
                        var bounds=CabinetWallMount.TransformedBounds(new Bounds(box.center,box.size),frame*box.transform.localToWorldMatrix);
                        entry.colliderMin=bounds.min;entry.colliderMax=bounds.max;
                    }
                    report.ports.Add(entry);
                }
                if(report.parts.Count==0)throw new InvalidOperationException("No Cable Analyzer meshes captured");
                var directory=System.IO.Path.Combine(Application.persistentDataPath,"ModularSwitchboards-CableAnalyzer-reference");
                Directory.CreateDirectory(directory);
                foreach(var part in report.parts)foreach(var stream in part.streams)
                {
                    if(stream.base64==null)continue;
                    stream.file="vertex-"+report.parts.IndexOf(part)+"-stream-"+stream.stream+".bin";
                    File.WriteAllBytes(System.IO.Path.Combine(directory,stream.file),Convert.FromBase64String(stream.base64));
                    stream.base64=null;
                }
                var seen=new HashSet<int>();
                foreach(var renderer in apc.GetComponentsInChildren<MeshRenderer>(true))
                    foreach(var material in renderer.sharedMaterials)
                    {
                        if(material==null||material.shader==null)continue;
                        for(int property=0;property<material.shader.GetPropertyCount();property++)
                        {
                            if(material.shader.GetPropertyType(property)!=ShaderPropertyType.Texture)continue;
                            var texture=material.GetTexture(material.shader.GetPropertyName(property));
                            if(texture==null||!seen.Add(texture.GetInstanceID()))continue;
                            report.textures.Add(ExportTexture(texture,directory,report.textures.Count));
                        }
                    }
                string path=System.IO.Path.Combine(directory,"ModularSwitchboards-CableAnalyzer-reference.json");
                string json=DiagnosticJson.Serialize(report);
                if(json.IndexOf("\"vertices\":[",StringComparison.Ordinal)<0 || json.IndexOf("\"surfaces\":[",StringComparison.Ordinal)<0)
                    throw new InvalidOperationException("Diagnostic export omitted geometry; file not written");
                File.WriteAllText(path,json);
                string zip=System.IO.Path.Combine(Application.persistentDataPath,"ModularSwitchboards-CableAnalyzer-reference.zip");
                if(File.Exists(zip))File.Delete(zip);
                System.IO.Compression.ZipFile.CreateFromDirectory(directory,zip);
                captured=true;
                Debug.Log("[Modular Switchboards] ANALYSER DIAG upload this file: "+zip);
                Debug.Log("[Modular Switchboards] ANALYSER DIAG saved: "+path+"; parts="+report.parts.Count+
                    ". Geometry includes all parts for identification; no claim that a rear surface has already been selected.");
            }
            catch(Exception ex) { Debug.LogError("[Modular Switchboards] ANALYSER DIAG failed: "+ex); }
        }

        private static TextureInfo ExportTexture(Texture texture,string directory,int index)
        {
            var result=new TextureInfo{name=texture.name,width=texture.width,height=texture.height};
            RenderTexture temporary=null;Texture2D readable=null;var previous=RenderTexture.active;
            try
            {
                if(!(texture is Texture2D))throw new InvalidOperationException("Only 2D diffuse textures exported; material reference is retained");
                if(texture.width>8192 || texture.height>8192)throw new InvalidOperationException("Texture exceeds diagnostic readback limit");
                temporary=RenderTexture.GetTemporary(texture.width,texture.height,0,RenderTextureFormat.ARGB32,RenderTextureReadWrite.sRGB);
                Graphics.Blit(texture,temporary);RenderTexture.active=temporary;
                readable=new Texture2D(texture.width,texture.height,TextureFormat.RGBA32,false);
                readable.ReadPixels(new Rect(0,0,texture.width,texture.height),0,0);readable.Apply();
                result.file="diffuse-"+index+".png";
                File.WriteAllBytes(System.IO.Path.Combine(directory,result.file),readable.EncodeToPNG());
            }
            catch(Exception ex){result.error=ex.Message;result.file=null;}
            finally
            {
                RenderTexture.active=previous;
                if(temporary!=null)RenderTexture.ReleaseTemporary(temporary);
                if(readable!=null)UnityEngine.Object.Destroy(readable);
            }
            return result;
        }

        private static string PathOf(Transform current,Transform root)
        {
            var names=new List<string>();
            while(current!=null){names.Add(current.name);if(current==root)break;current=current.parent;}
            names.Reverse();return string.Join("/",names.ToArray());
        }

        private static List<Property> Properties(Material mat,MaterialPropertyBlock block)
        {
            var result=new List<Property>();
            for(int i=0;i<mat.shader.GetPropertyCount();i++)
            {
                string name=mat.shader.GetPropertyName(i);int id=Shader.PropertyToID(name);
                var type=mat.shader.GetPropertyType(i);var prop=new Property{name=name,type=type.ToString(),blockHasProperty=block.HasProperty(id)};
                if(type==ShaderPropertyType.Color){prop.color=mat.GetColor(id);prop.blockColor=block.GetColor(id);}
                else if(type==ShaderPropertyType.Vector){prop.vector=mat.GetVector(id);prop.blockVector=block.GetVector(id);}
                else if(type==ShaderPropertyType.Texture){var texture=mat.GetTexture(id);prop.texture=texture==null?"":texture.name;var overrideTexture=block.GetTexture(id);prop.blockTexture=overrideTexture==null?"":overrideTexture.name;}
                else if(type==ShaderPropertyType.Float || type==ShaderPropertyType.Range){prop.value=mat.GetFloat(id);prop.blockFloat=block.GetFloat(id);}
                result.Add(prop);
            }
            // Block values of zero alone do not establish that a property is overridden.
            // Preserve block emptiness and both scopes so analysis can distinguish them.
            return result;
        }
    }
}
