using UnityEngine;

namespace ModularSwitchboards
{
    public sealed class DoorStopView:MonoBehaviour
    {
        public DinBreaker Owner;
        public Transform Button;
        private bool initialized,pressed;
        private float depth,twist;
        private void Awake(){Bind();}
        private void OnEnable(){Bind();}
        private void Bind()
        {
            Owner=GetComponent<DinBreaker>();
            Button=transform.Find("DoorStopButton");
        }
        private void LateUpdate()
        {
            // Instantiation copies component fields: only animate this instance's model.
            if(Owner==null||Owner.gameObject!=gameObject||Button==null||Button.parent!=transform)Bind();
            if(Owner==null||Button==null)return;
            bool next=Owner.OnOff;
            if(!initialized){initialized=true;pressed=next;depth=next?-.009f:0;twist=0;}
            else if(next!=pressed){if(pressed&&!next)twist=-90;pressed=next;}
            depth=Mathf.MoveTowards(depth,pressed?-.009f:0,.06f*Mathf.Max(0,Time.deltaTime));
            twist=Mathf.MoveTowards(twist,0,360*Mathf.Max(0,Time.deltaTime));
            Button.localPosition=new Vector3(0,0,depth);Button.localRotation=Quaternion.Euler(0,0,twist);
        }
    }
}
