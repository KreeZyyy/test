using Assets.Scripts;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Inventory;
using Assets.Scripts.Objects;
using LibConstruct;
namespace ModularSwitchboards
{
    internal static class MountPlacement
    {
        private static Structure lockedCursor;
        private static MultiConstructor lockedKit;
        private static PlacementBoard lockedBoard;
        private static Grid3 lockedGrid;
        private static int lockedRotation;
        private static bool Active(out Structure cursor,out MultiConstructor kit)
        {
            cursor=InventoryManager.ConstructionCursor;kit=InventoryManager.ActiveHandSlot?.Get() as MultiConstructor;
            return !GameManager.IsBatchMode&&InventoryManager.CurrentMode==InventoryManager.Mode.Placement&&
                SwitchboardKitModel.IsKit(kit)&&cursor!=null&&cursor.IsCursor&&cursor is IPlacementBoardStructure&&KeyManager.GetButton(KeyMap.QuantityModifier);
        }
        internal static bool Usable(PlacementBoard board)
        {
            if(board is DinModuleBoard)return board.PrimaryHost is DinRail rail&&rail!=null&&rail.CanFitModules;
            if(board is SwitchboardLabelBoard)return board.PrimaryHost is InnerCoverModule cover&&cover!=null&&cover.Host!=null&&cover.Host.IsOpen&&cover.Host.IsStructureCompleted;
            if(board?.PrimaryHost is SwitchboardCabinet host&&host!=null)
                return (board is SwitchboardDoorBoard||board is DoorLabelBoard)?host.IsStructureCompleted:
                    (board is CabinetRailBoard||board is SwitchboardBridgeBoard)&&host.CanFitRails;
            return false;
        }
        internal static void BeforeRaycast()
        {
            if(!Active(out var cursor,out var kit)){Clear();return;}
            if(lockedCursor==cursor&&lockedKit==kit&&Usable(lockedBoard))return;
            Clear();var mount=(IPlacementBoardStructure)cursor;var board=PlacementBoard.CursorBoard;
            if(board==null||mount.Board!=board||!Usable(board))return;
            lockedCursor=cursor;lockedKit=kit;lockedBoard=board;lockedGrid=PlacementBoard.CursorGrid;lockedRotation=PlacementBoard.CursorRotation;
        }
        internal static void AfterRaycast()
        {
            if(!Active(out var cursor,out var kit)||lockedCursor!=cursor||lockedKit!=kit||!Usable(lockedBoard)){Clear();return;}
            // LibConstruct's raycast deliberately clears CursorBoard. Restore a
            // held native placement lock before its normal placement pipeline runs.
            PlacementBoard.CursorBoard=lockedBoard;PlacementBoard.CursorGrid=lockedGrid;PlacementBoard.CursorRotation=lockedRotation;
            ((IPlacementBoardStructure)cursor).Board=lockedBoard;
            cursor.transform.SetPositionAndRotation(lockedBoard.GridToWorld(lockedGrid),lockedBoard.IndexToRotation(lockedRotation));
        }
        internal static bool TryLockedGrid(Structure cursor,PlacementBoard board,out Grid3 grid)
        {
            grid=lockedGrid;
            return Active(out var active,out var kit)&&active==cursor&&lockedCursor==cursor&&lockedKit==kit&&lockedBoard==board&&Usable(board);
        }
        private static void Clear(){lockedCursor=null;lockedKit=null;lockedBoard=null;}
    }
}
