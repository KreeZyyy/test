using Assets.Scripts.Objects;
using Assets.Scripts.Networking;
namespace ModularSwitchboards
{
    internal static class DoorIsolatorControl
    {
        internal static string ActionName(bool on)=>on?"Turn OFF":"Turn ON";
        internal static float Angle(bool on,bool round=false)=>round?(on?45f:-45f):(on?0f:-90f);
        internal static bool CanUse(DinBreaker owner)=>owner!=null&&!owner.IsCursor&&!owner.IsBeingDestroyed&&owner.IsStructureCompleted&&owner.Board?.PrimaryHost is SwitchboardCabinet host&&host.IsStructureCompleted;
        internal static Thing.DelayedActionInstance Interact(DinBreaker owner,Interactable control,bool doAction)
        {
            var result=new Thing.DelayedActionInstance{Duration=0f,ActionMessage=ActionName(owner.OnOff)};
            if(!CanUse(owner))return result.Fail("Install the switch on a completed door first.");
            // Native state handles server authority, replication, saves and joining.
            if(doAction)OnServer.Interact(control,owner.OnOff?0:1);
            return result.Succeed();
        }
    }
}
