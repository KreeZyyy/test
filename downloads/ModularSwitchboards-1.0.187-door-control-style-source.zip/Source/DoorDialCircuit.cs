using System.Collections.Generic;using System.Linq;
namespace ModularSwitchboards {
 internal static class DoorDialCircuit {
  private static bool DialEnd(CabinetWireEnd e,HashSet<long> d)=>d.Contains(e.Owner)&&e.Contact==0;
  private static bool OutputEnd(CabinetWireEnd e)=>e.Owner==0&&e.Contact>=1&&e.Contact<=3;
  internal static long[] DataBridges(IEnumerable<CabinetWireSaveData> wires,IEnumerable<long> bridges,IEnumerable<long> dials) {
   var bs=new HashSet<long>(bridges);var ds=new HashSet<long>(dials);
   return wires.SelectMany(w=>new[]{new[]{w.From,w.To},new[]{w.To,w.From}}).Where(p=>DialEnd(p[0],ds)&&bs.Contains(p[1].Owner)&&p[1].Contact==3).Select(p=>p[1].Owner).Distinct().ToArray();
  }
  internal static bool Valid(IEnumerable<CabinetWireSaveData> wires,IEnumerable<long> bridges,IEnumerable<long> dials) {
   var all=wires.Where(w=>!w.Burnt).ToArray();var bs=new HashSet<long>(bridges);var ds=new HashSet<long>(dials);
   foreach(var w in all)foreach(var p in new[]{new[]{w.From,w.To},new[]{w.To,w.From}})
    if(ds.Contains(p[0].Owner)&&(!DialEnd(p[0],ds)||!bs.Contains(p[1].Owner)||p[1].Contact!=3))return false;
   foreach(long bridge in DataBridges(all,bs,ds)){
    int door=0,plate=0;
    foreach(var w in all)foreach(var p in new[]{new[]{w.From,w.To},new[]{w.To,w.From}})if(p[0].Owner==bridge){
     if(p[0].Contact==3&&DialEnd(p[1],ds))door++;
     else if(p[0].Contact==2&&OutputEnd(p[1]))plate++;
     else return false;
    }
    if(door!=1||plate>1)return false;
   }
   return true;
  }
  internal static int Output(long dial,IEnumerable<CabinetWireSaveData> wires,IEnumerable<long> bridges,IEnumerable<long> dials) {
   var all=wires.Where(w=>!w.Burnt).ToArray();if(!Valid(all,bridges,dials))return 0;
   var targets=all.SelectMany(w=>new[]{new[]{w.From,w.To},new[]{w.To,w.From}}).Where(p=>p[0].Owner==dial&&p[0].Contact==0&&p[1].Contact==3&&bridges.Contains(p[1].Owner)).Select(p=>p[1].Owner).Distinct().ToArray();
   if(targets.Length!=1)return 0;long bridge=targets[0];
   var outputs=all.SelectMany(w=>new[]{new[]{w.From,w.To},new[]{w.To,w.From}}).Where(p=>p[0].Owner==bridge&&p[0].Contact==2&&OutputEnd(p[1])).Select(p=>p[1].Contact).Distinct().ToArray();
   return outputs.Length==1?outputs[0]:0;
  }
  internal static IEnumerable<CabinetWireSaveData> PowerWires(IEnumerable<CabinetWireSaveData> wires,IEnumerable<long> bridges,IEnumerable<long> dials) {
   var all=wires.ToArray();var ds=new HashSet<long>(dials);var data=new HashSet<long>(DataBridges(all,bridges,ds));
   return all.Where(w=>!ds.Contains(w.From.Owner)&&!ds.Contains(w.To.Owner)&&!data.Contains(w.From.Owner)&&!data.Contains(w.To.Owner));
  }
 }
}
