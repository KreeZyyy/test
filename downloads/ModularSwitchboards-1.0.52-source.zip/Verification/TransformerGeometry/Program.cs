using System;using System.Linq;using UnityEngine;using ModularSwitchboards;
class P{
 static int n;static void Check(bool b,string m){n++;if(!b)throw new Exception(m);}
 static void Main(){var original=TransformerPanelLayout.Body();var mesh=original;foreach(float side in new[]{-1f,1f}){float half=TransformerPanelLayout.Width*2.25f*.5f,edge=TransformerPanelLayout.CenterX+side*half;var hole=new Bounds(new Vector3((edge-side*.0014f)/2.25f,0,.034f/1.15f),new Vector3(.0034f/2.25f,.044f/1.35f,.045f/1.15f));mesh=TransformerCasePocket.Cut(mesh,hole);}
 Check((mesh.bounds.size-original.bounds.size).sqrMagnitude<1e-14f,"breaker silhouette changed");Check((mesh.bounds.center-original.bounds.center).sqrMagnitude<1e-14f,"breaker position changed");
 var ov=original.vertices;var on=original.normals;var mv=mesh.vertices;var mn=mesh.normals;
 for(int i=0;i<ov.Length;i++){var v=ov[i];if(Math.Abs(v.y)<.023f&&v.z>.009f&&v.z<.052f)continue;bool found=false;for(int j=0;j<mv.Length;j++)if((mv[j]-v).sqrMagnitude<1e-14f&&(mn[j]-on[i]).sqrMagnitude<1e-10f){found=true;break;}Check(found,"outer bevel vertex/normal altered at "+i+" position "+v.x+","+v.y+","+v.z+" normal "+on[i].x+","+on[i].y+","+on[i].z);}
 foreach(var normal in mn)Check(float.IsFinite(normal.x)&&float.IsFinite(normal.y)&&float.IsFinite(normal.z)&&Math.Abs(normal.sqrMagnitude-1)<.001f,"invalid pocket normal");
 foreach(var ids in mesh.T.Values)for(int i=0;i<ids.Length;i+=3)Check(Vector3.Cross(mv[ids[i+1]]-mv[ids[i]],mv[ids[i+2]]-mv[ids[i]]).sqrMagnitude>1e-22f,"zero area pocket triangle");
 var control=new Bounds(new Vector3(0,.1f,.2f),new Vector3(.2f,.1f,.03f));var region=TransformerPanelLayout.ControlsRegion(control);Check(region.min.y<control.min.y&&region.max.y>control.max.y,"front crop loses controls");Check(region.min.y>-.01f,"lower coil area enters front panel");Check(region.size.x>control.size.x,"no frame margin");Console.WriteLine(n+" actual transformer breaker-body/pocket/bevel/control crop checks passed.");}
}
