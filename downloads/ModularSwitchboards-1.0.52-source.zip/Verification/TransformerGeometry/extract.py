from pathlib import Path
root=Path(__file__).resolve().parents[2];out=Path(__file__).resolve().parent
s=(root/'Verification/ContactorGeometry/Stubs.cs').read_text().replace('public struct Vector2{','public struct Vector2{public static Vector2 zero=>new(0,0);')
s=s.replace('public struct Bounds{','public struct Bounds{public void SetMinMax(Vector3 lo,Vector3 hi){center=(lo+hi)*.5f;size=hi-lo;}')
s=s.replace('public Vector2[] uv;','public Vector2[] uv{get=>UV?.ToArray()??Array.Empty<Vector2>();set=>UV=value.ToList();}')
(out/'Stubs.cs').write_text(s)
base=(root/'Source/DinBreakerModel.cs').read_text()
def method(s,marker):
 a=s.index(marker);b=s.index('{',a);e=b+1;n=1
 while n:n+=(s[e]=='{')-(s[e]=='}');e+=1
 return s[a:e]
(out/'Extracted.cs').write_text('using System;using System.Linq;using System.Collections.Generic;using UnityEngine;namespace ModularSwitchboards{static class DinBreakerModel{internal static Vector3 VisualScale=new(2.25f,1.35f,1.15f);'+method(base,'internal static Mesh Build(')+method(base,'private static void EndDisk(')+'}static class DinTransformer{internal const int SlotCount=2;}static class DinLayout{internal const float SlotPitch=.0405f;}static class WireContactLayout{internal const float BreakerEntryY=.0375f,BreakerEntryZ=.029f;}}')

import re
slots=re.search(r"internal const int SlotCount=(\d+)",(root/"Source/DinTransformer.cs").read_text()).group(1)
p=out/"Extracted.cs";p.write_text(p.read_text().replace("internal const int SlotCount=2;","internal const int SlotCount="+slots+";"))
