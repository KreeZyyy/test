from pathlib import Path
r=Path(__file__).resolve().parents[2];s=(r/'Source/SwitchboardLabel.cs').read_text()
def method(marker):
 a=s.index(marker);b=s.index('{',a);i=b+1;depth=1
 while depth:depth+=(s[i]=='{')-(s[i]=='}');i+=1
 return s[a:i]
(Path(__file__).parent/'Extracted.cs').write_text('using System.Linq;using System.Collections.Generic;using UnityEngine;using LibConstruct;using Assets.Scripts.Objects;using Assets.Scripts.GridSystem;namespace ModularSwitchboards{'+method('internal static class LabelLayout')+'partial class SwitchboardLabel{'+method('internal static bool CanSupport(')+method('internal static bool CanPlace(')+method('internal static void SetBounds(')+'}}')
