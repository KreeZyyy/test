using System;using ModularSwitchboards;
namespace ModularSwitchboards{static class DinTransformer{public const string PrefabNameId="StructureDinTransformer";}static class SmartContactor{public const string PrefabNameId="StructureDinSmartContactor";}static class DinContactorModel{public const string PrefabName="StructureDinContactor",NcPrefabName="StructureDinContactorNC";}static class SmartOutputModel{public const string PrefabName="StructureSmartOutputModule";}static class SwitchboardsMod{public const string SmartKitName="smartkit",DoorKitName="door",CoverKitName="coverkit",RailKitName="railkit",BreakerKitName="breakerkit",CoverName="cover",RailName="rail";}}
class Program{
 static int n;static void Check(bool v){n++;if(!v)throw new Exception("Smart name migration check "+n);}
 static void Main(){const string id="StructureDinSmartModule";
 Check(SwitchboardNames.Default(id)=="DIN Smart Core Module");
 foreach(var old in new[]{"Smart Module","DIN Smart Module","Smart Core Module"})Check(SwitchboardNames.Migrate(id,old)=="DIN Smart Core Module");
 foreach(var custom in new[]{"DIN Smart Core Module","Air handling PLC","DIN Smart Module 2","",null})Check(SwitchboardNames.Migrate(id,custom)==custom);
 Check(SwitchboardNames.Migrate("OtherDevice","DIN Smart Module")=="DIN Smart Module");
 Check(SwitchboardNames.Default(SwitchboardsMod.SmartKitName)=="Kit (DIN Smart Modules)");
 Check(SwitchboardNames.Default(SmartOutputModel.PrefabName)=="DIN Smart Net Module");
 foreach(var old in new[]{"Smart Output Module","Smart Net Module"})Check(SwitchboardNames.Migrate(SmartOutputModel.PrefabName,old)=="DIN Smart Net Module");
 Check(SwitchboardNames.Migrate(SmartOutputModel.PrefabName,"Airlock network")=="Airlock network");
 Check(SwitchboardNames.Migrate(SmartContactor.PrefabNameId,"DIN Smart Contactor")=="DIN Smart Output Module");
 Check(SwitchboardNames.Migrate(SmartContactor.PrefabNameId,"Ventilation output")=="Ventilation output");
 Check(SwitchboardNames.Default(DinTransformer.PrefabNameId)=="DIN Transformer (Small)");
 Check(SwitchboardNames.Migrate(DinTransformer.PrefabNameId,"DIN Transformer")=="DIN Transformer (Small)");
 foreach(var custom in new[]{"Workshop supply","DIN Transformer (Small)","",null})Check(SwitchboardNames.Migrate(DinTransformer.PrefabNameId,custom)==custom);
 Console.WriteLine(n+" Smart Core name checks passed: old defaults migrated, custom names and prefab identity retained, shared Smart kit unchanged.");}
}
