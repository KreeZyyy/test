using System;using ModularSwitchboards;using UnityEngine;
namespace UnityEngine{
 public class MonoBehaviour{public T GetComponent<T>()where T:class=>null;}
 public class Vector3{public float y;public Vector3(float x,float y,float z){this.y=y;}}
 public class Transform{public Vector3 localPosition;}
 public class MeshRenderer{public void SetPropertyBlock(object b){}}
 public static class Time{public static float deltaTime=.016f;}
}
namespace ModularSwitchboards{
 public class DinBreaker{public bool IsCursor,IsBeingDestroyed,ContactorClosed;public object Board;}
 public class NativePortSurface{public MeshRenderer Renderer;public int Restores;public T GetComponent<T>()where T:class=>Renderer as T;public void Restore(){if(Renderer==null)throw new NullReferenceException("preview renderer stripped");Restores++;}}
 static class ContactorSwitchAudio{public static int Calls;public static void Play(DinBreaker d,bool b){Calls++;}}
}
class Program{
 static int n;static void Check(bool v,string m){n++;if(!v)throw new Exception(m);}
 static void Main(){
  var v=new DinContactorView();v.LateUpdate();Check(ContactorSwitchAudio.Calls==0,"missing owner safe");
  v.Owner=new DinBreaker{IsCursor=true};v.LateUpdate();Check(true,"missing cursor slider safe");
  v.Slider=new Transform();v.WindowSurface=new NativePortSurface();for(int i=0;i<100;i++)v.LateUpdate();Check(v.WindowSurface.Restores==0,"cursor with stripped renderer safe");
  v.Owner.IsCursor=false;v.Owner.Board=new object();v.Owner.ContactorClosed=true;v.LateUpdate();Check(ContactorSwitchAudio.Calls==0,"first active baseline silent even missing renderer");
  v.WindowSurface.Renderer=new MeshRenderer();v.LateUpdate();Check(v.WindowSurface.Restores==1,"complete renderer restored");
  v.Owner.ContactorClosed=false;v.LateUpdate();Check(ContactorSwitchAudio.Calls==1,"installed transition sounds once");
  for(int i=0;i<100;i++)v.LateUpdate();Check(ContactorSwitchAudio.Calls==1,"steady state no sound spam");
  v.WindowSurface.Renderer=null;v.LateUpdate();Check(true,"renderer removed mid lifetime safe");
  v.Owner.IsCursor=true;v.LateUpdate();v.Owner.IsCursor=false;v.Owner.ContactorClosed=true;v.LateUpdate();Check(ContactorSwitchAudio.Calls==1,"cursor reuse establishes new silent baseline");
  v.Slider=null;v.LateUpdate();Check(true,"destroyed slider safe");
  Console.WriteLine(n+" actual DinContactorView preview/lifecycle checks passed.");
 }
}
