using UnityEngine;namespace ModularSwitchboards{    public sealed class DinContactorView:MonoBehaviour
    {
        public DinBreaker Owner;
        public Transform Slider;
        public NativePortSurface WindowSurface;
        private ContactorIndicatorMotion motion;
        internal void LateUpdate()
        {
            if(Owner==null)Owner=GetComponent<DinBreaker>();
            if(Owner==null||Slider==null)return;
            if(Owner.IsCursor){motion=null;return;}
            if(motion==null)motion=new ContactorIndicatorMotion();
            bool active=!Owner.IsCursor&&!Owner.IsBeingDestroyed&&Owner.Board!=null;
            bool changed=motion.Tick(active,Owner.ContactorClosed,Time.deltaTime);
            Slider.localPosition=new Vector3(0,motion.Offset,0);
            if(WindowSurface!=null)
            {
                var renderer=WindowSurface.GetComponent<MeshRenderer>();
                if(renderer!=null){renderer.SetPropertyBlock(null);WindowSurface.Restore();}
            }
            if(changed)ContactorSwitchAudio.Play(Owner,Owner.ContactorClosed);
        }
    }
}