from pathlib import Path
import runpy
root=Path(__file__).resolve().parents[2];out=Path(__file__).resolve().parent
runpy.run_path(str(root/'Verification/TransformerGeometry/extract.py'))
s=(root/'Verification/TransformerGeometry/Stubs.cs').read_text()
(out/'Stubs.cs').write_text(s)
(out/'Extracted.cs').write_text((root/'Verification/TransformerGeometry/Extracted.cs').read_text())
