using System;using System.Linq;using System.Collections.Generic;using System.Xml.Serialization;using System.IO;using ModularSwitchboards;
class Program
{
 static int n;static void Check(bool b,string m){n++;if(!b)throw new Exception(m);}
 static CabinetWireSaveData W(long a,int p,long b,int q)=>new(){From=new(a,p),To=new(b,q)};
 static void Main()
 {
  const long relay=10,plc=20,breaker=30;int nc=ContactorCircuit.NcPin;
  var wiring=new[]{W(0,0,breaker,0),W(breaker,1,relay,0),W(plc,1,relay,2),W(relay,1,0,1),W(relay,nc,0,2)};
  foreach(bool input in new[]{false,true})foreach(bool control in new[]{false,true})foreach(bool protection in new[]{false,true})
  {
   var fixedIds=protection?new[]{breaker}:Array.Empty<long>();
   var closed=ContactorCircuit.Resolve(wiring,fixedIds,new[]{relay},Array.Empty<long>(),input,Array.Empty<long>(),control?new[]{new CabinetWireEnd(plc,1)}:null,new[]{relay});
   Check(closed.Contains(relay)==control,"A1 state independent from IN");
   var graph=ContactorCircuit.WithNormallyClosed(wiring,new[]{relay},closed).ToArray();var ids=fixedIds.Concat(closed).ToArray();
   bool no=input&&WireCircuit.Reachable(new(0,0),new(0,1),graph,ids),off=input&&WireCircuit.Reachable(new(0,0),new(0,2),graph,ids);
   Check(no==(input&&control&&protection),"NO power/protection truth table");Check(off==(input&&!control&&protection),"NC power/protection truth table");Check(!(no&&off),"break before make/no simultaneous feed");
   Check(!WireCircuit.Reachable(new(plc,1),new(0,1),graph,ids)&&!WireCircuit.Reachable(new(plc,1),new(0,2),graph,ids),"PLC cannot backfeed either mains output");
   Check(graph.Count(w=>w.From.Owner==relay&&w.From.Contact==0&&w.To.Contact==nc)==(control?0:1),"one active NC path only");
   Check(wiring.Length==5,"derived edges never mutate saved wires");
   if(input&&protection)Check(WireCircuit.Reachable(new(breaker,1),new(0,control?1:2),graph,ids),"upstream protection load path retained on either branch");
  }
  var a=new CabinetWireEnd(relay,nc);var b=new CabinetWireEnd(0,2);
  Check(a.IsSource&&!a.IsNeutral&&a.Capacity==3,"NC directional output classification");
  foreach(var ends in new[]{new[]{a,b},new[]{b,a}}){Check(WireCircuit.CanConnect(ends[0],ends[1],new List<CabinetWireSaveData>(),new[]{relay},out _),"NC wiring click order");WireCircuit.Orient(ends[0],ends[1],out var from,out var to);Check(from.Equals(a)&&to.Equals(b),"NC orientation");}
  Check(!WireCircuit.CanConnect(a,new(relay,0),new List<CabinetWireSaveData>(),new[]{relay},out _),"self wiring forbidden");
  var path=new[]{W(relay,nc,40,0)};Check(!WireCircuit.CanConnect(new(40,1),new(relay,0),path,new long[]{relay,40},out _,normallyClosed:new[]{relay}),"NC cycle rejected");
  Check(!SmartContactorCircuit.Allowed(new(plc,1),a,new[]{plc},new[]{relay}),"PLC cannot wire NC");
  var ordinary=new[]{W(0,0,40,0),W(40,1,relay,2)};
  Check(ContactorCircuit.Resolve(ordinary,new long[]{40},new[]{relay},Array.Empty<long>(),true,Array.Empty<long>(),normallyClosed:new[]{relay}).Contains(relay),"ordinary button picks up NC variant");
  Check(!ContactorCircuit.Resolve(ordinary,Array.Empty<long>(),new[]{relay},new[]{relay},true,Array.Empty<long>(),normallyClosed:new[]{relay}).Any(),"button release opens NO");
  Check(!ContactorCircuit.Resolve(ordinary,new long[]{40},new[]{relay},new[]{relay},false,Array.Empty<long>(),normallyClosed:new[]{relay}).Any(),"source loss drops stale coil");
  var battery=new[]{W(50,1,relay,0),W(relay,nc,relay+1,2)};
  Check(ContactorCircuit.Resolve(battery,Array.Empty<long>(),new[]{relay,relay+1},Array.Empty<long>(),false,new long[]{50},normallyClosed:new[]{relay}).Contains(relay+1),"battery can power coil through NC");
  var self=new[]{W(0,0,relay,0),W(relay,nc,relay,2)};var previous=Array.Empty<long>();
  for(int i=0;i<10;i++){previous=ContactorCircuit.Resolve(self,Array.Empty<long>(),new[]{relay},previous,true,Array.Empty<long>(),normallyClosed:new[]{relay}).ToArray();Check(previous.Contains(relay)==(i%2==0),"self interrupting coil advances one state per refresh");}
  var ser=new XmlSerializer(typeof(CabinetWireSaveData));using var writer=new StringWriter();ser.Serialize(writer,W(relay,nc,0,2));using var reader=new StringReader(writer.ToString());var loaded=(CabinetWireSaveData)ser.Deserialize(reader);Check(loaded.From.Equals(a)&&loaded.To.Equals(b),"NC wire XML reload preserves pin");
  Check(new CabinetWireEnd(99,2).IsNeutral&&new CabinetWireEnd(99,3).IsNeutral,"door bridge compatibility");
  Console.WriteLine(n+" NC circuit checks passed.");
 }
}
