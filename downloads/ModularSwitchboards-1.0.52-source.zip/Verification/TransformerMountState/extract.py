from pathlib import Path
r=Path(__file__).resolve().parents[2];s=(r/'Source/DinTransformer.cs').read_text();out=Path(__file__).parent

def block(marker):
 a=s.index(marker);b=s.index('{',a);e=b+1;n=1
 while n:n+=(s[e]=='{')-(s[e]=='}');e+=1
 return s[a:e]
dto=block('public sealed class DinTransformerSaveData')
methods=''.join(block(m)for m in ['public override ThingSaveData SerializeSave()','protected override void InitialiseSaveData(','public override void DeserializeSave(','public override void SerializeOnJoin(','public override void DeserializeOnJoin('])
(out/'Extracted.cs').write_text('using System.Xml.Serialization;namespace ModularSwitchboards{'+dto+'partial class DinTransformer{'+methods+'}}')
