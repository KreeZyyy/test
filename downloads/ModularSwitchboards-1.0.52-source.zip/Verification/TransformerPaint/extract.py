from pathlib import Path
r=Path(__file__).resolve().parents[2];out=Path(__file__).parent

def block(s,marker):
 a=s.index(marker);b=s.index('{',a);e=b+1;n=1
 while n:n+=(s[e]=='{')-(s[e]=='}');e+=1
 return s[a:e]
s=(r/'Source/CabinetAppearance.cs').read_text();methods=[]
for marker in ['internal static bool CanCacheRenderer','internal static void RefreshPaint(','private static void RefreshPaintCore','internal static void RegisterRenderers(','private static void RegisterRenderersCore']:
 m=block(s,marker)
 if marker in ['private static void RefreshPaintCore','private static void RegisterRenderersCore']:
  # Relevant real module branches only; independent cabinet rendering is not exercised.
  m=m[:m.index('            if (!SwitchboardsMod.IsCabinetName')]+ '        }'
 methods.append(m)
a='using System;using System.Linq;using System.Collections.Generic;using System.Xml.Serialization;using UnityEngine;namespace ModularSwitchboards{static class CabinetAppearance{static readonly System.Reflection.FieldInfo PaintMappings=typeof(Thing).GetField("_customMaterials");'+''.join(methods)+'}'
a+='static class DinBreakerModel{'+block((r/'Source/DinBreakerModel.cs').read_text(),'internal static void Refresh(')+'}'
a+='static partial class SwitchboardsMod{'+block((r/'Source/SwitchboardsMod.cs').read_text(),'private static void MigrateBreakerName(').replace('private static void','internal static void')+'}'
a+=block((r/'Source/DinBreaker.cs').read_text(),'public sealed class DinBreakerSaveData')+block((r/'Source/DinTransformer.cs').read_text(),'public sealed class DinTransformerSaveData')+'}'
(out/'Extracted.cs').write_text(a)
