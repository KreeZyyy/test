using System;using System.Collections.Generic;using System.Linq;using System.IO;using System.Xml.Serialization;using ModularSwitchboards;using UnityEngine;
namespace UnityEngine{
 public struct Color{public static Color black=>new();}
 public class Material{public int Index;}
 public class MaterialPropertyBlock{public Dictionary<int,float> Values=new();public void SetFloat(int p,float v)=>Values[p]=v;public void SetColor(int p,Color v){}public MaterialPropertyBlock Copy()=>new(){Values=new(Values)};}
 public class Mesh{public int GetIndexCount(int n)=>n==2?0:6;}public class MeshFilter{public Mesh sharedMesh=new();}
 public class MeshRenderer{public string name;public Thing Owner;public Material[] sharedMaterials=new Material[5];public MeshFilter MeshFilter=new();public Dictionary<int,MaterialPropertyBlock> Blocks=new();public T GetComponentInParent<T>()where T:class=>Owner as T;public void GetPropertyBlock(MaterialPropertyBlock b,int role){b.Values=Blocks.TryGetValue(role,out var x)?new(x.Values):new();}public void SetPropertyBlock(MaterialPropertyBlock b,int role)=>Blocks[role]=b.Copy();public float Index(int n)=>Blocks.TryGetValue(n,out var b)?b.Values.GetValueOrDefault(Thing.DiffuseIndexPropertyID,-1):-1;public void NativeOverpaint(int color){for(int i=0;i<5;i++){var b=new MaterialPropertyBlock();b.SetFloat(Thing.DiffuseIndexPropertyID,color);SetPropertyBlock(b,i);}}}
}
namespace ModularSwitchboards{
 public enum ColorType{Blue=0,Gray=1,Green=2,Orange=3,Red=4,Yellow=5,White=6,Black=7}
 public class ColorSwatch{public int Index;}
 public class Thing{public const int DiffuseIndexPropertyID=1,SmoothnessIndexPropertyID=2,EMISSION_COLOR=3;public string PrefabName;public bool OnOff;public Material PaintableMaterial=new(){Index=6};public ColorSwatch CustomColor=new(){Index=6};public Color EmissionColor;public List<MeshRenderer> Children=new();public List<ThingRenderer> Renderers=new();public List<CustomColorMapping> _customMaterials=new();public T[] GetComponentsInChildren<T>(bool all)=>Children.OfType<T>().ToArray();}
 public class Structure:Thing{public int CurrentBuildStateIndex;}
 public class DinTransformer:Thing{}
 public class DinBreaker:Thing{public bool IsDoorPart,IsSmartOutputModule;public float RatedWatts;}
 public class SmartModule:Thing{}public class SmartContactor:Thing{}public class DinRail:Thing{}public class InnerCoverModule:Thing{}public class SwitchboardLabel:Thing{}
 public class ThingRenderer{public MeshRenderer Renderer;public MeshFilter MeshFilter=>Renderer.MeshFilter;public ThingRenderer(Thing t,MeshRenderer r){Renderer=r;}}
 public class CustomColorMapping{public ThingRenderer Renderer;public int Role;public int Index;public CustomColorMapping(ThingRenderer r,int role,int i){Renderer=r;Role=role;Index=i;}}
 public class ThingSaveData{public int CustomColorIndex;public string CustomName;}
 public class StructureSaveData:ThingSaveData{}
 public class TransformerSaveData:StructureSaveData{public float OutputSetting;}
 public class PlacementBoardStructureSaveData{public int BoardId;}
 static class GameManager{public static int GetColorIndex(Material m)=>m.Index;}
 static class SwitchboardKitModel{public static bool IsKit(Thing t)=>false;public static void Refresh(Thing t){}}
 static class SwitchboardFinish{public static void Refresh(Thing t){}}
 static class SmartPaintSurface{public static void RestoreNative(Thing t){}public static bool IsPainted(string s)=>s=="DinBreakerModel";}
 static class DinRailModel{public static void Refresh(Thing t){}}
 static class CabinetGeometry{public static int[] PaletteIndices={1,6,5,7,1};}
 static class ApcLeverGeometry{public static bool Paint(MeshRenderer r,float f)=>false;}
 static class DinModuleColours{public static int Index(float f)=>3;}
 static class BreakerSwitchPose{public static int IndicatorColor(bool b)=>b?2:4;}
 static class ApcBreakerBearings{public static void Restore(Thing t){}}
 static class ModuleMechanicalSurface{public static void Restore(Thing t){}}
 static class SwitchboardNames{public static string Migrate(string p,string s)=>s;}
 static class DinModuleCatalog{public class Spec{public string Title;}public static Dictionary<string,Spec> Specs=new();}
 static partial class SwitchboardsMod{public const string CabinetName="cabinet",BreakerKitName="kit";public static bool IsCabinetName(string s)=>s==CabinetName;}
}
class P{
 static int n;static void Check(bool b,string s){n++;if(!b)throw new Exception(s);}
 static MeshRenderer Add(Thing o,string name){var r=new MeshRenderer{name=name,Owner=o};o.Children.Add(r);return r;}
 static void Main(){
 var t=new DinTransformer{PrefabName="StructureDinTransformer"};var body=Add(t,"DinBreakerModel");var surfaces=new[]{Add(t,"TransformerFront"),Add(t,"TransformerWinding"),Add(t,"TransformerDial"),Add(t,"TransformerRangeArc")};foreach(var r in t.Children)r.NativeOverpaint(0);
 Check(body.Index(1)==0&&surfaces.All(r=>r.Index(0)==0),"fixture must reproduce generic native all-blue overpaint");
 bool native=true;Check(!CabinetAppearance.CanCacheRenderer(t,ref native)&&!native,"transformer must bypass generic native renderer registration");
 var atlasSentinel=new MaterialPropertyBlock();atlasSentinel.SetFloat(1,19);foreach(var r in surfaces)r.SetPropertyBlock(atlasSentinel,0);
 CabinetAppearance.RegisterRenderers(t);
 Check(t.Renderers.Count==1&&t.Renderers[0].Renderer==body,"only body must be registered for native recolouring");
 Check(t._customMaterials.Count==1&&t._customMaterials[0].Role==1&&t._customMaterials[0].Renderer.Renderer==body,"same paintable body role as breaker");
 Check(body.Index(1)==6&&body.Index(3)==7&&body.Index(4)==1,"module palette not restored after registration");
 foreach(var r in surfaces)Check(r.Index(0)==19,"registration changed reference texture surfaces");
 foreach(int paint in new[]{6,4,0}){t.CustomColor.Index=paint;body.NativeOverpaint(paint);CabinetAppearance.RefreshPaint(t);Check(body.Index(1)==paint,"body paint not preserved");Check(body.Index(3)==7&&body.Index(4)==1,"generic property-block update changed fixed fascia or terminals");foreach(var r in surfaces)Check(r.Index(0)==19,"body paint changed winding/dial/front/arc");}
 foreach(Thing other in new Thing[]{new DinBreaker{PrefabName="breaker"},new SmartModule{PrefabName="core"}}){var b=Add(other,"DinBreakerModel");bool cached=true;Check(!CabinetAppearance.CanCacheRenderer(other,ref cached)&&!cached,"existing module paint interception changed");CabinetAppearance.RegisterRenderers(other);Check(other._customMaterials.Count==1&&other._customMaterials[0].Role==1,"existing module body mapping changed");other.CustomColor.Index=4;b.NativeOverpaint(4);CabinetAppearance.RefreshPaint(other);Check(b.Index(1)==4&&b.Index(3)==7&&b.Index(4)==1,"existing module palette/paint regressed");}
 var nativeThing=new Thing{PrefabName="StructureTransformerSmall"};native=true;Check(CabinetAppearance.CanCacheRenderer(nativeThing,ref native)&&native,"native small transformer must remain native");
 foreach(bool legacyBlue in new[]{false,true}){var save=new DinTransformerSaveData{CustomColorIndex=legacyBlue?0:4,CustomName="My branch",OutputSetting=32100,RailBoard=new(){BoardId=42}};SwitchboardsMod.MigrateBreakerName(t,save);Check(save.CustomColorIndex==6&&save.OutputSetting==32100&&save.RailBoard.BoardId==42&&save.CustomName=="My branch","legacy hidden colour migration damaged power/mount/name");}
 var xml=new XmlSerializer(typeof(DinTransformerSaveData));var painted=new DinTransformerSaveData{BodyPaintVersion=1,CustomColorIndex=0,CustomName="Deliberately blue",OutputSetting=17500,RailBoard=new(){BoardId=77}};var writer=new StringWriter();xml.Serialize(writer,painted);var restored=(DinTransformerSaveData)xml.Deserialize(new StringReader(writer.ToString()));SwitchboardsMod.MigrateBreakerName(t,restored);Check(restored.BodyPaintVersion==1&&restored.CustomColorIndex==0&&restored.OutputSetting==17500&&restored.RailBoard.BoardId==77,"new intentionally blue paint/save must survive");
 var old=(DinTransformerSaveData)xml.Deserialize(new StringReader("<DinTransformerSaveData><CustomColorIndex>0</CustomColorIndex><OutputSetting>23000</OutputSetting></DinTransformerSaveData>"));Check(old.BodyPaintVersion==0,"old XML missing version must migrate");SwitchboardsMod.MigrateBreakerName(t,old);Check(old.CustomColorIndex==6&&old.OutputSetting==23000,"old XML must load white without losing setting");
 var ordinarySave=new ThingSaveData{CustomColorIndex=0};SwitchboardsMod.MigrateBreakerName(nativeThing,ordinarySave);Check(ordinarySave.CustomColorIndex==0,"migration recoloured unrelated native transformer");
 Console.WriteLine(n+" production transformer paint registration/palette/texture-isolation/legacy and painted XML save checks passed.");
 }
}

namespace Assets.Scripts.Objects.Motherboards{public enum ColorType{White=6,Blue=0,Red=4}}
