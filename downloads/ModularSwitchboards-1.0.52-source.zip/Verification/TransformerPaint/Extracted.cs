using System;using System.Linq;using System.Collections.Generic;using System.Xml.Serialization;using UnityEngine;namespace ModularSwitchboards{static class CabinetAppearance{static readonly System.Reflection.FieldInfo PaintMappings=typeof(Thing).GetField("_customMaterials");internal static bool CanCacheRenderer(Thing __instance, ref bool __result)
        {
            if (!SwitchboardsMod.IsCabinetName(__instance.PrefabName) && !(__instance is DinRail) && !(__instance is DinBreaker) && !(__instance is SmartModule) && !(__instance is DinTransformer) && !(__instance is InnerCoverModule) && !(__instance is SwitchboardLabel) && !SwitchboardKitModel.IsKit(__instance)) return true;
            __result = false; return false;
        }internal static void RefreshPaint(Thing __instance)
        {
            RefreshPaintCore(__instance);
            if(!(__instance is DinBreaker)&&!(__instance is SmartModule)&&!(__instance is DinTransformer))SwitchboardFinish.Refresh(__instance);
        }private static void RefreshPaintCore(Thing __instance)
        {
            if(SwitchboardKitModel.IsKit(__instance)){SwitchboardKitModel.Refresh(__instance);return;}
            if (__instance is DinBreaker||__instance is SmartModule||__instance is DinTransformer) { DinBreakerModel.Refresh(__instance);SmartPaintSurface.RestoreNative(__instance); return; }
            if (__instance is DinRail) { DinRailModel.Refresh(__instance); return; }
        }internal static void RegisterRenderers(Thing __instance)
        {
            RegisterRenderersCore(__instance);
            SwitchboardFinish.Refresh(__instance);
        }private static void RegisterRenderersCore(Thing __instance)
        {
            if(__instance is DinBreaker door&&door.IsDoorPart)
            {
                __instance.Renderers=__instance.GetComponentsInChildren<MeshRenderer>(true).Where(r=>r.GetComponentInParent<Thing>()==__instance&&r.name!="DoorTerminalText").Select(r=>new ThingRenderer(__instance,r)).ToList();
                PaintMappings.SetValue(__instance,new List<CustomColorMapping>());return;
            }

            if (__instance is InnerCoverModule||SwitchboardKitModel.IsKit(__instance))
            {
                __instance.Renderers=__instance.GetComponentsInChildren<MeshRenderer>(true).Where(r=>r.GetComponentInParent<Thing>()==__instance).Select(r=>new ThingRenderer(__instance,r)).ToList();
                PaintMappings.SetValue(__instance,new List<CustomColorMapping>());if(SwitchboardKitModel.IsKit(__instance))SwitchboardKitModel.Refresh(__instance);return;
            }
            if (__instance is DinRail || __instance is DinBreaker || __instance is SmartModule || __instance is DinTransformer)
            {
                __instance.Renderers = new List<ThingRenderer>();
                var moduleMappings=new List<CustomColorMapping>();
                foreach (var renderer in __instance.GetComponentsInChildren<MeshRenderer>(true))
                    if (renderer.GetComponentInParent<Thing>() == __instance && renderer.name!="BreakerStateText" && renderer.name!="FuseCaps" && renderer.name!="IntactFuse" && renderer.name!="BurntFuse" && renderer.name!="BatteryPart" && renderer.name!="NativeApcBatteryBay" && renderer.name!="NativeAnalyserFront" && renderer.name!="BatteryContactPads")
                    {
                        // Native Thing.SetCustomColor writes every renderer in this
                        // list, even when it has no explicit paint mapping.
                        if(__instance is DinTransformer&&renderer.name!="DinBreakerModel")continue;
                        if(__instance is SmartModule&&!SmartPaintSurface.IsPainted(renderer.name))continue;
                        if(__instance is DinBreaker output&&output.IsSmartOutputModule&&renderer.name!="DinBreakerModel")continue;
                        var entry=new ThingRenderer(__instance,renderer);__instance.Renderers.Add(entry);
                        // The casing and Smart display bezel share paintable role 1.
                        // Screen, glyphs, chip and contacts remain separate.
                        if((__instance is DinBreaker||__instance is SmartModule||__instance is DinTransformer)&&(renderer.name=="DinBreakerModel"||__instance is SmartModule&&renderer.name=="NativeLEDBezel")&&entry.MeshFilter.sharedMesh.GetIndexCount(1)>0)
                            moduleMappings.Add(new CustomColorMapping(entry,1,GameManager.GetColorIndex(__instance.PaintableMaterial)));
                    }
                PaintMappings.SetValue(__instance,moduleMappings);
                if (__instance is DinBreaker||__instance is SmartModule||__instance is DinTransformer){DinBreakerModel.Refresh(__instance);SmartPaintSurface.RestoreNative(__instance);}else DinRailModel.Refresh(__instance);
                return;
            }
        }}static class DinBreakerModel{internal static void Refresh(Thing module)
        {
            if(module is DinBreaker led&&led.IsDoorPart)return;
            foreach(var renderer in module.GetComponentsInChildren<MeshRenderer>(true))
            {
                if(renderer.GetComponentInParent<Thing>()!=module ||
                    (renderer.name!="DinBreakerModel" && !((module is SmartModule||module is SmartContactor)&&renderer.name=="NativeLEDBezel") && renderer.name!="BreakerLever" && renderer.name!="BreakerIndicator" && renderer.name!="FuseCartridge" && renderer.name!="ModuleRatingPlate" && renderer.name!="FuseContacts" && renderer.name!="ContactorMechanicalSlider" && renderer.name!="ContactorOnPanel" && renderer.name!="ContactorOffPanel" && renderer.name!="ContactorGuide"))continue;
                if(renderer.name=="BreakerLever" && module is DinBreaker rated)
                {
                    if(ApcLeverGeometry.Paint(renderer,rated.RatedWatts))continue;
                    int colour=DinModuleColours.Index(rated.RatedWatts);
                    for(int index=0;index<renderer.sharedMaterials.Length;index++){var block=new MaterialPropertyBlock();block.SetFloat(Thing.DiffuseIndexPropertyID,colour);block.SetColor(Thing.EMISSION_COLOR,Color.black);renderer.SetPropertyBlock(block,index);}continue;
                }
                for(int role=0;role<5;role++)
                {
                    var block=new MaterialPropertyBlock();renderer.GetPropertyBlock(block,role);
                    int color=role==0?(int)ColorType.Orange:CabinetGeometry.PaletteIndices[role];
                    if((renderer.name=="DinBreakerModel"||(module is SmartModule||module is SmartContactor)&&renderer.name=="NativeLEDBezel")&&role==1)color=module.CustomColor==null?(int)ColorType.White:module.CustomColor.Index;
                    if(renderer.name=="FuseCartridge")color=CabinetGeometry.PaletteIndices[3];
                    if(renderer.name=="ModuleRatingPlate")color=CabinetGeometry.PaletteIndices[1];
                    if(renderer.name=="ContactorOnPanel")color=(int)ColorType.Green;
                    if(renderer.name=="ContactorOffPanel")color=(int)ColorType.Red;
                    if(renderer.name=="BreakerIndicator") color=BreakerSwitchPose.IndicatorColor(module.OnOff);
                    block.SetFloat(Thing.DiffuseIndexPropertyID,color);
                    block.SetFloat(Thing.SmoothnessIndexPropertyID,0f);
                    block.SetColor(Thing.EMISSION_COLOR,(renderer.name=="DinBreakerModel"||(module is SmartModule||module is SmartContactor)&&renderer.name=="NativeLEDBezel")&&role==1?module.EmissionColor:Color.black);renderer.SetPropertyBlock(block,role);
                }
            }
            // State/lever updates also call this method directly, bypassing paint hooks.
            SwitchboardFinish.Refresh(module);
            ApcBreakerBearings.Restore(module);
            ModuleMechanicalSurface.Restore(module);
        }}static partial class SwitchboardsMod{internal static void MigrateBreakerName(Thing __instance, ThingSaveData __0)
        {
            __0.CustomName=SwitchboardNames.Migrate(__instance.PrefabName,__0.CustomName);
            // Previously modules had fixed white casings, while the hidden native
            // color could come from the locker template. Migrate old saves once.
            if(__instance is DinBreaker && __0 is DinBreakerSaveData paintSave && paintSave.BodyPaintVersion<1)
                __0.CustomColorIndex=(int)Assets.Scripts.Objects.Motherboards.ColorType.White;
            // The transformer previously bypassed the module paint registration.
            // Discard that legacy hidden template colour once, as for breakers.
            if(__instance is DinTransformer && __0 is DinTransformerSaveData transformerPaintSave && transformerPaintSave.BodyPaintVersion<1)
                __0.CustomColorIndex=(int)Assets.Scripts.Objects.Motherboards.ColorType.White;


            if(__instance.PrefabName==CabinetName && (__0.CustomName=="Switchboard Cabinet" || __0.CustomName=="Switchboard")) __0.CustomName="Switchboard Small";
            if(DinModuleCatalog.Specs.TryGetValue(__instance.PrefabName,out var spec)&&(__0.CustomName=="DIN Breaker 1P"||__0.CustomName=="DIN Breaker")) __0.CustomName=spec.Title;
            // Migrate only the old default titles; preserve player custom names.
            if((__instance.PrefabName=="StructureDinBatteryBackup"&&__0.CustomName=="DIN Battery Backup (2 slots)")||
                (__instance.PrefabName=="StructureDinCableAnalyser"&&__0.CustomName=="DIN Cable Analyzer (3 slots)"))
                __0.CustomName=DinModuleCatalog.Specs[__instance.PrefabName].Title;
            if(__instance.PrefabName==BreakerKitName && (__0.CustomName=="Kit (DIN Breaker 1P)"||__0.CustomName=="Kit (DIN Breaker)")) __0.CustomName="Kit (Switchboard Modules)";
        }}public sealed class DinBreakerSaveData : StructureSaveData
    {
        [XmlElement] public PlacementBoardStructureSaveData RailBoard;
        [XmlElement] public bool Tripped;
        [XmlElement] public int BodyPaintVersion;
    }public sealed class DinTransformerSaveData:TransformerSaveData
    {
        [XmlElement]public PlacementBoardStructureSaveData RailBoard;
        [XmlElement]public int BodyPaintVersion;
        [XmlElement]public int ModuleSlots;
    }}