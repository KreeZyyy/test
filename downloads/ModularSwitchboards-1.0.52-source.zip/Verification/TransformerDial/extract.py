from pathlib import Path
r=Path(__file__).resolve().parents[2]
s=(r/'Art/TransformerControl-reference.cs.txt').read_text()
(Path(__file__).parent/'Extracted.cs').write_text('using System;namespace Fixture{partial class NativeTransformer{'+s+'}}')
