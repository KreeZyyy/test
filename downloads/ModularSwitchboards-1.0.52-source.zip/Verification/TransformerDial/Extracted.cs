using System;namespace Fixture{partial class NativeTransformer{public double Setting
	{
		get
		{
			return _outputSetting;
		}
		set
		{
			_outputSetting = Mathf.Clamp((float)value, 0f, OutputMaximum);
			if (NetworkManager.IsServer)
			{
				base.NetworkUpdateFlags |= 256;
			}
			SetKnob();
		}
	}
public void SetKnob()
	{
		if (ThreadedManager.IsThread)
		{
			SetKnobFromThread().Forget();
		}
		else if (!(_needleTransform == null))
		{
			_needleRotation = Mathf.Lerp(NeedleMinimum, NeedleMaximum, (float)Setting / OutputMaximum);
			_needleTransform.localRotation = _needleBaseRotation;
			_needleTransform.Rotate(0f, _needleRotation, 0f, Space.Self);
		}
	}
public override DelayedActionInstance InteractWith(Interactable interactable, Interaction interaction, bool doAction = true)
	{
		DelayedActionInstance delayedActionInstance = HandleButtonSetting(interactable, interaction, doAction);
		if (delayedActionInstance != null)
		{
			return delayedActionInstance;
		}
		DelayedActionInstance delayedActionInstance2 = new DelayedActionInstance
		{
			Duration = 0f,
			ActionMessage = interactable.ContextualName
		};
		delayedActionInstance2.AppendStateMessage(GameStrings.OutputWatts, StringManager.Get((int)Setting));
		delayedActionInstance2.AppendStateMessage(GameStrings.HoldForSmallIncrements, Localization.QuantityModifierKey);
		delayedActionInstance2.AppendStateMessage(GameStrings.UseLabelerToSet);
		double num = Setting;
		switch (interactable.Action)
		{
		case InteractableType.Button2:
			delayedActionInstance2.ActionMessage = GameStrings.GlobalIncrease.AsString();
			if (doAction && num < (double)OutputMaximum)
			{
				PlayPooledAudioSound(Defines.Sounds.DialTurn, _needleTransform.localPosition);
			}
			if (GameManager.RunSimulation && doAction)
			{
				if (num < (double)OutputMaximum)
				{
					num += (double)(interaction.AltKey ? StepSmall : StepNormal);
				}
				Setting = Mathf.Min((float)num, OutputMaximum);
			}
			return delayedActionInstance2.Succeed();
		case InteractableType.Button1:
			delayedActionInstance2.ActionMessage = GameStrings.GlobalDecrease.AsString();
			if (doAction && num > 0.0)
			{
				PlayPooledAudioSound(Defines.Sounds.DialTurn, _needleTransform.localPosition);
			}
			if (GameManager.RunSimulation && doAction)
			{
				if (num > 0.0)
				{
					num -= (double)(interaction.AltKey ? StepSmall : StepNormal);
				}
				Setting = Mathf.Max((float)num, 0f);
			}
			return delayedActionInstance2.Succeed();
		default:
			return base.InteractWith(interactable, interaction, doAction);
		}
	}}}