using System;using System.Linq;using System.Collections.Generic;using Assets.Scripts.Networks;using Assets.Scripts.Objects.Items;using ModularSwitchboards;
static class TransformerHarness
{
 static int n;static void Check(bool b,string m){n++;if(!b)throw new Exception(m);}
 static CabinetWireSaveData W(long a,int p,long b,int q)=>new(){From=new(a,p),To=new(b,q)};
 static CabinetPowerNode T(long id,float limit)=>new(){ReferenceId=id,IsTransformer=true,Conducting=limit>0,TransferLimit=limit};
 internal static void Run()
 {
  foreach(bool batteryMode in new[]{false,true})foreach(bool reverse in new[]{false,true})
  {
   var c=new SwitchboardCabinet();var input=new CableNetwork{PotentialLoad=batteryMode?0:50000};var one=new CableNetwork{RequiredLoad=5000};var two=new CableNetwork{RequiredLoad=5000};c.InputConnection.cable.CableNetwork=input;c.Output1Connection.cable.CableNetwork=one;c.Output2Connection.cable.CableNetwork=two;
   var cell=new BatteryCell{ReferenceId=150,PowerStored=50000,PowerMaximum=50000};var battery=new CabinetPowerNode{ReferenceId=50,Conducting=true,IsBatteryModule=true,Battery=cell};var transformer=T(10,5000);var fuse=new CabinetPowerNode{ReferenceId=30,Conducting=true,RatedWatts=10000};var modules=batteryMode?new[]{transformer,battery,fuse}:new[]{transformer,fuse};
   var wires=new[]{W(batteryMode?50:0,batteryMode?1:0,30,0),W(30,1,10,0),W(10,1,0,1),W(10,1,0,2)};var p=new CabinetWiringPower();p.RefreshNodes(c,wires,modules);
   float a=p.Generated(one),b=p.Generated(two);Check(Math.Abs(a+b-5000)<.01f,"shared transformer duplicated or lost capacity");Check(a==p.Generated(one)&&b==p.Generated(two),"native double query changed budget");
   if(reverse){p.Use(two,b);p.Use(one,a);}else{p.Use(one,a);p.Use(two,b);}Check(p.DrainTrips().Length==0,"transformer tripped instead of limiting");
   Check(batteryMode?cell.PowerStored==45000&&p.Used(input)==0:p.Used(input)==5000,"limited transfer energy conservation");if(!batteryMode)p.Receive(input,5000);
   // Start the next provider frame in either branch order; total still capped.
   if(reverse){b=p.Generated(two);a=p.Generated(one);}else{a=p.Generated(one);b=p.Generated(two);}Check(a+b<=5000.01f,"sequential native ticks duplicated transformer budget");p.ObserveIdle(one);p.ObserveIdle(two);
   fuse.RatedWatts=1000;p.RefreshNodes(c,wires,modules);a=p.Generated(one);p.Use(one,Math.Min(a,1500));Check(p.DrainTrips().Contains(30),"upstream protection bypassed by limiter");p.ObserveIdle(one);
   transformer.Conducting=false;p.RefreshNodes(c,wires,modules);Check(p.Generated(one)==0&&p.Generated(two)==0,"OFF or zero setting passed power");
   transformer.Conducting=true;transformer.TransferLimit=700;p.RefreshNodes(c,wires,modules);p.ObserveIdle(one);p.ObserveIdle(two);Check(p.Generated(one)+p.Generated(two)<=700.01f,"decreased setting not applied");p.ObserveIdle(one);p.ObserveIdle(two);
   input.PotentialLoad=0;cell.PowerStored=0;p.RefreshNodes(c,wires,modules);Check(p.Generated(one)==0&&p.Generated(two)==0,"no IN manufactured power");
  }
  // Charging a native cell through the limiter is capped and billed to IN.
  {
   var c=new SwitchboardCabinet();var input=new CableNetwork{PotentialLoad=50000};c.InputConnection.cable.CableNetwork=input;var cell=new BatteryCell{ReferenceId=150,PowerStored=0,PowerMaximum=5000};var t=T(10,250);var battery=new CabinetPowerNode{ReferenceId=50,Conducting=true,IsBatteryModule=true,Battery=cell};var modules=new[]{t,battery};var wires=new[]{W(0,0,10,0),W(10,1,50,0)};var p=new CabinetWiringPower();p.RefreshNodes(c,wires,modules);Check(p.Used(input)==250,"charging demand bypassed transformer");p.Receive(input,250);Check(cell.PowerStored==250,"charge limit or energy wrong");Check(p.Used(input)==250,"next charge tick stuck at zero");p.Receive(input,250);Check(cell.PowerStored==500,"second charge tick wrong");
  }
  // Completing a charge must release its old tick's transfer reservation.
  {
   var c=new SwitchboardCabinet();var input=new CableNetwork{PotentialLoad=50000};var output=new CableNetwork{RequiredLoad=1000};c.InputConnection.cable.CableNetwork=input;c.Output1Connection.cable.CableNetwork=output;var cell=new BatteryCell{ReferenceId=150,PowerStored=0,PowerMaximum=250};var battery=new CabinetPowerNode{ReferenceId=50,Conducting=true,IsBatteryModule=true,Battery=cell};var p=new CabinetWiringPower();var wires=new[]{W(0,0,10,0),W(10,1,50,0),W(10,1,0,1)};p.RefreshNodes(c,wires,new[]{T(10,250),battery});Check(p.Used(input)==250,"initial charge demand");p.Receive(input,250);Check(cell.PowerStored==250&&p.Used(input)==0,"completed charge demand did not clear");Check(p.Generated(output)==250,"old charge tick permanently blocks output capacity");
  }
  // External and upstream battery supply share the SAME limiter.
  {
   var c=new SwitchboardCabinet();var input=new CableNetwork{PotentialLoad=1000};var output=new CableNetwork{RequiredLoad=10000};c.InputConnection.cable.CableNetwork=input;c.Output1Connection.cable.CableNetwork=output;var cell=new BatteryCell{ReferenceId=150,PowerStored=5000,PowerMaximum=5000};var battery=new CabinetPowerNode{ReferenceId=50,Conducting=true,IsBatteryModule=true,Battery=cell};var p=new CabinetWiringPower();var wires=new[]{W(0,0,50,0),W(50,1,10,0),W(10,1,0,1)};p.RefreshNodes(c,wires,new[]{T(10,2000),battery});float offered=p.Generated(output);Check(offered==2000,"mixed sources each claim full transformer limit");p.Use(output,offered);Check(cell.PowerStored==4000&&p.Used(input)>=1000,"mixed source energy wrong");
  }
  // Power crosses the transformer; native data classification does not.
  {
   var graph=new[]{W(0,0,10,0),W(10,1,0,2),W(10,1,90,0)};
   Check(WireCircuit.Reachable(new(0,0),new(90,0),graph,new long[]{10}),"power fails to cross transformer");
   Check(SmartCircuit.Selection(90,graph,Array.Empty<long>(),Array.Empty<long>())==2,"downstream Net/Core consumer migrated to input data network");
   Check(SmartCircuit.Selection(10,graph,Array.Empty<long>(),Array.Empty<long>())==AnalyserCircuit.Input,"transformer setting device not on IN side");
   Check(!WireCircuit.Reachable(new(10,1),new(0,0),graph,new long[]{10}),"backfeed from transformer OUT to IN");
  }
  var rng=new Random(741);
  for(int k=0;k<1000;k++)
  {
   float supply=rng.Next(1,100000),a=rng.Next(0,50000),b=rng.Next(0,50000);var limits=new Dictionary<long,float>{{10,a},{11,b}};long[][] paths={new long[]{10},new long[]{10,11},Array.Empty<long>()};var demands=new[]{(float)rng.Next(10000),(float)rng.Next(10000),(float)rng.Next(10000)};var amounts=TransformerBudget.Allocate(supply,demands,new[]{true,true,true},paths,limits);
   Check(amounts.All(x=>x>=0&&float.IsFinite(x)),"invalid allocation");Check(amounts.Sum()<=supply+.05f,"supply multiplied");Check(amounts[0]+amounts[1]<=a+.05f&&amounts[1]<=b+.05f,"serial/shared cap exceeded");Check(Math.Abs(amounts.Sum()-supply)<.05f,"uncapped independent bypass branch starved");
  }
  Console.WriteLine(n+" transformer power checks passed: native min limit, shared branches, both callback orders, batteries, charging, protection, no-source/OFF, serial limits and bypass headroom.");
 }
}
