using System;using System.Linq;using ModularSwitchboards;using Assets.Scripts.Networks;using Assets.Scripts.Objects.Items;
static class NormallyClosedPowerHarness
{
 static int n;static void Check(bool b,string m){n++;if(!b)throw new Exception(m);}
 static CabinetWireSaveData W(long a,int p,long b,int q)=>new(){From=new(a,p),To=new(b,q)};
 internal static void Run()
 {
  foreach(bool batteryMode in new[]{false,true})foreach(bool energized in new[]{false,true})
  {
   var c=new SwitchboardCabinet();var input=new CableNetwork{PotentialLoad=batteryMode?0:2000};var no=new CableNetwork{RequiredLoad=1500};var nc=new CableNetwork{RequiredLoad=1500};c.InputConnection.cable.CableNetwork=input;c.Output1Connection.cable.CableNetwork=no;c.Output2Connection.cable.CableNetwork=nc;
   var protect=new DinBreaker{ReferenceId=30,OnOff=true,RatedWatts=1000};var relay=new DinBreaker{ReferenceId=10,IsContactor=true,ContactorClosed=energized};var cell=new BatteryCell{ReferenceId=100,PowerStored=3000,PowerMaximum=5000};var battery=new DinBreaker{ReferenceId=50,IsBatteryModule=true,Battery=cell};
   var modules=batteryMode?new[]{protect,relay,battery}:new[]{protect,relay};
   var wires=new[]{W(batteryMode?50:0,batteryMode?1:0,30,0),W(30,1,10,0),W(10,1,0,1),W(10,ContactorCircuit.NcPin,0,2)};
   CabinetWireSaveData[] Graph()=>ContactorCircuit.WithNormallyClosed(wires,new long[]{10},energized?new long[]{10}:Array.Empty<long>()).ToArray();
   var p=new CabinetWiringPower();p.Refresh(c,Graph(),modules);var selected=energized?no:nc;var blocked=energized?nc:no;
   Check(p.Generated(selected)==(batteryMode?3000:2000),"NC/NO actual provider budget");Check(p.Generated(blocked)==0,"inactive output generates no power");
   p.Use(selected,1500);Check(p.DrainTrips().SequenceEqual(new long[]{30}),"active NC/NO load trips only real upstream protection");
   Check(batteryMode?cell.PowerStored==1500&&p.Used(input)==0:p.Used(input)==1500,"consumed energy charged to correct source");
   if(!batteryMode)p.Receive(input,1500);
   protect.OnOff=false;p.Refresh(c,Graph(),modules);Check(p.Generated(no)==0&&p.Generated(nc)==0,"protection opening blocks both branches");
   protect.OnOff=true;if(batteryMode)cell.PowerStored=0;else input.PotentialLoad=0;p.Refresh(c,Graph(),modules);Check(p.Generated(no)==0&&p.Generated(nc)==0,"lost IN supplies neither branch");
  }
  Console.WriteLine(n+" NC production power checks passed: mains/battery, both states, protection and energy accounting.");
 }
}
