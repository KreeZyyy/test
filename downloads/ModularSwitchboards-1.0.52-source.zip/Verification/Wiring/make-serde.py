from pathlib import Path
s=(Path(__file__).resolve().parents[2]/'Source/CabinetWiring.cs').read_text();a=s.index('        internal static float[] Flatten');b=s.index('        private void Color',a)
out='''using System;using System.Linq;using System.Collections.Generic;using System.IO;using ModularSwitchboards;
class RocketBinaryWriter{readonly BinaryWriter w;public RocketBinaryWriter(Stream s){w=new(s);}public void WriteInt32(int i)=>w.Write(i);public void WriteInt64(long i)=>w.Write(i);public void WriteSingle(float f)=>w.Write(f);}
class RocketBinaryReader{readonly BinaryReader r;public RocketBinaryReader(Stream s){r=new(s);}public int ReadInt32()=>r.ReadInt32();public long ReadInt64()=>r.ReadInt64();public float ReadSingle()=>r.ReadSingle();}
static class GameManager{public static bool RunSimulation=false;}
partial class SerdeHarness{internal SwitchboardCabinet Owner=new();const int CurrentRouteVersion=6;readonly List<CabinetWireSaveData> wires=new();readonly Dictionary<long,CabinetWireEnd> pending=new();readonly Dictionary<long,float> pendingUntil=new();string topology;int revision,routeRevision;bool rebuild,needsReroute,cleanupOnLoad;
'''+s[a:b]+'''
 internal static void AssertRoundTrip(CabinetWireSaveData wire)
 {
  var first=new SerdeHarness();first.Load(new[]{wire});if(first.wires.Count!=1)throw new Exception("Real routed wire rejected by save validation");
  using var stream=new MemoryStream();first.Write(new(stream));stream.Position=0;var second=new SerdeHarness();second.Read(new(stream));
  if(second.wires.Count!=1||!second.wires[0].Points.SequenceEqual(wire.Points))throw new Exception("Real routed wire lost on network/load roundtrip");
 }
 internal static void Run(){var h=new SerdeHarness();var a=new CabinetWireEnd(0,0);var b=new CabinetWireEnd(51,0);var wire=new CabinetWireSaveData{From=a,To=b,InputSlot=3,RouteVersion=2,ColorIndex=7,Points=new[]{0f,.217f,.0463f,.012f,.171f,.108f}};h.Load(new[]{wire});h.pending[123]=a;using var stream=new MemoryStream();h.Write(new(stream));stream.Position=0;var restored=new SerdeHarness();restored.Read(new(stream));if(restored.wires.Count!=1||restored.wires[0].ColorIndex!=7||restored.wires[0].InputSlot!=3||restored.wires[0].RouteVersion!=2||!restored.wires[0].To.Equals(b)||!restored.wires[0].Points.SequenceEqual(wire.Points)||!restored.pending[123].Equals(a))throw new Exception("Wire network roundtrip failed");
 var serializer=new System.Xml.Serialization.XmlSerializer(typeof(CabinetWireSaveData));var sw=new StringWriter();serializer.Serialize(sw,wire);var painted=(CabinetWireSaveData)serializer.Deserialize(new StringReader(sw.ToString()));if(painted.ColorIndex!=7)throw new Exception("Wire XML color lost");var oldXml=sw.ToString().Replace(" ColorIndex=\\"7\\"","");var oldWire=(CabinetWireSaveData)serializer.Deserialize(new StringReader(oldXml));if(oldWire.ColorIndex!=-1)throw new Exception("Old save no longer defaults red");
 using(var legacy=new MemoryStream()){var lw=new RocketBinaryWriter(legacy);lw.WriteInt32(1);WriteEnd(lw,wire.From);WriteEnd(lw,wire.To);lw.WriteInt32(wire.InputSlot);lw.WriteInt32(wire.RouteVersion);lw.WriteInt32(wire.Points.Length);foreach(float value in wire.Points)lw.WriteSingle(value);lw.WriteInt32(0);legacy.Position=0;var oldReader=new SerdeHarness();oldReader.Read(new(legacy));if(oldReader.wires.Count!=1||oldReader.wires[0].ColorIndex!=-1||!oldReader.wires[0].Points.SequenceEqual(wire.Points))throw new Exception("Legacy binary wire packet unreadable");}
 AssertRoundTrip(new(){From=new(10,1),To=new(900,2),RouteVersion=4,Points=new[]{-.10125f,.042f,.06535f,-.197f,.144f,.06535f,-.192f,.144f,.0244f}});
 AssertRoundTrip(new(){From=new(10,ContactorCircuit.NcPin),To=new(0,2),RouteVersion=6,Points=new[]{0f,0f,.05f,.02f,-.1f,.05f}});
 var passage=new CabinetWireSaveData{From=new(900,3),To=new(0,2),RouteVersion=4,Points=new[]{-.164f,.204f,.06535f,.108f,-.184f,.06535f}};
 restored.Load(new[]{passage});using(var joined=new MemoryStream()){restored.Write(new(joined));joined.Position=0;var again=new SerdeHarness();again.Read(new(joined));if(again.wires.Count!=1||again.wires[0].From.Contact!=3||!again.wires[0].Points.SequenceEqual(passage.Points))throw new Exception("Highest bridge channel lost");}
 passage.From.Contact=39;restored.Load(new[]{passage});if(restored.wires.Count!=0)throw new Exception("Invalid bridge channel accepted");
 Console.WriteLine("Wire color: XML and versioned binary roundtrip, legacy XML defaults red, legacy binary reader preserves routes.");
 GameManager.RunSimulation=true;restored.Load(new[]{wire});if(!restored.needsReroute)throw new Exception("Version 2 migration not scheduled");var old=new CabinetWireSaveData{From=new(0,0),To=new(0,2),RouteVersion=0,Points=new[]{0f,.205f,.0463f,.1f,-.205f,.0463f}};restored.Load(new[]{old});if(restored.wires.Count!=1||!restored.needsReroute)throw new Exception("Legacy bypass or migration request lost");GameManager.RunSimulation=false;
 wire.Points[0]=float.NaN;restored.Load(new[]{wire});if(restored.wires.Count!=0)throw new Exception("Invalid path accepted");using var bad=new MemoryStream();new RocketBinaryWriter(bad).WriteInt32(65);bad.Position=0;bool rejected=false;try{restored.Read(new(bad));}catch(InvalidOperationException){rejected=true;}if(!rejected)throw new Exception("Invalid network count accepted");Console.WriteLine("Production wire save/network serialization passed: endpoints, exact path, fan slot, player selection and malformed data guards.");}
}
'''
(Path(__file__).resolve().parent/'SerdeHarness.cs').write_text(out)
