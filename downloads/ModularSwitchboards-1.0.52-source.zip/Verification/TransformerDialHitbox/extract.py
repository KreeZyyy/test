from pathlib import Path
r=Path(__file__).resolve().parents[2]
s=(r/'Source/TransformerFrontGeometry.cs').read_text().splitlines()
lines=[line for line in s if 'internal const float KnobRadius='in line or 'internal static readonly Vector3 KnobCenter='in line]
(Path(__file__).parent/'Extracted.cs').write_text('using UnityEngine;namespace ModularSwitchboards{static class TransformerPanelLayout{public const float CenterX=.02025f;}static class TransformerFrontGeometry{'+''.join(lines)+'}}')
