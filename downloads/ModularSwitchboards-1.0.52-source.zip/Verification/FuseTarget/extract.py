from pathlib import Path
import runpy
r=Path(__file__).resolve().parents[2];v=Path(__file__).parent
runpy.run_path(str(r/'Verification/TransformerGeometry/extract.py'))
def method(s,m):
 a=s.index(m);b=s.index('{',a);e=b+1;n=1
 while n:n+=(s[e]=='{')-(s[e]=='}');e+=1
 return s[a:e]
(v/'Stubs.cs').write_text((r/'Verification/TransformerGeometry/Stubs.cs').read_text())
s=(r/'Verification/TransformerGeometry/Extracted.cs').read_text()
s+='namespace ModularSwitchboards{static class DinFuseModel{'+method((r/'Source/DinFuseModel.cs').read_text(),'internal static Mesh Housing()')+'}static class ModuleFrontHitbox{'+method((r/'Source/ModuleFrontHitbox.cs').read_text(),'internal static Bounds LocalBounds(')+'}}'
p=(r/'Source/DinModuleAccess.cs').read_text();a=p.index('housingCollider.center=');b=p.index(';',p.index('housingCollider.size=',a))+1
s+='namespace ModularSwitchboards{static class InstalledFuseCollider{internal static void Fit(UnityEngine.BoxCollider housingCollider,UnityEngine.Mesh housing){'+p[a:b]+'}}}'
(v/'Extracted.cs').write_text(s)
