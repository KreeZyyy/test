using Assets.Scripts.Sound;using System;using System.Linq;using System.Collections.Generic;using UnityEngine;namespace Assets.Scripts.Sound{public partial class GameAudioSource{public void Init(IAudioParent parent)
	{
		Parent = parent;
		_priority = AudioSource.priority;
		_minDistance = AudioSource.minDistance;
		_maxDistance = AudioSource.maxDistance;
	}}}namespace ModularSwitchboards{public partial class NativeThing{private void InitAudio()
	{
		if (IsCursor)
		{
			return;
		}
		foreach (GameAudioSource audioSource in AudioSources)
		{
			audioSource.Init(this);
		}
		foreach (GameAudioEvent audioEvent in AudioEvents)
		{
			audioEvent.SetConcurrencyIds();
		}
		foreach (Interactable interactable in Interactables)
		{
			foreach (GameAudioEvent associatedAudioEvent in interactable.AssociatedAudioEvents)
			{
				associatedAudioEvent.SetConcurrencyIds();
			}
		}
	}}public partial class NativeTransformer{public override void Awake()
	{
		base.Awake();
		_needleTransform = Needle.transform;
		_needleBaseRotation = _needleTransform.localRotation;
		SetKnob();
	}}public partial class DinTransformer{public override void Awake(){CacheStates(true);PrefabAudioOwner.PrepareInstance(this);base.Awake();BoardStructureHooks.Awake(this);}}static class Rewrite{public static void Broken(DinTransformer owner){foreach(var child in owner.transform.Cast<Transform>().ToArray())UnityEngine.Object.DestroyImmediate(child.gameObject);}public static HashSet<Transform> Fixed(DinTransformer owner){var audioRoots=TransformerAudio.PreserveSources(owner);foreach(var child in owner.transform.Cast<Transform>().ToArray())if(!audioRoots.Contains(child))UnityEngine.Object.DestroyImmediate(child.gameObject);return audioRoots;}}}