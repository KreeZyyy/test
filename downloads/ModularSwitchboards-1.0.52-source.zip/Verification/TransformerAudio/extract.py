from pathlib import Path
r=Path(__file__).resolve().parents[2];out=Path(__file__).parent
# Source references captured from the installed game's C# methods.
def block(s,marker):
 a=s.index(marker);b=s.index('{',a);e=b+1;n=1
 while n:n+=(s[e]=='{')-(s[e]=='}');e+=1
 return s[a:e]
ref=(out/'NativeInit-reference.txt').read_text().split('\n// NEXT METHOD\n')
text='using Assets.Scripts.Sound;using System;using System.Linq;using System.Collections.Generic;using UnityEngine;namespace Assets.Scripts.Sound{public partial class GameAudioSource{'+ref[0]+'}}namespace ModularSwitchboards{public partial class NativeThing{'+ref[1]+'}public partial class NativeTransformer{'+ref[2]+'}public partial class DinTransformer{'+block((r/'Source/DinTransformer.cs').read_text(),'public override void Awake()')+'}'
new=(r/'Source/DinTransformerModel.cs').read_text();line=next(l.strip()for l in new.splitlines()if 'foreach(var child in owner.transform.Cast<Transform>()'in l)
old=line.replace('if(!audioRoots.Contains(child))','')
text+='static class Rewrite{public static void Broken(DinTransformer owner){'+old+'}public static HashSet<Transform> Fixed(DinTransformer owner){var audioRoots=TransformerAudio.PreserveSources(owner);'+line+'return audioRoots;}}}'
(out/'Extracted.cs').write_text(text)
