using System;using System.Collections;using System.Collections.Generic;using System.Linq;using ModularSwitchboards;using UnityEngine;using Assets.Scripts.Sound;
namespace UnityEngine{
 public struct Vector3{public float x,y,z;public Vector3(float a,float b,float c){x=a;y=b;z=c;}public static Vector3 one=>new(1,1,1);}public struct Quaternion{public static Quaternion identity=>new();}
 public class GameObject{public Transform transform;public bool Destroyed;public GameObject(){transform=new Transform(this);}public void Destroy(){foreach(var c in transform.Children.ToArray())c.gameObject.Destroy();Destroyed=true;transform.parent?.Children.Remove(transform);}}
 public class Transform:IEnumerable{public GameObject gameObject;public Transform parent;public List<Transform> Children=new();public Vector3 localPosition,localScale;public Quaternion localRotation;public Transform(GameObject o){gameObject=o;}public void SetParent(Transform p,bool world){parent?.Children.Remove(this);parent=p;p.Children.Add(this);}public IEnumerator GetEnumerator()=>Children.GetEnumerator();}
 public class Object{public static void DestroyImmediate(GameObject g)=>g.Destroy();}
 public class AudioSource{public Transform transform;public int priority{get{Alive();return 73;}}public float minDistance{get{Alive();return .8f;}}public float maxDistance{get{Alive();return 23f;}}void Alive(){if(transform.gameObject.Destroyed)throw new NullReferenceException("AudioSource destroyed by model rewrite");}}
}
namespace Assets.Scripts.Sound{
 public interface IAudioParent{}
 public partial class GameAudioSource{public string Name;public float SourcePitch=1.2f,SourceVolume=.7f;public IAudioParent Parent;public AudioSource AudioSource;private int _priority;private float _minDistance,_maxDistance;public bool Ready=>_priority==73&&Math.Abs(_minDistance-.8)<.0001&&_maxDistance==23;}
 public class GameAudioEvent{public int Count;public void SetConcurrencyIds(){Count++;}}
}
namespace ModularSwitchboards{
 public class Interactable{public List<GameAudioEvent> AssociatedAudioEvents=new();}
 public partial class NativeThing:IAudioParent{public Transform transform=new GameObject().transform;public bool IsCursor,RendererReady;public List<GameAudioSource> AudioSources=new();public List<GameAudioEvent> AudioEvents=new();public List<Interactable> Interactables=new();public virtual void Awake(){InitAudio();RendererReady=true;}}
 public partial class NativeTransformer:NativeThing{public GameObject Needle;private Transform _needleTransform;private Quaternion _needleBaseRotation;public bool DialReady;public void SetKnob(){if(_needleTransform==null)throw new Exception("missing dial");DialReady=true;}}
 public partial class DinTransformer:NativeTransformer{public bool Cached,Prepared,BoardReady;public void CacheStates(bool b){Cached=b;}}
 static class PrefabAudioOwner{public static void PrepareInstance(DinTransformer d){d.Prepared=true;}}
 static class BoardStructureHooks{public static void Awake(DinTransformer d){d.BoardReady=true;}}
 static class TransformerPanelLayout{public const float CenterX=.02025f;}
}
class P{
 static int n;static void Check(bool b,string s){n++;if(!b)throw new Exception(s);}
 static DinTransformer Make(bool nested=false){var t=new DinTransformer();var frame=new GameObject();frame.transform.SetParent(t.transform,false);for(int i=0;i<2;i++){var g=new GameObject();g.transform.SetParent(nested?frame.transform:t.transform,false);t.AudioSources.Add(new(){Name="channel"+i,AudioSource=new AudioSource{transform=g.transform}});}t.AudioEvents.Add(new());t.Interactables.Add(new(){AssociatedAudioEvents=new(){new()}});return t;}
 static void Dial(DinTransformer d){d.Needle=new GameObject();d.Needle.transform.SetParent(d.transform,false);}
 static void Main(){
 var broken=Make();Rewrite.Broken(broken);Dial(broken);bool reproduced=false;try{broken.Awake();}catch(NullReferenceException){reproduced=true;}Check(reproduced,"must reproduce exact GameAudioSource.Init crash");Check(broken.Cached&&broken.Prepared&&!broken.RendererReady&&!broken.DialReady&&!broken.BoardReady,"native audio failure must block renderer/dial/board initialization");
 foreach(bool nested in new[]{false,true}){var t=Make(nested);var channels=t.AudioSources.ToArray();var components=channels.Select(x=>x.AudioSource).ToArray();var roots=Rewrite.Fixed(t);Dial(t);t.Awake();Check(t.RendererReady&&t.DialReady&&t.BoardReady,"native lifecycle must finish after preservation");Check(roots.Count==2,"two original source roots must survive");for(int i=0;i<channels.Length;i++){Check(ReferenceEquals(t.AudioSources[i],channels[i])&&ReferenceEquals(channels[i].AudioSource,components[i]),"channel ordering/metadata/component replaced");Check(channels[i].Parent==t&&channels[i].Ready,"native source init did not bind real owner and source properties");Check(channels[i].SourcePitch==1.2f&&channels[i].SourceVolume==.7f,"authored sound settings changed");Check(components[i].transform.parent==t.transform&&!components[i].transform.gameObject.Destroyed,"source lost under old visual parent");Check(Math.Abs(components[i].transform.localPosition.x-.02025)<.0001&&Math.Abs(components[i].transform.localPosition.z-.04)<.0001,"audio not centered on DIN module");}Check(t.AudioEvents[0].Count==1&&t.Interactables[0].AssociatedAudioEvents[0].Count==1,"native event initialization skipped");}
 var rootSource=Make();rootSource.AudioSources.Add(new(){Name="root",AudioSource=new(){transform=rootSource.transform}});Rewrite.Fixed(rootSource);Dial(rootSource);rootSource.Awake();Check(rootSource.AudioSources[2].Ready&&rootSource.transform.parent==null,"root source must not self-parent");
 var cursor=Make(true);cursor.IsCursor=true;Rewrite.Fixed(cursor);Dial(cursor);cursor.Awake();Check(cursor.RendererReady&&cursor.DialReady&&cursor.BoardReady&&cursor.AudioEvents[0].Count==0,"cursor audio skip behavior changed");
 Console.WriteLine(n+" exact native audio-init/transformer-Awake crash and source-preserving lifecycle checks passed (Unity hierarchy fixture).");
 }
}
