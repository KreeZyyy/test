from pathlib import Path
root=Path(__file__).resolve().parents[2];source=(root/'Source/DinTransformer.cs').read_text();a=source.index('    public sealed class DinTransformerSaveData');b=source.index('\n    // Native dial',a)
(Path(__file__).resolve().parent/'Extracted.cs').write_text('using System.Xml.Serialization;using Assets.Scripts.Objects.Electrical;using LibConstruct;namespace ModularSwitchboards{'+source[a:b]+'}')
assert 'Mod.AddSaveDataType<DinTransformerSaveData>();' in (root/'Source/SwitchboardsMod.cs').read_text()
