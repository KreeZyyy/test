from pathlib import Path
root=Path(__file__).resolve().parents[2];s=(root/'Source/DinTransformer.cs').read_text()
def block(marker):
 a=s.index(marker);b=s.index('{',a);e=b+1;n=1
 while n:n+=(s[e]=='{')-(s[e]=='}');e+=1
 return s[a:e]
text='using System.Linq;namespace ModularSwitchboards{partial class DinTransformer{'+block('public override bool OnOff')+block('public override void Awake()')+block('public override void OnRegistered(')+'}}'
(Path(__file__).resolve().parent/'Extracted.cs').write_text(text)
