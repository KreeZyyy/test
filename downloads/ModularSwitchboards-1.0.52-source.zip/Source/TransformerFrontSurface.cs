using UnityEngine;
namespace ModularSwitchboards
{
    internal static class TransformerFrontSurface
    {
        private static Material[] materials;
        internal static Material[] Materials
        {
            get
            {
                if(materials!=null)return materials;
                var shader=Shader.Find("Standard");
                if(shader==null||!shader.isSupported)throw new System.InvalidOperationException("Transformer front shader unavailable.");
                var colors=new[]{new Color(.25f,.28f,.28f),new Color(.045f,.05f,.05f),new Color(.43f,.19f,.085f),new Color(.075f,.08f,.075f),new Color(.67f,.69f,.66f)};
                materials=new Material[colors.Length];
                for(int i=0;i<colors.Length;i++){var m=new Material(shader){name="Switchboards.OwnTransformerSurface."+i,color=colors[i]};m.SetFloat("_Glossiness",i==2?.28f:.12f);m.SetFloat("_Metallic",i==2?.4f:0);materials[i]=m;}
                return materials;
            }
        }
    }
}
