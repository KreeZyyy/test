using System.Collections.Generic;
using Assets.Scripts;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Motherboards;
using UnityEngine;
using UnityEngine.Rendering;
using HarmonyLib;
using Rendering;
using Assets.Scripts.UI;

namespace ModularSwitchboards
{
    internal static class DinBreakerModel
    {
        internal static readonly Vector3 VisualScale=new Vector3(2.25f,1.35f,1.15f);
        internal static Mesh Build(float width=.0176f,float centerX=0f,bool battery=false,float openingX=0f,float openingY=0f,bool plain=false,bool inputOnly=false,bool bottomOnly=false,bool contactor=false,bool wideFace=false,bool normallyClosed=false)
        {
            var vertices=new List<Vector3>();var normals=new List<Vector3>();var triangles=new List<int>[5];
            for(int i=0;i<5;i++)triangles[i]=new List<int>();
            System.Action<Vector3,Vector3,int,float> shape=(center,size,role,radius)=>
            {
                center.x+=centerX;
                if(contactor&&center.z>.058f)
                {
                    BatteryAperture.Box(vertices,normals,triangles[role],center,size,radius,ContactorWindowLayout.OpeningWidth,ContactorWindowLayout.OpeningHeight);return;
                }
                if(!battery){RoundedGeometry.Box(vertices,normals,triangles[role],center,size,radius);return;}
                // Same breaker surfaces, with only the seated battery aperture cut out.
                float holeX=openingX>0?openingX:ApcBatteryRegion.SocketHeight/VisualScale.x;
                float holeY=openingY>0?openingY:ApcBatteryRegion.SocketHeight/VisualScale.y;
                BatteryAperture.Box(vertices,normals,triangles[role],center,size,radius,holeX,holeY,openingX>0?0:holeX*.1f,openingX>0?0:holeY*.1f);

            };
            shape(new Vector3(0,0,.029f),new Vector3(width,.075f,.056f),1,.0018f);
            shape(new Vector3(0,0,.059f),new Vector3(width,.052f,.008f),1,.0015f);
            shape(new Vector3(0,0,.0635f),new Vector3(width-(wideFace?.002f:.0046f),.045f,.001f),3,.0004f);
            if(battery)
            {
                // The slightly larger native cell extends just behind the former
                // rear plane. Recess only its rear cover; fuse rear walls stay put.
                float rear=openingX>0?.003f:-.0018f,depth=openingX>0?.002f:.0016f;
                // One continuous liner from the closed rear to the actual front.
                // The former three overlapping wall sets are deliberately absent.
                float holeX=openingX>0?openingX:ApcBatteryRegion.SocketHeight/VisualScale.x;
                float holeY=openingY>0?openingY:ApcBatteryRegion.SocketHeight/VisualScale.y;
                float rearFace=rear+depth*.5f;
                BatteryAperture.Walls(vertices,normals,triangles[3],new Vector3(centerX,0,(rearFace+.064f)*.5f),
                    new Vector3(width,.075f,.064f-rearFace),holeX,holeY,openingX>0?0:holeX*.1f,openingX>0?0:holeY*.1f);
                RoundedGeometry.Box(vertices,normals,triangles[3],new Vector3(centerX,0,rear),new Vector3(width,.075f,depth),.0007f);
            }
            foreach(float side in bottomOnly?new[]{-1f}:inputOnly?new[]{1f}:new[]{-1f,1f})
            {
                foreach(float terminalX in contactor&&(side>0||normallyClosed)?new[]{-.004f,.004f}:new[]{0f})
                {
                    float tw=contactor&&(side>0||normallyClosed)?.0057f:.009f,sw=contactor&&(side>0||normallyClosed)?.0035f:.006f;
                    RoundedGeometry.Box(vertices,normals,triangles[4],new Vector3(centerX+terminalX,side*.03f,.0577f),new Vector3(tw,.009f,.0015f),.0005f);
                    RoundedGeometry.Box(vertices,normals,triangles[3],new Vector3(centerX+terminalX,side*.03f,.0586f),new Vector3(sw,.001f,.0005f),.00015f);
                }
            }
            foreach(float side in bottomOnly?new[]{-1f}:inputOnly?new[]{1f}:new[]{-1f,1f})
            {
                foreach(float terminalX in contactor&&(side>0||normallyClosed)?new[]{-.004f,.004f}:new[]{0f})
                {
                    EndDisk(vertices,normals,triangles[4],new Vector3(centerX+terminalX,side*(WireContactLayout.BreakerEntryY+.0001f),WireContactLayout.BreakerEntryZ),.0042f,side);
                    EndDisk(vertices,normals,triangles[3],new Vector3(centerX+terminalX,side*(WireContactLayout.BreakerEntryY+.0002f),WireContactLayout.BreakerEntryZ),.0032f,side);
                }
            }
            // Two fixed spindle bearings straddle the flap, matching the APC's mounting.
            // Their inner edges clear the 12 mm plate while enclosing its axle ends.
            if(!battery&&!plain)foreach(float side in bottomOnly?new[]{-1f}:inputOnly?new[]{1f}:new[]{-1f,1f})
                RoundedGeometry.Box(vertices,normals,triangles[4],new Vector3(centerX+side*.0073f,0,.0667f),
                    new Vector3(.0022f,.0042f,.0048f),.0007f);
            var mesh=new Mesh{name="Switchboards.RoundedBreaker"};mesh.SetVertices(vertices);mesh.SetNormals(normals);mesh.subMeshCount=5;
            for(int i=0;i<5;i++)mesh.SetTriangles(triangles[i],i);
            CabinetGeometry.ApplyNativeUv(mesh);mesh.RecalculateBounds();return mesh;
        }
        private static void EndDisk(List<Vector3> vertices,List<Vector3> normals,List<int> triangles,Vector3 center,float worldRadius,float side)
        {
            for(int i=0;i<16;i++)
            {
                float a=i*Mathf.PI/8,b=(i+1)*Mathf.PI/8;
                var p=center+new Vector3(Mathf.Cos(a)*worldRadius/VisualScale.x,0,Mathf.Sin(a)*worldRadius/VisualScale.z);
                var q=center+new Vector3(Mathf.Cos(b)*worldRadius/VisualScale.x,0,Mathf.Sin(b)*worldRadius/VisualScale.z);
                int start=vertices.Count;vertices.AddRange(side>0?new[]{center,q,p}:new[]{center,p,q});normals.AddRange(new[]{Vector3.up*side,Vector3.up*side,Vector3.up*side});triangles.AddRange(new[]{start,start+1,start+2});
            }
        }
        internal static Mesh RoundedHandle()
        {
            var vertices=new List<Vector3>();var normals=new List<Vector3>();var indices=new List<int>();
            RoundedGeometry.Box(vertices,normals,indices,new Vector3(0,.0105f,0),new Vector3(.012f,.021f,.0025f),.0008f);
            var mesh=new Mesh{name="Switchboards.RoundedLeverFallback"};mesh.SetVertices(vertices);mesh.SetNormals(normals);mesh.subMeshCount=5;
            for(int i=0;i<5;i++)mesh.SetTriangles(i==0?indices.ToArray():new int[0],i);
            CabinetGeometry.ApplyNativeUv(mesh);mesh.RecalculateBounds();return mesh;
        }
        internal static Mesh ControlMesh(string name, Vector3 center, Vector3 size)
        {
            var vertices=new List<Vector3>();var triangles=new List<int>();
            DinRailModel.AddBox(vertices,triangles,center,size);
            var mesh=new Mesh{name=name};mesh.SetVertices(vertices);mesh.subMeshCount=5;
            for(int i=0;i<5;i++)mesh.SetTriangles(i==0?triangles.ToArray():new int[0],i);
            mesh.RecalculateNormals();CabinetGeometry.ApplyNativeUv(mesh);mesh.RecalculateBounds();return mesh;
        }
        private static Transform Control(Transform parent,string name,Mesh mesh,Vector3 position)
        {
            var go=new GameObject(name){layer=parent.gameObject.layer};go.transform.SetParent(parent,false);
            go.transform.localPosition=position;go.AddComponent<MeshFilter>().sharedMesh=mesh;
            var renderer=go.AddComponent<MeshRenderer>();renderer.sharedMaterials=CabinetGeometry.Materials;
            renderer.lightProbeUsage=LightProbeUsage.BlendProbes;renderer.reflectionProbeUsage=ReflectionProbeUsage.BlendProbes;
            renderer.shadowCastingMode=ShadowCastingMode.On;renderer.receiveShadows=true;return go.transform;
        }
        private static void Box(List<Vector3> vertices,List<int>[] triangles,int role,Vector3 center,Vector3 size)
            => DinRailModel.AddBox(vertices,triangles[role],center,size);
        internal static void Install(DinBreaker module, Transform storage)
        {
            foreach(var component in module.GetComponentsInChildren<Renderer>(true)) Object.DestroyImmediate(component);
            foreach(var component in module.GetComponentsInChildren<MeshFilter>(true)) Object.DestroyImmediate(component);
            foreach(var component in module.GetComponentsInChildren<Collider>(true)) Object.DestroyImmediate(component);
            foreach(var component in module.GetComponentsInChildren<Animator>(true)) Object.DestroyImmediate(component);
            module.BaseAnimator=null;
            module.Renderers=new List<ThingRenderer>();
            module.Interactables=new List<Interactable>();module.Slots=new List<Slot>();
            module._staticColliders=new List<Collider>();module._dynamicColliders=new List<Collider>();module._selfColliders=new List<Collider>();
            module.CustomNavMeshFilter=null;module.structureRenderMode=StructureRenderMode.Standard;
            module.ForceGridBounds.Clear();module.BrokenBuildStates=new List<BrokenBuildState>();
            module.StructureCollisionType=CollisionType.BlockCustom;
            module.SelectionDisplay=SelectionHighlightMethod.Bounds;module.UseCellPosition=false;
            module.CustomColor=GameManager.GetColorSwatch((int)ColorType.White);module.PaintableMaterial=module.CustomColor.Normal;module.HasColorState=false;module.MPBRenderers.Clear();
            var model=new GameObject("DinBreakerModel"){layer=module.gameObject.layer};model.transform.SetParent(module.transform,false);
            bool regularBreaker=!module.IsContactor&&!module.IsFuseHolder&&!module.IsBatteryModule&&!module.IsAnalyserModule&&!module.IsSmartModule&&!module.IsSmartOutputModule&&!module.IsDoorPart;
            bool nativeBearings=regularBreaker&&ApcBreakerBearings.Ready;
            var mesh=Build(plain:nativeBearings,wideFace:regularBreaker);
            var visualScale=VisualScale;model.transform.localScale=visualScale;
            model.AddComponent<MeshFilter>().sharedMesh=mesh;
            var renderer=model.AddComponent<MeshRenderer>();renderer.sharedMaterials=CabinetGeometry.Materials;
            renderer.lightProbeUsage=LightProbeUsage.BlendProbes;renderer.reflectionProbeUsage=ReflectionProbeUsage.BlendProbes;
            renderer.shadowCastingMode=ShadowCastingMode.On;renderer.receiveShadows=true;
            var collider=model.AddComponent<BoxCollider>();collider.center=mesh.bounds.center;collider.size=mesh.bounds.size;
            var leverMesh=RoundedHandle();
            bool nativeLever=ApcLeverGeometry.TryGet(out var nativeMesh,out var nativeMaterials);
            if(nativeLever)leverMesh=nativeMesh;
            var indicatorMesh=ControlMesh("BreakerIndicator",Vector3.zero,regularBreaker?new Vector3(.01f,.0023f,.00035f):new Vector3(.01f,.003f,.001f));
            var lever=Control(model.transform,"BreakerLever",leverMesh,new Vector3(0,0,.0675f));
            lever.localRotation=Quaternion.Euler(BreakerSwitchPose.LeverAngle(false),0,0);
            if(nativeLever)lever.GetComponent<MeshRenderer>().sharedMaterials=nativeMaterials;
            foreach(bool on in nativeLever?new bool[0]:new[]{true,false})
            {
                var text=new GameObject("BreakerStateText"){layer=module.gameObject.layer};text.transform.SetParent(lever,false);
                text.AddComponent<MeshFilter>().sharedMesh=BreakerLettering.Build(on,leverMesh.bounds.center.y+.003f,on?leverMesh.bounds.max.z+.00015f:leverMesh.bounds.min.z-.00015f);
                var textRenderer=text.AddComponent<MeshRenderer>();textRenderer.sharedMaterial=CabinetGeometry.Materials[1];
                var block=new MaterialPropertyBlock();block.SetFloat(Thing.DiffuseIndexPropertyID,(int)ColorType.White);block.SetColor(Thing.EMISSION_COLOR,Color.black);textRenderer.SetPropertyBlock(block);
            }
            var indicator=Control(model.transform,"BreakerIndicator",indicatorMesh,regularBreaker?new Vector3(0,.024f,.06315f):new Vector3(0,.0245f,.0645f));
            if(nativeBearings)ApcBreakerBearings.Install(model.transform);
            var control=new GameObject("BreakerControl"){layer=module.gameObject.layer};control.transform.SetParent(model.transform,false);
            var hit=control.AddComponent<BoxCollider>();hit.center=new Vector3(0,0,.067f);hit.size=new Vector3(.017f,.047f,.047f);
            ModuleFrontHitbox.Apply(module,hit);
            var toggle=new Interactable {
                Parent=module, Action=InteractableType.OnOff, Collider=hit,
                JoinInProgressSync=true, CanKeyInteract=true, KeyMap="PrimaryAction"
            };
            if(ModuleFrontHitbox.Applies(module))toggle.CacheBounds();
            // A new Interactable has native state 0 (OFF). Never reset this in Awake/load callbacks.
            module.Interactables=new List<Interactable>{toggle};module.HasOnOffState=true;
            var view=module.gameObject.AddComponent<BreakerSwitchView>();view.Owner=module;view.Lever=lever;
            module.Bounds=mesh.bounds;
            module.Bounds.Encapsulate(new Bounds(new Vector3(0,0,.069f),new Vector3(.0176f,.047f,.044f)));
            module.Bounds=new Bounds(Vector3.Scale(module.Bounds.center,visualScale),Vector3.Scale(module.Bounds.size,visualScale));module.SurfaceArea=.016f;
            module.GridBounds=new GridBounds(module);
            module.Thumbnail=CabinetIcons.Get(module.IsAnalyserModule?"DinAnalyser":module.IsBatteryModule?"DinBattery":module.IsFuseHolder?"DinFuse"+DinModuleCatalog.Colour(module.RatedWatts):"DinBreaker"+DinModuleCatalog.Colour(module.RatedWatts));module.Thumbnails=new Sprite[0];
            var state=module.BuildStates[0];state.Visualizer=renderer;state.StateMeshes=new List<Mesh>();state.RendererInstance=null;
            state.Colliders=new List<Collider>{collider,hit};state.Interactables=new List<Interactable>{toggle};
            state.LinkedGameObjects=new List<GameObject>();state.RenderMode=BuildStateRenderMode.OnMyState;
            state.BlockAir=state.AlwaysBlockAir=state.BlockLight=state.BlockGravity=false;state.Thumbnail=module.Thumbnail;
            AccessTools.Field(typeof(BuildState),"initialDrawData").SetValue(state,new DrawData{mesh=null,materials=new Material[0]});
            var blueprint=new GameObject("DinBreakerBlueprint"){layer=module.gameObject.layer};blueprint.transform.SetParent(storage,false);
            var ghost=new Mesh{name="BreakerOffBlueprint"};
            ghost.CombineMeshes(new[] {
                new CombineInstance{mesh=mesh,subMeshIndex=1,transform=Matrix4x4.Scale(visualScale)},
                new CombineInstance{mesh=mesh,subMeshIndex=3,transform=Matrix4x4.Scale(visualScale)},
                new CombineInstance{mesh=mesh,subMeshIndex=4,transform=Matrix4x4.Scale(visualScale)},
                new CombineInstance{mesh=leverMesh,subMeshIndex=0,transform=Matrix4x4.Scale(visualScale)*Matrix4x4.TRS(lever.localPosition,lever.localRotation,Vector3.one)},
                new CombineInstance{mesh=indicatorMesh,subMeshIndex=0,transform=Matrix4x4.Scale(visualScale)*Matrix4x4.Translate(indicator.localPosition)}
            },true,true);ghost.RecalculateBounds();
            var filter=blueprint.AddComponent<MeshFilter>();filter.sharedMesh=ghost;
            var br=blueprint.AddComponent<MeshRenderer>();br.sharedMaterial=CabinetGeometry.Materials[4];
            var wire=blueprint.AddComponent<Wireframe>();wire.BlueprintTransform=blueprint.transform;
            wire.BlueprintBounds=ghost.bounds;wire.BlueprintMeshFilter=filter;wire.BlueprintRenderer=br;
            blueprint.AddComponent<CabinetBlueprint>();
            module.Blueprint=blueprint;module.BlueprintOrientVector=Vector3.zero;
        }
        internal static void Refresh(Thing module)
        {
            if(module is DinBreaker led&&led.IsDoorPart)return;
            foreach(var renderer in module.GetComponentsInChildren<MeshRenderer>(true))
            {
                if(renderer.GetComponentInParent<Thing>()!=module ||
                    (renderer.name!="DinBreakerModel" && !((module is SmartModule||module is SmartContactor)&&renderer.name=="NativeLEDBezel") && renderer.name!="BreakerLever" && renderer.name!="BreakerIndicator" && renderer.name!="FuseCartridge" && renderer.name!="ModuleRatingPlate" && renderer.name!="FuseContacts" && renderer.name!="ContactorMechanicalSlider" && renderer.name!="ContactorOnPanel" && renderer.name!="ContactorOffPanel" && renderer.name!="ContactorGuide"))continue;
                if(renderer.name=="BreakerLever" && module is DinBreaker rated)
                {
                    if(ApcLeverGeometry.Paint(renderer,rated.RatedWatts))continue;
                    int colour=DinModuleColours.Index(rated.RatedWatts);
                    for(int index=0;index<renderer.sharedMaterials.Length;index++){var block=new MaterialPropertyBlock();block.SetFloat(Thing.DiffuseIndexPropertyID,colour);block.SetColor(Thing.EMISSION_COLOR,Color.black);renderer.SetPropertyBlock(block,index);}continue;
                }
                for(int role=0;role<5;role++)
                {
                    var block=new MaterialPropertyBlock();renderer.GetPropertyBlock(block,role);
                    int color=role==0?(int)ColorType.Orange:CabinetGeometry.PaletteIndices[role];
                    if((renderer.name=="DinBreakerModel"||(module is SmartModule||module is SmartContactor)&&renderer.name=="NativeLEDBezel")&&role==1)color=module.CustomColor==null?(int)ColorType.White:module.CustomColor.Index;
                    if(renderer.name=="FuseCartridge")color=CabinetGeometry.PaletteIndices[3];
                    if(renderer.name=="ModuleRatingPlate")color=CabinetGeometry.PaletteIndices[1];
                    if(renderer.name=="ContactorOnPanel")color=(int)ColorType.Green;
                    if(renderer.name=="ContactorOffPanel")color=(int)ColorType.Red;
                    if(renderer.name=="BreakerIndicator") color=BreakerSwitchPose.IndicatorColor(module.OnOff);
                    block.SetFloat(Thing.DiffuseIndexPropertyID,color);
                    block.SetFloat(Thing.SmoothnessIndexPropertyID,0f);
                    block.SetColor(Thing.EMISSION_COLOR,(renderer.name=="DinBreakerModel"||(module is SmartModule||module is SmartContactor)&&renderer.name=="NativeLEDBezel")&&role==1?module.EmissionColor:Color.black);renderer.SetPropertyBlock(block,role);
                }
            }
            // State/lever updates also call this method directly, bypassing paint hooks.
            SwitchboardFinish.Refresh(module);
            ApcBreakerBearings.Restore(module);
            ModuleMechanicalSurface.Restore(module);
        }
    }
}
