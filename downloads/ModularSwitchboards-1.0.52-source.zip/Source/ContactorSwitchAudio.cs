using Assets.Scripts;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Sound;
using Assets.Scripts.Util;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class ContactorSwitchAudio
    {
        internal static void Play(DinBreaker owner,bool closed)
        {
            if(owner==null||!owner.IsContactor||GameManager.IsBatchMode||GameManager.GameState!=GameState.Running||Singleton<AudioManager>.Instance==null)return;
            // Native Objects.SwitchOnOff uses this pair. Breaker/APC audio is unchanged.
            owner.PlayPooledAudioSound(closed?Defines.Sounds.SwitchOn:Defines.Sounds.SwitchOff,Vector3.zero);
        }
    }
}
