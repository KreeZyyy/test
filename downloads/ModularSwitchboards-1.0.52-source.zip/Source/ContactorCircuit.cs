using System.Collections.Generic;
using System.Linq;
namespace ModularSwitchboards
{
    internal static class ContactorCircuit
    {
        internal const int CoilPin=2;
        // 2/3 belong to neutral door bridge terminals; 5 is a directional power output.
        internal const int NcPin=5;
        internal static IEnumerable<CabinetWireSaveData> WithNormallyClosed(IEnumerable<CabinetWireSaveData> wires,IEnumerable<long> nc,IEnumerable<long> energized)
        {
            var closed=new HashSet<long>(energized);
            return wires.Concat(nc.Where(id=>!closed.Contains(id)).Select(id=>new CabinetWireSaveData{From=new CabinetWireEnd(id,0),To=new CabinetWireEnd(id,NcPin)}));
        }
        internal static HashSet<long> Resolve(IEnumerable<CabinetWireSaveData> wires,IEnumerable<long> fixedClosed,IEnumerable<long> ids,IEnumerable<long> previous,bool inputLive,IEnumerable<long> liveCells,IEnumerable<CabinetWireEnd> liveControls=null,IEnumerable<long> normallyClosed=null)
        {
            var graph=wires.ToArray();var fixedIds=fixedClosed.ToArray();var all=ids.Distinct().ToArray();var cells=liveCells.ToArray();var controls=(liveControls??Enumerable.Empty<CabinetWireEnd>()).ToArray();
            var closed=new HashSet<long>(previous.Where(all.Contains));
            System.Func<long,bool> powered=id=>
                controls.Any(source=>WireCircuit.Reachable(source,new CabinetWireEnd(id,CoilPin),graph,fixedIds.Concat(closed)))||
                inputLive&&WireCircuit.Reachable(new CabinetWireEnd(0,0),new CabinetWireEnd(id,CoilPin),graph,fixedIds.Concat(closed))||
                cells.Any(cell=>WireCircuit.Reachable(new CabinetWireEnd(cell,1),new CabinetWireEnd(id,CoilPin),graph,fixedIds.Concat(closed)));
            // NC feedback is sampled atomically from the previous contact state.
            // This avoids inventing a stable solution for self-interrupting coils.
            var nc=(normallyClosed??Enumerable.Empty<long>()).Distinct().ToArray();
            if(nc.Length>0)
            {
                graph=WithNormallyClosed(graph,nc,closed).ToArray();
                return new HashSet<long>(all.Where(id=>powered(id)));
            }
            // Release invalid held circuits first, then pick up newly powered coils.
            // A saved ON state must not supply a coil after its source disappears.
            for(int n=0;n<=all.Length;n++){var off=closed.Where(id=>!powered(id)).ToArray();if(off.Length==0)break;foreach(var id in off)closed.Remove(id);}
            for(int n=0;n<=all.Length;n++){var on=all.Where(id=>!closed.Contains(id)&&powered(id)).ToArray();if(on.Length==0)break;foreach(var id in on)closed.Add(id);}
            return closed;
        }
    }
}
