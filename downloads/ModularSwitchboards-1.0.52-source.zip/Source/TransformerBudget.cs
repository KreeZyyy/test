using System;
using System.Collections.Generic;
using System.Linq;
namespace ModularSwitchboards
{
    internal static class TransformerBudget
    {
        internal static float Finite(float value)=>float.IsNaN(value)||float.IsInfinity(value)?0:Math.Max(0,value);
        // Progressive filling: satisfy demand first, then advertise unused headroom.
        // A transformer is one shared resource even if its OUT forks to all outputs.
        internal static float[] Allocate(float available,float[] demands,bool[] active,long[][] paths,IDictionary<long,float> limits)
        {
            if(limits.Count==0)return WireCircuit.AllocateSupply(available,demands,active);
            var result=new float[demands.Length];float left=Finite(available);
            var remaining=limits.ToDictionary(p=>p.Key,p=>Finite(p.Value));
            void fill(bool demand)
            {
                for(int pass=0;pass<=demands.Length+limits.Count;pass++)
                {
                    var ids=Enumerable.Range(0,result.Length).Where(i=>active[i]&&(!demand||result[i]<Finite(demands[i]))&&(paths[i]??Array.Empty<long>()).All(id=>!remaining.ContainsKey(id)||remaining[id]>0)).ToArray();
                    if(ids.Length==0||left<=0)return;
                    var weights=ids.ToDictionary(i=>i,i=>demand?Math.Max(0,(double)Finite(demands[i])-result[i]):1d);double total=weights.Values.Sum();if(total<=0)return;
                    double step=left/total;
                    if(demand)step=Math.Min(step,1);
                    foreach(var p in remaining){double weight=ids.Where(i=>(paths[i]??Array.Empty<long>()).Contains(p.Key)).Sum(i=>weights[i]);if(weight>0)step=Math.Min(step,p.Value/weight);}
                    if(step<=0)return;
                    var increments=ids.ToDictionary(i=>i,i=>(float)(weights[i]*step));
                    foreach(int i in ids){result[i]+=increments[i];left=Math.Max(0,left-increments[i]);}
                    foreach(long id in remaining.Keys.ToArray())remaining[id]=Math.Max(0,remaining[id]-ids.Where(i=>(paths[i]??Array.Empty<long>()).Contains(id)).Sum(i=>increments[i]));
                }
            }
            fill(true);fill(false);return result;
        }
    }
}
