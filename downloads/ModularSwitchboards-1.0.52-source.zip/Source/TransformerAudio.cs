using System;
using System.Collections.Generic;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class TransformerAudio
    {
        internal static HashSet<Transform> PreserveSources(DinTransformer owner)
        {
            // GameAudioSource is serialized metadata pointing to an AudioSource
            // component (normally the native PoweredAudio child). Keep those
            // components before deleting the old transformer model hierarchy.
            var roots=new HashSet<Transform>();
            foreach(var channel in owner.AudioSources)
            {
                if(channel==null||channel.AudioSource==null)throw new InvalidOperationException("Native transformer audio channel has no AudioSource before model replacement.");
                var source=channel.AudioSource.transform;
                if(source==owner.transform)continue;
                source.SetParent(owner.transform,false);
                source.localPosition=new Vector3(TransformerPanelLayout.CenterX,0,.04f);
                source.localRotation=Quaternion.identity;source.localScale=Vector3.one;
                roots.Add(source);
            }
            return roots;
        }
    }
}
