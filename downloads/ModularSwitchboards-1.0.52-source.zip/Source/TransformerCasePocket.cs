using System;
using System.Collections.Generic;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class TransformerCasePocket
    {
        private struct Point {internal Vector3 P,N;internal Vector2 U;internal Point(Vector3 p,Vector3 n,Vector2 u){P=p;N=n;U=u;}}
        // The case is our readable generated breaker mesh. Preserve its original
        // bevel normals outside the coil pockets instead of flattening the shell.
        internal static Mesh Cut(Mesh source,Bounds hole)
        {
            var v=source.vertices;var n=source.normals;var uv=source.uv;var output=new List<Vector3>();var normals=new List<Vector3>();var tex=new List<Vector2>();var groups=new List<int>[source.subMeshCount];
            void emit(List<Point> p,List<int> ids)
            {
                for(int i=1;i<p.Count-1;i++)
                {
                    if(Vector3.Cross(p[i].P-p[0].P,p[i+1].P-p[0].P).sqrMagnitude<1e-22f)continue;
                    foreach(var q in new[]{p[0],p[i],p[i+1]}){ids.Add(output.Count);output.Add(q.P);normals.Add(q.N);tex.Add(q.U);}
                }
            }
            List<Point> clip(List<Point> p,int axis,float plane,bool above,bool strict=false)
            {
                var result=new List<Point>();if(p.Count==0)return result;
                Func<float,bool> inside=d=>above?(strict?d>0:d>=0):(strict?d<0:d<=0);
                var old=p[p.Count-1];float od=old.P[axis]-plane;bool oi=inside(od);
                foreach(var current in p)
                {
                    float d=current.P[axis]-plane;bool ci=inside(d);
                    if(oi!=ci){float t=od/(od-d);result.Add(new Point(old.P+(current.P-old.P)*t,(old.N+(current.N-old.N)*t).normalized,old.U+(current.U-old.U)*t));}
                    if(ci)result.Add(current);old=current;od=d;oi=ci;
                }
                return result;
            }
            for(int role=0;role<groups.Length;role++)
            {
                groups[role]=new List<int>();var ids=source.GetTriangles(role);
                for(int i=0;i<ids.Length;i+=3)
                {
                    var p=new List<Point>();for(int j=0;j<3;j++){int id=ids[i+j];p.Add(new Point(v[id],n[id],uv.Length==v.Length?uv[id]:Vector2.zero));}
                    for(int axis=0;axis<3&&p.Count>0;axis++){emit(clip(p,axis,hole.min[axis],false,true),groups[role]);p=clip(p,axis,hole.min[axis],true);emit(clip(p,axis,hole.max[axis],true,true),groups[role]);p=clip(p,axis,hole.max[axis],false);}
                }
            }
            var mesh=new Mesh{name="DIN.Transformer.BreakerCaseWithCoilPockets"};mesh.SetVertices(output);mesh.SetNormals(normals);mesh.SetUVs(0,tex);mesh.subMeshCount=groups.Length;for(int i=0;i<groups.Length;i++)mesh.SetTriangles(groups[i],i);mesh.RecalculateTangents();mesh.RecalculateBounds();return mesh;
        }
    }
}
