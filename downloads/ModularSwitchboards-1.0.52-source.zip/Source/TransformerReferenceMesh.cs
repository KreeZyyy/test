using System;
using System.IO;
using System.Reflection;
using UnityEngine;
namespace ModularSwitchboards
{
    // Exact exported topology and UVs, packaged with this mod. Never guessed primitives.
    internal static class TransformerReferenceMesh
    {
        internal static Mesh Load(string name)
        {
            using(var stream=Assembly.GetExecutingAssembly().GetManifestResourceStream("ModularSwitchboards.Transformer."+name+".meshbin"))
            {
                if(stream==null)throw new InvalidDataException("Missing transformer mesh "+name);
                using(var reader=new BinaryReader(stream))
                {
                    int count=reader.ReadInt32(),indices=reader.ReadInt32();if(count<3||count>65535||indices<3||indices%3!=0)throw new InvalidDataException("Transformer mesh header");
                    var v=new Vector3[count];var uv=new Vector2[count];for(int i=0;i<count;i++){v[i]=new Vector3(reader.ReadSingle(),reader.ReadSingle(),reader.ReadSingle());uv[i]=new Vector2(reader.ReadSingle(),reader.ReadSingle());}
                    var ids=new int[indices];for(int i=0;i<indices;i++){ids[i]=reader.ReadInt32();if(ids[i]<0||ids[i]>=count)throw new InvalidDataException("Transformer mesh index");}
                    if(stream.Position!=stream.Length)throw new InvalidDataException("Transformer mesh trailing bytes");
                    var mesh=new Mesh{name="Switchboards.ExportedSmallTransformer."+name,vertices=v,uv=uv,subMeshCount=1};mesh.SetTriangles(ids,0);mesh.RecalculateNormals();mesh.RecalculateBounds();return mesh;
                }
            }
        }
    }
}
