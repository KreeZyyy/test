using Assets.Scripts.Objects.Items;
namespace ModularSwitchboards
{
    // Immutable-by-convention snapshot of Unity state, read by the power bridge.
    internal sealed class CabinetPowerNode
    {
        internal long ReferenceId;
        internal bool Conducting,IsContactor,IsBatteryModule,IsAnalyserModule,IsDoorPart,IsDoorBridge,IsBeingDestroyed,IsTransformer;
        internal float RatedWatts,TransferLimit;
        internal BatteryCell Battery;
        internal static CabinetPowerNode From(DinBreaker m)=>new CabinetPowerNode{ReferenceId=m.ReferenceId,Conducting=m.Conducting,IsContactor=m.IsContactor,IsBatteryModule=m.IsBatteryModule,IsAnalyserModule=m.IsAnalyserModule,IsDoorPart=m.IsDoorPart,IsDoorBridge=m.IsDoorBridge,IsBeingDestroyed=m.IsBeingDestroyed,RatedWatts=m.RatedWatts,Battery=m.Battery};
    }
}
