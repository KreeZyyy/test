namespace ModularSwitchboards
{
    internal static class ContactorWindowLayout
    {
        internal const float ScaleX=1.12f,ScaleY=1.45f;
        internal const float OpeningWidth=.0118f*ScaleX,OpeningHeight=.0246f*ScaleY;
    }
}
