using System.Linq;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Objects;
using LibConstruct;

namespace ModularSwitchboards
{
    internal static class ModuleLayout
    {
        internal static bool Fits(int x, int y, int z, int rotation, int width, int capacity)
            => x % 10 == 0 && y == 0 && z == 0 && rotation == 0 && width > 0 &&
                x >= 0 && x / 10 + width <= capacity;
        internal static bool Overlaps(int start, int width, int other, int otherWidth)
            => start < other + otherWidth && other < start + width;
    }

    public sealed class DinModuleBoard : PlacementBoard
    {
        public override float GridSize => DinLayout.SlotPitch;
        public override IPlacementBoardStructure EquivalentStructure(Structure structure)
            => (structure is DinBreaker||structure is SmartModule||structure is SmartContactor||structure is DinTransformer) && PrimaryHost is DinRail rail && rail.CanFitModules
                ? structure as IPlacementBoardStructure : null;

        internal bool CanPlace(Grid3 position, int rotation, int width)
        {
            if (!(PrimaryHost is DinRail rail) || !rail.CanFitModules ||
                !ModuleLayout.Fits(position.x-DinLayout.FirstModuleSlot*10, position.y, position.z, rotation, width, rail.ModuleCapacity)) return false;
            if(rail.Board?.PrimaryHost is SwitchboardCabinet cabinet && cabinet.Wiring.WouldBlockModule(this,position,width))return false;
            return !DinParts.On(this).Any(module =>
                ModuleLayout.Overlaps(position.x / 10, width,
                    WorldToGrid(module.Transform.position).x / 10, DinParts.Width(module)));
        }
    }
}
