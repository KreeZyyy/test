using System;
using System.Collections.Generic;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class TransformerCoilSides
    {
        internal static void Install(DinTransformer owner,Transform body,Mesh[] meshes,MeshRenderer[] sources,Material[][] materials,Bounds source)
        {
            float scale=Mathf.Min(.044f/source.size.x,.043f/source.size.y),width=source.size.x*scale,height=source.size.y*scale;
            float depthScale=source.size.z>.00001f?.0024f/source.size.z:scale;
            var geometry=body.GetComponent<MeshFilter>().sharedMesh;
            float half=TransformerPanelLayout.Width*DinBreakerModel.VisualScale.x*.5f;
            foreach(float side in new[]{-1f,1f})
            {
                float edge=TransformerPanelLayout.CenterX+side*half;
                var pocket=new Bounds(new Vector3(edge-side*.0014f,0,.034f),new Vector3(.0034f,height+.001f,width+.001f));
                var local=new Bounds(Vector3.Scale(pocket.center,new Vector3(1/DinBreakerModel.VisualScale.x,1/DinBreakerModel.VisualScale.y,1/DinBreakerModel.VisualScale.z)),Vector3.Scale(pocket.size,new Vector3(1/DinBreakerModel.VisualScale.x,1/DinBreakerModel.VisualScale.y,1/DinBreakerModel.VisualScale.z)));
                var cut=TransformerCasePocket.Cut(geometry,local);if(cut==null)throw new InvalidOperationException("Transformer side pocket removed entire case.");geometry=cut;
                var mount=new GameObject(side<0?"TransformerCoilLeft":"TransformerCoilRight"){layer=owner.gameObject.layer}.transform;mount.SetParent(owner.transform,false);mount.localRotation=Quaternion.Euler(0,side*90,0);mount.localScale=new Vector3(scale,scale,depthScale);
                var origin=new Vector3(source.center.x,source.center.y,source.min.z);
                mount.localPosition=new Vector3(edge-side*.0023f,0,.034f)-mount.localRotation*Vector3.Scale(origin,mount.localScale);
                for(int i=0;i<meshes.Length;i++)
                {
                    var part=new GameObject("CoilSurface"+i){layer=owner.gameObject.layer};part.transform.SetParent(mount,false);part.AddComponent<MeshFilter>().sharedMesh=meshes[i];var r=part.AddComponent<MeshRenderer>();if(sources[i]!=null)NativePortSurface.Capture(sources[i],r);else NativePortSurface.Capture(materials[i],r);
                }
                var v=new List<Vector3>();var n=new List<Vector3>();var g=new List<int>[5];for(int i=0;i<5;i++)g[i]=new List<int>();
                RoundedGeometry.Box(v,n,g[3],new Vector3(edge-side*.003f,0,.034f),new Vector3(.0005f,height+.001f,width+.001f),.0001f);
                var backing=new Mesh{name="DIN.Transformer.CoilPocketLiner"};backing.SetVertices(v);backing.SetNormals(n);backing.subMeshCount=5;for(int i=0;i<5;i++)backing.SetTriangles(g[i],i);CabinetGeometry.ApplyNativeUv(backing);backing.RecalculateBounds();
                var liner=new GameObject("TransformerCoilLiner"){layer=owner.gameObject.layer};liner.transform.SetParent(owner.transform,false);liner.AddComponent<MeshFilter>().sharedMesh=backing;var rr=liner.AddComponent<MeshRenderer>();rr.sharedMaterials=CabinetGeometry.Materials;var block=new MaterialPropertyBlock();block.SetFloat(Assets.Scripts.Objects.Thing.DiffuseIndexPropertyID,CabinetGeometry.PaletteIndices[3]);rr.SetPropertyBlock(block,3);
            }
            body.GetComponent<MeshFilter>().sharedMesh=geometry;
        }
    }
}
