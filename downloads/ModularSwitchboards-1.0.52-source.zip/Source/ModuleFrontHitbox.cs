using Assets.Scripts.Objects;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class ModuleFrontHitbox
    {
        internal static bool Applies(DinBreaker module)=>module.IsFuseHolder||
            (!module.IsContactor&&!module.IsBatteryModule&&!module.IsAnalyserModule&&!module.IsSmartModule&&!module.IsSmartOutputModule&&!module.IsDoorPart);
        internal static Bounds LocalBounds(bool fuse)
        {
            // Front face dimensions in the same local coordinates as the actual
            // breaker fascia and the fuse insert's outer .00622 x .02195 rim.
            // The front of each target clears the whole-case collider.
            return fuse?new Bounds(new Vector3(0,0,(FusePocket.Rear+.0656f)*.5f),new Vector3(.01244f,.0439f,.0656f-FusePocket.Rear)):
                new Bounds(new Vector3(0,0,.0667f),new Vector3(.0156f,.045f,.0062f));
        }
        internal static void Apply(DinBreaker module,BoxCollider hit)
        {
            if(!Applies(module))return;
            var bounds=LocalBounds(module.IsFuseHolder);hit.center=bounds.center;hit.size=bounds.size;
        }
        internal static void AfterSelection(Interactable __instance,ref SelectionInstance __result)
        {
            if(!(__instance.Parent is DinBreaker module)||!Applies(module)||
                !(__instance.Collider is BoxCollider box)||box.name!="BreakerControl"||
                (__instance.Action!=InteractableType.OnOff&&__instance.Action!=InteractableType.Slot1))return;
            // Same scoped rule as the Smart Output screw: no native extra 10 mm
            // around this already fitted target. Keep native owner/action identity.
            var scale=box.transform.lossyScale;
            __result.Bounds=new Bounds(Vector3.Scale(box.center,scale),Vector3.Scale(box.size,new Vector3(Mathf.Abs(scale.x),Mathf.Abs(scale.y),Mathf.Abs(scale.z))));
        }
    }
}
