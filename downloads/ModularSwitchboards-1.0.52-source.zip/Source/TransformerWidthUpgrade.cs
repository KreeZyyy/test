using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Assets.Scripts;
using Assets.Scripts.Objects;
using HarmonyLib;
using LibConstruct;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class TransformerWidthUpgrade
    {
        private sealed class SavedPart{internal Structure Part;internal PlacementBoardStructureSaveData Save;}
        internal static void BeforeFinishLoad()
        {
            if(!GameManager.RunSimulation)return;
            try
            {
                var refs=(IDictionary)AccessTools.Field(typeof(PlacementBoard),"LoadingRefs").GetValue(null);
                var boards=refs.Values.Cast<object>().Select(LoadingBoard).ToArray();
                foreach(var board in boards.OfType<DinModuleBoard>())
                {
                    if(!(board.PrimaryHost is DinRail rail))continue;
                    var records=new List<SavedPart>();bool unknown=false;
                    foreach(var item in Waiting(board))
                    {
                        var type=item.GetType();var part=AccessTools.Field(type,"Structure").GetValue(item) as Structure;
                        if(!(part is DinBreaker)&&!(part is SmartModule)&&!(part is SmartContactor)&&!(part is DinTransformer)){unknown=true;break;}
                        records.Add(new SavedPart{Part=part,Save=(PlacementBoardStructureSaveData)AccessTools.Field(type,"SaveData").GetValue(item)});
                    }
                    if(unknown||!records.Any(p=>p.Part is DinTransformer t&&t.ModuleWidth<4)||records.Any(p=>p.Save.Position.x%10!=0||p.Save.Position.y!=0||p.Save.Position.z!=0||p.Save.Rotation!=0))continue;
                    var cabinet=rail.Board?.PrimaryHost as SwitchboardCabinet;
                    if(cabinet==null)cabinet=boards.Where(b=>b.PrimaryHost is SwitchboardCabinet).FirstOrDefault(b=>Waiting(b).Cast<object>().Any(i=>ReferenceEquals(AccessTools.Field(i.GetType(),"Structure").GetValue(i),rail)))?.PrimaryHost as SwitchboardCabinet;
                    if(cabinet==null)continue;
                    int capacity=DinLayout.ModuleCount(CabinetShape.RailWidth(cabinet.PrefabName));
                    foreach(var entry in records.Where(p=>p.Part is DinTransformer).OrderBy(p=>p.Save.Position.x))
                    {
                        var transformer=(DinTransformer)entry.Part;if(transformer.ModuleWidth==4)continue;
                        var spans=records.Select(p=>new SmartUpgradePart(p.Part.ReferenceId,p.Save.Position.x/10,DinParts.Width(p.Part),false,false,false));
                        if(!TransformerExpansionLayout.CanExpand(spans,transformer.ReferenceId,DinLayout.FirstModuleSlot,capacity))continue;
                        transformer.ModuleWidth=4;DinTransformerModel.ApplyWidth(transformer);
                        Debug.Log("[Modular Switchboards] Expanded saved DIN Transformer (Small) to four positions; right front and wire entries kept in place.");
                    }
                }
            }
            catch(Exception ex){Debug.LogWarning("[Modular Switchboards] Transformer width migration deferred; compact saved units retained: "+ex.Message);}
        }
        private static PlacementBoard LoadingBoard(object reference)
        {
            var contract=reference.GetType().GetInterfaces().First(t=>t.Name=="IBoardRef");return (PlacementBoard)contract.GetProperty("Board").GetValue(reference,null);
        }
        private static IEnumerable Waiting(PlacementBoard board)=>(IEnumerable)AccessTools.Field(typeof(PlacementBoard),"AwaitingRegister").GetValue(board);
    }
}
