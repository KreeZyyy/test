using System;
using System.Linq;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Electrical;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class ApcBreakerBearings
    {
        private static Mesh[] meshes;private static MeshRenderer source;private static bool attempted;
        internal static Bounds Region(bool left)=>new Bounds(new Vector3(left?.004657f:.132583f,0,.182116f),new Vector3(.0099f,.0224f,.0261f));
        internal static Vector3 Map(Vector3 p,float leverWidth)
        {
            float fit=.012f*DinBreakerModel.VisualScale.x/leverWidth;
            return new Vector3((p.x-.069f)*fit/DinBreakerModel.VisualScale.x,p.y*fit/DinBreakerModel.VisualScale.y,.0675f+(p.z-.18f)*fit/DinBreakerModel.VisualScale.z);
        }
        internal static Mesh Build(Mesh original,Matrix4x4 frame,bool left,float leverWidth)
        {
            var region=Region(left);
            var result=NativeMeshCrop.Read(original,frame,region,"Breaker.OriginalAPCBearing",(a,b,c)=>region.Contains(a)&&region.Contains(b)&&region.Contains(c));
            if(result==null)throw new InvalidOperationException("Original APC spindle bearing missing.");
            var v=result.vertices;for(int i=0;i<v.Length;i++)v[i]=Map(v[i],leverWidth);result.vertices=v;result.RecalculateNormals();result.RecalculateBounds();return Close(result,left);
        }
        internal static Mesh Close(Mesh mesh,bool left)
        {
            var v=mesh.vertices.ToList();var n=mesh.normals.ToList();var triangles=new System.Collections.Generic.List<int>();
            for(int sub=0;sub<mesh.subMeshCount;sub++)triangles.AddRange(mesh.GetTriangles(sub));
            var bounds=mesh.bounds;float outer=left?bounds.min.x:bounds.max.x;var rim=new System.Collections.Generic.List<Vector3>();
            foreach(var p in mesh.vertices)
                if(Mathf.Abs(p.x-outer)<.000001f&&!rim.Any(q=>(p-q).sqrMagnitude<1e-14f))rim.Add(p);
            if(rim.Count<3)throw new InvalidOperationException("Native bearing side boundary missing.");
            var center=Vector3.zero;foreach(var p in rim)center+=p;center*=1f/rim.Count;
            rim=rim.OrderBy(p=>Math.Atan2(p.z-center.z,p.y-center.y)).ToList();var normal=left?Vector3.left:Vector3.right;
            Action<Vector3,Vector3,Vector3,Vector3> face=(a,b,c,outward)=>
            {
                int start=v.Count;v.AddRange(new[]{a,b,c});n.AddRange(new[]{outward,outward,outward});var cross=Vector3.Cross(b-a,c-a);
                bool reverse=cross.x*outward.x+cross.y*outward.y+cross.z*outward.z<0;
                triangles.AddRange(reverse?new[]{start,start+2,start+1}:new[]{start,start+1,start+2});
            };
            for(int i=0;i<rim.Count;i++)face(center,rim[i],rim[(i+1)%rim.Count],normal);
            // Close the native underside as well, joining the side cap to the shell.
            var a0=new Vector3(bounds.min.x,bounds.min.y,bounds.min.z);var b0=new Vector3(bounds.max.x,bounds.min.y,bounds.min.z);
            var c0=new Vector3(bounds.max.x,bounds.max.y,bounds.min.z);var d0=new Vector3(bounds.min.x,bounds.max.y,bounds.min.z);
            face(a0,b0,c0,Vector3.back);face(a0,c0,d0,Vector3.back);
            mesh.SetVertices(v);mesh.SetNormals(n);mesh.subMeshCount=5;
            for(int sub=0;sub<5;sub++)mesh.SetTriangles(sub==4?triangles:new System.Collections.Generic.List<int>(),sub);
            CabinetGeometry.ApplyNativeUv(mesh);mesh.RecalculateBounds();return mesh;
        }
        internal static bool Ready
        {
            get
            {
                if(!attempted)
                {
                    attempted=true;
                    try
                    {
                        var apc=WorldManager.Instance.SourcePrefabs.OfType<AreaPowerControl>().First(p=>p.PrefabName=="StructureAreaPowerControl");source=apc.GetComponent<MeshRenderer>();
                        var front=Matrix4x4.Rotate(CabinetModel.FrontSign<0?Quaternion.Euler(0,180,0):Quaternion.identity)*apc.transform.worldToLocalMatrix;
                        var lever=apc.GetComponentsInChildren<MeshRenderer>(true).First(r=>r.name=="MasterLever");
                        CabinetGeometry.ReadNativeMesh(lever.GetComponent<MeshFilter>().sharedMesh,out var vertices,out _,out _);
                        var pose=front*lever.transform.localToWorldMatrix;var points=vertices.Select(p=>pose.MultiplyPoint3x4(p)).ToArray();float width=points.Max(p=>p.x)-points.Min(p=>p.x);
                        if(width<=0)throw new InvalidOperationException("Invalid native lever width.");
                        var frame=front*source.transform.localToWorldMatrix;var mesh=source.GetComponent<MeshFilter>().sharedMesh;
                        meshes=new[]{Build(mesh,frame,true,width),Build(mesh,frame,false,width)};
                    }
                    catch(Exception ex){meshes=null;Debug.LogWarning("[Modular Switchboards] Native APC bearings unavailable; retaining original fallback: "+ex.Message);}
                }
                return meshes!=null;
            }
        }
        internal static void Install(Transform parent)
        {
            if(!Ready)return;
            for(int i=0;i<2;i++)
            {
                var go=new GameObject(i==0?"BreakerNativeBearingLeft":"BreakerNativeBearingRight"){layer=parent.gameObject.layer};go.transform.SetParent(parent,false);
                go.AddComponent<MeshFilter>().sharedMesh=meshes[i];var renderer=go.AddComponent<MeshRenderer>();renderer.sharedMaterials=CabinetGeometry.Materials;ModuleMechanicalSurface.Apply(renderer);
            }
        }
        internal static void Restore(Thing owner)
        {
            foreach(var renderer in owner.GetComponentsInChildren<MeshRenderer>(true))
                if(renderer.name.StartsWith("BreakerNativeBearing"))ModuleMechanicalSurface.Apply(renderer);
        }
    }
}
