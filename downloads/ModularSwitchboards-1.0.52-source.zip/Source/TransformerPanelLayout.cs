using UnityEngine;
namespace ModularSwitchboards
{
    internal static class TransformerPanelLayout
    {
        internal static float CenterX=>DinLayout.SlotPitch*.5f;
        internal static float Width=>WidthFor(DinTransformer.SlotCount);
        internal static float WidthFor(int slots)=>.0176f+(slots-1)*DinLayout.SlotPitch/DinBreakerModel.VisualScale.x;
        internal static readonly Vector3 PanelCenter=new Vector3(CenterX,0,.0742f);
        internal static Bounds ControlsRegion(Bounds controls)
        {
            var size=controls.size;float h=Mathf.Max(size.y,.01f);
            var min=controls.min-new Vector3(size.x*.2f,h*.3f,h*.12f);
            var max=controls.max+new Vector3(size.x*.2f,h*.3f,h*.05f);
            var b=new Bounds();b.SetMinMax(min,max);return b;
        }
        internal static float PortCenterX(int slots)=>(slots-1)*DinLayout.SlotPitch*.5f;
        internal static Mesh Body(int slots=DinTransformer.SlotCount)
        {
            float center=PortCenterX(slots);
            return DinBreakerModel.Build(WidthFor(slots),center/DinBreakerModel.VisualScale.x,plain:true,wideFace:true);
        }
    }
}
