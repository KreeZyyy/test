using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.Linq;
using HarmonyLib;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Electrical;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class NativeTransformerParts
    {
        // Retain native switch poses, material states and binary animations. Copy
        // serialized authoring data only; no runtime tasks/caches or old owners.
        internal static void Copy(Transformer source,DinTransformer owner,Func<Transform,Transform> frame,Func<Collider,Collider> collider)
        {
            var scripts=new Dictionary<MonoBehaviour,MonoBehaviour>();
            foreach(var part in source.GetComponentsInChildren<MonoBehaviour>(true))
                if(part is Objects.DevicePart||part is InteractableAnimComponent||part is Effects.StateMaterialChanger||part is Effects.MaterialChanger)scripts[part]=(MonoBehaviour)frame(part.transform).gameObject.AddComponent(part.GetType());
            var copied=new Dictionary<object,object>();
            object value(object original)
            {
                if(original==null)return null;
                if(ReferenceEquals(original,source))return owner;
                if(original is Transform t&&t.IsChildOf(source.transform))return frame(t);
                if(original is GameObject go&&go.transform.IsChildOf(source.transform))return frame(go.transform).gameObject;
                if(original is Collider hit&&hit.transform.IsChildOf(source.transform))return collider(hit);
                if(original is MonoBehaviour script&&scripts.TryGetValue(script,out var replacement))return replacement;
                if(original is Component component&&component.transform.IsChildOf(source.transform))return frame(component.transform).GetComponent(component.GetType());
                var type=original.GetType();
                if(original is UnityEngine.Object||type.IsValueType||original is string)return original;
                if(copied.TryGetValue(original,out var cached))return cached;
                if(original is Array array){var result=Array.CreateInstance(type.GetElementType(),array.Length);copied[original]=result;for(int i=0;i<array.Length;i++)result.SetValue(value(array.GetValue(i)),i);return result;}
                if(original is IList list){var result=(IList)Activator.CreateInstance(type);copied[original]=result;foreach(var item in list)result.Add(value(item));return result;}
                if(!type.IsSerializable)throw new InvalidOperationException("Unsupported native transformer serialized data: "+type.FullName);
                var clone=Activator.CreateInstance(type);copied[original]=clone;fields(original,clone,type);return clone;
            }
            void fields(object original,object destination,Type type)
            {
                for(var current=type;current!=null&&current!=typeof(MonoBehaviour);current=current.BaseType)
                    foreach(var field in current.GetFields(BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.Instance|BindingFlags.DeclaredOnly))
                        if(!field.IsInitOnly&&!field.IsNotSerialized&&(field.IsPublic||field.IsDefined(typeof(SerializeField),true)))field.SetValue(destination,value(field.GetValue(original)));
            }
            foreach(var pair in scripts){fields(pair.Key,pair.Value,pair.Key.GetType());if(pair.Value is Objects.DevicePart part)part.SetParentThing(owner);if(pair.Value is InteractableAnimComponent animation)animation.SetParentThing(owner);}
            foreach(string name in new[]{"switchOnOff","activateButton","leverAnimationComponent","MaterialChanger"})
            {
                var field=AccessTools.Field(typeof(Thing),name);var original=field?.GetValue(source) as MonoBehaviour;
                field?.SetValue(owner,original!=null&&scripts.TryGetValue(original,out var replacement)?replacement:null);
            }
            owner.AnimComponents=owner.GetComponentsInChildren<Effects.StateMaterialChanger>(true).ToList();
        }
    }
}
