using System;
namespace ModularSwitchboards
{
    // Mechanical strip travel is 22.707 mm in world space; no LED or emission.
    internal sealed class ContactorIndicatorMotion
    {
        internal const float HalfTravel=.0058f*ContactorWindowLayout.ScaleY;
        internal const float Duration=.2f;
        internal float Offset{get;private set;}=HalfTravel;
        private bool initialized,previous;
        // Inactive cursors/reinstallation reset the baseline, never produce sounds.
        internal bool Tick(bool active,bool closed,float deltaTime)
        {
            float target=closed?-HalfTravel:HalfTravel;
            if(!active){initialized=false;Offset=HalfTravel;return false;}
            if(!initialized){initialized=true;previous=closed;Offset=target;return false;}
            bool changed=previous!=closed;previous=closed;
            float step=2f*HalfTravel*Math.Max(0f,deltaTime)/Duration;
            Offset=Offset<target?Math.Min(target,Offset+step):Math.Max(target,Offset-step);
            return changed;
        }
    }
}
