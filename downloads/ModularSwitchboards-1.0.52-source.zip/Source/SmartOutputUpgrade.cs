using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Assets.Scripts;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Objects;
using HarmonyLib;
using LibConstruct;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class SmartOutputUpgrade
    {
        private sealed class SavedPart{internal Structure Structure;internal PlacementBoardStructureSaveData Save;}
        internal static void BeforeFinishLoad()
        {
            if(!GameManager.RunSimulation)return;
            try
            {
                // Adjust saved board coordinates before LibConstruct registers
                // bounds cells. This avoids live teleportation and client-only moves.
                var references=(IDictionary)AccessTools.Field(typeof(PlacementBoard),"LoadingRefs").GetValue(null);
                var boards=references.Values.Cast<object>().Select(LoadingBoard).ToArray();
                foreach(var board in boards.OfType<DinModuleBoard>())
                {
                    if(!(board?.PrimaryHost is DinRail rail))continue;
                    var waiting=Waiting(board);
                    var records=new List<SavedPart>();
                    foreach(var item in waiting)
                    {
                        var type=item.GetType();var part=AccessTools.Field(type,"Structure").GetValue(item) as Structure;
                        if(!(part is DinBreaker)&&!(part is SmartModule)&&!(part is SmartContactor)&&!(part is DinTransformer))continue;
                        var save=(PlacementBoardStructureSaveData)AccessTools.Field(type,"SaveData").GetValue(item);
                        records.Add(new SavedPart{Structure=part,Save=save});
                    }
                    if(!records.Any(p=>p.Structure is SmartContactor output&&output.ModuleWidth<SmartContactor.SlotCount))continue;
                    if(records.Any(p=>p.Save.Position.x%10!=0||p.Save.Position.y!=0||p.Save.Position.z!=0||p.Save.Rotation!=0))continue;
                    // The parent rail may not be registered on the cabinet board
                    // yet. Resolve its pending host before choosing Small/Medium capacity.
                    var cabinet=rail.Board?.PrimaryHost as SwitchboardCabinet;
                    if(cabinet==null)cabinet=boards.Where(b=>b.PrimaryHost is SwitchboardCabinet).FirstOrDefault(b=>Waiting(b).Cast<object>().Any(item=>ReferenceEquals(AccessTools.Field(item.GetType(),"Structure").GetValue(item),rail)))?.PrimaryHost as SwitchboardCabinet;
                    if(cabinet==null)continue;
                    int capacity=DinLayout.ModuleCount(CabinetShape.RailWidth(cabinet.PrefabName));
                    var plan=SmartOutputUpgradeLayout.Plan(records.Select(p=>new SmartUpgradePart(p.Structure.ReferenceId,p.Save.Position.x/10,DinParts.Width(p.Structure),
                        p.Structure is SmartModule,p.Structure is SmartContactor||p.Structure is DinBreaker net&&net.IsSmartOutputModule,p.Structure is SmartContactor)),DinLayout.FirstModuleSlot,capacity);
                    int upgraded=0;
                    foreach(var record in records)
                    {
                        var next=plan[record.Structure.ReferenceId];record.Save.Position=new Grid3(next.X*10,0,0);
                        if(record.Structure is SmartContactor output&&output.ModuleWidth!=next.Width)
                        {output.ModuleWidth=next.Width;SmartContactorModel.ApplyWidth(output);upgraded++;}
                    }
                    if(upgraded>0)Debug.Log("[Modular Switchboards] Expanded "+upgraded+" saved PLC Outputs to two DIN positions; addresses and wires retained.");
                    if(records.Any(p=>p.Structure is SmartContactor output&&output.ModuleWidth<SmartContactor.SlotCount))Debug.LogWarning("[Modular Switchboards] A legacy PLC Output needs a free slot at the left end of its bus before it can expand to two positions. No neighbouring modules were overwritten.");
                }
            }
            catch(Exception ex){Debug.LogWarning("[Modular Switchboards] Output width migration deferred; saved modules retained: "+ex.Message);}
        }
        private static PlacementBoard LoadingBoard(object reference)
        {
            var contract=reference.GetType().GetInterfaces().First(t=>t.Name=="IBoardRef");return (PlacementBoard)contract.GetProperty("Board").GetValue(reference,null);
        }
        private static IEnumerable Waiting(PlacementBoard board)=>(IEnumerable)AccessTools.Field(typeof(PlacementBoard),"AwaitingRegister").GetValue(board);
        internal static void Reindex(SmartContactor output)
        {
            var board=output.Board;if(board==null||output.BoardCells==null)return;
            foreach(var cell in output.BoardCells)if(ReferenceEquals(cell.Structure,output))cell.Structure=null;
            output.BoardCells=board.ValidBoundsCells(output.transform,output.Bounds).ToArray();foreach(var cell in output.BoardCells)cell.Structure=output;
        }
    }
}
