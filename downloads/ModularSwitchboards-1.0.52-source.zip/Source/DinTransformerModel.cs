using System;
using System.Linq;
using System.Collections.Generic;
using Assets.Scripts;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Electrical;
using Assets.Scripts.Objects.Motherboards;
using Assets.Scripts.UI;
using Assets.Scripts.Util;
using HarmonyLib;
using Rendering;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class DinTransformerModel
    {
        internal static void Install(DinTransformer owner,Transformer source,Transform storage)
        {
            // Our breaker body and mounting plate hold the exact supplied winding,
            // dial and range arc. No whole transformer body or ON/OFF switch.
            if(source.PrefabName!="StructureTransformerSmall")throw new InvalidOperationException("Small transformer reference required.");
            var audioRoots=TransformerAudio.PreserveSources(owner);
            foreach(var a in owner.GetComponentsInChildren<Animator>(true))UnityEngine.Object.DestroyImmediate(a);
            foreach(var r in owner.GetComponentsInChildren<Renderer>(true))UnityEngine.Object.DestroyImmediate(r);
            foreach(var f in owner.GetComponentsInChildren<MeshFilter>(true))UnityEngine.Object.DestroyImmediate(f);
            foreach(var c in owner.GetComponentsInChildren<Collider>(true))UnityEngine.Object.DestroyImmediate(c);
            foreach(var child in owner.transform.Cast<Transform>().ToArray())if(!audioRoots.Contains(child))UnityEngine.Object.DestroyImmediate(child.gameObject);
            owner.BaseAnimator=null;owner.Renderers=new List<ThingRenderer>();owner._staticColliders=new List<Collider>();owner._dynamicColliders=new List<Collider>();owner._selfColliders=new List<Collider>();owner.Slots=new List<Slot>();owner.OpenEnds=new List<Connection>();owner.InputConnection=null;owner.OutputConnection=null;owner.InputNetwork=null;owner.OutputNetwork=null;owner.CustomNavMeshFilter=null;owner.ForceGridBounds.Clear();owner.BrokenBuildStates=new List<BrokenBuildState>();owner.UseCellPosition=false;owner.StructureCollisionType=CollisionType.BlockCustom;owner.SelectionDisplay=SelectionHighlightMethod.Bounds;owner.HasColorState=false;owner.MPBRenderers.Clear();owner.UsedPower=0;
            foreach(string field in new[]{"switchOnOff","activateButton","leverAnimationComponent","MaterialChanger"})AccessTools.Field(typeof(Thing),field).SetValue(owner,null);
            owner.AnimComponents=new List<Effects.StateMaterialChanger>();
            owner.structureRenderMode=StructureRenderMode.Standard;owner.DiffuseIndex=(int)ColorType.White;owner.EmissionColor=Color.black;
            owner.CustomColor=GameManager.GetColorSwatch((int)ColorType.White);owner.PaintableMaterial=owner.CustomColor.Normal;
            var root=new GameObject("DinBreakerModel"){layer=owner.gameObject.layer};root.transform.SetParent(owner.transform,false);root.transform.localScale=DinBreakerModel.VisualScale;
            var body=TransformerFrontGeometry.Body();root.AddComponent<MeshFilter>().sharedMesh=body;var caseRenderer=root.AddComponent<MeshRenderer>();caseRenderer.sharedMaterials=CabinetGeometry.Materials;
            var caseHit=root.AddComponent<BoxCollider>();caseHit.center=body.bounds.center;caseHit.size=body.bounds.size;
            var face=Part(owner,"TransformerFront",TransformerFrontGeometry.Face());
            ReferencePart(owner,"TransformerCoverLeads","CoverLeads");
            ReferencePart(owner,"TransformerCoverLeadsRight","CoverLeadsRight");
            var cover=ReferencePart(owner,"TransformerSideCover","SideCover");cover.transform.localPosition=new Vector3(0,0,.0105f);
            var winding=ReferencePart(owner,"TransformerWinding","Winding");
            ReferencePart(owner,"TransformerWindingBands","WindingBands");
            var arc=ReferencePart(owner,"TransformerRangeArc","RangeArc");arc.transform.localPosition=new Vector3(0,.004f,0);
            Part(owner,"TransformerDialFrame",TransformerFrontGeometry.DialFrame());
            var dial=ReferencePart(owner,"TransformerDial","Dial");
            dial.transform.localPosition=TransformerFrontGeometry.KnobCenter;dial.transform.localRotation=Quaternion.Euler(90,0,0);owner.Needle=dial.gameObject;
            owner.NeedleMinimum=source.NeedleMinimum;owner.NeedleMaximum=source.NeedleMaximum;
            // The DIN (Small) uses the actual small transformer limits and steps.
            owner.OutputMaximum=source.OutputMaximum;owner.StepSmall=source.StepSmall;owner.StepNormal=source.StepNormal;
            owner.Interactables=new List<Interactable>();var hits=new List<Collider>{caseHit};
            foreach(var action in new[]{InteractableType.Button1,InteractableType.Button2})
            {
                var original=source.Interactables.Single(i=>i.Action==action);var target=TransformerDialHitbox.LocalBounds(action==InteractableType.Button1);
                var hitObject=new GameObject(action==InteractableType.Button1?"TransformerDecrease":"TransformerIncrease"){layer=owner.gameObject.layer};hitObject.transform.SetParent(owner.transform,false);
                var hit=hitObject.AddComponent<BoxCollider>();hitObject.transform.localPosition=target.center;hit.center=Vector3.zero;hit.size=target.size;hits.Add(hit);
                var control=new Interactable{Parent=owner,Action=action,Collider=hit,CanKeyInteract=true,KeyMap="PrimaryAction",JoinInProgressSync=true,AssociatedAudioEvents=new List<Assets.Scripts.Sound.GameAudioEvent>()};control.CacheBounds();owner.Interactables.Add(control);
            }
            foreach(var action in new[]{InteractableType.Powered,InteractableType.Error})owner.Interactables.Add(new Interactable{Parent=owner,Action=action,JoinInProgressSync=true});
            // Entry coordinates route cables; front screw coordinates select IN/OUT.
            UpdatePorts(owner);
            var state=owner.BuildStates[0];state.Visualizer=caseRenderer;state.StateMeshes=new List<Mesh>();state.RendererInstance=null;state.Colliders=hits;state.Interactables=owner.Interactables;state.LinkedGameObjects=new List<GameObject>();state.RenderMode=BuildStateRenderMode.OnMyState;AccessTools.Field(typeof(BuildState),"initialDrawData").SetValue(state,new DrawData{mesh=null,materials=new Material[0]});
            owner.CacheStates(true);owner.Setting=source.Setting;DinBreakerModel.Refresh(owner);
            var all=ModelBlueprint.Build(owner.transform);owner.Bounds=all.bounds;owner.GridBounds=new GridBounds(owner);owner.SurfaceArea=.016f*owner.ModuleWidth;
            owner.Thumbnail=CabinetIcons.Get("DinTransformer");owner.Thumbnails=new Sprite[0];state.Thumbnail=owner.Thumbnail;
            var bp=new GameObject("DinTransformerBlueprint"){layer=owner.gameObject.layer};bp.transform.SetParent(storage,false);var filter=bp.AddComponent<MeshFilter>();filter.sharedMesh=all;var renderer=bp.AddComponent<MeshRenderer>();renderer.sharedMaterial=CabinetGeometry.Materials[4];var wire=bp.AddComponent<Wireframe>();wire.BlueprintTransform=bp.transform;wire.BlueprintBounds=all.bounds;wire.BlueprintMeshFilter=filter;wire.BlueprintRenderer=renderer;bp.AddComponent<CabinetBlueprint>();owner.Blueprint=bp;owner.BlueprintOrientVector=Vector3.zero;
            Debug.Log("[Modular Switchboards] Four-position transformer body with original right front and left warning cover installed; centered native-Setting dial, no ON/OFF control; maximum="+owner.OutputMaximum+" W.");
        }
        private static void UpdatePorts(DinTransformer owner)
        {
            float center=TransformerPanelLayout.PortCenterX(owner.ModuleWidth)/DinBreakerModel.VisualScale.x;
            owner.InternalInput=Vector3.Scale(new Vector3(center,WireContactLayout.BreakerEntryY,WireContactLayout.BreakerEntryZ),DinBreakerModel.VisualScale);
            owner.InternalOutput=Vector3.Scale(new Vector3(center,-WireContactLayout.BreakerEntryY,WireContactLayout.BreakerEntryZ),DinBreakerModel.VisualScale);
            owner.InternalInputAim=Vector3.Scale(new Vector3(center,WireContactLayout.BreakerScrewY,WireContactLayout.BreakerScrewZ),DinBreakerModel.VisualScale);
            owner.InternalOutputAim=Vector3.Scale(new Vector3(center,-WireContactLayout.BreakerScrewY,WireContactLayout.BreakerScrewZ),DinBreakerModel.VisualScale);
        }
        internal static void ApplyWidth(DinTransformer owner)
        {
            var root=owner.transform.Find("DinBreakerModel");if(root==null)return;
            var body=TransformerFrontGeometry.Body(owner.ModuleWidth);root.GetComponent<MeshFilter>().sharedMesh=body;
            var hit=root.GetComponent<BoxCollider>();hit.center=body.bounds.center;hit.size=body.bounds.size;
            foreach(string name in new[]{"TransformerCoverLeads","TransformerCoverLeadsRight","TransformerSideCover"}){var part=owner.transform.Find(name);if(part!=null)part.gameObject.SetActive(owner.ModuleWidth>=DinTransformer.SlotCount);}
            owner.transform.Find("TransformerFront").GetComponent<MeshFilter>().sharedMesh=TransformerFrontGeometry.Face(owner.ModuleWidth);
            UpdatePorts(owner);owner.SurfaceArea=.016f*owner.ModuleWidth;
            owner.Bounds=ModelBlueprint.Build(owner.transform).bounds;owner.GridBounds=new GridBounds(owner);DinBreakerModel.Refresh(owner);
        }
        private static MeshRenderer ReferencePart(DinTransformer owner,string name,string asset)
        {
            var renderer=Part(owner,name,TransformerReferenceMesh.Load(asset));renderer.sharedMaterials=new[]{TransformerReferenceSurface.Material};return renderer;
        }
        private static MeshRenderer Part(DinTransformer owner,string name,Mesh mesh)
        {
            var go=new GameObject(name){layer=owner.gameObject.layer};go.transform.SetParent(owner.transform,false);go.AddComponent<MeshFilter>().sharedMesh=mesh;var renderer=go.AddComponent<MeshRenderer>();renderer.sharedMaterials=TransformerFrontSurface.Materials;return renderer;
        }
    }
}
