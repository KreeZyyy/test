using Assets.Scripts.Objects;
using UnityEngine;
namespace ModularSwitchboards
{
    // The well uses one dark finish; the slider and bearings remain light gray.
    // Both are opaque and cannot sample white regions of the APC atlas.
    internal static class ModuleMechanicalSurface
    {
        private static Material material,darkMaterial;
        internal static void Apply(MeshRenderer renderer)
        {
            if(renderer==null)return;
            bool dark=renderer.name=="ContactorGuide";
            var color=dark?new Color(.035f,.035f,.035f,1f):new Color(.42f,.45f,.45f,1f);
            var selected=dark?darkMaterial:material;
            if(selected==null)
            {
                var shader=Shader.Find("Standard");
                if(shader==null||!shader.isSupported)
                {
                    var fallback=new MaterialPropertyBlock();fallback.SetFloat(Thing.DiffuseIndexPropertyID,CabinetGeometry.PaletteIndices[dark?3:4]);fallback.SetColor(Thing.EMISSION_COLOR,Color.black);renderer.SetPropertyBlock(fallback,4);return;
                }
                selected=new Material(shader){name=dark?"Switchboards.DarkMechanismWell":"Switchboards.LightGrayMechanism",color=color};
                selected.SetFloat("_Glossiness",dark?0f:.25f);selected.SetFloat("_Metallic",0f);
                if(dark)darkMaterial=selected;else material=selected;
            }
            var materials=renderer.sharedMaterials;if(materials.Length<5)return;materials[4]=selected;renderer.sharedMaterials=materials;
            var block=new MaterialPropertyBlock();block.SetColor("_Color",color);block.SetColor("_EmissionColor",Color.black);renderer.SetPropertyBlock(block,4);
        }
        internal static void Restore(Thing owner)
        {
            foreach(var renderer in owner.GetComponentsInChildren<MeshRenderer>(true))
                if(renderer.name=="ContactorGuide"||renderer.name=="ContactorMechanicalSlider")Apply(renderer);
        }
    }
}
