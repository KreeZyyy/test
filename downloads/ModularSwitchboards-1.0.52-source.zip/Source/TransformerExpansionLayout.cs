using System.Collections.Generic;
using System.Linq;
namespace ModularSwitchboards
{
    internal static class TransformerExpansionLayout
    {
        internal static bool CanExpand(IEnumerable<SmartUpgradePart> input,long id,int first,int capacity)
        {
            var parts=input.ToArray();var own=parts.FirstOrDefault(p=>p.Id==id);
            if(own.Width!=2||parts.Any(p=>p.Width<1)||own.X<first||own.X+4>first+capacity)return false;
            return !parts.Any(p=>p.Id!=id&&own.X<p.X+p.Width&&p.X<own.X+4);
        }
    }
}
