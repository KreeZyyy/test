"""Render the four installed label widths with their physical dimensions."""
import bpy,math,sys
from pathlib import Path
from mathutils import Vector
root=Path(__file__).resolve().parents[1]
for width in ((4,) if '--only-four' in sys.argv else (1,2,3,4)):
 bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
 w=width*.0405-.004
 bpy.ops.mesh.primitive_cube_add(size=1);plate=bpy.context.object;plate.dimensions=(w,.018,.002);bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
 mat=bpy.data.materials.new('Matte white label');mat.diffuse_color=(.015,.015,.015,1);plate.data.materials.append(mat)
 bpy.ops.mesh.primitive_cube_add(size=1,location=(0,0,.00105));face=bpy.context.object;face.dimensions=(w-.0024,.0156,.0001);white=bpy.data.materials.new('White inset');white.diffuse_color=(.85,.85,.85,1);face.data.materials.append(white)
 bpy.ops.object.text_add(location=(0,0,.0013));txt=bpy.context.object;txt.data.body='LABEL';txt.data.align_x='CENTER';txt.data.align_y='CENTER';txt.data.size=.010;dark=bpy.data.materials.new('Label ink');dark.diffuse_color=(.03,.03,.03,1);txt.data.materials.append(dark)
 s=bpy.context.scene;s.render.engine='CYCLES';s.cycles.samples=32;s.cycles.use_denoising=False;s.render.resolution_x=256;s.render.resolution_y=256;s.render.resolution_percentage=100;s.render.film_transparent=True;s.world.color=(.2,.2,.2);s.view_settings.view_transform='Standard'
 bpy.ops.object.camera_add(location=(.015,-.05,.12));cam=bpy.context.object;cam.rotation_euler=(-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=w*1.3;s.camera=cam
 bpy.ops.object.light_add(type='AREA',location=(-.05,-.05,.1));bpy.context.object.data.energy=2;bpy.context.object.data.size=.2
 s.render.filepath=str(root/f'Assets/Icons/Label{width}.png');bpy.ops.render.render(write_still=True)
