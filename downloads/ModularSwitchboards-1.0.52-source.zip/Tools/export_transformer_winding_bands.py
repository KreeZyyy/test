"""Export the two complete original winding clamp prisms, with their original gray atlas UVs."""
from pathlib import Path
import json,struct
r=Path(__file__).resolve().parents[1];p=json.loads((r/'Art/SmallTransformer-reference.json').read_text())['parts'][0]
ids=[]
for s in p['surfaces']:
 for i in range(0,len(s['triangles']),3):
  tri=s['triangles'][i:i+3]
  # Measured complete lower and upper source prisms; exclude casing faces sharing their planes.
  if all(281<=k<=316 for k in tri)or all(317<=k<=352 for k in tri):assert s['material']=='spaceships_dif';ids+=tri
assert len(ids)==40*3
used=list(dict.fromkeys(ids));lookup={k:i for i,k in enumerate(used)}
v=[[.02025+p['vertices'][k]['x']*.195,-.0125+(p['vertices'][k]['y']+.089095)*.195,.0754+(p['vertices'][k]['z']-.244260132)*.195]for k in used]
uv=[[p['uv'][k][c]for c in 'xy']for k in used];tri=[lookup[k]for k in ids]
with(r/'Assets/Transformer/WindingBands.meshbin').open('wb')as f:
 f.write(struct.pack('<ii',len(v),len(tri)))
 for a,b in zip(v,uv):f.write(struct.pack('<5f',*a,*b))
 f.write(struct.pack('<'+'i'*len(tri),*tri))
(r/'Art/TransformerWindingBands.json').write_text(json.dumps({'vertices':v,'uv':uv,'triangles':{'0':tri},'sourceIndices':used,'sourceTriangles':ids,'scale':.195}))
print('Exact original winding clamps:',len(v),'vertices,',len(tri)//3,'triangles, original UV/gray atlas.')
