"""Reuse both native insulated leads, rotated to exit the cover side into the transformer."""
from pathlib import Path
from collections import defaultdict
import json,struct
r=Path(__file__).resolve().parents[1];j=json.loads((r/'Art/SmallTransformer-reference.json').read_text());p=j['parts'][0]
keys=[tuple(round(v[c],5)for c in 'xyz')for v in p['vertices']];adj=defaultdict(set)
for s in p['surfaces']:
 for i in range(0,len(s['triangles']),3):
  t=[keys[k]for k in s['triangles'][i:i+3]]
  for a,b in[(t[0],t[1]),(t[1],t[2]),(t[2],t[0])]:adj[a].add(b);adj[b].add(a)
seen=set();selected=set();pieces=[]
for k in adj:
 if k in seen:continue
 seen.add(k);g={k};queue=[k]
 while queue:
  for v in adj[queue.pop()]:
   if v not in seen:seen.add(v);g.add(v);queue.append(v)
 lo=[min(v[i]for v in g)for i in range(3)];hi=[max(v[i]for v in g)for i in range(3)]
 if len(g)==20 and lo[0]>.17:selected.update(g);pieces.append(len(g))
assert sorted(pieces)==[20,20]
ids=[]
for s in p['surfaces']:
 for i in range(0,len(s['triangles']),3):
  t=s['triangles'][i:i+3]
  if all(keys[k]in selected for k in t):assert s['material']=='spaceships_dif';ids+=t
assert len(ids)==64*3
used=list(dict.fromkeys(ids));lookup={k:i for i,k in enumerate(used)};scale=.245
# Proper axis permutation: native down becomes DIN left; depth enters the face.
v=[[.115-(p['vertices'][k]['y']+.09966)*scale,-(p['vertices'][k]['z']-.18709)*scale,.078+(p['vertices'][k]['x']-.19962)*scale]for k in used]
uv=[[p['uv'][k][c]for c in 'xy']for k in used];tri=[lookup[k]for k in ids]
with(r/'Assets/Transformer/CoverLeads.meshbin').open('wb')as f:
 f.write(struct.pack('<ii',len(v),len(tri)))
 for a,b in zip(v,uv):f.write(struct.pack('<5f',*a,*b))
 f.write(struct.pack('<'+'i'*len(tri),*tri))
(r/'Art/TransformerCoverLeads.json').write_text(json.dumps({'vertices':v,'uv':uv,'triangles':{'0':tri},'sourceIndices':used,'sourceTriangles':ids,'scale':scale}))
print('Exact red/black side leads:',len(v),'vertices,',len(tri)//3,'triangles')
