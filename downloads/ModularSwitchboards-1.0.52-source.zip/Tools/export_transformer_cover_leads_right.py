"""Mirror the native left lead pair across the center of the warning box."""
from pathlib import Path
import json,struct
r=Path(__file__).resolve().parents[1]
j=json.loads((r/'Art/TransformerCoverLeads.json').read_text())
j['vertices']=[[2*.10125-v[0],v[1],v[2]]for v in j['vertices']]
# Reflection reverses handedness. Reverse every triangle so faces stay outward.
for key in ['sourceTriangles']:
 ids=j[key];j[key]=[k for i in range(0,len(ids),3)for k in [ids[i],ids[i+2],ids[i+1]]]
for key,ids in j['triangles'].items():j['triangles'][key]=[k for i in range(0,len(ids),3)for k in [ids[i],ids[i+2],ids[i+1]]]
j['mirroredAcrossX']=.10125
v=j['vertices'];uv=j['uv'];tri=j['triangles']['0']
with(r/'Assets/Transformer/CoverLeadsRight.meshbin').open('wb')as f:
 f.write(struct.pack('<ii',len(v),len(tri)))
 for p,t in zip(v,uv):f.write(struct.pack('<5f',*p,*t))
 f.write(struct.pack('<'+'i'*len(tri),*tri))
(r/'Art/TransformerCoverLeadsRight.json').write_text(json.dumps(j))
print('Exact mirrored native red/black pair:',len(v),'vertices,',len(tri)//3,'triangles')
