"""Use the supplied exact source topology/UVs, not an approximated coil or knob."""
from pathlib import Path
from collections import defaultdict
import json,struct,shutil,math
root=Path(__file__).resolve().parents[1]
j=json.loads((root/'Art/SmallTransformer-reference.json').read_text());p=j['parts'][0]
keys=[tuple(round(v[c],5)for c in 'xyz')for v in p['vertices']];adj=defaultdict(set)
for s in p['surfaces']:
 for a,b,c in zip(s['triangles'][::3],s['triangles'][1::3],s['triangles'][2::3]):
  for x,y in [(a,b),(b,c),(c,a)]:adj[keys[x]].add(keys[y]);adj[keys[y]].add(keys[x])
seed=next(k for k in adj if abs(k[0]-.14297)<.0001 and abs(k[2]-.30716)<.0001) if any(abs(k[0]-.14297)<.0001 and abs(k[2]-.30716)<.0001 for k in adj)else max((k for k in adj if k[1]<0 and abs(k[0])<.15),key=lambda k:k[2])
visited={seed};queue=[seed]
while queue:
 for k in adj[queue.pop()]:
  if k not in visited:visited.add(k);queue.append(k)
assert len(visited)==110,('wrong winding component',len(visited))
coil=[];arc=[]
for s in p['surfaces']:
 for i in range(0,len(s['triangles']),3):
  ids=s['triangles'][i:i+3]
  if all(keys[k]in visited for k in ids):coil+=ids
  if all(p['uv'][k]['x']>.94 and p['uv'][k]['y']>.92 and abs(p['vertices'][k]['z']-.244260132)<.0001 and p['vertices'][k]['y']>.14 and p['vertices'][k]['x']<.001 for k in ids):arc+=ids
assert len(arc)==33,('wrong range arc',len(arc))
scale=.195;cx=.02025;cy=.0145;plane=.0754
source_center=j['hierarchy'][3]['position'];assert j['hierarchy'][3]['path']==j['needlePath']
source_center=[source_center[c]for c in 'xyz']
coil_center_y=(min(k[1]for k in visited)+max(k[1]for k in visited))/2
positions={}
def coil_map(v):return [cx+v['x']*scale,-.0125+(v['y']-coil_center_y)*scale,plane+(v['z']-.244260132)*scale]
def dial_map(v):
 x,y,z=[v[c]-source_center[i]for i,c in enumerate('xyz')]
 return [x*scale,z*scale,-y*scale] # inverse original Rx90; native local Y rotates it

def arc_map(v):return [cx+(v['x']-source_center[0])*scale,cy+(v['y']-source_center[1])*scale,plane+.0001]
out=root/'Assets/Transformer';out.mkdir(exist_ok=True)
preview={};provenance={}
def write(name,part,ids,transform):
 used=list(dict.fromkeys(ids));lookup={x:i for i,x in enumerate(used)};v=[transform(part['vertices'][i])for i in used];uv=[[part['uv'][i][c]for c in 'xy']for i in used];tri=[lookup[i]for i in ids]
 with (out/(name+'.meshbin')).open('wb')as f:
  f.write(struct.pack('<ii',len(v),len(tri)))
  for a,b in zip(v,uv):f.write(struct.pack('<5f',*a,*b))
  f.write(struct.pack('<'+'i'*len(tri),*tri))
 preview[name]={'vertices':v,'uv':uv,'triangles':{'0':tri}}
 provenance[name]={'sourceIndices':used,'sourceTriangles':ids,'scale':scale,'vertexCount':len(v),'triangles':len(tri)//3}
 return v
coil_v=write('Winding',p,coil,coil_map);write('RangeArc',p,arc,arc_map)
knob=next(part for part in j['parts']if part['path']==j['needlePath']);write('Dial',knob,knob['surfaces'][0]['triangles'],dial_map)
# Original exported atlas is packaged privately; no runtime native material/mesh lookup.
source_atlas=root/'Art/TransformerReferenceAtlas.png'
if not source_atlas.exists():shutil.copyfile(root.parent/'transformer-reference/StructureTransformerSmall/diffuse-0.png',source_atlas)
shutil.copyfile(source_atlas,out/'Atlas.png')
(root/'Art/TransformerParts.json').write_text(json.dumps(preview));(root/'Art/TransformerParts-provenance.json').write_text(json.dumps(provenance))
print({k:(v['vertexCount'],v['triangles'])for k,v in provenance.items()});print('Winding bounds',[(min(v[i]for v in coil_v),max(v[i]for v in coil_v))for i in range(3)])
