using System;
using System.Collections.Generic;
using System.Linq;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Objects;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class SmartOutputModel
    {
        internal const string PrefabName="StructureSmartOutputModule";
        private static Mesh Housing()
        {
            var body=DinBreakerModel.Build(plain:true,bottomOnly:true);
            var vertices=new List<Vector3>(body.vertices);var normals=new List<Vector3>(body.normals);var groups=new List<int>[5];
            for(int i=0;i<5;i++)groups[i]=new List<int>(body.GetTriangles(i));
            Action<int,Vector3,Vector3,float> box=(role,center,size,radius)=>RoundedGeometry.Box(vertices,normals,groups[role],center,size,radius);
            // Narrow PLC-style frame around a recessed, segmented front cover.
            foreach(float side in new[]{-1f,1f})
                box(1,new Vector3(side*.0069f,-.001f,.0646f),new Vector3(.0012f,.041f,.0013f),.00025f);
            box(4,new Vector3(0,-.001f,.0648f),new Vector3(.0115f,.035f,.0011f),.00045f);
            for(int row=0;row<7;row++)
                box(3,new Vector3(0,-.014f+row*.0043f,.06545f),new Vector3(.0105f,.00035f,.00025f),.00005f);
            box(4,new Vector3(0,-.021f,.0646f),new Vector3(.012f,.004f,.001f),.0003f);
            // Shallow dark slots on the top face; these are casing vents, not terminals.
            for(int vent=0;vent<5;vent++)
                box(3,new Vector3(0,.03755f,.014f+vent*.007f),new Vector3(.010f,.0002f,.0016f),.00008f);
            var mesh=new Mesh{name="Smart.Output.PlcHousing"};mesh.SetVertices(vertices);mesh.SetNormals(normals);mesh.subMeshCount=5;
            for(int i=0;i<5;i++)mesh.SetTriangles(groups[i],i);
            CabinetGeometry.ApplyNativeUv(mesh);mesh.RecalculateBounds();UnityEngine.Object.DestroyImmediate(body);return mesh;
        }
        internal static void Install(DinBreaker module,Sprite thumbnail)
        {
            var model=module.transform.Find("DinBreakerModel");
            foreach(var name in new[]{"BreakerLever","BreakerIndicator","BreakerControl"})
            {var part=model.Find(name);if(part!=null)UnityEngine.Object.DestroyImmediate(part.gameObject);}
            var view=module.GetComponent<BreakerSwitchView>();if(view!=null)UnityEngine.Object.DestroyImmediate(view);
            var mesh=Housing();model.GetComponent<MeshFilter>().sharedMesh=mesh;
            var hit=model.GetComponent<BoxCollider>();hit.center=mesh.bounds.center;hit.size=mesh.bounds.size;
            module.Interactables=new List<Interactable>();module.HasOnOffState=false;
            module.BuildStates[0].Interactables=module.Interactables;module.BuildStates[0].Colliders=new List<Collider>{hit};
            module.CacheStates(true);module.Bounds=new Bounds(Vector3.Scale(mesh.bounds.center,DinBreakerModel.VisualScale),Vector3.Scale(mesh.bounds.size,DinBreakerModel.VisualScale));module.GridBounds=new GridBounds(module);
            module.Thumbnail=thumbnail;module.BuildStates[0].Thumbnail=thumbnail;
            var plate=new GameObject("ModuleRatingPlate"){layer=module.gameObject.layer};plate.transform.SetParent(model,false);
            var vertices=new List<Vector3>();var normals=new List<Vector3>();var triangles=new List<int>();
            RoundedGeometry.Box(vertices,normals,triangles,new Vector3(0,.026f,.0645f),new Vector3(.015f,.007f,.0005f),.0003f);
            var plateMesh=new Mesh{name="Smart.Output.NamePlate"};plateMesh.SetVertices(vertices);plateMesh.SetNormals(normals);plateMesh.subMeshCount=5;
            for(int role=0;role<5;role++)plateMesh.SetTriangles(role==3?triangles.ToArray():new int[0],role);
            CabinetGeometry.ApplyNativeUv(plateMesh);plate.AddComponent<MeshFilter>().sharedMesh=plateMesh;
            var plateRenderer=plate.AddComponent<MeshRenderer>();plateRenderer.sharedMaterials=CabinetGeometry.Materials;
            var plateBlock=new MaterialPropertyBlock();plateBlock.SetFloat(Thing.DiffuseIndexPropertyID,(int)Assets.Scripts.Objects.Motherboards.ColorType.Black);plateBlock.SetColor(Thing.EMISSION_COLOR,Color.black);plateRenderer.SetPropertyBlock(plateBlock,3);
            var lens=GameObject.CreatePrimitive(PrimitiveType.Sphere);lens.name="SmartOutputLens";lens.layer=module.gameObject.layer;lens.transform.SetParent(model,false);
            lens.transform.localPosition=new Vector3(.0058f,.026f,.065f);
            lens.transform.localScale=new Vector3(.004f/DinBreakerModel.VisualScale.x,.004f/DinBreakerModel.VisualScale.y,.002f/DinBreakerModel.VisualScale.z);
            UnityEngine.Object.DestroyImmediate(lens.GetComponent<Collider>());
            var lensRenderer=lens.GetComponent<MeshRenderer>();
            CabinetGeometry.ReadNativeMesh(lens.GetComponent<MeshFilter>().sharedMesh,out var lensVertices,out _,out var lensGroups);
            var lensMesh=new Mesh{name="Smart.Output.NativeLens"};lensMesh.vertices=lensVertices;lensMesh.subMeshCount=lensGroups.Length;
            for(int i=0;i<lensGroups.Length;i++)lensMesh.SetTriangles(lensGroups[i],i);
            lensMesh.RecalculateNormals();CabinetGeometry.ApplyNativeUv(lensMesh);lens.GetComponent<MeshFilter>().sharedMesh=lensMesh;
            // Match the door indicator: a plain Standard lens, not the cabinet atlas shader.
            var shader=Shader.Find("Standard");
            if(shader==null||!shader.isSupported)throw new InvalidOperationException("NET indicator shader unavailable.");
            var lensMaterial=new Material(shader){name="Switchboards.SmartOutput.Indicator",color=Color.black};
            CabinetMatteSurface.Configure(lensMaterial);lensMaterial.EnableKeyword("_EMISSION");
            lensMaterial.SetColor("_EmissionColor",Color.black);
            lensRenderer.sharedMaterial=lensMaterial;
            lensRenderer.shadowCastingMode=UnityEngine.Rendering.ShadowCastingMode.Off;lensRenderer.receiveShadows=false;
            var glow=new GameObject("SmartOutputGlow"){layer=module.gameObject.layer};glow.transform.SetParent(model,false);
            glow.transform.localPosition=new Vector3(.0058f,.026f,.067f);
            var light=glow.AddComponent<Light>();light.type=LightType.Point;light.range=.08f;light.intensity=.025f;
            light.renderMode=LightRenderMode.ForcePixel;light.shadows=LightShadows.None;light.enabled=false;
            module.gameObject.AddComponent<SmartOutputView>();
            Font font=null;foreach(var name in new[]{"LegacyRuntime.ttf","Arial.ttf"}){try{font=Resources.GetBuiltinResource<Font>(name);}catch(Exception){}if(font!=null)break;}
            if(font==null)font=Resources.FindObjectsOfTypeAll<Font>().FirstOrDefault();
            if(font!=null)
            {
                var go=new GameObject("SmartOutputText"){layer=module.gameObject.layer};go.transform.SetParent(model,false);go.transform.localPosition=new Vector3(-.0017f,.026f,.0651f);go.transform.localRotation=Quaternion.Euler(0,180,0);
                var text=go.AddComponent<TextMesh>();text.font=font;text.fontSize=64;text.fontStyle=FontStyle.Bold;text.characterSize=.004f;text.anchor=TextAnchor.MiddleCenter;text.alignment=TextAlignment.Center;text.richText=false;text.color=new Color(.75f,.78f,.75f);text.text="NET";
                // Fit the actual font bounds inside the plate, without affecting the casing.
                // Use generated glyph geometry; renderer bounds can be stale at prefab construction.
                text.font.RequestCharactersInTexture(text.text,text.fontSize,text.fontStyle);
                var generated=text.GetComponent<MeshFilter>()?.sharedMesh;
                if(generated!=null)generated.RecalculateBounds();
                var size=generated!=null?generated.bounds.size:text.GetComponent<MeshRenderer>().localBounds.size;
                go.transform.localScale=Vector3.one*Mathf.Min(.0064f/Mathf.Max(.0001f,size.x),.0032f/Mathf.Max(.0001f,size.y));
                DepthLabelText.Apply(text);
                var ink=new Material(text.GetComponent<MeshRenderer>().sharedMaterial){name="Switchboards.SmartOutput.Label",color=text.color};
                text.GetComponent<MeshRenderer>().sharedMaterial=ink;
            }
        }
    }
}
