using System.Collections.Generic;
using Assets.Scripts;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Motherboards;
using UnityEngine;
using UnityEngine.Rendering;
using HarmonyLib;
using Rendering;
using Assets.Scripts.UI;

namespace ModularSwitchboards
{
    internal static class DinBreakerModel
    {
        internal static Mesh Build()
        {
            var vertices = new List<Vector3>();
            var triangles = new List<int>[5];
            for (int i=0;i<5;i++) triangles[i]=new List<int>();
            Box(vertices,triangles,1,new Vector3(0,0,.029f),new Vector3(.0176f,.075f,.056f));
            Box(vertices,triangles,1,new Vector3(0,0,.059f),new Vector3(.0176f,.04f,.008f));
            Box(vertices,triangles,3,new Vector3(0,0,.0635f),new Vector3(.013f,.022f,.001f));
            foreach (float side in new[]{-1f,1f})
            {
                Box(vertices,triangles,4,new Vector3(0,side*.03f,.0577f),new Vector3(.009f,.009f,.0015f));
                Box(vertices,triangles,3,new Vector3(0,side*.03f,.0586f),new Vector3(.006f,.001f,.0005f));
            }
            var mesh=new Mesh{name="Switchboards.DinBreaker1P"};mesh.SetVertices(vertices);mesh.subMeshCount=5;
            for(int i=0;i<5;i++)mesh.SetTriangles(triangles[i],i);
            mesh.RecalculateNormals();CabinetGeometry.ApplyNativeUv(mesh);mesh.RecalculateBounds();return mesh;
        }
        internal static Mesh ControlMesh(string name, Vector3 center, Vector3 size)
        {
            var vertices=new List<Vector3>();var triangles=new List<int>();
            DinRailModel.AddBox(vertices,triangles,center,size);
            var mesh=new Mesh{name=name};mesh.SetVertices(vertices);mesh.subMeshCount=5;
            for(int i=0;i<5;i++)mesh.SetTriangles(i==0?triangles.ToArray():new int[0],i);
            mesh.RecalculateNormals();CabinetGeometry.ApplyNativeUv(mesh);mesh.RecalculateBounds();return mesh;
        }
        private static Transform Control(Transform parent,string name,Mesh mesh,Vector3 position)
        {
            var go=new GameObject(name){layer=parent.gameObject.layer};go.transform.SetParent(parent,false);
            go.transform.localPosition=position;go.AddComponent<MeshFilter>().sharedMesh=mesh;
            var renderer=go.AddComponent<MeshRenderer>();renderer.sharedMaterials=CabinetGeometry.Materials;
            renderer.lightProbeUsage=LightProbeUsage.BlendProbes;renderer.reflectionProbeUsage=ReflectionProbeUsage.BlendProbes;
            renderer.shadowCastingMode=ShadowCastingMode.On;renderer.receiveShadows=true;return go.transform;
        }
        private static void Box(List<Vector3> vertices,List<int>[] triangles,int role,Vector3 center,Vector3 size)
            => DinRailModel.AddBox(vertices,triangles[role],center,size);
        internal static void Install(DinBreaker module, Transform storage)
        {
            foreach(var component in module.GetComponentsInChildren<Renderer>(true)) Object.DestroyImmediate(component);
            foreach(var component in module.GetComponentsInChildren<MeshFilter>(true)) Object.DestroyImmediate(component);
            foreach(var component in module.GetComponentsInChildren<Collider>(true)) Object.DestroyImmediate(component);
            foreach(var component in module.GetComponentsInChildren<Animator>(true)) Object.DestroyImmediate(component);
            module.BaseAnimator=null;
            module.Renderers=new List<ThingRenderer>();
            module.Interactables=new List<Interactable>();module.Slots=new List<Slot>();
            module._staticColliders=new List<Collider>();module._dynamicColliders=new List<Collider>();module._selfColliders=new List<Collider>();
            module.CustomNavMeshFilter=null;module.structureRenderMode=StructureRenderMode.Standard;
            module.ForceGridBounds.Clear();module.BrokenBuildStates=new List<BrokenBuildState>();
            module.StructureCollisionType=CollisionType.BlockCustom;
            module.SelectionDisplay=SelectionHighlightMethod.Bounds;module.UseCellPosition=false;
            module.PaintableMaterial=null;module.HasColorState=false;module.MPBRenderers.Clear();
            var model=new GameObject("DinBreakerModel"){layer=module.gameObject.layer};model.transform.SetParent(module.transform,false);
            var mesh=Build();
            var visualScale=new Vector3(1.5f,1.2f,1.1f);model.transform.localScale=visualScale;
            model.AddComponent<MeshFilter>().sharedMesh=mesh;
            var renderer=model.AddComponent<MeshRenderer>();renderer.sharedMaterials=CabinetGeometry.Materials;
            renderer.lightProbeUsage=LightProbeUsage.BlendProbes;renderer.reflectionProbeUsage=ReflectionProbeUsage.BlendProbes;
            renderer.shadowCastingMode=ShadowCastingMode.On;renderer.receiveShadows=true;
            var collider=model.AddComponent<BoxCollider>();collider.center=mesh.bounds.center;collider.size=mesh.bounds.size;
            var leverMesh=ControlMesh("BreakerLever",new Vector3(0,0,.0045f),new Vector3(.012f,.007f,.009f));
            var indicatorMesh=ControlMesh("BreakerIndicator",Vector3.zero,new Vector3(.01f,.003f,.001f));
            var lever=Control(model.transform,"BreakerLever",leverMesh,new Vector3(0,-.005f,.064f));
            lever.localRotation=Quaternion.Euler(25f,0,0);
            var indicator=Control(model.transform,"BreakerIndicator",indicatorMesh,new Vector3(0,.016f,.0645f));
            var control=new GameObject("BreakerControl"){layer=module.gameObject.layer};control.transform.SetParent(model.transform,false);
            var hit=control.AddComponent<BoxCollider>();hit.center=new Vector3(0,0,.067f);hit.size=new Vector3(.017f,.029f,.024f);
            var toggle=new Interactable {
                Parent=module, Action=InteractableType.OnOff, Collider=hit,
                JoinInProgressSync=true, CanKeyInteract=true, KeyMap="PrimaryAction"
            };
            // A new Interactable has native state 0 (OFF). Never reset this in Awake/load callbacks.
            module.Interactables=new List<Interactable>{toggle};module.HasOnOffState=true;
            var view=module.gameObject.AddComponent<BreakerSwitchView>();view.Owner=module;view.Lever=lever;
            module.Bounds=mesh.bounds;
            module.Bounds.Encapsulate(new Bounds(new Vector3(0,0,.069f),new Vector3(.0176f,.03f,.024f)));
            module.Bounds=new Bounds(Vector3.Scale(module.Bounds.center,visualScale),Vector3.Scale(module.Bounds.size,visualScale));module.SurfaceArea=.016f;
            module.GridBounds=new GridBounds(module);
            module.Thumbnail=CabinetIcons.Get("DinBreaker");module.Thumbnails=new Sprite[0];
            var state=module.BuildStates[0];state.Visualizer=renderer;state.StateMeshes=new List<Mesh>();state.RendererInstance=null;
            state.Colliders=new List<Collider>{collider,hit};state.Interactables=new List<Interactable>{toggle};
            state.LinkedGameObjects=new List<GameObject>();state.RenderMode=BuildStateRenderMode.OnMyState;
            state.BlockAir=state.AlwaysBlockAir=state.BlockLight=state.BlockGravity=false;state.Thumbnail=module.Thumbnail;
            AccessTools.Field(typeof(BuildState),"initialDrawData").SetValue(state,new DrawData{mesh=null,materials=new Material[0]});
            var blueprint=new GameObject("DinBreakerBlueprint"){layer=module.gameObject.layer};blueprint.transform.SetParent(storage,false);
            var ghost=new Mesh{name="BreakerOffBlueprint"};
            ghost.CombineMeshes(new[] {
                new CombineInstance{mesh=mesh,subMeshIndex=1,transform=Matrix4x4.Scale(visualScale)},
                new CombineInstance{mesh=mesh,subMeshIndex=3,transform=Matrix4x4.Scale(visualScale)},
                new CombineInstance{mesh=mesh,subMeshIndex=4,transform=Matrix4x4.Scale(visualScale)},
                new CombineInstance{mesh=leverMesh,subMeshIndex=0,transform=Matrix4x4.Scale(visualScale)*Matrix4x4.TRS(lever.localPosition,lever.localRotation,Vector3.one)},
                new CombineInstance{mesh=indicatorMesh,subMeshIndex=0,transform=Matrix4x4.Scale(visualScale)*Matrix4x4.Translate(indicator.localPosition)}
            },true,true);ghost.RecalculateBounds();
            var filter=blueprint.AddComponent<MeshFilter>();filter.sharedMesh=ghost;
            var br=blueprint.AddComponent<MeshRenderer>();br.sharedMaterial=CabinetGeometry.Materials[4];
            var wire=blueprint.AddComponent<Wireframe>();wire.BlueprintTransform=blueprint.transform;
            wire.BlueprintBounds=ghost.bounds;wire.BlueprintMeshFilter=filter;wire.BlueprintRenderer=br;
            blueprint.AddComponent<CabinetBlueprint>();
            module.Blueprint=blueprint;module.BlueprintOrientVector=Vector3.zero;
        }
        internal static void Refresh(Thing module)
        {
            foreach(var renderer in module.GetComponentsInChildren<MeshRenderer>(true))
            {
                if(renderer.GetComponentInParent<Thing>()!=module ||
                    (renderer.name!="DinBreakerModel" && renderer.name!="BreakerLever" && renderer.name!="BreakerIndicator"))continue;
                for(int role=0;role<5;role++)
                {
                    var block=new MaterialPropertyBlock();renderer.GetPropertyBlock(block,role);
                    int color=role==0?(int)ColorType.Blue:CabinetGeometry.PaletteIndices[role];
                    if(renderer.name=="BreakerIndicator") color=BreakerSwitchPose.IndicatorColor(module.OnOff);
                    block.SetFloat(Thing.DiffuseIndexPropertyID,color);
                    block.SetFloat(Thing.SmoothnessIndexPropertyID,module.SmoothnessIndex);
                    block.SetColor(Thing.EMISSION_COLOR,Color.black);renderer.SetPropertyBlock(block,role);
                }
            }
        }
    }
}
