using System;
using System.Collections.Generic;
using System.Linq;
using Assets.Scripts.Objects.Electrical;
using UnityEngine;

namespace ModularSwitchboards
{
    internal static class CabinetRearModel
    {
        internal const float CornerRadius=.020f;
        internal static void Install(SwitchboardCabinet cabinet)
        {
            var apc=WorldManager.Instance.SourcePrefabs.OfType<AreaPowerControl>().First(p=>p.PrefabName=="StructureAreaPowerControl");
            var root=new GameObject("RearCableCasing"){layer=cabinet.gameObject.layer};root.transform.SetParent(cabinet.transform.Find("SwitchboardModel/CompletedShell"),false);
            float rearDepth=.04f;
            var source=apc.GetComponentsInChildren<MeshRenderer>(true).FirstOrDefault(r=>r.name==apc.PrefabName);
            var original=source?.GetComponent<MeshFilter>()?.sharedMesh;
            if(original!=null)
            {
                var canonical=Matrix4x4.Rotate(CabinetModel.FrontSign<0?Quaternion.Euler(0,180,0):Quaternion.identity)*apc.transform.worldToLocalMatrix*source.transform.localToWorldMatrix;
                rearDepth=Mathf.Clamp(-CabinetWallMount.TransformedBounds(original.bounds,canonical).min.z,.025f,.09f);
            }
            Bounds input=default,left=default,right=default;bool ports=false;
            try{input=ExternalCablePorts.VisualBounds(0);left=ExternalCablePorts.VisualBounds(1);right=ExternalCablePorts.VisualBounds(2);ports=true;}
            catch(Exception ex){Debug.LogWarning("[Modular Switchboards] Rear attachment sizing: "+ex.Message);}
            float top=ports?Mathf.Clamp(input.min.y-.002f,.10f,.24f):.18f,bottom=-.24f;
            float height=top-bottom,mid=(top+bottom)*.5f,plane=-CabinetModel.MountOffset;
            Add(root.transform,cabinet,"WallNeck",new Vector3(0,mid,plane*.5f),new Vector3(.352f,height-.020f,CabinetModel.MountOffset+.002f),.016f,4);
            Add(root.transform,cabinet,"RearBox",new Vector3(0,mid,plane-rearDepth*.5f),new Vector3(.380f,height,rearDepth),CornerRadius,4);
            float coverWidth=.275f,coverHeight=Mathf.Min(.29f,height-.045f),coverZ=plane-rearDepth-.002f;
            Add(root.transform,cabinet,"RearCover",new Vector3(0,mid,coverZ),new Vector3(coverWidth,coverHeight,.004f),.014f,4);
            foreach(float x in new[]{-coverWidth*.5f+.014f,coverWidth*.5f-.014f})
                foreach(float y in new[]{mid-coverHeight*.5f+.014f,mid+coverHeight*.5f-.014f})
                    Add(root.transform,cabinet,"RearCoverBolt",new Vector3(x,y,coverZ-.003f),new Vector3(.008f,.008f,.003f),.004f,1);
            var sign=new GameObject("RearWarningAnchor"){layer=cabinet.gameObject.layer};sign.transform.SetParent(root.transform,false);
            sign.transform.localPosition=new Vector3(0,mid,coverZ-.0025f);sign.transform.localRotation=Quaternion.Euler(0,180,0);
            ApcWarning.Install(apc,sign.transform);
            var warning=sign.transform.Find("NativeApcWarning");
            if(warning!=null)
            {
                var mesh=warning.GetComponent<MeshFilter>()?.sharedMesh;
                if(mesh!=null){warning.localScale=Vector3.one*1.5f;warning.localPosition=-mesh.bounds.center*1.5f;}
            }
            float barY=ports?(left.center.y+right.center.y)*.5f:-.5f;
            float barMin=ports?left.max.x-.001f:-.25f,barMax=ports?right.min.x+.001f:.25f;
            if(barMax-barMin<.08f){barMin=-.25f;barMax=.25f;}
            float barHeight=ports?Mathf.Clamp(Math.Min(left.size.y,right.size.y),.035f,.065f):.05f;
            float carrierZ=ports?(left.center.z+right.center.z)*.5f:plane;
            float carrierDepth=ports?Mathf.Clamp(Math.Min(left.size.z,right.size.z)-.004f,.018f,.06f):.035f;
            float stemBottom=barY+barHeight*.5f;
            if(bottom>stemBottom)
                Add(root.transform,cabinet,"LowerStem",new Vector3(0,(bottom+stemBottom)*.5f,carrierZ),new Vector3(.065f,bottom-stemBottom,carrierDepth),.006f,4);
            Add(root.transform,cabinet,"LowerCrossbar",new Vector3((barMin+barMax)*.5f,barY,carrierZ),new Vector3(barMax-barMin,barHeight,carrierDepth),.006f,4);
            CabinetModel.SetBounds(cabinet);
            Debug.Log("[Modular Switchboards] Closed rounded rear: painted front unchanged; wall neck; dark rear box and separate bolted warning cover; no body cutouts or stretched native body mesh.");
        }
        private static void Add(Transform parent,SwitchboardCabinet cabinet,string name,Vector3 center,Vector3 size,float radius,int role)
        {
            var vertices=new List<Vector3>();var normals=new List<Vector3>();var indices=new List<int>();
            RoundedGeometry.Panel(vertices,normals,indices,center,size,radius);
            var mesh=new Mesh{name="Switchboards."+name};mesh.SetVertices(vertices);mesh.SetNormals(normals);mesh.subMeshCount=5;
            for(int sub=0;sub<5;sub++)mesh.SetTriangles(sub==role?indices.ToArray():new int[0],sub);
            CabinetGeometry.ApplyNativeUv(mesh);
            if(role==4){var uv=mesh.uv;for(int i=0;i<uv.Length;i++)uv[i].x=Mathf.Min(.995f,uv[i].x+.5f);mesh.uv=uv;}
            mesh.RecalculateTangents();mesh.RecalculateBounds();
            var go=new GameObject(name){layer=cabinet.gameObject.layer};go.transform.SetParent(parent,false);
            go.AddComponent<MeshFilter>().sharedMesh=mesh;go.AddComponent<MeshRenderer>().sharedMaterials=CabinetGeometry.Materials;
            var hit=go.AddComponent<MeshCollider>();hit.sharedMesh=mesh;cabinet.BuildStates[1].Colliders.Add(hit);
        }
    }
}
