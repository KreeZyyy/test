using System;
using System.IO;
using System.Collections.Generic;
using Assets.Scripts.Objects;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class ModuleKitModel
    {
        internal const string RendererName="Switchboards.ModuleKitModel";
        private static Material material;
        private static Mesh Mesh()
        {
            using(var s=typeof(ModuleKitModel).Assembly.GetManifestResourceStream("ModularSwitchboards.ModuleKit.Model.meshbin"))
            using(var r=new BinaryReader(s??throw new InvalidDataException("Module kit model missing")))
            {
                if(new string(r.ReadChars(4))!="MKIT")throw new InvalidDataException("Invalid module kit model");
                int count=r.ReadInt32(),length=r.ReadInt32();
                if(count<1||count>65535||length<3||length%3!=0||length>300000)throw new InvalidDataException("Invalid module kit counts");
                var v=new List<Vector3>();var n=new List<Vector3>();var uv=new List<Vector2>();
                for(int i=0;i<count;i++){v.Add(new Vector3(r.ReadSingle(),r.ReadSingle(),r.ReadSingle()));n.Add(new Vector3(r.ReadSingle(),r.ReadSingle(),r.ReadSingle()));uv.Add(new Vector2(r.ReadSingle(),r.ReadSingle()));}
                var t=new int[length];for(int i=0;i<length;i++){t[i]=r.ReadInt32();if(t[i]<0||t[i]>=count)throw new InvalidDataException("Invalid module kit index");}
                if(s.Position!=s.Length)throw new InvalidDataException("Unexpected module kit trailing data");
                var mesh=new Mesh{name=RendererName};mesh.SetVertices(v);mesh.SetNormals(n);mesh.SetUVs(0,uv);mesh.SetTriangles(t,0);mesh.RecalculateBounds();return mesh;
            }
        }
        private static Material Surface()
        {
            if(material!=null)return material;
            var shader=Shader.Find("Standard");if(shader==null||!shader.isSupported)shader=Shader.Find("StandardInstanced");
            if(shader==null||!shader.isSupported)throw new InvalidOperationException("Module kit standard shader unavailable");
            using(var s=typeof(ModuleKitModel).Assembly.GetManifestResourceStream("ModularSwitchboards.ModuleKit.Surface.png"))
            using(var b=new MemoryStream())
            {
                if(s==null)throw new InvalidDataException("Module kit texture missing");s.CopyTo(b);
                var texture=new Texture2D(2,2,TextureFormat.RGBA32,true,false){name="Switchboards.ModuleKit.Surface"};
                if(!ImageConversion.LoadImage(texture,b.ToArray(),true)){UnityEngine.Object.Destroy(texture);throw new InvalidDataException("Invalid module kit texture");}
                texture.wrapMode=TextureWrapMode.Repeat;
                material=new Material(shader){name="Switchboards.ModuleKit.Material",mainTexture=texture,color=Color.white};
                material.SetFloat("_Glossiness",.5f);material.SetFloat("_Metallic",0f);return material;
            }
        }
        internal static void Install(MultiConstructor kit,Bounds original)
        {
            var mesh=Mesh();var surface=Surface();
            foreach(var lod in kit.GetComponentsInChildren<LODGroup>(true))UnityEngine.Object.DestroyImmediate(lod);
            foreach(var old in kit.GetComponentsInChildren<MeshRenderer>(true))UnityEngine.Object.DestroyImmediate(old);
            var model=new GameObject(RendererName){layer=kit.gameObject.layer};model.transform.SetParent(kit.transform,false);
            float fit=SwitchboardKitGeometry.Fit(original.size,mesh.bounds.size);
            model.transform.localScale=Vector3.one*fit;model.transform.localPosition=original.center-mesh.bounds.center*fit;
            model.AddComponent<MeshFilter>().sharedMesh=mesh;var renderer=model.AddComponent<MeshRenderer>();renderer.sharedMaterial=surface;
            kit.Renderers=new List<ThingRenderer>{new ThingRenderer(kit,renderer)};kit.PaintableMaterial=null;kit.HasColorState=false;
            kit.Thumbnail=CabinetIcons.Get("KitModules");kit.Thumbnails=new Sprite[0];Refresh(renderer);
        }
        internal static void Refresh(MeshRenderer renderer)
        {
            renderer.SetPropertyBlock(null);for(int i=0;i<renderer.sharedMaterials.Length;i++)renderer.SetPropertyBlock(null,i);
            renderer.sharedMaterial=Surface();
        }
    }
}
