"""Build one standalone module-kit asset from preserved authoring data.
Only Surface.png and Model.meshbin are loaded by the runtime model.
"""
from pathlib import Path
import json,struct,math
from PIL import Image
root=Path(__file__).resolve().parents[1]
data=json.loads((root/'Art/ModuleKit/source.json').read_text());shell=data['shell'];contents=data['contents']
im=Image.open(root/'Assets/ModuleKit/Surface.png').convert('RGB')
# Choose existing neutral atlas swatches. The exported atlas is copied unchanged.
def swatch(target):
 best=None
 for y in range(24,1000,16):
  for x in range(24,1000,16):
   rgb=im.getpixel((x,y));distance=sum((a-b)**2 for a,b in zip(rgb,target))
   if best is None or distance<best[0]:best=(distance,(x+.5)/im.width,1-(y+.5)/im.height)
 return list(best[1:])
uvRole={0:swatch((38,38,38)),1:swatch((230,230,230)),2:swatch((230,230,230)),3:swatch((38,38,38)),4:swatch((155,155,155))}
v=list(shell['vertices']);n=list(shell['normals']);uv=list(shell['uv']);indices=list(shell['triangles']['0']);shellCount=len(indices)
for role,ts in contents['triangles'].items():
 for i in range(0,len(ts),3):
  points=[contents['vertices'][j]for j in ts[i:i+3]];a,b,c=points;u=[b[j]-a[j]for j in range(3)];w=[c[j]-a[j]for j in range(3)];normal=[u[1]*w[2]-u[2]*w[1],u[2]*w[0]-u[0]*w[2],u[0]*w[1]-u[1]*w[0]];length=math.sqrt(sum(x*x for x in normal));assert length>1e-14;normal=[x/length for x in normal]
  for point in points:indices.append(len(v));v.append(point);n.append(normal);uv.append(uvRole[int(role)])
assert len(v)<65536
with (root/'Assets/ModuleKit/Model.meshbin').open('wb')as f:
 f.write(b'MKIT');f.write(struct.pack('<ii',len(v),len(indices)))
 for p,normal,t in zip(v,n,uv):f.write(struct.pack('<8f',*p,*normal,*t))
 f.write(struct.pack('<'+'i'*len(indices),*indices))
(root/'Art/ModuleKit/model.json').write_text(json.dumps({'vertices':v,'normals':n,'uv':uv,'triangles':{'0':indices},'originalCrateIndexCount':shellCount,'neutralUV':uvRole}))
print('Standalone module kit:',len(v),'vertices,',len(indices)//3,'triangles; copied atlas, one material.')
