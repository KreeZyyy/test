# ModularSwitchboards — 2026-10-18

Latest published: 0.12.34, commit 665223e, KreeZyyy/test downloads.
Prepared locally: 0.12.35, internal wiring + native electrical callbacks. See README.md and Verification/Wiring-0.12.35.json.

Controls: active Wire Cutters + ordinary Cable Coil offhand; first/second primary actions select/connect; secondary cuts and refunds one coil unit; same pin cancels. Input fanout16, other contacts1, maximum64 wires. Top breaker contact is IN, bottom OUT. Native OnOff controls graph continuity. Explicit direct IN-to-output bypass is allowed. No neutral, no automatic overcurrent trip yet.

Automatic routing: 3mm lattice, native module/terminal body exclusions, 3D wire clearance, up to four internal depth planes; rejects blocked or self-intersecting routes. Placement prevents new modules overlapping wires. Deconstruct wired modules only after removing wires. Save XML and native binary join/update synchronized; authority validates and consumes coil.

Power: cabinet supplies separate output networks through native provider callbacks and transformer-style consumption accounting on IN; one shared input budget. OFF blocks only its branch. Output/input same network excluded; native provider recursion detection retained. Actual gameplay remains to test.

Source /workspace/work/switchboard-redesign. Distribution repo /workspace/test. SDK /workspace/work/dotnet/dotnet. Build args in previous README/source project; references in build-reference/rocketstation_Data/Managed. Do not overwrite downloads/ModularSwitchboards-0.12.7-BASE-BACKUP.zip. User prefers Czech, concise friendly communication and action.
