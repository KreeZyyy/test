from pathlib import Path
s=(Path(__file__).resolve().parents[2]/'Source/CabinetWiring.cs').read_text();a=s.index('        private WirePoint[] MakeRoute(');b=s.index('        internal bool WouldBlockModule',a);methods=s[a:b].replace('private WirePoint[] MakeRoute(','internal WirePoint[] MakeRoute(')
out='''using System;using System.Linq;using System.Collections.Generic;using ModularSwitchboards;
struct Vector3{public float x,y,z;public Vector3(float x,float y,float z){this.x=x;this.y=y;this.z=z;}public static Vector3 operator +(Vector3 a,Vector3 b)=>new(a.x+b.x,a.y+b.y,a.z+b.z);}
class RouteHarness{
 internal class Contact{internal CabinetWireEnd End;internal Vector3 Position,Exit;internal WireRect Bounds;}
 internal Dictionary<CabinetWireEnd,Contact> contacts=new();internal List<CabinetWireSaveData> wires=new();static WirePoint Point(Vector3 p)=>new(p.x,p.y,p.z);
 static WirePoint[] Expand(float[] p)=>Enumerable.Range(0,p.Length/3).Select(i=>new WirePoint(p[i*3],p[i*3+1],p[i*3+2])).ToArray();
'''+methods+'''
 internal static void Run(){var h=new RouteHarness();var input=new CabinetWireEnd(0,0);h.contacts[input]=new(){End=input,Position=new(0,.217f,.0463f),Exit=new(0,.184f,.108f),Bounds=new(-.036f,.036f,.195f,.227f)};
 for(int i=1;i<=2;i++){float x=i==1?.108f:-.108f;var e=new CabinetWireEnd(0,i);h.contacts[e]=new(){End=e,Position=new(x,-.217f,.0463f),Exit=new(x,-.184f,.108f),Bounds=new(x-.036f,x+.036f,-.227f,-.195f)};}
 for(int i=0;i<3;i++){float x=-.14175f+i*.0405f;var bounds=new WireRect(x-.0198f,x+.0198f,.108f-.050625f,.108f+.050625f);for(int pin=0;pin<2;pin++){var e=new CabinetWireEnd(10+i,pin);h.contacts[e]=new(){End=e,Position=new(x,.108f+(pin==0?.0405f:-.0405f),.100425f),Exit=new(x,pin==0?.167625f:.048375f,.108f),Bounds=bounds};}}
 for(int i=0;i<3;i++){var target=new CabinetWireEnd(10+i,0);var p=h.MakeRoute(input,target,out int slot,out var fail);if(p==null)throw new Exception("Full contact route "+i+": "+fail);Console.WriteLine(string.Join(";",p.Select(q=>$"{q.X:F4},{q.Y:F4},{q.Z:F4}")));var values=p.SelectMany(q=>new[]{q.X,q.Y,q.Z}).ToArray();h.wires.Add(new(){From=input,To=target,InputSlot=slot,Points=values});Console.WriteLine("Production full route "+i+" passed, fan slot "+slot+", vertices "+p.Length);}
 for(int i=0;i<2;i++){var source=new CabinetWireEnd(10+i,1);var target=new CabinetWireEnd(0,i+1);var p=h.MakeRoute(source,target,out int slot,out var fail);if(p==null)throw new Exception("Output route "+i+": "+fail);h.wires.Add(new(){From=source,To=target,InputSlot=slot,Points=p.SelectMany(q=>new[]{q.X,q.Y,q.Z}).ToArray()});Console.WriteLine("Production output route "+i+" passed, max depth "+p.Max(q=>q.Z));}
 }
}
'''
(Path(__file__).resolve().parent/'RouteHarness.cs').write_text(out)
