using System;using System.Linq;using System.Collections.Generic;using ModularSwitchboards;
struct Vector3{public float x,y,z;public Vector3(float x,float y,float z){this.x=x;this.y=y;this.z=z;}public static Vector3 operator +(Vector3 a,Vector3 b)=>new(a.x+b.x,a.y+b.y,a.z+b.z);}
class RouteHarness{
 internal class Contact{internal CabinetWireEnd End;internal Vector3 Position,Exit;internal WireRect Bounds;}
 internal Dictionary<CabinetWireEnd,Contact> contacts=new();internal List<CabinetWireSaveData> wires=new();static WirePoint Point(Vector3 p)=>new(p.x,p.y,p.z);
 static WirePoint[] Expand(float[] p)=>Enumerable.Range(0,p.Length/3).Select(i=>new WirePoint(p[i*3],p[i*3+1],p[i*3+2])).ToArray();
        internal WirePoint[] MakeRoute(CabinetWireEnd from,CabinetWireEnd to,out int slot,out string failure)
        {
            var used=new HashSet<int>(wires.Where(w=>w.From.Equals(from)).Select(w=>w.InputSlot));
            var candidates=Enumerable.Range(0,16).Where(i=>!used.Contains(i)).OrderBy(i=>i==0?0:((contacts[to].Exit.x<=0)==(i%2==1)?i:100+i));
            if(from.Owner!=0)candidates=Enumerable.Repeat(0,1).OrderBy(i=>i);
            failure=null;slot=0;
            foreach(var plane in new[]{WireRouting.Plane,.116f,.124f,.132f})
            foreach(var candidate in candidates)
            {
                var found=MakeRouteSlot(from,to,candidate,plane,out failure);
                if(found!=null){slot=candidate;return found;}
            }
            return null;
        }
        private WirePoint[] MakeRouteSlot(CabinetWireEnd from,CabinetWireEnd to,int slot,float plane,out string failure)
        {
            failure=null;var a=contacts[from];var b=contacts[to];
            bool joint=from.Owner==0&&from.Contact==0;
            float fan=slot==0?0:((slot+1)/2)*.006f*(slot%2==1?1:-1);
            var start=new WirePoint(a.Exit.x+(joint?fan:0),a.Exit.y,plane);var end=new WirePoint(b.Exit.x,b.Exit.y,plane);
            var blocks=contacts.Values.Select(c=>c.Bounds).Distinct().ToList();
            var occupied=wires.Select(w=>Expand(w.Points)).ToList();
            var middle=WireRouting.Find(start,end,blocks,occupied,joint,3);
            if(middle==null){failure="No clear route around devices and installed wires.";return null;}
            var path=new List<WirePoint>{Point(a.Position),new WirePoint(start.X,a.Position.y,plane)};
            path.AddRange(middle);path.Add(new WirePoint(end.X,b.Position.y,plane));path.Add(Point(b.Position));
            // Check contact leads too; the router only controls the central part.
            for(int i=1;i<path.Count;i++)
            {
                var exceptOwn=contacts.Values.Where(c=>!c.End.Equals(from)&&!c.End.Equals(to)&&
                    !(c.End.Owner!=0&&(c.End.Owner==from.Owner||c.End.Owner==to.Owner))).Select(c=>c.Bounds).Distinct().ToList();
                if(!WireRouting.Clear(path[i-1],path[i],exceptOwn,occupied,joint)){failure="A contact lead is blocked by another wire or device.";return null;}
            }
            var result=path.Where((p,i)=>i==0||(p-path[i-1]).Squared>1e-12f).ToArray();
            if(result.Length>512){failure="The route is too complex. Move a wire or device first.";return null;}
            if(WireRouting.SelfIntersects(result)){failure="The route would intersect its own contact lead.";return null;}
            return result;
        }

 internal static void Run(){var h=new RouteHarness();var input=new CabinetWireEnd(0,0);h.contacts[input]=new(){End=input,Position=new(0,.217f,.0463f),Exit=new(0,.184f,.108f),Bounds=new(-.036f,.036f,.195f,.227f)};
 for(int i=1;i<=2;i++){float x=i==1?.108f:-.108f;var e=new CabinetWireEnd(0,i);h.contacts[e]=new(){End=e,Position=new(x,-.217f,.0463f),Exit=new(x,-.184f,.108f),Bounds=new(x-.036f,x+.036f,-.227f,-.195f)};}
 for(int i=0;i<3;i++){float x=-.14175f+i*.0405f;var bounds=new WireRect(x-.0198f,x+.0198f,.108f-.050625f,.108f+.050625f);for(int pin=0;pin<2;pin++){var e=new CabinetWireEnd(10+i,pin);h.contacts[e]=new(){End=e,Position=new(x,.108f+(pin==0?.0405f:-.0405f),.100425f),Exit=new(x,pin==0?.167625f:.048375f,.108f),Bounds=bounds};}}
 for(int i=0;i<3;i++){var target=new CabinetWireEnd(10+i,0);var p=h.MakeRoute(input,target,out int slot,out var fail);if(p==null)throw new Exception("Full contact route "+i+": "+fail);Console.WriteLine(string.Join(";",p.Select(q=>$"{q.X:F4},{q.Y:F4},{q.Z:F4}")));var values=p.SelectMany(q=>new[]{q.X,q.Y,q.Z}).ToArray();h.wires.Add(new(){From=input,To=target,InputSlot=slot,Points=values});Console.WriteLine("Production full route "+i+" passed, fan slot "+slot+", vertices "+p.Length);}
 for(int i=0;i<2;i++){var source=new CabinetWireEnd(10+i,1);var target=new CabinetWireEnd(0,i+1);var p=h.MakeRoute(source,target,out int slot,out var fail);if(p==null)throw new Exception("Output route "+i+": "+fail);h.wires.Add(new(){From=source,To=target,InputSlot=slot,Points=p.SelectMany(q=>new[]{q.X,q.Y,q.Z}).ToArray()});Console.WriteLine("Production output route "+i+" passed, max depth "+p.Max(q=>q.Z));}
 }
}
