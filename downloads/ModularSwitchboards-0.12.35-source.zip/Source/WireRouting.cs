using System;
using System.Collections.Generic;
using System.Linq;

namespace ModularSwitchboards
{
    // Pure geometry, also exercised without Unity. All coordinates are cabinet-local metres.
    public struct WirePoint
    {
        public float X,Y,Z;
        public WirePoint(float x,float y,float z){X=x;Y=y;Z=z;}
        public static WirePoint operator +(WirePoint a,WirePoint b)=>new WirePoint(a.X+b.X,a.Y+b.Y,a.Z+b.Z);
        public static WirePoint operator -(WirePoint a,WirePoint b)=>new WirePoint(a.X-b.X,a.Y-b.Y,a.Z-b.Z);
        public static WirePoint operator *(WirePoint a,float n)=>new WirePoint(a.X*n,a.Y*n,a.Z*n);
        public float Squared=>X*X+Y*Y+Z*Z;
        public static float Dot(WirePoint a,WirePoint b)=>a.X*b.X+a.Y*b.Y+a.Z*b.Z;
    }
    public struct WireRect
    {
        public float Left,Right,Bottom,Top;
        public WireRect(float l,float r,float b,float t){Left=l;Right=r;Bottom=b;Top=t;}
        public bool Contains(WirePoint p,float margin=0)=>p.X>=Left-margin&&p.X<=Right+margin&&p.Y>=Bottom-margin&&p.Y<=Top+margin;
    }
    internal static class WireRouting
    {
        internal const float Radius=.0016f,Clearance=.0048f,Step=.003f,Plane=.108f;
        internal const float HalfWidth=.168f,HalfHeight=.228f;
        // Fan-out at IN is one deliberate electrical joint, not an accidental crossing.
        internal static bool InInputJoint(WirePoint p)=>Math.Abs(p.X)<.032f&&p.Y>.188f;
        internal static float SegmentDistanceSquared(WirePoint a,WirePoint b,WirePoint c,WirePoint d)
        {
            var u=b-a;var v=d-c;var w=a-c;float aa=u.Squared,bb=WirePoint.Dot(u,v),cc=v.Squared,dd=WirePoint.Dot(u,w),ee=WirePoint.Dot(v,w);
            if(aa<1e-12f&&cc<1e-12f)return w.Squared;
            float s=aa<1e-12f?0:Math.Max(0,Math.Min(1,(bb*ee-cc*dd)/Math.Max(1e-12f,aa*cc-bb*bb)));
            float t=cc<1e-12f?0:Math.Max(0,Math.Min(1,(bb*s+ee)/cc));
            s=aa<1e-12f?0:Math.Max(0,Math.Min(1,(bb*t-dd)/aa));
            t=cc<1e-12f?0:Math.Max(0,Math.Min(1,(bb*s+ee)/cc));
            return (a+u*s-c-v*t).Squared;
        }
        internal static bool SegmentHitsRect(WirePoint a,WirePoint b,WireRect r,float margin)
        {
            float lo=0,hi=1;float[] from={a.X,a.Y},delta={b.X-a.X,b.Y-a.Y};
            float[] min={r.Left-margin,r.Bottom-margin},max={r.Right+margin,r.Top+margin};
            for(int i=0;i<2;i++)
            {
                if(Math.Abs(delta[i])<1e-9f){if(from[i]<min[i]||from[i]>max[i])return false;}
                else {float p=(min[i]-from[i])/delta[i],q=(max[i]-from[i])/delta[i];if(p>q){float tmp=p;p=q;q=tmp;}lo=Math.Max(lo,p);hi=Math.Min(hi,q);if(lo>hi)return false;}
            }
            return true;
        }
        internal static bool Clear(WirePoint a,WirePoint b,IList<WireRect> blocks,IList<WirePoint[]> wires,bool inputJoint)
        {
            foreach(var r in blocks)if(SegmentHitsRect(a,b,r,Radius+.001f))return false;
            foreach(var wire in wires)for(int i=1;i<wire.Length;i++)
            {
                // Only sections wholly inside the common input joint may meet there.
                if(inputJoint&&InInputJoint(a)&&InInputJoint(b)&&InInputJoint(wire[i-1])&&InInputJoint(wire[i]))continue;
                if(SegmentDistanceSquared(a,b,wire[i-1],wire[i])<Clearance*Clearance)return false;
            }
            return true;
        }
        internal static bool SelfIntersects(IList<WirePoint> path)
        {
            for(int i=1;i<path.Count;i++)
            {
                float gap=0;
                for(int j=i+1;j<path.Count;j++)
                {
                    if(j>i+1)gap+=(float)Math.Sqrt((path[j-1]-path[j-2]).Squared);
                    if(gap<Radius*2)continue;
                    if(SegmentDistanceSquared(path[i-1],path[i],path[j-1],path[j])<Radius*Radius*4)return true;
                }
            }
            return false;
        }
        private struct Entry {internal int Node;internal float Score;internal Entry(int n,float s){Node=n;Score=s;}}
        private sealed class Heap
        {
            readonly List<Entry> list=new List<Entry>();
            internal int Count=>list.Count;
            internal void Push(int node,float score){var e=new Entry(node,score);int i=list.Count;list.Add(e);while(i>0){int p=(i-1)/2;if(list[p].Score<=score)break;list[i]=list[p];i=p;}list[i]=e;}
            internal Entry Pop(){var result=list[0];var last=list[list.Count-1];list.RemoveAt(list.Count-1);if(list.Count==0)return result;int i=0;while(i*2+1<list.Count){int c=i*2+1;if(c+1<list.Count&&list[c+1].Score<list[c].Score)c++;if(list[c].Score>=last.Score)break;list[i]=list[c];i=c;}list[i]=last;return result;}
        }
        internal static WirePoint[] Find(WirePoint start,WirePoint end,IList<WireRect> blocks,IList<WirePoint[]> wires,bool inputJoint,int goalDirection=-1)
        {
            const int nx=113,ny=153; // 3 mm lattice, including the usable border.
            Func<int,int,WirePoint> point=(x,y)=>new WirePoint(-HalfWidth+x*Step,-HalfHeight+y*Step,start.Z);
            int sx=(int)Math.Round((start.X+HalfWidth)/Step),sy=(int)Math.Round((start.Y+HalfHeight)/Step);
            int ex=(int)Math.Round((end.X+HalfWidth)/Step),ey=(int)Math.Round((end.Y+HalfHeight)/Step);
            if(sx<0||sx>=nx||ex<0||ex>=nx||sy<0||sy>=ny||ey<0||ey>=ny)return null;
            if(!Clear(start,point(sx,sy),blocks,wires,inputJoint)||!Clear(point(ex,ey),end,blocks,wires,inputJoint))return null;
            int count=nx*ny*4;var cost=new float[count];var parent=new int[count];var closed=new bool[count];
            for(int i=0;i<count;i++){cost[i]=float.PositiveInfinity;parent[i]=-1;}
            var heap=new Heap();for(int dir=0;dir<4;dir++){int node=(sy*nx+sx)*4+dir;cost[node]=0;heap.Push(node,0);}
            int[] dx={1,0,-1,0},dy={0,1,0,-1};int goal=-1;
            while(heap.Count>0)
            {
                int n=heap.Pop().Node;if(closed[n])continue;closed[n]=true;
                int cell=n/4,x=cell%nx,y=cell/nx,old=n%4;if(x==ex&&y==ey&&(goalDirection<0||old==goalDirection)){goal=n;break;}
                for(int dir=0;dir<4;dir++)
                {
                    if(dir==(old+2)%4)continue;int xx=x+dx[dir],yy=y+dy[dir];if(xx<0||xx>=nx||yy<0||yy>=ny)continue;
                    int next=(yy*nx+xx)*4+dir;if(closed[next])continue;
                    if(!Clear(point(x,y),point(xx,yy),blocks,wires,inputJoint))continue;
                    float laneCost=(dir%2==0)?Math.Max(0,Math.Max(start.Y,end.Y)-point(x,y).Y)*.08f:0;
                    float candidate=cost[n]+Step+laneCost+(dir==old?0:.012f);if(candidate>=cost[next])continue;
                    cost[next]=candidate;parent[next]=n;heap.Push(next,candidate+(Math.Abs(xx-ex)+Math.Abs(yy-ey))*Step);
                }
            }
            if(goal<0)return null;
            var result=new List<WirePoint>{end};for(int n=goal;n>=0;n=parent[n]){int cell=n/4;result.Add(point(cell%nx,cell/nx));}result.Add(start);result.Reverse();
            // Remove only exactly collinear vertices; never shortcut across a corner.
            var simple=new List<WirePoint>();foreach(var p in result){if(simple.Count>0&&(p-simple[simple.Count-1]).Squared<1e-12f)continue;while(simple.Count>=2){var a=simple[simple.Count-1]-simple[simple.Count-2];var b=p-simple[simple.Count-1];float cross=a.X*b.Y-a.Y*b.X;if(Math.Abs(cross)>1e-10f||WirePoint.Dot(a,b)<0)break;simple.RemoveAt(simple.Count-1);}simple.Add(p);}return simple.ToArray();
        }
    }
}
