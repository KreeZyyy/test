import bpy,json,math
from pathlib import Path
from mathutils import Vector
root=Path(__file__).resolve().parents[1];data=json.loads((root/'Art/EmergencyStopLabel.json').read_text())
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
def mat(name,color):
 m=bpy.data.materials.new(name);m.diffuse_color=(*color,1);m.use_nodes=True;m.node_tree.nodes['Principled BSDF'].inputs['Base Color'].default_value=(*color,1);m.node_tree.nodes['Principled BSDF'].inputs['Roughness'].default_value=.7;return m
yellow=mat('Yellow identification ring',(.95,.78,.015));black=mat('Fixed black lettering',(.006,.006,.006))
indices=data['triangles']['1'];mesh=bpy.data.meshes.new('Emergency ring');mesh.from_pydata(data['vertices'],[],[indices[i:i+3] for i in range(0,len(indices),3)]);mesh.update();obj=bpy.data.objects.new('Emergency ring',mesh);bpy.context.collection.objects.link(obj);mesh.materials.append(yellow)
for value,top,spread in [('EMERGENCY',True,64),('STOP',False,24)]:
 for i,c in enumerate(value):
  a=math.radians(-spread+2*spread*i/(len(value)-1));bpy.ops.object.text_add(location=(.0339*math.sin(a),(1 if top else -1)*.0339*math.cos(a),.0024));text=bpy.context.object;text.data.body=c;text.data.align_x='CENTER';text.data.align_y='CENTER';text.data.size=.0079;text.rotation_euler.z=-a if top else a;text.data.materials.append(black)
s=bpy.context.scene;s.render.engine='CYCLES';s.cycles.samples=32;s.cycles.use_denoising=False;s.render.resolution_x=s.render.resolution_y=256;s.render.resolution_percentage=100;s.render.film_transparent=True;s.world.color=(.3,.3,.3);s.view_settings.view_transform='Standard'
bpy.ops.object.camera_add(location=(.015,-.025,.2));cam=bpy.context.object;cam.rotation_euler=(-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=.092;s.camera=cam
bpy.ops.object.light_add(type='AREA',location=(-.1,.1,.2));bpy.context.object.data.energy=.45;bpy.context.object.data.size=.3
s.render.filepath=str(root/'Assets/Icons/EmergencyStopLabel.png');bpy.ops.render.render(write_still=True)
