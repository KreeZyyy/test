using System;using System.Linq;using System.Collections.Generic;using System.Xml.Serialization;using UnityEngine;namespace ModularSwitchboards{static class CabinetInnerCover{        internal static Mesh Build(IEnumerable<WireRect> windows)
        {
            var v=new List<Vector3>();var normals=new List<Vector3>();var t=new List<int>();
            float front=InnerCoverLayout.Plane+InnerCoverLayout.Thickness*.5f,rear=InnerCoverLayout.Plane-InnerCoverLayout.Thickness*.5f;
            System.Action<Vector3,Vector3,Vector3,Vector3,Vector3> quad=(a,b,c,d,n)=>
            {
                int s=v.Count;v.AddRange(new[]{a,b,c,d});normals.AddRange(new[]{n,n,n,n});
                bool forward=Vector3.Dot(Vector3.Cross(b-a,c-a),n)>0;
                t.AddRange(forward?new[]{s,s+1,s+2,s,s+2,s+3}:new[]{s,s+2,s+1,s,s+3,s+2});
            };
            foreach(var cell in InnerCoverLayout.Cells(windows))
            {
                float l=cell.Left,r=cell.Right,b=cell.Bottom,u=cell.Top;
                quad(new Vector3(l,b,front),new Vector3(r,b,front),new Vector3(r,u,front),new Vector3(l,u,front),Vector3.forward);
                quad(new Vector3(l,b,rear),new Vector3(r,b,rear),new Vector3(r,u,rear),new Vector3(l,u,rear),Vector3.back);
                if(cell.West)quad(new Vector3(l,b,rear),new Vector3(l,u,rear),new Vector3(l,u,front),new Vector3(l,b,front),Vector3.left);
                if(cell.East)quad(new Vector3(r,b,rear),new Vector3(r,u,rear),new Vector3(r,u,front),new Vector3(r,b,front),Vector3.right);
                if(cell.South)quad(new Vector3(l,b,rear),new Vector3(r,b,rear),new Vector3(r,b,front),new Vector3(l,b,front),Vector3.down);
                if(cell.North)quad(new Vector3(l,u,rear),new Vector3(r,u,rear),new Vector3(r,u,front),new Vector3(l,u,front),Vector3.up);
            }
            var result=new Mesh{name="Switchboards.InnerCover.DinWindows"};result.SetVertices(v);result.SetNormals(normals);result.subMeshCount=5;
            for(int i=0;i<5;i++)result.SetTriangles(i==0?t.ToArray():new int[0],i);
            CabinetGeometry.ApplyNativeUv(result);result.RecalculateBounds();return result;
        }
}    public sealed class SwitchboardCabinetSaveData : StructureSaveData
    {
        [XmlElement] public PlacementBoardHostSaveData RailBoard;
        [XmlArray] public CabinetWireSaveData[] Wires;
        [XmlElement] public int CoverSchema;
        [XmlElement] public PlacementBoardHostSaveData CoverBoard;
    }

partial class SwitchboardCabinet{        public bool HasInnerCover => CurrentBuildStateIndex==2 || CoverBoard?.Structures.OfType<InnerCoverModule>().Any(c=>!c.IsBeingDestroyed)==true;
        public bool CanAccessModules => CurrentBuildStateIndex>=1&&IsOpen;
        public bool CanFitRails => CurrentBuildStateIndex == 1 && IsOpen && !HasInnerCover;

        protected override CanConstructInfo CanDeconstruct()
        {
            if(CurrentBuildStateIndex==2)return IsOpen?CanConstructInfo.ValidPlacement:CanConstructInfo.InvalidPlacement("Open the cabinet first.");
            if(HasInnerCover)return CanConstructInfo.InvalidPlacement("Remove the inner cover first.");
            return Wiring.HasAnyWires?CanConstructInfo.InvalidPlacement("Remove internal wires first."):RailBoard != null && RailBoard.Structures.Count > 0
                ? CanConstructInfo.InvalidPlacement("Remove DIN rails first.") : base.CanDeconstruct();
        }
        public override DelayedActionInstance AttackWith(Attack attack, bool doAction = true)
        {
            if(attack.SourceItem?.PrefabName=="ItemWrench"&&CurrentBuildStateIndex==2)
            {
                if(!IsOpen)return new DelayedActionInstance{Duration=0}.Fail("Open the cabinet first.");
                return base.AttackWith(attack,doAction);
            }
            if(HasInnerCover&&(attack.SourceItem?.PrefabName=="ItemWrench"||attack.SourceItem?.PrefabName=="ItemDrill"))return null;
            if(Wiring.TryAttack(attack,doAction,out var wireAction))return wireAction;
            if(Wiring.HasAnyWires && (attack.SourceItem?.PrefabName=="ItemWrench"||attack.SourceItem?.PrefabName=="ItemDrill"))return null;
            if (RailBoard != null && RailBoard.Structures.Count > 0 &&
                (attack.SourceItem?.PrefabName == "ItemWrench" || attack.SourceItem?.PrefabName == "ItemDrill"))
                return null;
            return base.AttackWith(attack, doAction);
        }
}static class Migration{public const string CabinetName="cabinet";        internal static void MigrateCabinetSave(Structure __instance, ThingSaveData __0)
        {
            if (__instance.PrefabName == CabinetName && __0 is StructureSaveData save && save.CurrentBuildState > 1 && (save.CurrentBuildState>2 || !(__0 is SwitchboardCabinetSaveData coverSave) || coverSave.CoverSchema<1))
            {
                save.CurrentBuildState = 1;
                Debug.Log("[Modular Switchboards] Migrated legacy completed cabinet to simple completed shell.");
            }
        }

}partial class InnerCoverModule{        internal static bool CanPlace(PlacementBoard board,Grid3 position,int rotation)
            =>board is CabinetCoverBoard&&board.PrimaryHost is SwitchboardCabinet host&&host.CanFitRails&&
                position.x==0&&position.y==0&&position.z==0&&rotation==0&&board.Structures.Count==0;
}}