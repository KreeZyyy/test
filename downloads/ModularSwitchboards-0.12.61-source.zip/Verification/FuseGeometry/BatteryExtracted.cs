using System;using System.Collections.Generic;using UnityEngine;namespace ModularSwitchboards {static class DinBatteryModel{
        internal static Mesh Build()
        {
            var v=new List<Vector3>();var n=new List<Vector3>();var t=new List<int>[5];for(int i=0;i<5;i++)t[i]=new List<int>();
            float face=ApcBatteryRegion.Front(ApcBatteryRegion.FitScale(new Vector3(.10804666f,.10804666f,0)));
            float x=DinBatteryLayout.CenterX;
            float width=DinBatteryLayout.Width;
            System.Action<Vector3,Vector3,int> box=(p,s,r)=>RoundedGeometry.Box(v,n,t[r],p,s,.0007f);
            // Closed two-position enclosure with a front fascia. Only the native
            // socket aperture remains open; there is no full-width open cubby.
            float holeX=(ApcBatteryRegion.SocketHeight+.0006f)/DinBreakerModel.VisualScale.x;
            float holeY=(ApcBatteryRegion.SocketHeight+.0006f)/DinBreakerModel.VisualScale.y;
            float outerY=.075f;
            box(new Vector3(x,0,.003f),new Vector3(width,outerY,.002f),1);
            // Four solid walls extend up to the front, surrounding the cell pocket.
            foreach(float side in new[]{-1f,1f})
            {
                float sideWidth=(width-holeX)*.5f;
                box(new Vector3(x+side*(holeX+sideWidth)*.5f,0,(face+.004f)*.5f),new Vector3(sideWidth,outerY,face-.004f),1);
                float capHeight=(outerY-holeY)*.5f;
                box(new Vector3(x,side*(holeY+capHeight)*.5f,(face+.004f)*.5f),new Vector3(holeX,capHeight,face-.004f),1);
                box(new Vector3(x,side*.030f,face+.0005f),new Vector3(.009f,.009f,.001f),4);
                box(new Vector3(x,side*.030f,face+.0012f),new Vector3(.006f,.001f,.0004f),3);
                box(new Vector3(x,side*.0376f,.029f),new Vector3(.004f,.0003f,.004f),3);
            }
            // Flat grey front plate, filled all the way to the socket rim. The
            // four strips form a real hole, not a solid plate through the battery.
            float plateWidth=width-.002f,plateHeight=.057f;
            foreach(float side in new[]{-1f,1f})
            {
                float stripWidth=(plateWidth-holeX)*.5f;
                box(new Vector3(x+side*(holeX+stripWidth)*.5f,0,face+.00035f),new Vector3(stripWidth,plateHeight,.0007f),3);
                float stripHeight=(plateHeight-holeY)*.5f;
                box(new Vector3(x,side*(holeY+stripHeight)*.5f,face+.00035f),new Vector3(holeX,stripHeight,.0007f),3);
            }
            var mesh=new Mesh{name="Switchboards.DinBatteryHousing"};mesh.SetVertices(v);mesh.SetNormals(n);mesh.subMeshCount=5;
            for(int i=0;i<5;i++)mesh.SetTriangles(t[i],i);CabinetGeometry.ApplyNativeUv(mesh);mesh.RecalculateBounds();return mesh;
        }
}
    internal static class ModuleLayout
    {
        internal static bool Fits(int x, int y, int z, int rotation, int width, int capacity)
            => x % 10 == 0 && y == 0 && z == 0 && rotation == 0 && width > 0 &&
                x >= 0 && x / 10 + width <= capacity;
        internal static bool Overlaps(int start, int width, int other, int otherWidth)
            => start < other + otherWidth && other < start + width;
    }

}