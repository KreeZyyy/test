using System.Collections.Generic;
using System.Linq;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Items;
using UnityEngine;
using Rendering;
using Assets.Scripts.UI;

namespace ModularSwitchboards
{
    internal static class DinBatteryModel
    {
        internal static Mesh Build()
        {
            var v=new List<Vector3>();var n=new List<Vector3>();var t=new List<int>[5];for(int i=0;i<5;i++)t[i]=new List<int>();
            float face=ApcBatteryGeometry.FaceDepth;
            float x=DinBatteryLayout.CenterX;
            float width=DinBatteryLayout.Width;
            System.Action<Vector3,Vector3,int> box=(p,s,r)=>RoundedGeometry.Box(v,n,t[r],p,s,.0007f);
            // Closed two-position enclosure with a front fascia. Only the native
            // socket aperture remains open; there is no full-width open cubby.
            float holeX=(ApcBatteryRegion.SocketHeight+.0006f)/DinBreakerModel.VisualScale.x;
            float holeY=(ApcBatteryRegion.SocketHeight+.0006f)/DinBreakerModel.VisualScale.y;
            float outerY=.075f;
            box(new Vector3(x,0,.003f),new Vector3(width,outerY,.002f),1);
            // Four solid walls extend up to the front, surrounding the cell pocket.
            foreach(float side in new[]{-1f,1f})
            {
                float sideWidth=(width-holeX)*.5f;
                box(new Vector3(x+side*(holeX+sideWidth)*.5f,0,(face+.004f)*.5f),new Vector3(sideWidth,outerY,face-.004f),1);
                float capHeight=(outerY-holeY)*.5f;
                box(new Vector3(x,side*(holeY+capHeight)*.5f,(face+.004f)*.5f),new Vector3(holeX,capHeight,face-.004f),1);
                box(new Vector3(x,side*.030f,face+.0005f),new Vector3(.009f,.009f,.001f),4);
                box(new Vector3(x,side*.030f,face+.0012f),new Vector3(.006f,.001f,.0004f),3);
                box(new Vector3(x,side*.0376f,.029f),new Vector3(.004f,.0003f,.004f),3);
            }
            // Flat grey front plate, filled all the way to the socket rim. The
            // four strips form a real hole, not a solid plate through the battery.
            float plateWidth=width-.002f,plateHeight=.057f;
            foreach(float side in new[]{-1f,1f})
            {
                float stripWidth=(plateWidth-holeX)*.5f;
                box(new Vector3(x+side*(holeX+stripWidth)*.5f,0,face+.00035f),new Vector3(stripWidth,plateHeight,.0007f),3);
                float stripHeight=(plateHeight-holeY)*.5f;
                box(new Vector3(x,side*(holeY+stripHeight)*.5f,face+.00035f),new Vector3(holeX,stripHeight,.0007f),3);
            }
            var mesh=new Mesh{name="Switchboards.DinBatteryHousing"};mesh.SetVertices(v);mesh.SetNormals(n);mesh.subMeshCount=5;
            for(int i=0;i<5;i++)mesh.SetTriangles(t[i],i);CabinetGeometry.ApplyNativeUv(mesh);mesh.RecalculateBounds();return mesh;
        }
        internal static void Install(DinBreaker module)
        {
            var oldView=module.GetComponent<BreakerSwitchView>();if(oldView!=null)Object.DestroyImmediate(oldView);
            var model=module.transform.Find("DinBreakerModel");
            foreach(string name in new[]{"BreakerLever","BreakerControl","BreakerIndicator"}){var child=model.Find(name);if(child!=null)Object.DestroyImmediate(child.gameObject);}
            var mesh=Build();model.GetComponent<MeshFilter>().sharedMesh=mesh;
            var bayMesh=ApcBatteryGeometry.Install(model);
            var body=model.GetComponent<BoxCollider>();body.center=mesh.bounds.center;body.size=mesh.bounds.size;
            var action=new GameObject("BatteryControl"){layer=module.gameObject.layer};action.transform.SetParent(model,false);
            var collider=action.AddComponent<BoxCollider>();collider.center=ApcBatteryGeometry.HitBounds.center;collider.size=ApcBatteryGeometry.HitBounds.size;
            var toggle=new Interactable{Parent=module,Action=InteractableType.Slot1,Collider=collider,JoinInProgressSync=true,CanKeyInteract=true,KeyMap="PrimaryAction"};
            module.Slots=new List<Slot>{ApcBatteryGeometry.CreateSlot(module,model,collider,toggle)};
            module.Interactables=new List<Interactable>{toggle};module.HasOnOffState=false;
            module.BuildStates[0].Interactables=module.Interactables;module.BuildStates[0].Colliders=new List<Collider>{body,collider};
            var bounds=mesh.bounds;bounds.Encapsulate(bayMesh.bounds);bounds.Encapsulate(new Bounds(collider.center,collider.size));
            module.Bounds=new Bounds(Vector3.Scale(bounds.center,model.localScale),Vector3.Scale(bounds.size,model.localScale));module.SurfaceArea=.016f*module.ModuleWidth;
            module.GridBounds=new GridBounds(module);
            var ghost=module.Blueprint.GetComponent<MeshFilter>().sharedMesh;ghost.Clear();
            var pieces=Enumerable.Range(0,5).Select(i=>new CombineInstance{mesh=mesh,subMeshIndex=i,transform=Matrix4x4.Scale(model.localScale)}).ToList();
            for(int i=0;i<bayMesh.subMeshCount;i++)pieces.Add(new CombineInstance{mesh=bayMesh,subMeshIndex=i,transform=Matrix4x4.Scale(model.localScale)});
            ghost.CombineMeshes(pieces.ToArray(),true,true);ghost.RecalculateBounds();
            module.Blueprint.GetComponent<Wireframe>().BlueprintBounds=ghost.bounds;
            var view=module.gameObject.AddComponent<DinBatteryView>();view.Owner=module;
        }
    }

    // The real cell stays in the native-style slot. Its own renderer/material
    // state machinery handles type, charge colours and critical blinking.
    public sealed class DinBatteryView:MonoBehaviour
    {
        public DinBreaker Owner;
        private BatteryCell previous;
        private bool previousVisible;
        private int diagnosticDelay;
        private void LateUpdate()
        {
            if(Owner==null)return;
            var cell=Owner.Battery;
            bool show=CabinetWiring.CabinetOf(Owner)?.IsOpen==true;
            if(Owner.Slots.Count==1)Owner.Slots[0].HidesOccupant=!show;
            if(diagnosticDelay>0&&--diagnosticDelay==0&&show)BatteryAppearanceDiagnostics.Capture(Owner);
            if(ReferenceEquals(cell,previous)&&show==previousVisible)return;
            if(show)diagnosticDelay=3;
            previous=cell;previousVisible=show;
            if(cell!=null)cell.SetVisibility(show);
        }
    }
}
