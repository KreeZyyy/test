using System;
using System.Collections.Generic;
using System.Linq;
using Assets.Scripts;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Inventory;
using Assets.Scripts.Networking;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Entities;
using Assets.Scripts.Objects.Items;
using Assets.Scripts.Objects.Motherboards;
using LibConstruct;
using UnityEngine;

namespace ModularSwitchboards
{
    public sealed class CabinetWirePaintTarget : MonoBehaviour { public CabinetWireSaveData Wire; }

    public sealed class CabinetWireTarget : MonoBehaviour { public CabinetWireEnd End; }

    public sealed partial class CabinetWiring : MonoBehaviour
    {
        internal const ushort UpdateFlag=32768;
        internal const int CurrentRouteVersion=4;
        public SwitchboardCabinet Owner;
        private readonly List<CabinetWireSaveData> wires=new List<CabinetWireSaveData>();
        private readonly Dictionary<long,CabinetWireEnd> pending=new Dictionary<long,CabinetWireEnd>();
        private readonly Dictionary<long,float> pendingUntil=new Dictionary<long,float>();
        private readonly Dictionary<CabinetWireEnd,Contact> contacts=new Dictionary<CabinetWireEnd,Contact>();
        private readonly List<GameObject> visuals=new List<GameObject>();
        private readonly List<Collider> colliders=new List<Collider>();
        internal readonly CabinetWiringPower Power=new CabinetWiringPower();
        private Transform shell,visualRoot;
        private readonly List<WireRect> railObstacles=new List<WireRect>();
        private readonly WireRect[] moduleReservations=WireModuleSpace.Reservations().ToArray();
        private readonly Dictionary<CabinetWireSaveData,MeshRenderer> wireRenderers=new Dictionary<CabinetWireSaveData,MeshRenderer>();
        private GameObject preview;
        private WirePoint[] previewPath;
        private int previewFrame=-1;
        private bool needsReroute;
        private string migrationFailure;
        private float nextRefresh,topologyReadyAt;
        private string topology;
        private bool rebuild=true;
        private int revision,routeRevision=-1;
        private CabinetWireEnd routeFrom,routeTo;
        private WirePoint[] route;
        private string routeFailure;
        private int routeSlot;
        private sealed class Contact {internal CabinetWireEnd End;internal Vector3 Position,Aim,Exit;internal WireRect Bounds;internal GameObject Marker;}
        internal static SwitchboardCabinet CabinetOf(DinBreaker breaker)=>(breaker.Board?.PrimaryHost as DinRail)?.Board?.PrimaryHost as SwitchboardCabinet;
        internal IEnumerable<DinBreaker> Breakers=>Owner.RailBoard==null?Enumerable.Empty<DinBreaker>():Owner.RailBoard.Structures.OfType<DinRail>()
            .Where(r=>r.Modules!=null).SelectMany(r=>r.Modules.Structures.OfType<DinBreaker>());
        private Transform Shell=>shell!=null?shell:(shell=Owner.transform.Find("SwitchboardModel/CompletedShell"));
        internal static WirePoint Point(Vector3 p)=>new WirePoint(p.x,p.y,p.z);
        internal static Vector3 Vector(WirePoint p)=>new Vector3(p.X,p.Y,p.Z);
        internal bool HasWires(long breaker)=>wires.Any(w=>w.From.Owner==breaker||w.To.Owner==breaker);
        internal Assets.Scripts.Networks.CableNetwork AnalysedNetwork(DinBreaker analyser,out string reason)
        {
            reason=null;
            if(Owner==null||Owner.IsCursor||!Owner.IsStructureCompleted||Owner.GridController==null){reason="No cable network found.";return null;}
            int output=AnalyserCircuit.Output(analyser.ReferenceId,wires,Breakers.Where(b=>b.Conducting).Select(b=>b.ReferenceId));
            if(output==0){reason="Wire the analyser OUT to Output 1 or Output 2.";return null;}
            var first=Owner.Output1Connection?.GetCable()?.CableNetwork;
            var second=Owner.Output2Connection?.GetCable()?.CableNetwork;
            if(output==3&&!ReferenceEquals(first,second)){reason="Analyser leads to two different networks.";return null;}
            var network=output==2?second:first;
            if(network==null)reason="No cable network found on Output "+(output==2?"2":"1")+".";
            return network;
        }
        internal bool HasAnyWires=>wires.Count!=0;
        internal static bool IsCoil(DynamicThing item)=>item?.PrefabName=="ItemCableCoil"&&item is Stackable;
        private static bool LocalTools()=>!GameManager.IsBatchMode&&IsCoil(InventoryManager.ActiveHandSlot?.Get());
        private int Occupied(CabinetWireEnd e)=>wires.Count(w=>w.From.Equals(e)||w.To.Equals(e));
        private void Changed(){HidePreview();revision++;routeRevision=-1;rebuild=true;Owner.NetworkUpdateFlags|=UpdateFlag;RefreshPower();}
        private void RefreshPower()
        {
            var modules=Breakers.ToArray();
            if(GameManager.RunSimulation)foreach(var id in Power.DrainTrips())modules.FirstOrDefault(b=>b.ReferenceId==id)?.Trip();
            Power.Refresh(Owner,wires,modules);
        }
        internal void Tick()
        {
            if(Owner==null||Owner.IsCursor||!Owner.IsStructureCompleted)return;
            if(Time.unscaledTime>=nextRefresh)
            {
                nextRefresh=Time.unscaledTime+.15f;RefreshContacts();
                if(GameManager.RunSimulation)
                    foreach(var actor in pendingUntil.Where(p=>p.Value<Time.unscaledTime).Select(p=>p.Key).ToArray())
                    {pending.Remove(actor);pendingUntil.Remove(actor);Owner.NetworkUpdateFlags|=UpdateFlag;}
            }
            if(!Owner.IsOpen&&GameManager.RunSimulation&&pending.Count>0){pending.Clear();pendingUntil.Clear();Owner.NetworkUpdateFlags|=UpdateFlag;}
            if(needsReroute&&GameManager.RunSimulation&&!PlacementBoard.Loading&&Owner.RailBoard!=null&&Time.unscaledTime>=topologyReadyAt&&wires.All(w=>contacts.ContainsKey(w.From)&&contacts.ContainsKey(w.To)))RerouteLegacy();
            RefreshPower();
            if(rebuild){RebuildVisuals();rebuild=false;}
            bool show=Owner.IsOpen,tools=show&&LocalTools();
            if(visualRoot!=null)visualRoot.gameObject.SetActive(show);
            var human=GameManager.IsBatchMode?null:Human.LocalHuman;pending.TryGetValue(human!=null?human.ReferenceId:0,out var selected);
            foreach(var c in contacts.Values)
            {
                if(c.Marker==null)continue;
                bool available=Occupied(c.End)<c.End.Capacity&&(selected==null||selected.Equals(c.End)||
                    WireCircuit.CanConnect(selected,c.End,wires,Breakers.Select(b=>b.ReferenceId),out _));
                c.Marker.SetActive(tools&&available);
                var renderer=c.Marker.GetComponent<MeshRenderer>();
                if(renderer!=null)Color(renderer,c.End.Equals(selected)?ColorType.Yellow:c.End.IsSource?ColorType.Green:ColorType.Orange);
            }
            bool cutting=!GameManager.IsBatchMode&&InventoryManager.ActiveHandSlot?.Get() is WireCutter&&show;
            int hover=cutting&&CursorManager.Instance!=null?WireAt(CursorManager.CursorHit.point):-1;
            foreach(var pair in wireRenderers)if(pair.Value!=null)Color(pair.Value,hover>=0&&ReferenceEquals(wires[hover],pair.Key)?ColorType.Yellow:WireColor(pair.Key));
            if(!tools||!show||previewFrame!=Time.frameCount)HidePreview();
        }
        private void RefreshContacts()
        {
            if(Shell==null)return;
            var breakers=Breakers.Where(b=>!b.IsBeingDestroyed).ToArray();
            var rails=Owner.RailBoard==null?new DinRail[0]:Owner.RailBoard.Structures.OfType<DinRail>().ToArray();
            var signature=string.Join(";",breakers.Select(b=>b.ReferenceId+":"+b.ModuleWidth+":"+Shell.InverseTransformPoint(b.Transform.position).ToString("F5")).OrderBy(x=>x))+"|"+string.Join(";",rails.Select(r=>r.ReferenceId+":"+Shell.InverseTransformPoint(r.Transform.position).ToString("F5")).OrderBy(x=>x));
            if(topology==signature&&contacts.Count>0)return;
            topology=signature;topologyReadyAt=Time.unscaledTime+.5f;ClearVisuals();contacts.Clear();railObstacles.Clear();
            foreach(var rail in rails)
            {
                var model=rail.transform.Find("DinRailModel");var mesh=model?.GetComponent<MeshFilter>()?.sharedMesh;
                if(model==null||mesh==null)continue;
                var bounds=mesh.bounds;var min=Vector3.one*float.MaxValue;var max=Vector3.one*float.MinValue;
                foreach(float x in new[]{bounds.min.x,bounds.max.x})foreach(float y in new[]{bounds.min.y,bounds.max.y})foreach(float z in new[]{bounds.min.z,bounds.max.z})
                {var p=Shell.InverseTransformPoint(model.TransformPoint(new Vector3(x,y,z)));min=Vector3.Min(min,p);max=Vector3.Max(max,p);}
                railObstacles.Add(new WireRect(min.x,max.x,min.y,max.y));
            }
            foreach(var terminal in Owner.GetComponentsInChildren<CabinetTerminalBlock>(true))
            {
                var p=Shell.InverseTransformPoint(terminal.FrontContactWorld(0));
                var center=Shell.InverseTransformPoint(terminal.transform.position);
                int index=(int)terminal.TerminalId;
                AddContact(new CabinetWireEnd(0,index),p,Shell.InverseTransformPoint(terminal.transform.TransformPoint(terminal.SelectionPoint)),new Vector3(center.x,center.y+(index==0?-.027f:.027f),WireRouting.Plane),
                    new WireRect(center.x-.036f,center.x+.036f,center.y-.016f,center.y+.016f));
            }
            foreach(var breaker in breakers)
            {
                var model=breaker.transform.Find("DinBreakerModel");if(model==null)continue;
                var center=Shell.InverseTransformPoint(model.position);
                var p0=Shell.InverseTransformPoint(model.TransformPoint(new Vector3(-.0088f,-.0375f,0)));
                var p1=Shell.InverseTransformPoint(model.TransformPoint(new Vector3(.0088f+(breaker.ModuleWidth-1)*DinLayout.SlotPitch/DinBreakerModel.VisualScale.x,.0375f,0)));
                var bounds=new WireRect(Mathf.Min(p0.x,p1.x),Mathf.Max(p0.x,p1.x),Mathf.Min(p0.y,p1.y),Mathf.Max(p0.y,p1.y));
                for(int pin=0;pin<2;pin++)
                {
                    var p=Shell.InverseTransformPoint(model.TransformPoint(Vector(WireContactLayout.BreakerEntry(pin))+Vector3.right*breaker.ContactOffsetX));
                    var exit=new Vector3(p.x,pin==0?bounds.Top+.015375f:bounds.Bottom-.015375f,WireRouting.Plane);
                    AddContact(new CabinetWireEnd(breaker.ReferenceId,pin),p,Shell.InverseTransformPoint(model.TransformPoint(Vector(WireContactLayout.BreakerAim(pin))+Vector3.right*breaker.ContactOffsetX)),exit,bounds);
                }
            }
            if(GameManager.RunSimulation)
            {
                var batteryIds=new HashSet<long>(breakers.Where(b=>b.IsBatteryModule).Select(b=>b.ReferenceId));
                foreach(var wire in wires)
                {
                    var points=Expand(wire.Points);
                    if(batteryIds.Contains(wire.From.Owner)&&contacts.TryGetValue(wire.From,out var from)&&(points[0]-Point(from.Position)).Squared>.000001f)needsReroute=true;
                    if(batteryIds.Contains(wire.To.Owner)&&contacts.TryGetValue(wire.To,out var to)&&(points[points.Length-1]-Point(to.Position)).Squared>.000001f)needsReroute=true;
                }
            }
            // References may not be loaded yet: do not prune saved wires until a real deconstruction event.
            revision++;routeRevision=-1;rebuild=true;
        }
        private void AddContact(CabinetWireEnd end,Vector3 position,Vector3 aim,Vector3 exit,WireRect bounds)
        {contacts[end]=new Contact{End=end,Position=position,Aim=aim,Exit=exit,Bounds=bounds};}
        private bool TryContact(Attack attack,out Contact contact)
        {
            contact=null;if(Shell==null)return false;
            var p=Shell.InverseTransformPoint(attack.Position);float best=.016f*.016f;
            foreach(var c in contacts.Values){float distance=(p-c.Aim).sqrMagnitude;if(distance<best){best=distance;contact=c;}}
            return contact!=null;
        }
        internal bool ContainsInteractionPoint(Vector3 world)
        {
            if(Shell==null)return false;var p=Shell.InverseTransformPoint(world);
            return Mathf.Abs(p.x)<.19f&&Mathf.Abs(p.y)<.24f&&p.z>=0&&p.z<.16f;
        }
        internal bool TryAttack(Attack attack,bool doAction,out Thing.DelayedActionInstance result)
        {
            result=null;
            if(attack.SourceItem is ISprayer sprayer&&TryPaintWire(attack,sprayer,doAction,out result))return true;
            bool cutting=attack.SourceItem is WireCutter;
            var coil=IsCoil(attack.SourceItem)?attack.SourceItem as Stackable:null;
            if(!cutting&&coil==null)return false;
            HidePreview();
            result=new Thing.DelayedActionInstance{Duration=0};
            if(Owner.IsCursor||!Owner.IsStructureCompleted||!Owner.IsOpen){result.Fail("Open the completed cabinet first.");return true;}
            var actor=attack.SourceItem.RootParentHuman;
            if(actor==null){result.Fail("Hold a cable coil to connect, or wire cutters to remove a wire.");return true;}
            if((actor.Transform.position-Owner.Transform.position).sqrMagnitude>16f){result.Fail("Move closer to the cabinet.");return true;}
            RefreshContacts();
            if(migrationFailure!=null)result.AppendStateMessage(migrationFailure);
            long actorId=actor.ReferenceId;
            if(!cutting&&attack.IsDestroy)
            {
                result.ActionMessage="Cancel wire selection";
                if(doAction&&GameManager.RunSimulation){pending.Remove(actorId);pendingUntil.Remove(actorId);Owner.NetworkUpdateFlags|=UpdateFlag;}
                return true;
            }
            if(cutting)
            {
                result.ActionMessage="Cut internal wire";
                int index=WireAt(attack.Position);
                if(index<0){result.Fail("Aim at an internal wire to cut it.");return true;}
                var refund=Prefab.Find<Item>("ItemCableCoil");
                if(refund==null){result.Fail("Cable coil prefab unavailable.");return true;}
                if(doAction&&GameManager.RunSimulation)
                {
                    int units=wires[index].CableUnits;
                    OnServer.CreateOrStack(refund,units,attack.Position,Quaternion.identity,attack.OtherHand);
                    wires.RemoveAt(index);pending.Remove(actorId);pendingUntil.Remove(actorId);Changed();
                }
                return true;
            }
            if(!TryContact(attack,out var target)){result.Fail("Choose a highlighted contact. Right click cancels; wire cutters remove a wire.");return true;}
            if(Occupied(target.End)>=target.End.Capacity){result.Fail("Contact occupied.");return true;}
            if(!pending.TryGetValue(actorId,out var selected))
            {
                result.ActionMessage="Select "+target.End;
                if(doAction&&GameManager.RunSimulation){pending[actorId]=target.End;pendingUntil[actorId]=Time.unscaledTime+60;Owner.NetworkUpdateFlags|=UpdateFlag;}
                return true;
            }
            if(selected.Equals(target.End))
            {
                result.ActionMessage="Cancel wire selection";
                if(doAction&&GameManager.RunSimulation){pending.Remove(actorId);pendingUntil.Remove(actorId);Owner.NetworkUpdateFlags|=UpdateFlag;}
                return true;
            }
            if(!contacts.ContainsKey(selected)){result.Fail("Selected contact no longer exists. Select it again.");if(doAction&&GameManager.RunSimulation){pending.Remove(actorId);Owner.NetworkUpdateFlags|=UpdateFlag;}return true;}
            if(!WireCircuit.CanConnect(selected,target.End,wires,Breakers.Select(b=>b.ReferenceId),out var reason)){result.Fail(reason);return true;}
            if(wires.Count>=64){result.Fail("Cabinet wire capacity reached.");return true;}
            if(coil.Quantity<1){result.Fail("One cable coil unit is required.");return true;}
            var from=selected.IsSource?selected:target.End;var to=selected.IsSource?target.End:selected;
            if(routeRevision!=revision||!from.Equals(routeFrom)||!to.Equals(routeTo))
            {routeFrom=from;routeTo=to;routeRevision=revision;route=MakeRoute(from,to,out routeSlot,out routeFailure);}
            result.ActionMessage="Wire "+from+" -> "+to;
            if(route==null){result.Fail(routeFailure??"No clear route. Move a wire or a breaker first.");return true;}
            if(!doAction)ShowPreview(route);
            if(doAction&&GameManager.RunSimulation)
            {
                if(coil.RemoveQuantity(1)!=1){result.Fail("Cable coil is empty.");return true;}
                wires.Add(new CabinetWireSaveData{From=from,To=to,InputSlot=routeSlot,RouteVersion=CurrentRouteVersion,CableUnits=1,Points=Flatten(route)});
                pending.Remove(actorId);pendingUntil.Remove(actorId);Changed();
            }
            return true;
        }
        private int WireAt(Vector3 world,float radius=.012f)
        {
            var p=Point(Shell.InverseTransformPoint(world));float best=radius*radius;int found=-1;
            for(int i=0;i<wires.Count;i++){var path=Expand(wires[i].Points);for(int j=1;j<path.Length;j++){float distance=WireRouting.SegmentDistanceSquared(p,p,path[j-1],path[j]);if(distance<best){best=distance;found=i;}}}return found;
        }
        private WirePoint[] MakeRoute(CabinetWireEnd from,CabinetWireEnd to,out int slot,out string failure)
        {
            var used=new HashSet<int>(wires.Where(w=>w.From.Equals(from)).Select(w=>w.InputSlot));
            var candidates=Enumerable.Range(0,16).Where(i=>!used.Contains(i)).OrderBy(i=>i==0?0:((contacts[to].Exit.x<=0)==(i%2==1)?i:100+i));
            if(from.Owner!=0)candidates=Enumerable.Repeat(0,1).OrderBy(i=>i);
            failure=null;slot=0;
            foreach(var plane in new[]{WireRouting.Plane,.08135f,.09735f,.11335f})
            foreach(var candidate in candidates)
            {
                var found=MakeRouteSlot(from,to,candidate,plane,out failure);
                if(found!=null){slot=candidate;return found;}
            }
            return null;
        }
        private WirePoint[] MakeRouteSlot(CabinetWireEnd from,CabinetWireEnd to,int slot,float plane,out string failure)
        {
            failure=null;var a=contacts[from];var b=contacts[to];
            bool joint=from.Owner==0&&from.Contact==0;
            float fan=slot==0?0:((slot+1)/2)*.008f*(slot%2==1?1:-1);
            var start=new WirePoint(a.Exit.x+(joint?fan:0),a.Exit.y,plane);var end=new WirePoint(b.Exit.x,b.Exit.y,plane);
            var blocks=contacts.Values.Select(c=>c.Bounds).Concat(railObstacles).Concat(moduleReservations).Distinct().ToList();
            var occupied=wires.Select(w=>Expand(w.Points)).ToList();
            var middle=WireRouting.Find(start,end,blocks,occupied,joint,3);
            if(middle==null){failure="No clear route around devices and installed wires.";return null;}
            var path=new List<WirePoint>(WireContactLayout.EntryLead(Point(a.Position),start));
            path.AddRange(middle.Skip(1));path.AddRange(WireContactLayout.EntryLead(Point(b.Position),end).Reverse().Skip(1));
            // Check contact leads too; the router only controls the central part.
            var leadReservations=WireModuleSpace.ForLead(moduleReservations,from.Owner==0?(WireRect?)null:a.Bounds,to.Owner==0?(WireRect?)null:b.Bounds);
            var exceptOwn=contacts.Values.Where(c=>!c.End.Equals(from)&&!c.End.Equals(to)&&
                    !(c.End.Owner!=0&&(c.End.Owner==from.Owner||c.End.Owner==to.Owner))).Select(c=>c.Bounds).Concat(railObstacles).Concat(leadReservations).Distinct().ToList();
            for(int i=1;i<path.Count;i++)
            {
                if(!WireRouting.Clear(path[i-1],path[i],exceptOwn,occupied,joint)){failure="A contact lead is blocked by another wire or device.";return null;}
            }
            var result=path.Where((p,i)=>i==0||(p-path[i-1]).Squared>1e-12f).ToArray();
            result=WireTube.Clean(result,(p,q)=>WireRouting.Clear(p,q,exceptOwn,occupied,joint));
            if(result.Length>512){failure="The route is too complex. Move a wire or device first.";return null;}
            if(WireRouting.SelfIntersects(result)){failure="The route would intersect its own contact lead.";return null;}
            // Store the rounded centreline itself: preview, hit testing, saves and
            // subsequent wire clearance all use exactly the rendered route.
            foreach(float cut in new[]{.008f,.006f,.004f})
            {
                var rounded=WireTube.Round(result,cut);
                if(rounded.Length>512||WireRouting.SelfIntersects(rounded))continue;
                bool clear=true;
                for(int i=1;i<rounded.Length;i++)if(!WireRouting.Clear(rounded[i-1],rounded[i],exceptOwn,occupied,joint)){clear=false;break;}
                if(clear)return rounded;
            }
            return result;
        }
        internal bool WouldBlockModule(PlacementBoard board,Grid3 position,int width=1)
        {
            if(Shell==null)return false;
            var c=Shell.InverseTransformPoint(board.GridToWorld(position));
            var first=WireModuleSpace.At(c.x,c.y);var last=WireModuleSpace.At(c.x+(width-1)*DinLayout.SlotPitch,c.y);
            var r=new WireRect(first.Left,last.Right,first.Bottom,first.Top);
            return wires.Any(w=>{var p=Expand(w.Points);for(int i=1;i<p.Length;i++)if(WireRouting.SegmentHitsRect(p[i-1],p[i],r,WireRouting.Radius+.001f))return true;return false;});
        }
        internal bool WouldBlockRail(PlacementBoard board,Grid3 position)
        {
            if(Shell==null)return false;
            var center=Shell.InverseTransformPoint(board.GridToWorld(position));
            var bounds=new WireRect(center.x-.162f,center.x+.162f,center.y-.0175f,center.y+.0175f);
            return wires.Any(w=>{var path=Expand(w.Points);for(int i=1;i<path.Length;i++)if(WireRouting.SegmentHitsRect(path[i-1],path[i],bounds,WireRouting.Radius+.001f))return true;return false;});
        }
        private void RerouteLegacy()
        {
            needsReroute=false;var backup=wires.ToArray();wires.Clear();
            foreach(var old in backup.OrderBy(w=>w.From.Owner==0?0:1))
            {
                var path=MakeRoute(old.From,old.To,out var slot,out var failure);
                if(path==null)
                {
                    wires.Clear();wires.AddRange(backup);migrationFailure="Existing route needs manual rewiring: "+failure;
                    Debug.LogWarning("[Modular Switchboards] "+migrationFailure+" Connections and coil quantities preserved.");return;
                }
                wires.Add(new CabinetWireSaveData{From=old.From,To=old.To,InputSlot=slot,RouteVersion=CurrentRouteVersion,CableUnits=old.CableUnits,ColorIndex=old.ColorIndex,Points=Flatten(path)});
            }
            migrationFailure=null;Changed();
            Debug.Log("[Modular Switchboards] Existing wiring rerouted around reserved future module spaces without changing connections or coil quantities.");
        }
        private void HidePreview(){if(preview!=null)preview.SetActive(false);}
        private void ShowPreview(WirePoint[] path)
        {
            if(GameManager.IsBatchMode||Shell==null)return;
            if(preview==null)
            {
                preview=new GameObject("WireRoutePreview"){layer=Owner.gameObject.layer};preview.transform.SetParent(Shell,false);
                preview.AddComponent<MeshFilter>();var renderer=preview.AddComponent<MeshRenderer>();renderer.sharedMaterial=CabinetGeometry.Materials[3];Color(renderer,ColorType.Yellow);
            }
            if(!ReferenceEquals(previewPath,path))
            {
                var filter=preview.GetComponent<MeshFilter>();if(filter.sharedMesh!=null)Destroy(filter.sharedMesh);
                filter.sharedMesh=WireMesh.Build(path);previewPath=path;
            }
            previewFrame=Time.frameCount;preview.SetActive(Owner.IsOpen);
        }
        internal void RefundAndRemoveBreaker(long id,Vector3 position,Slot destination)
        {
            if(!GameManager.RunSimulation)return;
            int units=wires.Where(w=>w.From.Owner==id||w.To.Owner==id).Sum(w=>w.CableUnits);
            if(units>0)
            {
                var prefab=Prefab.Find<Item>("ItemCableCoil");
                if(prefab==null)throw new InvalidOperationException("Cable coil prefab unavailable during module demolition");
                OnServer.CreateOrStack(prefab,units,position,Quaternion.identity,destination);
            }
            RemoveBreaker(id);
        }
        internal void RemoveBreaker(long id)
        {
            if(wires.RemoveAll(w=>w.From.Owner==id||w.To.Owner==id)>0)Changed();
            foreach(var actor in pending.Where(p=>p.Value.Owner==id).Select(p=>p.Key).ToArray()){pending.Remove(actor);pendingUntil.Remove(actor);Owner.NetworkUpdateFlags|=UpdateFlag;}
            topology=null;
        }
        internal static float[] Flatten(IList<WirePoint> points){var result=new float[points.Count*3];for(int i=0;i<points.Count;i++){result[i*3]=points[i].X;result[i*3+1]=points[i].Y;result[i*3+2]=points[i].Z;}return result;}
        internal static WirePoint[] Expand(float[] values)
        {if(values==null||values.Length%3!=0)return new WirePoint[0];var result=new WirePoint[values.Length/3];for(int i=0;i<result.Length;i++)result[i]=new WirePoint(values[i*3],values[i*3+1],values[i*3+2]);return result;}
        internal CabinetWireSaveData[] Save()=>wires.ToArray();
        internal void Load(IEnumerable<CabinetWireSaveData> saved)
        {
            wires.Clear();pending.Clear();pendingUntil.Clear();
            if(saved!=null)foreach(var w in saved.Take(64))
                if(Valid(w)&&WireCircuit.CanConnect(w.From,w.To,wires,wires.SelectMany(x=>new[]{x.From.Owner,x.To.Owner}).Concat(new[]{w.From.Owner,w.To.Owner}).Where(id=>id!=0).Distinct(),out _,allowLegacyBypass:true))wires.Add(w);
            needsReroute=GameManager.RunSimulation&&wires.Any(w=>w.RouteVersion<CurrentRouteVersion);
            topology=null;revision++;routeRevision=-1;rebuild=true;
        }
        private static bool Valid(CabinetWireSaveData w)=>w!=null&&ValidEnd(w.From)&&ValidEnd(w.To)&&w.From.IsSource&&!w.To.IsSource&&w.Points!=null&&w.Points.Length>=6&&w.Points.Length<=1536&&w.Points.Length%3==0&&w.CableUnits==1&&w.RouteVersion>=0&&w.RouteVersion<=CurrentRouteVersion&&w.InputSlot>=0&&w.InputSlot<16&&
            Expand(w.Points).All(p=>!float.IsNaN(p.X)&&!float.IsInfinity(p.X)&&!float.IsNaN(p.Y)&&!float.IsInfinity(p.Y)&&!float.IsNaN(p.Z)&&!float.IsInfinity(p.Z)&&Math.Abs(p.X)<=.18f&&Math.Abs(p.Y)<=.24f&&p.Z>=0&&p.Z<=.15f);
        private static bool ValidEnd(CabinetWireEnd e)=>e!=null&&e.Owner>=0&&e.Contact>=0&&e.Contact<(e.Owner==0?3:2);
        internal void Write(RocketBinaryWriter writer)
        {
            writer.WriteInt32(-2);writer.WriteInt32(wires.Count);foreach(var w in wires){WriteEnd(writer,w.From);WriteEnd(writer,w.To);writer.WriteInt32(w.InputSlot);writer.WriteInt32(w.RouteVersion);writer.WriteInt32(w.ColorIndex);writer.WriteInt32(w.Points.Length);foreach(var p in w.Points)writer.WriteSingle(p);}
            writer.WriteInt32(pending.Count);foreach(var p in pending){writer.WriteInt64(p.Key);WriteEnd(writer,p.Value);}
        }
        internal void Read(RocketBinaryReader reader)
        {
            int header=reader.ReadInt32();bool colored=header==-2;int count=colored?reader.ReadInt32():header;if(count<0||count>64)throw new InvalidOperationException("Invalid cabinet wire count.");var loaded=new List<CabinetWireSaveData>();
            for(int i=0;i<count;i++){var w=new CabinetWireSaveData{From=ReadEnd(reader),To=ReadEnd(reader),InputSlot=reader.ReadInt32(),RouteVersion=reader.ReadInt32()};if(colored)w.ColorIndex=reader.ReadInt32();int n=reader.ReadInt32();if(n<6||n>1536||n%3!=0)throw new InvalidOperationException("Invalid cabinet wire path.");w.Points=new float[n];for(int j=0;j<n;j++)w.Points[j]=reader.ReadSingle();loaded.Add(w);}Load(loaded);
            count=reader.ReadInt32();if(count<0||count>128)throw new InvalidOperationException("Invalid cabinet wire selection count.");for(int i=0;i<count;i++){long actor=reader.ReadInt64();var end=ReadEnd(reader);if(ValidEnd(end))pending[actor]=end;}
        }
        private static void WriteEnd(RocketBinaryWriter writer,CabinetWireEnd end){writer.WriteInt64(end.Owner);writer.WriteInt32(end.Contact);}
        private static CabinetWireEnd ReadEnd(RocketBinaryReader reader)=>new CabinetWireEnd(reader.ReadInt64(),reader.ReadInt32());
        private void Color(MeshRenderer renderer,ColorType color)
        {var block=new MaterialPropertyBlock();renderer.GetPropertyBlock(block);block.SetFloat(Thing.DiffuseIndexPropertyID,(int)color);block.SetColor(Thing.EMISSION_COLOR,UnityEngine.Color.black);renderer.SetPropertyBlock(block);}
        private void Register(Collider c){colliders.Add(c);Thing._colliderLookup[c]=Owner;}
        private void ClearVisuals()
        {
            if(preview!=null){preview.SetActive(false);var mesh=preview.GetComponent<MeshFilter>()?.sharedMesh;if(mesh!=null)Destroy(mesh);Destroy(preview);preview=null;previewPath=null;}
            wireRenderers.Clear();
            foreach(var c in colliders)if(c!=null&&Thing._colliderLookup.TryGetValue(c,out var thing)&&thing==Owner)Thing._colliderLookup.Remove(c);colliders.Clear();
            foreach(var go in visuals)if(go!=null){go.SetActive(false);var filter=go.GetComponent<MeshFilter>();if(filter!=null&&go.name=="InternalWire")Destroy(filter.sharedMesh);Destroy(go);}visuals.Clear();
            if(visualRoot!=null){visualRoot.gameObject.SetActive(false);Destroy(visualRoot.gameObject);visualRoot=null;}
            foreach(var c in contacts.Values)c.Marker=null;
        }
        private void RebuildVisuals()
        {
            ClearVisuals();if(Shell==null||GameManager.IsBatchMode)return;
            visualRoot=new GameObject("InternalWiring").transform;visualRoot.SetParent(Shell,false);
            foreach(var wire in wires)
            {
                if(!contacts.ContainsKey(wire.From)||!contacts.ContainsKey(wire.To))continue;
                var path=Expand(wire.Points);if(path.Length<2)continue;
                var go=new GameObject("InternalWire"){layer=Owner.gameObject.layer};go.transform.SetParent(visualRoot,false);visuals.Add(go);
                go.AddComponent<MeshFilter>().sharedMesh=WireMesh.Build(path);
                var renderer=go.AddComponent<MeshRenderer>();renderer.sharedMaterial=CabinetGeometry.Materials[3];Color(renderer,WireColor(wire));wireRenderers[wire]=renderer;
                for(int i=1;i<path.Length;i++)
                {
                    var a=Vector(path[i-1]);var b=Vector(path[i]);var delta=b-a;if(delta.sqrMagnitude<1e-10f)continue;
                    var hit=new GameObject("WireHit"){layer=Owner.gameObject.layer};hit.transform.SetParent(go.transform,false);hit.transform.localPosition=(a+b)*.5f;hit.transform.localRotation=Quaternion.LookRotation(delta);
                    var box=hit.AddComponent<BoxCollider>();box.size=new Vector3(.006f,.006f,delta.magnitude);Register(box);hit.AddComponent<CabinetWirePaintTarget>().Wire=wire;
                }
            }
            foreach(var c in contacts.Values)
            {
                var go=new GameObject("WireContact"){layer=Owner.gameObject.layer};go.transform.SetParent(Shell,false);go.transform.localPosition=c.Aim+Vector3.forward*.004f;
                go.AddComponent<MeshFilter>().sharedMesh=WireMesh.Contact;
                go.AddComponent<MeshRenderer>().sharedMaterial=CabinetGeometry.Materials[3];var target=go.AddComponent<CabinetWireTarget>();target.End=c.End;
                var hit=go.AddComponent<SphereCollider>();hit.radius=.0075f;Register(hit);visuals.Add(go);c.Marker=go;go.SetActive(false);
            }
        }
        private void OnDestroy()=>ClearVisuals();
    }
    internal static class WireMesh
    {
        private static Mesh contact;
        internal static Mesh Contact
        {
            get
            {
                if(contact!=null)return contact;
                var v=new[]{Vector3.right,Vector3.left,Vector3.up,Vector3.down,Vector3.forward,Vector3.back};
                contact=new Mesh{name="Switchboards.WireContact"};contact.vertices=v.Select(p=>p*.0045f).ToArray();
                contact.triangles=new[]{4,0,2,4,2,1,4,1,3,4,3,0,5,2,0,5,1,2,5,3,1,5,0,3};contact.RecalculateNormals();CabinetGeometry.ApplyNativeUv(contact);contact.RecalculateBounds();return contact;
            }
        }
        internal static Mesh Build(WirePoint[] path)
        {
            path=WireTube.Supports(path);
            var v=new List<Vector3>();var normals=new List<Vector3>();var triangles=new List<int>();const int sides=12;
            var right=new WirePoint();var tangent=new WirePoint();
            for(int i=0;i<path.Length;i++)
            {
                var p=CabinetWiring.Vector(path[i]);var ring=WireTube.Ring(path,i,sides,ref right,ref tangent);
                for(int k=0;k<sides;k++){var n=CabinetWiring.Vector(ring[k]);v.Add(p+n*WireRouting.Radius);normals.Add(n);}
                if(i>0)for(int k=0;k<sides;k++){int a=(i-1)*sides+k,b=(i-1)*sides+(k+1)%sides,c=i*sides+k,d=i*sides+(k+1)%sides;triangles.AddRange(new[]{a,b,c,b,d,c});}
            }
            // Small flat end caps are buried in their contacts.
            for(int k=1;k<sides-1;k++){triangles.AddRange(new[]{0,k+1,k});int n=(path.Length-1)*sides;triangles.AddRange(new[]{n,n+k,n+k+1});}
            var mesh=new Mesh{name="Switchboards.InternalWire"};mesh.SetVertices(v);mesh.SetNormals(normals);mesh.SetTriangles(triangles,0);CabinetGeometry.ApplyNativeUv(mesh);mesh.RecalculateBounds();return mesh;
        }
    }
}
