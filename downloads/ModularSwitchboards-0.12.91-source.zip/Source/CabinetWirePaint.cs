using Assets.Scripts;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Items;
using Assets.Scripts.Objects.Motherboards;
using UnityEngine;
namespace ModularSwitchboards
{
    public sealed partial class CabinetWiring
    {
        private static ColorType WireColor(CabinetWireSaveData wire)
            =>GameManager.IsValidColor(wire.ColorIndex)?(ColorType)wire.ColorIndex:ColorType.Red;
        private bool TryPaintWire(Attack attack,ISprayer sprayer,bool doAction,out Thing.DelayedActionInstance result)
        {
            result=null;
            if(attack.DestinationThing!=Owner||!ContainsInteractionPoint(attack.Position))return false;
            CabinetWireSaveData wire;
            if(attack.TargetCollider!=null)
            {
                var target=attack.TargetCollider.GetComponent<CabinetWirePaintTarget>();
                if(target==null||!wires.Contains(target.Wire))return false;
                wire=target.Wire;
            }
            else
            {
                // Native AttackWith messages carry a world hit position, not a collider.
                int index=WireAt(attack.Position,.0045f);if(index<0)return false;
                wire=wires[index];
            }
            result=new Thing.DelayedActionInstance{Duration=sprayer.TimeToUse(),ActionMessage="Paint internal wire",ActionSoundHash=sprayer.ConstructingSoundHash,ActionCompleteSoundHash=attack.SourceItem is Item item?item.FinishedConstructingSoundHash:-1};
            if(Owner.IsCursor||!Owner.IsStructureCompleted||!Owner.IsOpen){result.Fail("Open the completed cabinet first.");return true;}
            var actor=attack.SourceItem.RootParentHuman;
            if(actor==null||(actor.Transform.position-Owner.Transform.position).sqrMagnitude>16f){result.Fail("Move closer to the cabinet.");return true;}
            if(attack.IsDestroy||attack.IsCopy){result.Fail("Use primary action to paint this wire.");return true;}
            if(attack.SourceItem is Tool tool&&!tool.OnOff){result.Fail("Turn the spray gun on first.");return true;}
            var material=sprayer.GetPaintMaterial();
            if(material==null||sprayer.IsEmpty){result.Fail("Not enough spray paint.");return true;}
            var swatch=GameManager.GetColorSwatch(material);
            if(swatch==null||!GameManager.IsValidColor(swatch.Index)){result.Fail("Unsupported paint color.");return true;}
            if((int)WireColor(wire)==swatch.Index){result.Fail("Wire already has this color.");return true;}
            if(doAction&&GameManager.RunSimulation)
            {
                if(!sprayer.OnUseItem(sprayer.GetUseAmount(),Owner)){result.Fail("Could not use spray paint.");return true;}
                wire.ColorIndex=swatch.Index;
                if(wireRenderers.TryGetValue(wire,out var renderer)&&renderer!=null)Color(renderer,WireColor(wire));
                Owner.NetworkUpdateFlags|=UpdateFlag;
            }
            return true;
        }
    }
}
