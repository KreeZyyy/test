using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using Assets.Scripts;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Items;
using Assets.Scripts.Objects.Motherboards;
using ModularSwitchboards;
namespace UnityEngine{
 public struct Vector3{public float x,y,z;public Vector3(float a,float b,float c){x=a;y=b;z=c;}public float sqrMagnitude=>x*x+y*y+z*z;public static Vector3 operator -(Vector3 a,Vector3 b)=>new(a.x-b.x,a.y-b.y,a.z-b.z);}
 public class Transform{public Vector3 position;public Vector3 InverseTransformPoint(Vector3 p)=>p;}
 public class Material{public int Index;}
 public class MeshRenderer{public int Index;}
 public class Collider{public CabinetWirePaintTarget Target;public T GetComponent<T>()where T:class=>Target as T;}
}
namespace Assets.Scripts{
 public static class GameManager{public static bool RunSimulation=true;public static bool IsValidColor(int i)=>i>=0&&i<=16;public static ColorSwatch GetColorSwatch(Material m)=>m==null?null:new(){Index=m.Index};}
 public class ColorSwatch{public int Index;}
}
namespace Assets.Scripts.Objects.Motherboards{public enum ColorType:byte{Red=5,Blue=7,Green=8}}
namespace Assets.Scripts.Objects{
 public class Thing{public Transform Transform=new();public sealed class DelayedActionInstance{public float Duration;public string ActionMessage;public int ActionSoundHash,ActionCompleteSoundHash;public bool IsDisabled;public DelayedActionInstance Fail(string message){IsDisabled=true;return this;}}}
 public class DynamicThing:Thing{public Thing RootParentHuman=new Thing();}
 public class Item:DynamicThing{public int FinishedConstructingSoundHash=>20;}
 public class Tool:Item{public bool OnOff=true;}
 public struct Attack{public Thing DestinationThing;public DynamicThing SourceItem;public Collider TargetCollider;public Vector3 Position;public bool IsDestroy,IsCopy;}
}
namespace Assets.Scripts.Objects.Items{
 public interface ISprayer{float TimeToUse();int ConstructingSoundHash{get;}Material GetPaintMaterial();bool IsEmpty{get;}bool OnUseItem(float amount,Thing target);float GetUseAmount();}
 public class FakeSpray:Tool,ISprayer{public int Color=7,Used;public bool Empty,FailUse;public Thing UsedOn;public float TimeToUse()=>.5f;public int ConstructingSoundHash=>10;public Material GetPaintMaterial()=>new(){Index=Color};public bool IsEmpty=>Empty;public bool OnUseItem(float amount,Thing target){if(FailUse)return false;Used++;UsedOn=target;return true;}public float GetUseAmount()=>1;}
}
namespace ModularSwitchboards{
 public class SwitchboardCabinet:Thing{public bool IsOpen=true,IsStructureCompleted=true,IsCursor;public ushort NetworkUpdateFlags;public int ColorIndex=3;}
 public class CabinetWirePaintTarget{public CabinetWireSaveData Wire;}
 public sealed partial class CabinetWiring{
  internal SwitchboardCabinet Owner=new();internal Transform Shell=new();internal List<CabinetWireSaveData> wires=new();internal Dictionary<CabinetWireSaveData,MeshRenderer> wireRenderers=new();internal const ushort UpdateFlag=32768;
  internal bool Paint(Attack a,ISprayer s,bool action,out Thing.DelayedActionInstance result)=>TryPaintWire(a,s,action,out result);
  internal static ColorType ReadColor(CabinetWireSaveData wire)=>WireColor(wire);
  private static WirePoint Point(Vector3 p)=>new(p.x,p.y,p.z);
  private static WirePoint[] Expand(float[] p)=>Enumerable.Range(0,p.Length/3).Select(i=>new WirePoint(p[3*i],p[3*i+1],p[3*i+2])).ToArray();
  private bool ContainsInteractionPoint(Vector3 p)=>Shell!=null&&Math.Abs(p.x)<.19f&&Math.Abs(p.y)<.24f&&p.z>=0&&p.z<.16f;
  private void Color(MeshRenderer r,ColorType c){r.Index=(int)c;}
 }
}
class Program{
 static void Check(bool v,string m){if(!v)throw new Exception(m);}
 static void Main(){
 var wiring=new CabinetWiring();var first=new CabinetWireSaveData{Points=new[]{0f,.1f,.05f,.1f,.1f,.05f}};var second=new CabinetWireSaveData{Points=new[]{0f,.15f,.05f,.1f,.15f,.05f}};wiring.wires.AddRange(new[]{first,second});wiring.wireRenderers[first]=new();wiring.wireRenderers[second]=new();
 var spray=new FakeSpray();var attack=new Attack{DestinationThing=wiring.Owner,SourceItem=spray,Position=new(.05f,.1f,.0524f),TargetCollider=new(){Target=new(){Wire=first}}};
 Check(wiring.Paint(attack,spray,false,out var preview)&&!preview.IsDisabled&&spray.Used==0&&first.ColorIndex==-1,"Preview mutated paint");
 GameManager.RunSimulation=false;wiring.Paint(attack,spray,true,out _);Check(spray.Used==0&&first.ColorIndex==-1,"Client consumed paint");GameManager.RunSimulation=true;
 wiring.Paint(attack,spray,true,out var painted);Check(!painted.IsDisabled&&spray.Used==1&&first.ColorIndex==7&&second.ColorIndex==-1&&wiring.Owner.ColorIndex==3&&spray.UsedOn==wiring.Owner&&wiring.Owner.NetworkUpdateFlags==32768&&wiring.wireRenderers[first].Index==7,"Single-wire paint altered other surfaces or missed replication");
 wiring.Paint(attack,spray,true,out var same);Check(same.IsDisabled&&spray.Used==1,"Same color consumed paint");
 spray.Color=8;spray.Empty=true;wiring.Paint(attack,spray,true,out var empty);Check(empty.IsDisabled&&first.ColorIndex==7&&spray.Used==1,"Empty spray changed wire");spray.Empty=false;
 spray.OnOff=false;wiring.Paint(attack,spray,true,out var off);Check(off.IsDisabled&&first.ColorIndex==7,"Off spray gun changed wire");spray.OnOff=true;
 spray.FailUse=true;wiring.Paint(attack,spray,true,out var failed);Check(failed.IsDisabled&&first.ColorIndex==7,"Failed consumption changed wire");spray.FailUse=false;
 wiring.Owner.IsOpen=false;wiring.Paint(attack,spray,true,out var closed);Check(closed.IsDisabled&&spray.Used==1,"Closed cabinet accepted paint");wiring.Owner.IsOpen=true;
 attack.TargetCollider=null;attack.Position=new(.05f,.15f,.0524f);wiring.Paint(attack,spray,true,out var server);Check(!server.IsDisabled&&second.ColorIndex==8&&first.ColorIndex==7&&spray.Used==2,"Server position lookup painted wrong wire");
 attack.Position=new(.05f,.12f,.05f);Check(!wiring.Paint(attack,spray,true,out _)&&spray.Used==2,"Miss painted a nearby wire");
 attack.TargetCollider=new();attack.Position=new(.05f,.15f,.0524f);Check(!wiring.Paint(attack,spray,true,out _),"Non-wire collider intercepted normal painting");
 second.ColorIndex=int.MaxValue;Check(CabinetWiring.ReadColor(second)==ColorType.Red,"Invalid saved color not safely red");
 Console.WriteLine("Production wire paint and hit lookup passed: preview/client no mutation, one wire only, cabinet color unchanged, paint consumed once, same/empty/off/failure/closed guards, server position lookup, misses, normal surface fallback and invalid color fallback.");
 }
}
