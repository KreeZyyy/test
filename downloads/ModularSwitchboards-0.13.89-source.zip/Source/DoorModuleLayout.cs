using System;
using System.Collections.Generic;
using System.Linq;
namespace ModularSwitchboards
{
    internal static class DoorModuleLayout
    {
        internal const int BridgePositions=18;
        internal const float GridOffsetY=-.025f;
        // Snap geometrically first; occupancy must never move the selection.
        internal static int SnapSlot(int value,int min,int max)=>Math.Max(min,Math.Min(max,(int)Math.Round(value/10d,MidpointRounding.ToEven)*10));
        internal const float Pitch=.10f,Spacing=.024f;
        internal static bool Fits(int x,int y,int z,int rotation)=>x%10==0&&y%10==0&&Math.Abs(x)<=10&&Math.Abs(y)<=10&&z==0&&rotation==0;
        internal static WireRect HarnessWindow=>new WireRect(-.193f,-.164f,-.220f,.220f);
        internal static WireRect HarnessWindowAt(float y)=>new WireRect(HarnessWindow.Left,HarnessWindow.Right,y-.006f,y+.006f);
        internal static WireRect[] Reservations()=>Enumerable.Range(-1,3).SelectMany(x=>Enumerable.Range(-1,3).Select(y=>new WireRect(x*Pitch-.019f,x*Pitch+.019f,y*Pitch+GridOffsetY-.034f,y*Pitch+GridOffsetY+.034f))).ToArray();
        internal static WireRect[] Reservations(string name)=>Enumerable.Range(-1,3).SelectMany(x=>Enumerable.Range(CabinetShape.MinDoorY(name)/10,2-CabinetShape.MinDoorY(name)/10).Select(y=>new WireRect(x*Pitch-.019f,x*Pitch+.019f,y*Pitch+GridOffsetY-.034f,y*Pitch+GridOffsetY+.034f))).ToArray();
        internal static bool BridgeFits(int x,int y,int z,int rotation)=>x==0&&y%10==0&&y>=-90&&y<=80&&z==0&&rotation==0;
        internal static IEnumerable<CabinetWireSaveData> Through(IEnumerable<CabinetWireSaveData> wires,IEnumerable<long> passages)
            =>WireCircuit.Through(wires,passages);
        internal static class DoorFlexGeometry
        {
            internal static WirePoint[] AroundFrame(WirePoint start,WirePoint safe,WirePoint end,WirePoint approach)
            {
                var first=Build(start,start+new WirePoint(.035f,0,.05f),safe-new WirePoint(.015f,0,.03f),safe);
                var second=Build(safe,safe+new WirePoint(.015f,0,.03f),end+approach,end);
                return first.Concat(second.Skip(1)).ToArray();
            }
            internal static WirePoint[] Build(WirePoint a,WirePoint b,WirePoint c,WirePoint d)
            {
                var path=new WirePoint[25];
                for(int i=0;i<path.Length;i++){float t=i/(float)(path.Length-1),u=1-t;path[i]=a*(u*u*u)+b*(3*u*u*t)+c*(3*u*t*t)+d*(t*t*t);}
                return path;
            }
        }
        internal static bool Energized(long led,IEnumerable<CabinetWireSaveData> wires,IEnumerable<long> closed,bool inputLive,IEnumerable<long> liveBatteries)
        {
            var target=new CabinetWireEnd(led,0);var paths=wires.ToArray();var ids=closed.ToArray();
            return inputLive&&WireCircuit.Reachable(new CabinetWireEnd(0,0),target,paths,ids)||
                liveBatteries.Any(id=>WireCircuit.Reachable(new CabinetWireEnd(id,1),target,paths,ids));
        }
    }
}
