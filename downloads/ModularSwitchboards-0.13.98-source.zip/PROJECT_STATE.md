# Current build: 0.13.98

DIN Smart Module is a native LogicDisplay + ICircuitHolder, four DIN positions/cost4, native LED glyph rendering and transplanted Air Conditioner IC10 socket. Single upper power/data IN only; no OUT or overload protection. SmartCircuit selects the Input or common feeder/output network, never joins separate data networks. Native device registration lets the selected branch computer IC motherboard discover DIN Smart Module. db addresses the display-owning module; ID/batch reads scoped to selected native network. No physical d0-d5 selectors yet.

Source models are read from native runtime SourcePrefabs. Original uploaded Diagnostics dumps/decompiled reference live outside this package. Native socket and occupant preserve original pose/materials and move together onto fascia. Body paint is separate from native LED color/materials. Standard breaker geometry unchanged.

SmartModuleSaveData extends native LogicBaseSaveData; native base owns settings and inventory. Mount/editor/error added, old prototype mount accepted. Old Smart OUT wires are refunded, IN preserved. Seven save data types registered. Authoritative placement validates4slots before kit consumption; detached/authoring targeting/cover window/label occupancy include Smart.

See README for wiring and test program. Production DLL build + fixture checks complete; actual Unity glyph draw, IC10 seating, motherboard dropdown, multiplayer and game save/load pending user testing.
