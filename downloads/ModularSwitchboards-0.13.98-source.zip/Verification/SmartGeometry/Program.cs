using System;using System.IO;using System.Linq;using System.Collections.Generic;using System.Text.Json;using UnityEngine;using ModularSwitchboards;
static class Program {
 static int n;static void Check(bool ok,string why){n++;if(!ok)throw new Exception(why);}
 static Mesh Load(JsonElement part)=>new(){vertices=part.GetProperty("Vertices").EnumerateArray().Select(p=>new Vector3(p.GetProperty("x").GetSingle(),p.GetProperty("y").GetSingle(),p.GetProperty("z").GetSingle())).ToArray(),uv=part.GetProperty("Uv").EnumerateArray().Select(p=>new Vector2(p.GetProperty("x").GetSingle(),p.GetProperty("y").GetSingle())).ToArray(),groups=part.GetProperty("Parts").EnumerateArray().Select(p=>p.GetProperty("Triangles").EnumerateArray().Select(i=>i.GetInt32()).ToArray()).ToArray()};
 static void Main(string[] args){
 var source=new Mesh{vertices=new[]{new Vector3(-1,-1,0),new Vector3(1,-1,0),new Vector3(0,1,0)},uv=new[]{new Vector2(0,0),new Vector2(1,0),new Vector2(.5f,1)},groups=new[]{new[]{0,1,2},Array.Empty<int>()}};
 var clip=new Bounds(new(0,0,0),new(1,1,1));var crop=NativeMeshCrop.Read(source,new Matrix4x4(1),clip,"crop");
 Check(crop!=null&&crop.vertices.Length>0&&crop.groups.Length==2,"clipping lost polygon/submeshes");
 foreach(var p in crop.vertices)Check(Math.Abs(p.x)<=.500001&&Math.Abs(p.y)<=.500001,"clipped vertex escaped region");
 for(int i=0;i<crop.vertices.Length;i++){var p=crop.vertices[i];var uv=crop.uv[i];Check(Math.Abs(uv.x-(p.x+1)/2)<1e-6&&Math.Abs(uv.y-(p.y+1)/2)<1e-6,"cut UV was not interpolated");}
 Check(source.vertices.Length==3&&source.groups[0].SequenceEqual(new[]{0,1,2}),"source mesh modified");
 var mirror=NativeMeshCrop.Read(source,new Matrix4x4(-1),clip,"mirror");for(int t=0;t<mirror.groups[0].Length;t+=3){var ids=mirror.groups[0];var a=mirror.vertices[ids[t]];var b=mirror.vertices[ids[t+1]];var c=mirror.vertices[ids[t+2]];Check(Vector3.Cross(b-a,c-a).z>0,"mirrored winding reversed");}
 using var native=JsonDocument.Parse(File.ReadAllText(args[0]));var parts=native.RootElement.GetProperty("Meshes").EnumerateArray().ToArray();
 var body=Load(parts.Single(p=>p.GetProperty("Name").GetString()=="StructureConsoleLED5"));var screen=Load(parts.Single(p=>p.GetProperty("Name").GetString()=="Screen"));var center=screen.bounds.center;
 var bezel=NativeMeshCrop.Read(body,new Matrix4x4(1),new Bounds(new(center.x,center.y,center.z+.006f),new(.51f,.18f,.045f)),"native bezel");Check(bezel!=null,"actual native LED bezel empty");
 var nativeFace=new List<object>();var all=new List<Vector3>();
 foreach(var pair in new[]{(Name:"bezel",Mesh:bezel),(Name:"screen",Mesh:screen)}){
 var points=pair.Mesh.vertices.Select(v=>SmartModuleModel.DisplayCenter+(v-center)*SmartModuleModel.DisplayScale).ToArray();all.AddRange(points);
 Check(points.All(p=>p.z>.0736f-.0001f),"LED sits behind Smart fascia");
 Check(points.All(p=>p.x>=.028f&&p.x<=.1414f&&Math.Abs(p.y)<.035f),"LED overlaps chip region or casing edge");
 nativeFace.Add(new{name=pair.Name,vertices=points.Select(v=>new[]{v.x,v.y,v.z}),triangles=pair.Mesh.groups});
 }
 Check(all.Max(p=>p.x)-all.Min(p=>p.x)<.103f,"native LED frame wider than red area");
 Check(SmartModuleModel.ChipCenter.x+.020f<all.Min(p=>p.x),"chip and LED areas overlap");
 File.WriteAllText(args[1],JsonSerializer.Serialize(nativeFace));
 Console.WriteLine(n+" native Smart face checks passed: triangle/UV clipping, winding, source preservation, actual LED frame, fascia depth and left-display/right-chip separation. Socket seating uses native runtime Slot pose.");
 }
}
namespace UnityEngine {
 public struct Vector2 {public float x,y;public Vector2(float x,float y){this.x=x;this.y=y;}public static Vector2 operator +(Vector2 a,Vector2 b)=>new(a.x+b.x,a.y+b.y);public static Vector2 operator -(Vector2 a,Vector2 b)=>new(a.x-b.x,a.y-b.y);public static Vector2 operator *(Vector2 a,float b)=>new(a.x*b,a.y*b);}
 public struct Vector3 {public float x,y,z;public Vector3(float x,float y,float z){this.x=x;this.y=y;this.z=z;}public float this[int i]=>i==0?x:i==1?y:z;public float sqrMagnitude=>x*x+y*y+z*z;public static Vector3 operator +(Vector3 a,Vector3 b)=>new(a.x+b.x,a.y+b.y,a.z+b.z);public static Vector3 operator -(Vector3 a,Vector3 b)=>new(a.x-b.x,a.y-b.y,a.z-b.z);public static Vector3 operator *(Vector3 a,float b)=>new(a.x*b,a.y*b,a.z*b);public static Vector3 Cross(Vector3 a,Vector3 b)=>new(a.y*b.z-a.z*b.y,a.z*b.x-a.x*b.z,a.x*b.y-a.y*b.x);}
 public struct Bounds {public Vector3 center,size;public Bounds(Vector3 c,Vector3 s){center=c;size=s;}public Vector3 min=>center-size*.5f;public Vector3 max=>center+size*.5f;}
 public struct Matrix4x4 {float scale;public Matrix4x4(float x){scale=x;}public float determinant=>scale;public Vector3 MultiplyPoint3x4(Vector3 p)=>new(p.x*scale,p.y,p.z);}
 public class Mesh {public string name;public Rendering.IndexFormat indexFormat;public Vector3[] vertices;public Vector2[] uv;public int[][] groups;public int subMeshCount{get=>groups.Length;set=>groups=new int[value][];}public void SetVertices(List<Vector3> v){vertices=v.ToArray();}public void SetUVs(int i,List<Vector2> v){uv=v.ToArray();}public void SetTriangles(List<int> t,int i){groups[i]=t.ToArray();}public void RecalculateNormals(){}public void RecalculateTangents(){}public void RecalculateBounds(){}public Bounds bounds{get{var a=new Vector3(vertices.Min(p=>p.x),vertices.Min(p=>p.y),vertices.Min(p=>p.z));var b=new Vector3(vertices.Max(p=>p.x),vertices.Max(p=>p.y),vertices.Max(p=>p.z));return new((a+b)*.5f,b-a);}}}
}
namespace UnityEngine.Rendering {public enum IndexFormat {UInt32}}
namespace ModularSwitchboards {static class CabinetGeometry {public static void ReadNativeMesh(Mesh m,out Vector3[] p,out Vector2[] uv,out int[][] groups){p=m.vertices;uv=m.uv;groups=m.groups;}}}
