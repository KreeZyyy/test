using UnityEngine;namespace ModularSwitchboards{static class SmartModuleModel{        internal const float DisplayScale=.20f;
        internal static readonly Vector3 DisplayCenter=new Vector3(.085f,0,.077f);
        internal static readonly Vector3 ChipCenter=new Vector3(.007f,0,.077f);
}}