using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Serialization;
using Assets.Scripts;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Networking;
using Assets.Scripts.Networks;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Electrical;
using Assets.Scripts.Objects.Pipes;
using Assets.Scripts.Objects.Motherboards;
using Cysharp.Threading.Tasks;
using LibConstruct;
using UnityEngine;
namespace ModularSwitchboards
{
    public sealed class SmartModuleSaveData:LogicBaseSaveData
    {
        [XmlElement]public PlacementBoardStructureSaveData RailBoard;
        [XmlElement]public int CodeError;
        [XmlElement]public ulong LastEditor;
    }
    // The real native LED class owns all formatting, glyph rendering, logic
    // modes, colours, setting replication and native device identity.
    public sealed class SmartModule:LogicDisplay,IPlacementBoardStructure,ICircuitHolder
    {
        public PlacementBoard Board{get;set;}
        public PlacementBoard.BoardCell[] BoardCells{get;set;}
        public int ModuleWidth=>DinSmartLayout.Slots;
        public SwitchboardCabinet Cabinet=>(Board?.PrimaryHost as DinRail)?.Board?.PrimaryHost as SwitchboardCabinet;
        public ProgrammableChip Chip=>Slots.Count==1?Slots[0].Get() as ProgrammableChip:null;
        public ulong LastEditedBy{get;set;}
        internal Cable BoundCable;
        internal CableNetwork BoundNetwork;
        private float nextLink;
        private int codeError;
        private float nextExecute;
        public override void Awake(){base.Awake();BoardStructureHooks.Awake(this);}
        public override Grid3 GetLocalGrid()=>Board==null?default(Grid3):Board.WorldToGrid(transform.position);
        public override CanConstructInfo CanConstruct()
        {
            if(IsCursor){MountPlacement.AfterRaycast();MountBoardResolver.Resolve(CursorManager.Instance);}
            if(!(Board is DinModuleBoard board))return CanConstructInfo.InvalidPlacement("Aim at an available four-position span on a DIN rail.");
            var p=board.WorldToGrid(transform.position);
            if(IsCursor)
            {
                if(MountPlacement.TryLockedGrid(this,board,out var locked))p=locked;
                else p=new Grid3(DoorModuleLayout.SnapSlot(p.x,DinLayout.FirstModuleSlot*10,(DinLayout.FirstModuleSlot+((DinRail)board.PrimaryHost).ModuleCapacity-4)*10),0,0);
                PlacementBoard.CursorGrid=p;PlacementBoard.CursorRotation=0;transform.SetPositionAndRotation(board.GridToWorld(p),board.IndexToRotation(0));
            }
            return board.CanPlace(p,board.RotationToIndex(transform.rotation),4)?CanConstructInfo.ValidPlacement:CanConstructInfo.InvalidPlacement("Choose four free DIN positions.");
        }
        protected override CanConstructInfo CanDeconstruct()=>Cabinet!=null&&Cabinet.CanAccessModules&&Chip==null&&!Cabinet.Wiring.HasWires(ReferenceId)?CanConstructInfo.ValidPlacement:CanConstructInfo.InvalidPlacement("Open the cabinet, remove the IC10 and disconnect wires first.");
        public override void OnDeregistered(){SmartModuleNetwork.Unbind(this);base.OnDeregistered();if(Board!=null)BoardStructureHooks.OnDeregistered(this);}
        public override void OnDestroy(){SmartModuleNetwork.Unbind(this);base.OnDestroy();}
        public override void OnRegistered(Cell cell){base.OnRegistered(cell);}
        private void LateUpdate()
        {
            if(IsCursor)return;
            if(Cabinet==null){if(BoundNetwork!=null)SmartModuleNetwork.Unbind(this);return;}
            if(Time.unscaledTime>=nextLink){nextLink=Time.unscaledTime+.15f;SmartModuleNetwork.Refresh(this);}
            if(GameManager.RunSimulation&&Time.unscaledTime>=nextExecute){nextExecute=Time.unscaledTime+.5f;Execute();}
            foreach(var hit in BuildStates[0].Colliders)if(hit!=null)hit.enabled=Cabinet.IsOpen;
            if(Slots.Count==1&&Slots[0].Collider!=null)Slots[0].Collider.enabled=Cabinet.CanAccessModules;
        }
        public override void OnAddCableNetwork(CableNetwork network){}
        public override void OnRemoveCableNetwork(CableNetwork network){if(network==BoundNetwork)AssessPower(null,false);}
        public override bool PreventInteraction(out DelayedActionInstance failure,Interactable interactable,Interaction interaction)
        {
            if(interactable.Action==InteractableType.Slot1&&(Cabinet==null||!Cabinet.CanAccessModules))
            {failure=new DelayedActionInstance{Duration=0f}.Fail("Open the cabinet and remove the cover first.");return true;}
            return base.PreventInteraction(out failure,interactable,interaction);
        }
        public override DelayedActionInstance InteractWith(Interactable interactable,Interaction interaction,bool doAction=true)
        {
            if(interactable.Action==InteractableType.Slot1&&(Cabinet==null||!Cabinet.CanAccessModules))
                return new DelayedActionInstance{Duration=0f}.Fail("Open the cabinet and remove the cover first.");
            return base.InteractWith(interactable,interaction,doAction);
        }
        public override void OnChildEnterInventory(DynamicThing child){base.OnChildEnterInventory(child);if(GameManager.RunSimulation&&child is ProgrammableChip){Chip.Reset();ClearError();}}
        public override void OnChildExitInventory(DynamicThing child){base.OnChildExitInventory(child);if(GameManager.RunSimulation&&child is ProgrammableChip chip){chip.Reset();ClearError();}}
        public void ClearError()=>RaiseError(0);
        public void RaiseError(int state){codeError=state;if(GameManager.RunSimulation&&InteractError!=null)OnServer.Interact(InteractError,state==0?0:1);}
        public bool IsValidIndex(int index)=>index==int.MaxValue;
        public ILogicable GetLogicableFromIndex(int index,int networkIndex=int.MinValue)=>index==int.MaxValue?this:null;
        public ILogicable GetLogicableFromId(int id,int networkIndex=int.MinValue)
        {
            if(id==ReferenceId)return this;
            var device=Referencable.Find<Device>(id);
            return device!=null&&DataCableNetwork!=null&&DataCableNetwork.DataDeviceList.Contains(device)?networkIndex==int.MinValue?(ILogicable)device:device.GetNetwork(networkIndex):null;
        }
        public List<ILogicable> GetBatchOutput()=>DataCableNetwork==null?new List<ILogicable>():DataCableNetwork.DataDeviceList.OfType<ILogicable>().ToList();
        public List<LogicBinding> GetLogicBindings()=>new List<LogicBinding>{new LogicBinding("DEVICE")};
        public void SetDeviceLabel(int index,string label){}
        public void HasPut(){}
        public UniTask HaltAndCatchFire(){if(GameManager.RunSimulation)OnServer.Interact(InteractOnOff,0);return UniTask.CompletedTask;}
        public string GetSourceCode()=>Chip==null?"":Chip.GetSourceCode();
        public void SetSourceCode(string source){if(Chip!=null){Chip.SetSourceCode(source,this);Chip.SendUpdate();}}
        public void Execute(){if(GameManager.RunSimulation&&!IsCursor&&OnOff&&Powered&&GameManager.GameState==GameState.Running&&!WorldManager.IsGamePaused&&Chip!=null&&!Chip.CompilationError)Chip.Execute(128);}
        public override bool CanLogicRead(LogicType type)=>type==LogicType.LineNumber||base.CanLogicRead(type);
        public override bool CanLogicWrite(LogicType type)=>type==LogicType.LineNumber||base.CanLogicWrite(type);
        public override double GetLogicValue(LogicType type)=>type==LogicType.LineNumber?(Chip==null?0:Chip.LineNumber):base.GetLogicValue(type);
        public override void SetLogicValue(LogicType type,double value){if(type==LogicType.LineNumber){if(Chip!=null)Chip.LineNumber=(uint)value;}else base.SetLogicValue(type,value);}
        public override ThingSaveData SerializeSave(){ThingSaveData data=new SmartModuleSaveData();InitialiseSaveData(ref data);return data;}
        protected override void InitialiseSaveData(ref ThingSaveData data){base.InitialiseSaveData(ref data);if(data is SmartModuleSaveData save){if(Board!=null)save.RailBoard=BoardStructureHooks.SerializeSave(this);save.CodeError=codeError;save.LastEditor=LastEditedBy;}}
        public override void DeserializeSave(ThingSaveData data){base.DeserializeSave(data);if(data is SmartModuleSaveData save){codeError=save.CodeError;LastEditedBy=save.LastEditor;if(save.RailBoard!=null)BoardStructureHooks.DeserializeSave(this,save.RailBoard);}else if(data is DinBreakerSaveData old){OnOff=true;if(old.RailBoard!=null)BoardStructureHooks.DeserializeSave(this,old.RailBoard);}}
        public override void SerializeOnJoin(RocketBinaryWriter writer){base.SerializeOnJoin(writer);BoardStructureHooks.SerializeOnJoin(writer,this);writer.WriteInt32(codeError);}
        public override void DeserializeOnJoin(RocketBinaryReader reader){base.DeserializeOnJoin(reader);BoardStructureHooks.DeserializeOnJoin(reader,this);codeError=reader.ReadInt32();}
    }
}
