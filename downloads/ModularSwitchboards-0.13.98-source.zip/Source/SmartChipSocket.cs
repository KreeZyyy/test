using System;
using System.Linq;
using Assets.Scripts;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Electrical;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class SmartChipSocket
    {
        internal static void Install(SmartModule module,Vector3 target)
        {
            var air=WorldManager.Instance.SourcePrefabs.OfType<AirConditioner>().First(p=>p.PrefabName=="StructureAirConditioner");
            var slot=air.Slots[0];
            var pose=air.transform.worldToLocalMatrix*slot.Location.localToWorldMatrix;
            // The native chip's local up/forward establish the original seating pose.
            var chipSource=WorldManager.Instance.SourcePrefabs.OfType<ProgrammableChip>().First(p=>slot.SpecificTypePrefabHashes==null||slot.SpecificTypePrefabHashes.Length==0||slot.SpecificTypePrefabHashes.Contains(p.PrefabHash));
            Bounds? nativeBounds=null;
            foreach(var f in chipSource.GetComponentsInChildren<MeshFilter>(true))if(f.sharedMesh!=null)
            {var b=CabinetWallMount.TransformedBounds(f.sharedMesh.bounds,pose*chipSource.transform.worldToLocalMatrix*f.transform.localToWorldMatrix);if(nativeBounds.HasValue){var value=nativeBounds.Value;value.Encapsulate(b);nativeBounds=value;}else nativeBounds=b;}
            if(!nativeBounds.HasValue)throw new InvalidOperationException("Native IC10 seating bounds missing.");
            var chip=nativeBounds.Value;
            float fit=Mathf.Min(.035f/Mathf.Max(chip.size.x,.001f),.042f/Mathf.Max(chip.size.y,.001f));
            var centre=chip.center;
            var holder=new GameObject("NativeAirChipSocket"){layer=module.gameObject.layer};holder.transform.SetParent(module.transform,false);holder.transform.localPosition=target-centre*fit;holder.transform.localScale=Vector3.one*fit;
            var crop=chip;crop.Expand(new Vector3(chip.size.x*.30f,chip.size.y*.20f,chip.size.z+.020f));
            Bounds? socketBounds=null;int socketParts=0;
            foreach(var renderer in air.GetComponentsInChildren<MeshRenderer>(true))
            {
                if(renderer.name!=air.PrefabName)continue;var mesh=renderer.GetComponent<MeshFilter>()?.sharedMesh;if(mesh==null)continue;
                var selected=NativeMeshCrop.Read(mesh,air.transform.worldToLocalMatrix*renderer.transform.localToWorldMatrix,crop,"Smart.NativeAirIC10Socket");if(selected==null)continue;
                socketParts++;if(socketBounds.HasValue){var b=socketBounds.Value;b.Encapsulate(selected.bounds);socketBounds=b;}else socketBounds=selected.bounds;
                var part=new GameObject("OriginalSocketFrame"){layer=module.gameObject.layer};part.transform.SetParent(holder.transform,false);part.AddComponent<MeshFilter>().sharedMesh=selected;NativePortSurface.Capture(renderer,part.AddComponent<MeshRenderer>());
            }
            if(!socketBounds.HasValue)throw new InvalidOperationException("Original Air Conditioner IC10 socket frame is missing.");
            // Seat the original socket on the fascia, keeping its complete rear
            // above the casing. The chip and its native slot move as one assembly.
            float lift=Mathf.Max(0f,.0737f-(target.z+(socketBounds.Value.min.z-centre.z)*fit));
            target.z+=lift;holder.transform.localPosition=target-centre*fit;
            Debug.Log("[Modular Switchboards] Smart native IC10 socket: parts="+socketParts+" fit="+fit+" fascia lift="+lift);
            var location=new GameObject("NativeIC10Location"){layer=module.gameObject.layer};location.transform.SetParent(module.transform,false);location.transform.localPosition=target+(pose.MultiplyPoint3x4(Vector3.zero)-centre)*fit;location.transform.localRotation=pose.rotation;location.transform.localScale=pose.lossyScale*fit;
            // Hitbox lives directly in module space so its size is independent of chip scaling.
            var actionRoot=new GameObject("ChipInsertionHitbox"){layer=module.gameObject.layer};actionRoot.transform.SetParent(module.transform,false);actionRoot.transform.localPosition=target;
            var hit=actionRoot.AddComponent<BoxCollider>();hit.size=new Vector3(.040f,.047f,.012f);
            var action=new Interactable{Parent=module,Action=InteractableType.Slot1,Collider=hit,JoinInProgressSync=true,CanKeyInteract=true,KeyMap="PrimaryAction"};
            var copy=new Slot{Parent=module,StringKey=slot.StringKey,StringHash=slot.StringHash,Type=slot.Type,SpecificTypePrefabHashes=(int[])(slot.SpecificTypePrefabHashes??new int[0]).Clone(),Location=location.transform,RealWorldScale=slot.RealWorldScale,ScaleMultiplier=slot.ScaleMultiplier,HidesOccupant=false,OccupantCastsShadows=slot.OccupantCastsShadows,UseInternalAtmosphere=slot.UseInternalAtmosphere,IsSwappable=slot.IsSwappable,AllowDragging=slot.AllowDragging,IsInteractable=slot.IsInteractable,Size=slot.Size,Action=InteractableType.Slot1,Collider=hit,Interactable=action};
            module.Slots.Add(copy);module.Interactables.Add(action);module.BuildStates[0].Colliders.Add(hit);module.BuildStates[0].Interactables=module.Interactables;
        }
    }
}
