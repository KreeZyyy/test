using System;
using Assets.Scripts.Networks;
using Assets.Scripts.Objects.Electrical;
using Assets.Scripts.Objects.Pipes;
using HarmonyLib;
namespace ModularSwitchboards
{
    internal static class SmartModuleNetwork
    {
        private static readonly System.Reflection.PropertyInfo PowerCable=AccessTools.Property(typeof(Device),"PowerCable");
        private static readonly System.Reflection.PropertyInfo PowerCables=AccessTools.Property(typeof(Device),"PowerCables");
        private static readonly System.Reflection.PropertyInfo DataCables=AccessTools.Property(typeof(Device),"DataCables");
        internal static void Refresh(SmartModule module)
        {
            var cable=module.Cabinet?.Wiring.SmartCable(module);
            if(cable==module.BoundCable&&cable?.CableNetwork==module.BoundNetwork&&
                (module.BoundNetwork==null||module.BoundNetwork.GetDeviceRegistration(module)?.Contains(cable)==true))return;
            Unbind(module);if(cable==null||cable.CableNetwork==null)return;
            module.BoundCable=cable;module.BoundNetwork=cable.CableNetwork;
            module.DataCable=cable;PowerCable.SetValue(module,cable,null);
            PowerCables.SetValue(module,new[]{cable},null);DataCables.SetValue(module,new[]{cable},null);
            module.InputNetwork1=cable.CableNetwork;module.OutputNetwork1=null;
            cable.CableNetwork.AddDevice(cable,module);
        }
        internal static void Unbind(SmartModule module)
        {
            if(module.BoundNetwork!=null)module.BoundNetwork.RemoveDevice(module);
            module.BoundCable=null;module.BoundNetwork=null;module.DataCable=null;
            PowerCable.SetValue(module,null,null);PowerCables.SetValue(module,Array.Empty<Cable>(),null);DataCables.SetValue(module,Array.Empty<Cable>(),null);
            module.InputNetwork1=null;module.OutputNetwork1=null;
        }
    }
}
