using System;
using System.Collections.Generic;
using System.Linq;
using Assets.Scripts;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Electrical;
using Assets.Scripts.Objects.Motherboards;
using Assets.Scripts.UI;
using HarmonyLib;
using Rendering;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class SmartModuleModel
    {
        internal const float DisplayScale=.20f;
        internal static readonly Vector3 DisplayCenter=new Vector3(.085f,0,.077f);
        internal static readonly Vector3 ChipCenter=new Vector3(.007f,0,.077f);
        internal static void Install(SmartModule module,Transform storage)
        {
            SmartNativeReferences.Capture();
            var source=WorldManager.Instance.SourcePrefabs.OfType<LogicDisplay>().First(p=>p.PrefabName=="StructureConsoleLED5");
            var screenBounds=CabinetWallMount.TransformedBounds(source.ScreenMesh.GetComponent<MeshFilter>().sharedMesh.bounds,source.transform.worldToLocalMatrix*source.ScreenMesh.transform.localToWorldMatrix);
            var nativeBody=source.GetComponentsInChildren<MeshRenderer>(true).First(r=>r!=source.ScreenMesh&&r.GetComponent<MeshFilter>()?.sharedMesh!=null&&r.name==source.PrefabName);
            var region=new Bounds(new Vector3(screenBounds.center.x,screenBounds.center.y,screenBounds.center.z+.006f),new Vector3(.51f,.18f,.045f));
            var bezel=NativeMeshCrop.Read(nativeBody.GetComponent<MeshFilter>().sharedMesh,source.transform.worldToLocalMatrix*nativeBody.transform.localToWorldMatrix,region,"Smart.NativeLEDBezel");
            if(bezel==null)throw new InvalidOperationException("Native LED bezel extraction empty.");
            foreach(var hit in module.GetComponentsInChildren<Collider>(true))UnityEngine.Object.DestroyImmediate(hit);
            foreach(var renderer in module.GetComponentsInChildren<MeshRenderer>(true))if(renderer!=module.ScreenMesh){var filter=renderer.GetComponent<MeshFilter>();if(filter!=null)UnityEngine.Object.DestroyImmediate(filter);UnityEngine.Object.DestroyImmediate(renderer);}
            var children=new List<Transform>();foreach(Transform child in module.transform)children.Add(child);
            var display=new GameObject("OriginalDisplayMount"){layer=module.gameObject.layer};display.transform.SetParent(module.transform,false);
            foreach(var child in children)child.SetParent(display.transform,false);
            display.transform.localScale=Vector3.one*DisplayScale;
            display.transform.localPosition=DisplayCenter-screenBounds.center*DisplayScale;
            var bezelGo=new GameObject("NativeLEDBezel"){layer=module.gameObject.layer};bezelGo.transform.SetParent(display.transform,false);
            bezelGo.AddComponent<MeshFilter>().sharedMesh=bezel;
            NativePortSurface.Capture(nativeBody,bezelGo.AddComponent<MeshRenderer>());
            var model=new GameObject("DinBreakerModel"){layer=module.gameObject.layer};model.transform.SetParent(module.transform,false);model.transform.localScale=DinBreakerModel.VisualScale;
            var body=DinBreakerModel.Build(DinSmartLayout.Width,DinSmartLayout.CenterX,plain:true,inputOnly:true);
            model.AddComponent<MeshFilter>().sharedMesh=body;var bodyRenderer=model.AddComponent<MeshRenderer>();bodyRenderer.sharedMaterials=CabinetGeometry.Materials;
            var bodyHit=model.AddComponent<BoxCollider>();bodyHit.center=body.bounds.center;bodyHit.size=body.bounds.size;
            module.Renderers=new List<ThingRenderer>();module._staticColliders=new List<Collider>();module._dynamicColliders=new List<Collider>();module._selfColliders=new List<Collider>();
            module.BaseAnimator=null;module.OnOffButton=null;module.Slots=new List<Slot>();module.OpenEnds=new List<Connection>();module.UseCellPosition=false;
            module.StructureCollisionType=CollisionType.BlockCustom;module.SelectionDisplay=SelectionHighlightMethod.Bounds;module.CustomNavMeshFilter=null;
            module.CustomColor=GameManager.GetColorSwatch((int)ColorType.White);module.PaintableMaterial=module.CustomColor.Normal;module.MPBRenderers.Clear();
            module.UsedPower=source.UsedPower;module.InputNetwork1=null;module.OutputNetwork1=null;
            module.Interactables=module.Interactables.Where(i=>i.Action!=InteractableType.Slot1&&i.Action!=InteractableType.Open).ToList();
            foreach(var i in module.Interactables){i.Parent=module;i.Collider=null;i.Animator=null;i.FakeCollider=null;}
            var on=module.Interactables.FirstOrDefault(i=>i.Action==InteractableType.OnOff);if(on!=null)on.State=1;
            var powered=module.Interactables.FirstOrDefault(i=>i.Action==InteractableType.Powered);if(powered!=null)powered.State=0;
            var state=module.BuildStates[0];state.Visualizer=bodyRenderer;state.StateMeshes=new List<Mesh>();state.RendererInstance=null;state.Colliders=new List<Collider>{bodyHit};state.Interactables=module.Interactables;state.LinkedGameObjects=new List<GameObject>();state.RenderMode=BuildStateRenderMode.OnMyState;
            AccessTools.Field(typeof(BuildState),"initialDrawData").SetValue(state,new DrawData{mesh=null,materials=new Material[0]});
            SmartChipSocket.Install(module,ChipCenter);
            var scale=DinBreakerModel.VisualScale;module.Bounds=new Bounds(Vector3.Scale(body.bounds.center,scale),Vector3.Scale(body.bounds.size,scale));
            foreach(var renderer in module.GetComponentsInChildren<MeshRenderer>(true))
            {
                var filter=renderer.GetComponent<MeshFilter>();if(filter==null||filter.sharedMesh==null)continue;
                module.Bounds.Encapsulate(CabinetWallMount.TransformedBounds(filter.sharedMesh.bounds,module.transform.worldToLocalMatrix*renderer.transform.localToWorldMatrix));
            }

            module.GridBounds=new GridBounds(module);module.SurfaceArea=.064f;
            module.Thumbnail=CabinetIcons.Get("DinSmart");module.Thumbnails=new Sprite[0];state.Thumbnail=module.Thumbnail;
            var bp=new GameObject("SmartBlueprint"){layer=module.gameObject.layer};bp.transform.SetParent(storage,false);var mesh=ModelBlueprint.Build(module.transform);var filterBp=bp.AddComponent<MeshFilter>();filterBp.sharedMesh=mesh;var rendererBp=bp.AddComponent<MeshRenderer>();rendererBp.sharedMaterial=CabinetGeometry.Materials[4];var wire=bp.AddComponent<Wireframe>();wire.BlueprintTransform=bp.transform;wire.BlueprintBounds=mesh.bounds;wire.BlueprintMeshFilter=filterBp;wire.BlueprintRenderer=rendererBp;bp.AddComponent<CabinetBlueprint>();module.Blueprint=bp;module.BlueprintOrientVector=Vector3.zero;
        }
    }
}
