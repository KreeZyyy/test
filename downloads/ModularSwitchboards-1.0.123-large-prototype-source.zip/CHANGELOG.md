# Modular Switchboards 1.0.123 — standing Large prototype

Local test prototype, not yet tested in Unity. Not a Steam Workshop update.

- Standing on the floor, with native StructureStorageLocker dimensions read at startup. Own authored cabinet shell, interior and double doors; does not reuse the Locker storage model.
- Four longer DIN rows; standard modules keep their original size and pitch. Each row costs one Rail kit.
- One IN and three isolated OUT ports, all facing upwards in two rows of native cable-grid cells. No automatic connection to neighbouring cabinets or internal bridging.
- Doors open to 90 degrees. Both door control/label/bridge boards are preserved in save and multiplayer payloads.
- Prototype economy: 6 cabinet kits plus 10 Plastic Sheets; optional Large cover 4 cover kits. Empty cover returns kits, labelled cover retains its state.
- New F1 entry and four label rows; existing Small/Medium layouts and costs unchanged.
- For this first shape test the kit/F1 still uses the Medium thumbnail. Dedicated Large icons and detailed visual refinement remain pending.

Validation: full native-reference build with 0 warnings/errors; 168 layout/terminal/cover-save checks across nine dimension profiles, 78 direct cover checks, 94 cover-transfer checks, 25 door load/animation checks, 8005 cover-memory checks and 22 wiring-readiness checks passed. These use stubs/fixtures, not actual Unity playtesting.

Try on a test save with one active copy of the mod. Select Large from the Switchboard Kit. Check the floor snap, closed/open doors, all four DIN rows, roof connector/cable alignment and wall clearance, cover, save/load and refunds. Actual native Locker dimensions are logged during startup. If Large setup fails, existing variants are retained and the log names the Large error. Multiplayer is untested.

# Modular Switchboards 1.0.122 — restore cabinet door pose during load

Saved door positions now apply immediately during save/join restoration and registration, with first-physics-step initialization as a fallback. Small and both Medium door hinges retain their existing animation and physical colliders. This addresses a door initialization gap; whether it resolves reported player displacement near cabinets requires in-game verification.

Validation: 23 door load/physics/animation checks passed; native-reference build without warnings/errors.

# Modular Switchboards 1.0.121 — empty cover kit refunds

Removing a cover without live labels uses normal deconstruction and returns its cover kits (Small 1, Medium 2). Covers with labels remain portable Fitted Covers, preserving labels, openings and colour. Empty painted covers also return kits.

Validation: 94 cover-transfer checks passed; native-reference build without warnings/errors. Actual in-game refund verification remains pending.

# Modular Switchboards 1.0.120 — remaining kit economy and cover size costs

Smart Output now uses4 Smart kits (Net remains1). Door kit recipe:5 Iron +20 Copper; LEDs, round switches and individual bridges use1 kit, while TOTAL STOP and Main Switch use3. Label kit recipe:5 Silicon, with1 kit per label regardless of width. Cover kit recipe:20 Silicon; Small cover uses1 kit, Medium2.

Medium cover has a separate hidden native-cost prefab so LibConstruct consumes2 kits through its normal construction path. Mounting and server authority select the cabinet-size-matched prefab. All cabinet orientations/input-output variants use the corresponding Small/Medium cost. Existing fitted covers retain labels/color/openings and can be refitted without new kits. The standalone covers remain hidden from F1/creative listings; the kit entry describes both costs.

Validation: native-reference build without warnings/errors;74 direct cover/name/preview/client/cancellation/size/cost checks and70 actual cover-transfer checks passed. Other staged module behavior and accepted geometry remain unchanged. Actual Unity printer/consumption/refund/new-prefab/save-load/multiplayer verification remains pending.

# Modular Switchboards 1.0.119 — native rounded display outline and pocket surfaces

The unfinished Core display opening follows the actual original white bezel outline, including its curved segments, instead of simple chamfered corners. Its floor remains 4 mm deep. Display and IC10 pocket floors/walls now use source material roles, sampled native UVs and original material property blocks instead of the bright cabinet gray. Chip lining is visible only before the native socket is installed; the completed native socket remains unchanged. F1 stage images match the revised models.

Construction, kit recipes, save migration and completed-only chip/control/network/power/wiring gates remain unchanged.

Validation: native-reference build without warnings/errors; 7,395 geometry/ray/rounded-outline/depth/UV-role/nondegenerate checks and 61 stage/model/control/rollback/lining checks passed. F1 icons visually inspected. Actual Unity appearance/color/construction/save-load/multiplayer verification remains pending.

# Modular Switchboards 1.0.118 — visible IC10 and display pockets in unfinished Core

Core now shows the original-depth IC10 opening with an opaque gray floor before the socket is fitted. The display opening matches the native bezel footprint and is 4 mm deep, also with gray walls and a closed floor. These pockets remain beneath the fitted components. Stage0 shows both openings, stage1 adds the display, stage2 adds the original native IC10 socket. F1 images match the revised stage models.

Construction remains 5 Smart kits, then 2 Electronic Parts, then 5 Heavy Cable Coils; IC10 separate. Recipes, saved-stage migration, completed-only chip/control/network/power/wiring gates remain unchanged.

Validation: native-reference build without warnings/errors; 7,005 native geometry/ray/depth/material/nondegenerate checks and 49 stage/model/control/rollback checks passed. Actual Unity appearance/construction/save-load/multiplayer verification remains pending.

# Modular Switchboards 1.0.117 — Smart kit economy and three-stage Core

One Smart kit now costs 10 Copper + 8 Steel + 4 Solder in the Electronics Printer. Core construction: 5 Smart kits build the solid body without display or IC10 socket; 2 Electronic Parts add the display; 5 Heavy Cable Coils add the original socket and its pocket. Insert a separate removable IC10 only after completion. Other Smart module construction kit counts remain unchanged.

Each Core stage has its own F1 image. Incomplete Cores cannot accept IC10, use controls, run programs, bind power/data networks or receive new wiring. Heavy coil assembly uses native construction instead of internal wiring at the display-only stage. New saves preserve partial stages; older completed Core saves migrate to the final stage. The completed native display/socket appearance is preserved.

Validation: native-reference build without warnings/errors; 14 Smart-kit placement/recipe checks, 15 Core save/XML/chip/legacy checks, 49 stage/model/control/rollback checks, 2,085 native LED/socket geometry checks and 21,938 other geometry checks passed. Stage icons visually inspected. Actual Unity construction/slot/wiring/save-load/multiplayer verification remains pending.

# Modular Switchboards 1.0.116 — original battery floor depth and material

The unfinished battery holder now uses the original deepest native APC floor geometry and material instead of the shallow gray plate. Preserve its original floor depth, vertex channels, UVs, material roles and property blocks. Expand only in X/Y to close the unfinished aperture. The completed native holder stays unchanged. The F1 unfinished image matches the deeper original floor.

Battery construction remains 5 DIN kits plus 1 Electronic Parts; cell separate. Transformer construction remains Small 5 kits plus 2 Heavy Cable Coils, Medium 8 kits plus 6 Heavy Cable Coils. Completed-only new wiring and existing save/power/slot gates remain.

Validation: native-reference build without warnings/errors; 12 production floor-selection/material-role/depth/backface checks passed. Actual Unity appearance/construction/slot/wiring/save-load/multiplayer verification remains pending.

# Modular Switchboards 1.0.115 — battery completion parts and heavy transformer windings

Battery holder: 5 DIN module kits build the body; 1 Electronic Parts completes the original native holder. No Gold or Plastic Sheet is required for this completion. The removable cell remains separate. An opaque gray backing now closes the unfinished aperture, with a matching F1 stage image; the completed original holder is unchanged.

Transformer winding completion now requires Heavy Cable Coils: Small uses 5 DIN module kits plus 2 Heavy Cable Coils; Medium uses 8 DIN module kits plus 6 Heavy Cable Coils. The heavy coil prefab is resolved from the native cable catalog instead of guessing its name. Body construction, completed-only new wiring, slot/power gates, saved-stage migration and other recipes remain as before.

Validation: native-reference build without warnings/errors; 12 updated production winding/contact-priority checks and 21,938 geometry checks passed. Actual Unity appearance/construction/slot/wiring/save-load/multiplayer verification remains pending.

# Modular Switchboards 1.0.114 — restore original battery holder model

Restore the original battery holder appearance without added gray frame bars or extra gold contact pads. Five DIN module kits build the body with an empty opening; 1 g Gold completes the original native holder. The battery cell remains separately removable. Retain construction stages, old-save completion migration, power/slot gates, separate F1 stage images, and the rule allowing new wiring only on completed modules. Battery stage images now show only the original body and native holder.

Validation: native-reference build passes without warnings/errors. Recipe, migration and wiring sources remain identical to 1.0.113. Published source snapshots are preserved. Actual Unity appearance/interaction/save-load/multiplayer validation remains pending.

# Modular Switchboards 1.0.113 — battery construction, stage icons and completed-module wiring

Battery holder construction now uses 5 DIN module kits for the base, then 1 g Gold to finish. There is no Plastic Sheet requirement. The unfinished gray mounts differ visibly from the completed native holder with gold contact pads. Insert the removable battery cell only after completing the holder. Incomplete holders cannot conduct, charge or discharge. Existing completed holders migrate to the completed stage when loading older saves; new saves retain their construction stage.

New internal cables require completed modules at both endpoints. Incomplete contacts do not show wiring markers; attempting to connect displays a completion message. Existing wires are retained and can still be removed with wire cutters. A previously selected endpoint is rechecked before connecting.

F1 Build States now has separate unfinished/finished images for both transformers and the battery holder. All six new icons use the production geometry exports; transformer images retain the original winding supports and materials.

Validation: native-reference build without warnings/errors, 14 battery save/migration/conduction checks, 22 module wiring readiness checks, and 21,934 production geometry checks passed. The six stage icons were visually inspected. Actual Unity construction/slot/wiring/save-load/multiplayer verification remains pending.

# Modular Switchboards 1.0.112 — original winding supports in unfinished transformers

Based on the accepted 1.0.110 appearance, replacing the rejected 1.0.111 visual change. Unfinished Small and Medium transformers hide only the copper winding while retaining original holders, covers and leads. Small keeps its original WindingBands; Medium retains the exact gray/dark support triangles embedded in the original winding mesh. The original gray fascia is flat and coplanar behind the missing winding, without new holder primitives or a white plate. Completing construction restores the original recessed face and full winding. Kit prices, construction quantities, power gates, save migration and the state -1 startup fix remain unchanged.

Validation: native-reference build without warnings/errors; 17,422 geometry checks and 8 initialization checks pass, with exact support triangle/UV provenance verified. Actual Unity appearance, interaction and multiplayer verification remains pending.

# Modular Switchboards 1.0.110 — transformer prefab initialization fix

Fix the 1.0.109 startup failure: do not invoke native stage visualization on an unplaced transformer prefab at state -1, and do not rebuild its fitted hitbox while the native state has all children inactive. Explicitly restore shared body, terminals and controls in both placed construction stages. Completed-stage winding visibility and the 1.0.109 recipes/counts remain.

# Modular Switchboards 1.0.109 — cabinet economy and transformer construction

Cabinet kit: 60 Iron + 30 Copper, Electronics Printer only. Small uses 1 kit + 2 Plastic Sheets; Medium uses 3 kits + 5 Plastic Sheets, including reverse/collector variants.

DIN rail kit: 5 Iron. One kit per Small or Medium rail. DIN module kit: 5 Iron + 20 Copper. Other kit recipes remain unchanged; all custom kits remain exclusive to the Electronics Printer.

DIN transformers now have two construction stages. Small: 5 module kits for the body, then 3 normal Cable Coil units. Medium: 8 module kits, then 5 normal Cable Coil units. The unfinished body keeps the gray pocket backing without windings. Its terminals can be wired, but it transfers no power until finished. Aim the coil at the body to finish construction; terminal targets retain wiring priority. Native construction handles material consumption and stage dismantling. Existing completed transformers migrate to the completed stage when loading older saves.

Validation: native-reference build succeeds without warnings/errors; 28 save/XML/join-order checks, 12 winding-versus-terminal routing checks, and 4,791 power-engine regression checks pass. Actual Unity stage rendering, construction interaction and multiplayer still need in-game testing.

# Modular Switchboards 1.0.108 — own preview/hitbox audit

- Isolate copied world renderers on every own construction-cursor family with forceRenderingOff, preserving ghost hierarchy, helper subtrees, materials and placed objects. Enforce through status-script enabled changes.
- Use actual blueprint bounds for unpadded board-part selection, including transformers, Smart Output, door parts, rails, covers and labels. Preserve native UI visibility/validity and cabinet placement behaviour. Synchronize contour tint for every own structure preview.
- Fit passive DIN/Smart/transformer/door/rail bodies to model triangles; keep control/slot/mount colliders. Rebuild after width changes, preserve serialized collider references on prefab cloning and manage runtime/shared mesh ownership. Exclude nested mounted structures; retain temporarily disabled own body geometry.
- Fit custom kit convex body/selection envelopes to package geometry, retaining native triggers, quantities and carry poses. Keep installed cover/label perforation colliders and portable-cover payload system.
- Add startup diagnostics for missing own preview meshes/renderers/fitted bodies and a family audit report. Native build and relevant source/stub regressions pass; actual Unity/physics/MP validation pending.

# Modular Switchboards 1.0.107 — exact casing-volume placement

- Reject physical cabinet overlap independently of coarse half-metre cell occupancy. Covers Small/Medium in either build order, frames, all ratios/orientations and rolled mounts.
- Read transformed Housing mesh bounds; use oriented-volume separating-axis checks, with a small contact tolerance and bounds fallback when geometry is absent. Do not add physical/selection colliders or change grid cells.
- Track registered cabinets through OnRegistered/OnFinishedLoad and remove on OnDeregistered/OnDestroy. Skip self, cursors, destroyed objects and other grid controllers. Check current transforms on each placement query.
- Preserve native placement failures, APC terminal rule, native yellow connection feedback, power and serialization. Block new intersecting placement without moving existing objects.
- Native-reference build and source/stub geometry/placement/preview tests pass. Actual Unity/MP placement validation pending.

# Modular Switchboards 1.0.106 — native yellow cable previews and APC adjacency

- Use native SmallGrid.WillJoinNetwork for cable-join previews. A narrowly scoped Harmony prefix/postfix/finalizer exposes finished Power type only on unregistered cabinet cursors; real unfinished endpoint types and power gates stay unchanged. Preserve original endpoint references for native helper colouring.
- Add future-port adjacency validation after native construction validation. Match APC's facing-cell power-device rule and native pipe exemption, including neighboring switchboard frames with inactive ports. Preserve native error text/base failures; no blanket cabinet spacing.
- Synchronize static construction edges with native fill validity colour while preserving opacity and the existing animated native material.
- Build against native game references; production helper/extracted-method and preview/power regressions pass with stubs. In-game placement/runtime validation pending.

# Modular Switchboards 1.0.105 — power fan-in and family documentation

- Three wires at IN/OUT on analyzers, breakers, fuses, transformers and batteries; contactor power contacts match. Preserve A1, DATA, Smart controls/Core at one and door bridges at three.
- Route shared module-input entries; retain all three incoming saved/networked wires without changing endpoint IDs or packet framing. Keep loop, bypass and control rules.
- Generalize source/path accounting to all eight cabinet profiles and multiple output networks. Share source/cell/transformer budgets once, demand then spare capacity; preserve pending offers, per-path protective loads, partial repayments, charge limits and native standby. Account paid charging/standby against each real source too.
- F1 lists only canonical Small/Medium family pages with all four options per size. Hide cached variant search results and list records; retain all eight kit/creative/save variants. Extend canonical search terms.
- Show logical input helpers for all collector inputs without changing saved native roles, transforms, cable cells or network types.
- Native-reference Release build and source/stub regression/routing/serialization checks passed. In-game graphics, physics, native power threading and host/client save/load are not claimed.

# Modular Switchboards 1.0.104 — collecting power cabinets

- Append four new stable prefab variants to the same kit: Small2IN/1OUT and Medium3IN/1OUT, each Basic/Reverse. Existing four prefab IDs and first four constructable indices stay intact. Register/search/localize all eight and reuse size geometry/costs, grey-backed skeleton, doors and cover profiles.
- Preserve physical socket placement and cable-grid layout while assigning independent logical Input1/2/3 and common Output. Additional input contacts use saved Owner0 contact4/6, primary Input0 and Output1 retain their directional meanings. Native role slots remain unique; explicit logical mapping owns labels and cable lookup.
- Allow2/3 incoming wires at common Output only. Module input limits, direct-source/bypass prohibition, directional loop rules and manual construction remain unchanged. Extend router shared-target pockets and physical-slot lane rules to allow convergence without overlapping other cable portions.
- Route new variants into a separate collecting power bridge. Reserve actual source/path contributions, deduplicate the same cable network, track actual network debt, respect path-specific protection and shared transformer caps, external-first batteries, aggregate native cell charge rate and transformer standby. Enumerate/caches actual paths rather than applying a union load to parallel protectors. Retain the legacy solver for existing variants.
- Recognize Input2/3 in live contacts, Core power/data classification, coils, LEDs and analyzer selection. An analyzer on one branch can read the common external Output network. No automatic data-network joins or transfer-switch logic.
- Extend wire XML/network validation to contact4/6 and cover eight-variant roundtrips. Native prefab in-game startup/MP/GPU behavior remains pending player confirmation.

# Modular Switchboards 1.0.103 — safe host teardown and DIN outline resizing

Standalone Switchboard Cover is hidden from F1 creative spawn and Stationpedia. The registered prefab, Cover Kit constructable reference, recipes, transfer and existing saves remain intact; Kit Covers stays visible.

- Route all owned-board cleanup in SwitchboardCabinet, DinRail and InnerCoverModule through BoardHostLifetime.Release. During non-Running states clear board/handle references without native RemoveHost/orphan operations on destroyed child transforms. Preserve native cleanup for real in-world removal.
- Track SizedGhostSource alongside SizedGhost, so the same cursor is rebuilt when its source mesh changes between Small and Medium. Previously an existing assigned ghost caused an early return even after resizing.
- Refresh cached outline child mesh with the newly sized ghost, free previous outline mesh, preserve materials and resource ownership. Clear obsolete native WireframeEdges for the custom DIN cursor. No rebuild on unchanged size.
- Native Release build0 warnings/errors. Stub checks:36 lifecycle,39 extracted production resize methods,22 actual refresh ownership/width/cleanup. Actual runtime exit/MP/visual validation pending.

# Modular Switchboards 1.0.102 — retain grey rear shell during frame construction

- Add only the existing integrated grey rear body (Housing role1) to first-stage Frame geometry, preserving actual triangles, native UVs and normals. No white casing, interior fittings or separate protruding APC box is copied.
- Restore the same native-grey material/property block as the finished housing. Keep accepted green preview code unchanged.
- Update the exact frame collider to the combined mesh; preview, tight selection and frame-stage icons use the combined assembly. Frame is state0 only, so grey body is not duplicated in the finished stage.
- Existing finished stage and costs unchanged. Native build0 warnings/errors;14818 extraction/channel/source-preservation checks passed with stubs.

# Modular Switchboards 1.0.101 — fit skeleton to cabinet profiles

- Replace duplicated rectangular mounting frames with rounded rings derived from the native Small .400 x .500 / R20 and Medium .800 x 1.000 / R40 housing profiles. Offset inside native 6/12 mm skin with a further 0.5 mm clearance.
- Place four depth rails within the curved corner section. Keep housing depth fixed across sizes; front/rear rings clear panel and door planes.
- Replace square edge boxes with a static MeshCollider using the exact visual skeleton mesh, only in build-state 0. Retain open centres, native owner registration, existing finished-stage geometry and build costs.
- Construction previews, tight selection and regenerated icons use the new actual frame mesh. Native green material code untouched.
- 75737 production geometry/scope/state checks passed with Unity stubs; native-reference Release build passed with 0 warnings/errors. Actual runtime gameplay remains to confirm.

# Modular Switchboards 1.0.100 — full cabinet skeleton

- Extend stage 0 into a full-depth cabinet skeleton: duplicate original rear frame at the front, connect all four corners with rounded rails. End at housing front z=.180 m, before doors at .185 m.
- Preserve native material roles, detailed frame mesh, native UV mapping and model-relative orientation. Derive Medium dimensions after its geometry scaling.
- Add eight precise rail colliders alongside the original four; all belong only to stage 0. Remove the 1.0.99 invisible opening trigger. The finished shell/interior/doors and build costs are unchanged.
- Existing construction preview and frame selection use the new actual Frame mesh. Regenerate Small/Medium stage icons from production geometry exports. Keep accepted preview material code unchanged.
- Native-reference build: zero warnings/errors. 60365 production skeleton checks with stubs passed. GPU appearance and runtime native save/network/raycast behavior need gameplay validation.

# Modular Switchboards 1.0.99 — frame construction target

- Add an invisible trigger across the bare frame opening; aiming at the narrow physical bars is no longer required.
- Derive dimensions from the actual frame edge colliders after Medium geometry, inherit model orientation for both reverse variants.
- Register only in native OnMyState build-state 0 so complete/legacy-cover states disable it and dismantling re-enables it. Native collider cache registers ownership. No solid obstruction or new visual.
- Tighten only frame-stage displayed selection bounds to the actual frame mesh at its current wall-fit transform. Preserve full cabinet bounds for mounting/grid occupancy and all native selection owner/action identities.
- Keep accepted 1.0.98 preview implementation unchanged. Native-reference build passed; 201 frame geometry/state-registration/selection checks passed with stubs. Actual gameplay raycast/save/network behavior remains for in-game verification.

# Modular Switchboards 1.0.98 — accepted native preview appearance

- Reuse ThingImporter blueprint template material for native animated fill; retain static outlines, real openings and labels. User accepted appearance in hand and placement. No further material changes.

# Modular Switchboards 1.0.97 — static outlines/labels with animated hatch

- Restore the stronger cover/hole contours, label frames and saved label text from 1.0.95. Only the diagonal hatch from 1.0.96 moves.
- Render outlines/frames in a separate mesh built once, independent of the sixteen cached hatch phases. Exclude label areas and actual openings from every hatch phase.
- Keep per-frame animation allocation-free; clean up cached phase meshes, static overlay and owned materials when the cursor is destroyed. Real item paint, saved state and cutout-aware icons stay unchanged.

# Modular Switchboards 1.0.96 — animated hatch only

- Show only moving diagonal green hatch for fitted-cover placement. Remove contour ribbons, label frames and preview label text. Saved openings remain transparent in every phase.
- Build sixteen clipped hatch meshes once per cached cursor; switch their references at 20 Hz using unscaled time. No geometry rebuild or material creation in LateUpdate. Stop naturally when the cached cursor is inactive; release all owned meshes/material on destruction.
- Keep actual covers, saved label text, per-cover inventory icons, generic kit outlines and placement controls unchanged.

# Modular Switchboards 1.0.95 — hatched cover preview, bold boundaries and labels

- Combine faint diagonal green hatch strips with stronger physical cover/hole outlines. Build cover contours from the actual filled-cell boundary flags, removing internal grid/T-junction seams from the generic mesh edge extractor.
- Clip hatch polygons to sheet cells and remove label rectangles from hatch coverage. Holes and labels stay clear. Hatch is 2 mm wide at 25 mm pitch; physical boundary ribbons are 1.8 mm wide with stronger alpha, label frames 1.4 mm.
- Show saved label text in green, using the existing text fitting and a private emissive/cutout preview ink material. Real label text/paint/materials remain unchanged. Preview font materials are cached separately from real ink.
- Keep generic wire outlines for other kits and covers without saved state. Keep per-cover inventory icons from 1.0.94. Mesh/material ownership remains per cached cursor and is cleaned up on destruction.

# Modular Switchboards 1.0.94 — outline placement and per-cover cutout icons

- Replace filled translucent placement triangles with actual MeshTopology.Lines geometry. Weld identical positions, keep boundary/crease edges and remove coplanar triangulation diagonals. Hole perimeters remain visible without broad overlapping green bands.
- Use Hidden/Internal-Colored and the blend/cull/depth-write properties confirmed in native Wireframe.CreateLineMaterial. Preserve native construction-preview alpha; no painted surface texture or UV is involved. Owned cursor meshes/materials are disposed with the cursor.
- Generate each fitted cover's 128px inventory icon from its saved dimensions, retained apertures and label positions, plus saved hue. Holes and background are transparent. Label rectangles are represented; tiny label text is not rasterized.
- Cache one owned icon per item/state/colour, refresh on repaint or replacement state, dispose previous textures/sprites and release them when the item is destroyed. The prefab-only colour icon remains a fallback when no instance state is available.
- User confirmed the 1.0.93 colour icon works. New outline rendering and cutout icons require in-game verification.

# Modular Switchboards 1.0.93 — native placement material and actual thumbnail API

- Copy the complete material from a real vanilla Locker/APC construction blueprint rather than assigning CursorManager.CursorShader. Preserve native shader, blending, render queue, keywords and textures; use InventoryManager's construction-preview alpha with green precision-placement tint.
- Intercept both native Thing.GetThumbnail overloads only for fitted covers, returning the saved-colour cached icon. The instance method is sealed and cannot be overridden; changing Thumbnail alone did not cover all UI paths.
- After recovering a cover, explicitly flag its payload update so clients receive saved colour/labels/openings immediately after the item is spawned. Previously only native base colour flags were guaranteed.
- Retain actual-item paint/atlas and all source blueprints. Native game/MP verification is still needed; local fixtures alone did not expose the previous preview mismatch.

# Modular Switchboards 1.0.92 — transparent placement preview and saved-colour icon

- Precision-placement cursor removes cloned construction-only Wireframe/blueprint boot components before activation and explicitly selects the native cursor shader and clears inherited renderer property blocks. Native placement owns green/red validity tint with the existing 20% alpha; saved paint belongs to the actual item.
- Portable-cover cursor instances skip late saved-paint restoration. Held/world items retain the real saved finish.
- Inventory/hand-slot thumbnail uses a cached tinted cover icon keyed by saved colour. Preserve source shading and alpha, update on repaint even when the same state object is mutated, and safely fall back for an unknown palette index. Only the shared cover icon retains a CPU-readable source buffer; tinted outputs discard theirs.
- No per-frame sprite/material creation. Exact ghost transparency/validity and live UI icon refresh still require a native game check.

# Modular Switchboards 1.0.91 — retain native textured paint on gold and bronze

- Fix CabinetPaintSurface replacing the native textured array material with ColorSwatch.Normal, a legacy solid-colour material. Keep the original cabinet atlas material and change the diffuse palette index through existing property blocks, including repaint and moved covers.
- Preserve the native prefab SmoothnessIndex (surface texture-array layer); do not replace it with a gloss float from the legacy solid-colour swatch. Fixed hardware, rear surface, emission fixes, LED materials and module finishes stay unchanged.
- Gold/bronze screenshot comparisons exposed the missing native grain/surface detail. Local tests verify material retention and native surface index; exact visual parity still needs an in-game comparison.

# Modular Switchboards 1.0.90 — matching corners, transferred paint and wire shadows

- Match Medium outer door corners to the housing's 40 mm radius while retaining seam, handles, pivots, colliders and smaller mirrored hinges.
- Native Structure.SetStructureData skips SetCustomColor when the requested colour equals the prefab colour. Force non-emissive colour initialization when recovering/mounting a fitted cover, including white -> white. Keep the saved independent colour and all labels/openings.
- Clear inherited emission for physical cabinet/rail/module/kit/label paint in existing registration/paint callbacks. Cover rendering also suppresses inherited emission so already-moved covers recover visually. Native child batteries and live door LED/screen materials are excluded from this normalization.
- Disable shadow casting on procedural internal wire bodies/ends, previews and contact markers. Door flex already had casting disabled; unify that path. Retain received lighting/shadows, material finish and cable paint. This targets shadow-map streaks on the inner cover; in-game confirmation remains needed.

# Modular Switchboards 1.0.89 — smaller mirrored hinges and native paint finishes

- Reduce exported Small hinges to 10 x 24 x 16 mm, including normals and retained Blender source. Medium retains the same hardware size and adds mirrored hinges on the other door side; correct reflected triangle winding and normals. Cabinet dimensions and door pivots stay unchanged.
- Cabinet panels use the selected native colour swatch material and smoothness instead of matte clones with disabled reflections. Restore original materials before swapping only the paintable role; preserve fixed hardware/rear material roles.
- Mounted and portable inner covers use their independently saved colour for the same native finish. Existing module matte surfaces, cable colours and live LED materials are unchanged.
- No new per-frame material clones. In-game metallic appearance still needs visual verification.

# Modular Switchboards 1.0.88 — reuse power topology and unchanged saved routes

- Share one cached adjacency graph and reachable-contact sets across power queries. Cache module-path arrays until wire endpoints, burnt state, conducting IDs or eligible module IDs change. Snapshots use endpoint values, detecting in-place mutations too.
- Continue live supply/demand/charge reads, energy reservations, consumption and overload accounting at their existing cadence. This change does not throttle power simulation.
- Skip marker capacity/connectivity/material work when wiring markers are hidden.
- Promote revision-8 routes to revision 9 without A* only when every saved endpoint still matches its live contact within the existing 1 mm tolerance. Preserve exact path arrays and all saved wire attributes. Moved Medium transformer contacts and older routes still use atomic migration; required route searches remain synchronous.
- User measured about 20 FPS with cabinets versus 50 FPS after removing cabinets. Local query benchmark is not an in-game FPS measurement; user validation remains needed.

# Modular Switchboards 1.0.87 — stop repeated failed route migration

- A failed atomic route migration no longer restarts synchronous A* every 0.15 seconds when periodic contact checks still see old endpoints. Keep the original wires and manual-rewiring message until a real wiring change permits another attempt.
- This loop can be exposed by the corrected Medium transformer contacts and route revision 9. No in-game FPS measurement yet; this is a confirmed retry path, not a confirmed diagnosis of the player's entire slowdown.
- Cover painting, terminal capacity, geometry and wire clearances are unchanged.

# Modular Switchboards 1.0.86 — Mono initialization fix

- Remove the global Harmony patch on the static interface method ISprayer.DoSpray. The user's Mono log confirms dynamic wrapper generation fails with "Owner can't be an array or an interface."
- Keep mounted and loose cover painting through their existing AttackWith overrides. Cover state, three-wire door contacts and transformer alignment from 1.0.85 are retained.
- No global sprayer patch or runtime-specific workaround is needed.

# Modular Switchboards 1.0.85 — independent cover paint and three-wire door terminals

- Paint mounted and loose inner covers independently. Preserve colour through removal, save/load and installation elsewhere, including covers without labels.
- Allow three wires per door bridge contact on either side, preserving capacity during save/load and checking branch clearance outside the shared contact fork.
- Correct the Medium transformer contact position by removing a duplicate content offset; migrate saved routes atomically to revision 9.
- Build and automated checks pass; native gameplay and multiplayer paint/input still require an in-game check.

# Modular Switchboards 1.0.84 — model-referenced mounting and switch states

- Use the actual exported breaker body, native APC flap and bearing geometry to reference the preview's spindle mounting.
- First upper breaker ON, all other breaker flaps down in OFF. Preserve filled fuses, banner, layout and loader information.
- Gameplay is unchanged.

# Modular Switchboards 1.0.83 — game-style breaker flaps

- Match preview breaker handles to the actual module reference: short coloured hinged plates, recessed black faces and lower spindle details, replacing oversized bent levers.
- Keep filled fuse cartridges, banner, installation description and gameplay unchanged.

# Modular Switchboards 1.0.82 — clearer preview module details

- Fill the empty fuse holder in the promotional artwork with a grey cartridge and silver end caps.
- Give breaker modules projecting toggle levers so they read differently from fuse cartridges, sockets, battery, displays and transformers.
- Preserve the LaunchPad banner, wording and installation information. Runtime behaviour is unchanged.

# Modular Switchboards 1.0.81 — preview and installation information

- Replace the sparse preview with detailed switchboard artwork and an orange StationeersLaunchPad banner.
- Put the BepInEx/LaunchPad requirement and installation link first in game/Workshop descriptions. Keep required LibConstructReloaded visible next to it.
- Use plain bullets in the in-game description and Steam BBCode in the prepared Workshop text. Runtime behaviour is unchanged from1.0.80.

# Modular Switchboards 1.0.80 — responsive previews and burnt-wire colour maintenance

- Run preview path search on an isolated geometry snapshot in a cancellable worker. Poll/cache results without waiting on the game thread. Reuse search buffers and cache edge costs independently of bend history.
- Restore saved colour continuously for burnt insulation. Separate the coloured/type-marked body renderer from local scorch/conductor materials; compact each mesh to its own referenced vertices.
- Preserve routing clearances, power limits, damage persistence and refund rules. Cold server commit validation and old-save migration remain synchronous.

# Modular Switchboards 1.0.79 — local cable scorching

- Ruptured wires retain original insulation colour and Heavy/SuperHeavy details. Only the broken ends are scorched, with tapered insulation and three exposed metal conductors.
- Existing burnt saved wires acquire the corrected appearance automatically. Electrical limits, routing, rupture effects, packet format and no-refund removal stay as in1.0.78.

# Modular Switchboards 1.0.78 — routing reservations and cable rupture

- Reserve the widest 8mm cable for every type, protect unused contact pockets across depth layers, and prevent sub-diameter grid doglegs. Preserve old connections if migration cannot fit the stricter layout.
- Evaluate native Normal/Heavy/SuperHeavy ratings against actual per-wire transferred load, including common branch sums. Keep damaged wires open, charred and visibly split until cut; return no coil for burnt wires.
- Use native CableSpark sound and shared sparks; persist and sync damage with legacy packet reading and no repeated/load-time effects.

# Modular Switchboards 1.0.66 — DIN analyzér na konfiguračním tabletu

- Konfigurační kazeta tabletu při zaměření DIN Cable Analyzeru nově ukazuje ReferenceId a PowerActual, PowerPotential, PowerRequired. Hodnoty jsou jen pro čtení, ve stejném formátu a se stejným zaokrouhlením jako původní herní přehled logických hodnot.
- Čte se stejná síť vybraná současným zapojením analyzéru jako v jeho tooltipu. Přepojení na Input nebo jiný Output se projeví při dalším čtení; chybějící či nejednoznačná síť vrací nulové hodnoty, jako nezapojený původní analyzér.
- Příčina N/A byla v kazetě: běžně zpracovává jen Device, zatímco pasivní DIN analyzér je Structure. Úprava je omezená na jeho zobrazení v konfigurační kazetě. Nevytváří další elektrický přístroj ani nemění odběr, sítě, ochranu nebo podporu IC10. Ostatní cíle a běžné herní analyzéry dál zpracovává původní kazeta.

# Modular Switchboards 1.0.65 — úplná těla Smart modulů a nižší náplň krabice

- Opravené pořadí vrcholů ploch Core a Outputu při převodu do dekorativní náplně Smart kitu. Převod z Unity do Blenderu obsahuje zrcadlení; bez obrácení pořadí vrcholů hra odvrácené plochy těla nezobrazovala. Vlastní Blender geometrie Netu, popisků a LED zůstává orientovaná správně.
- Náplň zůstává 2× Core, 4× Net a 4× Output, ale díly jsou menší a znovu usazené s 8mm rezervou od hran a maximální výškou 360 mm v souřadnicích zdrojové krabice. Oproti dřívějším 433 mm tak neleží nad horním lemem.
- Náhled a ikona nově zobrazují pouze přední strany ploch, stejně jako herní materiál. Kontroly kromě průniků a opory ověřují i orientaci ploch těl; běžný Module kit i ostatní moduly jsou beze změny.

# Modular Switchboards 1.0.64 — Smart kit ve stejné krabici jako běžné moduly

- Kit (DIN Smart Modules) používá stejnou otevřenou krabici, atlas a měřítko obalu jako Kit (Switchboard Modules). Uvnitř jsou volně naskládané současné modely Core, Net a Output, nikoli běžné jističe. Tři existující druhy se v náplni opakují; nejde o nové stavební varianty ani obsah inventáře.
- Vlastní ikona, držený/položený model i blueprint Smart kitu používají tento nový vzhled. Předměty v krabici jsou offline usazené stejným postupem jako běžné moduly, s kontrolou vzájemných průniků, stěn a opory.
- Recept s Electrum, počty kitů, varianty Core/Net/Output, jejich napájení i uložené identity jsou beze změny. Zůstávají všechny opravy F1, traf a krytu z 1.0.63.
- Source archive also omits derived Art/DinTransformer.blend and Art/DinTransformerMedium.blend: regenerate production JSON with Verification/TransformerFront/extract.py and Check.csproj, then run Blender Tools/render_transformer.py (and -- --medium for Medium). Original native references, runtime meshes, textures, source and tools remain included.
- Source archive omits regenerable SmartKit model.json, source.json, pile-input.json, pile-settled.json and SmartKit.blend; original module designs, shared crate source, final runtime mesh, checked layout.json, support audit and all tools are retained. To replay the exact layout, run prepare_smart_pile.py then replay_smart_pile.py instead of the placement search.
- Rebuild Smart crate: Blender Tools/prepare_smart_pile.py; Tools/settle_kit.py with Art/SmartKit/pile-input.json and pile-settled.json; Tools/check_settled_support.py with pile-settled.json and support-audit.json; Python Tools/bake_kit_contents.py SmartKit; Blender Tools/render_smart_kit.py. Uses the preserved ModuleKit shell and existing Smart/CoreLED/Output authoring references.

# Modular Switchboards 1.0.63 — oprava automatické tabulky Bindings u Core

- Samotný textový popisek byl zkrácen už v 1.0.61, ale hra vedle něj generuje samostatnou tabulku Bindings z ICircuitHolder. Ta u Core stále ukazovala d0–d5 jako SCREW_0 až SCREW_5. Oprava nyní upravuje i tuto skutečnou tabulku F1.
- Core v tabulce zobrazuje pouze db → CORE, tedy adresu samotného Core. Nezobrazuje neexistující fyzické šrouby. Výběr d0–d5 a příkazy pro připojené Smart Output moduly jsou dál vysvětlené u Outputu.
- Změna se týká jen zobrazení ve Stationpedii. Skutečné adresování připojených Outputů z IC10/Lua, ukládání, napájení i ostatní zařízení jsou beze změny. Obsahuje také všechny popisky a opravy geometrie/krytu z 1.0.62.

# Modular Switchboards 1.0.62 — výřezy vnitřního krytu kolem traf

- Výřezy krytu nyní zahrnují DIN Transformer Small (4 pozice), Medium (6 pozic) a Smart Output (2 pozice, případně starou kompaktní jednotku). Tyto samostatné komponenty dříve nebyly v seznamu jističových modulů, ze kterého se otvory počítaly.
- Opravené jsou obě cesty: samostatný nasazený kryt i původní kryt jako stavební stav skříně. Poloha a šířka otvoru vychází ze skutečně osazeného modulu, nikoli z posunuté pozice svorek Medium. Výřezy se aktualizují i po změně osazení nebo šířky při načtení.
- Small i Medium mají nyní stejnou výšku šedého čela jako jistič: 60,75 mm, také shodný boční odstup čela od těla. Původní komponenty jsou rovnoměrně zmenšené na přibližně 86,4 % a usazené s vůlí uvnitř čela; kolečko zůstává kulaté. Společně se přizpůsobují obě poloviny klikací plochy až k zadní straně kolečka.
- Kapsy za vinutím odpovídají nové poloze a měřítku; za Small vinutím i oběma Medium vinutími je uzavřená šedá výplň. Bílé původní upevňovací lišty vinutí zůstávají součástí původního modelu. Kryt odkryje čelo a nechává svorky zakryté. Popisky z 1.0.61 i spotřeba z 1.0.60 zůstávají.

# Modular Switchboards 1.0.61 — stručné a přehledné popisky F1

- Sjednocené krátké popisky všech vlastních modulů, jističů a pojistkových držáků všech hodnot, baterie, analyzéru, Smart systému, dveřních prvků, skříní, lišt, krytů, štítků a kitů. Účel, zapojení a důležitý limit jsou oddělené krátkými odstavci; klíčové kontakty, hodnoty a funkce jsou žlutě zvýrazněné. Odkazy na související moduly používají původní formát Stationpedie.
- Core vysvětluje jen vlastní funkci a displej; d0–d5 a příklad spínání patří k Outputu. Net zajišťuje DATA, Output ovládá A1 stykače. Opravené zastaralé záměny Net/Output, šířka Outputu na 2 pozice a kapacita lišt 7/14 podle skříně.
- Jistič jasně uvádí jmenovitý limit, sdílení mezi třemi vodiči OUT a ruční reset po odstranění přetížení. Pojistka uvádí shodnou hodnotu vložky, dva vodiče OUT a nutnost výměny po přetížení.
- Trafa zachovávají původní lokalizovaný herní popisek a modré odkazy; stručný DIN dodatek nově zvýrazňuje šířku, kroky kolečka a chování Setting 0. Skutečná spotřeba z 1.0.60 je beze změny.

# Modular Switchboards 1.0.60 — skutečná vlastní spotřeba DIN traf

- Small i Medium přebírají vlastní spotřebu z původního herního prefabu: v aktuální hře oba 10 W. Odběr se skutečně účtuje na straně IN, vedle energie přenesené na OUT; nejde jen o údaj ve F1. Celých 5000 W na OUT Small tedy vyžaduje 5010 W na vstupu, 25000 W na OUT Medium vyžaduje 25010 W. Nižší dostupný příkon omezí dodávku; nenapájené řízení nepovolí výstup.
- Účtování běží jednou za nativní elektrický krok hry, nikoli za snímek nebo dotaz na dostupný výkon. Opakované dotazy nepřidávají další spotřebu. Elektronika zůstává napájená i při Setting 0, které vypíná jen přenos; rozpojený či nenapájený IN nic neodebírá. Kurzor, rozestavěný nebo nepřipojený modul nespotřebovává energii.
- Přednost má skutečný přívod; chybějící část může dodat správně zapojená baterie. Spotřeba dalšího trafa za prvním se započítává do limitu prvního. Vlastní odběr prochází předřazenými jističi/pojistkami včetně bateriového napájení. Nedochází k druhému nativnímu účtování stejného DIN modulu.
- Po připojení se řízení musí nejprve skutečně napájet v herním elektrickém kroku; řetězec více traf nabíhá od zdroje. V multiplayeru klient respektuje synchronizovaný stav Powered ze serveru. Přemístění či odstranění modulu uvolní jeho nevyčerpané rezervace.
- F1 používá původní lokalizovaný herní popisek Small/Medium včetně původních odkazů, doplněný stručným ovládáním DIN varianty. Původní herní řádek Base Power Usage automaticky zobrazuje žlutých 10 W z totožného pole UsedPower. Logická hodnota RequiredPower ukazuje stejný jmenovitý odběr.
- Limity 5000/25000 W, kroky 100/10 W, vzhled, rozmístění, štítky, recepty i save identity zůstávají. Exportéry do AppData se nevracejí. Ostatní moduly tato změna nesjednocuje; jejich popisky lze upravit samostatně.

# Modular Switchboards 1.0.59 — dvojité vinutí a žebrování Medium

- Medium má dvě původní velká vinutí vedle sebe vpravo a dvě původní sady žeber pod kolečkem. Díly zachovávají původní velikost, profil, UV a barvy; nejsou zploštěné kvůli místu.
- Kolečko, stupnice, světlá podložka a obě klikací plochy jsou společně posunuté o 25 mm doleva. Původní hloubka hitboxu až k zadní ploše zůstává. Levý kryt s vodiči je beze změny.
- Opraven samostatný katalog Stationpedie: popisky 4 a 6 jsou nyní zařazené do Electronics / Modular Switchboards i vyhledávání, nejen do stavebního kitu a textových popisů.
- Tělo má dál šest pozic, maximum 25000 W, stejné kroky 100/10 W a cenu dvou Module kitů. Small se nemění. Vlastní odběr trafa stále 0 W; neobnovuje se žádný export do AppData.

# Modular Switchboards 1.0.58 — sestavené Medium trafo a štítky na šest pozic

- Medium používá přesné původní díly z nově dodaného modelu: vlevo kryt s bleskem, čtyři šrouby a všechny tři původní vodiče; pod zachovaným kolečkem čtyři původní chladicí žebra; vpravo větší původní vinutí s původními lištami. Zachované UV, barvy a průřezy, pouze jednotné měřítko jednotlivých sestav a jejich posun. Medium vinutí má přibližně dvojnásobnou výšku oproti Small. Maximum 25000 W, kroky 100/10 W, šest pozic a dva Module kity zůstávají.
- Small zachovává hotové díly i 5000 W. Klikací plochy obou koleček nyní pokrývají plnou hloubku až k zadní ploše. Každá polovina stále plní zvýšení/snížení; ovládání nepokrývá vinutí ani podložku.
- Kit (Switchboard Labels) nabízí navíc šestipozicový štítek. F1 jednotlivých popisků výslovně uvádí šířku i nabídku 1, 2, 3, 4 a 6 pozic. Cena zůstává jeden Label kit, text Labellerem; ověřuje se podpora celé šířky a volné místo.
- Z runtime jsou odstraněné exportéry modelů, textur a referenčních reportů do AppData/LocalLow, jejich automatická volání i související nepoužitý diagnostický kód. Načítání nativních dílů do paměti potřebné pro vzhled modulů zůstává; nic se kvůli němu neexportuje na disk. Existující soubory v AppData se nemažou.
- Zdrojový balík zachovává dodaný Medium model i offline nástroje pro opakovatelný převod. Source archive omits only regenerable Art/TransformerGeometry.json and Art/TransformerMediumGeometry.json; regenerate with Verification/TransformerFront/extract.py and Check.csproj.
- Vlastní odběr DIN traf je stále 0 W; tato verze nepřidává dříve diskutovanou spotřebu 10 W.

# Modular Switchboards 1.0.57 — DIN Transformer (Medium), příprava šesti pozic

- Nová samostatná varianta DIN Transformer (Medium), šest DIN pozic a maximum 25000 W z nativního Medium. V nabídce zůstává Small se 5000 W a čtyřmi pozicemi.
- Hotové díly Small jsou zachované v levých čtyřech pozicích; dvě nové pozice jsou přidané doprava se souvislým tělem a čelem, připravené pro následné skládání původního Medium modelu. IN/OUT zůstávají u hotové části. Stejné kolečko, 100 W běžný a 10 W jemný krok; Setting, síťový limit, izolace dat a ovládání zůstávají. Cena nadále dva běžné Module kity.
- Pozadí Small i Medium používá shodný nativní materiál, UV a paletový index jako čelo jističe. Světlá podložka kolečka a původní texturované díly zůstávají.
- Při spuštění modu se jednorázově uloží původní Medium včetně geometrie, hierarchie, textur a ovládání do LocalLow: ModularSwitchboards-Transformer-Medium-reference.zip. Již existující export se nepřepisuje. Skutečné vytvoření na počítači hráče proběhne až při spuštění této verze.
- Součástí zdrojů je i již dodaný původní Medium export v Art/MediumTransformerReference. Dosavadní vlastní odběr trafa zůstává 0 W; tato změna nepřidává dříve diskutovaný odběr 10 W.

# Modular Switchboards 1.0.56 — souvislé tělo za vystouplou krabičkou

- Odstraněn starý otvor pro zapuštěný kryt s bleskem z šedého čela i bílého těla. Vystouplá krabička má za sebou souvislé čelo a tělo; hluboko uložená náhradní zadní ploška už není potřeba.
- Poloha krabičky, její boky, blesk/šrouby, zrcadlové vodiče, plná světle šedá podložka kolečka i klikací plochy zůstávají stejné. Výřez a šedá výplň za vinutím zůstávají.

# Modular Switchboards 1.0.55 — plná světle šedá podložka kolečka

- Čtvercový rámeček kolem kolečka a obloukové značky je vyplněný stejnou světle šedou. Tvoří jednu plnou podložku, zachovává rozměry i polohu a nepřekrývá kolečko ani značku.

# Modular Switchboards 1.0.54 — světle šedý rámeček regulátoru

- Tenký čtvercový rámeček kolem kolečka a obloukové značky má pevný světle šedý materiál místo tmavého. Tvar, poloha, klikací plochy a ostatní části trafa zůstávají stejné.

# Modular Switchboards 1.0.53 — boky krytu zarovnané s čelem

- Krabička s bleskem zůstává stejně vystouplá. Jen zadní konce jejích bočních stěn dosedají přesně na společné šedé čelo. Přední plocha, výška/šířka, blesk, šrouby, původní UV, kolečko i oba páry vodičů zůstávají stejné.

# Modular Switchboards 1.0.52 — čtyřpozicový popisek a podpora trafa / Output

- Kit (Switchboard Labels) nabízí i čtyřpozicový štítek. Stejný model, text Labellerem a cena jednoho Label kitu; šířka odpovídá čtyřem DIN pozicím. Původní varianty 1–3 i dveřní štítky zůstávají.
- Kontrola modulů pod popiskem nově zahrnuje DIN Transformer i samostatný Smart Output, včetně jejich skutečné aktuální šířky. Platí stejné omezení na správnou řadu, dokončený kryt, volný rozsah a podporu po celé délce. Staré dvoupozicové trafo se počítá jako dvě pozice, nové jako čtyři.
- Obsahuje také úpravy trafa z 1.0.51: vystouplou krabičku, čtvercový rámeček kolečka/stupnice a přesně zrcadlové červenočerné vodiče po obou stranách. Kolečko zůstává v původní poloze.

# Modular Switchboards 1.0.51 — vystouplý kryt a rámeček regulace

- Levý kryt s bleskem je celý před šedým čelem, nikoli zapuštěný: zadní plocha krytu je 0,11 mm před čelem. Původní tvar, blesk, šrouby a textura jsou zachované. Červenočerné vodiče vstupují do obou boků krytu: levý i pravý pár končí zapuštěný v čele. Všechny používají původní tvar/průřez/UV a barvy; pravý pár je přesným zrcadlem levého podle středu krabičky, se stejnou délkou i tloušťkou a červeným vodičem nahoře.
- Kolečko zůstává přesně ve stejné poloze jako v 1.0.50, včetně klikacích ploch. Kolečko a původní oblouková značka jsou společně v tenkém čtvercovém rámečku, celý uvnitř šedého čela a nad lištou vinutí.

# Modular Switchboards 1.0.50 — oprava míření na pojistky

## Změny 1.0.50

- Trafo má jedno souvislé šedé vnitřní čelo, bez dvou samostatných montážních podkladů a původní černé plochy pod nimi. Kryt s bleskem, kolečko a vinutí jsou usazeny ve společném těle. Dvoupozicové staré kusy dostávají odpovídající užší čelo.
- Původní červený a černý vodič z exportu malého transformátoru jsou otočené k levému boku krabičky a končí zapuštěné v čele; původní UV/barvy/průřez a jednotné měřítko zůstávají.

- Kolizní obal držáku pojistky se po výměně modelu přepočítá podle skutečného těla držáku. Původní obal jističe zahrnoval i úchytky páčky a zakrýval užší cíl vložení/vyjmutí pojistky.
- Hluboký hitbox až k zadní stěně, jeho čelní rozměry, model a elektrické funkce zůstávají.

# Modular Switchboards 1.0.50 — čtyřpozicový DIN Transformer (Small)

## Změny 1.0.49

- Celé bílé tělo je rozšířeno na čtyři DIN pozice, jako jeden souvislý kryt. Pravé dvě pozice zachovávají původní čelo, kolečko, stupnici a vinutí; vlevo jsou přidány dvě pozice s původním šedým bočním krytem, bleskem a čtyřmi šrouby. Kryt je přímo z dodaného exportu (222 vrcholů, 148 trojúhelníků), s původními UV/atlasem a rovnoměrným měřítkem.
- IN i OUT jsou doprostřed celého těla mezi druhou a třetí pozici, včetně fyzických šroubů, otvorů, cílů kabelového nástroje a začátků vodičů. Staré konce vodičů využívají dosavadní atomické přetrasování; propojení a zaplacené kabely se neztrácejí.
- Staré dvoupozicové kusy se při načítání zvětší pouze tehdy, pokud jsou obě další pozice na straně přístavby volné. Sousední moduly se nepřepisují ani neposouvají. Pokud místo chybí, zůstane kompaktní starý kus s původním tělem a přívody; po uvolnění dvou míst a dalším načtení se může rozšířit. Nově stavěné kusy vždy zabírají čtyři pozice.
- Šířka je uložena v save a předána klientům před registrací na lištu. Prefab/save identity, vlastní názvy, Setting a lakování zůstávají. Cena výroby nadále dva běžné Module kity; prostorová cena jsou čtyři pozice.
- Small stále odpovídá původnímu malému transformátoru: 5000 W maximum, 100 W běžný krok a 10 W s C/modifikátorem. Pasivní tooltip je krátký, vysvětlení je ve F1. Šedá výplň za vinutím, úzké hitboxy kolečka i zachovaný zvukový zdroj zůstávají.
- U pojistky je hitbox vložení/vyjmutí rozšířen do hloubky až k zadní stěně kapsy, se stejným čelním obrysem otvoru. Vyplňuje vnitřek i polohu vložené pojistky. Jistič si zachovává mělký čelní hitbox.
- Ověřena skutečná geometrie, rovnoměrný převod původního krytu, volné/obsazené pozice, absence překrytí sousedů, XML/šířka/Setting a pořadí síťové registrace. Skutečný Unity běh ještě zbývá ověřit.

## Změny 1.0.48

- Modul se jmenuje DIN Transformer (Small) a používá přímo šablonu malého herního transformátoru: maximum 5000 W, běžný krok 100 W a jemný krok 10 W s modifikátorem množství (výchozí C). Nativní Setting, Labeller, pohyb a synchronizace zůstávají. Dřívější uložené nastavení nad 5000 W nativní setter při načtení omezí na 5000 W. Identita prefabu a save typu se nemění; přejmenuje se pouze starý výchozí název, vlastní názvy zůstanou.
- Za vinutím je souvislá uzavřená šedá výplň se šedými boky. Přidává se až po vyříznutí otvoru, aby následné řezání neodstranilo viditelnou zadní plochu. Kryje i rohy otvoru a nezasahuje do skutečné geometrie vinutí.
- Obě poloviny klikací plochy kolečka jsou pouze 2 mm hluboké na předním čele. Výběrový rámeček nepřidává nativní 1 cm kolem každé poloviny; odpovídá skutečnému kolečku, ne vinutí nebo okolní desce. Nativní zvuková inicializace z 1.0.47 zůstává zachována.
- Pasivní tooltip při míření na tělo ukazuje pouze název a Output ve wattech. Vysvětlení IN/OUT, limitu, použití a kroků je ve F1. Ovládací tooltip regulátoru používá původní herní stručné informace včetně aktuální klávesy modifikátoru.
- Ověřeno pokrytí zadní stěny ve 100 místech včetně rohů, odstup šedých stěn od vinutí, zúžené hitboxy, přesný výběr, nativní kroky a omezení staršího nastavení. Skutečné vykreslení/ovládání je třeba potvrdit ve hře.

Následující oddíly jsou historie; dřívější zmínky o maximu 50 kW jsou nahrazeny specifikací Small výše.

## Změny 1.0.47

- Opravena konkrétní výjimka z herního logu: GameAudioSource.Init → Thing.InitAudio → DinTransformer.Awake. Při výměně modelu se smazal nativní objekt PoweredAudio, ale seznam AudioSources stále obsahoval jeho komponentu. Pád nastával před dokončením registrace rendererů, navázáním kolečka i BoardStructureHooks; úprava samotných barev proto nestačila.
- Zvukové objekty se nyní zachovají a před odstraněním starého modelu přesunou přímo pod DIN modul. Zůstávají původní kanály, komponenty, filtry, metadata a nastavení; zvuk se nevypíná ani nesupluje novým. Zdroje jsou umístěny uprostřed DIN těla.
- Regresní test přehrává skutečné nativní metody InitAudio, GameAudioSource.Init a Transformer.Awake v testovacím prostředí hierarchie: původní odstranění zdroje vyvolá chybu, zachování zdrojů umožní doběhnout inicializaci rendererů, kolečka a lišty. Skutečný Unity běh je ještě potřeba ověřit.
- Interakční hitbox běžného jističe kopíruje jeho přední šedou plochu (35.1 × 60.75 mm), s hloubkou jen 7.13 mm místo původních 54.05 mm. Pojistkový držák používá rozměr svého čelního rámečku (27.99 × 59.265 mm), hloubku 2.3 mm. Svorkové šrouby již nespadají do ovládací oblasti.
- Zelený výběrový rámeček těchto dvou ovladačů nepřidává nativní 1 cm na každou stranu. Výběr používá přesnou velikost cíle při zachování identity a orientace interakce. Ostatní ovladače a celé stavební kolize zůstávají. Vložení/vyjmutí pojistky i přepnutí jističe používají dosavadní akce.
- Model, vinutí, kolečko, atlas, výkonová pravidla a oprava barvení z 1.0.46 jsou zachovány. UnityEngine.AudioModule je pouze reference na DLL instalované hry; do modového ZIPu se nekopíruje.

## Změny 1.0.46

- DIN Transformer je nově zapojen do společných obsluh CabinetAppearance stejně jako jistič: potlačení obecné nativní registrace, vlastní registrace rendereru pláště, lakovatelná pouze role 1 a obnova pevných barev po SetCustomColor a UpdateAllMaterialPropertyBlocks. Samotné nastavení bílé při tvorbě prefabu ve starší verzi nestačilo.
- V registraci pro nativní barvení je pouze tělo. Čelo, vyexportované vinutí, kolečko a černý oblouk zůstávají samostatně, s původním atlasem a beze změn.
- Stejně jako jistič má i transformátor BodyPaintVersion v save. Staré transformátory bez této značky při prvním načtení převedou dřívější skrytou barvu na bílou; po uložení verze 1 se další záměrné lakování včetně modré zachová. Setting, název a umístění se nepřepisují.
- Model, materiálový atlas, pohyb, IN/OUT, maximální výkon a účtování energie jsou beze změny proti 1.0.45.
- Ověřeno testem skutečných větví registrace/barvení a migrace: plášť bílý nebo hráčem zvolený, rámeček a svorky podle pevných rolí, reference mimo barvení, starý save bílý a nový úmyslně modrý zůstává modrý. Ověření v běžící hře ještě zbývá.

## Změny 1.0.45

- Vlastní dvoupozicové tělo jističe nyní skutečně používá geometrii z dodaného exportu malého transformátoru: celé vinutí (180 trojúhelníků), celé kolečko (96) a černý oblouk stupnice (11). Zůstaly přesné vrcholy, UV, zkosení, návraty vinutí a jeden rovnoměrný rozměrový převod .195. Žádné náhradní příčky, zjednodušený disk nebo tečky.
- Geometrie i původní atlas jsou zabalené v modových assets s vlastní instancí materiálu; žádný přístup k souborům AppData ani vyhledávání nativního meshe/materiálu za běhu. Kolečko je přemístěné doprostřed, ON/OFF tlačítko není přidáno.
- Čelo a tělo mají skutečný prostor pro zapuštěnou část vinutí a uzavřený tmavý podklad. Viditelné oblé návraty se neřežou o původní plnou stěnu.
- Vykreslování těla je nastaveno stejně jako u jističe na Standard, s počátečním bílým DiffuseIndex. Předchozí verze si ponechala režim z nativního transformátoru; nešlo tedy o stejnou konfiguraci jako u jističe. Záměrné pozdější lakování zůstává. Opravu samovolné modré je třeba potvrdit v herním běhu.
- Obě klikací poloviny kolečka mají vlastní umístění, vyplněné interakční Bounds a explicitní PrimaryAction. Běžný/jemný krok jsou přepočteny z poměru malého trafa na dosavadní maximum 50 kW: 1000/100 W, tedy 6.4°/0.64° na klik. Předchozích 100/10 W znamenalo jen 0.64°/0.064°. Setting, Labeller a synchronizaci stále řídí původní třída Transformer.
- Zachována identita prefabu/save typu, dva kity, dvě DIN pozice, maximum 50 kW, IN/OUT, pravidla výkonu i absence ON/OFF přepínače. Nová ikona a blueprint odpovídají skutečně sestavené geometrii.
- Ověřena přesná topologie/UV/délky hran po rovnoměrném měřítku, geometrie a native click/Setting/rotace v testovacím prostředí. Blender náhled není herní screenshot; interakce a barvu je nutné potvrdit ve hře.

Následující oddíly jsou historie; aktuální použití skutečných exportovaných dílů nahrazuje předchozí přibližnou geometrii.

## Změny 1.0.44

- DIN Transformer má přímo ve hře vlastní dvoupozicové tělo ze sdíleného modelu jističe. Bez páčky, jejích držáků a horní diody; IN je nahoře, OUT dole.
- Vlastní čelo na šedé ploše: jednoduchá šedá deska, šest měděných žeber vinutí a vystouplé tmavé kolečko uprostřed nad vinutím. Tvarová reference je skutečný export StructureTransformerSmall od uživatele. Žádný nativní mesh transformátoru ani jeho textura se do modelu nevkládá.
- Kolečkem otáčí původní Transformer.SetKnob podle Setting v rozsahu -160 až +160 stupňů. Levá polovina kolečka snižuje limit, pravá jej zvyšuje; jemný krok a Labeller zůstávají. Kroky 10/100 W odpovídají malému transformátoru.
- Žádný ON/OFF přepínač ani skrytý vypnutý stav. Setting = 0 zastaví přenos; bez zdroje na IN není energie na OUT. Dřívější uložené OFF se na této variantě neuplatní.
- Zachována identita prefabu/save typu, dva běžné kity, dvě DIN pozice, ukládání/synchronizace Setting a dosavadní maximum 50 kW. Změna modelu nezkracuje rozsah již uloženého nastavení. Datová a výkonová pravidla zůstávají.
- Skutečné horní/dolní kabelové vstupy sdílejí geometrii jističe. Cílení na přední šrouby je oddělené od polohy kabelových vstupů. Existující vodiče se přetrasují atomicky se zachováním spojení a množství kabelu.
- Nová F1 ikona a blueprint jsou ze skutečné produkční geometrie. Offline náhled je Blender render; herní vykreslení a interakce je ještě potřeba ověřit.
- Exportní build 1.0.43 splnil účel. Automatický export transformátoru v této verzi neběží.

Následující oddíly popisují historii; aktuální vlastní model a odstranění ON/OFF je popsáno výše.

## Změny 1.0.41

- Přidán **DIN Transformer** za dva běžné Switchboard Module kity, zabírá dvě DIN pozice. Původní moduly a jejich identity zůstávají.
- Používá přímo herní třídu `Transformer`: nativní Setting, maximum, běžný/jemný krok, ručičku, +/- ovládání a Labeller. Model, UV, materiály, ukazatel, stav přepínače a kolidery se přebírají z instalované hry a celek se rovnoměrně zmenší do DIN prostoru. F1 používá původní ikonu transformátoru. Žádná změna skutečného napětí.
- Vnitřní vodiče IN → OUT přenášejí nejvýše nastavený výkon a dostupnou energii. Překročení limitu omezí dodávku, transformátor netripuje. Při rozdělení OUT mezi více výstupů rozvaděče platí jeden společný limit; sériové transformátory i společné externí/bateriové zdroje jej nesčítají. Upstream jistič/pojistka dál měří skutečný přenos.
- Započítané je také nabíjení a vybíjení baterie přes transformátor, rezervace nativních dotazů na výkon a účtování odebrané energie.
- Datové sítě IN/OUT se nepřemosťují. Transformátor lze najít a nastavovat přes Net na jeho vstupní straně. Core napájený za transformátorem potřebuje skutečnou navazující výstupní kabelovou síť; jeho nativní odběr pak prochází limitovaným výstupem, nikoli přímo vstupem rozvaděče.
- ON/OFF a Setting používají původní ukládání a synchronizaci transformátoru; doplněno je pouze umístění na DIN liště. Vratka kabelů při demontáži zachová běžná pravidla. Ruční ovládání vyžaduje otevřenou skříň a sejmutý vnitřní kryt.
- V rozvětvení, které stejný externí výstup napájí současně přes transformátor i paralelní cestou mimo něj, bridge používá konzervativní společný limit; samostatná výstupní větev mimo transformátor má vlastní rozpočet bez jeho limitu.
- Ověřeno sestavením a automatickými kontrolami přenosu/rezervací, uložení modového save typu a přemapování nativních animovaných částí. Skutečný model instalované hry, ovládání a multiplayer vyžadují ověření ve hře; toto není záznam úspěšného herního testu.
- Zdrojový ZIP vynechává odvozený výsledek fyzikálního skládání `Art/ModuleKit/pile-settled.json`; finální produkční mesh je přiložen a mezivýsledek lze obnovit pomocí `Tools/build_kit_pile.py ModuleKit` (Blender/Pillow). Dosavadní generované geometry fixtures se obnovují svými extract skripty.

## Změny 1.0.40

- Přidán DIN Contactor (NC), samostatná varianta za jeden běžný kit a jednu DIN pozici. Původní stykač zůstává.
- Nahoře IN a A1, dole NO vlevo / NC vpravo při pohledu zepředu. Bez signálu vede IN → NC, se signálem IN → NO. Bez napájení IN nemá napájení ani jeden výstup; A1 nepřenáší napájení do silové cesty.
- Stejný model, šoupátko, animace a zvuky; dvě dolní svorky a kruhové kabelové vstupy.
- NC vazby se vyhodnocují atomicky jednou za obnovu obvodu; zapojení přerušující vlastní cívku může kmitat.

## Změny 1.0.39

- Stykač zjednodušen do stylu jističe: jedno tmavé čelo a jedna souvislá zapuštěná vana, bez dalšího nasazeného rámečku a krátkých překrývajících se lišt.
- Boční vodicí drážky jsou součástí souvislých stěn. Hrany vany přesně navazují na otvor v čele; žádné vystouplé konce stěn u rámečku.
- Světlé šoupátko, čitelné ON/OFF, rozměry sestavy, animace 0,2 s, zvuky a elektrické funkce zachovány.

## Změny 1.0.38

- Stykač: podklad, stěny i vodicí drážky mají jednotnou tmavou barvu. Světle šedé zůstává pouze šoupátko, zelené ON a červené OFF vystupují z tmavého okolí.
- Okénko je zkrácené podle koncových poloh jezdce, celá sestava je větší a vyplňuje většinu čela. Proporce původních nápisů ON/OFF zachovány.
- Zapuštění, skutečné boční vedení, 0,2s přesun, zvuky a elektrické funkce beze změn. Jističe zachovávají vzhled z 1.0.37.

## Změny 1.0.37

- Stykač: skutečně zapuštěné okénko se světlejší šedou podlahou/stěnami. Širší šoupátko má kraje zasunuté do obou bočních vodicích drážek. Původní proporce ON/OFF, 0,2s přesun a zvuky beze změn.
- Jističe: původní úchyty mají uzavřené vnější boky i spodní plochy, stejný tvar a polohu, ale světlejší jednotnou šedou. Tmavý podklad za páčkou je širší, bez bílých bočních ploch.
- Zachované kulaté průchodky, nízká kontrolka jističe a oprava stavebního náhledu. Elektrická funkce a uložená data beze změn.

## Změny 1.0.36

- Stykač má neporušené zaoblené tělo stejného základu jako jistič, dvě kulaté horní průchodky a žádnou prostřední. Hladké ploché čelo bez vnitřních schodů a úchytů páčky.
- Původní APC ON/OFF zachovává poměr stran a je na rovných barevných plochách pod menším šoupátkem; 0,2s animace a SwitchOn/SwitchOff beze změn.
- Jističe přebírají originální APC úchyty ke krajům páčky v původním materiálu/barvě. Horní kontrolka je nízká, téměř zapuštěná do čela.
- Opraven NullReferenceException v DinContactorView při stavebním náhledu: kurzor neprovádí obnovu odstraněných rendererů, částečně vytvořené vizuály bezpečně přeskočí.

## Změny 1.0.35

- Menší mechanické šoupátko s jediným vystouplým úchopem, bez dvojice žeber. Původní APC rámeček zůstává dlouhý, vnitřní ON/OFF jsou blíž středu a dráha kratší.
- Animace přesunu 0,2 s. Elektrické sepnutí i zvuk reagují okamžitě na skutečný stav A1.
- Souvislá tmavá vana a boční stěny kolem okénka zakrývají bílé vnitřní hrany. Zadní stěna uzavírá průhled mezi dvěma horními svorkami; šroubky i konektory zůstávají na místě.

## Změny 1.0.34

- DIN Contactor přebírá přímo dlouhé původní APC okénko včetně ON/OFF, původních UV a materiálu. Vyplňuje většinu tmavého čela; šedé plastové šoupátko s příčným úchopem zakrývá vždy opačný stav. Není ručně ovladatelné.
- Popisky kontaktů IN/A1/OUT a jejich štítky odstraněny z modelu. Elektrické konektory zůstávají na původních místech.
- Zvuk stykače nově používá nativní SwitchOn / SwitchOff. Jističe nadále používají APC zvuky. Bez diody, skutečný stav cívky A1, 1 DIN pozice.

## Změny 1.0.33

- Klasický DIN Contactor má zapuštěné mechanické okénko: barevné šoupátko ON (zelená) / OFF (červená) sleduje skutečné sepnutí cívky A1. Bez diody a bez ruční páčky.
- Při změně kontaktu se šoupátko přesune a jednou zahraje nativní zvuk APC On/Off. Načtení, připojení klienta a náhled jsou bez cvakání.
- Tělo, tmavé čelo, IN/A1/OUT, 1 DIN pozice a elektrická funkce zůstávají kompatibilní se stávajícími uloženými moduly.

## Změny 1.0.32

- Tmavá čela a horní proužky NET a Output mají společnou výšku: popisky, diody i podsvit jsou zarovnané. Output zůstává na svém místě; proužek NET se posune přibližně o 2,6 mm výš.
- Původní šroubek housingu je zvětšený na 16 mm a posunutý asi o 4 mm výš. Hlavička vystupuje přibližně 3,2 mm před čelo; dno drážky už neleží pod čelem modulu. Zepředu je tak vidět i spojení obou polovin hlavičky.
- Těsný hitbox a shodné zvýraznění se šroubovákem i bez něj se přizpůsobí novému rozměru a poloze.

## Změny 1.0.31

- Nad displejem je stejný proužek, dioda, bílé písmo a styl jako na NET modulu, s nápisem **Output**.
- Dioda při zapnutém/napájeném Core: **oranžová** bez vodiče z OUT na A1 klasického stykače, **červená** s vodičem a rozepnutým výstupem, **zelená** s vodičem a skutečně napájeným výstupem. Core vypnutý/bez napájení: **zhasnutá**.
- Barva nezávisí na silovém IN stykače. Ukazuje stav řídicího OUT/A1, nikoli napájení spotřebiče.
- Šroubek má nyní 14 mm místo 10 mm; tvar, drážka, UV a materiál původního housingu zůstávají. Je zapuštěný a hitbox pokrývá jen viditelnou hlavičku s 1 mm rezervou po obvodu.
- Obě cesty ovládání (namíření bez nástroje i se šroubovákem) zvýrazňují stejný malý cíl. Nevzniká obrys celého modulu ani nativní 10 mm okraj kolem interakce. Kliknutí na displej či vedle hlavičky adresu nemění.
- Přepínání adres stále vyžaduje šroubovák, otevřený kabinet a sejmutý kryt; obsazené adresy se přeskakují a změna adresy vypne příkaz On.

## DIN Smart Output Module

- 1 Smart kit, **2 DIN pozice**. Přisedá nalevo do souvislé řady rozšíření Core.
- **Žádný IN ani DATA.** Napájení i povely bere z Core přes boční sběrnici.
- Jediný spodní **OUT lze zapojit pouze na A1 klasického DIN Contactoru**. Nelze jej spojit s přímým spotřebičem, silovým IN, jiným Outputem ani bridge.
- Až šest soukromých adres d0–d5; NET adresy nezabírá. `db` je dál Core.
- `s d0 On 1` napájí A1, `s d0 On 0` jej vypne. Core OFF, ztráta napájení, přerušená sběrnice nebo neplatná adresa OUT odpojí.
- Příkaz On se ukládá a po návratu Core může výstup opět zapnout. Nejde o bezpečnostní blokování restartu.
- Ploché čelo: nahoře stavová dioda s nápisem Output, uprostřed **stejný původní LED rámeček, podklad a číslice jako na Core**. Dole je skutečný šroubek z IC Housingu (83 vrcholů, 40 trojúhelníků, původní UV a materiál), zapuštěný do čela s vlastním hitboxem. Bez velkých IN/OUT/ON nápisů.
- Displej adresy svítí při napájeném/zapnutém Core i při příkazu Output OFF. Zelená dioda svítí pouze při napájeném OUT. Bez Core displej i dioda zhasnou, adresa zůstane uložená.
- Šroubovákem pouze na hlavičce šroubku vybereš další volnou adresu. Obsazené přeskočí; změna nejdřív vypne příkaz On. Otevři kabinet a sejmi kryt.
- Native odběr ovládání je 5 W při příkazu On. Klasická cívka zatím samostatný odběr nemodeluje; jde o dosavadní binární detekci napájení A1.

## DIN Contactor

- 1 běžný kit modulů, 1 DIN pozice, libovolné volné místo na liště.
- Původní dlouhé APC okénko s pevným ON/OFF a pohyblivým šedým šoupátkem, nativní SwitchOn/SwitchOff. Bez diody, ručního ovládání a popisků kontaktů na modelu.
- IN vlevo nahoře, OUT dole, A1 vpravo nahoře. Napájený A1 sepne samostatnou silovou cestu IN → OUT.
- A1 může napájet PLC Output **nebo obyčejné tlačítko/vypínač**. Žádná datová logika.
- Silovou větev chraň jističem/pojistkou. Výkon spotřebiče neprochází PLC Outputem a A1 se silovou cestou nespojí.

```ic10
loop:
s d0 On 1
sleep 5
s d0 On 0
sleep 5
j loop
```

## Přechod ze starších verzí

Identita prefabu a adresy Smart Outputů zůstávají. Staré jednomístné kusy se při načtení rozšíří na dvě DIN pozice, pokud je za souvislou řadou jejich rozšíření dost místa. Core a vnitřní NET zůstávají na místě; vnější NET/Output moduly stejné sběrnice se posunou ven. Adresy zůstanou a trasy vodičů se přepočítají. Cizí moduly se neposouvají ani nemažou; záměrné mezery ve sběrnici se nespojují. Bez volného místa zůstane starý kus dočasně úzký a vypíše diagnostiku. Uvolni místo na konci řady a ulož/načti, případně Output přestav na volné dvě pozice. Nové kusy vždy vyžadují dvě pozice. Malá lišta má 7 pozic: Core (4) + Output (2) + jeden NET (1) ji zcela zaplní; další NET vyžaduje větší kabinet/lištu. Starý IN, DATA a OUT vedený jinam než na A1 se po načtení vrátí jako kabel. Tyto vodiče do té doby nevedou proud. Silový okruh přepoj přes klasický stykač. Platný OUT → A1 zůstane zachován.

Reference IC Housingu byla úspěšně získána a je uložená ve zdrojácích. Automatický export housingu byl odstraněn. Model klasického stykače je zatím provizorní. Ikonka Outputu odpovídá novému dvoumístnému tělu a nativnímu panelu Core. V multiplayeru musí mít všichni stejnou verzi. Při připojení klienta se šířka obnoví před registrací buněk lišty. Build a místní kontroly nenahrazují ověření nového modelu a migrace přímo ve hře.

## Zachované moduly

Dioda je zhasnutá, když je Core vypnutý, bez napájení nebo chybí spojení s jeho boční sběrnicí. Pokud je Core napájený a zapnutý, je oranžová bez vybrané datové sítě a zelená s ní. Není závislá na tom, zda právě běží program nebo se přenáší data. Po obnovení napájení se barvy vrátí podle každého Outputu. Ověřené propojení sítí a přístup počítače zůstávají; žádný Channel0 se nepoužívá.

Opraven je případ při zapínání spotřebiče na druhé větvi. Dosavadní dělení mohlo dát veškerou nabídku výkonu větvi s již známým odběrem a nulu druhé větvi, která ještě hlásila nulový odběr. Přívod měl přitom rezervu. Nově se nejdříve pokryjí známé požadavky a zbývající výkon se rozdělí mezi živé větve. Při nedostatku zdroje zůstává poměr podle požadovaného odběru. Součet nabídek nepřekračuje dostupný přívod; již přislíbený externí výkon se rezervuje při čekajících nativních dotazech. Vypnuté nebo nepřipojené větve nedostávají výkon. Jističe nadále reagují na skutečný odběr a baterie nepřidávají ani neztrácejí energii. Běžná prodleva nativního power ticku a IC programu zůstává; skutečný čas zapnutí je potřeba ověřit ve hře.

Opraven je také displej zůstávající na RUN po zápisu stejného Setting, jaké už bylo uložené. Nativní IC10 v takovém případě přeskočí SetLogicValue, takže Core po nahrání nového programu nerozpoznal požadavek zobrazit vlastní hodnotu. Úzká úprava store instrukcí s/sd/sb/sbn nyní zaznamená zápis Setting do Smart Core i při shodné hodnotě. Hodnota čtená z Setting se nemění, obyčejné čtení nezapíná vlastní displej a ostatní herní zařízení se nemění. Pokud se nativní struktura instrukce v jiné verzi hry změní, úprava se vynechá s diagnostikou. Výchozí RUN, přednost chyby a původní Mode/Setting/Color zůstávají.

Příklad, který má po nahrání zobrazit OTAS (i při opakovaném nahrání):
```ic10
loop:
s db Mode 10
s db Setting STR("OTAS")
yield
j loop
```
Číselná hodnota funguje stejně s Mode 0; nula je platná hodnota. Volitelná Lua není povinná závislost a její běžné přímé zápisy se nemění.

Ověření mimo Unity: Release build bez chyb a varování, 73 kontrol PLC/stavu diody, 16 kontrol rendereru diody, 42 kontrol displeje/store úpravy, kontroly rozběhu a rozpočtu výkonu včetně 2023 bateriových kontrol a kontrol ochrany/tří větví, a aktualizované F1 hledání. Přesný vzhled, skutečnou prodlevu a běh Harmony úpravy v Unity je ještě potřeba potvrdit ve hře. Po aktualizaci úplně restartujte hru, host i klient musí mít stejnou verzi.

## Předchozí verze

# Modular Switchboards 1.0.10

Další oprava barev Smart Output LED po hráčově snímku, na kterém zůstala bílá i v 1.0.9. Indikátor nově používá nativní herní materiál a barevnou paletu, stejně jako indikátory jističů, místo obecného Standard shaderu. Jeho vlastní kopie kulové geometrie dostává skutečné nativní UV souřadnice. Výchozí materiál má oranžovou barvu nastavenou už při vytvoření prefabu.

Matná úprava rozvaděče už živý materiál Output diody nenahrazuje kopií. Ovladač navíc vrátí svůj materiál na renderer, pokud jej jiný průchod vymění. Barva palety se zapisuje do materiálu i obou úrovní property bloků; zelená při dostupné datové síti, oranžová bez ní. AQ, propojení, cena, napájení a IC chování zůstávají stejné.

Pro ověření přímo ve hře vznikne při prvním běhu indikátoru a změně spojení jediný řádek logu Smart Output LED s ID modulu, stavem green/orange, shaderem a verzí. Díky tomu lze rozlišit nespuštěný ovladač od překresleného materiálu. Nejde o opakované logování v každém snímku. Hráč potvrdil, že počítač Core vidí; datovou logiku tato verze nemění.

Ověření: Release build bez chyb a varování, 12 kontrol LED ovladače a kontroly matných materiálů včetně zachování identity živé diody a matného těla. Kontroly běží mimo Unity; předchozí snímek prokázal, že samotný test property bloků nepokrývá výsledný herní render. Konečnou barvu je nutné potvrdit ve hře po úplném restartu s touto verzí.

## Předchozí verze

# Modular Switchboards 1.0.9

Oprava bílé stavové diody Smart Outputu. Barva a emise se nyní zapisují do vlastního materiálu instance, renderer-wide bloku i přímo do materiálového slotu 0. Slotový blok má v Unity přednost; samotný zápis na renderer nestačil proti bílé nativní výjimce.

Vzhled se obnovuje v každém LateUpdate i tehdy, když se připojení nezměnilo. Dřívější vynechání při stejné barvě mohlo ponechat následný bílý přepis. Vyhodnocení datového spojení stále běží jen po 0,15 s. Ovladač také zkusí znovu navázat renderer, pokud při aktivaci ještě nebyl dostupný. Každý Output má vlastní materiál, který se při odstranění uvolní. Odlesky diody jsou vypnuté, aby malou zelenou/oranžovou plochu nepřekrýval bílý lesk.

Význam se nemění: oranžová bez dostupného datového spojení, zelená s připojenou sítí. AQ, spodní DATA kontakt, barvení těla a celé datové zapojení zůstávají stejné jako v 1.0.8. Core pořád vidí všechny skutečně připojené Output sítě; žádný Channel0. Hráč potvrdil, že počítač Core vidí; tato verze opravuje pouze vzhled diody.

Ověření: test s bílým per-material blokem selhal na původním kódu. Po opravě prochází 9 kontrol skutečného SmartOutputView proti modelu priorit Unity property bloků: oranžová/zelená, emise, pozdější nativní bílý přepis i před dalším vyhodnocením spojení, oddělení instancí a pozdní navázání rendereru. Release build bez chyb a varování. Nejde o živý Unity render; konečnou barvu je ještě potřeba potvrdit ve hře po úplném restartu.

## Předchozí verze

# Modular Switchboards 1.0.8

Oprava obnovování registrace Core pro počítače na sítích Smart Outputů. Nativní Device.InitializeDataConnection může přepsat skutečné DataCables, PowerCables a primární kabely bez změny interního snímku zapojení. Dosavadní rychlá kontrola pak registraci přeskočila. Core mohl zmizet z DataDeviceList, ze kterého počítač přímo sestavuje IC editor, ačkoli Output měl stále dostupnou datovou síť.

Obnova nyní porovnává i skutečná nativní pole kabelů a síťové ukazatele. Při rozdílu je obnoví, zneplatní seznamy zařízení a oznámí změnu počítačům na všech připojených větvích. Platné napájení se kvůli opravě dat nepřerušuje. Při stabilním připojení se seznam zbytečně neobnovuje.

Výsledkem má být jeden Core v editoru počítače na každé skutečně připojené Output síti. Počítač připojený pouze na silový vstup Core nedostane datový přístup. Bez propojené datové větve se Core do seznamu nepřidává. Žádné globální vyhledávání ani přemosťování sítí se nepřidává. Core dál ovládá všechna zařízení zpřístupněná skutečnými Outputy, bez Channel0. AQ, oranžová/zelená dioda a ceny zůstávají.

Ověření: regrese nejprve selhala na 1.0.7 po simulovaném vymazání nativních datových kabelů; po opravě prošlo všech 67 kontrol PLC. Zahrnují obnovu všech větví i samotné druhé větve, oznámení počítačům, zachování napájení a izolace, bez opakovaného oznamování při stabilním stavu. Release build je bez chyb a varování. Toto je test mimo Unity; příčinu konkrétního hráčova zapojení a skutečný IC editor je ještě potřeba ověřit ve hře.

Po aktualizaci hru úplně restartujte a znovu otevřete IC editor. Host i klient musí mít stejnou verzi. Oranžová dioda znamená nejprve zkontrolovat propojení DATA kontaktu s příslušnou vnější datovou sítí; samotná tato oprava nevytváří chybějící fyzické spojení.

## Předchozí verze

# Modular Switchboards 1.0.7

Smart Output má malé vodorovné označení AQ a jednoduchou kulatou stavovou LED místo velkého svislého DATA. DATA kontakt i kabel zůstávají zespodu; cena a šířka se nemění.

Zelená: modul je připojený souvislou boční sběrnicí ke Core a jeho DATA zapojení vybírá dostupnou nativní kabelovou síť. Oranžová: nezapojený DATA kontakt, chybějící vnější kabel/síť, nejednoznačná větev nebo odříznutí od Core. LED ukazuje spojení, nikoli přenos jednotlivých povelů, běh IC ani napájení spotřebičů. Prázdná, ale připojená datová síť je zelená. Samotné vypnutí jističe nemusí přerušit datovou síť a nemusí změnit barvu.

Tělo lze barvit; AQ štítek a dioda si zachovávají své materiály a stavovou barvu. Malá dioda používá vlastní emisní povrch bez dalšího bodového světla. Každá instance má vlastní stav rendereru. Obnovuje se podle existujícího zapojení včetně připojení/odpojení a načtení; nepřidává nový ukládací typ ani protokol.

Core vidí VŠECHNY datové sítě skutečně zpřístupněné jeho zapojenými Smart Outputy. Je-li připojena jen net 0, net 1 ovládat nemůže. Jsou-li připojeny obě, sb podle hashe může ovládat odpovídající zařízení na obou. Rozsah určuje vnitřní zapojení a nativní sítě. Nepoužívá se ruční Channel0 ani NameHash. Předchozí nevydaný návrh 1.0.7 s volbou kanálu byl zrušen; tato verze znovu vychází z vydané 1.0.6 a zachovává její přístup ke všem dostupným sítím.

Core stále potřebuje vlastní napájení a běžící program; cílová zařízení vlastní přívod. Output nepřemosťuje silové sítě. Výstup jističe dál přijme tři vodiče (pojistkový modul dva). Aktualizována F1 a nápověda Outputu. Po aktualizaci hru úplně restartujte, host i klient musí mít stejnou verzi.

Ověření: Release build bez chyb a varování a 61 kontrol PLC a stavu LED, včetně samostatného odpojení druhé větve, chybějícího kabelu, nejednoznačného zapojení, přerušené sběrnice a nezávislosti indikace na jističovém napájení. Logika dostupných sítí zůstává stejná jako ve vydané 1.0.6. Barvy, odlesky a synchronizaci při skutečné hře je ještě potřeba ověřit v Unity.

## Předchozí verze

# Modular Switchboards 1.0.6

Výstup jističe nově přijme až tři vodiče. Všechny větve sdílejí původní proudový limit jističe; pojistkové moduly zůstávají na dvou vodičích. Router nabízí třetí větev s vlastním odbočením.

Oprava prvního testu PLC: Core nyní čerpá napájení z přívodu rozvaděče podle skutečné průchodnosti vnitřního zapojení. Stačí Input → zapnutý jistič → Core POWER IN, bez zapojené výstupní svorky rozvaděče i bez Smart Output modulu. Otevření jističe napájení Core přeruší. Výběr datové sítě je od napájení oddělený.

Output se připojuje skutečně vlevo při pohledu do rozvaděče. Předchozí verze zaměnila směr místní souřadnice lišty za směr na obrazovce. DATA kontakt i otvor jsou nyní zespodu; logická identita kontaktu zůstává stejná. Uložené vodiče na posunutém kontaktu se při načtení přetrasují. Popisek DATA se podle skutečných rozměrů fontu zmenší do svého štítku.

Outputy postavené vpravo ve verzi 1.0.5 přesuňte rozebráním a novým postavením vlevo; vpravo už sběrnici netvoří. Core, čip a jeho program není třeba mazat. Všechny ostatní ceny a funkce zůstávají: Output 1 Smart kit/1 DIN pozice, více oddělených datových sítí, Core 10 kitů/4 pozice.

Ověření: Release build bez chyb a varování a 53 kontrol PLC a větvení jističe, včetně samostatného Core za jističem bez výstupní sítě, otevření a zavření jističe a opraveného pořadí rozšíření. Vzhled a fungování v Unity ještě musí potvrdit test ve hře. Po výměně modu hru úplně restartujte.

## Předchozí verze

# Modular Switchboards 1.0.5

DIN Smart Core Module je nyní základ modulárního PLC. Core má jen POWER IN; čip a displej fungují lokálně i bez rozšíření. Pro komunikaci s vnější sítí a IC editorem slouží nový DIN Smart Net Module: jedna DIN pozice, jeden Smart kit. Core nadále stojí deset Smart kitů a zabírá čtyři pozice.

Output lze postavit pouze těsně vlevo od Core nebo souvislé řady jeho rozšíření na stejné liště. Přisednutí automaticky vytvoří boční datovou sběrnici. Lze připojit více Output modulů hned; každý může vybírat jinou datovou síť. Core má přístup k jejich zařízením, ale fyzické sítě se neslučují a sběrnice nepřenáší napájení. Nechte vlevo od Core volné místo. Rozebírejte zleva, nejprve rozšíření, potom Core.

Zapojení: napájecí větev přiveďte na Core POWER IN. Spodní DATA kontakt každého Outputu je odbočka vybírající síť, stejně jako dřívější datové připojení Core. Například z výstupu jističe veďte vodič na svorku Output 1 rozvaděče a druhý vodič na DATA modulu; vnější kabel na svorce Output 1 pak určí jeho datovou síť. DATA kontakt nemá vlastní silový výstup. Nejednoznačně zapojený Output neposkytne datovou síť.

Batch operace Core zahrnují dostupné sítě bez duplicit. Přímé ReferenceId funguje pouze pro zařízení těchto sítí. Volitelná Lua může vybírat batch síť pomocí networkIndex: 0 je Output nejblíže Core, 1 další vlevo; nezapojené pozice se nepřečíslují. Lua ic.net zprávy používají první dostupnou datovou síť, nikoli automatické vysílání přes všechny větve. Lua není povinná závislost.

DŮLEŽITÉ pro starší světy: dosavadní vstup Core nyní dodává jen napájení. Pro obnovení přístupu k vnějším zařízením a editoru přidejte Output modul a zapojte jeho DATA kontakt. Identita Core a uložené čipy zůstávají. Přerušení souvislé řady odpojí rozšíření za mezerou; rozšíření se automaticky nemažou. Všichni hráči musí mít stejnou verzi.

F1 popisuje cenu, umístění, napájení a datové větve obou modulů. Displej zachovává původní Mode/Setting/Color, automatické RUN a přednost chyby. Lakování těla a bílého okraje zachovává chráněnou mřížku a patici z 1.0.4.

Ověření: Release build bez chyb a varování; 41 kontrol PLC topologie, autoritativního umístění, více sítí, izolace napájení, odpojení a obnovení registrace; dále kontroly F1, displeje, názvů a registrace ukládacích typů. Nejde o test uvnitř Unity: umístění, vzhled, načtení celého PLC a multiplayer je ještě potřeba ověřit ve hře po úplném restartu.

## Předchozí verze

# Modular Switchboards 1.0.4

DIN Smart Module se nyní jmenuje DIN Smart Core Module. Prefab, jeho hash, typ a uložená data zůstávají stejné. Při načtení se staré výchozí názvy Smart Module a DIN Smart Module převedou na DIN Smart Core Module; vlastní názvy hráče zůstávají. Nový název je i ve F1, nabídce stavby, IC editoru a nápovědě vodiče. Rodinný Kit (DIN Smart Modules) se nepřejmenovává.

Barví se pouze tělo a vnější rámeček displeje. Předchozí úprava chybně sloučila všechny materiálové části rámečku do jedné lakované plochy a nativní Thing.SetCustomColor navíc přepisoval mřížku a patici i bez jejich explicitního paint mappingu. Nově se z původní geometrie vyčlení pouze bílé trojúhelníky okraje. Tmavý podklad zachovává vlastní původní UV a materiály; samotná LED mřížka má původní materiál z originálního displeje.

Seznam rendererů pro barvení Smartu obsahuje jen tělo a lakovaný bílý okraj. Plocha displeje, tmavé detaily a patice jsou vyřazené a jejich původní materiály se obnovují včetně odstranění zděděné globální barvy a emise. Vložený čip a jiné objekty se nemění. Původní rozměry rámečku i rozmístění znaků zůstávají.

Nativní Mode/Setting/Color, vlastní hodnoty a přednost oranžové chyby z 1.0.3 zůstávají. Cena je stále 10 Smart kitů s elektrem a čtyři DIN pozice.

Ověření: Release build bez chyb a varování, 19 kontrol oddělení lakovaných a původních povrchů (geometrie, UV, grid, patice, zděděná emise, jiné objekty), 10 kontrol přejmenování bez změny identity/vlastních názvů a 75 kontrol F1 katalogu. SmartModule a ukládací logika jsou beze změny. Vzhled opraveného podkladu a patice je třeba potvrdit ve hře po úplném restartu s touto verzí.

## Předchozí verze

# Modular Switchboards 1.0.3

Smart zůstává IC housingem. Při běhu používá displej původní LED nastavení Mode, Setting a Color: 0 = číslo, 10 = ASCII text a ostatní původní režimy zachovávají své jednotky a čísla. Formátování přebírá přímo nativní LogicDisplay. Dokud program nezapíše Setting, je vidět zelené RUN. Přidaný poslední režim 17 (Automatic RUN v aktuální hře) obnoví RUN bez změny uložené hodnoty Setting. Nula v číselném režimu je platné číslo, nikoli reset.

IC10 číslo:
```
s db Mode 0
s db Setting 42.5
```
IC10 text:
```
s db Mode 10
s db Setting STR("HELLO")
```
Návrat na RUN: `s db Mode 17`. Color používá původní herní indexy barev a mění pouze vlastní zobrazovanou hodnotu. Barva lakovaného těla a rámečku zůstává samostatná. Znaky čerpají vlastní emisní materiál; nemění povrch jističe.

Při chybě má vždy přednost oranžové ERR s řádkem, nad 999 ERR--- a plný detail v nápovědě. Žádná hodnota, Mode ani Color chybu neschová. Po odstranění chyby se vlastní hodnota a její barva obnoví. Bez proudu je displej prázdný, mimo běh zůstává IDLE. Výměna čipu nebo nahrání nového programu vrací výchozí RUN, dokud program znovu nezapíše Setting.

Text STR podporuje do šesti ASCII znaků; u širokých znaků se text ořízne podle skutečného počtu pixelů, bez zmenšování. Pokud číselný formát nebo údaj s jednotkou přesahuje displej, místo zavádějícího uříznutého čísla se ukáže OVR. Skutečné Setting lze dál přečíst přes logiku. Native LED režimy i znaky s jednotkami se zachovávají.

Volitelná Lua používá stejné rozhraní:
```lua
ic.write(ic.const.BASE_UNIT_INDEX, ic.enums.LogicType.Mode, 10)
ic.write(ic.const.BASE_UNIT_INDEX, ic.enums.LogicType.Setting, ic.ascii.pack6("HELLO"))
```
Pro čísla použijte Mode 0 a numerické Setting. Lua mod není závislost; běžný IC10 funguje samostatně. Aktualizované příklady jsou v Examples/DinSmartModule.lua, DinSmartModule.ic10 a DinSmartValues.ic10.

F1 má původní LED tabulku režimů včetně nového Automatic RUN, čtení/zápis Mode/Setting/Color, vysvětlení přednosti chyby a konkrétní příklady IC10 a Lua. Příznak vlastního displeje a jeho barva se ukládají i přenášejí klientům. Staré světy bez nových položek se načtou s automatickým RUN; hodnoty Setting se nemažou. Pro multiplayer musí mít host i klient stejnou verzi.

Obsahuje lakovatelný rámeček se stejným materiálem a povrchem jako tělo jističe z 1.0.2. Plocha displeje a svítící znaky zůstávají oddělené. Smart vyžaduje dál 10 samostatných Smart kitů s elektrem a zabírá čtyři pozice.

Ověření: Release build bez chyb a varování. 30 kontrol integrovaného displeje nad extrahovanými produkčními metodami: default RUN, číslo/0/záporná hodnota, text, původní procenta/jednotky, barva, přednost a obnovení po chybě, staré/nové XML, síťové rámování a připojení do hry, nový čip a nový program. Dále 32 stavových kontrol, 12 kontrol barvení, 15 kontrol volitelného Lua adaptéru a 74 kontrol F1 katalogu. Nativní renderer a VM jsou v testech nahrazené fixture; potvrzení skutečného vykreslení, barvy rámečku a Lua ve hře zbývá.

## Předchozí verze

# Modular Switchboards 1.0.2

Rámeček LED displeje DIN Smart Module se nyní barví spolu s tělem modulu stejným povrchem jako jistič. Původní tvar rámečku zůstává; jeho samostatný bílý povrch byl přemapován na lakovatelnou roli těla. Registrace barvení, obnova barvy a matná úprava zahrnují i NativeLEDBezel, takže změna používá stávající ukládání a síťovou replikaci barvy Smartu.

Plocha displeje, zelené RUN, oranžové ERR/ERR---, patice a vložený čip se tím nepřebarvují. Ostatní moduly ani původní LED displeje se nemění. Vlastní Smart kit s elektrem a cena 10 Smart kitů zůstávají.

Ověření: Release build bez chyb a varování, kontrola oddělení rámečku a screen/glyph rendererů a mapování stejné barvy jako tělo. Živý vzhled, přebarvení existujícího Smartu a barvu po načtení je třeba potvrdit ve hře.

## Předchozí verze

# Modular Switchboards 1.0.1

Smart prvky mají samostatný Kit (DIN Smart Modules), zatím s původním modelem a ikonou Logic Kitu. Běžný Kit (Switchboard Modules) staví jističe, pojistkové držáky, bateriové a měřicí moduly; Smart už v jeho výběru není. Nový kit má vlastní nabídku, záznam ve F1 a vyhledávání. Kontrola správného kitu probíhá jak při umisťování, tak na serveru.

DIN Smart Module spotřebuje 10 Smart kitů a stále zabírá čtyři DIN pozice. Electronics Printer vyrábí jeden Smart kit z 2 g železa, 1 g mědi a 1 g elektra. Celý Smart tedy vyžaduje 20 g železa, 10 g mědi a 10 g elektra. Recept běžného DIN kitu zůstává 2 g železa + 1 g mědi. Existující moduly se nemažou; při další stavbě či demontáži používají aktuální stavební definici se Smart kity.

Vlastní vzhled kitu ani další Smart moduly zatím přidané nejsou. Lua zůstává volitelná a běžný IC10 ji nepotřebuje. Autor KreeZy.

Ověření: Release build bez chyb a varování, 14 kontrol správného kitu/odmítnutí cizího kitu na klientovi a serveru, rozměru a receptu s elektrem. Ověřeno také F1 vyhledávání, samostatné odkazy a opakovaná registrace. Živou výrobu, stavbu, demontáž a načtení světa je nutné potvrdit ve hře.

## Předchozí verze

# Modular Switchboards 1.0.0

Vydání 1.0 obsahuje ranou verzi DIN Smart Module: programovatelný housing s integrovaným stavovým displejem, nativním IC10 a volitelnou podporou Lua.

Postavení jednoho DIN Smart Module nyní vyžaduje 10 DIN kitů namísto dosavadních 4. Základní suroviny a výrobní recept samotného kitu ani cena ostatních modulů se nemění. Smart stále fyzicky zabírá čtyři DIN pozice; počet spotřebovaných kitů je oddělený od jeho rozměrů. Existující postavené moduly nemají žádný doplatek. Spouštěcí kontrola registrace ověřuje i cenu Smartu. F1 popis Smartu i popis Kit (Switchboard Modules) přebírají cenu ze stejné konstanty jako stavba: 10 kitů, čtyři fyzické pozice.

Ověření: Release build bez chyb a varování, kontrola požadovaného množství v definici stavebního stavu. Spotřebu ve hře je potřeba potvrdit. Obsahuje také opravu spreje z 0.13.110.

F1 logické hodnoty: Smart nenabízí Mode ani Color a nyní neuvádí ani zděděný seznam režimů LED. Setting a LineNumber zůstávají čitelné/zapisovatelné hodnoty housingu; Setting nemění stavový displej. Nativní informace o napájení, zapnutí, chybě, paměti a identitě se generují podle skutečně podporovaného rozhraní. Kontrola zahrnuje i zachování režimů obyčejných LED displejů.

## Předchozí verze

# Modular Switchboards 0.13.110

Oprava barvení těla DIN Smart Module: sprej nabízel Paint a spotřeboval barvu, ale nativní OnServer.SetCustomColor potom odmítl změnu kvůli zděděnému HasColorState z LED displeje. Smart nyní po každém CacheStates používá barvu těla jako housing (HasColorState=false). Nativní Color interactable zůstává v cache kvůli lifecycle metodám displeje; ostatní LED displeje se nemění.

Stavové znaky nadále používají zelené RUN a oranžové ERR/ERR--- podle čipu. Sprej je nemění a nemění ani čip. Zachované jsou nativní kontroly spreje, spotřeba, uložení barvy a replikace; geometrie a stávající mapování lakovatelných částí těla se nemění.

Ověření: Release build bez chyb a varování. 11 kontrol barvení zahrnuje reprodukci původní chyby (spotřeba bez změny při HasColorState=true), skutečné provedení po opravě, opakované cache, zachování obyčejných LED displejů, náhled bez spotřeby, stejnou barvu, prázdný sprej a oddělenou barvu znaků/Setting. Jde o izolované fixture; živé barvení, načtení a klienty je potřeba potvrdit ve hře.

## Předchozí verze

# Modular Switchboards 0.13.109

Stavový displej má pevnou velikost textu: ERR0 až ERR999 ukazují číslo řádku, od řádku 1000 zobrazuje vždy ERR---. Přesné číslo a detail chyby dál pocházejí z původního čipu/Lua runtime a zůstávají v nápovědě. Zkracuje se pouze text na displeji; chyba ani síťově přenášený řádek se neupravují. Automatické zmenšování z místní 0.13.108 bylo odstraněno. RUN, IDLE a zhasnutí bez napájení beze změny. Zahrnuje také opravu duplicitní nápovědy z 0.13.107.

Ověření: Release build bez chyb a varování; 20 stavových kontrol včetně hranice 999/1000, řádku 4398, int.MaxValue a zachování plného řádku z Lua hlášení. Vzhled ve hře zbývá potvrdit.

## Předchozí návrhy a verze

# Modular Switchboards 0.13.108

Dlouhé stavové hlášení (například ERR4398) se nyní automaticky vejde do nativního displeje. Šířka se počítá ze skutečných nativních glyphů a rozestupů. Při překročení šířky plochy se pouze text rovnoměrně zmenší a znovu vystředí s okrajem jednoho pixelu; rámeček ani tělo modulu se nemění. RUN a kratší chyby si zachovávají původní velikost. Po návratu ke krátkému textu se původní měřítko obnoví; opakovaná aktualizace nezpůsobuje postupné zmenšování. Číslo řádku se nekrátí.

Ověření: Release build bez chyb a varování; 19 kontrol skutečné produkční metody přes fixture transformů ověřuje dlouhá čísla včetně ERR4398, vystředění, rovnoměrné měřítko, stabilitu při 100 opakováních a obnovení RUN/ERR1/prázdného displeje. Živé vykreslení ve hře zbývá potvrdit. Obsahuje také opravu duplicitního tooltipu z 0.13.107.

## Předchozí verze

# Modular Switchboards 0.13.107

Oprava duplicitního řádku chyby v nápovědě osazeného čipu Smart modulu. Po sestavení nápovědy slotu se ponechá jediný výskyt přesného hlášení nativního čipu, a to i mezi ExtendedMessage a stavovou zprávou. Jiné informace a upozornění se zachovávají; ostatní zařízení se nemění. Stavový displej RUN/ERR zůstává. Release build a 9 kontrol formátovaných zpráv prošly; potvrzení ve hře zbývá.

## Předchozí verze

# Modular Switchboards 0.13.106

Oprava ztráty natažených vnitřních kabelů při načtení Medium a Medium Reverse. Zápis ukládal trasy správně, ale kontrola Load používala pevné rozměry Small: X ±0,18 m (±0,20 m s Bridge) a Y ±0,24 m. Platné větší trasy se proto při načítání vyřadily.

Validace nyní vychází z CabinetShape.Width/Height konkrétního prefabu: Medium a Medium Reverse přijímají trasy do X ±0,38 m (±0,40 m s Bridge) a Y ±0,49 m. Small a Small Reverse mají stejné limity jako dříve. Zachované jsou kontroly konečných souřadnic, hloubky, identit kontaktů, verze trasy, množství kabelu, počtu bodů a spojitelnosti. Uložení i síťové načtení pro připojení do hry používají stejnou opravenou validaci. Schéma save se nemění, není potřeba přepočet již uložených tras.

Kabely lze znovu načíst z původního save, ve kterém jsou jejich záznamy stále přítomné. Pokud se svět po zahození kabelů znovu uložil, chybějící záznamy tato oprava nevytvoří.

Ověření: 62 kontrol ukládání Small/Small Reverse/Medium/Medium Reverse přes XML a binární síťový přenos, přesné souřadnice, koncové kontakty včetně Output 3 a Bridge, barva, fan slot, verze a odmítnutí vadných dat. Celý stávající wiring balík prošel včetně routování všech variant, migrace a napájení. Release build bez chyb a varování. Ve hře je třeba zkontrolovat načtení původního Medium save. Náhledy, autor KreeZy a volitelná Lua kompatibilita z 0.13.105 zůstávají.

## Nabídka IC editoru

Podle dalšího herního screenshotu se dva řádky objevují i v 0.13.105. Kontrola je proto nyní také přímo před zobrazením hotového dropdownu, nezávisle na tom, která cesta seznam sestavila. Zahrnuje obaly stejného základního modulu a vyřazuje neaktivní nebo odpojené instance bez hostitelské skříně. Drží dvojice popisek/čip spolu a po přestavbě Lua seznamu obnovuje původní výběr pro Edit/Import/Export. Dva různé platné moduly se stejným názvem stále zůstávají dvě položky; neslučují se podle názvu.

Pokud by se duplicita opakovala, soubor LocalLow/.../ModularSwitchboards/Diagnostics/SmartEditor-devices.txt obsahuje skutečné typy včetně sestavení, ID, skříně a počty řádků před/po kontrole. Přesnou příčinu dvou uživatelových položek bez těchto runtime údajů zatím neznáme. 21 kontrol editoru pokrývá obaly, neaktivní instance, finální položky, přiřazení názvů, obnovení výběru a diagnostiku. Volitelné Lua napojení má 23 ověřených kontrol včetně kontraktu původní DLL.

## Stavový displej místo diody

Aktuální požadavek nahrazuje programovatelný LED text stavovým displejem housingu. Zeleně RUN, oranžově ERR a číslo chybného řádku podle čipu (například ERR4). Chybí-li údaj o řádku, jen ERR; bez programu IDLE a bez napájení či při vypnutí displej zhasne. Detail chyby zůstává v nápovědě. Pro Lua se číslo řádku čte z hlášení původního runtime, pokud je dostupné. Stav a řádek se přenášejí také klientům a při připojení do hry.

Samostatná malá dioda byla odstraněna. Setting zůstává hodnotou housingu; neurčuje zobrazený text. Mode a Color už nejsou programovatelné LED vstupy Smart modulu. Nativní LED renderer slouží pouze ke kreslení stavových znaků. Technická dědičnost LogicDisplay zůstává kvůli existujícím save a vykreslování; nejde o převod uložených entit na jiný prefab. Přidaných 15 kontrol ověřuje formát textu, stav a parsování chyb Lua; živé vykreslení ve hře zbývá ověřit.

## Smart jako housing s integrovanou LED

Smart zůstává jediným zařízením a jediným držákem čipu. Podle nativního CircuitHousing má nyní také IMemoryReadable/IMemoryWritable: ReadMemory, WriteMemory, ClearMemory a GetStackSize pracují přímo s pamětí vloženého čipu. Bez čipu vrací velikost 0 a paměťové operace vyvolají chybu stejně jako housing. LineNumber bez čipu je -1; slotové čtení čísla řádku i výběr sítě základní jednotky odpovídají housing kontraktu. Základní vazba se jmenuje HOUSING. Fyzické voliče d0–d5 nepřibývají.

Kvůli nativnímu vykreslování LED a kompatibilitě existujících uložených modulů zůstává implementačním předkem LogicDisplay. Nejde o nahrazení třídy ani přidání druhého samostatného zařízení. V předchozím návrhu řídily Mode 10 a Setting STR("PACEP") text displeje. Aktuální návrh výše je nahrazuje stavem housingu; Setting nikdy nepřejmenovává zařízení. Sprej se nyní předává nativnímu ISprayer i přes přítomnost LED Color stavu; barva těla a barva znaků zůstávají samostatné. Tím se nemění všechny materiály patice a kontaktů na barvu těla.

Odstranění Smart modulu nyní vrací a odpojuje jeho vnitřní kabely stejně jako u jističů. Deregistrace i zánik uvolňují obsazený kontakt; opakované odpojení nevrací kabel dvakrát. Nápověda zapojování má vlastní nadpis Switchboard wiring.

Ověření navíc: 20 kontrol demontáže a kapacity kontaktů, 8 kontrol směrování spreje a zachování LED hodnot, 11 kontrol paměťového kontraktu housingu. Testy používají izolované fixture; vzhled, sprej, IC/Lua a načtení světa je nutné potvrdit v běžící hře.

## Předchozí verze

# Modular Switchboards 0.13.105

Autor: **KreeZy**. Mod list má vlastní obrázky About/Preview.png (1600 × 900) a About/thumb.png (640 × 360), aktuální popis, autora, verzi a tagy. Hra přímo načítá About/Preview.png. Obrázky jsou vlastní rendery našich modelů, nikoli převzaté náhledy jiného modu. Verze v registraci modu, sestavení i About.xml je sjednocena na 0.13.105.

## Volitelná kompatibilita se StationeersLua

Běžný IC10 funguje bez StationeersLua. Není přidaná žádná povinná závislost, reference sestavení ani cizí DLL v balíčku. Adaptér se zapne při nalezení podporovaného běhového prostředí. Pro Lua je nutný Integrated Circuit (Lua) a samotný StationeersLua; IC10 assembler a Lua nejsou zaměnitelné jazyky.

Smart Module spouští Lua přes původní LuaChipRuntimeManager, nikoli jako IC10. Dodržuje serverovou autoritu, napájení, On/Off, pauzu a probíhající ukládání. Oznamuje změny aktivity a při vyjmutí čipu nebo zániku modulu žádá původní Lua runtime o snapshot a ukončení; vlastní serializaci Lua čipu nadále zajišťuje StationeersLua. Zelená dioda používá stav Lua VM místo IC10 instruction pointeru, oranžová ukazuje Lua chybu a nápověda přebírá její detail.

Čip má přes svůj nativní ICircuitHolder přístup k vlastnímu LED displeji jako základní jednotce a k datové větvi na IN. Ukázka čítače je v Examples/DinSmartModule.lua. Fyzické voliče d0–d5 nejsou přidané; jiné přístroje používejte přes ReferenceId nebo batch v připojené větvi.

Lua mod si přestavuje seznam v IC motherboard editoru vlastní cestou. Kontrola duplicit je proto navíc připojená k jeho závěrečnému řazení seznamu: stejný Smart Module se odstraní současně z položek i popisků, různé moduly stejného názvu se zachovají. Import/export a zdrojový editor zůstávají na původní implementaci StationeersLua. Zachovaná je i oprava základního seznamu a registrace ze 0.13.104.

Adaptér byl ověřen proti nahrané StationeersLua.dll 1.0 (SHA-256 b5244ed772c021c07ea5d5124a4cbf5b934f3e033e282d9fb3fecbfa9b07c214). Používá existující runtime API reflexí; u jiné verze s nekompatibilním API se Lua nespustí a zobrazí se informace o chybějícím/nepodporovaném prostředí. Standardní IC10 tím není zablokován.

Ověření: 23 kontrol volitelného adaptéru a kontraktu skutečné DLL, včetně nepřítomnosti Lua reference v produkční sestavě, a 13 kontrol identity editoru včetně dvojic popisek/čip v Lua seznamu. Release build bez chyb a varování. Živé ověření Lua programu, napájení, save/load, síťových klientů, IC editoru a náhledu v mod listu je ještě nutné. Herní runtime zde není k dispozici.

## Předchozí verze

# Modular Switchboards 0.13.104

Oprava dvojího zobrazení stejného DIN Smart Modulu v nabídce IC editoru. Nativní Computer.DeviceList předává editoru kopii DataDeviceList bez deduplikace. Pro Smart Module nyní nabídka zachová jednu položku pro jednu instanci/síťové ReferenceId a vynechá kurzor, šablony bez ID a odstraňované instance. Dva různé moduly se stejným názvem se neslučují. Ostatní nativní zařízení se nemění.

Při aktualizaci vazby Smart Modulu se také odstraní opakované registrace přesně stejné instance v jeho aktuální CableNetwork.DeviceList. Jedna registrace zůstane, mapa kabelů se zachová, odvozené datové/napájecí seznamy se zneplatní a počítače dostanou nativní upozornění na změnu. Datové sítě se nepropojují a výběr větve se nemění. Přesná cesta vzniku duplicity v uživatelově běžícím světě není z obrázku určitelná; oprava pokrývá opakovanou registraci i opakovaný záznam ve výsledném datovém seznamu.

Ověření: 9 kontrol identity v nabídce a 33 kontrol výběru a registrace sítě včetně opravy duplicity a zachování registrace kabelu. Release build bez chyb a varování. Oprava zvuků a zelená/oranžová dioda z 0.13.103 zůstávají. Ve hře je třeba ověřit nabídku s jedním modulem a se dvěma různými moduly stejného názvu.

## Předchozí verze

# Modular Switchboards 0.13.103

Doplněná oprava opakovaných zvukových výjimek po vypnutí a zapnutí napájení. Uživatel potvrdil pád i s 0.13.102: přepojení při tvorbě prefabu nestačilo. DIN Smart Module nyní před base.Awake vytvoří vlastní kopie zvukových událostí a nastaví jejich vlastníka přímo na vznikající instanci. Zachová nativní zvukové klipy, kanály, podmínky, podmínky stavebních stavů a sdílené reference uvnitř jedné instance. Zvukové události ani jejich seznamy se nesdílejí mezi herními instancemi. Zvuky nejsou vypnuté ani globálně potlačené. Ještě je nutné ověřit skutečné přepnutí napájení ve hře.

Nad paticí IC10 je malá stavová dioda. Zelená znamená zapnutý a napájený modul s běžícím programem, včetně sleep/yield. Oranžová znamená chybu kompilace nebo běhu. Červená se nepoužívá. Bez napájení, při vypnutí, bez čipu, bez programu, po dokončení nebo při pauze dioda nesvítí. Nápověda modulu ukazuje stav a nativní detail chyby včetně řádku z IC10. Stav diody se přenáší serverem včetně připojení do běžící hry; nový save formát není potřeba. Multiplayer musí používat stejnou verzi modu.

Ověření: 24 kontrol zvukových referencí včetně dvou nezávislých herních instancí a cyklu napájení, 10 kontrol inicializace Smart Modulu a 259 kontrol stavů diody. Release build bez chyb a varování. Původní rozměry, funkce LED displeje/db, IC10 a datová větev se nemění; přidaná stavová dioda má vlastní materiál a nezávisí na barvě displeje. Herní ověření zvukové opravy, nové diody a síťového přenosu je stále nutné.

## Předchozí verze

# Modular Switchboards 0.13.102

Oprava zvukových referencí při nahrazení původního komponentu prefabu. Interakce už mířily na nový modul, ale jejich GameAudioEvent.Parent mohl dál odkazovat na odstraněný původní komponent. Nativní GameAudioEvent.IsValid pak při změně stavu četl neplatného vlastníka, což odpovídá nahlášenému zásobníku AudioManager.LateUpdate / PlayScheduledSounds.

Před odstraněním původního komponentu se nyní přepojí vlastník zvukových událostí v AudioEvents, v interakcích a v interakcích stavebních stavů. Zvuky, jejich podmínky i nativní přehrávání zůstávají zachované. Oprava se použije při přípravě všech nahrazovaných prefabů, včetně DIN Smart Modulu. Geometrie a datová logika se nemění.

Ověření: 14 kontrol reprodukujících odstraněného vlastníka, přepojení všech tří cest, zachování sdílených referencí, živých podmínek a zvuku a oddělení původního prefabu. Dalších 10 kontrol inicializace Smart Modulu. Release build bez chyb a varování. Ještě je nutné ověřit načtení světa a změny stavu ve hře.

## Předchozí verze

# Modular Switchboards 0.13.101

Patice IC10 navazuje přímo na čelo DIN Smart Modulu: lem je v rovině čelní stěny místo původního přesahu 0,5 mm. Otvor respektuje osmiboký obrys patice; čtyři rohy doplňuje původní tmavá čelní plocha, takže kolem patice nezůstává obdélníková mezera. Vnitřní stěny a dno kapsy navazují na stejný otvor. Model patice, čip i nativní slot zůstávají ve společné transformaci.

Displej, IC10 a datová logika se nemění. Geometrické kontroly na původních exportech Air/LED a procedurálním těle zahrnují rovinu lemu, návaznost všech čtyř rohů, průchod kapsou, UV a nedegenerované trojúhelníky. Skutečné usazení je třeba ověřit ve hře.

## Předchozí úprava 0.13.100

Čelo DIN Smart Modulu: vpravo zůstává pouze originální patice IC10 z Air Conditioneru, bez přenesených bílých a šedých panelů. Výběr podle změřeného originálního meshe zachovává 166 celých trojúhelníků a původní UV/materiálové role. Patice je zvětšená na přibližně 46 × 49,5 mm.

Postup odpovídá Battery Backup: nejprve model patice a kapsa v těle, potom nativní slot. Model, slot a čip mají jednu společnou transformaci. Rámeček patice je jen 0,5 mm před čelem; její zadní část leží v kapse s bočními stěnami a dnem. Hloubka kapsy zohledňuje zadní mez původního čipu. Žádné okolní části Air Conditioneru se nepřenášejí.

LED displej je o 2,7 mm zapuštěnější. Pixelová plocha zůstává před čelem, rámeček vystupuje přibližně o 3,8 mm. Odstraněno je také všech 10 trojúhelníků původního šedého uchycení tlačítka nad LED. Horní svorka IN zůstává. Funkce displeje, db, IC10, napájení a výběr datové větve jsou beze změny; nativní vykreslování textu už potvrdil herní screenshot verze 0.13.99. Oprava startovací inicializace z 0.13.99 zůstává zachovaná.

Ověření: 332 geometrických kontrol na originálních exportech Air/LED a skutečném těle DIN: přesný výběr patice, nezměněná UV, vyloučení panelů, odstranění držáku tlačítka, odstupy, kapsa průchozí zepředu, dno, orientace stěn a zachování levé části čela. Release build bez chyb a varování. Nové rozměry a usazení čipu je třeba ověřit ve hře. Úplné herní exporty ani dekompilované zdroje nejsou součástí zdrojového ZIPu; původní materiály a slot se načítají ze hry.

## Oprava startu 0.13.99

Oprava pádu při startu verze 0.13.98: výchozí stav DIN Smart Modulu se nastavoval přes živý Interactable.State setter ještě před Unity Awake. Nativní LED callback přečetl neinicializovanou cache InteractOnOff, vyvolal NullReferenceException a zrušil celou přípravu prefabů; následující chyby registrace a receptů byly důsledkem tohoto prvního pádu.

Výchozí ON=1 a Powered=0 se teď zapisují přímo do serializovaného pole _state, bez spouštění LED, zvukových či síťových callbacků. Pak se naplní nativní interakční cache přes CacheStates(true). Ze sestaveného klonu jsou odstraněny staré animátory a odkazy na rodičovské interakce původního ovladače. Za běhu dál fungují nativní callbacky, zapínání i vykreslování.

Regresní test SmartPrefabState reprodukuje původní chybu před Awake a ověřuje deset případů včetně tiché přípravy, cache, oddělení původního prefabu a zachovaných běhových callbacků. Release build: 0 chyb, 0 varování. Ostatní funkce DIN Smart Modulu zůstávají jako v 0.13.98: čtyři DIN místa, jediný IN pro proud/data, vlastní nativní LED přes db a IC10. Ověření skutečného startu a zobrazení ve hře je stále nutné.

## Funkce 0.13.98

DIN Smart Module zabírá čtyři DIN pozice a používá 4 Kit (Switchboard Modules). Vlevo má originální LED Display (Small), vpravo originální usazení IC10 z Air Conditioneru. Páčka, její uchycení a horní stavový indikátor zůstávají odstraněné.

Modul má **jediný horní IN pro proud i data**. Zapoj ho jako spotřebič do odbočky: například jistič OUT -> Output 2 a ze stejného jističe OUT -> Smart IN. Počítač připojený k Output 2 ho v IC motherboardu najde jako **DIN Smart Module**. Před ochranou používá síť Input; za ochranou síť odpovídajícího externího Outputu. Samostatný vstup za jističem bez vedení na externí Output nemá z čeho určit externí datovou síť. Větev vedoucí na různé datové sítě se odmítne; sítě se nespojují. Výběr větve navazuje na pravidla Cable Analyzeru, přizpůsobená spotřebiči bez OUT.

Displej je skutečný nativní LogicDisplay: používá původní pixelovou síť, glyph renderer, režimy, barvy a logické hodnoty. Čip i displej vlastní stejné zařízení; **db je přímo DIN Smart Module**. Krátký program k ověření po nahrání z IC motherboardu:

```mips
s db On 1
s db Mode 0
s db Color 2
s db Setting 42
l r0 db Setting
```

Převezme spotřebu původního LED displeje (50 W). IC10 běží na serveru s nativním rozpočtem 128 instrukcí každých 0,5 s, když je modul zapnutý a napájený. Podporuje db a přímé ID/batch adresování zařízení ve vybrané síti; zatím nemá fyzické voliče d0–d5. IC10 lze zasunout po otevření dveří a sejmutí vnitřního krytu. Logické nastavení displeje zůstává dostupné zvenku přes síť. Modul není jistič a nemá ochranný výkonový limit.

Ukládá nativní stav displeje a inventář čipu, pozici DIN, chybu a posledního editora. Starší prototypek zachová pozici a název Smart Module se převede na DIN Smart Module; vlastní názvy hráče zůstanou. Kabely ze zrušeného OUT staršího prototypu se po načtení vrátí jako Cable Coil; IN zůstává. Původní nativní mesh soubory se dál exportují do LocalLow/.../ModularSwitchboards/Diagnostics. Jejich kompletní obsah ani dekompilované zdroje hry nejsou součástí zdrojového ZIPu.

Ověření: Release build bez chyb a varování; 29 kontrol jednoho IN a síťové registrace; 28 kontrol db, delegace LED logiky, běhu IC10 a ukládání/join; 37 kontrol ořezu originálního LED mesh, UV, orientace a usazení před čelem; produkční geometrie potvrzuje odstranění OUT kontaktu a nezměněné běžné jističe. Regresní testy vedení, napájení a routování prošly. Testy používají místní herní DLL a náhradní běhové prostředí; finální zobrazení LED, skutečné usazení IC10, seznam IC motherboardu a save/load je třeba vyzkoušet ve hře. Ikona zachycuje nové tělo s LED; IC10 socket se sestavuje z originálního Slotu a mesh Air Conditioneru při spuštění hry.

## Předchozí změny

### 0.13.97

Smart Module má čisté čtyřmístné tělo: odstraněná páčka, její spindle uchycení i horní indikátor stavu. Pryč je také původní ovládací hitbox, On/Off interakce a komponenta animace páčky. Náhled stavby, hranice výběru i ikona odpovídají prázdnému tělu; připojovací svorky a čtyřmístná obsazenost zůstávají. Čip a LED displej se doplní v následujícím kroku.

Tělo používá produkční builder s plain:true, shodný způsob odstranění spindle uchycení jako u Analyzeru. Blueprint se přegeneruje až po odstranění ovládacích dílů. Existující běžné jističe se nemění.

Ověření97: Release build bez chyb/varování; produkční geometrie ověřuje šířku a střed čtyřmístného plain těla. Ikona znovu vykreslená ze skutečného modelu a vizuálně zkontrolovaná bez páčky/indikátoru. Herní zobrazení je třeba ověřit ve hře.

Změny předchozí96:

První základ Smart Module: samostatná volba v Kit (Switchboard Modules), stabilní prefab StructureDinSmartModule. Původní jističové tělo rozšířené na čtyři DIN pozice; páčka, indikátor, svorky a hitbox jsou vystředěné, obsazenost a náklady jsou4modulové kity. Vlastní ikona z produkčního čtyřmístného modelu. Zatím zachovává ruční On/Off a výchozí1kW ochranu původního jističe; IC10, čip ani LED displej ještě nejsou osazené.

DinSmartLayout poskytuje společnou šířku a střed pro model, kontakty a počet míst. BreakerSwitchView dostal CenterX, aby animace nepřesouvala páčku širokého modulu zpátky vlevo. Ostatní jističe mají výchozíCenterX0 a původní chování. Nová varianta používá stávající ukládací typ DIN modulů.

Při startu hry se původní modely Air Conditioneru a StructureConsoleLED5 načtou a vyexportují stejně jako dřívější APC. Soubory AirConditioner-geometry.json a ConsoleLED5-geometry.json vzniknou v Application.persistentDataPath/ModularSwitchboards/Diagnostics (herní LocalLow). Obsahují původní mesh části, vrcholy převedené do souřadnic zařízení, UV, materiály/ID a trojúhelníky. Úplná cesta se zapíše do logu jako Smart native geometry exported. V paměti se uchovají i původní meshe/materiály a transformační matice pro následnou montáž čela. Tyto reference se v této verzi zatím na modul nemontují. Původní Unity assety nejsou součástí místních DLL; skutečná data tedy vyexportuje až hra, připravený exportér byl ověřen na fixture modelech.

Žlutá výstraha na Medium a Medium Reverse posunutá výš: ze skutečného Small door meshe změřená horní hranaY0.25m a střed výstrahyY0.17m, tedy80mm pod horní hranou. Medium má horní hranuY0.5m, proto se původní nezvětšená značka posune o250mm nahoru. Zachová se i přesný odstup horního okraje výstrahy; ten se změří z aktuálního nativního meshe a vypíše do logu. Small i Small Reverse se nemění.

Ověření96: Release build bez chyb/varování;98kontrol katalogu a modulových pravidel včetně Smart názvu/šířky/volby; produkční geometrie těla ověřuje fyzickou šířku čtyř pozic a vystředění;22kontrol nativního přepínání/animace/zvuku včetně zachování nenulového středu páčky. Ikona vykreslená ze skutečných produkčních meshů a vizuálně zkontrolovaná. Ověřený export obou JSON souborů včetně souřadnic, UV, materiálů a indexů; skutečný Medium mesh fixture kontroluje zachování odstupu výstrahy. Umístění, zapojení, skutečné nativní exporty a save/load vyžadují herní ověření.

Změny předchozí95:

Přidaný Switchboard Medium (Reverse), samostatný čtvrtý výběr ve stejném Kit (Switchboard). Vzpřímená skříň se dvěma dveřmi, Input dole a tři Outputs nahoře. Výstupy jsou zleva doprava1/2/3 také na vnitřní desce. Zachované rozměry0.8×1m, tři DIN řady po14pozicích, dveřní moduly/Bridge, kryt a cena3kitů za rám +5Plastic Sheets s klíčem za plášť.

Stabilní prefab StructureModularSwitchboardMediumReverse. Profil sdílí Medium geometrii a Small Reverse mapováníY. Input používá skutečnou dolní kabelovou buňku a společnou fyzickou plochu; všechny tři Outputy míří nahoru. Přesné nativní šestibodové profily koridorů se před generováním převedou do společných souřadnic a hotový mesh se zrcadlí s opravou windingu. Vnitřní svorky i středový popisek jsou zrcadlené, text zůstává vzpřímený. F1/popisy/vyhledávání i kontrola registrace zahrnují nový profil. Existující profily a jejich prefab ID se nemění.

Ověření95: Release build bez chyb/varování;428kontrol skutečných profilů, rozmístění a kabelové mřížky všech čtyř variant; produkční Input installer také pro Medium Reverse;3220kontrol přesných output spojů a trojúhelníků u obou Medium variant v pěti posunech stěny;10308kontrol zadního/Input koridoru včetně zrcadlených spojových vrcholů a normál;12464kontrol obvodů/tras/serializace. Herní vytvoření nového prefabu, dveře, kabely a save/load je třeba ověřit ve hře.

Změny předchozí94:

Dveřní moduly, Door Bridge a popisky nyní při stavění přes Authoring Tool používají stejné přichytávání a držení montážní pozice/natočení jako při použití příslušného kitu. Dveřní i vnitřní popisky zapínají správnou montážní plochu také při authoringu. DIN lišty a moduly zůstávají součástí stejného postupu.

Společná MountPlacementTool rozlišuje skutečný konstrukční cursor a odpovídající kit nebo nativní InventoryManager.IsAuthoringMode. MountBoardResolver, MountPlacement a BoardPlacementInput ji používají místo výhradní kontroly MultiConstructoru. Držení modifikátoru zachová desku, mřížku i rotaci; uvolnění tlačítka, změna nástroje/cursoru a znepřístupnění desky lock zruší. Požadavky na dokončenou skříň, kryt pro vnitřní popisky, obsazenost a vzdálenost se nemění. Zachovaná je také podpora kitu vnitřního krytu.

DIN: přidané samostatné montážní pásy v každé řadě, registrované na RailBoard a aktivní jen při stavění lišty (kit i authoring). Pásy mají výšku35mm a jejich Y odpovídá přesně souřadnicím řad. Při stavění popisků se vypnou. Hitbox pro osazování modulů na namontovanou DIN lištu zúžený z105mm na35mm. Doors: resolver při míření na oddělený namontovaný ovladač/popisek hledá správné křídlo podle jeho skutečné montážní desky.

Ověření94: Release build bez chyb/varování; 95 kontrol skutečných tříd pro lock, volbu nástroje a label plochy, šest typů přes kit i Authoring Tool; 151 kontrol skutečného resolveru a pozdní validace Bridge včetně nových authoring scénářů pro dveřní moduly a oba druhy popisků. Herní umístění a následné načtení je nutné ověřit ve hře.

Změny předchozí93:

Oprava stavebních značek: odstraněné vlastní piktogramy92. Výchozí nativní křížky u všech přípojek Small, Reverse a Medium se nahrazují přímo původními prefaby hry z InventoryManager.HelperIndicators pro Input/Output s typem PowerAndData. Jsou to stejné nativní značky, které používá APC; oba symboly jsou součástí původního prefabu. Output2/3 použijí původní Output variantu, pokud tabulka nemá vlastní kombinovanou variantu jejich role.

Postfix HandleStructurePrefab běží po vytvoření skutečného construction cursoru. Zachová přesnou pozici, otočení, velikost, rodiče a tag původní značky, nastaví Connection.HelperRenderer na nový nativní renderer a starý křížek odstraní. Tím dál fungují původní zelené/žluté/červené barvy hry. Funkční ConnectionRole, ConnectionType a registrace elektrických sítí se nemění; rám i orientační šipka zůstávají.

Příčina92: nativní HandleStructurePrefab vybírá HelperIndicators podle role a typu přípojky. Nedokončená skříň má NetworkType.None, takže použil výchozí křížek. Přidání vlastních značek do blueprintu jej nenahradilo.93 vybírá přímo původní kombinovaný vizuál, bez změny reálných síťových parametrů.

Ověření93: Release build bez chyb/varování; skutečná produkční třída s Unity náhradami ověřena napříč třemi profily: volba původního kombinovaného prefabu, správná role, odstranění křížku, zachování všech transformací/tagu a nezměněný typ přípojky. Skutečnou tabulku prefabů a vzhled je třeba ověřit ve hře; pokud původní kombinovaný prefab chybí, zapíše se konkrétní chyba a původní značka zůstane.

Změny předchozí92 (nahrazené v93):

Stavební náhled Small, Reverse a Medium nyní zobrazuje u Inputu i všech Outputů směrovou šipku a oba piktogramy: blesk pro proud a tříuzlovou síť pro data. Input míří dovnitř, Outputs ven; náhled zachovává horní orientační šipku i rám. Značky jsou oboustrannou geometrií samostatného blueprint meshe a přebírají zelenou/červenou barvu náhledu. Nejsou součástí dokončené skříně ani hitboxů.

Náhled se sestavuje až po instalaci funkčních přípojek a bere jejich skutečné lokální pozice. Směry používají společný CabinetLayout/OutputPlacement pro normální, Reverse i Medium. Tato změna je vizuální: nemění registraci elektrických sítí, průchod dat přes moduly ani budoucí IC10 chování.

Ověření92: Release build bez chyb a varování; osm geometrických případů Input/Output ve čtyřech směrech kontroluje směr šipky, konečné souřadnice, čelní rovinu a nenulovou plochu trojúhelníků. Nativní rendering a čitelnost při otáčení je třeba ověřit ve hře.

Změny předchozí91:

Medium Bridge: pevné svorky vrácené o 30 mm k pantu oproti90 (celkově20mm dovnitř oproti89). Dveřní svorky posunuté o10mm od pantu do plochy dveří, včetně kontaktů a rezervací pro ruční vodiče. Flex používá stejné Bezierovy odchylky jako Small, zrcadlově pro obě křídla.

Medium horní Input koridor nyní používá stejné oddělené normály rovinných ploch jako Outputs. Vyhlazování nepřechází přes hrany zkosení do dlouhých stěn. Přesný nativní šestibodový připojovací profil, geometrie, kabelové buňky a Small/Reverse zůstávají zachované.

Ověření91: Release build bez chyb/varování; 54 případů zadního koridoru, 8958 kontrol trojúhelníků a spojových vrcholů. U pěti poloh přesného Input profilu ověřeno oddělení všech normálových vrcholů bez jakékoli změny souřadnic trojúhelníků. Dále12464kontrol obvodů/tras/serializace a46zrcadlových poloh propoje0–110°. Kontrola středu i příčných posunů o poloměr2.4mm proti nativním dveřím bez průniku; rám mimo první dva koncové úseky u pevné svorky bez průniku. Vzhled je nutné ověřit ve hře.

Změny předchozí90:

Medium: pevné Door Bridge svorky jsou na obou stranách posunuté o 50 mm směrem do středu desky. Propoj používá jeden kratší plynulý oblouk mezi skutečnými otvory svorek, bez vynucené okliky před rámem. Small a Reverse mají původní umístění i propoj.

Medium Input a Outputs: generovaný koridor přebírá šest skutečných vrcholů připojovacího profilu nativního konektoru. Zachovává jejich přesné XYZ souřadnice; zkosení těla už neřeže rohy dosedacího profilu a neposouvá konec podle hloubky vrstvy. Kabelové buňky a logické porty se nemění.

Ověření90: Release build bez chyb a varování; přesné spojové vrcholy, uzavřenost a orientace output meshe napříč pěti posuny stěny; sdílený zadní koridor a přesné vrcholy Inputu; 12464 kontrol obvodů, tras a serializace; 46 zrcadlových poloh Bridge při otevření 0–110°. Střední úseky oblouku nekříží skutečné trojúhelníky Frame/Housing. Herní runtime není dostupný; tloušťku kabelu a vzhled při pohybu je třeba ověřit ve hře.

Změny předchozí89:

Door Bridge: před samotným CanConstruct se znovu vybere správná deska (po případném nativním resetu CursorBoard). Rozvaděč se hledá i přes montážní metadata oddělené DIN lišty/modulu/krytu; při míření na desku nebo lištu se náhled přichytí k nejbližší pozici u příslušného pantu. Obsazená pozice zůstane červená, nepřeskakuje se na jinou volnou. Podržený montážní lock má přednost. Platí pro Small, Reverse a obě strany Medium.

Medium Bridge flex: druhé křídlo používá správný opačný otvor pohyblivé svorky. Obě průchodky jsou zrcadlové, včetně lokálního natočení svorek. Modrý propoj má souvislý oblouk přes bezpečný bod před rámem; přechází do otvoru svorky po jeho ose a nezanořuje se střední částí do rámu. Elektrické kontakty a ID se nemění. Small/Reverse oblouk beze změny.

Medium Input nyní používá stejný ReadForBody jako Outputs: explicitní tělová buňka a fyzický spoj přesně uprostřed mezi kabelovou a tělovou buňkou. Vizuál i funkční registrace používají stejný výpočet; původní surový pivot zdrojového kabelu nemění polohu viditelného spoje. Po úpravě ověř napojení existujícího horního kabelu.

Odstraněno4mm překrytí na rozhraní generovaného Medium koridoru a nativních konektorů (Input i Outputs). Oba díly se stýkají na změřené připojovací rovině; jejich souběžné povrchy se v oblasti spoje již nepřekrývají.

Ověření89: Releasebuild0chyb/varování;143integrovaných kontrol skutečného resolveru a CanConstruct (oddělená DIN lišta, chybně zvolená deska, profily, strany, nejbližší/obsazené pozice);131kontrol nativních kabelových pozic včetně Input; produkční Inputinstaller;12464kontrol obvodů/energie/tras/serializace plus46zrcadlových případů propoje při otevírání.1748středních segmentů skutečně generovaných flex tras nekříží trojúhelníky původního Frame/Housing meshe. Testy nenahrazují Unityruntime: tloušťka flex kabelu, koncové úseky u svorek, vzhled švů a připojení skutečných kabelů vyžadují ověření ve hře.

Změny předchozí88:

Oprava nefunkční druhé kliky Medium: nativní Thing.IsOpen u rozvaděče bez animátoru čte pouze InteractOpen.State (první Open akci). Dvě vlastní Open instance proto mají odlišné stavy; změna druhé nemusí pohnout dveřmi. SwitchboardCabinet.InteractWith nyní pro obě kliky předá původnímu nativnímu zpracování tutéž první Open akci. Oba fyzické hitboxy a vlastní výběrové rámečky zůstávají, ale existuje jediný rozhodující a ukládaný/synchronizovaný stav. Druhá kliková interakce se nesynchronizuje samostatně. Small/Reverse a ostatní akce beze změny.

Ověření88: Releasebuild0chyb/varování;62kontrol, včetně reprodukce změny ignorovaného stavu druhé kliky, následného střídání obou klik při otevírání/zavírání, společného Open, jediného synchronizovaného stavu a zachování Small/ostatních akcí. Test používá skutečnou produkční volbu akce a větev Open z dekompilovaného nativního Thing.InteractWith, se serverovou/Unity náhradou. Skutečný herní runtime a multiplayer zde nejsou dostupné.

Změny předchozí87:

Sjednoceny obě kliky Medium: každá má vlastní fyzický hitbox a nově vytvořenou nativní akci Open se stejným hostitelem, ovládáním, rozměry výběru a synchronizací. Odstraněna asymetrie mezi původní upravenou locker interakcí a dodatečnou interakcí druhého křídla. Výběrové Bounds obou klik odpovídají rozměrům jejich colliderů; dodatečná klika je dříve neměla výslovně nastavené. Obě nadále otevírají společně stejné dvojité dveře. Small a Reverse beze změny.

Ověření87: Releasebuild bez chyb/varování; kontrola obou vazeb na collider, společného vlastníka Open, rozměrů výběru, shodného nastavení, dokončeného stavebního stavu a opakované registrace bez duplicit. Skutečné klikání ve hře a multiplayer zde nejsou dostupné; ověř obě kliky při otevřených i zavřených dveřích.

Změny předchozí86:

Opraven pád ModelBlueprint.Build (cannot build a preview without model geometry) při načtení Medium s DIN lištami skrytými pod krytem. Runtime změna šířky už neprochází viditelné renderery ani nepřepisuje sdílený prefab blueprint. Používá přímo vytvořený mesh lišty a případný vlastní Wireframe kurzoru. Pokud kurzor vznikne později nebo se vymění, dostane správný náhled i bez další změny šířky. Fyzické rozměry, montáž, zapojení a ukládání zůstávají stejné.

První montážní náhled Small/Reverse/Medium na svislé stěně se nově srovná šipkou nahoru. Úprava proběhne jen jednou při aktivaci náhledu před kontrolou montáže; zachová směr do stěny a následné ruční otočení. Výslovný roll nebo smart-rotate v prvním snímku má přednost. Postavené skříně a ostatní prefaby se neotáčejí.

Medium nově vyžaduje3×Kit(Switchboard) pro rám a5×PlasticSheets + Wrench pro skříň. Small/Reverse zůstávají1kit +2PlasticSheets. Počty jsou přímo v nativních BuildStates, které zobrazíF1 a používá stavba/demontáž; registrace kontroluje cenu každé varianty.

Ověření86:52kontrol produkční inicializace natočení (3varianty,4směry stěn, nová aktivace a zachování ručního otočení); Releasebuild0chyb/varování;27kontrol skutečné produkční metody Resize pro skrytý model, odstraněné collidery, náhled vytvořený později/vyměněný, střídání šířek a opakované volání. Předchozí metoda v regresním scénáři vyvolá stejnou výjimku; opravená ji nevyvolá. Unity/runtime zde není dostupný; ověř načtení svého světa s nasazeným krytem.

Změny předchozí85:

Opraven chybějící montážní náhled rámu Medium: původní rám měl geometrii jen v páté materiálové části, ale náhled používal jeden materiál. Společný CabinetPreview nyní slučuje všechny části skutečného rámu do jednoho submeshe. Small, Small (Reverse) i Medium mají v montážním náhledu plnou šipku nahoru; šipka se neobjeví na postavené skříni. Náhled zachovává skutečné rozměry, natočení a offset modelu.

Medium má vlastní obrázky hotové skříně i rámu (F1 a stavební stavy), vyrenderované z původního embedded meshe se skutečnými transformacemi Medium: dvoje dveře, dvě madla, širší/vyšší tělo. Small a Reverse si ponechávají své obrázky.

Ověření85: produkční Releasebuild bez chyb/varování; kontrola skutečného embedded rámu s prázdným prvním submeshem, kompletních indexů v jediném náhledovém submeshi, šipky a transformací pro všechny tři varianty. PNG s průhledností ověřeny a obrázek vizuálně zkontrolován. Unity/herní runtime zde není dostupný; skutečný stavební kurzor a F1 je potřeba ověřit ve hře.

Změny předchozí84:

Opravená zadní sestava Medium: místo zjednodušeného samotného krčku používá stejný generátor jako Small pro celé tělo zadní krabice, zaoblený půdorys, souvislý horní koridor a přechod bez vnitřního víčka. Zůstává původní nativní zadní kryt APC s výstrahou a šrouby, původní povrch a hloubka. Medium jen dodává rozměry svého nového horního konektoru. Spodní společný kryt má stejné nativní plošné zkosení jako Small, vedené kolem všech tří větví. Stejné plošné zkosení (nativní poměr0.5776 a hloubka nejvýše10mm) má i celý horní koridor od zadní krabice až k Inputu; přechod krabice do tohoto profilu používá společný generátor. Přívod Input zůstává na stejné kabelové pozici; výstupy2/3 a jejich vnitřní svorky jsou nově seřazené1–2–3. Existující vnější kabely2/3 přepoj na nové pozice; kontrola uložených vnitřních tras zachovává logické konce a přepočítá posunuté přívody.

Medium má všechny tři výstupy dolů vedle sebe na skutečné kabelové mřížce, s roztečí50cm. Zvenčí i na vnitřní desce jsou zleva Output1, Output2 uprostřed a Output3 vpravo. Identita jednotlivých elektrických větví zůstává stejná; mění se jejich fyzické pozice. Řada krajních konektorů má metr, proto spodní společný kryt přesahuje0,8m skříň. Každý vývod má samostatnou nativní elektrickou pozici a vlastní funkční collider. Nový souvislý spodní kryt má tři svislé větve. Původní boční výstupy Medium je nutné znovu napojit vnějšími kabely; vnitřní propojení a názvy větví se nemění.

Horní Input Medium používá tentýž původní APC konektor jako výstupy, otočený nahoru. Nativní logická pozice Input se nemění. Vizuál sedí na skutečném kabelovém spoji, používá vlastní původní materiály a jeho hitbox přímo obsluhuje Input. Horní krček má odpovídající průřez. Small a Reverse mají dosavadní konektory a rozložení.

Opraven InvalidCastException v DoorModules.CanConstruct při míření dovnitř otevřeného rozvaděče na jiný typ montážní desky/hostitele (například DIN lištu nebo kryt). Kontrola nejprve ověří správný typ hostitele a desky; nevhodná plocha vrátí neplatnou montáž bez pádu. Na správných dveřích zůstává snap a kontrola obsazení. Door Bridge se přichytí k nejbližší pozici u pantu, včetně krajních pozic Small/Reverse/Medium; obsazenou pozici nepřeskakuje a podržený montážní lock uchová konkrétní místo. Obě křídla mají vlastní4x3pozice. Součástí je oprava DIN kurzoru a o25cmnižší poloha Medium z0.13.82.

Stejný Kit (Switchboard), třetí varianta Medium; tři DIN řady po14pozicích, dvojité dveře ovládané společným nativním Open. Žádné automatické elektrické propojení. Vnitřní štítky vyžadují vnitřní kryt.

Ověření84: Releasebuild0chyb/varování;126kontrol nativních vývodů včetně pořadí1–2–3;12464kontrol obvodů/energie/tras/serializace a scénář přepojení vnitřních tras po přesunu svorek2/3 se zachováním identit a spotřeby kabelů;54případů zadní krabice/koridoru a8928trojúhelníků (celé tělo, různé překryvy a délky, otevřený vnitřní spoj);27případů zkosených spodních větví a5076trojúhelníků (orientace ploch, uzavřenost hran, triangulace). Tvorba těla a přechodu převzata přímo z produkčního Small; společný generátor.

Ověření předchozí83: Releasebuild bez chyb/varování;126kontrol nativních kabelových pozic včetně samostatných tří dolů orientovaných výstupů;27rozměrových případů nového krytu (3348trojúhelníků) s kontrolou triangulace, uzavřených hran a orientace ploch;73kontrol skutečných podmínek montáže dveří a přichycení bridge ve všech třech rozvaděčích včetně nevhodných hostitelů; funkčníInputfixture proSmall/Reverse/Medium, stavební stavy, nativní vizuální hitbox, duplicitní a chybné metadata. Testy používají náhrady Unity/nativních objektů. Skutečný herní runtime a multiplayer zde nejsou dostupné.

Instalace při vypnuté hře: nahraď složku ModularSwitchboards vmods; host i klienti stejná verze. Ve hře ověř všechny tři spodní kabely, vzhled a hitbox horního Input, dveřní montáž při otevřeném rozvaděči a save/load. Záloha0.13.51 zachovaná.

The winding uses the original Small transformer upper and lower gray clamps, including their atlas colors and full depth. The dial is raised 4 mm to clear the upper clamp.

Source archive: generated Art/TransformerGeometry.json and Art/TransformerMediumGeometry.json are omitted to fit the upload size. Regenerate both with Verification/TransformerFront/extract.py and its Check.csproj; production meshes, native Medium reference, textures, Blender projects and code are included.

Source ZIP omits regenerable Art/MediumCover.json, MediumRibs.json and MediumWinding.json as well as the generated transformer geometry exports. Regenerate the part JSON with Tools/export_medium_transformer_parts.py; original reference, provenance, production meshes/textures and Blender project remain included.

Generated Art/KitGeometry.json is also omitted from the source ZIP. Recreate it by running Verification/KitGeometry/Check.csproj with KIT_GEOMETRY_EXPORT set to the desired Art/KitGeometry.json path. All kit source data, production assets and generators remain included.
