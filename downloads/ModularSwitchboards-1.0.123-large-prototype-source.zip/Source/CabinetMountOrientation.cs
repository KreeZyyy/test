using Assets.Scripts;
using Assets.Scripts.Inventory;
using Assets.Scripts.Objects;
using UnityEngine;
namespace ModularSwitchboards
{
    // Only the first actual wall mount of this preview gets an upright default.
    public sealed class CabinetMountOrientation:MonoBehaviour
    {
        private bool pending=true;
        private void OnEnable(){pending=true;}
        internal static void BeforeMount(Structure __instance)
        {
            if(CabinetShape.Large(__instance.PrefabName))return;
            if(GameManager.IsBatchMode||!__instance.IsCursor||!SwitchboardsMod.IsCabinetName(__instance.PrefabName)||
                InventoryManager.CurrentMode!=InventoryManager.Mode.Placement||
                !(InventoryManager.ActiveHandSlot?.Get() is MultiConstructor kit)||kit.PrefabName!=SwitchboardsMod.KitName)return;
            var state=__instance.GetComponent<CabinetMountOrientation>();if(state==null||!state.pending)return;
            var forward=__instance.ThingTransform.forward;
            if(Mathf.Abs(Vector3.Dot(forward,Vector3.up))>.01f)return;
            state.pending=false;
            // Keep a roll or smart-rotate explicitly requested on that first frame.
            if(KeyManager.GetButtonUp(KeyMap.RotateRollLeft)||KeyManager.GetButtonUp(KeyMap.RotateRollRight)||KeyManager.GetButton(KeyMap.QuantityModifier))return;
            var up=Vector3.ProjectOnPlane(Vector3.up,forward).normalized;
            __instance.ThingTransform.rotation=Quaternion.LookRotation(forward,up);
            InventoryManager.CurrentRotation=__instance.ThingTransform.rotation;
        }
    }
}
