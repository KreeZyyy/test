using System;
using System.Collections.Generic;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class LargeCabinetGeometry
    {
        // Start with our authored two-leaf Medium geometry, not a vanilla mesh.
        // Bake dimensions into the meshes; never scale a board's transform, which
        // would also distort all subsequently fitted DIN modules and their pitch.
        internal static void ResizeAuthoredBody(SwitchboardCabinet host)
        {
            if(!LargeCabinetDimensions.Ready)throw new InvalidOperationException("Native Locker dimensions must be measured first.");
            host.GetComponent<CabinetDoor>().OpenAngle=90f;
            var model=host.transform.Find("SwitchboardModel");
            var scale=new Vector3(LargeCabinetDimensions.Width/.8f,LargeCabinetDimensions.Height,LargeCabinetDimensions.Depth/(.18f+CabinetRearDepth.NominalDepth));
            var meshes=new Dictionary<Mesh,Mesh>();
            foreach(var filter in model.GetComponentsInChildren<MeshFilter>(true))
            {
                if(filter.sharedMesh==null)continue;
                if(!meshes.TryGetValue(filter.sharedMesh,out var replacement))
                {replacement=Resize(filter.sharedMesh,scale);meshes.Add(filter.sharedMesh,replacement);}
                filter.sharedMesh=replacement;
            }
            foreach(var collider in model.GetComponentsInChildren<MeshCollider>(true))
                if(collider.sharedMesh!=null&&meshes.TryGetValue(collider.sharedMesh,out var replacement))collider.sharedMesh=replacement;
            foreach(var collider in model.GetComponentsInChildren<BoxCollider>(true))
            {collider.center=Vector3.Scale(collider.center,scale);collider.size=Vector3.Scale(collider.size,scale);}
            foreach(var child in model.GetComponentsInChildren<Transform>(true))
                if(child!=model)child.localPosition=Vector3.Scale(child.localPosition,scale);
            foreach(var action in host.Interactables)if(action.Collider is BoxCollider hit)action.Bounds=new Bounds(Vector3.zero,hit.size);
            // Native placement origin is preserved; the body occupies the same
            // vertical extent as Locker. Root-scale stays one on all boards.
            model.localPosition=new Vector3(0,LargeCabinetDimensions.NativeBounds.center.y,LargeCabinetDimensions.NativeBounds.center.z-CabinetModel.FrontSign*(.18f-CabinetRearDepth.NominalDepth)*.5f*scale.z);
        }
        internal static Mesh Resize(Mesh source,Vector3 scale)
        {
            if(scale.x<=0||scale.y<=0||scale.z<=0)throw new ArgumentOutOfRangeException(nameof(scale));
            var mesh=UnityEngine.Object.Instantiate(source);mesh.name="Large."+source.name;
            var points=mesh.vertices;for(int i=0;i<points.Length;i++)points[i]=Vector3.Scale(points[i],scale);mesh.vertices=points;
            mesh.RecalculateNormals();mesh.RecalculateTangents();mesh.RecalculateBounds();return mesh;
        }
    }
}
