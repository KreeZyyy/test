using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
namespace ModularSwitchboards
{
    [Serializable] public sealed class CoverHole
    {
        public float Left,Right,Bottom,Top;
        public CoverHole(){}
        internal CoverHole(WireRect r){Left=r.Left;Right=r.Right;Bottom=r.Bottom;Top=r.Top;}
        internal WireRect Rect=>new WireRect(Left,Right,Bottom,Top);
    }
    [Serializable] public sealed class CoverLabelMemory
    {
        public int X,Y,Width;public long OwnerId;public string Text;
        public CoverHole[] Holes=new CoverHole[0];
        internal string Key=>X+":"+Y+":"+Width;
    }
    [Serializable] public sealed class CoverMemory
    {
        public float Width,Height,Depth,Sheet;
        public int Colour;public bool FixedColour;
        public CoverLabelMemory[] Labels=new CoverLabelMemory[0];
        internal int FullSlots=>DinLayout.FullModuleCount(Height>1.05f?Width-.124f:Width>.5f?.65f:DinLayout.CabinetInnerWidth);
        internal int[] LabelRows
        {
            get
            {
                if(Height<=1.05f)return Height>.7f?new[]{-600,0,600}:new[]{-240,240};
                int outer=(int)Math.Floor(((Height+.026f)*.5f-.27f)/.018f)*10,inner=(outer/30)*10;
                return new[]{-outer*4,-inner*4,inner*4,outer*4};
            }
        }
        internal float HalfSpan=>(FullSlots-1)*DinLayout.SlotPitch*.5f;
        internal InnerCoverLayout.Panel Profile=>new InnerCoverLayout.Panel(Width,Height,Depth,Sheet);
        internal bool Fits(InnerCoverLayout.Panel p)=>Math.Abs(Width-p.Width)<.00001f&&Math.Abs(Height-p.Height)<.00001f&&Math.Abs(Depth-p.Depth)<.00001f&&Math.Abs(Sheet-p.Sheet)<.00001f;
        internal static CoverMemory Fresh(InnerCoverLayout.Panel p,int colour)=>new CoverMemory{Width=p.Width,Height=p.Height,Depth=p.Depth,Sheet=p.Sheet,Colour=colour};
        internal IEnumerable<WireRect> Retained=>(Labels??new CoverLabelMemory[0]).SelectMany(l=>l.Holes??new CoverHole[0]).Select(h=>h.Rect);
        private static string Key(WireRect r)=>string.Join(":",new[]{r.Left,r.Right,r.Bottom,r.Top}.Select(v=>v.ToString("F6",System.Globalization.CultureInfo.InvariantCulture)));
        internal CoverMemory Reconcile(IEnumerable<CoverLabelMemory> live,IEnumerable<WireRect> current)
        {
            var holes=current.ToArray();var old=(Labels??new CoverLabelMemory[0]).ToDictionary(l=>l.Key);
            var next=Fresh(Profile,Colour);next.FixedColour=FixedColour;float halfSpan=HalfSpan;
            next.Labels=live.OrderBy(l=>l.Y).ThenBy(l=>l.X).Select(l=>
            {
                var area=InnerCoverLayout.Window(-halfSpan+(l.X/90+(l.Width-1)*.5f)*DinLayout.SlotPitch,l.Y*.00045f,l.Width,false);
                // Labels own full slot cells, avoiding a new web between two
                // adjacent labels that jointly preserve one wide aperture.
                float cx=(area.Left+area.Right)*.5f;area.Left=cx-l.Width*DinLayout.SlotPitch*.5f;area.Right=cx+l.Width*DinLayout.SlotPitch*.5f;
                var pinned=old.TryGetValue(l.Key,out var saved)&&(saved.OwnerId==0||saved.OwnerId==l.OwnerId)?saved.Holes.Select(h=>h.Rect):Enumerable.Empty<WireRect>();
                var pieces=pinned.Concat(holes.Select(h=>new WireRect(Math.Max(h.Left,area.Left),Math.Min(h.Right,area.Right),Math.Max(h.Bottom,area.Bottom),Math.Min(h.Top,area.Top))))
                    .Where(h=>h.Right-h.Left>.000001f&&h.Top-h.Bottom>.000001f).GroupBy(Key).Select(g=>new CoverHole(g.First())).ToArray();
                return new CoverLabelMemory{X=l.X,Y=l.Y,Width=l.Width,OwnerId=l.OwnerId,Text=l.Text,Holes=pieces};
            }).ToArray();return next;
        }
        private static readonly XmlSerializer Serializer=new XmlSerializer(typeof(CoverMemory));
        internal string Pack(){using(var w=new StringWriter(System.Globalization.CultureInfo.InvariantCulture)){Serializer.Serialize(w,this);return w.ToString();}}
        internal static CoverMemory Unpack(string xml)
        {
            if(string.IsNullOrEmpty(xml))return null;if(xml.Length>262144)throw new InvalidDataException("Cover state is too large.");
            using(var r=XmlReader.Create(new StringReader(xml),new XmlReaderSettings{DtdProcessing=DtdProcessing.Prohibit,XmlResolver=null}))
            {var state=(CoverMemory)Serializer.Deserialize(r);state.Validate();return state;}
        }
        internal void Validate()
        {
            if(Colour<0||Colour>255||!Finite(Width)||!Finite(Height)||!Finite(Depth)||!Finite(Sheet)||Width<.1f||Width>3||Height<.1f||Height>3||Math.Abs(Depth)>1||Sheet<.0001f||Sheet>.01f||Labels==null||Labels.Length>256)throw new InvalidDataException("Invalid cover profile.");
            var keys=new HashSet<string>();int slots=FullSlots;
            foreach(var l in Labels)
            {
                if(l==null||l.OwnerId<0||!keys.Add(l.Key)||l.X%90!=0||l.X<0||l.X/90+l.Width>slots||!new[]{1,2,3,4,6}.Contains(l.Width)||!LabelRows.Contains(l.Y)||(l.Text?.Length??0)>2048||l.Holes==null||l.Holes.Length>128)throw new InvalidDataException("Invalid retained cover label.");
                foreach(var other in Labels)if(other!=null&&!ReferenceEquals(l,other)&&l.Y==other.Y&&l.X<other.X+other.Width*90&&other.X<l.X+l.Width*90)throw new InvalidDataException("Overlapping cover labels.");
                foreach(var h in l.Holes)if(h==null||!Finite(h.Left)||!Finite(h.Right)||!Finite(h.Bottom)||!Finite(h.Top)||h.Left>=h.Right||h.Bottom>=h.Top||Math.Abs(h.Left)>Width/2+.001f||Math.Abs(h.Right)>Width/2+.001f||Math.Abs(h.Bottom)>Height/2+.001f||Math.Abs(h.Top)>Height/2+.001f)throw new InvalidDataException("Invalid retained cover aperture.");
            }
        }
        private static bool Finite(float v)=>!float.IsNaN(v)&&!float.IsInfinity(v);
    }
}
