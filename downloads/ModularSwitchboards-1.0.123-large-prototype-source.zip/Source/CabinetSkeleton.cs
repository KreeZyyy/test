using System.Collections.Generic;
using Assets.Scripts.Objects;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class CabinetSkeleton
    {
        internal static void Install(Structure cabinet)
        {
            var model=cabinet.transform.Find("SwitchboardModel");var filter=model.Find("Frame").GetComponent<MeshFilter>();var source=filter.sharedMesh;
            var p=new CabinetSkeletonGeometry.Profile(CabinetShape.Medium(cabinet.PrefabName)?2:1);
            var vertices=new List<Vector3>();var normals=new List<Vector3>();var triangles=new List<int>();
            CabinetSkeletonGeometry.Ring(vertices,normals,triangles,p,CabinetSkeletonGeometry.Rear,CabinetSkeletonGeometry.Rear+CabinetSkeletonGeometry.RingDepth);
            CabinetSkeletonGeometry.Ring(vertices,normals,triangles,p,CabinetSkeletonGeometry.Front-CabinetSkeletonGeometry.RingDepth,CabinetSkeletonGeometry.Front);
            foreach(var rail in CabinetSkeletonGeometry.DepthRails(p))RoundedGeometry.Box(vertices,normals,triangles,rail.center,rail.size,.001f);
            int role=0,max=0;for(int i=0;i<source.subMeshCount;i++){int count=source.GetTriangles(i).Length;if(count>max){max=count;role=i;}}
            var mesh=new Mesh{name="Switchboards.ProfiledCabinetSkeleton",indexFormat=UnityEngine.Rendering.IndexFormat.UInt32};mesh.SetVertices(vertices);mesh.SetNormals(normals);mesh.subMeshCount=source.subMeshCount;
            for(int i=0;i<mesh.subMeshCount;i++)mesh.SetTriangles(i==role?triangles:new List<int>(),i);
            CabinetGeometry.ApplyNativeUv(mesh);mesh.RecalculateBounds();
            if(CabinetShape.Large(cabinet.PrefabName))
            {
                var resized=LargeCabinetGeometry.Resize(mesh,new Vector3(LargeCabinetDimensions.Width/.8f,LargeCabinetDimensions.Height,LargeCabinetDimensions.Depth/(.18f+CabinetRearDepth.NominalDepth)));
                Object.DestroyImmediate(mesh);mesh=resized;
            }
            filter.sharedMesh=mesh;
            // Match the rounded rails themselves, including curved corners.
            // Native cabinet housing already uses static non-convex MeshColliders.
            foreach(var old in cabinet.BuildStates[0].Colliders)if(old!=null)Object.DestroyImmediate(old);
            cabinet.BuildStates[0].Colliders.Clear();
            var go=new GameObject("ProfiledFrameCollider"){layer=cabinet.gameObject.layer};go.transform.SetParent(model,false);
            var hit=go.AddComponent<MeshCollider>();hit.sharedMesh=mesh;hit.enabled=false;cabinet.BuildStates[0].Colliders.Add(hit);
        }
    }
}
