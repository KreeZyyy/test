using System;
using System.Collections.Generic;
using System.Linq;
using Assets.Scripts;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Electrical;
using Assets.Scripts.Networks;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class LargeCabinetPorts
    {
        internal static void Install(SwitchboardCabinet host)
        {
            var reference=WorldManager.Instance.SourcePrefabs.OfType<AreaPowerControl>().First();
            host.SmallCollisionType=reference.SmallCollisionType;host.UsedPower=0f;
            host.OpenEnds=new List<Connection>();
            var shell=host.transform.Find("SwitchboardModel/CompletedShell");
            var b=LargeCabinetDimensions.NativeBounds;
            // Two rows of native half-metre cable cells: 1 IN and 3 isolated OUT.
            // All face upwards. A small raised collar bridges the mesh top to
            // each native grid face, without moving the electrical endpoint.
            var bodies=LargeCabinetDimensions.TopBodyCells();
            var cells=new HashSet<string>();
            for(int i=0;i<4;i++)
            {
                var socket=NativeCableLayout.ReadForBody(bodies[i],Vector3.up);
                if(!cells.Add(socket.CableCell.ToString()))throw new InvalidOperationException("Large top cable ports overlap.");
                var root=new GameObject(i==0?CabinetPowerInput.RootName:"LargePowerOutput"+i){layer=host.gameObject.layer};
                root.transform.SetParent(host.transform,false);root.transform.localPosition=socket.Point;
                root.transform.localRotation=Quaternion.LookRotation(socket.Forward,Vector3.forward);
                var hit=ExternalCablePorts.AttachNativeOutput(host,root.transform);
                hit.transform.localPosition=Quaternion.Inverse(root.transform.localRotation)*(socket.ContactPoint-socket.Point);
                var role=i==0?ConnectionRole.Input:CabinetShape.OutputRole(i-1);
                var port=new Connection(host){Transform=root.transform,Collider=hit,ConnectionRole=role,ConnectionType=NetworkType.None};
                port.Validate();host.OpenEnds.Add(port);host.BuildStates[1].Colliders.Add(hit);
                // Native lug geometry is placed relative to the connection's
                // cable cell. Keep its contact plane aligned to the cable mouth.
                float top=b.max.y;var mouth=host.transform.InverseTransformPoint(hit.transform.TransformPoint(hit.center));
                float bottom=Mathf.Min(top,mouth.y-.03f),height=Mathf.Abs(mouth.y-top)+.025f;
                var pedestal=new GameObject("TopPortSupport"+i){layer=host.gameObject.layer};pedestal.transform.SetParent(shell,false);
                pedestal.transform.position=host.transform.TransformPoint(new Vector3(mouth.x,bottom+height*.5f,mouth.z));
                var points=new List<Vector3>();var normals=new List<Vector3>();var indices=new List<int>();
                RoundedGeometry.Box(points,normals,indices,Vector3.zero,new Vector3(.12f,height,.12f),.004f);
                var mesh=new Mesh{name="Switchboards.LargeTopPortSupport"};mesh.SetVertices(points);mesh.SetNormals(normals);mesh.subMeshCount=CabinetGeometry.Materials.Length;
                for(int s=0;s<mesh.subMeshCount;s++)mesh.SetTriangles(s==CabinetRearSurface.Role?indices:new List<int>(),s);
                CabinetGeometry.ApplyNativeUv(mesh);mesh.RecalculateBounds();pedestal.AddComponent<MeshFilter>().sharedMesh=mesh;
                var renderer=pedestal.AddComponent<MeshRenderer>();renderer.sharedMaterials=CabinetGeometry.Materials;CabinetRearSurface.Restore(renderer);
                var collider=pedestal.AddComponent<MeshCollider>();collider.sharedMesh=mesh;host.BuildStates[1].Colliders.Add(collider);
                host.BuildStates[1].LinkedGameObjects.Add(root);
            }
            CabinetModel.SetBounds(host);
        }
    }
}
