using System.Reflection;
using Assets.Scripts.Objects;
namespace ModularSwitchboards
{
    internal static class LargeCabinetPlacement
    {
        internal static void Install(SwitchboardCabinet host,Structure native)
        {
            host.PlacementType=native.PlacementType;host.AllowedRotations=native.AllowedRotations;
            host.RotationAxis=native.RotationAxis;host.GridSize=native.GridSize;host.GridOffset=native.GridOffset;
            for(var type=typeof(Structure);type!=null;type=type.BaseType)
                foreach(var field in type.GetFields(BindingFlags.Instance|BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.DeclaredOnly))
                    if(!field.IsInitOnly&&(field.Name=="_useAxisIndependentGridSnapping"||field.Name.StartsWith("_grid")||field.Name=="requiresFrame"))field.SetValue(host,field.GetValue(native));
            if(native is SmallGrid grid)host.DualRegister=grid.DualRegister;
            var wall=host.GetComponent<CabinetWallFit>();if(wall!=null)UnityEngine.Object.DestroyImmediate(wall);
        }
    }
}
