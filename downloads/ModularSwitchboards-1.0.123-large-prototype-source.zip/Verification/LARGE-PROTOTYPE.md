# Modular Switchboards 1.0.123 — standing Large prototype

Local test prototype, not yet tested in Unity. Not a Steam Workshop update.

- Standing on the floor, with native StructureStorageLocker dimensions read at startup. Own authored cabinet shell, interior and double doors; does not reuse the Locker storage model.
- Four longer DIN rows; standard modules keep their original size and pitch. Each row costs one Rail kit.
- One IN and three isolated OUT ports, all facing upwards in two rows of native cable-grid cells. No automatic connection to neighbouring cabinets or internal bridging.
- Doors open to 90 degrees. Both door control/label/bridge boards are preserved in save and multiplayer payloads.
- Prototype economy: 6 cabinet kits plus 10 Plastic Sheets; optional Large cover 4 cover kits. Empty cover returns kits, labelled cover retains its state.
- New F1 entry and four label rows; existing Small/Medium layouts and costs unchanged.
- For this first shape test the kit/F1 still uses the Medium thumbnail. Dedicated Large icons and detailed visual refinement remain pending.

Validation: full native-reference build with 0 warnings/errors; 168 layout/terminal/cover-save checks across nine dimension profiles, 78 direct cover checks, 94 cover-transfer checks, 25 door load/animation checks, 8005 cover-memory checks and 22 wiring-readiness checks passed. These use stubs/fixtures, not actual Unity playtesting.

Try on a test save with one active copy of the mod. Select Large from the Switchboard Kit. Check the floor snap, closed/open doors, all four DIN rows, roof connector/cable alignment and wall clearance, cover, save/load and refunds. Actual native Locker dimensions are logged during startup. If Large setup fails, existing variants are retained and the log names the Large error. Multiplayer is untested.

