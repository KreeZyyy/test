from pathlib import Path
root=Path(__file__).resolve().parents[1];out=root/'Verification/ContactorGeometry';out.mkdir(exist_ok=True)
def method(s,marker):
 a=s.index(marker);b=s.index('{',a);e=b+1;n=1
 while n:n+=(s[e]=='{')-(s[e]=='}');e+=1
 return s[a:e]
stubs=(root/'Verification/SmartOutputGeometry/Stubs.cs').read_text()
stubs=stubs.replace('public struct Vector2{','public struct Vector2{public static Vector2 operator +(Vector2 a,Vector2 b)=>new(a.x+b.x,a.y+b.y);public static Vector2 operator -(Vector2 a,Vector2 b)=>new(a.x-b.x,a.y-b.y);public static Vector2 operator *(Vector2 a,float b)=>new(a.x*b,a.y*b);')
stubs=stubs.replace('public struct Vector3{','public struct Vector3{public float this[int i]{get=>i==0?x:i==1?y:z;set{if(i==0)x=value;else if(i==1)y=value;else z=value;}}public float sqrMagnitude=>x*x+y*y+z*z;')
stubs=stubs.replace('public class Mesh{','public class Mesh{public UnityEngine.Rendering.IndexFormat indexFormat;public void RecalculateTangents(){}')
stubs=stubs.replace('public void RecalculateNormals(){}','public void RecalculateNormals(){N=Enumerable.Repeat(Vector3.forward,V.Count).ToList();foreach(var ids in T.Values)for(int i=0;i<ids.Length;i+=3){var a=V[ids[i]];var b=V[ids[i+1]];var c=V[ids[i+2]];var n=Vector3.Cross(b-a,c-a).normalized;N[ids[i]]=N[ids[i+1]]=N[ids[i+2]]=n;}}')
stubs=stubs.replace('static class CabinetGeometry{','static class CabinetGeometry{internal static void ReadNativeMesh(UnityEngine.Mesh m,out UnityEngine.Vector3[] v,out UnityEngine.Vector2[] uv,out int[][] t){v=m.vertices;uv=m.UV?.ToArray()??new UnityEngine.Vector2[v.Length];t=Enumerable.Range(0,m.subMeshCount).Select(m.GetTriangles).ToArray();}')
stubs+='namespace UnityEngine{public struct Matrix4x4{public static Matrix4x4 identity=>new();public float determinant=>1;public Vector3 MultiplyPoint3x4(Vector3 v)=>v;}public class Object{public static void DestroyImmediate(object o){}}}namespace UnityEngine.Rendering{public enum IndexFormat{UInt32}}'
(out/'Stubs.cs').write_text(stubs)
base=(root/'Source/DinBreakerModel.cs').read_text();model=(root/'Source/DinContactorModel.cs').read_text()
(out/'Extracted.cs').write_text('using System;using System.Collections.Generic;using UnityEngine;namespace ModularSwitchboards{static class DinBreakerModel{internal static Vector3 VisualScale=new(2.25f,1.35f,1.15f);'+method(base,'internal static Mesh Build(')+method(base,'private static void EndDisk(')+'}static class DinContactorModel{'+method(model,'internal static Mesh Build(')+'}static class WireContactLayout{internal const float BreakerEntryY=.0375f,BreakerEntryZ=.029f;}}')
(out/'Check.csproj').write_text('''<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><OutputType>Exe</OutputType><TargetFramework>net8.0</TargetFramework></PropertyGroup><ItemGroup><Compile Include="../../Source/RoundedGeometry.cs"/><Compile Include="../../Source/BatteryAperture.cs"/><Compile Include="../../Source/NativeMeshCrop.cs"/></ItemGroup></Project>''')

window=(root/'Source/ApcContactorWindow.cs').read_text()
map_method=window[window.index('internal static Vector3 Map('):window.index(';',window.index('internal static Vector3 Map('))+1]
with(out/'Extracted.cs').open('a')as f:f.write('namespace ModularSwitchboards{static class ApcContactorWindow{internal const float Scale=.17f;internal static readonly Bounds Region=new(new Vector3(.069f,0,.184f),new Vector3(.154f,.30f,.032f));'+map_method+method(window,'internal static Mesh Build(')+'}}')
