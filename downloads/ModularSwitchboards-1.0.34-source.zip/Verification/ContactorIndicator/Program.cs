using System;using ModularSwitchboards;
class Program
{
 static int checks;static void Check(bool v,string why){checks++;if(!v)throw new Exception(why);}
 static void Main()
 {
  var m=new ContactorIndicatorMotion();
  Check(!m.Tick(false,true,1)&&m.Offset==ContactorIndicatorMotion.HalfTravel,"cursor stays OFF and silent");
  Check(!m.Tick(true,true,0)&&m.Offset==-ContactorIndicatorMotion.HalfTravel,"joining energized contact snaps silently");
  Check(!m.Tick(true,true,1),"steady ON silent");
  Check(m.Tick(true,false,.03f)&&m.Offset>-ContactorIndicatorMotion.HalfTravel&&m.Offset<ContactorIndicatorMotion.HalfTravel,"release changes once and moves strip");
  Check(!m.Tick(true,false,.1f)&&m.Offset==ContactorIndicatorMotion.HalfTravel,"release finishes without second sound");
  Check(m.Tick(true,true,.03f)&&m.Offset<ContactorIndicatorMotion.HalfTravel&&m.Offset>-ContactorIndicatorMotion.HalfTravel,"pickup moves opposite direction");
  Check(m.Tick(true,false,ContactorIndicatorMotion.HalfTravel),"reversal is a new transition");
  for(int i=0;i<100;i++)Check(!m.Tick(true,false,.016f),"no repeated clacks");
  Check(m.Offset==ContactorIndicatorMotion.HalfTravel,"no motion overshoot");
  Check(!m.Tick(false,false,.1f)&&!m.Tick(true,true,.01f),"reinstalled contact establishes silent baseline");
  Check(m.Tick(true,false,-1)&&m.Offset==-ContactorIndicatorMotion.HalfTravel,"negative delta does not reverse motion");
  Console.WriteLine(checks+" contactor indicator checks passed.");
 }
}
