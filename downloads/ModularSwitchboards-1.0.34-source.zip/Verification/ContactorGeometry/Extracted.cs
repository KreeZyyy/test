using System;using System.Collections.Generic;using UnityEngine;namespace ModularSwitchboards{static class DinBreakerModel{internal static Vector3 VisualScale=new(2.25f,1.35f,1.15f);internal static Mesh Build(float width=.0176f,float centerX=0f,bool battery=false,float openingX=0f,float openingY=0f,bool plain=false,bool inputOnly=false,bool bottomOnly=false)
        {
            var vertices=new List<Vector3>();var normals=new List<Vector3>();var triangles=new List<int>[5];
            for(int i=0;i<5;i++)triangles[i]=new List<int>();
            System.Action<Vector3,Vector3,int,float> shape=(center,size,role,radius)=>
            {
                center.x+=centerX;
                if(!battery){RoundedGeometry.Box(vertices,normals,triangles[role],center,size,radius);return;}
                // Same breaker surfaces, with only the seated battery aperture cut out.
                float holeX=openingX>0?openingX:ApcBatteryRegion.SocketHeight/VisualScale.x;
                float holeY=openingY>0?openingY:ApcBatteryRegion.SocketHeight/VisualScale.y;
                BatteryAperture.Box(vertices,normals,triangles[role],center,size,radius,holeX,holeY,openingX>0?0:holeX*.1f,openingX>0?0:holeY*.1f);

            };
            shape(new Vector3(0,0,.029f),new Vector3(width,.075f,.056f),1,.0018f);
            shape(new Vector3(0,0,.059f),new Vector3(width,.052f,.008f),1,.0015f);
            shape(new Vector3(0,0,.0635f),new Vector3(width-.0046f,.045f,.001f),3,.0004f);
            if(battery)
            {
                // The slightly larger native cell extends just behind the former
                // rear plane. Recess only its rear cover; fuse rear walls stay put.
                float rear=openingX>0?.003f:-.0018f,depth=openingX>0?.002f:.0016f;
                // One continuous liner from the closed rear to the actual front.
                // The former three overlapping wall sets are deliberately absent.
                float holeX=openingX>0?openingX:ApcBatteryRegion.SocketHeight/VisualScale.x;
                float holeY=openingY>0?openingY:ApcBatteryRegion.SocketHeight/VisualScale.y;
                float rearFace=rear+depth*.5f;
                BatteryAperture.Walls(vertices,normals,triangles[3],new Vector3(centerX,0,(rearFace+.064f)*.5f),
                    new Vector3(width,.075f,.064f-rearFace),holeX,holeY,openingX>0?0:holeX*.1f,openingX>0?0:holeY*.1f);
                RoundedGeometry.Box(vertices,normals,triangles[3],new Vector3(centerX,0,rear),new Vector3(width,.075f,depth),.0007f);
            }
            foreach(float side in bottomOnly?new[]{-1f}:inputOnly?new[]{1f}:new[]{-1f,1f})
            {
                RoundedGeometry.Box(vertices,normals,triangles[4],new Vector3(centerX,side*.03f,.0577f),new Vector3(.009f,.009f,.0015f),.0005f);
                RoundedGeometry.Box(vertices,normals,triangles[3],new Vector3(centerX,side*.03f,.0586f),new Vector3(.006f,.001f,.0005f),.00015f);
            }
            foreach(float side in bottomOnly?new[]{-1f}:inputOnly?new[]{1f}:new[]{-1f,1f})
            {
                EndDisk(vertices,normals,triangles[4],new Vector3(centerX,side*(WireContactLayout.BreakerEntryY+.0001f),WireContactLayout.BreakerEntryZ),.0042f,side);
                EndDisk(vertices,normals,triangles[3],new Vector3(centerX,side*(WireContactLayout.BreakerEntryY+.0002f),WireContactLayout.BreakerEntryZ),.0032f,side);
            }
            // Two fixed spindle bearings straddle the flap, matching the APC's mounting.
            // Their inner edges clear the 12 mm plate while enclosing its axle ends.
            if(!battery&&!plain)foreach(float side in bottomOnly?new[]{-1f}:inputOnly?new[]{1f}:new[]{-1f,1f})
                RoundedGeometry.Box(vertices,normals,triangles[4],new Vector3(centerX+side*.0073f,0,.0667f),
                    new Vector3(.0022f,.0042f,.0048f),.0007f);
            var mesh=new Mesh{name="Switchboards.RoundedBreaker"};mesh.SetVertices(vertices);mesh.SetNormals(normals);mesh.subMeshCount=5;
            for(int i=0;i<5;i++)mesh.SetTriangles(triangles[i],i);
            CabinetGeometry.ApplyNativeUv(mesh);mesh.RecalculateBounds();return mesh;
        }private static void EndDisk(List<Vector3> vertices,List<Vector3> normals,List<int> triangles,Vector3 center,float worldRadius,float side)
        {
            for(int i=0;i<16;i++)
            {
                float a=i*Mathf.PI/8,b=(i+1)*Mathf.PI/8;
                var p=center+new Vector3(Mathf.Cos(a)*worldRadius/VisualScale.x,0,Mathf.Sin(a)*worldRadius/VisualScale.z);
                var q=center+new Vector3(Mathf.Cos(b)*worldRadius/VisualScale.x,0,Mathf.Sin(b)*worldRadius/VisualScale.z);
                int start=vertices.Count;vertices.AddRange(side>0?new[]{center,q,p}:new[]{center,p,q});normals.AddRange(new[]{Vector3.up*side,Vector3.up*side,Vector3.up*side});triangles.AddRange(new[]{start,start+1,start+2});
            }
        }}static class DinContactorModel{internal static Mesh Build()
        {
            var body=DinBreakerModel.Build(plain:true);
            // Replace the single top terminal with two independently aimed terminals.
            var cropped=NativeMeshCrop.Outside(body,new Bounds(new Vector3(0,.030f,.059f),new Vector3(.011f,.011f,.005f)),"Contactor.Housing");
            var cavity=NativeMeshCrop.Outside(cropped,new Bounds(new Vector3(0,0,.063f),new Vector3(.0117f,.039f,.012f)),"Contactor.WindowCavity");
            UnityEngine.Object.DestroyImmediate(cropped);cropped=cavity;
            var v=new List<Vector3>(cropped.vertices);var n=new List<Vector3>(cropped.normals);var g=new List<int>[5];for(int i=0;i<5;i++)g[i]=new List<int>(cropped.GetTriangles(i));
            foreach(float x in new[]{-.004f,.004f})
            {
                RoundedGeometry.Box(v,n,g[4],new Vector3(x,.030f,.058f),new Vector3(.0057f,.009f,.0015f),.0004f);
                RoundedGeometry.Box(v,n,g[3],new Vector3(x,.030f,.059f),new Vector3(.0035f,.001f,.0005f),.0001f);
                RoundedGeometry.Box(v,n,g[4],new Vector3(x,.03755f,.029f),new Vector3(.0035f,.0003f,.006f),.0001f);
            }
            var mesh=new Mesh{name="DIN.Contactor.Body"};mesh.SetVertices(v);mesh.SetNormals(n);mesh.subMeshCount=5;for(int i=0;i<5;i++)mesh.SetTriangles(g[i],i);CabinetGeometry.ApplyNativeUv(mesh);mesh.RecalculateBounds();
            UnityEngine.Object.DestroyImmediate(body);UnityEngine.Object.DestroyImmediate(cropped);return mesh;
        }}static class WireContactLayout{internal const float BreakerEntryY=.0375f,BreakerEntryZ=.029f;}}namespace ModularSwitchboards{static class ApcContactorWindow{internal const float Scale=.17f;internal static readonly Bounds Region=new(new Vector3(.069f,0,.184f),new Vector3(.154f,.30f,.032f));internal static Vector3 Map(Vector3 p)=>new Vector3((p.x-.069f)*Scale/DinBreakerModel.VisualScale.x,p.y*Scale/DinBreakerModel.VisualScale.y,.064f+(p.z-.198f)*Scale/DinBreakerModel.VisualScale.z);internal static Mesh Build(Mesh original,Matrix4x4 frame)
        {
            var result=NativeMeshCrop.Read(original,frame,Region,"Contactor.OriginalAPCMasterWindow");
            if(result==null)throw new InvalidOperationException("Original APC master window not found.");
            var points=result.vertices;for(int i=0;i<points.Length;i++)points[i]=Map(points[i]);result.vertices=points;
            result.RecalculateNormals();result.RecalculateTangents();result.RecalculateBounds();return result;
        }}}