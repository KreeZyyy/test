using System;
using System.Linq;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Electrical;
using UnityEngine;

namespace ModularSwitchboards
{
    internal static class ApcLeverGeometry
    {
        private static Mesh mesh;
        private static Material[] materials;
        private static MaterialPropertyBlock[] blocks;
        private static bool attempted;

        internal static bool TryGet(out Mesh result,out Material[] surface)
        {
            if(!attempted)
            {
                attempted=true;
                try
                {
                    var prefabs=WorldManager.Instance.SourcePrefabs.OfType<AreaPowerControl>();
                    var apc=prefabs.FirstOrDefault(p=>p.PrefabName=="StructureAreaPowerControl") ?? prefabs.FirstOrDefault();
                    var source=apc==null?null:apc.GetComponentsInChildren<MeshRenderer>(true).FirstOrDefault(r=>r.name=="MasterLever");
                    var original=source==null?null:source.GetComponent<MeshFilter>()?.sharedMesh;
                    if(original!=null)
                    {
                        CabinetGeometry.ReadNativeMesh(original,out var points,out var uv,out var triangles);
                        var matrix=apc.transform.worldToLocalMatrix*source.transform.localToWorldMatrix;
                        if(CabinetModel.FrontSign<0)matrix=Matrix4x4.Rotate(Quaternion.Euler(0,180,0))*matrix;
                        for(int i=0;i<points.Length;i++)points[i]=matrix.MultiplyPoint3x4(points[i]);
                        // Recover the broad face of the actual APC flap instead of treating its
                        // depth as a projecting handle. Neutralize its baked prefab pose.
                        Vector3 face=Vector3.forward;float largest=0f;
                        foreach(var indices in triangles)
                            for(int j=0;j<indices.Length;j+=3)
                            {
                                var cross=Vector3.Cross(points[indices[j+1]]-points[indices[j]],points[indices[j+2]]-points[indices[j]]);
                                if(cross.sqrMagnitude>largest){largest=cross.sqrMagnitude;face=cross.normalized;}
                            }
                        if(Vector3.Dot(face,Vector3.forward)<0)face=-face;
                        var right=Vector3.ProjectOnPlane(Vector3.right,face).normalized;
                        if(right.sqrMagnitude<.5f)throw new InvalidOperationException("APC flap face has no horizontal spindle axis");
                        var up=Vector3.Cross(face,right).normalized;
                        for(int i=0;i<points.Length;i++)
                            points[i]=new Vector3(Vector3.Dot(points[i],right),Vector3.Dot(points[i],up),Vector3.Dot(points[i],face));
                        FitFlap(points);
                        mesh=new Mesh{name="Switchboards.NativeAPCMasterLever"};mesh.vertices=points;mesh.uv=uv;mesh.subMeshCount=triangles.Length;
                        for(int sub=0;sub<triangles.Length;sub++)
                        {
                            if(matrix.determinant<0)for(int j=0;j<triangles[sub].Length;j+=3){int swap=triangles[sub][j+1];triangles[sub][j+1]=triangles[sub][j+2];triangles[sub][j+2]=swap;}
                            mesh.SetTriangles(triangles[sub],sub);
                        }
                        mesh.RecalculateNormals();mesh.RecalculateTangents();mesh.RecalculateBounds();
                        materials=source.sharedMaterials;
                        blocks=new MaterialPropertyBlock[materials.Length];var global=new MaterialPropertyBlock();source.GetPropertyBlock(global);
                        for(int i=0;i<blocks.Length;i++){var block=new MaterialPropertyBlock();source.GetPropertyBlock(block,i);blocks[i]=block.isEmpty?global:block;}
                        Debug.Log("[Modular Switchboards] Native APC MasterLever reused: "+points.Length+" vertices; edge spindle, broad flap fit 12x18x2.5 mm; original UV and materials retained.");
                    }
                }
                catch(Exception ex){mesh=null;Debug.LogWarning("[Modular Switchboards] APC lever extraction: "+ex.Message);}
                if(mesh==null)Debug.LogWarning("[Modular Switchboards] Native APC lever unavailable; rounded prototype handle used.");
            }
            result=mesh;surface=materials;return mesh!=null;
        }
        internal static void FitFlap(Vector3[] points)
        {
            var bounds=new Bounds(points[0],Vector3.zero);foreach(var point in points)bounds.Encapsulate(point);
            var size=bounds.size;
            var fit=new Vector3(.012f/Mathf.Max(size.x,.00001f),.018f/Mathf.Max(size.y,.00001f),.0025f/Mathf.Max(size.z,.00001f));
            for(int i=0;i<points.Length;i++)
            {
                var p=Vector3.Scale(points[i]-bounds.center,fit);
                // Hinge runs across the short edge: the plate extends upward from y=0.
                points[i]=p+new Vector3(0,.009f,0);
            }
        }
        internal static bool Restore(Renderer renderer)
        {
            if(mesh==null || renderer.GetComponent<MeshFilter>()?.sharedMesh!=mesh)return false;
            for(int i=0;i<blocks.Length;i++)renderer.SetPropertyBlock(blocks[i],i);
            return true;
        }
    }
}
