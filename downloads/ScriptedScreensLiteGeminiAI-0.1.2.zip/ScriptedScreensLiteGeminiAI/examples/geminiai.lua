--@module geminiai
-- ScriptedScreensLiteGeminiAI 0.1.2 — library chip module: geminiai
-- Use require("geminiai") from a chip on the same data network, or embed this factory.
local GeminiAI = {}

function GeminiAI.new(config)
    config = config or {}
    local host = ic.host_info()
    local self = {
        base = config.base or "http://localhost:18766",
        token = config.token or "PASTE_LOCAL_BRIDGE_TOKEN_HERE",
        source_ref_id = tostring(config.source_ref_id or (host and host.ref_id) or ""),
        conversation_id = config.conversation_id,
        system_prompt = config.system_prompt,
        speech_style = config.speech_style,
        voice = config.voice,
        sound_id = "geminiai_voice",
        audio_elapsed = nil, audio_deadline = nil, last_audio_key = nil,
        audio_start_grace = math.max(0, math.min(10, tonumber(config.audio_start_grace) or 0)),
        request = nil, kind = nil, job = nil, elapsed = 0, poll_elapsed = 0,
        timeout = config.timeout or 240, callback = nil,
    }
    local headers = {["X-Station-Token"] = self.token}
    local function complete(result, err)
        local callback = self.callback
        self.request, self.kind, self.job, self.callback = nil, nil, nil, nil
        if callback then callback(result, err) end
    end
    function self:busy() return self.request ~= nil or self.job ~= nil end
    function self:ask(question, preferences, callback)
        if self:busy() then return nil, "Dotaz už probíhá." end
        if self.token == "PASTE_LOCAL_BRIDGE_TOKEN_HERE" or #self.token < 24 then
            return nil, "Doplň místní Bridge Token; Gemini klíč do Lua nepatří."
        end
        if type(question) ~= "string" or not question:find("%S") then return nil, "Napiš zprávu." end
        if not self.source_ref_id:match("^%d+$") then return nil, "Chybí ReferenceId hostitelského zařízení." end
        preferences = preferences or {}
        local payload = {
            question = question, source_ref_id = self.source_ref_id,
            conversation_id = preferences.conversation_id or self.conversation_id,
            remember = preferences.remember ~= false, speak = preferences.speak ~= false,
            system_prompt = preferences.system_prompt or self.system_prompt,
            speech_style = preferences.speech_style or self.speech_style,
            voice = preferences.voice or self.voice,
            model = preferences.model, tts_model = preferences.tts_model,
            max_output_tokens = preferences.max_output_tokens, temperature = preferences.temperature,
        }
        local ok, encoded = pcall(util.json.encode, payload)
        if not ok then return nil, "Nastavení dotazu nelze převést na JSON." end
        local posted, id = pcall(ic.http.post, self.base.."/ask", encoded, "application/json", headers, 10)
        if not posted or id == nil then return nil, "HTTP není dostupné. Ověř AllowHttp a AllowHttpLocalhost." end
        self.request, self.kind, self.callback = id, "ask", callback
        self.elapsed, self.poll_elapsed = 0, 0
        return true
    end
    function self:reset(callback)
        if self:busy() then return nil, "Nejdřív počkej na dokončení dotazu." end
        if self.token == "PASTE_LOCAL_BRIDGE_TOKEN_HERE" or #self.token < 24 then return nil, "Doplň Bridge Token." end
        local payload = util.json.encode({source_ref_id=self.source_ref_id, conversation_id=self.conversation_id})
        local ok, id = pcall(ic.http.post, self.base.."/memory/reset", payload, "application/json", headers, 10)
        if not ok or id == nil then return nil, "Paměť se nepodařilo resetovat." end
        self.request, self.kind, self.callback = id, "reset", callback
        self.elapsed, self.poll_elapsed = 0, 0
        return true
    end
    function self:test_memory(callback)
        if self:busy() then return nil,"Dotaz už probíhá." end
        if self.token == "PASTE_LOCAL_BRIDGE_TOKEN_HERE" or #self.token < 24 then return nil,"Doplň Bridge Token." end
        local ok,id=pcall(ic.http.post,self.base.."/memory/test",util.json.encode({}),"application/json",headers,10)
        if not ok or id==nil then return nil,"Test ukládání se nepodařilo spustit." end
        self.request,self.kind,self.callback=id,"test_memory",callback
        self.elapsed,self.poll_elapsed=0,0
        return true
    end
    function self:test_audio(callback)
        if self:busy() then return nil, "Dotaz už probíhá." end
        if self.token == "PASTE_LOCAL_BRIDGE_TOKEN_HERE" or #self.token < 24 then return nil, "Doplň Bridge Token." end
        local payload=util.json.encode({source_ref_id=self.source_ref_id})
        local ok,id=pcall(ic.http.post,self.base.."/audio/test",payload,"application/json",headers,10)
        if not ok or id==nil then return nil,"Místní test zvuku se nepodařilo spustit." end
        self.request,self.kind,self.callback=id,"test_audio",callback
        self.elapsed,self.poll_elapsed=0,0
        return true
    end
    -- For chips using other HTTP APIs: call handle_completion from ONE central poll loop.
    function self:handle_completion(id, ok, code, body, err)
        if self.request == nil or id ~= self.request then return false end
        local kind = self.kind
        self.request, self.kind = nil, nil
        local decoded, data = pcall(util.json.decode, body or "")
        local status = tonumber(code) or 0
        if not ok or status < 200 or status >= 300 then
            local message = decoded and type(data)=="table" and type(data.error)=="string" and data.error
            local fallback = status == 409 and "Konverzace ještě zpracovává dotaz. Počkej a zkus to znovu." or
                status == 429 and "Limit požadavků nebo kvóta. Počkej a zkus to ručně znovu." or
                ("HTTP "..status..". Ověř mod a jeho konfiguraci.")
            complete(nil, message or fallback)
        elseif not decoded or type(data) ~= "table" then
            complete(nil, "Mod nevrátil platný JSON.")
        elseif kind == "test_audio" then
            if tostring(data.source_ref_id) ~= self.source_ref_id then complete(nil,"Test patří jinému zařízení.")
            else complete(data,nil) end
        elseif kind == "reset" or kind == "test_memory" then
            complete(data, nil)
        elseif kind == "ask" then
            if type(data.id) ~= "string" or not data.id:match("^[a-f0-9]+$") or #data.id ~= 32 then
                complete(nil, "Neplatné ID úlohy.")
            else self.job = data.id; self.poll_elapsed = 0 end
        elseif data.state == "done" then
            if tostring(data.source_ref_id) ~= self.source_ref_id then complete(nil, "Odpověď patří jinému zařízení.")
            elseif type(data.text) ~= "string" then complete(nil, "Odpověď neobsahuje text.")
            else complete(data, nil) end
        elseif data.state == "error" then
            complete(nil, type(data.error)=="string" and data.error or "Gemini neodpovědělo.")
        elseif data.state ~= "queued" and data.state ~= "running" then
            complete(nil, "Neznámý stav úlohy.")
        end
        return true
    end
    function self:play_audio(result, replay)
        if not result or tostring(result.source_ref_id) ~= self.source_ref_id then return nil, "Jiné zařízení." end
        if type(result.audio_url) ~= "string" or not result.audio_url:match("^https?://") then return nil, "Hlas není dostupný." end
        if not ss or not ss.play_sound then return nil, "ScriptedScreens není dostupný." end
        local audio_key = result.id or result.audio_url
        if not replay and audio_key == self.last_audio_key then return self.sound_id end
        local duration = tonumber(result.audio_duration_seconds)
        if not duration or duration ~= duration or duration <= 0 or duration > 360 then
            return nil, "Chybí platná délka hlasu. Aktualizuj DLL modu na 0.1.2."
        end
        local stop_after = tonumber(result.audio_stop_after_seconds) or duration
        if stop_after ~= stop_after or stop_after <= 0 or stop_after > duration then
            return nil, "Neplatné časování hlasu."
        end
        self:stop_audio()
        -- Explicit one-shot; the backend's silent tail absorbs coarse game-tick timing.
        local sound_id = "geminiai_"..tostring(result.id or "voice")
        local ok, sound = pcall(ss.play_sound, result.audio_url, {volume=0.8, loop=false, id=sound_id})
        if not ok then return nil, "Přehrávání hlasu selhalo. Ověř nastavení médií a dostupnost URL u hráčů." end
        self.sound_id = sound or sound_id
        self.last_audio_key = audio_key
        self.audio_elapsed, self.audio_deadline = 0, stop_after + self.audio_start_grace
        return self.sound_id
    end
    function self:stop_audio()
        self.audio_elapsed, self.audio_deadline = nil, nil
        if ss and ss.stop_sound then pcall(ss.stop_sound, self.sound_id) end
    end
    -- poll_http=false when your script drains HTTP itself through handle_completion.
    function self:tick(dt, poll_http)
        dt = math.max(0, tonumber(dt) or 0.5)
        -- Advance before completions: a clip started this tick must not lose one dt.
        if self.audio_elapsed then
            self.audio_elapsed = self.audio_elapsed + dt
            if self.audio_elapsed >= self.audio_deadline then self:stop_audio() end
        end
        if poll_http ~= false then
            for _ = 1, 8 do
                local polled, id, ok, code, body, err = pcall(ic.http.poll)
                if not polled then
                    if self:busy() then complete(nil, "HTTP polling není dostupný.") end
                    break
                end
                if id == nil then break end
                self:handle_completion(id, ok, code, body, err)
            end
        end
        if self:busy() then
            self.elapsed = self.elapsed + dt
            if self.elapsed > self.timeout then complete(nil, "Časový limit. Úloha na serveru ještě může doběhnout."); return end
        end
        self.poll_elapsed = self.poll_elapsed + dt
        if self.job and not self.request and self.poll_elapsed >= 1 then
            self.poll_elapsed = 0
            local ok, id = pcall(ic.http.get, self.base.."/jobs/"..self.job, headers, 10)
            if not ok or id == nil then complete(nil, "Výsledek se nepodařilo načíst.")
            else self.request, self.kind = id, "poll" end
        end
    end
    return self
end
return GeminiAI
