using System.Collections.Generic;
using Assets.Scripts.Objects;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class CabinetDoorHandles
    {
        internal static void Install(SwitchboardCabinet host,BoxCollider left,BoxCollider right)
        {
            // Replace the inherited locker interaction: both leaves use the same
            // explicit native Open action, each registered to its own handle collider.
            host.Interactables.RemoveAll(i=>i!=null&&i.Action==InteractableType.Open);
            foreach(var state in host.BuildStates)state.Interactables.RemoveAll(i=>i!=null&&i.Action==InteractableType.Open);
            foreach(var hit in new[]{left,right})
            {
                var action=new Interactable{Parent=host,Action=InteractableType.Open,Collider=hit,Animator=null,FakeCollider=null,
                    CanKeyInteract=true,JoinInProgressSync=true,KeyMap="PrimaryAction",Bounds=new Bounds(Vector3.zero,hit.size)};
                host.Interactables.Add(action);host.BuildStates[1].Interactables.Add(action);
                if(!host.BuildStates[1].Colliders.Contains(hit))host.BuildStates[1].Colliders.Add(hit);
            }
        }
    }
}
