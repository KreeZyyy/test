using System;
using System.Collections.Generic;
using System.Linq;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Objects;
using Assets.Scripts.Util;
using UnityEngine;

namespace ModularSwitchboards
{
    public sealed class CabinetOutputSocket : MonoBehaviour
    {
        public ConnectionRole Role;
        public Vector3 CableCell,BodyCell;
    }
    public sealed class CabinetOutputCasing : MonoBehaviour
    {
        [NonSerialized] public Mesh InstanceMesh;
        private void OnDestroy(){if(InstanceMesh!=null)UnityEngine.Object.Destroy(InstanceMesh);}
    }
    internal static class CabinetPowerOutputs
    {
        internal const string RootName="SwitchboardPowerOutputs",CasingName="OutputTCasing";
        internal static void Install(SwitchboardCabinet cabinet)
        {
            if(cabinet.InputConnection==null)throw new InvalidOperationException("Install Input before the outputs.");
            var shell=cabinet.transform.Find("SwitchboardModel/CompletedShell");
            var root=new GameObject(RootName){layer=cabinet.gameObject.layer};root.transform.SetParent(cabinet.transform,false);
            cabinet.BuildStates[1].LinkedGameObjects.Add(root);
            var cells=new HashSet<Grid3>{cabinet.transform.InverseTransformPoint(cabinet.InputConnection.Transform.position).ToGrid(SmallGrid.SmallGridSize,SmallGrid.SmallGridOffset)};
            // Positive canonical shell X is the viewer's left, as confirmed by the terminal labels.
            var left=cabinet.transform.InverseTransformDirection(shell.TransformDirection(Vector3.right)).normalized;
            var front=cabinet.transform.InverseTransformDirection(shell.TransformDirection(Vector3.forward)).normalized;
            for(int i=0;i<2;i++)
            {
                var outward=i==0?left:-left;
                var socket=NativeCableLayout.Read(outward*.5f+Vector3.down*.5f,outward);
                if(!cells.Add(socket.CableCell))throw new InvalidOperationException("Output cable cell overlaps another port.");
                var role=i==0?ConnectionRole.Output:ConnectionRole.Output2;
                var go=new GameObject(i==0?"Output1":"Output2"){layer=cabinet.gameObject.layer};go.transform.SetParent(root.transform,false);
                go.transform.localPosition=socket.Point;go.transform.localRotation=Quaternion.LookRotation(socket.Forward,front);
                var data=go.AddComponent<CabinetOutputSocket>();data.Role=role;data.CableCell=socket.CableCell.ToVector3();data.BodyCell=socket.BodyCell.ToVector3();
                var hit=ExternalCablePorts.AttachNativeOutput(cabinet,go.transform);
                // Geometry and future socket metadata only; no electrical Connection here.
                cabinet.BuildStates[1].Colliders.Add(hit);
                Debug.Log("[Modular Switchboards] "+go.name+" native grid: point="+socket.Point.ToString("F6")+
                    "; inward axis="+socket.Forward+"; cable cell="+socket.CableCell+"; body cell="+socket.BodyCell);
            }
            var casing=new GameObject(CasingName){layer=cabinet.gameObject.layer};casing.transform.SetParent(shell,false);
            casing.AddComponent<CabinetOutputCasing>();casing.AddComponent<MeshFilter>();
            casing.AddComponent<MeshRenderer>().sharedMaterials=CabinetGeometry.Materials;
            var collider=casing.AddComponent<MeshCollider>();cabinet.BuildStates[1].Colliders.Add(collider);
            Fit(cabinet);CabinetRearSurface.Restore(casing.GetComponent<MeshRenderer>());CabinetModel.SetBounds(cabinet);
            Debug.Log("[Modular Switchboards] T output housing installed; left Output 1 and right Output 2 are model-only lugs with planned grid anchors; no output Connection registered.");
        }
        internal static void Fit(Structure cabinet)
        {
            var shell=cabinet.transform.Find("SwitchboardModel/CompletedShell");
            var root=cabinet.transform.Find(RootName);var casing=shell==null?null:shell.Find(CasingName);
            if(root==null||casing==null)return;
            Bounds? total=null;
            float xmin=0,xmax=0;
            foreach(Transform port in root)
            {
                Bounds? lug=null;
                foreach(var filter in port.GetComponentsInChildren<MeshFilter>(true))
                {
                    if(filter.sharedMesh==null)continue;
                    var b=CabinetWallMount.TransformedBounds(filter.sharedMesh.bounds,shell.worldToLocalMatrix*filter.transform.localToWorldMatrix);
                    if(lug.HasValue){var v=lug.Value;v.Encapsulate(b);lug=v;}else lug=b;
                }
                if(!lug.HasValue)throw new InvalidOperationException("Output lug has no geometry.");
                var bounds=lug.Value;
                if(bounds.center.x>0)xmax=bounds.min.x+.004f;else xmin=bounds.max.x-.004f;
                if(total.HasValue){var b=total.Value;b.Encapsulate(bounds);total=b;}else total=bounds;
            }
            if(!total.HasValue)return;
            var body=NativeRearBox.BodyBounds(cabinet);var arms=total.Value;
            float low=arms.center.y-.016f,barTop=arms.center.y+.016f,stemTop=body.min.y+.004f;
            if(xmin>=-.016f||xmax<=.016f||barTop>=stemTop)throw new InvalidOperationException("Native output grid does not leave space for the T housing.");
            // A thin 28 mm cover, rather than the whole depth envelope between grid and body.
            float centerZ=Mathf.Clamp(arms.center.z,body.min.z+.014f,body.max.z-.014f);
            float zmin=centerZ-.014f,zmax=centerZ+.014f;
            var corners=new[]{new Vector2(xmin,low),new Vector2(xmax,low),new Vector2(xmax,barTop),
                new Vector2(.016f,barTop),new Vector2(.016f,stemTop),new Vector2(-.016f,stemTop),
                new Vector2(-.016f,barTop),new Vector2(xmin,barTop)};
            var outline=RoundOutline(corners,.003f);
            var vertices=new List<Vector3>();var normals=new List<Vector3>();var indices=new List<int>();
            int n=outline.Count;
            for(int i=0;i<n;i++)
            {
                var a=outline[i];var b=outline[(i+1)%n];int first=vertices.Count;
                vertices.AddRange(new[]{new Vector3(a.x,a.y,zmin),new Vector3(b.x,b.y,zmin),new Vector3(b.x,b.y,zmax),new Vector3(a.x,a.y,zmax)});
                var normal=new Vector3(b.y-a.y,a.x-b.x,0).normalized;normals.AddRange(new[]{normal,normal,normal,normal});
                indices.AddRange(new[]{first,first+1,first+2,first,first+2,first+3});
            }
            var triangles=Triangulate(outline);
            foreach(bool front in new[]{false,true})
            {
                int first=vertices.Count;foreach(var p in outline){vertices.Add(new Vector3(p.x,p.y,front?zmax:zmin));normals.Add(front?Vector3.forward:Vector3.back);}
                for(int i=0;i<triangles.Count;i+=3)
                    indices.AddRange(front?new[]{first+triangles[i],first+triangles[i+1],first+triangles[i+2]}:new[]{first+triangles[i],first+triangles[i+2],first+triangles[i+1]});
            }
            var state=casing.GetComponent<CabinetOutputCasing>();
            if(state.InstanceMesh==null)state.InstanceMesh=new Mesh{name="Switchboards.NativeGridTCasing"};
            var mesh=state.InstanceMesh;mesh.Clear();mesh.SetVertices(vertices);mesh.SetNormals(normals);mesh.subMeshCount=5;
            for(int i=0;i<5;i++)mesh.SetTriangles(i==CabinetRearSurface.Role?indices.ToArray():new int[0],i);
            CabinetGeometry.ApplyNativeUv(mesh);CabinetRearSurface.ApplyUv(mesh);mesh.RecalculateBounds();
            casing.GetComponent<MeshFilter>().sharedMesh=mesh;var hit=casing.GetComponent<MeshCollider>();hit.sharedMesh=null;hit.sharedMesh=mesh;
        }
        private static List<Vector2> RoundOutline(Vector2[] corners,float radius)
        {
            var result=new List<Vector2>();
            for(int i=0;i<corners.Length;i++)
            {
                var p=corners[i];var before=corners[(i+corners.Length-1)%corners.Length];var after=corners[(i+1)%corners.Length];
                float r=Mathf.Min(radius,Mathf.Min((before-p).magnitude,(after-p).magnitude)*.25f);
                var a=p+(before-p).normalized*r;var b=p+(after-p).normalized*r;
                for(int step=0;step<=4;step++){float t=step/4f;result.Add(a*(1-t)*(1-t)+p*(2*t*(1-t))+b*t*t);}
            }
            return result;
        }
        private static float Cross(Vector2 a,Vector2 b,Vector2 c)=>(b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x);
        private static List<int> Triangulate(List<Vector2> p)
        {
            var remaining=Enumerable.Range(0,p.Count).ToList();var result=new List<int>();int guard=p.Count*p.Count;
            while(remaining.Count>3 && guard-->0)
            {
                bool clipped=false;
                for(int i=0;i<remaining.Count;i++)
                {
                    int a=remaining[(i+remaining.Count-1)%remaining.Count],b=remaining[i],c=remaining[(i+1)%remaining.Count];
                    if(Cross(p[a],p[b],p[c])<=1e-10f)continue;
                    bool occupied=remaining.Any(v=>v!=a&&v!=b&&v!=c&&Cross(p[a],p[b],p[v])>=-1e-10f&&Cross(p[b],p[c],p[v])>=-1e-10f&&Cross(p[c],p[a],p[v])>=-1e-10f);
                    if(occupied)continue;
                    result.AddRange(new[]{a,b,c});remaining.RemoveAt(i);clipped=true;break;
                }
                if(!clipped)throw new InvalidOperationException("Cannot triangulate output housing.");
            }
            if(remaining.Count!=3)throw new InvalidOperationException("Incomplete output housing cap.");
            result.AddRange(remaining);return result;
        }
        internal static void IncludeBounds(Structure cabinet,ref Bounds bounds)
        {
            foreach(var path in new[]{RootName,"SwitchboardModel/CompletedShell/"+CasingName})
            {
                var root=cabinet.transform.Find(path);if(root==null)continue;
                foreach(var filter in root.GetComponentsInChildren<MeshFilter>(true))if(filter.sharedMesh!=null)
                    bounds.Encapsulate(CabinetWallMount.TransformedBounds(filter.sharedMesh.bounds,cabinet.transform.worldToLocalMatrix*filter.transform.localToWorldMatrix));
            }
        }
    }
}
