using System;using System.Collections.Generic;using System.Linq;using Assets.Scripts.Objects;using Assets.Scripts.GridSystem;using Assets.Scripts.Objects.Electrical;using Assets.Scripts.Objects.Pipes;using Assets.Scripts.Networks;using LibConstruct;using ModularSwitchboards;
namespace UnityEngine{public class Transform{public Vector3 position;}public struct Vector3{public float x;public Vector3(float x){this.x=x;}}}
namespace Assets.Scripts.GridSystem{public struct Grid3{public int x,y,z;public Grid3(int x,int y,int z){this.x=x;this.y=y;this.z=z;}}}
namespace Assets.Scripts.Objects{public class Thing{public string PrefabName;public long ReferenceId;public bool IsBeingDestroyed,IsCursor;public UnityEngine.Transform transform=new();public UnityEngine.Transform Transform=>transform;}public class Structure:Thing{}public class MultiConstructor:Thing{}}
namespace LibConstruct{public interface IPlacementBoardStructure{PlacementBoard Board{get;set;}}public class PlacementBoard{public List<Structure> Structures=new();public Grid3 WorldToGrid(UnityEngine.Vector3 p)=>new((int)p.x,0,0);}}
namespace Assets.Scripts.Objects.Electrical{public class Cable{public CableNetwork CableNetwork;}}
namespace Assets.Scripts.Objects.Pipes{
 public interface ILogicable{}
 public class Device:Structure,ILogicable{public bool Powered=true,OnOff=true;public int PowerClears;public void AssessPower(object source,bool powered){PowerClears++;}public Cable DataCable;public Cable PowerCable{get;private set;}public Cable[] DataCables{get;private set;}=Array.Empty<Cable>();public Cable[] PowerCables{get;private set;}=Array.Empty<Cable>();public CableNetwork InputNetwork1,OutputNetwork1;public ILogicable GetNetwork(int index)=>null;public void OnNetwork(Cable c){DataCable=c;DataCables=new[]{c};c.CableNetwork.AddDevice(c,this);}}
 public static class Referencable{public static Dictionary<int,Device> All=new();public static T Find<T>(int id)where T:class=>All.GetValueOrDefault(id) as T;}
}
namespace Assets.Scripts.Networks{
 public class CableNetwork:ILogicable{
 public List<Device> DeviceList=new();public Dictionary<Device,HashSet<Cable>> Reg=new();public int Refreshes;
 public List<Device> DataDeviceList=>DeviceList.Where(d=>d.DataCables.Any(c=>c.CableNetwork==this)).Distinct().ToList();
 public List<Device> PowerDeviceList=>DeviceList.Where(d=>d.PowerCables.Any(c=>c.CableNetwork==this)).Distinct().ToList();
 public HashSet<Cable> GetDeviceRegistration(Device d)=>Reg.GetValueOrDefault(d);
 public void AddDevice(Cable c,Device d){if(!Reg.TryGetValue(d,out var set)){Reg[d]=set=new();DeviceList.Add(d);}set.Add(c);}
 public void RemoveDevice(Cable c,Device d){if(Reg.TryGetValue(d,out var set)){set.Remove(c);if(set.Count==0)RemoveDevice(d);}}
 public void RemoveDevice(Device d){Reg.Remove(d);DeviceList.RemoveAll(x=>x==d);}
 public void DirtyPowerAndDataDeviceLists(){}public void RefreshNetworkDevice(Device d){Refreshes++;}
 }}
namespace HarmonyLib{static class AccessTools{public static System.Reflection.PropertyInfo Property(Type t,string n)=>t.GetProperty(n);}}
namespace ModularSwitchboards{
 public static class SwitchboardsMod{public const string SmartKitName="smart";}

 public class DinModuleBoard:PlacementBoard{public bool Blocked;public int Capacity=20;public bool CanPlace(Grid3 p,int r,int width)=>!Blocked&&p.x>=10&&p.x%10==0&&p.y==0&&p.z==0&&r==0&&p.x/10+width<=Capacity&&!DinParts.On(this).Any(o=>p.x/10<WorldToGrid(o.transform.position).x/10+DinParts.Width(o)&&WorldToGrid(o.transform.position).x/10<p.x/10+width);}
 public partial class SmartModule:Device,IPlacementBoardStructure{public PlacementBoard Board{get;set;}public Cabinet Cabinet;public int ModuleWidth=>4;public Grid3 GetLocalGrid()=>Board.WorldToGrid(transform.position);public Cable BoundCable,BoundPowerCable;public CableNetwork BoundNetwork,BoundPowerNetwork;public Cable[] BoundDataCables=Array.Empty<Cable>();public CableNetwork[] BoundDataNetworks=Array.Empty<CableNetwork>();}
 public class DinBreaker:Structure,IPlacementBoardStructure{public PlacementBoard Board{get;set;}public int ModuleWidth=1;public bool IsSmartOutputModule,IsFuseHolder,Conducting,IsAnalyserModule,IsBatteryModule,IsDoorPart;public Grid3 GetLocalGrid()=>Board.WorldToGrid(transform.position);}
 public class Port{public Cable cable=new(){CableNetwork=new()};public Cable GetCable()=>cable;}
 public class Cabinet{public bool IsCursor,IsStructureCompleted=true;public object GridController=new();public Port InputConnection=new(),Output1Connection=new(),Output2Connection=new(),Output3Connection=new();internal CabinetWiring Wiring;}
 partial class CabinetWiring{public Cabinet Owner;public IEnumerable<DinBreaker> Breakers=Array.Empty<DinBreaker>();public IEnumerable<CabinetWireSaveData> CircuitWires=Array.Empty<CabinetWireSaveData>();}
}

public class Request{public Structure StructurePrefab;public Thing Constructor;public PlacementBoard Board;public Grid3 Position;public int Rotation;}

namespace ModularSwitchboards { internal static class DinSmartLayout { internal const int Slots=4; } }
