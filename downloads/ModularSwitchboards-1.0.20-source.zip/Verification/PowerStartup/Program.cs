using System;using System.Linq;using System.Collections.Generic;using ModularSwitchboards;using Assets.Scripts.Networks;
class Program
{
 static int checks;static void Check(bool b,string message){checks++;if(!b)throw new Exception(message);}
 static CabinetWireSaveData W(long a,int p,long b,int q)=>new(){From=new(a,p),To=new(b,q)};
 static void Cold(bool medium)
 {
  var host=new SwitchboardCabinet{Output3Connection=medium?new():null};var input=new CableNetwork{PotentialLoad=10000};var first=new CableNetwork{RequiredLoad=50};var second=new CableNetwork{RequiredLoad=0};
  host.InputConnection.cable.CableNetwork=input;host.Output1Connection.cable.CableNetwork=first;host.Output2Connection.cable.CableNetwork=second;
  var modules=new[]{new DinBreaker{ReferenceId=10,OnOff=true,RatedWatts=4000},new DinBreaker{ReferenceId=20,OnOff=true,RatedWatts=4000}};
  var wires=new[]{W(0,0,10,0),W(10,1,0,1),W(0,0,20,0),W(20,1,0,2)};var power=new CabinetWiringPower();power.Refresh(host,wires,modules);
  float one=power.Generated(first),two=power.Generated(second);
  Check(one>=50&&two>=50,(medium?"Medium":"Small")+": second Output has no startup supply while the first branch is active");
  Check(Math.Abs(one+two-10000)<.01f,"Startup headroom duplicates native supply");
  power.Use(first,50);power.Use(second,50);Check(power.Used(input)==100,"Actual lamp consumption not charged once");power.Receive(input,100);Check(power.Used(input)==0,"Repayment changed");
  modules[0].OnOff=false;power.Refresh(host,wires,modules);Check(power.Generated(first)==0&&power.Generated(second)==10000,"Opening first breaker changes available second branch incorrectly");power.ObserveIdle(second);
 }
 static void ReservedSupply()
 {
  var host=new SwitchboardCabinet{Output3Connection=new()};var input=new CableNetwork{PotentialLoad=1000};var first=new CableNetwork{RequiredLoad=600};var second=new CableNetwork();host.InputConnection.cable.CableNetwork=input;host.Output1Connection.cable.CableNetwork=first;host.Output2Connection.cable.CableNetwork=second;
  var modules=new[]{new DinBreaker{ReferenceId=10,OnOff=true},new DinBreaker{ReferenceId=20,OnOff=true}};var wires=new[]{W(0,0,10,0),W(10,1,0,1),W(0,0,20,0),W(20,1,0,2)};var power=new CabinetWiringPower();power.Refresh(host,wires,modules);var offeredFirst=power.Generated(first);second.RequiredLoad=900;power.Refresh(host,wires,modules);var offeredSecond=power.Generated(second);
  Check(offeredFirst+offeredSecond<=1000.01f,"pending external offer duplicates input supply after demand changes");
  Check(power.Generated(first)==offeredFirst,"native two-query offer must stay stable");power.Use(first,300);power.Use(second,100);Check(power.Used(input)==400,"reserved external offers altered actual energy accounting");
 }
 static void Main(){Cold(false);Cold(true);ReservedSupply();
  var reserve=WireCircuit.AllocateSupply(1000,new[]{100f,0f,50f},new[]{true,true,true});Check(reserve.All(v=>v>0)&&Math.Abs(reserve.Sum()-1000)<.01f,"three live branches must share spare supply");
  var limited=WireCircuit.AllocateSupply(100,new[]{100f,300f},new[]{true,true});Check(limited.SequenceEqual(new[]{25f,75f}),"insufficient supply must retain demand-proportional allocation");
  var inactive=WireCircuit.AllocateSupply(100,new[]{20f,0f},new[]{true,false});Check(inactive.SequenceEqual(new[]{100f,0f}),"inactive output must not receive startup headroom");
  var empty=WireCircuit.AllocateSupply(0,new[]{20f,0f},new[]{true,true});Check(empty.All(v=>v==0),"empty input manufactured startup energy");
  var random=new Random(111);for(int i=0;i<1000;i++){float available=(float)random.NextDouble()*100000;var demand=new[]{(float)random.NextDouble()*10000,(float)random.NextDouble()*10000,0f};var result=WireCircuit.AllocateSupply(available,demand,new[]{true,true,true});Check(result.All(v=>!float.IsNaN(v)&&v>=0)&&Math.Abs(result.Sum()-available)<.03f,"random startup allocation duplicated/lost supply");}
ProtectionHarness.Run();MediumPowerHarness.Run();BatteryHarness.Run();Console.WriteLine(checks+" power startup checks passed; protection, three-output and battery regressions passed.");}
}
namespace ModularSwitchboards{internal static class DoorModuleLayout{internal static IEnumerable<CabinetWireSaveData> Through(IEnumerable<CabinetWireSaveData> w,IEnumerable<long> ids)=>WireCircuit.Through(w,ids);}}
