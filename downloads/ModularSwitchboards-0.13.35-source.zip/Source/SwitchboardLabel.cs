using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Serialization;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Objects;
using Assets.Scripts.Networking;
using Assets.Scripts.Localization2;
using LibConstruct;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class LabelLayout
    {
        internal static bool Fits(int x,int y,int z,int rotation,int width)
            =>x%90==0&&x>=0&&x/90+width<=8&&(y==240||y==-240)&&z==0&&rotation==0&&width>=1&&width<=3;
        internal static bool Overlaps(int x,int width,int other,int otherWidth)=>x<other+otherWidth&&other<x+width;
    }
    public sealed class SwitchboardLabelSaveData:StructureSaveData
    {
        [XmlElement] public PlacementBoardStructureSaveData Mount;
    }
    public sealed class SwitchboardLabelBoard:PlacementBoard
    {
        public override float GridSize=>.0045f;
        public override IPlacementBoardStructure EquivalentStructure(Structure structure)
            =>structure is SwitchboardLabel&&PrimaryHost is InnerCoverModule cover&&cover.Host!=null&&cover.Host.IsOpen?structure as IPlacementBoardStructure:null;
    }
    public sealed class SwitchboardLabel:Structure,IPlacementBoardStructure
    {
        public int Width=1;
        public PlacementBoard Board{get;set;}
        public PlacementBoard.BoardCell[] BoardCells{get;set;}
        internal InnerCoverModule Cover=>Board?.PrimaryHost as InnerCoverModule;
        internal static bool CanPlace(PlacementBoard board,Grid3 position,int rotation,int width)
        {
            if(!(board is SwitchboardLabelBoard)||!(board.PrimaryHost is InnerCoverModule cover)||cover.Host==null||!cover.Host.IsOpen||!LabelLayout.Fits(position.x,position.y,position.z,rotation,width))return false;
            if(board.Structures.OfType<SwitchboardLabel>().Any(l=>{var p=board.WorldToGrid(l.transform.position);return p.y==position.y&&LabelLayout.Overlaps(position.x/90,width,p.x/90,l.Width);}))return false;
            // Every covered position must actually contain a module in the row below.
            for(int slot=position.x/90;slot<position.x/90+width;slot++)
            {
                float x=-3.5f*DinLayout.SlotPitch+slot*DinLayout.SlotPitch;
                float y=position.y>0?.108f:-.108f;
                if(!cover.Host.Wiring.Breakers.Any(b=>{var p=cover.transform.InverseTransformPoint(b.transform.position);return Mathf.Abs(p.y-y)<.01f&&x>=p.x-.01f&&x<p.x+(b.ModuleWidth-1)*DinLayout.SlotPitch+.01f;}))return false;
            }
            return true;
        }
        public override void Awake(){base.Awake();BoardStructureHooks.Awake(this);}
        public override Grid3 GetLocalGrid()=>Board==null?default(Grid3):Board.WorldToGrid(Transform.position);
        public override CanConstructInfo CanConstruct()
        {
            if(!(Board is SwitchboardLabelBoard))return CanConstructInfo.InvalidPlacement("Aim above modules on an installed inner cover.");
            var p=Board.WorldToGrid(Transform.position);
            if(IsCursor){p=new Grid3(Mathf.RoundToInt(p.x/90f)*90,p.y>=0?240:-240,0);Transform.SetPositionAndRotation(Board.GridToWorld(p),Board.IndexToRotation(0));}
            return CanPlace(Board,p,Board.RotationToIndex(Transform.rotation),Width)?CanConstructInfo.ValidPlacement:CanConstructInfo.InvalidPlacement("Choose free space directly above installed modules.");
        }
        protected override CanConstructInfo CanDeconstruct()=>Cover?.Host!=null&&Cover.Host.IsOpen?CanConstructInfo.ValidPlacement:CanConstructInfo.InvalidPlacement("Open the cabinet first.");
        public override DelayedActionInstance AttackWith(Attack attack,bool doAction=true)=>Cover?.Host!=null&&Cover.Host.IsOpen?base.AttackWith(attack,doAction):new DelayedActionInstance{Duration=0}.Fail("Open the cabinet first.");
        public override void OnDeregistered(){base.OnDeregistered();if(Board!=null)BoardStructureHooks.OnDeregistered(this);}
        public override ThingSaveData SerializeSave(){ThingSaveData data=new SwitchboardLabelSaveData();InitialiseSaveData(ref data);return data;}
        protected override void InitialiseSaveData(ref ThingSaveData data){base.InitialiseSaveData(ref data);if(data is SwitchboardLabelSaveData save&&Board!=null)save.Mount=BoardStructureHooks.SerializeSave(this);}
        public override void DeserializeSave(ThingSaveData data){base.DeserializeSave(data);if(data is SwitchboardLabelSaveData save&&save.Mount!=null)BoardStructureHooks.DeserializeSave(this,save.Mount);}
        public override void SerializeOnJoin(RocketBinaryWriter writer){base.SerializeOnJoin(writer);BoardStructureHooks.SerializeOnJoin(writer,this);}
        public override void DeserializeOnJoin(RocketBinaryReader reader){base.DeserializeOnJoin(reader);BoardStructureHooks.DeserializeOnJoin(reader,this);}
        internal static Mesh Mesh(int width)
        {
            var mesh=DinBreakerModel.ControlMesh("Switchboard label",new Vector3((width-1)*DinLayout.SlotPitch*.5f,0,0),new Vector3(width*DinLayout.SlotPitch-.004f,.018f,.002f));
            var triangles=mesh.GetTriangles(0);mesh.SetTriangles(new int[0],0);mesh.SetTriangles(triangles,1);return mesh;
        }
    }
    public sealed class SwitchboardLabelView:MonoBehaviour
    {
        public SwitchboardLabel Owner;
        public TextMesh Text;
        private void LateUpdate()
        {
            if(Owner==null||Text==null)return;
            var renderer=Text.GetComponent<MeshRenderer>();
            var cabinet=Owner.Cover?.Host;
            bool visible=!Owner.IsCursor&&cabinet!=null&&cabinet.IsOpen;
            var camera=Camera.main;
            renderer.enabled=visible&&(camera==null||Vector3.Dot(Owner.transform.forward,camera.transform.position-Owner.transform.position)>0);
            var body=Owner.transform.Find("InnerCoverModel");if(body!=null){body.GetComponent<MeshCollider>().enabled=visible;}
            string value=Owner.CustomName;
            if(string.IsNullOrWhiteSpace(value)||value=="Switchboard Label ("+Owner.Width+" module"+(Owner.Width==1?"":"s")+")")value="LABEL";
            value=value.Replace('\r',' ').Replace('\n',' ');var info=new System.Globalization.StringInfo(value);if(info.LengthInTextElements>48)value=info.SubstringByTextElements(0,47)+"…";
            Text.text=value;
            var bounds=renderer.localBounds.size;
            Text.transform.localScale=Vector3.one*Mathf.Min(1f,Mathf.Min((Owner.Width*DinLayout.SlotPitch-.009f)/Mathf.Max(.0001f,bounds.x),.012f/Mathf.Max(.0001f,bounds.y)));
        }
        internal static void Install(SwitchboardLabel owner)
        {
            Font font=null;
            foreach(var name in new[]{"LegacyRuntime.ttf","Arial.ttf"}){try{font=Resources.GetBuiltinResource<Font>(name);}catch(Exception){}if(font!=null)break;}
            if(font==null)font=Resources.FindObjectsOfTypeAll<Font>().FirstOrDefault();if(font==null)return;
            var go=new GameObject("LabelText"){layer=owner.gameObject.layer};go.transform.SetParent(owner.transform,false);go.transform.localPosition=new Vector3((owner.Width-1)*DinLayout.SlotPitch*.5f,0,.0015f);go.transform.localRotation=Quaternion.Euler(0,180,0);
            var text=go.AddComponent<TextMesh>();text.font=font;text.fontSize=64;text.characterSize=.01f;text.anchor=TextAnchor.MiddleCenter;text.alignment=TextAlignment.Center;text.richText=false;text.color=Color.black;text.text="LABEL";go.GetComponent<MeshRenderer>().sharedMaterial=font.material;
            var view=owner.gameObject.AddComponent<SwitchboardLabelView>();view.Owner=owner;view.Text=text;
        }
    }
}
