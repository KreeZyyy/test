using System.Linq;using UnityEngine;using Assets.Scripts.GridSystem;using LibConstruct;namespace ModularSwitchboards{internal static class LabelLayout
    {
        internal static bool Fits(int x,int y,int z,int rotation,int width)
            =>x%90==0&&x>=0&&x/90+width<=8&&(y==240||y==-240)&&z==0&&rotation==0&&width>=1&&width<=3;
        internal static bool Overlaps(int x,int width,int other,int otherWidth)=>x<other+otherWidth&&other<x+width;
    }public partial class SwitchboardLabel{internal static bool CanPlace(PlacementBoard board,Grid3 position,int rotation,int width)
        {
            if(!(board is SwitchboardLabelBoard)||!(board.PrimaryHost is InnerCoverModule cover)||cover.Host==null||!cover.Host.IsOpen||!LabelLayout.Fits(position.x,position.y,position.z,rotation,width))return false;
            if(board.Structures.OfType<SwitchboardLabel>().Any(l=>{var p=board.WorldToGrid(l.transform.position);return p.y==position.y&&LabelLayout.Overlaps(position.x/90,width,p.x/90,l.Width);}))return false;
            // Every covered position must actually contain a module in the row below.
            for(int slot=position.x/90;slot<position.x/90+width;slot++)
            {
                float x=-3.5f*DinLayout.SlotPitch+slot*DinLayout.SlotPitch;
                float y=position.y>0?.108f:-.108f;
                if(!cover.Host.Wiring.Breakers.Any(b=>{var p=cover.transform.InverseTransformPoint(b.transform.position);return Mathf.Abs(p.y-y)<.01f&&x>=p.x-.01f&&x<p.x+(b.ModuleWidth-1)*DinLayout.SlotPitch+.01f;}))return false;
            }
            return true;
        }}}