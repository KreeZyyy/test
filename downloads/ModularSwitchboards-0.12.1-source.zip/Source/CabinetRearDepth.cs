using System;
using System.Linq;
using Assets.Scripts;
using Assets.Scripts.Objects.Electrical;
using UnityEngine;

namespace ModularSwitchboards
{
    // Geometry lives in the Housing mesh, rather than a separate rear GameObject.
    internal static class CabinetRearDepth
    {
        internal const float NominalDepth = .05f;

        internal static float Measure()
        {
            ApcRearDiagnostics.Capture();
            try
            {
                var apc = WorldManager.Instance.SourcePrefabs.OfType<AreaPowerControl>()
                    .First(p => p.PrefabName == "StructureAreaPowerControl");
                var renderer = apc.GetComponentsInChildren<MeshRenderer>(true)
                    .First(r => r.name == apc.PrefabName && r.GetComponent<MeshFilter>() != null);
                CabinetGeometry.ReadNativeMesh(renderer.GetComponent<MeshFilter>().sharedMesh,
                    out var points, out var uv, out var groups);
                var matrix = Matrix4x4.Rotate(CabinetModel.FrontSign < 0f
                    ? Quaternion.Euler(0f, 180f, 0f) : Quaternion.identity)
                    * apc.transform.worldToLocalMatrix * renderer.transform.localToWorldMatrix;
                for (int i = 0; i < points.Length; i++) points[i] = matrix.MultiplyPoint3x4(points[i]);
                // Broad shell faces distinguish the main casing from small lugs and
                // the raised lightning cover. Do not use the whole renderer's bounds.
                float largestSpan = 0f;
                foreach (var indices in groups)
                    for (int i = 0; i < indices.Length; i += 3)
                        largestSpan = Mathf.Max(largestSpan, Span(points[indices[i]], points[indices[i+1]], points[indices[i+2]]));
                if (largestSpan < .08f) throw new InvalidOperationException("No broad APC shell faces");
                float back = 0f;
                foreach (var indices in groups)
                    for (int i = 0; i < indices.Length; i += 3)
                    {
                        var a = points[indices[i]]; var b = points[indices[i+1]]; var c = points[indices[i+2]];
                        if (Span(a,b,c) < largestSpan * .85f) continue;
                        back = Mathf.Min(back, Mathf.Min(a.z, Mathf.Min(b.z,c.z)));
                    }
                float depth = -back;
                if (depth < .005f || depth > .25f) throw new InvalidOperationException("APC rear depth outside expected range: " + depth);
                Debug.Log("[Modular Switchboards] Integrated rear shell: APC broad-face depth=" + depth.ToString("F6") + " m; no external ports.");
                return depth;
            }
            catch (Exception ex)
            {
                Debug.LogWarning("[Modular Switchboards] APC rear depth measurement unavailable; using nominal 0.050 m: " + ex.Message);
                return NominalDepth;
            }
        }

        private static float Span(Vector3 a, Vector3 b, Vector3 c)
        {
            return Mathf.Max(Mathf.Max(a.x,Mathf.Max(b.x,c.x))-Mathf.Min(a.x,Mathf.Min(b.x,c.x)),
                Mathf.Max(a.y,Mathf.Max(b.y,c.y))-Mathf.Min(a.y,Mathf.Min(b.y,c.y)));
        }

        internal static void Fit(Vector3[] vertices, Vector3[] normals, float depth)
        {
            float scale = depth / NominalDepth;
            for (int i = 0; i < vertices.Length; i++)
            {
                // Existing housing geometry starts at z=0. Only the integrated rear
                // extrusion occupies negative z; its joint remains exactly at zero.
                if (vertices[i].z >= 0f) continue;
                vertices[i].z *= scale;
                var n = normals[i]; n.z /= scale; normals[i] = n.normalized;
            }
        }
    }
}
