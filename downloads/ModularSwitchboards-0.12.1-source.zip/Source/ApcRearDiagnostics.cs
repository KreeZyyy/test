using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Assets.Scripts;
using Assets.Scripts.Objects.Electrical;
using UnityEngine;
using UnityEngine.Rendering;

namespace ModularSwitchboards
{
    // Capture original data rather than calling the current depth heuristic exact.
    internal static class ApcRearDiagnostics
    {
        [Serializable] public sealed class Report
        {
            public string version = SwitchboardsMod.Version;
            public string prefab;
            public string coordinates = "APC local, rotated so positive Z faces out from wall; metres";
            public float frontSign;
            public string paintMaterial;
            public float diffuseIndex, smoothnessIndex;
            public List<Part> parts = new List<Part>();
            public List<Port> ports = new List<Port>();
        }
        [Serializable] public sealed class Part
        {
            public string path, mesh;
            public Vector3[] vertices;
            public Vector2[] uv;
            public List<Surface> surfaces = new List<Surface>();
            public List<Property> globalBlock = new List<Property>();
            public bool globalBlockEmpty;
        }
        [Serializable] public sealed class Surface
        {
            public int submesh;
            public int[] triangles;
            public Vector3 min, max;
            public string material, shader;
            public bool paintable, blockEmpty;
            public List<Property> properties = new List<Property>();
        }
        [Serializable] public sealed class Property
        {
            public string name, type, texture, blockTexture;
            public bool blockHasProperty;
            public float value, blockFloat;
            public Color color, blockColor;
            public Vector4 vector, blockVector;
        }
        [Serializable] public sealed class Port
        {
            public string role;
            public Vector3 position;
            public Vector3 colliderMin, colliderMax;
        }
        private static bool captured;

        internal static void Capture()
        {
            if (captured) return;
            captured = true;
            try
            {
                var apc = WorldManager.Instance.SourcePrefabs.OfType<AreaPowerControl>()
                    .First(p => p.PrefabName == "StructureAreaPowerControl");
                var frame = Matrix4x4.Rotate(CabinetModel.FrontSign < 0f
                    ? Quaternion.Euler(0f,180f,0f) : Quaternion.identity) * apc.transform.worldToLocalMatrix;
                var report = new Report { prefab=apc.PrefabName, frontSign=CabinetModel.FrontSign,
                    paintMaterial=apc.PaintableMaterial == null ? "" : apc.PaintableMaterial.name };
                report.smoothnessIndex = apc.SmoothnessIndex;
                report.diffuseIndex = apc.CustomColor == null ? -1 : apc.CustomColor.Index;
                foreach (var renderer in apc.GetComponentsInChildren<MeshRenderer>(true))
                {
                    var mesh = renderer.GetComponent<MeshFilter>()?.sharedMesh;
                    if (mesh == null) continue;
                    try
                    {
                        CabinetGeometry.ReadNativeMesh(mesh,out var vertices,out var uv,out var groups);
                        var matrix = frame * renderer.transform.localToWorldMatrix;
                        for(int i=0;i<vertices.Length;i++) vertices[i]=matrix.MultiplyPoint3x4(vertices[i]);
                        var part = new Part {path=PathOf(renderer.transform,apc.transform),mesh=mesh.name,vertices=vertices,uv=uv};
                        var global = new MaterialPropertyBlock(); renderer.GetPropertyBlock(global);
                        part.globalBlockEmpty=global.isEmpty;
                        var mats=renderer.sharedMaterials;
                        for(int i=0;i<groups.Length;i++)
                        {
                            var mat=i<mats.Length?mats[i]:null;
                            var block=new MaterialPropertyBlock();renderer.GetPropertyBlock(block,i);
                            var surface=new Surface {submesh=i,triangles=groups[i],material=mat==null?"":mat.name,
                                shader=mat==null||mat.shader==null?"":mat.shader.name,paintable=mat==apc.PaintableMaterial,blockEmpty=block.isEmpty};
                            if(groups[i].Length>0)
                            {
                                var bounds=new Bounds(vertices[groups[i][0]],Vector3.zero);
                                foreach(int index in groups[i]) bounds.Encapsulate(vertices[index]);
                                surface.min=bounds.min;surface.max=bounds.max;
                            }
                            if(mat!=null && mat.shader!=null)
                            {
                                surface.properties=Properties(mat,block);
                                if(i==0) part.globalBlock=Properties(mat,global);
                            }
                            part.surfaces.Add(surface);
                            Debug.Log("[Modular Switchboards] APC REAR DIAG: "+part.path+" sub="+i+" material="+surface.material+
                                " paintable="+surface.paintable+" min="+surface.min.ToString("F6")+" max="+surface.max.ToString("F6"));
                        }
                        report.parts.Add(part);
                    }
                    catch(Exception ex) { Debug.LogWarning("[Modular Switchboards] APC REAR DIAG mesh unavailable: "+renderer.name+": "+ex.Message); }
                }
                if(apc.OpenEnds!=null) foreach(var port in apc.OpenEnds)
                {
                    if(port?.Transform==null)continue;
                    var entry=new Port {role=port.ConnectionRole.ToString(),position=frame.MultiplyPoint3x4(port.Transform.position)};
                    if(port.Collider is BoxCollider box)
                    {
                        var bounds=CabinetWallMount.TransformedBounds(new Bounds(box.center,box.size),frame*box.transform.localToWorldMatrix);
                        entry.colliderMin=bounds.min;entry.colliderMax=bounds.max;
                    }
                    report.ports.Add(entry);
                }
                if(report.parts.Count==0)throw new InvalidOperationException("No APC meshes captured");
                string path=System.IO.Path.Combine(Application.persistentDataPath,"ModularSwitchboards-APC-reference.json");
                File.WriteAllText(path,JsonUtility.ToJson(report,true));
                Debug.Log("[Modular Switchboards] APC REAR DIAG saved: "+path+"; parts="+report.parts.Count+
                    ". Geometry includes all parts for identification; no claim that a rear surface has already been selected.");
            }
            catch(Exception ex) { Debug.LogError("[Modular Switchboards] APC REAR DIAG failed: "+ex); }
        }

        private static string PathOf(Transform current,Transform root)
        {
            var names=new List<string>();
            while(current!=null){names.Add(current.name);if(current==root)break;current=current.parent;}
            names.Reverse();return string.Join("/",names.ToArray());
        }

        private static List<Property> Properties(Material mat,MaterialPropertyBlock block)
        {
            var result=new List<Property>();
            for(int i=0;i<mat.shader.GetPropertyCount();i++)
            {
                string name=mat.shader.GetPropertyName(i);int id=Shader.PropertyToID(name);
                var type=mat.shader.GetPropertyType(i);var prop=new Property{name=name,type=type.ToString(),blockHasProperty=block.HasProperty(id)};
                if(type==ShaderPropertyType.Color){prop.color=mat.GetColor(id);prop.blockColor=block.GetColor(id);}
                else if(type==ShaderPropertyType.Vector){prop.vector=mat.GetVector(id);prop.blockVector=block.GetVector(id);}
                else if(type==ShaderPropertyType.Texture){var texture=mat.GetTexture(id);prop.texture=texture==null?"":texture.name;var overrideTexture=block.GetTexture(id);prop.blockTexture=overrideTexture==null?"":overrideTexture.name;}
                else if(type==ShaderPropertyType.Float || type==ShaderPropertyType.Range){prop.value=mat.GetFloat(id);prop.blockFloat=block.GetFloat(id);}
                result.Add(prop);
            }
            // Block values of zero alone do not establish that a property is overridden.
            // Preserve block emptiness and both scopes so analysis can distinguish them.
            return result;
        }
    }
}
