using Assets.Scripts.Objects;
using UnityEngine;

namespace ModularSwitchboards
{
    // The game's existing Open interaction is saved and synchronized by Thing.
    // This component only presents that state using the new door geometry.
    public sealed class CabinetDoor : MonoBehaviour
    {
        public Structure Owner;
        public Transform Hinge;
        private bool initialized;
        private float angle;

        private void LateUpdate()
        {
            if (Owner == null || Hinge == null) return;
            float target = Owner.IsOpen ? -110f : 0f;
            angle = initialized ? Mathf.MoveTowards(angle, target, Time.deltaTime * 220f) : target;
            initialized = true;
            Hinge.localRotation = Quaternion.Euler(0f, angle, 0f);
        }
    }
}
