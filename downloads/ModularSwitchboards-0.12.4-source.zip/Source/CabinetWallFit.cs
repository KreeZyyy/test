using Assets.Scripts.Objects;
using UnityEngine;

namespace ModularSwitchboards
{
    // Root positions stay on the native grid. Only the model and its child colliders fit the wall skin.
    public sealed class CabinetWallFit : MonoBehaviour
    {
        private Structure owner;
        private Transform model;
        private Wall lastWall;
        private int lastState=int.MinValue;
        private Vector3 lastLocalPosition,lastLocalNormal;
        private float nextCheck;
        private bool fitted;

        private void LateUpdate()
        {
            if(owner==null) owner=GetComponent<Structure>();
            if(owner==null || owner.GridController==null) return;
            if(!owner.IsCursor && Time.unscaledTime<nextCheck) return;
            nextCheck=Time.unscaledTime+.25f;
            if(model==null) model=transform.Find("SwitchboardModel");
            if(model==null) return;
            float sign=CabinetModel.FrontSign;
            var normal=transform.forward*sign;
            var position=transform.position;
            var wall=owner.GridController.GetFaceStructure(position+normal*.25f,-normal) as Wall;
            if(wall==null) wall=owner.GridController.GetFaceStructure(position-normal*.25f,normal) as Wall;
            if(wall==null) return;
            var localPosition=wall.transform.InverseTransformPoint(position);
            var localNormal=wall.transform.InverseTransformDirection(normal);
            if(Mathf.Abs(localNormal.z)<.99f) return;
            if(fitted && wall==lastWall && wall.CurrentBuildStateIndex==lastState &&
                (localPosition-lastLocalPosition).sqrMagnitude<.000001f && (localNormal-lastLocalNormal).sqrMagnitude<.000001f) return;
            if(!CabinetWallMount.TryMeasure(wall,wall.BuildStates.Count-1,out var rear,out var front)) return;
            float surface=localNormal.z>0f?front:rear;
            var point=wall.transform.TransformPoint(new Vector3(localPosition.x,localPosition.y,surface));
            float offset=Vector3.Dot(point-position,normal)+CabinetWallMount.Clearance;
            if(offset<-.25f || offset>.5f) return;
            model.localPosition=new Vector3(0f,0f,sign*offset);
            if(owner.IsCursor && owner.Wireframe!=null)
                owner.Wireframe.transform.localPosition=new Vector3(0f,0f,sign*(offset-CabinetWallMount.BackOffset));
            ExternalCablePorts.AlignToGrid(owner);
            CabinetModel.SetBounds(owner);
            lastWall=wall;lastState=wall.CurrentBuildStateIndex;lastLocalPosition=localPosition;lastLocalNormal=localNormal;fitted=true;
            if(!owner.IsCursor)
                Debug.Log("[Modular Switchboards] Cabinet fitted to "+wall.PrefabName+"; wall thickness="+(front-rear).ToString("F6")+
                    " m; actual face offset="+(offset-CabinetWallMount.Clearance).ToString("F6")+" m; clearance=0.000500 m.");
        }
    }
}
