# Modular Switchboards 1.0.125 — integral lower cabinet body, no outlets

User-confirmed shape direction: like Medium, standing by a wall like Locker. The lower body acts as its own base; no separate slab underneath.

Removed the separate 1.0.124 grey platform. A 100 mm lower front band now lives inside the existing housing envelope and is merged into the paintable Housing mesh. Doors end above the band. It is also part of the frame preview and collision mesh; no FloorPlinth GameObject or extra base collider/height extension is created. The rear keeps its native-grey surface. Native Locker dimensions and standing placement are preserved.

Large remains a model/layout prototype without roof outlets or external electrical endpoints/fixed terminal blocks. Four DIN rows, our twin doors, covers and board mounting remain available. Existing Small/Medium variants are unchanged. Current Large cost: 6 cabinet kits + 10 Plastic Sheets; optional Large cover4kits. Medium thumbnail still used.

Validation: native-reference build without warnings/errors and 204 Large layout/base-envelope/cover-save checks. Game appearance, floor alignment and door clearance remain to be checked. No Steam Workshop update.

