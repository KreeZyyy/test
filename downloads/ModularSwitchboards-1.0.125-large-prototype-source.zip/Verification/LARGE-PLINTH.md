# Modular Switchboards 1.0.124 — Large plinth shape test

Large only: remove the roof sockets, raised socket supports and external electrical endpoints for now; omit the internal fixed terminal blocks as well. Add a low native-grey floor plinth, 100 mm below the housing with 5 mm overlap and 9 mm inset on each side. The base is included in frame/finished visual stages, frame construction blueprint, physical hitboxes and the overall grid/selection bounds. Standard Small/Medium ports are unchanged.

Large currently cannot connect to external power. Four DIN rows, double doors, covers and module/door mounting remain available for shape/layout testing. Prototype cost remains 6 cabinet kits + 10 Plastic Sheets, optional Large cover 4 cover kits. Large still uses the Medium thumbnail.

Validation: native-reference build 0 warnings/errors; 204 Large layout/plinth/cover-save checks passed. Actual floor alignment and appearance need in-game verification. Workshop not updated.

