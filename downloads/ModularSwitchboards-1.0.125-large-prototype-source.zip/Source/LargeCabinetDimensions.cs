using System;
using Assets.Scripts.Objects;
using UnityEngine;
namespace ModularSwitchboards
{
    // Read dimensions from the vanilla prefab, but never reuse its storage model.
    internal static class LargeCabinetDimensions
    {
        internal static Bounds NativeBounds {get;private set;}
        internal static bool Ready {get;private set;}
        internal static float Width=>NativeBounds.size.x;
        internal static float Height=>NativeBounds.size.y;
        internal static float Depth=>NativeBounds.size.z;
        internal static int[] Rows
        {
            get {int outer=(int)Math.Floor((Height*.5f-.27f)/.018f)*10;int inner=(outer/30)*10;return new[]{-outer,-inner,inner,outer};}
        }
        internal static Vector3[] TopBodyCells()
        {
            float y=(float)Math.Ceiling((NativeBounds.center.y+Height*.5f-.25f)/.5f)*.5f;
            float x=(float)Math.Round(NativeBounds.center.x/.5f)*.5f,z=(float)Math.Round(NativeBounds.center.z/.5f)*.5f;
            return new[]{new Vector3(x-.5f,y,z),new Vector3(x,y,z),new Vector3(x-.5f,y,z+.5f),new Vector3(x,y,z+.5f)};
        }
        internal const float BaseHeight=.10f;
        internal static Bounds LowerBodyBand(Bounds housing)
            =>new Bounds(new Vector3(housing.center.x,housing.center.y-housing.size.y*.5f+BaseHeight*.5f+.002f,housing.center.z+housing.size.z*.5f-.009f),new Vector3(housing.size.x-.10f,BaseHeight,.018f));
        internal static float RailWidth=>Width-.15f;
        internal static float CoverWidth=>Width*(.774f/.8f);
        internal static float CoverHeight=>Height*.974f;
        internal static void Measure(Structure locker)
        {
            if(locker==null||locker.PrefabName!="StructureStorageLocker")throw new InvalidOperationException("Large switchboard requires the native Locker dimension reference.");
            Configure(locker.Bounds);
            Debug.Log("[Modular Switchboards] Large cabinet dimension reference: "+NativeBounds+"; custom cabinet shell, doors and interior.");
        }
        internal static void Configure(Bounds bounds)
        {
            var size=bounds.size;
            if(!Finite(size.x)||!Finite(size.y)||!Finite(size.z)||size.x<.6f||size.x>3f||size.y<1.1f||size.y>3f||size.z<.2f||size.z>1.5f)
                throw new InvalidOperationException("Native Locker dimensions are outside the supported standing cabinet range: "+size);
            NativeBounds=bounds;Ready=true;
        }
        private static bool Finite(float x)=>!float.IsNaN(x)&&!float.IsInfinity(x);
    }
}
