using System.Collections.Generic;
using Assets.Scripts.Objects;
namespace ModularSwitchboards
{
    // Temporary shape prototype: no visible sockets and no hidden electrical endpoints.
    internal static class LargeCabinetPorts
    {
        internal static void Install(SwitchboardCabinet host)
        {
            host.OpenEnds=new List<Connection>();host.UsedPower=0f;
        }
    }
}
