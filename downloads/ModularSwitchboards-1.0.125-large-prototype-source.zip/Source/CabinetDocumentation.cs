namespace ModularSwitchboards
{
    internal static class CabinetDocumentation
    {
        internal static bool Listed(string name)=>name==SwitchboardsMod.LargeCabinetName||name==SwitchboardsMod.CabinetName||name==SwitchboardsMod.MediumCabinetName;
        internal static string Description(string name)
        {
            if(CabinetShape.Large(name))return "Standing Large switchboard. Uses the vanilla Locker dimensions with our own cabinet shell and two doors. Four full-width DIN rows; the DIN modules retain their original size.\n\nExternal power ports and their internal terminals are temporarily omitted from this shape prototype. External power cannot be connected yet. Place on the floor, either free-standing or with its back at a wall.\n\nPrototype construction: 6 Switchboard kits, then 10 Plastic Sheets with a Wrench. Each rail costs 1 Rail kit; optional Large cover costs 4 Cover kits. Existing DIN/Smart/door/label modules fit normally. No automatic connection to neighbouring cabinets. Multiplayer is untested.";
            bool medium=CabinetShape.Medium(name);string size=medium?"Medium":"Small",branches=medium?"3":"2";
            return size+" switchboard family. This description applies to all four versions of this size.\n\n"+
                "Available I/O layouts: 1 IN / "+branches+" OUT, or "+branches+" IN / 1 OUT. Both are available as Basic and Reverse. Choose the actual version from the Switchboard Kit with right-click before construction.\n\n"+
                "Basic distributor: one Input above, Outputs on the opposite side. Basic collector: Inputs occupy those original Output sockets; one Output occupies the original Input socket. Reverse flips the two sides. Internal terminal labels identify every port.\n\n"+
                (medium?"3 DIN rows of 14 positions; double doors. Frame: 3 kits; shell: 5 Plastic Sheets.":"2 DIN rows of 7 positions. Frame: 1 kit; shell: 2 Plastic Sheets.")+" Finish the shell with a Wrench.\n\n"+
                "All versions use the same manual wiring, rails, modules, covers and controls for this size. No built-in connection, overload protection or automatic source transfer. Wire the desired circuits through suitable protection/analyzers/contactors. Collecting Output accepts "+branches+" branch wires; power-module IN and OUT accept three wires each. A1, DATA and Smart Core POWER IN accept one. A branch analyzer can read the whole common Output network.";
        }
    }
}
