using System;
using System.IO;
using UnityEngine;

namespace ModularSwitchboards
{
    // Blender geometry baked as embedded mesh data. No Unity editor/runtime importer required.
    internal static class CabinetGeometry
    {
        internal static Mesh[] Meshes;
        internal static Material[] Materials;

        internal static void EnsureLoaded(Material fallback)
        {
            if (Meshes != null) return;
            var shader = Shader.Find("Standard") ?? Shader.Find("Universal Render Pipeline/Lit") ?? fallback?.shader;
            if (shader == null) throw new InvalidOperationException("No compatible cabinet shader found.");
            using (var stream = typeof(CabinetGeometry).Assembly.GetManifestResourceStream("ModularSwitchboards.Cabinet.meshbin"))
            {
                if (stream == null) throw new InvalidOperationException("Embedded cabinet mesh is missing.");
                using (var reader = new BinaryReader(stream))
                {
                    if (new string(reader.ReadChars(4)) != "SBMS" || reader.ReadInt32() != 1)
                        throw new InvalidDataException("Unsupported cabinet mesh format.");
                    int materialCount = reader.ReadInt32(), meshCount = reader.ReadInt32();
                    if (materialCount < 1 || materialCount > 32 || meshCount != 4)
                        throw new InvalidDataException("Invalid cabinet mesh counts.");
                    var materials = new Material[materialCount];
                    for (int i = 0; i < materialCount; i++)
                    {
                        var color = new Color(reader.ReadSingle(), reader.ReadSingle(), reader.ReadSingle(), reader.ReadSingle());
                        float metal = reader.ReadSingle(), rough = reader.ReadSingle();
                        var material = new Material(shader) { name = "Switchboards.Material." + i };
                        if (material.HasProperty("_Color")) material.SetColor("_Color", color);
                        if (material.HasProperty("_BaseColor")) material.SetColor("_BaseColor", color);
                        if (material.HasProperty("_Metallic")) material.SetFloat("_Metallic", metal);
                        if (material.HasProperty("_Glossiness")) material.SetFloat("_Glossiness", 1f - rough);
                        if (material.HasProperty("_Smoothness")) material.SetFloat("_Smoothness", 1f - rough);
                        materials[i] = material;
                    }
                    var meshes = new Mesh[meshCount];
                    for (int i = 0; i < meshCount; i++)
                    {
                        int count = reader.ReadInt32();
                        if (count < 3 || count > 65535) throw new InvalidDataException("Invalid vertex count.");
                        var vertices = new Vector3[count]; var normals = new Vector3[count];
                        for (int v = 0; v < count; v++)
                        {
                            vertices[v] = new Vector3(reader.ReadSingle(), reader.ReadSingle(), reader.ReadSingle());
                            normals[v] = new Vector3(reader.ReadSingle(), reader.ReadSingle(), reader.ReadSingle());
                        }
                        var mesh = new Mesh { name = "Switchboards." + new[] { "Housing", "Mounting", "Wiring", "Door" }[i] };
                        mesh.vertices = vertices; mesh.normals = normals; mesh.subMeshCount = materialCount;
                        for (int m = 0; m < materialCount; m++)
                        {
                            int n = reader.ReadInt32();
                            if (n < 0 || n > count * 3 || n % 3 != 0) throw new InvalidDataException("Invalid triangle count.");
                            var indices = new int[n];
                            for (int j = 0; j < n; j++)
                            {
                                indices[j] = reader.ReadInt32();
                                if (indices[j] < 0 || indices[j] >= count) throw new InvalidDataException("Invalid mesh index.");
                            }
                            mesh.SetTriangles(indices, m, false);
                        }
                        mesh.RecalculateBounds(); meshes[i] = mesh;
                    }
                    if (stream.Position != stream.Length) throw new InvalidDataException("Unexpected cabinet mesh data.");
                    Materials = materials; Meshes = meshes;
                }
            }
            Debug.Log("[Modular Switchboards] Cabinet shader: " + shader.name);
            Debug.Log("[Modular Switchboards] Blender geometry loaded: housing, mounting, wiring, door.");
        }
    }
}
