using System.Collections.Generic;
using System.Xml.Serialization;
using Assets.Scripts;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Networking;
using Assets.Scripts.Networks;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Pipes;
using Assets.Scripts.Objects.Items;
using Assets.Scripts.Objects.Electrical;
using Assets.Scripts.Objects.Motherboards;
using LibConstruct;
using UnityEngine;
namespace ModularSwitchboards
{
    public sealed class SmartContactorSaveData:StructureSaveData
    {
        [XmlElement]public PlacementBoardStructureSaveData RailBoard;
    }
    public sealed class SmartContactor:Device,IPlacementBoardStructure
    {
        internal const string PrefabNameId="StructureDinSmartContactor";
        public PlacementBoard Board{get;set;}
        public PlacementBoard.BoardCell[] BoardCells{get;set;}
        public SwitchboardCabinet Cabinet=>(Board?.PrimaryHost as DinRail)?.Board?.PrimaryHost as SwitchboardCabinet;
        private CabinetWiring lastWiring;
        internal CabinetWiring Wiring {get{if(Cabinet!=null)lastWiring=Cabinet.Wiring;return lastWiring;}}
        internal Cable PowerFeed,DataFeed;
        internal CableNetwork OldPower,OldData;
        internal bool Conducting=>!IsCursor&&!IsBeingDestroyed&&IsStructureCompleted&&PowerFeed?.CableNetwork!=null&&Powered&&OnOff;
        private float next;
        public override void Awake(){PrefabAudioOwner.PrepareInstance(this);base.Awake();BoardStructureHooks.Awake(this);}
        public override Grid3 GetLocalGrid()=>Board==null?default(Grid3):Board.WorldToGrid(transform.position);
        public override bool CanLogicRead(LogicType type)=>type==LogicType.On||type==LogicType.Power||type==LogicType.RequiredPower||type==LogicType.PrefabHash||type==LogicType.ReferenceId||type==LogicType.NameHash;
        public override bool CanLogicWrite(LogicType type)=>type==LogicType.On;
        public override void SetLogicValue(LogicType type,double value){if(type==LogicType.On)base.SetLogicValue(type,value);}
        public override PassiveTooltip GetPassiveTooltip(Collider hit)
        {var tip=base.GetPassiveTooltip(hit);tip.Extended=(Conducting?"CLOSED — IN connected to OUT.":"OPEN — IN disconnected from OUT.")+" Command: "+(OnOff?"ON":"OFF")+". Control power: "+(Powered?"available":"unavailable")+". DATA is separate. No overload protection.";return tip;}
        private void LateUpdate()
        {
            if(IsCursor)return;
            if(Time.unscaledTime>=next){next=Time.unscaledTime+.15f;SmartContactorNetwork.Refresh(this);}
            if(BuildStates.Count>0)foreach(var hit in BuildStates[0].Colliders)if(hit!=null)hit.enabled=Cabinet!=null&&Cabinet.IsOpen;
            DinBreakerModel.Refresh(this);
        }
        internal void ClearSupply()=>AssessPower(null,false);
        public override void OnAddCableNetwork(CableNetwork network){}
        public override void OnRemoveCableNetwork(CableNetwork network){if(network==OldPower)ClearSupply();}
        public override CanConstructInfo CanConstruct()
        {
            if(IsCursor){MountPlacement.AfterRaycast();MountBoardResolver.Resolve(CursorManager.Instance);}
            if(!(Board is DinModuleBoard board))return CanConstructInfo.InvalidPlacement("Choose a free DIN rail position.");
            var p=board.WorldToGrid(transform.position);
            if(IsCursor){if(MountPlacement.TryLockedGrid(this,board,out var locked))p=locked;else p=new Grid3(DoorModuleLayout.SnapSlot(p.x,DinLayout.FirstModuleSlot*10,(DinLayout.FirstModuleSlot+((DinRail)board.PrimaryHost).ModuleCapacity-1)*10),0,0);PlacementBoard.CursorGrid=p;PlacementBoard.CursorRotation=0;transform.SetPositionAndRotation(board.GridToWorld(p),board.IndexToRotation(0));}
            return board.CanPlace(p,board.RotationToIndex(transform.rotation),1)?CanConstructInfo.ValidPlacement:CanConstructInfo.InvalidPlacement("Choose one free DIN position.");
        }
        protected override CanConstructInfo CanDeconstruct()=>Cabinet==null||!Cabinet.CanAccessModules?CanConstructInfo.InvalidPlacement("Open the cabinet and remove the cover first."):Wiring?.HasWires(ReferenceId)==true&&Prefab.Find<Item>("ItemCableCoil")==null?CanConstructInfo.InvalidPlacement("Cable coil prefab unavailable."):CanConstructInfo.ValidPlacement;
        public override DelayedActionInstance AttackWith(Attack attack,bool doAction=true)=>IsPaintable&&attack.SourceItem is ISprayer sprayer?ISprayer.DoSpray(this,sprayer,doAction):base.AttackWith(attack,doAction);
        public override void OnDeregistered(){Wiring?.RemoveBreaker(ReferenceId);SmartContactorNetwork.Unbind(this);base.OnDeregistered();if(Board!=null)BoardStructureHooks.OnDeregistered(this);}
        public override void OnDestroy(){Wiring?.RemoveBreaker(ReferenceId);SmartContactorNetwork.Unbind(this);base.OnDestroy();}
        public override ThingSaveData SerializeSave(){ThingSaveData data=new SmartContactorSaveData();InitialiseSaveData(ref data);return data;}
        protected override void InitialiseSaveData(ref ThingSaveData data){base.InitialiseSaveData(ref data);if(data is SmartContactorSaveData save&&Board!=null)save.RailBoard=BoardStructureHooks.SerializeSave(this);}
        public override void DeserializeSave(ThingSaveData data){base.DeserializeSave(data);if(data is SmartContactorSaveData save&&save.RailBoard!=null)BoardStructureHooks.DeserializeSave(this,save.RailBoard);}
        public override void SerializeOnJoin(RocketBinaryWriter writer){base.SerializeOnJoin(writer);BoardStructureHooks.SerializeOnJoin(writer,this);}
        public override void DeserializeOnJoin(RocketBinaryReader reader){base.DeserializeOnJoin(reader);BoardStructureHooks.DeserializeOnJoin(reader,this);}
    }
}
