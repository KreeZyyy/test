using System;using System.Linq;using System.Collections.Generic;using ModularSwitchboards;using Assets.Scripts.Networks;using Assets.Scripts.Objects.Electrical;using Assets.Scripts.Objects.Pipes;
class Program
{
 static int count;static void Check(bool v,string why){count++;if(!v)throw new Exception(why);}
 static CabinetWireSaveData W(long a,int p,long b,int q)=>new(){From=new(a,p),To=new(b,q)};
 static void Main()
 {
  long id=20;var physical=new[]{W(0,0,id,0),W(id,1,0,1),W(0,0,id,2)};var open=SmartContactorCircuit.Through(physical,Array.Empty<long>()).ToArray();var closed=SmartContactorCircuit.Through(physical,new[]{id}).ToArray();
  Check(!WireCircuit.Reachable(new(0,0),new(0,1),open,Array.Empty<long>()),"open contact leaks power");
  Check(WireCircuit.Reachable(new(0,0),new(0,1),closed,Array.Empty<long>()),"closed contact blocks power");
  Check(!WireCircuit.Reachable(new(id,2),new(id,1),closed,Array.Empty<long>()),"DATA backfeeds OUT");
  Check(SmartCircuit.Selection(id,open,Array.Empty<long>(),new[]{id},2)==AnalyserCircuit.Input,"OFF lost upstream DATA selection");
  Check(SmartCircuit.Selection(id,closed,Array.Empty<long>(),new[]{id},2)==AnalyserCircuit.Input,"ON migrates upstream DATA selection");
  var noMain=new[]{W(0,0,id,2),W(id,1,0,1)};Check(!WireCircuit.Reachable(new(0,0),new(0,1),SmartContactorCircuit.Through(noMain,new[]{id}),Array.Empty<long>()),"DATA connection powers lamp without IN");
  var branch=new[]{W(0,0,10,0),W(10,1,id,2),W(10,1,0,2)};
  Check(SmartCircuit.Selection(id,branch,Array.Empty<long>(),new[]{10,id},2)==2,"open upstream breaker migrated DATA into Input");
  var cab=new Cabinet();var module=new SmartContactor{Cabinet=cab};var p=new Cable{CableNetwork=new()};var d=new Cable{CableNetwork=new()};cab.Wiring.Power=p;cab.Wiring.Data=d;SmartContactorNetwork.Refresh(module);
  Check(p.CableNetwork.PowerDeviceList.Contains(module)&&!p.CableNetwork.DataDeviceList.Contains(module),"power network exposed unrelated data");
  Check(d.CableNetwork.DataDeviceList.Contains(module)&&!d.CableNetwork.PowerDeviceList.Contains(module),"DATA network became power feed");
  Check(module.DataCable==d&&module.PowerCable==p&&module.DataCables.SequenceEqual(new[]{d})&&module.PowerCables.SequenceEqual(new[]{p}),"native arrays disagree");
  cab.Wiring.Power=null;SmartContactorNetwork.Refresh(module);Check(d.CableNetwork.DataDeviceList.Contains(module)&&module.PowerCable==null,"power loss disconnected remote restart DATA");
  var old=d.CableNetwork;d.CableNetwork=new();SmartContactorNetwork.Refresh(module);Check(!old.DeviceList.Contains(module)&&d.CableNetwork.DataDeviceList.Contains(module),"network rebuild left stale device");
  d.CableNetwork.DeviceList.Add(module);d.CableNetwork.DeviceList.Add(module);SmartContactorNetwork.Refresh(module);Check(d.CableNetwork.DeviceList.Count(x=>x==module)==1,"duplicate registration not repaired");
  p.CableNetwork=d.CableNetwork;cab.Wiring.Power=p;SmartContactorNetwork.Refresh(module);Check(d.CableNetwork.DataDeviceList.Contains(module)&&d.CableNetwork.PowerDeviceList.Contains(module),"shared native network lost one registration role");
  var shared=d.CableNetwork;cab.Wiring.Data=null;SmartContactorNetwork.Refresh(module);Check(shared.GetDeviceRegistration(module).SetEquals(new[]{p})&&!shared.DataDeviceList.Contains(module),"unwired DATA remains visible through power");
  SmartContactorNetwork.Unbind(module);SmartContactorNetwork.Unbind(module);Check(shared.DeviceList.Count==0&&module.DataCables.Length==0&&module.PowerCables.Length==0,"unlink/destroy leak");
  Console.WriteLine(count+" Smart contactor checks passed: switching, DATA/POWER isolation, OFF visibility, breaker branches, rebuilds, duplicate repair, shared network and cleanup.");
 }
}
namespace HarmonyLib{static class AccessTools{public static System.Reflection.PropertyInfo Property(Type t,string n)=>t.GetProperty(n);}}
namespace Assets.Scripts.Objects.Electrical{class Cable{public CableNetwork CableNetwork;}}
namespace Assets.Scripts.Objects.Pipes{class Device{public Cable DataCable;public Cable PowerCable{get;private set;}public Cable[] PowerCables{get;private set;}=Array.Empty<Cable>();public Cable[] DataCables{get;private set;}=Array.Empty<Cable>();}}
namespace Assets.Scripts.Networks
{
 class CableNetwork
 {
  public List<Device> DeviceList=new();public Dictionary<Device,HashSet<Cable>> Registered=new();
  public List<Device> DataDeviceList=>DeviceList.Where(d=>d.DataCables.Any(c=>c.CableNetwork==this)).ToList();
  public List<Device> PowerDeviceList=>DeviceList.Where(d=>d.PowerCables.Any(c=>c.CableNetwork==this)).ToList();
  public void DirtyPowerAndDataDeviceLists(){}public void RefreshNetworkDevice(Device d){}
  public HashSet<Cable> GetDeviceRegistration(Device d)=>Registered.GetValueOrDefault(d);
  public void AddDevice(Cable c,Device d){if(!Registered.TryGetValue(d,out var set))Registered[d]=set=new();set.Add(c);if(!DeviceList.Contains(d))DeviceList.Add(d);}
  public void RemoveDevice(Device d){Registered.Remove(d);DeviceList.RemoveAll(x=>x==d);}
  public void RemoveDevice(Cable c,Device d){if(Registered.TryGetValue(d,out var set)){set.Remove(c);if(set.Count==0)RemoveDevice(d);}}
 }
}
namespace ModularSwitchboards
{
 class SmartContactor:Device{public long ReferenceId=20;public Cabinet Cabinet;public Cable PowerFeed,DataFeed;public CableNetwork OldPower,OldData;public int Clears;public void ClearSupply(){Clears++;}}
 class Cabinet{public CabinetWiring Wiring=new();}
 class CabinetWiring{public Cable Power,Data;public Cable ContactorPowerCable(SmartContactor c)=>Power;public Cable SmartCable(long id,int pin)=>Data;}
}
