using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Serialization;
using Assets.Scripts;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Networking;
using Assets.Scripts.Networks;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Electrical;
using Assets.Scripts.Objects.Pipes;
using Assets.Scripts.Objects.Motherboards;
using Assets.Scripts.UI;
using LibConstruct;
using UnityEngine;
namespace ModularSwitchboards
{
    public sealed class DinTransformerSaveData:TransformerSaveData
    {
        [XmlElement]public PlacementBoardStructureSaveData RailBoard;
        [XmlElement]public int BodyPaintVersion;
        [XmlElement]public int ModuleSlots;
        [XmlElement]public int ConstructionVersion;
    }
    // Native dial/needle, Setting clamp, labeller interaction, logic and serialization.
    // The cabinet owns the only physical network power bridge: never register a
    // second provider for this visual/native-control device.
    public sealed class DinTransformer:Transformer,IPlacementBoardStructure
    {
        internal const string PrefabNameId="StructureDinTransformer";
        internal const int SlotCount=4;
        internal const string MediumPrefabNameId="StructureDinTransformerMedium";
        internal const int MediumSlots=6;
        [SerializeField]internal bool MediumVariant;
        internal bool IsMedium=>MediumVariant;
        internal int TargetSlots=>IsMedium?MediumSlots:SlotCount;
        internal float ContentOffsetX=>IsMedium?2*DinLayout.SlotPitch:0f;
        internal int RestoredWidth(int saved)=>IsMedium?MediumSlots:saved==SlotCount?SlotCount:2;
        internal const int BuildKits=5;
        internal bool WindingConstruction(DynamicThing item,Vector3 world)
        {
            if(IsCursor||IsStructureCompleted||!CabinetCableCoils.IsHeavy(item))return false;
            return (world-transform.TransformPoint(InternalInputAim)).sqrMagnitude>=.016f*.016f&&
                   (world-transform.TransformPoint(InternalOutputAim)).sqrMagnitude>=.016f*.016f;
        }
        public override void UpdateStateVisualizer(bool visualOnly=false)
        {
            base.UpdateStateVisualizer(visualOnly);
            if(CurrentBuildStateIndex>=0&&transform.Find("TransformerFront")!=null&&!IsCursor)
            {
                DinTransformerModel.RefreshConstructionFace(this);
                FittedModelCollider.Rebuild(this);
            }
        }
        [SerializeField]internal int ModuleWidth=SlotCount;
        [SerializeField]internal Mesh WoundFace,UnwoundFace;
        public PlacementBoard Board{get;set;}
        public PlacementBoard.BoardCell[] BoardCells{get;set;}
        public Vector3 InternalInput,InternalOutput,InternalInputAim,InternalOutputAim;
        public SwitchboardCabinet Cabinet=>(Board?.PrimaryHost as DinRail)?.Board?.PrimaryHost as SwitchboardCabinet;
        private CabinetWiring lastWiring;
        internal CabinetWiring Wiring {get{if(Cabinet!=null)lastWiring=Cabinet.Wiring;return lastWiring;}}
        internal bool Conducting=>!IsCursor&&!IsBeingDestroyed&&IsStructureCompleted&&Board!=null&&OnOff&&TransformerBudget.Finite((float)Setting)>0&&(UsedPower<=0||(!GameManager.RunSimulation?Powered:Wiring?.Power.TransformerPowered(ReferenceId)==true));
        public override bool IsPowerProvider=>false;
        public override bool IsPowerInputOutput=>false;
        public override bool DoSubmergableTick=>false;
        public override double GetLogicValue(LogicType type)=>type==LogicType.RequiredPower?TransformerBudget.Finite(UsedPower):base.GetLogicValue(type);
        // The cabinet bills the real control load on IN. Native direct billing
        // stays disabled here, while UsedPower remains the F1/logic nameplate.
        public override float GetGeneratedPower(CableNetwork network)=>0;
        public override float GetUsedPower(CableNetwork network)=>0;
        public override void UsePower(CableNetwork network,float amount){}
        public override void ReceivePower(CableNetwork network,float amount){}
        public override bool AllowSetPower(CableNetwork network)=>false;
        protected override void CheckConnections(){}
        public override void OnAddCableNetwork(CableNetwork network){}
        public override void OnRemoveCableNetwork(CableNetwork network){}
        // This DIN variant has no ON/OFF switch. Native audio/logic may query
        // this before Awake; always enabled is safe even without cached controls.
        // Actual transfer still requires a completed mount, IN power and Setting > 0.
        public override bool OnOff { get { return true; } set { } }
        public override void Awake(){CacheStates(true);PrefabAudioOwner.PrepareInstance(this);base.Awake();BoardStructureHooks.Awake(this);}
        public override void OnRegistered(Cell cell){CacheStates(true);base.OnRegistered(cell);}
        public override Grid3 GetLocalGrid()=>Board==null?default(Grid3):Board.WorldToGrid(transform.position);
        public override CanConstructInfo CanConstruct()
        {
            if(IsCursor){MountPlacement.AfterRaycast();MountBoardResolver.Resolve(CursorManager.Instance);}
            if(!(Board is DinModuleBoard board)||!(board.PrimaryHost is DinRail rail))return CanConstructInfo.InvalidPlacement("Choose free DIN positions inside an open cabinet.");
            var p=board.WorldToGrid(transform.position);
            if(IsCursor)
            {
                if(MountPlacement.TryLockedGrid(this,board,out var locked))p=locked;
                else p=new Grid3(DoorModuleLayout.SnapSlot(p.x,DinLayout.FirstModuleSlot*10,(DinLayout.FirstModuleSlot+rail.ModuleCapacity-ModuleWidth)*10),0,0);
                PlacementBoard.CursorGrid=p;PlacementBoard.CursorRotation=0;transform.SetPositionAndRotation(board.GridToWorld(p),board.IndexToRotation(0));
            }
            return board.CanPlace(p,board.RotationToIndex(transform.rotation),ModuleWidth)?CanConstructInfo.ValidPlacement:CanConstructInfo.InvalidPlacement("The full transformer footprint must be free.");
        }
        protected override CanConstructInfo CanDeconstruct()=>Cabinet?.CanAccessModules!=true?CanConstructInfo.InvalidPlacement("Open the cabinet and remove its cover first."):Wiring?.CanRefundBreaker(ReferenceId)==false?CanConstructInfo.InvalidPlacement("Cable coil prefab unavailable."):CanConstructInfo.ValidPlacement;
        public override DelayedActionInstance AttackWith(Attack attack,bool doAction=true)
        {
            if(Cabinet?.CanAccessModules!=true)return null;
            if(!WindingConstruction(attack.SourceItem,attack.Position)&&Wiring.TryAttack(attack,doAction,out var action))return action;
            return base.AttackWith(attack,doAction);
        }
        public override bool PreventInteraction(out DelayedActionInstance fail,Interactable control,Interaction interaction)
        {
            if(IsCursor||IsBeingDestroyed||Cabinet?.CanAccessModules!=true){fail=new DelayedActionInstance{Duration=0}.Fail("Open the cabinet and remove its cover first.");return true;}
            return base.PreventInteraction(out fail,control,interaction);
        }
        public override DelayedActionInstance InteractWith(Interactable control,Interaction interaction,bool doAction=true)
        {
            if(IsCursor||IsBeingDestroyed||Cabinet?.CanAccessModules!=true)return new DelayedActionInstance{Duration=0}.Fail("Open the cabinet and remove its cover first.");
            return base.InteractWith(control,interaction,doAction);
        }
        public override PassiveTooltip GetPassiveTooltip(Collider hit)
        {
            var tip=new PassiveTooltip(toDefault:true);tip.Title=DisplayName;tip.Extended="Output "+Setting.ToString("0")+" W";return tip;
        }
        private float next;
        private void LateUpdate()
        {
            if(IsCursor)return;
            if(Time.unscaledTime>=next){next=Time.unscaledTime+.15f;DinTransformerNetwork.Refresh(this);if(GameManager.RunSimulation&&InteractPowered!=null){bool live=Wiring?.Power.TransformerPowered(ReferenceId)==true;if(Powered!=live)OnServer.Interact(InteractPowered,live?1:0,skipAnimation:true);}}
            DinBreakerModel.Refresh(this);TransformerFrontSurface.Restore(this);
            if(BuildStates.Count>0)foreach(var hit in BuildStates[0].Colliders)if(hit!=null)hit.enabled=Cabinet?.IsOpen==true;

        }
        internal CabinetPowerNode PowerNode()=>new CabinetPowerNode{ReferenceId=ReferenceId,Conducting=Conducting,IsTransformer=true,TransferLimit=TransformerBudget.Finite((float)Setting),OwnWatts=TransformerBudget.Finite(UsedPower),ServiceEnabled=!IsCursor&&!IsBeingDestroyed&&IsStructureCompleted&&Board!=null};
        public override void OnDeregistered(){Wiring?.Power.RemoveOwnTransformer(ReferenceId);Wiring?.RemoveBreaker(ReferenceId);DinTransformerNetwork.Unbind(this);base.OnDeregistered();if(Board!=null)BoardStructureHooks.OnDeregistered(this);}
        public override void OnDestroy(){Wiring?.Power.RemoveOwnTransformer(ReferenceId);DinTransformerNetwork.Unbind(this);base.OnDestroy();}
        public override ThingSaveData SerializeSave(){ThingSaveData data=new DinTransformerSaveData();InitialiseSaveData(ref data);return data;}
        protected override void InitialiseSaveData(ref ThingSaveData data){base.InitialiseSaveData(ref data);if(data is DinTransformerSaveData save){save.ConstructionVersion=1;save.BodyPaintVersion=1;save.ModuleSlots=ModuleWidth;if(Board!=null)save.RailBoard=BoardStructureHooks.SerializeSave(this);}}
        public override void DeserializeSave(ThingSaveData data){if(data is DinTransformerSaveData old&&old.ConstructionVersion<1&&old.CurrentBuildState==0)old.CurrentBuildState=1;base.DeserializeSave(data);if(data is DinTransformerSaveData save){ModuleWidth=RestoredWidth(save.ModuleSlots);DinTransformerModel.ApplyWidth(this);if(save.RailBoard!=null)BoardStructureHooks.DeserializeSave(this,save.RailBoard);}}
        public override void SerializeOnJoin(RocketBinaryWriter writer){base.SerializeOnJoin(writer);BoardStructureHooks.SerializeOnJoin(writer,this);writer.WriteInt32(ModuleWidth);}
        public override void DeserializeOnJoin(RocketBinaryReader reader){base.DeserializeOnJoin(reader);var mount=new PlacementBoardStructureSaveData{BoardId=reader.ReadInt64(),PrimaryHostId=reader.ReadInt64(),Position=reader.ReadGrid3(),Rotation=reader.ReadSByte()};ModuleWidth=RestoredWidth(reader.ReadInt32());DinTransformerModel.ApplyWidth(this);BoardStructureHooks.DeserializeSave(this,mount);}
    }
}
