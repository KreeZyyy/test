using System.Collections.Generic;
using System.Linq;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class SmartCorePockets
    {
        internal const float DisplayDepth=.004f;
        internal static Mesh Display(Mesh body,Vector3[] outline,Vector3 scale)
        {
            float front=body.bounds.max.z,rear=front-DisplayDepth/scale.z;
            var ring=outline.Select(p=>new Vector3(p.x/scale.x,p.y/scale.y,front)).ToArray();
            float left=ring.Min(p=>p.x),right=ring.Max(p=>p.x),bottom=ring.Min(p=>p.y),top=ring.Max(p=>p.y);
            var pocket=new Bounds(new Vector3((left+right)*.5f,(bottom+top)*.5f,(rear+front+.001f/scale.z)*.5f),new Vector3(right-left,top-bottom,front+.001f/scale.z-rear));
            var mesh=NativeMeshCrop.Outside(body,pocket,"Smart.NativeRoundedDisplayPocket");
            var vertices=mesh.vertices.ToList();var uv=mesh.uv.ToList();var groups=Enumerable.Range(0,mesh.subMeshCount).Select(i=>mesh.GetTriangles(i).ToList()).ToArray();
            var colour=groups[3].Count>0?uv[groups[3][0]]:Vector2.zero;
            var centre=new Vector3((left+right)*.5f,(bottom+top)*.5f,front);float halfX=(right-left)*.5f,halfY=(top-bottom)*.5f;
            var outer=new Vector3[ring.Length];var edges=new int[ring.Length];
            for(int i=0;i<ring.Length;i++)
            {
                var d=ring[i]-centre;float nx=Mathf.Abs(d.x)/halfX,ny=Mathf.Abs(d.y)/halfY;
                float factor=1f/Mathf.Max(nx,ny);outer[i]=centre+d*factor;
                edges[i]=nx>=ny?(d.x>=0?0:2):(d.y>=0?1:3);
            }
            for(int i=0;i<ring.Length;i++)
            {
                int j=(i+1)%ring.Length;Add(vertices,uv,groups[3],ring[i],outer[i],outer[j],colour);Add(vertices,uv,groups[3],ring[i],outer[j],ring[j],colour);
                if(edges[i]!=edges[j])
                {
                    var corner=edges[i]==0?new Vector3(right,top,front):edges[i]==1?new Vector3(left,top,front):edges[i]==2?new Vector3(left,bottom,front):new Vector3(right,bottom,front);
                    Add(vertices,uv,groups[3],outer[i],corner,outer[j],colour);
                }
            }
            mesh.SetVertices(vertices);mesh.SetUVs(0,uv);for(int i=0;i<groups.Length;i++)mesh.SetTriangles(groups[i],i);
            mesh.RecalculateNormals();mesh.RecalculateBounds();return mesh;
        }
        private static void Add(List<Vector3> v,List<Vector2> uv,List<int> ids,Vector3 a,Vector3 b,Vector3 c,Vector2 colour)
        {
            var normal=Vector3.Cross(b-a,c-a);if(normal.sqrMagnitude<1e-18f)return;
            int start=v.Count;v.AddRange(new[]{a,b,c});uv.AddRange(new[]{colour,colour,colour});ids.AddRange(normal.z>0?new[]{start,start+1,start+2}:new[]{start,start+2,start+1});
        }
    }
}
