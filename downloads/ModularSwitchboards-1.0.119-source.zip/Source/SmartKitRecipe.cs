using Assets.Scripts;
using Assets.Scripts.Objects;
using Reagents;
namespace ModularSwitchboards
{
    internal static class SmartKitRecipe
    {
        internal static WorldManager.RecipeData Create()=>new WorldManager.RecipeData
        {
            PrefabName=SwitchboardsMod.SmartKitName,RecipeTier=MachineTier.TierOne,Output=1f,
            Recipe=new Recipe{Copper=10,Steel=8,Solder=4,Time=3f,Energy=400f}
        };
    }
}
