using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class SmartPocketProfile
    {
        private static float Turn(Vector3 a,Vector3 b,Vector3 c)=>(b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x);
        internal static Vector3[] FromMesh(Mesh mesh,Matrix4x4 pose)
        {
            var vertices=mesh.vertices;
            var points=Enumerable.Range(0,mesh.subMeshCount).SelectMany(i=>mesh.GetTriangles(i)).Distinct().Select(i=>pose.MultiplyPoint3x4(vertices[i]))
                .GroupBy(p=>Math.Round(p.x,7)+":"+Math.Round(p.y,7)).Select(g=>new Vector3(g.First().x,g.First().y,0)).OrderBy(p=>p.x).ThenBy(p=>p.y).ToArray();
            return Hull(points);
        }
        internal static Vector3[] Hull(IEnumerable<Vector3> source)
        {
            var points=source.OrderBy(p=>p.x).ThenBy(p=>p.y).ToArray();
            if(points.Length<3)throw new InvalidOperationException("Display outline unavailable.");
            var lower=new List<Vector3>();var upper=new List<Vector3>();
            foreach(var p in points){while(lower.Count>1&&Turn(lower[lower.Count-2],lower[lower.Count-1],p)<=1e-10f)lower.RemoveAt(lower.Count-1);lower.Add(p);}
            foreach(var p in points.Reverse()){while(upper.Count>1&&Turn(upper[upper.Count-2],upper[upper.Count-1],p)<=1e-10f)upper.RemoveAt(upper.Count-1);upper.Add(p);}
            lower.RemoveAt(lower.Count-1);upper.RemoveAt(upper.Count-1);lower.AddRange(upper);return lower.ToArray();
        }
        internal static Vector3[] Octagon(Bounds box,float corner)
        {
            var lo=box.min;var hi=box.max;
            return new[]{new Vector3(lo.x+corner,lo.y,0),new Vector3(hi.x-corner,lo.y,0),new Vector3(hi.x,lo.y+corner,0),new Vector3(hi.x,hi.y-corner,0),new Vector3(hi.x-corner,hi.y,0),new Vector3(lo.x+corner,hi.y,0),new Vector3(lo.x,hi.y-corner,0),new Vector3(lo.x,lo.y+corner,0)};
        }
    }
}
