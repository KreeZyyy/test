using System.Collections.Generic;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class NativeHolderSelection
    {
        internal static List<int>[] Floor(Vector3[] positions,int[][] groups)
        {
            float depth=float.PositiveInfinity;
            foreach(var group in groups)for(int i=0;i<group.Length;i+=3)
            {
                var a=positions[group[i]];var b=positions[group[i+1]];var c=positions[group[i+2]];
                var normal=Vector3.Cross(b-a,c-a);
                if(normal.sqrMagnitude<1e-16f||normal.z<=0||normal.z*normal.z<normal.sqrMagnitude*.99f)continue;
                if(Mathf.Max(a.z,Mathf.Max(b.z,c.z))-Mathf.Min(a.z,Mathf.Min(b.z,c.z))>.00001f)continue;
                depth=Mathf.Min(depth,(a.z+b.z+c.z)/3f);
            }
            if(float.IsInfinity(depth))throw new System.InvalidOperationException("Native battery floor unavailable.");
            var result=new List<int>[groups.Length];
            for(int role=0;role<groups.Length;role++)
            {
                result[role]=new List<int>();var group=groups[role];
                for(int i=0;i<group.Length;i+=3)
                {
                    var a=positions[group[i]];var b=positions[group[i+1]];var c=positions[group[i+2]];
                    if(Mathf.Abs(a.z-depth)>.00001f||Mathf.Abs(b.z-depth)>.00001f||Mathf.Abs(c.z-depth)>.00001f||Vector3.Cross(b-a,c-a).z<=0)continue;
                    result[role].AddRange(new[]{group[i],group[i+1],group[i+2]});
                }
            }
            return result;
        }
        // Keep original vertex IDs/order. No welding, role guesses or UV rebuilding.
        internal static List<int>[] Select(Vector3[] frameVertices,int[][] source)
        {
            var selected=new List<int>[source.Length];
            for(int role=0;role<source.Length;role++)
            {
                selected[role]=new List<int>();var triangles=source[role];
                for(int i=0;i<triangles.Length;i+=3)
                {
                    int a=triangles[i],b=triangles[i+1],c=triangles[i+2];
                    if(ApcBatteryRegion.Contains(frameVertices[a])&&ApcBatteryRegion.Contains(frameVertices[b])&&ApcBatteryRegion.Contains(frameVertices[c]))
                        selected[role].AddRange(new[]{a,b,c});
                }
            }
            return selected;
        }
    }
}
