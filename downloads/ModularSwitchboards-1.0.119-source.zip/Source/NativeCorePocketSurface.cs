using System;
using System.Collections.Generic;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class NativeCorePocketSurface
    {
        internal static void Install(Transform parent,string name,Renderer source,Mesh reference,Vector3[] ring,float rear,float front)
        {
            var mesh=Build(name,reference,source.sharedMaterials.Length,ring,rear,front);
            var go=new GameObject(name){layer=parent.gameObject.layer};go.transform.SetParent(parent,false);
            go.AddComponent<MeshFilter>().sharedMesh=mesh;NativePortSurface.Capture(source,go.AddComponent<MeshRenderer>());
        }
        internal static Mesh Build(string name,Mesh reference,int materialCount,Vector3[] ring,float rear,float front)
        {
            var positions=reference.vertices;var tex=reference.uv;int role=-1;Vector2 sample=Vector2.zero;float best=float.PositiveInfinity,largest=-1;
            for(int r=0;r<reference.subMeshCount;r++)
            {
                var ids=reference.GetTriangles(r);
                for(int i=0;i<ids.Length;i+=3)
                {
                    var a=positions[ids[i]];var b=positions[ids[i+1]];var c=positions[ids[i+2]];var n=Vector3.Cross(b-a,c-a);
                    float spread=Mathf.Max(a.z,Mathf.Max(b.z,c.z))-Mathf.Min(a.z,Mathf.Min(b.z,c.z));
                    bool floor=n.z>0&&spread<.00001f;float depth=(a.z+b.z+c.z)/3f;
                    if(floor&&depth<best||float.IsInfinity(best)&&n.sqrMagnitude>largest)
                    {
                        if(floor)best=depth;largest=n.sqrMagnitude;role=r;
                        sample=tex.Length==positions.Length?(tex[ids[i]]+tex[ids[i+1]]+tex[ids[i+2]])*(1f/3f):Vector2.zero;
                    }
                }
            }
            if(role<0)throw new InvalidOperationException("Original pocket material unavailable.");
            var v=new List<Vector3>();var uv=new List<Vector2>();var triangles=new List<int>();var centre=Vector3.zero;
            foreach(var p in ring)centre+=p;centre*=1f/ring.Length;centre.z=rear;
            for(int i=0;i<ring.Length;i++)
            {
                var a=ring[i];var b=ring[(i+1)%ring.Length];a.z=rear;b.z=rear;
                int start=v.Count;v.AddRange(new[]{centre,a,b});triangles.AddRange(new[]{start,start+1,start+2});
                var topA=a;var topB=b;topA.z=front;topB.z=front;
                start=v.Count;v.AddRange(new[]{a,topA,topB,b});triangles.AddRange(new[]{start,start+1,start+2,start,start+2,start+3});
            }
            foreach(var p in v)uv.Add(sample);
            var mesh=new Mesh{name=name+".NativeSample"};mesh.SetVertices(v);mesh.SetUVs(0,uv);mesh.subMeshCount=materialCount;
            for(int i=0;i<mesh.subMeshCount;i++)mesh.SetTriangles(i==role?triangles:new List<int>(),i);
            mesh.RecalculateNormals();mesh.RecalculateBounds();
            return mesh;
        }
    }
}
