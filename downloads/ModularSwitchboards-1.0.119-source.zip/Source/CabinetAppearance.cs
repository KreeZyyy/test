using System;
using System.Collections.Generic;
using System.Linq;
using Assets.Scripts;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Motherboards;
using HarmonyLib;
using UnityEngine;

namespace ModularSwitchboards
{
    internal static class CabinetAppearance
    {
        private static readonly System.Reflection.FieldInfo PaintMappings = AccessTools.Field(typeof(Thing), "_customMaterials");
        internal static bool CanCacheRenderer(Thing __instance, ref bool __result)
        {
            if (!SwitchboardsMod.IsCabinetName(__instance.PrefabName) && !(__instance is DinRail) && !(__instance is DinBreaker) && !(__instance is SmartModule) && !(__instance is DinTransformer) && !(__instance is InnerCoverModule) && !(__instance is SwitchboardLabel) && !SwitchboardKitModel.IsKit(__instance)) return true;
            __result = false; return false;
        }

        internal static void RefreshPaint(Thing __instance)
        {
            PaintEmission.Normalize(__instance);
            RefreshPaintCore(__instance);
            if(!(__instance is DinBreaker)&&!(__instance is SmartModule)&&!(__instance is DinTransformer))SwitchboardFinish.Refresh(__instance);
        }
        private static void RefreshPaintCore(Thing __instance)
        {
            if(SwitchboardKitModel.IsKit(__instance)){SwitchboardKitModel.Refresh(__instance);return;}
            if (__instance is DinBreaker||__instance is SmartModule||__instance is DinTransformer) { DinBreakerModel.Refresh(__instance);SmartPaintSurface.RestoreNative(__instance); return; }
            if (__instance is DinRail) { DinRailModel.Refresh(__instance); return; }
            if (!SwitchboardsMod.IsCabinetName(__instance.PrefabName)) return;
            var model = __instance.transform.Find("SwitchboardModel");
            if (model == null) return;
            int color = __instance.CustomColor == null ? (int)ColorType.White : __instance.CustomColor.Index;
            foreach (var renderer in CabinetRenderers(__instance,model))
            {
                if (CabinetWiring.IsWireVisual(renderer.name) || renderer.GetComponentInParent<Thing>() != __instance || (renderer.name=="CabinetLabelText" || renderer.name=="TerminalLabelText")) continue;
                if(CabinetTerminalBlocks.RestoreWireColor(renderer))continue;
                var nativePort=renderer.GetComponent<NativePortSurface>();
                if(nativePort!=null){nativePort.Restore();continue;}
                if (renderer.name == "NativeApcWarning") { ApcWarning.RestoreColor(renderer, 0); continue; }
                bool mattePanel=CabinetMatteSurface.IsPanel(renderer.name);
                if(mattePanel)CabinetPaintSurface.Apply(renderer,color);
                var filter = renderer.GetComponent<MeshFilter>();
                if (filter == null || filter.sharedMesh == null) continue;
                var materials = renderer.sharedMaterials;
                for (int i = 0; i < materials.Length; i++)
                {
                    if (filter.sharedMesh.GetIndexCount(i) == 0) continue;
                    if ((renderer.name == "Housing" || renderer.name == OvenInputSupport.RootName || renderer.name == CabinetPowerOutputs.CasingName || renderer.name == "NativeApcOutputBackCap" || renderer.name == "NativeApcOutputShell") && i == CabinetRearSurface.Role) { CabinetRearSurface.Restore(renderer);if(mattePanel)CabinetPaintSurface.Apply(renderer,color);continue; }
                    // All our mesh submeshes use the same role ordering. Spacer is a single native cube.
                    int role = renderer.name == "MountingSpacer" ? 4 : i;
                    var block = new MaterialPropertyBlock();
                    renderer.GetPropertyBlock(block, i);
                    block.SetFloat(Thing.DiffuseIndexPropertyID, role == 0 ? color : CabinetGeometry.PaletteIndices[role]);
                    block.SetFloat(Thing.SmoothnessIndexPropertyID, mattePanel&&i==0?CabinetPaintSurface.Smoothness(color,__instance.SmoothnessIndex):__instance.SmoothnessIndex);
                    block.SetColor(Thing.EMISSION_COLOR, role == 0 ? __instance.EmissionColor : Color.black);
                    renderer.SetPropertyBlock(block, i);
                }
            }
        }

        private static IEnumerable<MeshRenderer> CabinetRenderers(Thing owner,Transform model)
        {
            foreach(var renderer in model.GetComponentsInChildren<MeshRenderer>(true))yield return renderer;
            var outputs=owner.transform.Find(CabinetPowerOutputs.RootName);
            if(outputs!=null)foreach(var renderer in outputs.GetComponentsInChildren<MeshRenderer>(true))yield return renderer;
        }

        internal static void BeginBuildColor(Structure __instance,bool __1,out bool __state)
        {
            // Only actual tool actions enter this path; save loading and replication do not.
            // Run on the simulation authority so join-in-progress clients do not overwrite saved paint.
            __state=SwitchboardsMod.IsCabinetName(__instance.PrefabName) && GameManager.RunSimulation &&
                __1 && __instance.CurrentBuildStateIndex==0;
        }
        internal static void ApplyCompletedWhite(Structure __instance,bool __state)
        {
            if(__state && __instance.CurrentBuildStateIndex==1)
                __instance.SetCustomColor((int)ColorType.White);
        }

        internal static void RegisterRenderers(Thing __instance)
        {
            PaintEmission.Normalize(__instance);
            RegisterRenderersCore(__instance);
            SwitchboardFinish.Refresh(__instance);
        }
        private static void RegisterRenderersCore(Thing __instance)
        {
            if(__instance is DinBreaker door&&door.IsDoorPart)
            {
                __instance.Renderers=__instance.GetComponentsInChildren<MeshRenderer>(true).Where(r=>r.GetComponentInParent<Thing>()==__instance&&r.name!="DoorTerminalText").Select(r=>new ThingRenderer(__instance,r)).ToList();
                PaintMappings.SetValue(__instance,new List<CustomColorMapping>());return;
            }

            if (__instance is InnerCoverModule||SwitchboardKitModel.IsKit(__instance))
            {
                __instance.Renderers=__instance.GetComponentsInChildren<MeshRenderer>(true).Where(r=>r.GetComponentInParent<Thing>()==__instance).Select(r=>new ThingRenderer(__instance,r)).ToList();
                PaintMappings.SetValue(__instance,new List<CustomColorMapping>());if(SwitchboardKitModel.IsKit(__instance))SwitchboardKitModel.Refresh(__instance);return;
            }
            if (__instance is DinRail || __instance is DinBreaker || __instance is SmartModule || __instance is DinTransformer)
            {
                __instance.Renderers = new List<ThingRenderer>();
                var moduleMappings=new List<CustomColorMapping>();
                foreach (var renderer in __instance.GetComponentsInChildren<MeshRenderer>(true))
                    if (renderer.GetComponentInParent<Thing>() == __instance && renderer.name!="BreakerStateText" && renderer.name!="FuseCaps" && renderer.name!="IntactFuse" && renderer.name!="BurntFuse" && renderer.name!="BatteryPart" && renderer.name!="NativeApcBatteryBay" && renderer.name!="NativeAnalyserFront" && renderer.name!="BatteryContactPads" && renderer.name!="BatteryGoldContacts" && renderer.name!="BatteryBareMounts" && renderer.name!="BatteryUnfinishedBacking" && renderer.name!="NativeApcBatteryFloor")
                    {
                        // Native Thing.SetCustomColor writes every renderer in this
                        // list, even when it has no explicit paint mapping.
                        if(__instance is DinTransformer&&renderer.name!="DinBreakerModel")continue;
                        if(__instance is SmartModule&&!SmartPaintSurface.IsPainted(renderer.name))continue;
                        if(__instance is DinBreaker output&&output.IsSmartOutputModule&&renderer.name!="DinBreakerModel")continue;
                        var entry=new ThingRenderer(__instance,renderer);__instance.Renderers.Add(entry);
                        // The casing and Smart display bezel share paintable role 1.
                        // Screen, glyphs, chip and contacts remain separate.
                        if((__instance is DinBreaker||__instance is SmartModule||__instance is DinTransformer)&&(renderer.name=="DinBreakerModel"||__instance is SmartModule&&renderer.name=="NativeLEDBezel")&&entry.MeshFilter.sharedMesh.GetIndexCount(1)>0)
                            moduleMappings.Add(new CustomColorMapping(entry,1,GameManager.GetColorIndex(__instance.PaintableMaterial)));
                    }
                PaintMappings.SetValue(__instance,moduleMappings);
                if (__instance is DinBreaker||__instance is SmartModule||__instance is DinTransformer){DinBreakerModel.Refresh(__instance);SmartPaintSurface.RestoreNative(__instance);}else DinRailModel.Refresh(__instance);
                return;
            }
            if (!SwitchboardsMod.IsCabinetName(__instance.PrefabName)) return;
            var model = __instance.transform.Find("SwitchboardModel");
            if (model == null) return;
            __instance.Renderers = new List<ThingRenderer>();
            var mappings = new List<CustomColorMapping>();
            foreach (var renderer in CabinetRenderers(__instance,model))
            {
                if (CabinetWiring.IsWireVisual(renderer.name) || renderer.GetComponentInParent<Thing>() != __instance || (renderer.name=="CabinetLabelText" || renderer.name=="TerminalLabelText")) continue;
                var tr = new ThingRenderer(__instance, renderer);
                __instance.Renderers.Add(tr);
                var mesh = tr.MeshFilter.sharedMesh;
                if ((renderer.name == "Housing" || renderer.name == "Door" || renderer.name == "DoorReturnLip") && mesh.GetIndexCount(0) > 0)
                    mappings.Add(new CustomColorMapping(tr, 0, GameManager.GetColorIndex(__instance.PaintableMaterial)));
            }
            PaintMappings.SetValue(__instance, mappings);
            __instance.HasColorState = false;
            RefreshPaint(__instance);
            Debug.Log("[Modular Switchboards] Native APC texture mapping ready; exterior paint mappings=" + mappings.Count);
        }
    }
}
