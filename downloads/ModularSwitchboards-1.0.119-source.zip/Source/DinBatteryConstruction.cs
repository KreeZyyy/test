using System.Collections.Generic;
using System.Linq;
using Assets.Scripts.Objects;
using HarmonyLib;
using Rendering;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class DinBatteryConstruction
    {
        internal static void Install(DinBreaker owner)
        {
            var model=owner.transform.Find("DinBreakerModel");
            var holder=model.Find("OriginalAPCHolderMount");
            var control=model.Find("BatteryControl");
            var bay=holder.GetComponentInChildren<MeshRenderer>(true);
            var backing=NativeApcHolder.InstallUnfinishedFloor(model,ApcBatteryGeometry.HitBounds);
            var frame=owner.BuildStates[0];var finished=owner.BuildStates[1];
            frame.RenderMode=BuildStateRenderMode.OnMineAndPreviousStates;
            frame.Interactables=new List<Interactable>();
            frame.Colliders=frame.Colliders.Where(c=>c!=control.GetComponent<Collider>()).ToList();
            frame.LinkedGameObjects=new List<GameObject>{model.gameObject,backing};
            foreach(var hit in frame.Colliders)if(hit!=null&&!frame.LinkedGameObjects.Contains(hit.gameObject))frame.LinkedGameObjects.Add(hit.gameObject);
            finished.Visualizer=bay;finished.RendererInstance=null;finished.StateMeshes=new List<Mesh>();
            finished.RenderMode=BuildStateRenderMode.OnMyState;
            finished.LinkedGameObjects=frame.LinkedGameObjects.Where(g=>g!=backing).Concat(new[]{holder.gameObject,control.gameObject}).ToList();
            finished.Colliders=new List<Collider>(frame.Colliders){control.GetComponent<Collider>()};
            finished.Interactables=owner.Interactables;
            owner.Thumbnail=CabinetIcons.Get("DinBatteryFinished");frame.Thumbnail=CabinetIcons.Get("DinBatteryUnfinished");finished.Thumbnail=owner.Thumbnail;
            AccessTools.Field(typeof(BuildState),"initialDrawData").SetValue(finished,new DrawData{mesh=null,materials=new Material[0]});
            backing.SetActive(false);
            ModelBlueprint.Refresh(owner);
            backing.SetActive(true);
            owner.CacheStates(true);
            // Prefabs are state -1: do not invoke native stage visualization here.
        }
    }
}
