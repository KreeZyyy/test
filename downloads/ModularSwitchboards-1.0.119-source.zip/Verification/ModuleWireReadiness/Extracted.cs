using System.Linq;partial class Wiring{public bool WireEndpointReady(CabinetWireEnd end)
        {
            if(end.Owner==0)return true;
            var module=Breakers.Cast<Structure>().Concat(Transformers).Concat(SmartModules).Concat(Contactors).FirstOrDefault(m=>m.ReferenceId==end.Owner);
            return module!=null&&module.IsStructureCompleted&&!module.IsCursor&&!module.IsBeingDestroyed;
        }}