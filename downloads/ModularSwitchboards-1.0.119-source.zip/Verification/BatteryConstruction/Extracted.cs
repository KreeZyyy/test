using System.Xml.Serialization;namespace ModularSwitchboards{public sealed class DinBreakerSaveData : StructureSaveData
    {
        [XmlElement] public PlacementBoardStructureSaveData RailBoard;
        [XmlElement] public bool Tripped;
        [XmlElement] public int BodyPaintVersion;
        [XmlElement] public int BatteryConstructionVersion;
    }partial class DinBreaker:Native{public override ThingSaveData SerializeSave()
        {
            ThingSaveData data = new DinBreakerSaveData();
            InitialiseSaveData(ref data);
            return data;
        }protected override void InitialiseSaveData(ref ThingSaveData data)
        {
            base.InitialiseSaveData(ref data);
            if (data is DinBreakerSaveData save){save.Tripped=Tripped;save.BodyPaintVersion=1;if(IsBatteryModule)save.BatteryConstructionVersion=1;if(Board!=null)save.RailBoard=BoardStructureHooks.SerializeSave(this);}
        }public override void DeserializeSave(ThingSaveData data)
        {
            if(IsBatteryModule&&data is DinBreakerSaveData old&&old.BatteryConstructionVersion<1&&old.CurrentBuildState==0)old.CurrentBuildState=1;
            base.DeserializeSave(data);
            if(IsContactor)ContactorClosed=false;
            if (data is DinBreakerSaveData save){Tripped=save.Tripped;if(save.RailBoard!=null)BoardStructureHooks.DeserializeSave(this,save.RailBoard);}
        }public Assets.Scripts.Objects.Items.BatteryCell Battery=>IsBatteryModule&&IsStructureCompleted&&Slots.Count==1?Slots[0].Get() as Assets.Scripts.Objects.Items.BatteryCell:null;public bool Conducting=>!IsBeingDestroyed&&(!IsBatteryModule||IsStructureCompleted)&&!IsSmartOutputModule&&(IsContactor?ContactorClosed:(IsDoorStop?!OnOff:(IsDoorBridge||IsDoorLed||IsBatteryModule||IsAnalyserModule|| (IsFuseHolder?!Tripped&&Slots.Count==1&&Slots[0].Get() is MultiConstructor kit&&kit.Quantity==1&&System.Array.IndexOf(AllowedFuseKits,kit.PrefabHash)>=0:OnOff))));}}