using System;
using System.Collections.Generic;
using System.Linq;
using Assets.Scripts;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Items;
using Assets.Scripts.Objects.Motherboards;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class CabinetWireRefund
    {
        internal static int Normalise(int colour)=>GameManager.IsValidColor(colour)?colour:(int)ColorType.Red;
        internal static int CoilColour(DynamicThing coil)=>Normalise(coil?.CustomColor==null?-1:coil.CustomColor.Index);
        internal static bool TryRefund(IEnumerable<CabinetWireSaveData> wires,Vector3 position,Slot destination)
        {
            if(!GameManager.RunSimulation)return false;var made=new List<Stackable>();
            try
            {
                foreach(var group in wires.GroupBy(w=>new{w.CableKind,Colour=Normalise(w.ColorIndex)}))
                {
                    var prefab=CabinetCableCoils.RefundPrefab(group.Key.CableKind);if(prefab==null)throw new InvalidOperationException("Missing coil prefab");int units=group.Sum(w=>w.CableUnits);
                    while(units>0)
                    {
                        var item=OnServer.Create<Stackable>(prefab,position,Quaternion.identity);if(item==null)throw new InvalidOperationException("Could not create coil refund");made.Add(item);
                        int quantity=Math.Min(units,item.MaxQuantity);if(quantity<=0)throw new InvalidOperationException("Invalid coil stack size");item.SetQuantity(quantity);OnServer.SetCustomColor(item,group.Key.Colour);units-=quantity;
                    }
                }
            }
            catch(Exception ex){foreach(var item in made)OnServer.Destroy(item);Debug.LogWarning("[Modular Switchboards] Wire refund retained original connections: "+ex.Message);return false;}
            foreach(var item in made)
            {
                // Preserve native hand-stack behavior, including colour mixing
                // whenever the game's CanStack permits it. The held stack wins.
                if(destination?.Get() is Stackable held&&held.PrefabHash==item.PrefabHash&&held.CanStack(item))
                {
                    int quantity=Math.Min(held.MaxQuantity-held.Quantity,item.Quantity);
                    if(quantity>0){held.AddQuantity(quantity);if(quantity==item.Quantity){OnServer.Destroy(item);continue;}item.SetQuantity(item.Quantity-quantity);}
                }
                OnServer.MoveToSlotOrWorld(item,destination);
            }
            return true;
        }
    }
}
