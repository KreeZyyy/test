-- Optional StationeersLua + Integrated Circuit (Lua).
-- Original LED modes: 0 number, 10 text, other native formats unchanged.
-- Before Setting is written: RUN. Errors ALWAYS override your value.
local LT = ic.enums.LogicType
local db = ic.const.BASE_UNIT_INDEX
function tick()
    ic.write(db, LT.Mode, 10)
    ic.write(db, LT.Setting, ic.ascii.pack6("HELLO"))
end
-- Numeric: ic.write(db, LT.Mode, 0); ic.write(db, LT.Setting, 42.5)
-- Zero is valid. LT.Color changes the custom value colour, not body paint.
-- Return to RUN: ic.write(db, LT.Mode, 17)
-- Core POWER IN supplies power only. Attach Smart Output modules on its left.
-- Each Output DATA tap selects a network; batch operations see their union.
-- Indexed Lua batch: 0 nearest Core, 1 next left (including unwired positions).
-- ic.net messages use the first available data network.
