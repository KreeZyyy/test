using Assets.Scripts;
using Assets.Scripts.Inventory;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Items;
using UnityEngine;
using HarmonyLib;
using System.Collections;

namespace ModularSwitchboards
{
    // Scoped to an open cabinet. Normal cable construction resumes outside it.
    internal static class CabinetWiringInput
    {
        private static Structure hiddenCursor;
        private static DynamicThing editingItem;
        private static bool cursorWasVisible,panelWasVisible;
        internal static bool ModePrefix(InventoryManager __instance)
        {
            if(GameManager.IsBatchMode||CursorManager.Instance==null)return true;
            var active=InventoryManager.ActiveHandSlot?.Get();
            var target=CursorManager.CursorThing;
            var cabinet=target as SwitchboardCabinet;
            if(target is DinBreaker breaker)cabinet=CabinetWiring.CabinetOf(breaker);
            if(target is DinRail rail)cabinet=rail.Board?.PrimaryHost as SwitchboardCabinet;
            if(active is ISprayer&&active.RootParentHuman!=null&&cabinet!=null&&cabinet.IsOpen&&!cabinet.HasInnerCover&&cabinet.IsStructureCompleted&&target==cabinet&&cabinet.Wiring.PaintWireAt(CursorManager.CursorHit.point)!=null)
                return PaintMode(__instance,cabinet,active);
            if((!CabinetWiring.IsCoil(active)&&!(active is WireCutter))||active.RootParentHuman==null||cabinet==null||!cabinet.IsOpen||cabinet.HasInnerCover||!cabinet.IsStructureCompleted||
                !cabinet.Wiring.ContainsInteractionPoint(CursorManager.CursorHit.point))
            {Restore(__instance);return true;}
            if(hiddenCursor!=null&&editingItem!=active)Restore(__instance);
            var ghost=InventoryManager.ConstructionCursor;
            if(ghost!=null)
            {
                if(hiddenCursor!=ghost)
                {hiddenCursor=ghost;editingItem=active;cursorWasVisible=ghost.gameObject.activeSelf;panelWasVisible=__instance.ConstructionPanel.IsVisible;}
                ghost.gameObject.SetActive(false);
                if(__instance.ConstructionPanel.IsVisible)__instance.ConstructionPanel.SetVisible(false);
            }
            if(__instance.ActionCoroutine!=null)
            {__instance.StopCoroutine(__instance.ActionCoroutine);__instance.ActionCoroutine=null;active.OnPrimaryUseEnd();}
            __instance.ClearCursor();
            var attack=new Attack(__instance.ActiveHand.Slot,__instance.InactiveHand.Slot,CursorManager.CursorHit.point,cabinet,1f,CursorManager.Instance.CursorTargetCollider,false,false);
            if(!cabinet.Wiring.TryAttack(attack,false,out var action))return false;
            if(action!=null)
            {
                var tip=new PassiveTooltip(action,string.Empty,cabinet){color=action.IsDisabled?Color.red:Color.green};
                __instance.TooltipRef.HandleToolTipDisplay(tip);
                if(KeyManager.GetMouseDown("Primary")&&!action.IsDisabled)
                    OnServer.AttackWith(active.RootParentHuman,(byte)__instance.ActiveHand.SlotId,(byte)__instance.InactiveHand.SlotId,cabinet.ReferenceId,attack.Position,1f,false,false);
            }
            if(KeyManager.GetMouseDown("Secondary")&&CabinetWiring.IsCoil(active))
                OnServer.AttackWith(active.RootParentHuman,(byte)__instance.ActiveHand.SlotId,(byte)__instance.InactiveHand.SlotId,cabinet.ReferenceId,attack.Position,1f,true,false);
            return false;
        }
        private static readonly System.Reflection.MethodInfo PaintWait=AccessTools.Method(typeof(InventoryManager),"WaitUntilDone",new[]{typeof(InventoryManager.DelegateEvent),typeof(Thing.DelayedActionInstance),typeof(int),typeof(int)});
        private static bool PaintMode(InventoryManager inventory,SwitchboardCabinet cabinet,DynamicThing active)
        {
            Restore(inventory);
            var point=CursorManager.CursorHit.point;
            var wire=cabinet.Wiring.PaintWireAt(point);
            var attack=new Attack(inventory.ActiveHand.Slot,inventory.InactiveHand.Slot,point,cabinet,1f,CursorManager.Instance.CursorTargetCollider,false,false);
            inventory.ClearCursor();CursorManager.ClearLastSelectionId();
            if(!cabinet.Wiring.TryAttack(attack,false,out var action)||action==null)return false;
            inventory.TooltipRef.HandleToolTipDisplay(new PassiveTooltip(action,"Internal wire",cabinet){color=action.IsDisabled?Color.red:Color.green});
            if(KeyManager.GetMouseDown("Primary")&&!action.IsDisabled&&inventory.ActionCoroutine==null&&PaintWait!=null)
            {
                // Keep the game's progress bar, hold duration, sound and release
                // cancellation. Complete only on the original wire and tool.
                InventoryManager.DelegateEvent finish=()=>
                {
                    if(inventory.LastCompletedRatio<1f||InventoryManager.ActiveHandSlot?.Get()!=active||CursorManager.CursorThing!=cabinet||!cabinet.IsOpen||cabinet.HasInnerCover||
                        !ReferenceEquals(cabinet.Wiring.PaintWireAt(CursorManager.CursorHit.point),wire))return;
                    OnServer.AttackWith(active.RootParentHuman,(byte)inventory.ActiveHand.SlotId,(byte)inventory.InactiveHand.SlotId,cabinet.ReferenceId,CursorManager.CursorHit.point,1f,false,false);
                };
                var routine=(IEnumerator)PaintWait.Invoke(inventory,new object[]{finish,action,action.ActionSoundHash,action.ActionCompleteSoundHash});
                inventory.ActionCoroutine=inventory.StartCoroutine(routine);
            }
            return false;
        }
        private static void Restore(InventoryManager inventory)
        {
            if(hiddenCursor!=null&&InventoryManager.ConstructionCursor==hiddenCursor&&InventoryManager.ActiveHandSlot?.Get()==editingItem&&InventoryManager.CurrentMode==InventoryManager.Mode.Placement)
            {hiddenCursor.gameObject.SetActive(cursorWasVisible);if(panelWasVisible)inventory.ConstructionPanel.SetVisible(true);}
            hiddenCursor=null;editingItem=null;cursorWasVisible=panelWasVisible=false;
        }
    }
}
