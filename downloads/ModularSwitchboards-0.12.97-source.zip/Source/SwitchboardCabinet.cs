using System.Collections.Generic;
using System.Linq;
using Assets.Scripts;
using Assets.Scripts.Util;
using Assets.Scripts.Inventory;
using Assets.Scripts.Objects.Electrical;
using Assets.Scripts.Networks;
using Assets.Scripts.Objects.Pipes;
using System.Xml.Serialization;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Networking;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Structures;
using Assets.Scripts.Localization2;
using LibConstruct;
using UnityEngine;

namespace ModularSwitchboards
{
    public sealed class SwitchboardCabinetSaveData : StructureSaveData
    {
        [XmlElement] public PlacementBoardHostSaveData RailBoard;
        [XmlArray] public CabinetWireSaveData[] Wires;
        [XmlElement] public int CoverSchema;
        [XmlElement] public PlacementBoardHostSaveData CoverBoard;
    }

    // Retains the stock locker interactions; owns the LibConstruct mounting surface.
    public sealed class SwitchboardCabinet : Locker, IPlacementBoardHost
    {
        private CabinetWiring wiring;
        internal CabinetWiring Wiring
        {
            get {if(wiring==null){wiring=GetComponent<CabinetWiring>();if(wiring==null)wiring=gameObject.AddComponent<CabinetWiring>();wiring.Owner=this;}return wiring;}
        }
        public override bool IsPowerProvider=>true;
        public override bool IsPowerInputOutput=>true;
        public override float GetGeneratedPower(CableNetwork network)=>Wiring.Power.Generated(network);
        public override float GetUsedPower(CableNetwork network)=>Wiring.Power.Used(network);
        public override void UsePower(CableNetwork network,float value)=>Wiring.Power.Use(network,value);
        public override void ReceivePower(CableNetwork network,float value)=>Wiring.Power.Receive(network,value);
        public override bool AllowSetPower(CableNetwork network)=>Wiring.Power.AllowsPower(network);
        public override bool IsProviderToDevice(Device other,ref List<long> evaluated)=>Wiring.Power.IsProviderTo(this,other,ref evaluated);
        public Grid3[] PortBodyGrids;
        public Connection InputConnection => OpenEnds?.FirstOrDefault(p=>p.ConnectionRole==ConnectionRole.Input);
        public Connection Output1Connection => OpenEnds?.FirstOrDefault(p=>p.ConnectionRole==ConnectionRole.Output);
        public Connection Output2Connection => OpenEnds?.FirstOrDefault(p=>p.ConnectionRole==ConnectionRole.Output2);
        public override PassiveTooltip GetPassiveTooltip(Collider hitCollider)
        {
            if(hitCollider!=null && IsStructureCompleted)
            {
                var wireTarget=hitCollider.GetComponent<CabinetWireTarget>();
                if(wireTarget!=null)return new PassiveTooltip(toDefault:true){Title=wireTarget.End.ToString()};
                var terminal=hitCollider.GetComponent<CabinetTerminalBlock>();
                if(terminal!=null && terminal.Owner==this && terminal.TerminalCollider==hitCollider && terminal.ExternalConnection!=null)
                    return new PassiveTooltip(toDefault:true).Populate(terminal.ExternalConnection);
            }
            return base.GetPassiveTooltip(hitCollider);
        }
        private void PrepareInputConnection()
        {
            foreach(var port in OpenEnds)
            {
                port.Parent=this;
                port.ConnectionType=IsStructureCompleted?NetworkType.Power:NetworkType.None;
                port.Validate();
            }
        }
        public override object GetLocalSmallGridBounds()
        {
            if(PortBodyGrids==null)return base.GetLocalSmallGridBounds();
            var grids=new HashSet<Grid3>(PortBodyGrids);
            foreach(var port in OpenEnds)
                if(port?.Transform!=null)
                {
                    // Native cable traversal looks for the device at the other end of its connector.
                    // Register the T junction itself, without reserving the empty rectangle around it.
                    grids.Add(transform.InverseTransformPoint(port.Transform.position+port.Transform.forward*SmallGrid.SmallGridSize).ToGrid(SmallGrid.SmallGridSize,SmallGrid.SmallGridOffset));
                }
            // Connection.LocalGrid is where the cable lives, not occupied device body.
            // Reserving it makes Cable.CanConstruct reject this cabinet before highlighting.
            foreach(var port in OpenEnds)
                if(port?.Transform!=null)grids.Remove(transform.InverseTransformPoint(port.Transform.position).ToGrid(SmallGrid.SmallGridSize,SmallGrid.SmallGridOffset));
            return grids.ToArray();
        }
        public override bool IsConnected(Connection otherEnd)=>IsStructureCompleted && base.IsConnected(otherEnd);
        protected override void OnBuildStateUpdated(int newState,int previousState)
        {
            foreach(var port in OpenEnds)port.ConnectionType=newState>=1?NetworkType.Power:NetworkType.None;
            base.OnBuildStateUpdated(newState,previousState);
            if(!IsCursor && GridController!=null && GameManager.GameState==GameState.Running)
            {
                if(newState<1)
                    foreach(var network in ConnectedCableNetworks.ToArray())network.RemoveDevice(this);
                InitializeDataConnection();
                if(newState>=1)InitializeDevice();
            }
        }
        public Transform RailOrigin;
        public BoxCollider RailSurface;
        private BoardRef<CabinetRailBoard> railBoard;
        public CabinetRailBoard RailBoard => railBoard?.Board;
        // Prefab dimensions, not save data: existing covers adopt their cabinet's profile.
        public float InnerCoverWidth=.346f,InnerCoverHeight=.466f,InnerCoverDepth=.1015f,InnerCoverThickness=.002f;
        internal InnerCoverLayout.Panel CoverProfile=>new InnerCoverLayout.Panel(InnerCoverWidth,InnerCoverHeight,InnerCoverDepth,InnerCoverThickness);
        public Transform CoverOrigin;
        public BoxCollider CoverSurface;
        private BoardRef<CabinetCoverBoard> coverBoard;
        public CabinetCoverBoard CoverBoard => coverBoard?.Board;
        public bool HasInnerCover => CurrentBuildStateIndex==2 || CoverBoard?.Structures.OfType<InnerCoverModule>().Any(c=>!c.IsBeingDestroyed)==true;
        public bool CanAccessModules => CurrentBuildStateIndex>=1&&IsOpen;
        public bool CanFitRails => CurrentBuildStateIndex == 1 && IsOpen && !HasInnerCover;

        public IEnumerable<PlacementBoard> GetPlacementBoards()
        {
            if (RailBoard != null) yield return RailBoard;
            if (CoverBoard != null) yield return CoverBoard;
        }
        public IEnumerable<BoxCollider> CollidersForBoard(PlacementBoard board)
        {
            if (board is CabinetCoverBoard) { if(CoverSurface!=null)yield return CoverSurface; }
            else if (RailSurface != null) yield return RailSurface;
        }
        public void OnBoardStructureRegistered(PlacementBoard board, IPlacementBoardStructure structure) { }
        public void OnBoardStructureDeregistered(PlacementBoard board, IPlacementBoardStructure structure) { }

        public override void OnRegistered(Cell cell)
        {
            var ready=Wiring;
            PrepareInputConnection();
            base.OnRegistered(cell);
            if(!IsCursor && InputConnection!=null)
                Debug.Log("[Modular Switchboards] Cabinet IN ready: role="+InputConnection.ConnectionRole+
                    "; type="+InputConnection.ConnectionType+"; localGrid="+InputConnection.GetLocalGrid()+
                    "; facingGrid="+InputConnection.GetFacingGrid()+"; completed="+IsStructureCompleted);
            if (!IsCursor && RailOrigin != null)
                BoardHostHooks.OnRegisteredBoard(this, ref railBoard, RailOrigin);
            if(!IsCursor&&CoverOrigin!=null)BoardHostHooks.OnRegisteredBoard(this,ref coverBoard,CoverOrigin);
        }
        public override void OnFinishedLoad()
        {
            var ready=Wiring;
            PrepareInputConnection();
            base.OnFinishedLoad();
            if (!IsCursor && RailOrigin != null)
                BoardHostHooks.OnFinishedLoadBoard(this, ref railBoard, RailOrigin);
            if(!IsCursor&&CoverOrigin!=null)BoardHostHooks.OnFinishedLoadBoard(this,ref coverBoard,CoverOrigin);
        }
        public override ThingSaveData SerializeSave()
        {
            ThingSaveData data = new SwitchboardCabinetSaveData();
            InitialiseSaveData(ref data);
            return data;
        }
        protected override void InitialiseSaveData(ref ThingSaveData data)
        {
            base.InitialiseSaveData(ref data);
            if(data is SwitchboardCabinetSaveData wireSave){wireSave.Wires=Wiring.Save();wireSave.CoverSchema=1;}
            if (data is SwitchboardCabinetSaveData save && RailBoard != null)
                save.RailBoard = BoardHostHooks.SerializeBoard(this, RailBoard);
            if(data is SwitchboardCabinetSaveData coverSave&&CoverBoard!=null)coverSave.CoverBoard=BoardHostHooks.SerializeBoard(this,CoverBoard);
        }
        public override void DeserializeSave(ThingSaveData data)
        {
            base.DeserializeSave(data);
            Wiring.Load((data as SwitchboardCabinetSaveData)?.Wires);
            // Old cabinet saves intentionally have no board and gain an empty one on load.
            BoardHostHooks.DeserializeBoard(this, (data as SwitchboardCabinetSaveData)?.RailBoard,
                out railBoard, RailOrigin);
            BoardHostHooks.DeserializeBoard(this,(data as SwitchboardCabinetSaveData)?.CoverBoard,out coverBoard,CoverOrigin);
        }
        public override void SerializeOnJoin(RocketBinaryWriter writer)
        {
            base.SerializeOnJoin(writer);
            BoardHostHooks.SerializeBoardOnJoin(writer, this, RailBoard);
            Wiring.Write(writer);
            BoardHostHooks.SerializeBoardOnJoin(writer,this,CoverBoard);
        }
        public override void DeserializeOnJoin(RocketBinaryReader reader)
        {
            base.DeserializeOnJoin(reader);
            BoardHostHooks.DeserializeBoardOnJoin(reader, this, out railBoard, RailOrigin);
            Wiring.Read(reader);
            BoardHostHooks.DeserializeBoardOnJoin(reader,this,out coverBoard,CoverOrigin);
        }
        public override void BuildUpdate(RocketBinaryWriter writer,ushort networkUpdateType)
        {base.BuildUpdate(writer,networkUpdateType);if(Thing.IsNetworkUpdateRequired(CabinetWiring.UpdateFlag,networkUpdateType))Wiring.Write(writer);}
        public override void ProcessUpdate(RocketBinaryReader reader,ushort networkUpdateType)
        {base.ProcessUpdate(reader,networkUpdateType);if(Thing.IsNetworkUpdateRequired(CabinetWiring.UpdateFlag,networkUpdateType))Wiring.Read(reader);}
        public override void OnDestroy()
        {
            BoardHostHooks.OnDestroyedBoard(this, railBoard);
            BoardHostHooks.OnDestroyedBoard(this,coverBoard);
            base.OnDestroy();
        }
        protected override CanConstructInfo CanDeconstruct()
        {
            if(CurrentBuildStateIndex==2)return IsOpen?CanConstructInfo.ValidPlacement:CanConstructInfo.InvalidPlacement("Open the cabinet first.");
            if(HasInnerCover)return CanConstructInfo.InvalidPlacement("Remove the inner cover first.");
            return Wiring.HasAnyWires?CanConstructInfo.InvalidPlacement("Remove internal wires first."):RailBoard != null && RailBoard.Structures.Count > 0
                ? CanConstructInfo.InvalidPlacement("Remove DIN rails first.") : base.CanDeconstruct();
        }
        public override DelayedActionInstance AttackWith(Attack attack, bool doAction = true)
        {
            if(attack.SourceItem?.PrefabName=="ItemWrench"&&CurrentBuildStateIndex==2)
            {
                if(!IsOpen)return new DelayedActionInstance{Duration=0}.Fail("Open the cabinet first.");
                return base.AttackWith(attack,doAction);
            }
            if(HasInnerCover&&(attack.SourceItem?.PrefabName=="ItemWrench"||attack.SourceItem?.PrefabName=="ItemDrill"))return null;
            if(Wiring.TryAttack(attack,doAction,out var wireAction))return wireAction;
            if(Wiring.HasAnyWires && (attack.SourceItem?.PrefabName=="ItemWrench"||attack.SourceItem?.PrefabName=="ItemDrill"))return null;
            if (RailBoard != null && RailBoard.Structures.Count > 0 &&
                (attack.SourceItem?.PrefabName == "ItemWrench" || attack.SourceItem?.PrefabName == "ItemDrill"))
                return null;
            return base.AttackWith(attack, doAction);
        }
        private float nextPortCheck;
        private void SyncExternalCableNetworks()
        {
            var live=new HashSet<Cable>();
            if(IsStructureCompleted)
                foreach(var port in OpenEnds)
                {
                    var cable=port.GetCable();if(cable==null || cable.CableNetwork==null)continue;
                    live.Add(cable);
                    if(cable.CableNetwork.GetDeviceRegistration(this)?.Contains(cable)!=true)
                        cable.CableNetwork.AddDevice(cable,this);
                }
            // Cable removal/replacement can change the inherited Device.PowerCable cache.
            if(PowerCable!=live.FirstOrDefault())InitializeDataConnection();
            foreach(var network in ConnectedCableNetworks.ToArray())
            {
                var registration=network.GetDeviceRegistration(this);if(registration==null)continue;
                foreach(var cable in registration.ToArray())
                    if(!live.Contains(cable)||cable.CableNetwork!=network)network.RemoveDevice(cable,this);
            }
        }
        private void LateUpdate()
        {
            if(!IsCursor && GameManager.GameState==GameState.Running)Wiring.Tick();
            if (RailSurface != null) RailSurface.enabled = !IsCursor && CanFitRails;
            if(CoverSurface!=null)CoverSurface.enabled=!IsCursor&&CanFitRails&&InventoryManager.ConstructionCursor is InnerCoverModule;
            if(CoverSurface!=null&&CoverSurface.enabled)Thing._colliderLookup[CoverSurface]=this;
            // Outside connectors can occupy separate cable cells. Keep native registration
            // current after cable placement/removal/network rebuilds without joining the nets.
            if(!IsCursor && GameManager.GameState==GameState.Running && Time.unscaledTime>=nextPortCheck)
            {
                nextPortCheck=Time.unscaledTime+.25f;SyncExternalCableNetworks();
            }
        }
    }

    public sealed class CabinetRailBoard : PlacementBoard
    {
        public override float GridSize => DinLayout.ModulePitch;
        public override IPlacementBoardStructure EquivalentStructure(Structure structure)
            => structure is DinRail && PrimaryHost is SwitchboardCabinet host && host.CanFitRails
                ? structure as IPlacementBoardStructure : null;
    }
}
