# Oasis Switchboard Prototype 0.1.1

**Tohle už je plugin určený k instalaci do `mods`, ne HTML simulace.** Je to první herní vertikální prototyp s jedním pevným vývodem. Obsahuje skutečnou DLL pro LaunchPad, ale v běžící hře zde zatím otestovaný není.

## Oprava prázdné varianty v 0.1.1
Dodané hlášení potvrzuje registraci zařízení i stavebnice, ale uživatel viděl prázdnou variantu a jen kolizní kostku. Nová verze klonuje původní WorldManager.SourcePrefabs místo již registrovaných runtime kopií, přenáší data stavebních meshů a doplňuje Localization.GetThingName pro obě vlastní jména. Před zpřístupněním varianty ověřuje přítomnost modelových dat; počty zapisuje jako Raw clone visuals. Přesná příčina neviditelnosti a oprava vyžadují další herní test.
Aktualizace: ukonči celou hru, přepiš DLL a About (nebo celý balíček) v původní složce OasisSwitchboard, pak znovu spusť. IC10 skripty se nemění.

## Instalace a první test

1. Ukonči Stationeers.
2. Složku **OasisSwitchboard** ze ZIPu vlož do `Dokumenty\My Games\Stationeers\mods`.
3. V LaunchPadu povol **Oasis Switchboard Prototype [StationeersLaunchPad]** a spusť hru.
4. První test proveď v novém kreativním světě. V nabídce spawnování hledej **Oasis** nebo **Kit (Oasis Switchboard Prototype)**.
5. Pokud hra nabízí jen standardní **Kit (Transformer)**, projdi jeho stavební varianty; plugin se do kompatibilní MultiConstructor stavebnice také pokouší přidat.
6. Postav **Oasis Switchboard Prototype**, dokonči běžné stavební kroky a zapoj malý testovací okruh: zdroj/baterie → IN prototypu → OUT → světlo/spotřebič. Vstup a výstup nepropojuj zpátky do jedné sítě.
7. Ovladačem prototyp zapni. Výchozí limit je nejvýše 2000, mění se nativním ovladačem transformátoru nebo proměnnou **Setting**. Ověř, že vypnutí **On** přeruší výstup.
8. Připoj IC10 k datové síti zařízení, vyber prototyp na **d0** a nahraj `scripts/read-only.ic10`. Sleduj r0 až r3. Samostatný `switch-test.ic10` větev záměrně vypíná, použij jej jen v testovacím okruhu.
9. Ulož svět, znovu jej načti a ověř zařízení, nastavený limit i napájení. Ukládání je implementované přes původní formát transformátoru, ale tento herní test ještě neproběhl.

Pokud zařízení ani stavebnici nenajdeš, pošli `BepInEx/LogOutput.log`. Hledej zejména řádky `Registered StructureOasisSwitchboardPrototype`, `Registered creative kit` a případnou chybu registrace. Bez registrace nemá smysl zkoušet IC10.

## Co skutečně implementuje

- Nový prefab **StructureOasisSwitchboardPrototype** s vlastním stabilním hashem a samostatným názvem.
- Vlastní kreativní stavebnici odvozenou z existující stavebnice transformátoru, pokud ji hra poskytne.
- Skutečné nativní elektrické zařízení třídy **Transformer**. Vstupní a výstupní síť, přenos energie, nativní vypínání a limit zachovává hra; plugin nevyrábí energii ani neslučuje sítě.
- Jednoduchý procedurální rám skříně v existujícím rozměru zařízení. Původní tělo transformátoru, ovladače, kolizní plochy a zásuvky zůstávají přístupné. **Není to ještě velký čtyřpozicový model z návrhového náhledu.**
- Hodnoty přes standardní logické rozhraní. To umožňuje čtení IC10 a klientům, které toto rozhraní používají; vlastní Lua API ani odhadnuté Lua volání nepřidáváme.

| Hodnota | Čtení / zápis | Význam |
|---|---|---|
| `On` | nativní čtení/zápis | Zapnutí nebo vypnutí zařízení. |
| `Setting` | nativní čtení/zápis | Limit původního transformátoru. |
| `Maximum`, `Ratio` | nativní čtení | Původní maximum a poměr nastavení. |
| `PowerActual` | čtení přidané modem | Poslední skutečná alokace z tohoto zařízení do výstupní sítě (`PowerProvider.EnergyUsed`); při vypnutí nebo neplatném zapojení vrací nulu. |
| `PowerRequired` | čtení přidané modem | Nativní požadavek celé výstupní sítě z posledního power ticku. Při dalším zdroji na téže síti nejde o požadavek výhradně na náš přístroj. |

Nezaměňuj `Power` za měření příkonu: nativní `Power` je stav dostupnosti napájení. První měření používá původní jednotky power ticku hry; **integrované Wh/kWh tato verze ještě nevystavuje**, dokud nebude ověřená časová základna.

## Co zatím nemá

Čtyři oddělené vývody, vyjímatelné moduly, LibConstruct osazování, pojistkový držák, vratný jistič, otevírací dveře a plný 3D model nejsou v této první DLL zapojené. Nemá vlastní výrobní recept a nepřidává žádné nové internetové spojení ani externí proces.
Prototype omezuje výkon jako nativní transformátor; **Setting není vypínací práh jističe** a limit sám nepředstavuje pojistku.
Multiplayer nebyl ověřen. Před prvním multiplayer testem je potřeba stejná verze na serveru i klientech; metriky se navíc čtou z lokálního power ticku, takže zobrazení na klientovi vyžaduje další ověření.

## Ukládání a odebrání

Prefab zůstává třídou Transformer a používá původní TransformerSaveData. Dodatečný rám se vytváří při načtení instance. Nemáme vlastní neuložené přenosové sítě nebo čítače energie. Nastavení a samotný save/reload je přesto nutné ověřit ve hře.
Před odebráním modu odstraň z uloženého světa jeho vlastní zařízení a stavebnice; jejich nové prefab hashe bez modu hra nezná.

## Ověření tohoto sestavení

- DLL se sestavila proti uživatelem dodané herní Assembly-CSharp.dll, BepInEx 5 a rozhraní LaunchPadu. Build: žádné chyby, jedno upozornění na rozdílné tranzitivní verze System.Net.Http v referenčních knihovnách.
- **27 kontrol vazeb** ověřilo metadata, existenci všech Harmony cílů, typy návratových hodnot a parametrů, identitu prefabů, událost registrace a existenci původního TransformerSaveData.
- Kontrola potvrzuje, že mod nepatchuje nativní metody UsePower/ReceivePower/GetGeneratedPower/GetUsedPower/OnPowerTick/ApplyState.
- **Neověřeno v běžící hře:** úspěšné vytvoření prefabů, zobrazení v kreativním menu, umístění, rám, fyzické zapojení, IC10, save/reload a multiplayer. To je účel prvního testovacího ZIPu. Samotný úspěšný build toto nedokazuje.

## Zdroj a sestavení

Vlastní zdroj je přiložen v `source/`. Herní DLL, LaunchPad, BepInEx ani cizí modely nejsou přibalené. Postup je v `source/BUILD.txt`. Detailní výpis kontrol je v `validation/binding-results.log`.
Tato etapa záměrně nepoužívá LibConstruct: nejdřív ověřuje jeden skutečný vstup a výstup na nativním zařízení. Následující etapa přidá skříň-host a samostatný osazovaný modul se zachováním tohoto elektrického základu.
