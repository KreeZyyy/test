using System;
using System.Collections.Generic;
using System.Linq;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Structures;
using Assets.Scripts.Objects.Electrical;
using Assets.Scripts.Objects.Motherboards;
using Assets.Scripts;
using Assets.Scripts.UI;
using HarmonyLib;
using Rendering;
using UnityEngine.Rendering;
using UnityEngine;
using Object = UnityEngine.Object;

namespace ModularSwitchboards
{
    internal static class CabinetModel
    {
        internal const float MountOffset = .12f;
        internal const float ShellForwardOffset = .08f;
        private static float frontSign = -1f;
        private static MeshRenderer apcRenderer;

        internal static void Install(Structure cabinet)
        {
            var oldRenderers = cabinet.GetComponentsInChildren<Renderer>(true);
            var apc = WorldManager.Instance.SourcePrefabs.OfType<AreaPowerControl>()
                .FirstOrDefault(p => p.PaintableMaterial != null);
            apcRenderer = apc == null ? null : apc.GetComponentsInChildren<MeshRenderer>(true).FirstOrDefault();
            if (apc != null && Mathf.Abs(apc.Bounds.center.z) > .005f)
                frontSign = Mathf.Sign(apc.Bounds.center.z);
            Debug.Log("[Modular Switchboards] APC mounting orientation: front sign " + frontSign +
                "; APC bounds centre " + (apc == null ? "unavailable" : apc.Bounds.center.ToString()));
            CabinetGeometry.MapFromApc(apc);
            CabinetGeometry.EnsureLoaded();
            // Keep the tested native object/save type, replace its visual and collision geometry.
            foreach (var r in oldRenderers) Object.DestroyImmediate(r);
            foreach (var m in cabinet.GetComponentsInChildren<MeshFilter>(true)) Object.DestroyImmediate(m);
            foreach (var c in cabinet.GetComponentsInChildren<Collider>(true)) Object.DestroyImmediate(c);
            foreach (var a in cabinet.GetComponentsInChildren<Animator>(true)) Object.DestroyImmediate(a);
            if (cabinet is Locker locker)
            {
                locker.DontUseOpen = false;
                AccessTools.Field(typeof(Locker), "lockerAnimComponent")?.SetValue(locker, null);
                AccessTools.Field(typeof(Locker), "shutterMaterialAnimComponent")?.SetValue(locker, null);
            }
            cabinet.BaseAnimator = null;
            cabinet.Renderers = new List<ThingRenderer>();
            cabinet._staticColliders = new List<Collider>();
            cabinet._dynamicColliders = new List<Collider>();
            cabinet._selfColliders = new List<Collider>();
            cabinet.CustomNavMeshFilter = null;
            cabinet.structureRenderMode = StructureRenderMode.Standard;
            cabinet.PlacementType = PlacementSnap.FaceMount;
            cabinet.AllowedRotations = AllowedRotations.Wall;
            cabinet.RotationAxis = RotationAxis.Z;
            cabinet.GridSize = SmallGrid.SmallGridSize;
            // GridCenter adds half a cell internally. The native small-grid offset cancels
            // that half-cell shift so the back-plane origin can lie on a wall face.
            cabinet.GridOffset = SmallGrid.SmallGridOffset;
            // Locker prefabs can override GridSize/GridOffset with private per-axis snapping.
            // FaceMount needs the cabinet origin on the wall plane, not the locker grid offset.
            var axisSnap = AccessTools.Field(typeof(Structure), "_useAxisIndependentGridSnapping");
            var requiresFrame = AccessTools.Field(typeof(SmallGrid), "requiresFrame");
            if (axisSnap == null || requiresFrame == null)
                throw new MissingFieldException("Native mount configuration changed.");
            axisSnap.SetValue(cabinet, false);
            requiresFrame.SetValue(cabinet, false);
            cabinet.BoundsGridShiftForward = cabinet.BoundsGridShiftSide = 0f;
            cabinet.BoundsGridAddHeight = cabinet.BoundsGridAddBottom = 0f;
            cabinet.BoundsGridExtraHeight = cabinet.BoundsGridExtraWidth = 0f;
            cabinet.BoundsGridExtraForward = cabinet.BoundsForward = 0f;
            if (cabinet is SmallGrid smallGrid) smallGrid.DualRegister = false;
            Debug.Log("[Modular Switchboards] Wall mount reset: native small grid (0.5 m, offset 0.25 m), wall/frame support.");
            cabinet.SelectionDisplay = SelectionHighlightMethod.Bounds;
            cabinet.UseCellPosition = false;
            cabinet.ForceGridBounds.Clear();
            cabinet.HasColorState = false;
            cabinet.MPBRenderers.Clear();
            cabinet.CustomColor = GameManager.GetColorSwatch((int)ColorType.Gray);
            cabinet.PaintableMaterial = cabinet.CustomColor.Normal;
            if (apc != null) cabinet.SmoothnessIndex = apc.SmoothnessIndex;
            Debug.Log("[Modular Switchboards] APC paint style: " + (apc == null ? "native color palette" : apc.PrefabName));

            var open = cabinet.Interactables.FirstOrDefault(i => i.Action == InteractableType.Open);
            if (open == null) throw new InvalidOperationException("Native cabinet has no Open interaction.");
            open.Animator = null; open.FakeCollider = null;
            open.CanKeyInteract = true;
            cabinet.Interactables = new List<Interactable> { open };

            var model = Child(cabinet.transform, "SwitchboardModel", cabinet.gameObject.layer);
            model.localPosition = new Vector3(0f, 0f, frontSign * MountOffset);
            model.localRotation = frontSign < 0f ? Quaternion.Euler(0f, 180f, 0f) : Quaternion.identity;
            var frame = Renderer(model, "Frame", CabinetGeometry.Meshes[0], CabinetGeometry.Materials);
            var shell = Child(model, "CompletedShell", cabinet.gameObject.layer);
            shell.localPosition = new Vector3(0f, 0f, ShellForwardOffset);
            var housing = Renderer(shell, "Housing", CabinetGeometry.Meshes[1], CabinetGeometry.Materials);
            var interior = Renderer(shell, "Interior", CabinetGeometry.Meshes[2], CabinetGeometry.Materials);
            var hinge = Child(shell, "DoorHinge", cabinet.gameObject.layer);
            hinge.localPosition = new Vector3(.20f, 0f, .187f);
            Renderer(hinge, "Door", CabinetGeometry.Meshes[3], CabinetGeometry.Materials);
            ApcWarning.Install(apc, hinge);
            var doorCollider = Box(hinge, "DoorCollider", new Vector3(-.20f, 0f, .004f), new Vector3(.4f, .5f, .018f));
            open.Collider = doorCollider;
            var frameColliders = new List<Collider>
            {
                Box(model,"FrameLeft",new Vector3(-.185f,0f,.015f),new Vector3(.02f,.48f,.03f)),
                Box(model,"FrameRight",new Vector3(.185f,0f,.015f),new Vector3(.02f,.48f,.03f)),
                Box(model,"FrameTop",new Vector3(0f,.23f,.015f),new Vector3(.35f,.02f,.03f)),
                Box(model,"FrameBottom",new Vector3(0f,-.23f,.015f),new Vector3(.35f,.02f,.03f))
            };
            var colliders = new List<Collider>
            {
                Box(shell, "BackCollider", new Vector3(0f, 0f, .003f), new Vector3(.4f, .5f, .006f)),
                Box(shell, "LeftCollider", new Vector3(-.197f, 0f, .09f), new Vector3(.006f, .5f, .18f)),
                Box(shell, "RightCollider", new Vector3(.197f, 0f, .09f), new Vector3(.006f, .5f, .18f)),
                Box(shell, "TopCollider", new Vector3(0f, .247f, .09f), new Vector3(.4f, .006f, .18f)),
                Box(shell, "BottomCollider", new Vector3(0f, -.247f, .09f), new Vector3(.4f, .006f, .18f)),
                doorCollider
            };
            foreach (float x in new[] { -.15f, .15f })
            {
                var spacer = GameObject.CreatePrimitive(PrimitiveType.Cube);
                spacer.name = "MountingSpacer"; spacer.layer = cabinet.gameObject.layer;
                spacer.transform.SetParent(model, false);
                spacer.transform.localPosition = new Vector3(x, 0f, -MountOffset / 2f);
                spacer.transform.localScale = new Vector3(.018f, .38f, MountOffset);
                var spacerFilter = spacer.GetComponent<MeshFilter>();
                spacerFilter.sharedMesh = Object.Instantiate(spacerFilter.sharedMesh);
                CabinetGeometry.ApplyNativeUv(spacerFilter.sharedMesh);
                spacer.GetComponent<MeshRenderer>().sharedMaterial = CabinetGeometry.Materials[4];
                colliders.Add(spacer.GetComponent<Collider>());
                frameColliders.Add(spacer.GetComponent<Collider>());
            }
            foreach (float x in new[] { -.15f, .15f })
            {
                var support = GameObject.CreatePrimitive(PrimitiveType.Cube);
                support.name = "MountingSpacer"; support.layer = cabinet.gameObject.layer;
                support.transform.SetParent(shell, false);
                support.transform.localPosition = new Vector3(x, 0f, -ShellForwardOffset / 2f);
                support.transform.localScale = new Vector3(.018f, .38f, ShellForwardOffset);
                var filter = support.GetComponent<MeshFilter>();
                filter.sharedMesh = Object.Instantiate(filter.sharedMesh);
                CabinetGeometry.ApplyNativeUv(filter.sharedMesh);
                support.GetComponent<MeshRenderer>().sharedMaterial = CabinetGeometry.Materials[4];
                colliders.Add(support.GetComponent<Collider>());
            }
            var renderers = new[] { frame, housing };
            var drawField = AccessTools.Field(typeof(BuildState), "initialDrawData");
            if (drawField == null) throw new MissingFieldException("BuildState.initialDrawData");
            for (int i = 0; i < cabinet.BuildStates.Count; i++)
            {
                var state = cabinet.BuildStates[i];
                state.Visualizer = renderers[i];
                state.RendererInstance = null;
                state.RenderMode = BuildStateRenderMode.OnMyState;
                state.StateMeshes = new List<Mesh>();
                state.LinkedGameObjects = i == 1 ? new List<GameObject> { shell.gameObject } : new List<GameObject>();
                state.Colliders = new List<Collider>(i == 0 ? frameColliders : colliders);
                state.Interactables = i == 1 ? new List<Interactable> { open } : new List<Interactable>();
                state.Thumbnail = CabinetIcons.Get(i == 0 ? "Frame" : "Cabinet");
                state.BlockAir = false; state.AlwaysBlockAir = false;
                state.BlockGravity = false; state.BlockLight = false;
                drawField.SetValue(state, new DrawData { mesh = null, materials = new Material[0] });
            }
            // Damaged stock locker meshes would not match the replacement geometry.
            cabinet.BrokenBuildStates = new List<BrokenBuildState>();
            var door = cabinet.gameObject.AddComponent<CabinetDoor>();
            door.Owner = cabinet; door.Hinge = hinge;

            // Keep the preview external to the cabinet hierarchy. Native cursor setup destroys
            // the cabinet renderers before instantiating this independent blueprint.
            var blueprint = Child(cabinet.transform.parent, "SwitchboardBlueprint", cabinet.gameObject.layer);
            var combine = new List<CombineInstance>();
            foreach (int meshIndex in new[] { 0 })
                for (int m = 0; m < CabinetGeometry.Meshes[meshIndex].subMeshCount; m++)
                    if (CabinetGeometry.Meshes[meshIndex].GetIndexCount(m) != 0)
                        combine.Add(new CombineInstance
                        {
                            mesh = CabinetGeometry.Meshes[meshIndex], subMeshIndex = m,
                            transform = Matrix4x4.TRS(model.localPosition, model.localRotation, Vector3.one) *
                                (meshIndex == 3 ? Matrix4x4.Translate(hinge.localPosition) : Matrix4x4.identity)
                        });
            var ghostMesh = new Mesh { name = "Switchboards.ClosedBlueprint" };
            ghostMesh.CombineMeshes(combine.ToArray(), true, true);
            ghostMesh.RecalculateBounds();
            var ghostRenderer = blueprint.gameObject.AddComponent<MeshRenderer>();
            ghostRenderer.sharedMaterial = new Material(CabinetGeometry.Materials[0]);
            var ghostFilter = blueprint.gameObject.AddComponent<MeshFilter>(); ghostFilter.sharedMesh = ghostMesh;
            var wireframe = blueprint.gameObject.AddComponent<Wireframe>();
            wireframe.BlueprintTransform = blueprint;
            wireframe.BlueprintBounds = ghostMesh.bounds;
            wireframe.BlueprintMeshFilter = ghostFilter;
            wireframe.BlueprintRenderer = ghostRenderer;
            blueprint.gameObject.AddComponent<CabinetBlueprint>();
            cabinet.Blueprint = blueprint.gameObject;
            cabinet.BlueprintOrientVector = Vector3.zero;
            cabinet.Thumbnail = CabinetIcons.Get("Cabinet");
            cabinet.Thumbnails = new Sprite[0];
            SetBounds(cabinet);
            Debug.Log("[Modular Switchboards] Native APC mapped cabinet: bare mounting frame then sheet housing; dedicated state thumbnails.");
        }

        // Called from a narrowly scoped bounds prefix, including construction preview copies.
        internal static void SetBounds(Structure cabinet)
        {
            cabinet.ThingTransform = cabinet.transform;
            cabinet.Bounds = new Bounds(new Vector3(0f, 0f, frontSign * (.105f + MountOffset + ShellForwardOffset / 2f)), new Vector3(.43f, .51f, .23f + ShellForwardOffset));
            cabinet.SurfaceArea = 2f * (.4f * .5f + .5f * .18f + .18f * .4f);
            cabinet.GridBounds = new GridBounds(cabinet);
        }

        private static Transform Child(Transform parent, string name, int layer)
        {
            var obj = new GameObject(name) { layer = layer };
            obj.transform.SetParent(parent, false);
            return obj.transform;
        }

        private static MeshRenderer Renderer(Transform parent, string name, Mesh mesh, Material[] materials)
        {
            var obj = Child(parent, name, parent.gameObject.layer).gameObject;
            obj.AddComponent<MeshFilter>().sharedMesh = mesh;
            var renderer = obj.AddComponent<MeshRenderer>(); renderer.sharedMaterials = materials;
            renderer.lightProbeUsage = apcRenderer == null ? LightProbeUsage.BlendProbes : apcRenderer.lightProbeUsage;
            renderer.reflectionProbeUsage = apcRenderer == null ? ReflectionProbeUsage.BlendProbes : apcRenderer.reflectionProbeUsage;
            renderer.shadowCastingMode = apcRenderer == null ? ShadowCastingMode.On : apcRenderer.shadowCastingMode;
            renderer.receiveShadows = apcRenderer == null || apcRenderer.receiveShadows;
            renderer.probeAnchor = obj.transform;
            return renderer;
        }

        private static BoxCollider Box(Transform parent, string name, Vector3 center, Vector3 size)
        {
            var obj = Child(parent, name, parent.gameObject.layer).gameObject;
            var collider = obj.AddComponent<BoxCollider>(); collider.center = center; collider.size = size;
            return collider;
        }
    }
}
