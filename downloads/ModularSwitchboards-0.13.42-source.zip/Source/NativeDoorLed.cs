using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Assets.Scripts;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Structures;
using Assets.Scripts.Objects.Motherboards;
using UnityEngine;
using UnityEngine.Rendering;
namespace ModularSwitchboards
{
    // Read only the native Lights Kit LED, then keep its mesh/UV/materials.
    // Do not clone a WallLight device: power and network state belong to the door module.
    internal static class NativeDoorLed
    {
        internal static void Install(DinBreaker owner,DoorLedView fallback)
        {
            var sources=WorldManager.Instance.SourcePrefabs;
            var kits=sources.OfType<MultiConstructor>().Where(k=>k.PrefabName.IndexOf("Light",StringComparison.OrdinalIgnoreCase)>=0).ToArray();
            var listed=kits.SelectMany(k=>k.Constructables??new List<Structure>()).OfType<WallLight>().ToArray();
            var source=listed.Where(IsLed).OrderBy(l=>l.PrefabName,StringComparer.Ordinal).FirstOrDefault()??sources.OfType<WallLight>().Where(IsLed).OrderBy(l=>l.PrefabName,StringComparer.Ordinal).FirstOrDefault();
            if(source==null)
            {
                Debug.LogWarning("[Modular Switchboards] Native LED light not located. Light candidates: "+string.Join(", ",listed.Select(l=>l.PrefabName).Distinct())+"; keeping temporary lens.");
                return;
            }
            var parts=source.GetComponentsInChildren<MeshRenderer>(true).Where(r=>r.GetComponent<MeshFilter>()?.sharedMesh!=null&&!r.GetComponentsInParent<MonoBehaviour>(true).Any(c=>c.GetType().FullName=="VolumetricLight"||c.GetType().FullName=="ch.sycoforge.Flares.EasyFlares")).ToArray();
            if(parts.Length==0){Debug.LogWarning("[Modular Switchboards] Native LED has no readable mesh: "+source.PrefabName);return;}
            GameObject nativeRoot=null;
            try
            {
                var all=new List<Vector3>();
                foreach(var renderer in parts)
                {
                    CabinetGeometry.ReadNativeMesh(renderer.GetComponent<MeshFilter>().sharedMesh,out var points,out _,out _);
                    var matrix=source.transform.worldToLocalMatrix*renderer.transform.localToWorldMatrix;
                    all.AddRange(points.Select(matrix.MultiplyPoint3x4));
                }
                var bounds=new Bounds(all[0],Vector3.zero);foreach(var p in all)bounds.Encapsulate(p);
                float sign=Mathf.Abs(bounds.center.z)>.0001f?Mathf.Sign(bounds.center.z):-1f;
                var rotation=sign<0?Quaternion.Euler(0,180,0):Quaternion.identity;
                var rotated=all.Select(p=>rotation*p).ToArray();
                var oriented=new Bounds(rotated[0],Vector3.zero);foreach(var p in rotated)oriented.Encapsulate(p);
                float scale=.029f/Mathf.Max(oriented.size.x,oriented.size.y);
                var shift=new Vector3(-oriented.center.x*scale,-oriented.center.y*scale,.009f-oriented.max.z*scale);
                var group=new GameObject("NativeDoorLed"){layer=owner.gameObject.layer};group.transform.SetParent(owner.transform,false);nativeRoot=group;
                var view=group.AddComponent<NativeDoorLedView>();view.Owner=owner;
                var renderers=new List<MeshRenderer>();var paintSlots=new List<bool[]>();var offMaterials=new List<Material[]>();var onMaterials=new List<Material[]>();
                var mappings=typeof(Thing).GetField("_customMaterials",BindingFlags.Instance|BindingFlags.NonPublic)?.GetValue(source) as List<CustomColorMapping>;
                var green=GameManager.GetColorSwatch((int)ColorType.Green);
                foreach(var original in parts)
                {
                    var matrix=Matrix4x4.Translate(shift)*Matrix4x4.Scale(Vector3.one*scale)*Matrix4x4.Rotate(rotation)*source.transform.worldToLocalMatrix*original.transform.localToWorldMatrix;
                    var mesh=NativeMeshCrop.Read(original.GetComponent<MeshFilter>().sharedMesh,matrix,new Bounds(Vector3.zero,Vector3.one*10f),"Native LED "+original.name);
                    if(mesh==null)continue;
                    var go=new GameObject("NativeLedMesh"){layer=owner.gameObject.layer};go.transform.SetParent(group.transform,false);
                    go.AddComponent<MeshFilter>().sharedMesh=mesh;var renderer=go.AddComponent<MeshRenderer>();
                    var originals=original.sharedMaterials;
                    renderer.sharedMaterials=originals.Select(m=>new Material(m)).ToArray();
                    var paint=originals.Select((m,slot)=>!original.gameObject.CompareTag("NotPaintable")&&(m==source.PaintableMaterial||m.mainTexture is Texture2DArray||
                        mappings!=null&&mappings.Any(map=>map.MaterialIndex==slot&&map.ThingRenderer.GetRenderer()==original)||
                        source.PaintableMaterial!=null&&m.name.Replace(" (Instance)","")==source.PaintableMaterial.name.Replace(" (Instance)",""))).ToArray();
                    var off=renderer.sharedMaterials;
                    var on=off.ToArray();
                    for(int i=0;i<paint.Length;i++)if(paint[i]){if(!(originals[i].mainTexture is Texture2DArray))off[i]=new Material(green.Normal);on[i]=new Material(green.Emissive);on[i].EnableKeyword("_EMISSION");}
                    renderer.sharedMaterials=off;offMaterials.Add(off);onMaterials.Add(on);
                    for(int slot=0;slot<off.Length;slot++){var block=new MaterialPropertyBlock();original.GetPropertyBlock(block,slot);renderer.SetPropertyBlock(block,slot);}
                    renderer.shadowCastingMode=original.shadowCastingMode;renderer.receiveShadows=original.receiveShadows;
                    renderers.Add(renderer);paintSlots.Add(paint);
                }
                view.Surfaces=renderers.Select((renderer,i)=>new NativeLedSurface{Renderer=renderer,Paint=paintSlots[i],Off=offMaterials[i],On=onMaterials[i]}).ToArray();
                if(source.Light!=null)
                {
                    var lightRoot=UnityEngine.Object.Instantiate(source.Light.gameObject,group.transform);
                    foreach(var collider in lightRoot.GetComponentsInChildren<Collider>(true))UnityEngine.Object.DestroyImmediate(collider);
                    lightRoot.name="NativeLedGlow";lightRoot.transform.localPosition=new Vector3(0,0,.012f);lightRoot.transform.localRotation=Quaternion.identity;lightRoot.transform.localScale=Vector3.one*scale;
                    // Retain native visual effects, remove device/control scripts if any.
                    foreach(var script in lightRoot.GetComponentsInChildren<MonoBehaviour>(true))
                    {
                        string n=script.GetType().FullName;
                        if(n!="VolumetricLight"&&n!="ch.sycoforge.Flares.EasyFlares")UnityEngine.Object.DestroyImmediate(script);
                        else ReduceEffect(script);
                    }
                    view.Glow=lightRoot.GetComponent<Light>();
                    if(view.Glow!=null){view.Glow.range=Mathf.Min(.12f,source.Light.range*scale);view.Glow.intensity=source.Light.intensity*.01f;view.Glow.shadows=LightShadows.None;var cached=source.Lights.FirstOrDefault(l=>l.Light==source.Light);if(cached!=null)view.Glow.cullingMask=cached.LayerMask;view.Glow.color=GameManager.GetColorSwatch((int)ColorType.Green).Light;view.Glow.enabled=false;}
                    foreach(var flare in lightRoot.GetComponentsInChildren<LensFlare>(true)){flare.brightness*=.02f;flare.color=GameManager.GetColorSwatch((int)ColorType.Green).Light;}
                    view.GlowObject=lightRoot;
                }
                foreach(var name in new[]{"DoorLedBezel","DoorLedLens"}){var old=owner.transform.Find(name);if(old!=null)old.gameObject.SetActive(false);}
                fallback.enabled=false;
                Debug.Log("[Modular Switchboards] Native door LED reused: "+source.PrefabName+"; scale="+scale+"; painted slots="+view.Surfaces.Sum(p=>p.Paint.Count(x=>x))+"; tiny native glow.");
            }
            catch(Exception ex){if(nativeRoot!=null)UnityEngine.Object.DestroyImmediate(nativeRoot);Debug.LogWarning("[Modular Switchboards] Native LED copy failed; temporary lens retained: "+ex);}
        }
        private static bool IsLed(WallLight source)
        {
            if(source.PrefabName.IndexOf("LED",StringComparison.OrdinalIgnoreCase)>=0)return true;
            try{return Localization.GetThingName(source.PrefabName).IndexOf("LED",StringComparison.OrdinalIgnoreCase)>=0;}catch(Exception){return false;}
        }
        private static void ReduceEffect(MonoBehaviour effect)
        {
            foreach(var field in effect.GetType().GetFields(BindingFlags.Instance|BindingFlags.Public|BindingFlags.NonPublic))
            {
                if(!field.IsPublic&&!field.IsDefined(typeof(SerializeField),true))continue;
                string name=field.Name.ToLowerInvariant();
                if(name!="size"&&name!="scale"&&name!="intensity"&&name!="brightness")continue;
                try{if(field.FieldType==typeof(float))field.SetValue(effect,(float)field.GetValue(effect)*.04f);
                else if(field.FieldType==typeof(Vector2))field.SetValue(effect,(Vector2)field.GetValue(effect)*.04f);}catch(Exception){}
            }
        }
    }
    [Serializable]
    public sealed class NativeLedSurface{public MeshRenderer Renderer;public bool[] Paint;public Material[] Off,On;}
    public sealed class NativeDoorLedView:MonoBehaviour
    {
        public DinBreaker Owner;public NativeLedSurface[] Surfaces;
        public Light Glow;public GameObject GlowObject;private bool initialized,last;
        private void LateUpdate()
        {
            if(Owner==null||Surfaces==null)return;bool on=!Owner.IsCursor&&Owner.DoorLit;
            if(!initialized||last!=on){foreach(var surface in Surfaces)surface.Renderer.sharedMaterials=on?surface.On:surface.Off;initialized=true;last=on;}
            foreach(var surface in Surfaces)for(int slot=0;slot<surface.Paint.Length;slot++)
            {
                if(!surface.Paint[slot])continue;
                var block=new MaterialPropertyBlock();surface.Renderer.GetPropertyBlock(block,slot);
                block.SetFloat(Thing.DiffuseIndexPropertyID,(int)ColorType.Green);block.SetColor(Thing.EMISSION_COLOR,on?Color.white*.12f:Color.black);surface.Renderer.SetPropertyBlock(block,slot);
            }
            foreach(var hit in Owner.GetComponentsInChildren<Collider>())Thing._colliderLookup[hit]=Owner;
            if(GlowObject!=null)GlowObject.SetActive(on);if(Glow!=null)Glow.enabled=on;
        }
    }
}
