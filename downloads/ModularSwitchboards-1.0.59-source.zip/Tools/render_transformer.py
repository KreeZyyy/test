"""Render the exact production body/front/knob export; no substitute geometry."""
import bpy,json,math,sys
from pathlib import Path
from mathutils import Vector,Matrix
root=Path(__file__).resolve().parents[1]
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
def material(name,rgb,metal=0):
 m=bpy.data.materials.new(name);m.diffuse_color=(*rgb,1);m.use_nodes=True;s=m.node_tree.nodes.get('Principled BSDF');s.inputs['Base Color'].default_value=(*rgb,1);s.inputs['Roughness'].default_value=.65;s.inputs['Metallic'].default_value=metal;return m
body=[material('unused',(.3,.3,.3)),material('White breaker case',(.82,.82,.80)),material('unused2',(.3,.3,.3)),material('Dark breaker fascia',(.09,.11,.11)),material('Gray breaker terminals',(.45,.47,.47))]
face=[material('Breaker fascia palette approximation',(.09,.11,.11)),material('Own dark knob',(.045,.05,.05)),material('Own copper winding',(.43,.19,.085),.4),material('Own winding seat',(.075,.08,.075)),material('Own dial pointer and ticks',(.67,.69,.66))]
atlas=material('Exact exported surface',(1,1,1));nodes=atlas.node_tree.nodes;tex=nodes.new('ShaderNodeTexImage');tex.image=bpy.data.images.load(str(root/'Assets/Transformer/Atlas.png'));atlas.node_tree.links.new(tex.outputs['Color'],nodes.get('Principled BSDF').inputs['Base Color'])
mediumAtlas=material('Original Medium atlas',(1,1,1));nodes=mediumAtlas.node_tree.nodes;tex=nodes.new('ShaderNodeTexImage');tex.image=bpy.data.images.load(str(root/'Assets/Transformer/MediumAtlas.png'));mediumAtlas.node_tree.links.new(tex.outputs['Color'],nodes.get('Principled BSDF').inputs['Base Color'])
medium='--medium' in sys.argv
parts=json.loads((root/('Art/TransformerMediumGeometry.json' if medium else 'Art/TransformerGeometry.json')).read_text())
def to_blender(v):return(-v[0],-v[2],v[1])
for name,part in parts.items():
 v=[Vector(p)for p in part['vertices']]
 if name=='body':v=[Vector((p.x*2.25,p.y*1.35,p.z*1.15))for p in v]
 if name=='dial':
  # Mid setting: native +/-160 degrees maps half range to zero rotation.
  rot=Matrix.Rotation(math.pi/2,4,'X')@Matrix.Rotation(0,4,'Y')
  v=[rot@p+Vector((.02025,.0185,.080683))for p in v]
 if medium and name not in ('body','front') and not name.startswith('medium'):v=[p+Vector((.106,0,0))for p in v]
 if name=='sideCover':v=[p+Vector((0,0,.0105))for p in v]
 if name=='range':v=[p+Vector((0,.004,0))for p in v]
 faces=[];roles=[]
 for role,ids in part['triangles'].items():
  for i in range(0,len(ids),3):faces.append(ids[i:i+3]);roles.append(int(role))
 mesh=bpy.data.meshes.new(name);mesh.from_pydata([to_blender(p)for p in v],[],faces);mesh.update();ob=bpy.data.objects.new(name,mesh);bpy.context.collection.objects.link(ob)
 for m in body if name=='body'else face if name in ('front','frame')else[mediumAtlas] if name.startswith('medium')else[atlas]:mesh.materials.append(m)
 if name.startswith('medium') or name in ('dial','winding','range','sideCover','bands','leads','leadsRight'):
  uv=mesh.uv_layers.new(name='Original UV')
  for poly in mesh.polygons:
   for loop in poly.loop_indices:uv.data[loop].uv=part['uv'][mesh.loops[loop].vertex_index]
 for poly,role in zip(mesh.polygons,roles):poly.material_index=role
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=32;scene.cycles.use_denoising=False;scene.render.film_transparent=True;scene.view_settings.view_transform='Standard';scene.world.color=(.22,.22,.22)
center=Vector(to_blender((.10125 if medium else .06075,0,.038)))
bpy.ops.object.camera_add(location=center+Vector((.12,-.29,.10)));cam=bpy.context.object;cam.data.type='ORTHO';cam.data.ortho_scale=.30 if medium else .215;cam.rotation_euler=(center-cam.location).to_track_quat('-Z','Y').to_euler();scene.camera=cam
for loc,energy in [((.15,-.22,.25),2.8),((-.20,-.08,.10),1.1)]:
 bpy.ops.object.light_add(type='AREA',location=loc);o=bpy.context.object;o.data.energy=energy;o.data.size=.3;o.rotation_euler=(center-o.location).to_track_quat('-Z','Y').to_euler()
scene.render.resolution_percentage=100
for size,path in [(256,root/('Assets/Icons/DinTransformerMedium.png' if medium else 'Assets/Icons/DinTransformer.png')),(720,root.parent/('DinTransformer-Medium-1.0.59-preview.png' if medium else 'DinTransformer-1.0.59-preview.png'))]:
 scene.render.resolution_x=size;scene.render.resolution_y=size;scene.render.filepath=str(path);bpy.ops.render.render(write_still=True)
bpy.ops.wm.save_as_mainfile(filepath=str(root/('Art/DinTransformerMedium.blend' if medium else 'Art/DinTransformer.blend')))
cam.location=center+Vector((0,-.32,0));cam.rotation_euler=(center-cam.location).to_track_quat('-Z','Y').to_euler();scene.render.filepath=str(root.parent/('DinTransformer-Medium-1.0.59-front.png' if medium else 'DinTransformer-1.0.59-front.png'));bpy.ops.render.render(write_still=True)
