using System.Collections.Generic;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class MediumTransformerGeometry
    {
        internal const float KnobShift=.025f;
        internal static readonly float[] WindingCenters={.013f,.064f};
        internal static readonly float[] RibCenters={.1145f,.138f};
        internal static readonly Bounds[] Pockets={new Bounds(new Vector3(.013f,0,.0821f),new Vector3(.04874201f,.065f,.0358f)),new Bounds(new Vector3(.064f,0,.0821f),new Vector3(.04874201f,.065f,.0358f))};
        internal static Mesh Face()
        {
            var v=new List<Vector3>();var n=new List<Vector3>();var t=new List<int>();
            RoundedGeometry.Box(v,n,t,new Vector3(TransformerPanelLayout.PortCenterX(6),0,.0727f),new Vector3(TransformerPanelLayout.WidthFor(6)*DinBreakerModel.VisualScale.x-.010f,.068f,.0018f),.0013f);
            var cut=Finish(v,n,t);foreach(var pocket in Pockets)cut=TransformerCasePocket.Cut(cut,pocket);
            v=new List<Vector3>(cut.vertices);n=new List<Vector3>(cut.normals);t=new List<int>(cut.GetTriangles(0));
            foreach(var b in Pockets)
            {
            float back=.0644f,front=.0736f;
            RoundedGeometry.Box(v,n,t,new Vector3(b.center.x,0,back-.0005f),new Vector3(b.size.x+.001f,b.size.y+.001f,.001f),.0001f);
            foreach(float sign in new[]{-1f,1f})
            {
                RoundedGeometry.Box(v,n,t,new Vector3(b.center.x+sign*(b.size.x*.5f-.00015f),0,(back+front)*.5f),new Vector3(.0003f,b.size.y,front-back),.00002f);
                RoundedGeometry.Box(v,n,t,new Vector3(b.center.x,sign*(b.size.y*.5f-.00005f),(back+front)*.5f),new Vector3(b.size.x,.0001f,front-back),.00002f);
            }
            }
            var mesh=Finish(v,n,t);CabinetGeometry.ApplyNativeUv(mesh);return mesh;
        }
        private static Mesh Finish(List<Vector3> v,List<Vector3> n,List<int> t)
        {var mesh=new Mesh{name="Switchboards.MediumTransformerFace"};mesh.SetVertices(v);mesh.SetNormals(n);mesh.subMeshCount=5;for(int i=0;i<5;i++)mesh.SetTriangles(i==0?t:new List<int>(),i);mesh.RecalculateBounds();return mesh;}
    }
}
