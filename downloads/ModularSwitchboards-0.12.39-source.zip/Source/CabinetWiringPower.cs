using System;
using System.Collections.Generic;
using System.Linq;
using Assets.Scripts.Networks;
using Assets.Scripts.Objects.Pipes;

namespace ModularSwitchboards
{
    internal sealed class CabinetWiringPower
    {
        private sealed class Snapshot
        {
            internal CableNetwork Input,First,Second;
            internal float FirstBudget,SecondBudget;
            internal long[] FirstModules=new long[0],SecondModules=new long[0];
            internal Dictionary<long,float> Limits=new Dictionary<long,float>();
        }
        private volatile Snapshot state=new Snapshot();
        private readonly object gate=new object();
        private float debt,firstActual,secondActual;
        private readonly HashSet<long> trips=new HashSet<long>();
        internal void ObserveIdle(CableNetwork network){lock(gate){if(ReferenceEquals(network,state.First))firstActual=0;if(ReferenceEquals(network,state.Second))secondActual=0;}}
        internal long[] DrainTrips(){lock(gate){var result=trips.ToArray();trips.Clear();return result;}}
        internal void Refresh(SwitchboardCabinet owner,IList<CabinetWireSaveData> wires,IEnumerable<DinBreaker> breakers)
        {
            var next=new Snapshot();
            if(owner.IsStructureCompleted&&!owner.IsCursor&&owner.GridController!=null)
            {
                next.Input=owner.InputConnection?.GetCable()?.CableNetwork;
                var modules=breakers.Where(b=>b.Conducting).ToArray();
                var closed=modules.Select(b=>b.ReferenceId).ToArray();
                var source=new CabinetWireEnd(0,0);
                if(WireCircuit.Reachable(source,new CabinetWireEnd(0,1),wires,closed))next.First=owner.Output1Connection?.GetCable()?.CableNetwork;
                if(WireCircuit.Reachable(source,new CabinetWireEnd(0,2),wires,closed))next.Second=owner.Output2Connection?.GetCable()?.CableNetwork;
                next.FirstModules=modules.Where(b=>WireCircuit.Reachable(source,new CabinetWireEnd(b.ReferenceId,0),wires,closed)&&WireCircuit.Reachable(new CabinetWireEnd(b.ReferenceId,1),new CabinetWireEnd(0,1),wires,closed)).Select(b=>b.ReferenceId).ToArray();
                next.SecondModules=modules.Where(b=>WireCircuit.Reachable(source,new CabinetWireEnd(b.ReferenceId,0),wires,closed)&&WireCircuit.Reachable(new CabinetWireEnd(b.ReferenceId,1),new CabinetWireEnd(0,2),wires,closed)).Select(b=>b.ReferenceId).ToArray();
                next.Limits=modules.ToDictionary(b=>b.ReferenceId,b=>b.RatedWatts);
                // An external cable loop is not another power source.
                if(next.First==next.Input)next.First=null;if(next.Second==next.Input)next.Second=null;
                if(next.Second==next.First)next.Second=null;
            }
            var allocation=WireCircuit.Allocate(next.Input?.PotentialLoad??0,next.First?.RequiredLoad??0,next.Second?.RequiredLoad??0,next.First!=null,next.Second!=null);
            next.FirstBudget=allocation[0];next.SecondBudget=allocation[1];
            lock(gate){if(next.First!=state.First||(next.First?.RequiredLoad??0)<=0||!next.FirstModules.SequenceEqual(state.FirstModules))firstActual=0;if(next.Second!=state.Second||(next.Second?.RequiredLoad??0)<=0||!next.SecondModules.SequenceEqual(state.SecondModules))secondActual=0;state=next;}
        }
        internal float Generated(CableNetwork network)
        {
            var s=state;if(s.Input==null||network==null)return 0;
            bool first=ReferenceEquals(network,s.First),second=ReferenceEquals(network,s.Second);if(!first&&!second)return 0;
            return first?s.FirstBudget:s.SecondBudget;
        }
        internal float Used(CableNetwork network){if(!ReferenceEquals(network,state.Input)||network==null)return 0;lock(gate)return debt;}
        internal void Use(CableNetwork network,float value)
        {
            if(network==null)return;
            // A provider tick can finish after the switch opened. Charge that completed
            // transfer too; the current path only controls future generation.
            // Native Transformer uses the same consumption/repayment contract.
            lock(gate)
            {
                value=WireCircuit.Finite(value);debt=Math.Min(float.MaxValue/2,debt+value);
                var s=state;
                if(ReferenceEquals(network,s.First))firstActual=value;
                else if(ReferenceEquals(network,s.Second))secondActual=value;
                else return;
                foreach(var limit in s.Limits)
                {
                    float load=(s.FirstModules.Contains(limit.Key)?firstActual:0)+(s.SecondModules.Contains(limit.Key)?secondActual:0);
                    if(load>limit.Value)trips.Add(limit.Key);
                }
            }
        }
        internal void Receive(CableNetwork network,float value){if(network==null||!ReferenceEquals(network,state.Input))return;lock(gate)debt=Math.Max(0,debt-WireCircuit.Finite(value));}
        internal bool AllowsPower(CableNetwork network)=>network!=null&&ReferenceEquals(network,state.Input);
        internal bool IsProviderTo(Device self,Device other,ref List<long> visited)
        {
            var input=state.Input;if(other==null||input?.PowerTick?.InputOutputDevices==null||visited.Contains(self.ReferenceId))return false;
            visited.Add(self.ReferenceId);var providers=input.PowerTick.InputOutputDevices;
            if(providers.Any(p=>p?.Device==other))return true;
            foreach(var provider in providers){if(provider?.Device==null)continue;if(visited.Count>=Device.MaxProviderRecursionIterations)return false;if(provider.Device.IsProviderToDevice(other,ref visited))return true;}return false;
        }
    }
}
