using System.Linq;
using Assets.Scripts.Objects;
using UnityEngine;
using Rendering;
using Assets.Scripts.UI;

namespace ModularSwitchboards
{
    internal static class DinModuleAccess
    {
        internal static bool CanEnter(Thing __instance,Slot destinationSlot,ref CanEnterResult __result)
        {
            if(!(destinationSlot?.Parent is DinBreaker module)||!module.IsFuseHolder)return true;
            if((!LibConstruct.PlacementBoard.Loading&&(!(module.Board?.PrimaryHost is DinRail rail)||!rail.CanFitModules))||!(__instance is MultiConstructor kit)||kit.Quantity!=1||!module.AllowedFuseKits.Contains(kit.PrefabHash))
            {__result=CanEnterResult.Fail("Open the cabinet and insert one unit of the matching Cable Fuse kit.");return false;}
            return true;
        }
        internal static void Install(DinBreaker module)
        {
            var model=module.transform.Find("DinBreakerModel");
            if(module.IsFuseHolder)
            {
                var view=module.GetComponent<BreakerSwitchView>();if(view!=null)Object.DestroyImmediate(view);
                var lever=model.Find("BreakerLever");if(lever!=null)Object.DestroyImmediate(lever.gameObject);
                var control=model.Find("BreakerControl");var hit=control.GetComponent<BoxCollider>();
                var door=new GameObject("FuseCartridge"){layer=module.gameObject.layer};door.transform.SetParent(model,false);
                door.AddComponent<MeshFilter>().sharedMesh=DinBreakerModel.ControlMesh("FuseCartridge",new Vector3(0,0,.070f),new Vector3(.013f,.035f,.005f));
                door.AddComponent<MeshRenderer>().sharedMaterials=CabinetGeometry.Materials;
                var ghost=module.Blueprint.GetComponent<MeshFilter>().sharedMesh;
                var pieces=new System.Collections.Generic.List<CombineInstance>();var body=model.GetComponent<MeshFilter>().sharedMesh;
                foreach(int role in new[]{1,3,4})pieces.Add(new CombineInstance{mesh=body,subMeshIndex=role,transform=Matrix4x4.Scale(model.localScale)});
                pieces.Add(new CombineInstance{mesh=door.GetComponent<MeshFilter>().sharedMesh,subMeshIndex=0,transform=Matrix4x4.Scale(model.localScale)});
                ghost.Clear();ghost.CombineMeshes(pieces.ToArray(),true,true);ghost.RecalculateBounds();
                var wire=module.Blueprint.GetComponent<Wireframe>();wire.BlueprintBounds=ghost.bounds;
                var toggle=new Interactable{Parent=module,Action=InteractableType.Slot1,Collider=hit,JoinInProgressSync=true,CanKeyInteract=true,KeyMap="PrimaryAction"};
                var location=new GameObject("FuseContents").transform;location.SetParent(model,false);location.localPosition=new Vector3(0,0,.07f);
                module.Slots=new System.Collections.Generic.List<Slot>{new Slot{Parent=module,StringKey="Cable Fuse",Type=Slot.Class.None,SpecificTypePrefabHashes=module.AllowedFuseKits,
                    Location=location,HidesOccupant=true,IsSwappable=false,Action=InteractableType.Slot1,Collider=hit,Interactable=toggle}};
                module.Interactables=new System.Collections.Generic.List<Interactable>{toggle};module.HasOnOffState=false;
                module.BuildStates[0].Interactables=new System.Collections.Generic.List<Interactable>{toggle};
            }
            var plate=new GameObject("ModuleRatingPlate"){layer=module.gameObject.layer};plate.transform.SetParent(model,false);
            plate.AddComponent<MeshFilter>().sharedMesh=DinBreakerModel.ControlMesh("ModuleRatingPlate",new Vector3(0,.022f,.092f),new Vector3(.017f,.010f,.0008f));
            plate.AddComponent<MeshRenderer>().sharedMaterials=CabinetGeometry.Materials;
            var labelObject=new GameObject("ModuleRating"){layer=module.gameObject.layer};labelObject.transform.SetParent(model,false);
            labelObject.transform.localPosition=new Vector3(0,.022f,.0925f);labelObject.transform.localRotation=Quaternion.Euler(0,180,0);
            Font font=null;foreach(var name in new[]{"LegacyRuntime.ttf","Arial.ttf"}){try{font=Resources.GetBuiltinResource<Font>(name);}catch(System.Exception){}if(font!=null)break;}
            if(font==null)font=Resources.FindObjectsOfTypeAll<Font>().FirstOrDefault();
            if(font==null){Object.DestroyImmediate(labelObject);return;}
            labelObject.tag="ExcludeFromBounds";
            var text=labelObject.AddComponent<TextMesh>();text.font=font;text.text="";text.fontSize=96;text.characterSize=.01f;
            text.anchor=TextAnchor.MiddleCenter;text.alignment=TextAlignment.Center;text.color=Color.black;
            labelObject.GetComponent<MeshRenderer>().sharedMaterial=text.font.material;
            var label=module.gameObject.AddComponent<DinModuleLabel>();label.Owner=module;label.Text=text;
        }
    }
    public sealed class DinModuleLabel:MonoBehaviour
    {
        public DinBreaker Owner;public TextMesh Text;
        private string previous;
        private void LateUpdate()
        {
            if(Owner==null||Text==null)return;
            string value=(Owner.IsFuseHolder?(Owner.Conducting?"FUSE":Owner.Tripped?"BLOWN":"EMPTY"):Owner.Tripped?"TRIP":"CB")+"\n"+DinModuleCatalog.Rating(Owner.RatedWatts);
            if(value!=previous){Text.text=value;previous=value;var bounds=Text.GetComponent<MeshRenderer>().localBounds.size;Text.transform.localScale=Vector3.one*Mathf.Min(.015f/Mathf.Max(bounds.x,.0001f),.008f/Mathf.Max(bounds.y,.0001f));}
            var cabinet=CabinetWiring.CabinetOf(Owner);var renderer=Text.GetComponent<MeshRenderer>();
            bool visible=!Owner.IsCursor&&cabinet!=null&&cabinet.IsOpen;var camera=Camera.main;
            if(visible&&camera!=null){var delta=Text.transform.position-camera.transform.position;visible=Vector3.Dot(Owner.transform.forward,-delta)>0&&!Physics.Raycast(camera.transform.position,delta.normalized,delta.magnitude-.001f,Physics.DefaultRaycastLayers,QueryTriggerInteraction.Ignore);}
            renderer.enabled=visible;
            var indicator=Owner.transform.Find("DinBreakerModel/BreakerIndicator")?.GetComponent<MeshRenderer>();
            if(indicator!=null){var block=new MaterialPropertyBlock();block.SetFloat(Thing.DiffuseIndexPropertyID,BreakerSwitchPose.IndicatorColor(Owner.Conducting));indicator.SetPropertyBlock(block);}
        }
    }
}
