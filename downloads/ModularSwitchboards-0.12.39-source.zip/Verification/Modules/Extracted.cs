using System.Linq;using Assets.Scripts.Objects;using Assets.Scripts;using Assets.Scripts.Networking;using System.Xml.Serialization;using LibConstruct;
namespace ModularSwitchboards {
    public sealed class DinBreakerSaveData : StructureSaveData
    {
        [XmlElement] public PlacementBoardStructureSaveData RailBoard;
        [XmlElement] public bool Tripped;
    }


partial class DinBreaker {
        internal void Trip()
        {
            if(!GameManager.RunSimulation||!Conducting)return;
            if(IsFuseHolder){var kit=Slots[0].Get() as MultiConstructor;if(kit!=null)kit.RemoveQuantity(1);}
            else {OnOff=false;}
            Tripped=true;NetworkUpdateFlags|=ModuleUpdate;
        }
        public override void BuildUpdate(RocketBinaryWriter writer,ushort flags){base.BuildUpdate(writer,flags);if(Thing.IsNetworkUpdateRequired(ModuleUpdate,flags)){writer.WriteBoolean(Tripped);writer.WriteBoolean(!IsFuseHolder&&OnOff);}}
        public override void ProcessUpdate(RocketBinaryReader reader,ushort flags){base.ProcessUpdate(reader,flags);if(Thing.IsNetworkUpdateRequired(ModuleUpdate,flags)){Tripped=reader.ReadBoolean();bool on=reader.ReadBoolean();if(!IsFuseHolder)OnOff=on;}}
        public override ThingSaveData SerializeSave()
        {
            ThingSaveData data = new DinBreakerSaveData();
            InitialiseSaveData(ref data);
            return data;
        }
        protected override void InitialiseSaveData(ref ThingSaveData data)
        {
            base.InitialiseSaveData(ref data);
            if (data is DinBreakerSaveData save){save.Tripped=Tripped;if(Board!=null)save.RailBoard=BoardStructureHooks.SerializeSave(this);}
        }
        public override void DeserializeSave(ThingSaveData data)
        {
            base.DeserializeSave(data);
            if (data is DinBreakerSaveData save){Tripped=save.Tripped;if(save.RailBoard!=null)BoardStructureHooks.DeserializeSave(this,save.RailBoard);}
        }
        public override void SerializeOnJoin(RocketBinaryWriter writer)
        {
            base.SerializeOnJoin(writer);
            BoardStructureHooks.SerializeOnJoin(writer, this);writer.WriteBoolean(Tripped);
        }
        public override void DeserializeOnJoin(RocketBinaryReader reader)
        {
            base.DeserializeOnJoin(reader);
            BoardStructureHooks.DeserializeOnJoin(reader, this);Tripped=reader.ReadBoolean();
        }

}
static class DinModuleAccess {
        internal static bool CanEnter(Thing __instance,Slot destinationSlot,ref CanEnterResult __result)
        {
            if(!(destinationSlot?.Parent is DinBreaker module)||!module.IsFuseHolder)return true;
            if((!LibConstruct.PlacementBoard.Loading&&(!(module.Board?.PrimaryHost is DinRail rail)||!rail.CanFitModules))||!(__instance is MultiConstructor kit)||kit.Quantity!=1||!module.AllowedFuseKits.Contains(kit.PrefabHash))
            {__result=CanEnterResult.Fail("Open the cabinet and insert one unit of the matching Cable Fuse kit.");return false;}
            return true;
        }

}}