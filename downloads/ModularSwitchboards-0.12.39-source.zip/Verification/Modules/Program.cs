using System;
using System.Linq;
using System.Collections.Generic;
using System.IO;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Electrical;
using Assets.Scripts;
using Assets.Scripts.Networking;
using ModularSwitchboards;
namespace LibConstruct{static class PlacementBoard{public static bool Loading;}public class PlacementBoardStructureSaveData{public int Row;}static class BoardStructureHooks{public static PlacementBoardStructureSaveData SerializeSave(DinBreaker m)=>new(){Row=m.Board.Row};public static void DeserializeSave(DinBreaker m,PlacementBoardStructureSaveData d){m.Board=new(){Row=d.Row};}public static void SerializeOnJoin(RocketBinaryWriter w,DinBreaker m)=>w.WriteInt32(m.Board?.Row??0);public static void DeserializeOnJoin(RocketBinaryReader r,DinBreaker m){m.Board=new(){Row=r.ReadInt32()};}}}
namespace Assets.Scripts {static class GameManager{public static bool RunSimulation=true;}}
namespace Assets.Scripts.Objects{
 public class ThingSaveData{public bool OnOff;} public class StructureSaveData:ThingSaveData{}
 class Thing {public virtual ThingSaveData SerializeSave()=>new StructureSaveData();protected virtual void InitialiseSaveData(ref ThingSaveData d){d.OnOff=((DinBreaker)this).OnOff;}public virtual void DeserializeSave(ThingSaveData d){((DinBreaker)this).OnOff=d.OnOff;}public virtual void SerializeOnJoin(RocketBinaryWriter w)=>w.WriteBoolean(((DinBreaker)this).OnOff);public virtual void DeserializeOnJoin(RocketBinaryReader r){((DinBreaker)this).OnOff=r.ReadBoolean();}public int PrefabHash;public static bool IsNetworkUpdateRequired(uint flag,ushort flags)=>(flag&flags)!=0;public virtual void BuildUpdate(RocketBinaryWriter w,ushort f){}public virtual void ProcessUpdate(RocketBinaryReader r,ushort f){}}
 class Structure:Thing{}
 class MultiConstructor:Thing{public float Quantity=1;public int Removed;public List<Structure> Constructables=new();public void RemoveQuantity(int n){Removed+=n;Quantity-=n;}}
 class Slot{public Thing Parent;public Thing Item;public Thing Get()=>Item;}
 struct CanEnterResult{public bool Valid;public static CanEnterResult Fail(string reason)=>new(){Valid=false};}
}
namespace Assets.Scripts.Objects.Electrical {class CableFuse:Structure{public float PowerBreak;}}
namespace Assets.Scripts.Networking {
 class RocketBinaryWriter {readonly BinaryWriter w;public RocketBinaryWriter(Stream s){w=new(s);}public void WriteBoolean(bool b)=>w.Write(b);public void WriteInt32(int n)=>w.Write(n);}
 class RocketBinaryReader {readonly BinaryReader r;public RocketBinaryReader(Stream s){r=new(s);}public bool ReadBoolean()=>r.ReadBoolean();public int ReadInt32()=>r.ReadInt32();}
}
namespace ModularSwitchboards{
 static class SwitchboardsMod{public const string BreakerName="StructureDinBreaker1P";}
 class Board{public int Row;public object PrimaryHost;}
 class DinRail{public bool CanFitModules=true;}
 partial class DinBreaker:Thing{
  public bool IsFuseHolder,OnOff,Tripped;public ushort NetworkUpdateFlags;const ushort ModuleUpdate=32768;
  public int[] AllowedFuseKits=Array.Empty<int>();public Board Board=new(){PrimaryHost=new DinRail()};public List<Slot> Slots=new();
  public bool Conducting=>IsFuseHolder?!Tripped&&Slots.Count==1&&Slots[0].Get() is MultiConstructor kit&&kit.Quantity==1&&AllowedFuseKits.Contains(kit.PrefabHash):OnOff;
 }
}
static class Program{
 static int count;static void Check(bool ok,string msg){count++;if(!ok)throw new Exception(msg);}
 static void Main(){
  var f4=new CableFuse{PowerBreak=4000};var f100=new CableFuse{PowerBreak=100000};var kit=new MultiConstructor{PrefabHash=17,Constructables=new(){f4,f100}};
  var specs=DinModuleCatalog.Discover(new Thing[]{f4,f100,kit});Check(specs.Count==5,"Variant count");Check(specs.Count(s=>s.Fuse)==2,"Fuse variants");Check(specs[0].Name==SwitchboardsMod.BreakerName,"Legacy prefab identity lost");Check(specs.Where(s=>s.Fuse).All(s=>s.FuseKits.SequenceEqual(new[]{17})),"Fuse kit match wrong");Check(specs.Select(s=>s.Name).Distinct().Count()==5,"Duplicate prefabs");Check(specs.Any(s=>!s.Fuse&&s.Watts==20000),"Intermediate breaker missing");Check(DinModuleCatalog.Rating(4000)=="4 kW","Power label");
  bool rejected=false;try{DinModuleCatalog.Discover(new Thing[]{f4});}catch(InvalidOperationException){rejected=true;}Check(rejected,"Missing native fuse kit accepted");
  var breaker=new DinBreaker{OnOff=true};breaker.Trip();Check(!breaker.OnOff&&breaker.Tripped&&breaker.NetworkUpdateFlags==32768,"Breaker didn't trip with sync flag");breaker.OnOff=true;GameManager.RunSimulation=false;breaker.Trip();Check(breaker.OnOff,"Client mutation");GameManager.RunSimulation=true;
  var holder=new DinBreaker{IsFuseHolder=true,AllowedFuseKits=new[]{17}};holder.Slots.Add(new(){Parent=holder,Item=kit});var result=new CanEnterResult();Check(DinModuleAccess.CanEnter(kit,holder.Slots[0],ref result),"Valid fuse rejected");kit.Quantity=2;Check(!DinModuleAccess.CanEnter(kit,holder.Slots[0],ref result),"Whole stack admitted");kit.Quantity=1;((DinRail)holder.Board.PrimaryHost).CanFitModules=false;Check(!DinModuleAccess.CanEnter(kit,holder.Slots[0],ref result),"Closed cabinet admitted fuse");LibConstruct.PlacementBoard.Loading=true;Check(DinModuleAccess.CanEnter(kit,holder.Slots[0],ref result),"Saved fuse rejected during board restore");LibConstruct.PlacementBoard.Loading=false;((DinRail)holder.Board.PrimaryHost).CanFitModules=true;
  Check(!DinModuleAccess.CanEnter(new MultiConstructor{PrefabHash=99},holder.Slots[0],ref result),"Wrong kit accepted");holder.Trip();Check(kit.Removed==1&&!holder.Conducting&&holder.Tripped,"Fuse didn't consume one cartridge");holder.Trip();Check(kit.Removed==1,"Repeated trip consumed another cartridge");
  foreach(ushort flags in new ushort[]{0,64,32768,65535}){using var stream=new MemoryStream();breaker.OnOff=true;breaker.Tripped=false;breaker.BuildUpdate(new(stream),flags);stream.Position=0;var peer=new DinBreaker();peer.ProcessUpdate(new(stream),flags);Check(stream.Position==stream.Length,"Update framing");Check(peer.OnOff==((flags&32768)!=0),"Trip/reset state not synchronized");}
  breaker.OnOff=false;breaker.Tripped=true;breaker.Board.Row=60;var data=(DinBreakerSaveData)breaker.SerializeSave();var xml=new System.Xml.Serialization.XmlSerializer(typeof(DinBreakerSaveData));using var text=new StringWriter();xml.Serialize(text,data);var saved=(DinBreakerSaveData)xml.Deserialize(new StringReader(text.ToString()));var restored=new DinBreaker();restored.DeserializeSave(saved);Check(restored.Tripped&&!restored.OnOff&&restored.Board.Row==60,"Save/restore trip and board state");
  using(var stream=new MemoryStream()){breaker.SerializeOnJoin(new(stream));stream.Position=0;restored=new();restored.DeserializeOnJoin(new(stream));Check(restored.Tripped&&!restored.OnOff&&restored.Board.Row==60&&stream.Position==stream.Length,"Join/restore trip and board framing");}
  Console.WriteLine($"Production DIN module catalog, insertion policy, trip mutation and update serialization passed {count} checks.");
 }
}
