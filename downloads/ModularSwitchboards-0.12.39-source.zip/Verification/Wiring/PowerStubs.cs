using System.Collections.Generic;
namespace Assets.Scripts.Networks{public class CableNetwork{public float PotentialLoad,RequiredLoad;public PowerTick PowerTick=new();}public class PowerTick{public PowerProvider[] InputOutputDevices=new PowerProvider[0];}public class PowerProvider{public Assets.Scripts.Objects.Pipes.Device Device;}}
namespace Assets.Scripts.Objects.Pipes{public class Device{public long ReferenceId;public const int MaxProviderRecursionIterations=64;public virtual bool IsProviderToDevice(Device device,ref List<long> visited)=>false;}}
namespace ModularSwitchboards
{
 public class StubCable{public Assets.Scripts.Networks.CableNetwork CableNetwork;}
 public class StubConnection{public StubCable cable=new();public StubCable GetCable()=>cable;}
 public class SwitchboardCabinet{public bool IsStructureCompleted=true,IsCursor;public object GridController=new();public StubConnection InputConnection=new(),Output1Connection=new(),Output2Connection=new();}
 public class DinBreaker{public bool OnOff,IsBeingDestroyed,IsFuseHolder,FusePresent;public float RatedWatts=4000f;public bool Conducting=>!IsBeingDestroyed&&(IsFuseHolder?FusePresent:OnOff);public long ReferenceId;}
}
