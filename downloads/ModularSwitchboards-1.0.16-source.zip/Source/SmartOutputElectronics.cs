using System;
using System.Collections.Generic;
using System.Linq;
using Assets.Scripts;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Structures;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class SmartOutputElectronics
    {
        private static readonly HashSet<string> Exported=new HashSet<string>();
        // A visual insert only: never instantiate a vending machine, slots or logic.
        internal static void Install(Transform model,int layer)
        {
            try{if(TryNative(model,layer))return;}
            catch(Exception ex){Debug.LogWarning("[Modular Switchboards] NET reference/visual unavailable; retaining authored panel: "+ex);}
            InstallAuthored(model,layer);
        }
        private static bool TryNative(Transform model,int layer)
        {
            var prefabs=WorldManager.Instance?.SourcePrefabs;
            if(prefabs==null)return false;
            // The kit is listed before the built machine. Export the structure,
            // including constructables reached through its kit, never ItemKitVendingMachine.
            var structures=prefabs.OfType<Structure>().Concat(prefabs.OfType<MultiConstructor>().Where(k=>k!=null).SelectMany(k=>k.Constructables??new List<Structure>()));
            var machines=VendingSelection.Select(structures);
            foreach(var machine in machines)
            {
                if(Exported.Contains(machine.PrefabName))continue;
                try{ApcWarning.ExportReference(machine,machine.PrefabName+"-NET-reference.json");Exported.Add(machine.PrefabName);}
                catch(Exception ex){Debug.LogWarning("[Modular Switchboards] Vending reference export failed for "+machine.PrefabName+": "+ex.Message);}
            }
            var source=machines.FirstOrDefault(p=>p.PrefabName=="StructureVendingMachine")??machines.FirstOrDefault();
            if(source!=null)
            {
                var candidates=source.GetComponentsInChildren<MeshRenderer>(true).Where(r=>r!=null&&r.GetComponent<MeshFilter>()?.sharedMesh!=null&&
                    new[]{"circuit","pcb","electronics"}.Any(n=>r.name.IndexOf(n,StringComparison.OrdinalIgnoreCase)>=0)).ToArray();
                // Only a clearly isolated electronics insert is safe to reuse.
                if(candidates.Length==1)
                {
                    var original=candidates[0];var mesh=original.GetComponent<MeshFilter>().sharedMesh;var b=mesh.bounds;
                    if(b.size.x>0&&b.size.y>0&&b.size.z<Mathf.Max(b.size.x,b.size.y)*.5f)
                    {
                        var go=new GameObject("NativeVendingElectronics"){layer=layer};go.transform.SetParent(model,false);
                        float fit=Mathf.Min(.012f/b.size.x,.035f/b.size.y);
                        go.transform.localScale=Vector3.one*fit*.85f;go.transform.localPosition=new Vector3(0,-.005f,.0645f)-b.center*fit*.85f;
                        go.AddComponent<MeshFilter>().sharedMesh=mesh;NativePortSurface.Capture(original,go.AddComponent<MeshRenderer>());
                        Debug.Log("[Modular Switchboards] NET: isolated vending electronics insert reused: "+original.name);return true;
                    }
                }
                try{ApcWarning.ExportReference(source,"VendingMachine-NET-reference.json");}
                catch(Exception ex){Debug.LogWarning("[Modular Switchboards] Vending reference export failed: "+ex.Message);}
            }
            return false;
        }
        private static void InstallAuthored(Transform model,int layer)
        {
            // Combined native meshes need an inspected crop; use a self-contained
            // insert meanwhile, never guess a crop that could include the whole machine.
            Debug.LogWarning("[Modular Switchboards] NET: isolated vending insert unavailable; using authored electronics panel. Vending reference exported when available.");
            var v=new List<Vector3>();var nrm=new List<Vector3>();var groups=new List<int>[3];for(int i=0;i<3;i++)groups[i]=new List<int>();
            Action<int,Vector3,Vector3,float> box=(role,c,s,r)=>RoundedGeometry.Box(v,nrm,groups[role],c,s,r);
            box(0,new Vector3(0,-.004f,.0645f),new Vector3(.012f,.034f,.0007f),.00035f);
            box(1,new Vector3(0,.006f,.0653f),new Vector3(.0093f,.011f,.0009f),.0003f);
            for(int i=0;i<7;i++)foreach(float side in new[]{-1f,1f})
                box(2,new Vector3(-.004f+i*.0013f,.006f+side*.0064f,.0652f),new Vector3(.00065f,.0018f,.0005f),.00008f);
            box(1,new Vector3(.002f,-.012f,.0652f),new Vector3(.0044f,.0054f,.0008f),.00015f);
            for(int i=0;i<4;i++)foreach(float side in new[]{-1f,1f})
                box(2,new Vector3(.002f+side*.0026f,-.0138f+i*.0012f,.06515f),new Vector3(.001f,.0006f,.0004f),.00007f);
            foreach(float y in new[]{-.010f,-.014f})box(2,new Vector3(-.0035f,y,.0652f),new Vector3(.0018f,.0021f,.001f),.00025f);
            var mesh2=new Mesh{name="Smart.Output.ElectronicsInsert"};mesh2.SetVertices(v);mesh2.SetNormals(nrm);mesh2.subMeshCount=3;
            for(int i=0;i<3;i++)mesh2.SetTriangles(groups[i],i);mesh2.RecalculateBounds();
            var root=new GameObject("SmartOutputElectronics"){layer=layer};root.transform.SetParent(model,false);root.transform.localScale=new Vector3(.85f,.85f,1f);root.transform.localPosition=new Vector3(0,-.003f,0);root.AddComponent<MeshFilter>().sharedMesh=mesh2;
            root.AddComponent<MeshRenderer>().sharedMaterials=new[]{Material("PCB",new Color(.075f,.19f,.085f)),Material("Chip",new Color(.025f,.029f,.028f)),Material("Contacts",new Color(.48f,.5f,.46f))};
        }
        internal static Material Material(string name,Color color)
        {
            var shader=Shader.Find("Standard");if(shader==null||!shader.isSupported)throw new InvalidOperationException("NET panel shader unavailable");
            var m=new Material(shader){name="Switchboards.NET."+name,color=color};CabinetMatteSurface.Configure(m);return m;
        }
    }
}
