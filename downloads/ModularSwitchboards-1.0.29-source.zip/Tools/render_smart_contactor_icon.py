"""Render Smart Output body and screw from the production geometry test export."""
import bpy,json,math
from pathlib import Path
from mathutils import Vector
root=Path(__file__).resolve().parents[1]
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
def material(name,color,emission=0):
 m=bpy.data.materials.new(name);m.diffuse_color=(*color,1);m.use_nodes=True;n=m.node_tree.nodes.get('Principled BSDF');n.inputs['Base Color'].default_value=(*color,1);n.inputs['Roughness'].default_value=.85
 if emission:n.inputs['Emission Color'].default_value=(*color,1);n.inputs['Emission Strength'].default_value=emission
 return m
white=material('Paintable body',(.78,.81,.80));black=material('Protected dark fascia',(.035,.035,.035));gray=material('Gray fittings',(.27,.29,.29));green=material('Green LED',(.04,1,.08),1.4)
palette=[gray,white,gray,black,gray]
def point(p):return(-p[0]*2.25,-p[2]*1.15,p[1]*1.35)
parts=json.loads((root/'Art/SmartOutputGeometry.json').read_text())
for name,part in parts.items():
 vertices=[point(p)for p in part['vertices']];faces=[];roles=[]
 for role,indices in part['triangles'].items():
  for i in range(0,len(indices),3):faces.append(indices[i:i+3]);roles.append(int(role))
 mesh=bpy.data.meshes.new(name);mesh.from_pydata(vertices,[],faces);mesh.update();ob=bpy.data.objects.new(name,mesh);bpy.context.collection.objects.link(ob)
 for m in (palette if name=='body'else[gray]):mesh.materials.append(m)
 for polygon,role in zip(mesh.polygons,roles):polygon.material_index=role if name=='body'else 0
centerX=.009
bpy.ops.mesh.primitive_uv_sphere_add(segments=20,ring_count=12,location=point((centerX,.017,.0641)));ob=bpy.context.object;ob.name='Output energized';ob.scale=(.003,.0008,.003);ob.data.materials.append(green)
# Thumbnail illustration of the native LED glyphs used dynamically in-game.
patterns=['00001/00001/01111/10001/10001/10001/01111','01110/10001/10011/10101/11001/10001/01110']
pixel=.00225
for k,pattern in enumerate(patterns):
 for row,line in enumerate(pattern.split('/')):
  for col,on in enumerate(line):
   if on!='1':continue
   u=(k*6+col-5)*pixel;v=(3-row)*pixel
   bpy.ops.mesh.primitive_cube_add(size=1,location=point((centerX-u/2.25,.001+v/1.35,.0649)))
   ob=bpy.context.object;ob.dimensions=(pixel*.8,.0003,pixel*.8);ob.data.materials.append(green)
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=32;scene.cycles.use_denoising=False;scene.render.film_transparent=True;scene.view_settings.view_transform='Standard';scene.world.color=(.22,.22,.22)
center=Vector(point((centerX,0,.031)));bpy.ops.object.camera_add(location=center+Vector((.09,-.31,.08)));cam=bpy.context.object;cam.rotation_euler=(center-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=.145;scene.camera=cam
for pos,power in [((.15,-.22,.25),2.5),((-.20,-.08,.10),.8)]:
 bpy.ops.object.light_add(type='AREA',location=pos);ob=bpy.context.object;ob.data.energy=power;ob.data.size=.35;ob.rotation_euler=(center-ob.location).to_track_quat('-Z','Y').to_euler()
scene.render.resolution_percentage=100
for size,path in [(256,root/'Assets/Icons/DinSmartContactor.png'),(640,root.parent/'SmartOutput-1.0.29-preview.png')]:
 scene.render.resolution_x=size;scene.render.resolution_y=size;scene.render.filepath=str(path);bpy.ops.render.render(write_still=True)
