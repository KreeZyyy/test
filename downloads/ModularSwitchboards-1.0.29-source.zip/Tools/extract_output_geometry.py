from pathlib import Path
r=Path(__file__).resolve().parents[1];p=r/'Source/SmartContactorModel.cs';s=p.read_text()
def method(s,marker):
 a=s.index(marker);b=s.index('{',a);end=b+1;level=1
 while level:
  level+=(s[end]=='{')-(s[end]=='}');end+=1
 return s[a:end]
out=r/'Verification/SmartOutputGeometry';out.mkdir(exist_ok=True)
base=(r/'Verification/FuseGeometry/Program.cs').read_text();a=base.index('namespace UnityEngine');b=base.index('namespace Assets.Scripts.Objects');stubs=base[a:b]
stubs=stubs.replace('public struct Vector2{','public class Object{public static void DestroyImmediate(object value){}}\n public struct Vector2{public static Vector2 operator +(Vector2 a,Vector2 b)=>new(a.x+b.x,a.y+b.y);public static Vector2 operator -(Vector2 a,Vector2 b)=>new(a.x-b.x,a.y-b.y);public static Vector2 operator *(Vector2 a,float b)=>new(a.x*b,a.y*b);')
(out/'Stubs.cs').write_text('using System;using System.Linq;using System.Collections.Generic;'+stubs+'''namespace ModularSwitchboards{static class CabinetGeometry{internal static void ApplyNativeUv(UnityEngine.Mesh m){}}static class SmartContactor{internal const int SlotCount=2;internal static float CenterX=>.009f;internal static float BodyWidth=>.0356f;}static class ApcBatteryRegion{internal const float SocketHeight=.026f;}}''')
bodySource=(r/'Source/DinBreakerModel.cs').read_text();geom='using System;using System.Linq;using System.Collections.Generic;using UnityEngine;namespace ModularSwitchboards{static class DinBreakerModel{internal static Vector3 VisualScale=new(2.25f,1.35f,1.15f);'+method(bodySource,'internal static Mesh Build(')+method(bodySource,'private static void EndDisk(')+'} static class SmartContactorModel{'+method(s,'internal static Mesh Body(')+method(s,'private static void DisplayFace(')+method(s,'private static Mesh AddressScrew(').replace('private static Mesh AddressScrew','internal static Mesh AddressScrew')+method(s,'private static void AddFace(')+'}}';(out/'Extracted.cs').write_text(geom)
(out/'Check.csproj').write_text('''<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><OutputType>Exe</OutputType><TargetFramework>net8.0</TargetFramework></PropertyGroup><ItemGroup><Compile Include="../../Source/RoundedGeometry.cs"/><Compile Include="../../Source/BatteryAperture.cs"/><Compile Include="../../Source/WireContactLayout.cs"/><Compile Include="../../Source/WireRouting.cs"/></ItemGroup></Project>''')
# WireContactLayout has other router deps; extract its dimensional entry members only.
w=(r/'Source/WireContactLayout.cs').read_text();
# Only end-face disk constants are used by the body builder.
cp=out/'Check.csproj';cp.write_text(cp.read_text().replace('<Compile Include="../../Source/WireContactLayout.cs"/>','').replace('<Compile Include="../../Source/WireRouting.cs"/>',''))
with (out/'Extracted.cs').open('a') as f:f.write('namespace ModularSwitchboards{static class WireContactLayout{internal const float BreakerEntryY=.0375f,BreakerEntryZ=.029f;}}')
(out/'Program.cs').write_text('''using System;using System.IO;using System.Linq;using System.Text.Json;using ModularSwitchboards;using UnityEngine;
class Program{
 static int checks;static void Check(bool v,string name){checks++;if(!v)throw new Exception(name);}
 static void Main(string[] args){var body=SmartContactorModel.Body();var screw=SmartContactorModel.AddressScrew();
 Check(Math.Abs(body.V.Max(p=>p.x)-body.V.Min(p=>p.x)-SmartContactor.BodyWidth)<1e-6,"body width must cover two slots");
 Check(body.V.All(p=>p.z<=.06461f),"body/bezel protrudes beyond flat fascia");
 Check(screw.V.All(p=>p.x>=SmartContactor.CenterX-.0024f&&p.x<=SmartContactor.CenterX+.0024f&&p.y>=-.020f&&p.y<=-.012f&&p.z>=.06395f&&p.z<=.06515f),"hex head escapes screwdriver target");
 Check(screw.V.Min(p=>p.y)>-.022f&&screw.V.Max(p=>p.y)<-.008f,"address screw overlaps display or lower terminal");
 foreach(var mesh in new[]{body,screw}){Check(mesh.V.All(v=>float.IsFinite(v.x)&&float.IsFinite(v.y)&&float.IsFinite(v.z)),"nonfinite geometry");foreach(var t in mesh.T.Values)Check(t.Length%3==0&&t.All(i=>i>=0&&i<mesh.V.Count),"invalid triangle indices");}
 // The top surface must leave a real slot at its central X strip.
 var screwTriangles=screw.T[0];int tops=0;for(int i=0;i<screwTriangles.Length;i+=3){var ps=screwTriangles.Skip(i).Take(3).Select(j=>screw.V[j]).ToArray();if(ps.All(p=>p.z>.0648f)){tops++;Check(ps.All(p=>p.x<=SmartContactor.CenterX-.00054f/2.25f)||ps.All(p=>p.x>=SmartContactor.CenterX+.00054f/2.25f),"top face fills screwdriver slot");}}
 Check(tops>=4,"missing slotted head top");
 object Dump(Mesh mesh)=>new{vertices=mesh.V.Select(p=>new[]{p.x,p.y,p.z}),triangles=mesh.T};File.WriteAllText(Path.Combine(args[0],"Art/SmartOutputGeometry.json"),JsonSerializer.Serialize(new{body=Dump(body),screw=Dump(screw)}));
 Console.WriteLine(checks+" Output geometry checks passed: two-slot width, flat fascia, hex slot, screw bounds, display clearance, finite mesh indices.");
 }}''')
