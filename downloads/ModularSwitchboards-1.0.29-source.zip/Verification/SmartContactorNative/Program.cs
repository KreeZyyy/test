using System;using System.IO;using System.Linq;using System.Reflection;using System.Runtime.Loader;
string root=Path.GetFullPath(args[0]),managed=Path.Combine(root,"work/build-deps/Stationeers/rocketstation_Data/Managed");
var dirs=new[]{managed,Path.Combine(root,"work/build-deps/LibConstruct"),Path.Combine(root,"work/build-deps/LaunchPadBooster"),Path.Combine(root,"work/build-deps/Stationeers/BepInEx/core")};
AssemblyLoadContext.Default.Resolving+=(context,name)=>{var p=dirs.Select(d=>Path.Combine(d,name.Name+".dll")).FirstOrDefault(File.Exists);return p==null?null:context.LoadFromAssemblyPath(p);};
var game=AssemblyLoadContext.Default.LoadFromAssemblyPath(Path.Combine(managed,"Assembly-CSharp.dll"));
var mod=AssemblyLoadContext.Default.LoadFromAssemblyPath(Path.Combine(root,"work/release129/ModularSwitchboards/Assemblies/ModularSwitchboards.dll"));
var device=game.GetType("Assets.Scripts.Objects.Pipes.Device",true);var type=mod.GetType("ModularSwitchboards.SmartContactor",true);var logic=game.GetType("Assets.Scripts.Objects.Motherboards.LogicType",true);
if(type.BaseType!=device||type.IsAbstract||!type.GetInterfaces().Any(t=>t.Name=="ILogicable")||!type.GetInterfaces().Any(t=>t.Name=="IPlacementBoardStructure"))throw new Exception("Native device / board contract mismatch");
foreach(var name in new[]{"CanLogicRead","CanLogicWrite"}){var m=type.GetMethod(name,new[]{logic});if(m?.DeclaringType!=type||!m.IsVirtual)throw new Exception(name);}
if(type.GetMethod("SetLogicValue",new[]{logic,typeof(double)})?.DeclaringType!=type)throw new Exception("Native On writer override missing");
if(mod.GetType("ModularSwitchboards.SmartContactorSaveData",true).BaseType?.Name!="StructureSaveData")throw new Exception("Save inheritance mismatch");
if(!mod.GetManifestResourceNames().Contains("ModularSwitchboards.Icons.DinSmartContactor.png"))throw new Exception("Contactor icon not packaged");
foreach(var property in new[]{"PowerCable","PowerCables","DataCables"})if(device.GetProperty(property)?.GetSetMethod(true)==null)throw new Exception("Native connection setter changed: "+property);
if(type.GetField("OutputAddress")?.FieldType!=typeof(int)||mod.GetType("ModularSwitchboards.SmartContactorSaveData",true).GetField("OutputAddress")?.FieldType!=typeof(int))throw new Exception("Address save contract missing");
if(game.GetType("Assets.Scripts.Objects.Interactable",true).GetField("_state",BindingFlags.NonPublic|BindingFlags.Instance)==null)throw new Exception("Native address state field changed");
if(type.GetMethod("OnInteractableUpdated")?.DeclaringType!=type||type.GetMethod("ProcessUpdate")?.DeclaringType!=type)throw new Exception("Address authority/replication override missing");
if(type.GetField("ModuleWidth",BindingFlags.NonPublic|BindingFlags.Instance)?.FieldType!=typeof(int)||mod.GetType("ModularSwitchboards.SmartContactorSaveData",true).GetField("ModuleSlots")?.FieldType!=typeof(int))throw new Exception("Legacy width/save contract missing");
Console.WriteLine("Smart contactor native reflection passed: Device/ILogicable/LibConstruct contracts, native logic overrides, save type, connection setters and embedded icon. Unity execution not attempted.");
