using System;using System.Linq;using System.Collections.Generic;using UnityEngine;namespace ModularSwitchboards{static class DinBreakerModel{internal static Vector3 VisualScale=new(2.25f,1.35f,1.15f);internal static Mesh Build(float width=.0176f,float centerX=0f,bool battery=false,float openingX=0f,float openingY=0f,bool plain=false,bool inputOnly=false,bool bottomOnly=false)
        {
            var vertices=new List<Vector3>();var normals=new List<Vector3>();var triangles=new List<int>[5];
            for(int i=0;i<5;i++)triangles[i]=new List<int>();
            System.Action<Vector3,Vector3,int,float> shape=(center,size,role,radius)=>
            {
                center.x+=centerX;
                if(!battery){RoundedGeometry.Box(vertices,normals,triangles[role],center,size,radius);return;}
                // Same breaker surfaces, with only the seated battery aperture cut out.
                float holeX=openingX>0?openingX:ApcBatteryRegion.SocketHeight/VisualScale.x;
                float holeY=openingY>0?openingY:ApcBatteryRegion.SocketHeight/VisualScale.y;
                BatteryAperture.Box(vertices,normals,triangles[role],center,size,radius,holeX,holeY,openingX>0?0:holeX*.1f,openingX>0?0:holeY*.1f);

            };
            shape(new Vector3(0,0,.029f),new Vector3(width,.075f,.056f),1,.0018f);
            shape(new Vector3(0,0,.059f),new Vector3(width,.052f,.008f),1,.0015f);
            shape(new Vector3(0,0,.0635f),new Vector3(width-.0046f,.045f,.001f),3,.0004f);
            if(battery)
            {
                // The slightly larger native cell extends just behind the former
                // rear plane. Recess only its rear cover; fuse rear walls stay put.
                float rear=openingX>0?.003f:-.0018f,depth=openingX>0?.002f:.0016f;
                // One continuous liner from the closed rear to the actual front.
                // The former three overlapping wall sets are deliberately absent.
                float holeX=openingX>0?openingX:ApcBatteryRegion.SocketHeight/VisualScale.x;
                float holeY=openingY>0?openingY:ApcBatteryRegion.SocketHeight/VisualScale.y;
                float rearFace=rear+depth*.5f;
                BatteryAperture.Walls(vertices,normals,triangles[3],new Vector3(centerX,0,(rearFace+.064f)*.5f),
                    new Vector3(width,.075f,.064f-rearFace),holeX,holeY,openingX>0?0:holeX*.1f,openingX>0?0:holeY*.1f);
                RoundedGeometry.Box(vertices,normals,triangles[3],new Vector3(centerX,0,rear),new Vector3(width,.075f,depth),.0007f);
            }
            foreach(float side in bottomOnly?new[]{-1f}:inputOnly?new[]{1f}:new[]{-1f,1f})
            {
                RoundedGeometry.Box(vertices,normals,triangles[4],new Vector3(centerX,side*.03f,.0577f),new Vector3(.009f,.009f,.0015f),.0005f);
                RoundedGeometry.Box(vertices,normals,triangles[3],new Vector3(centerX,side*.03f,.0586f),new Vector3(.006f,.001f,.0005f),.00015f);
            }
            foreach(float side in bottomOnly?new[]{-1f}:inputOnly?new[]{1f}:new[]{-1f,1f})
            {
                EndDisk(vertices,normals,triangles[4],new Vector3(centerX,side*(WireContactLayout.BreakerEntryY+.0001f),WireContactLayout.BreakerEntryZ),.0042f,side);
                EndDisk(vertices,normals,triangles[3],new Vector3(centerX,side*(WireContactLayout.BreakerEntryY+.0002f),WireContactLayout.BreakerEntryZ),.0032f,side);
            }
            // Two fixed spindle bearings straddle the flap, matching the APC's mounting.
            // Their inner edges clear the 12 mm plate while enclosing its axle ends.
            if(!battery&&!plain)foreach(float side in bottomOnly?new[]{-1f}:inputOnly?new[]{1f}:new[]{-1f,1f})
                RoundedGeometry.Box(vertices,normals,triangles[4],new Vector3(centerX+side*.0073f,0,.0667f),
                    new Vector3(.0022f,.0042f,.0048f),.0007f);
            var mesh=new Mesh{name="Switchboards.RoundedBreaker"};mesh.SetVertices(vertices);mesh.SetNormals(normals);mesh.subMeshCount=5;
            for(int i=0;i<5;i++)mesh.SetTriangles(triangles[i],i);
            CabinetGeometry.ApplyNativeUv(mesh);mesh.RecalculateBounds();return mesh;
        }private static void EndDisk(List<Vector3> vertices,List<Vector3> normals,List<int> triangles,Vector3 center,float worldRadius,float side)
        {
            for(int i=0;i<16;i++)
            {
                float a=i*Mathf.PI/8,b=(i+1)*Mathf.PI/8;
                var p=center+new Vector3(Mathf.Cos(a)*worldRadius/VisualScale.x,0,Mathf.Sin(a)*worldRadius/VisualScale.z);
                var q=center+new Vector3(Mathf.Cos(b)*worldRadius/VisualScale.x,0,Mathf.Sin(b)*worldRadius/VisualScale.z);
                int start=vertices.Count;vertices.AddRange(side>0?new[]{center,q,p}:new[]{center,p,q});normals.AddRange(new[]{Vector3.up*side,Vector3.up*side,Vector3.up*side});triangles.AddRange(new[]{start,start+1,start+2});
            }
        }} static class SmartContactorModel{internal static Mesh Body()
        {
            var body=DinBreakerModel.Build(SmartContactor.BodyWidth,SmartContactor.CenterX,plain:true,bottomOnly:true);
            var v=new List<Vector3>(body.vertices);var n=new List<Vector3>(body.normals);var g=new List<int>[5];for(int i=0;i<5;i++)g[i]=new List<int>(body.GetTriangles(i));
            // Flush display rim and a protected dark screen, on the same fascia as Core/NET.
            DisplayFace(v,n,g[4],.029f,.020f,.009f,.06425f);
            DisplayFace(v,n,g[3],.027f,.018f,.008f,.0646f);
            var mesh=new Mesh{name="DIN.SmartContactor.Body"};mesh.SetVertices(v);mesh.SetNormals(n);mesh.subMeshCount=5;for(int i=0;i<5;i++)mesh.SetTriangles(g[i],i);CabinetGeometry.ApplyNativeUv(mesh);mesh.RecalculateBounds();UnityEngine.Object.DestroyImmediate(body);return mesh;
        }private static void DisplayFace(List<Vector3> vertices,List<Vector3> normals,List<int> triangles,float width,float height,float radius,float z)
        {
            var polygon=new List<Vector2>();
            for(int corner=0;corner<4;corner++)
            {
                float cx=(corner==0||corner==3?1:-1)*(width*.5f-radius),cy=(corner<2?1:-1)*(height*.5f-radius);
                for(int step=0;step<=8;step++)
                {
                    float angle=(corner*90+step*90f/8)*Mathf.PI/180;
                    polygon.Add(new Vector2(cx+Mathf.Cos(angle)*radius,cy+Mathf.Sin(angle)*radius));
                }
            }
            int start=vertices.Count;foreach(var p in polygon){vertices.Add(new Vector3(SmartContactor.CenterX+p.x,.001f+p.y,z));normals.Add(Vector3.forward);}
            for(int i=1;i<polygon.Count-1;i++)triangles.AddRange(new[]{start,start+i,start+i+1});
        }internal static Mesh AddressScrew()
        {
            var vertices=new List<Vector3>();var normals=new List<Vector3>();var indices=new List<int>();
            var center=new Vector3(SmartContactor.CenterX,-.016f,.0645f);
            // Work in physical front-plane units so the anisotropic housing scale
            // does not stretch a hexagon into an oval. Clip each top triangle on
            // either side of the slot to leave a real recessed channel.
            var polygon=Enumerable.Range(0,6).Select(i=>new Vector2(Mathf.Cos(i*Mathf.PI/3)*.005f,Mathf.Sin(i*Mathf.PI/3)*.005f)).ToList();
            foreach(float side in new[]{-1f,1f})
            {
                var clipped=new List<Vector2>();
                for(int i=0;i<polygon.Count;i++)
                {
                    var a=polygon[i];var b=polygon[(i+1)%polygon.Count];bool keepA=side*a.x>=.00055f,keepB=side*b.x>=.00055f;
                    if(keepA)clipped.Add(a);
                    if(keepA!=keepB){float t=(side*.00055f-a.x)/(b.x-a.x);clipped.Add(a+(b-a)*t);}
                }
                AddFace(clipped,.00035f,center,vertices,normals,indices);
            }
            AddFace(polygon,0,center,vertices,normals,indices);
            for(int i=0;i<6;i++)
            {
                var a=polygon[i];var b=polygon[(i+1)%6];int k=vertices.Count;
                foreach(var p in new[]{a,b,b,a})vertices.Add(center+new Vector3(p.x/DinBreakerModel.VisualScale.x,p.y/DinBreakerModel.VisualScale.y,0));
                vertices[k+2]+=Vector3.forward*.00035f;vertices[k+3]+=Vector3.forward*.00035f;
                for(int j=0;j<4;j++)normals.Add(new Vector3(a.x,a.y,0).normalized);
                indices.AddRange(new[]{k,k+1,k+2,k,k+2,k+3});
            }
            var mesh=new Mesh{name="DIN.Output.AddressScrew.HexSlotted"};mesh.SetVertices(vertices);mesh.SetNormals(normals);mesh.SetTriangles(indices,0);mesh.RecalculateBounds();return mesh;
        }private static void AddFace(List<Vector2> polygon,float depth,Vector3 center,List<Vector3> v,List<Vector3> n,List<int> t)
        {
            int start=v.Count;foreach(var p in polygon){v.Add(center+new Vector3(p.x/DinBreakerModel.VisualScale.x,p.y/DinBreakerModel.VisualScale.y,depth));n.Add(Vector3.forward);}
            for(int i=1;i<polygon.Count-1;i++)t.AddRange(new[]{start,start+i,start+i+1});
        }}}namespace ModularSwitchboards{static class WireContactLayout{internal const float BreakerEntryY=.0375f,BreakerEntryZ=.029f;}}