using System;using System.IO;using System.Linq;using System.Text.Json;using ModularSwitchboards;using UnityEngine;
class Program{
 static int checks;static void Check(bool v,string name){checks++;if(!v)throw new Exception(name);}
 static void Main(string[] args){var body=SmartContactorModel.Body();var screw=SmartContactorModel.AddressScrew();
 Check(Math.Abs(body.V.Max(p=>p.x)-body.V.Min(p=>p.x)-SmartContactor.BodyWidth)<1e-6,"body width must cover two slots");
 Check(body.V.All(p=>p.z<=.06461f),"body/bezel protrudes beyond flat fascia");
 Check(screw.V.All(p=>p.x>=SmartContactor.CenterX-.0024f&&p.x<=SmartContactor.CenterX+.0024f&&p.y>=-.020f&&p.y<=-.012f&&p.z>=.06395f&&p.z<=.06515f),"hex head escapes screwdriver target");
 Check(screw.V.Min(p=>p.y)>-.022f&&screw.V.Max(p=>p.y)<-.008f,"address screw overlaps display or lower terminal");
 foreach(var mesh in new[]{body,screw}){Check(mesh.V.All(v=>float.IsFinite(v.x)&&float.IsFinite(v.y)&&float.IsFinite(v.z)),"nonfinite geometry");foreach(var t in mesh.T.Values)Check(t.Length%3==0&&t.All(i=>i>=0&&i<mesh.V.Count),"invalid triangle indices");}
 // The top surface must leave a real slot at its central X strip.
 var screwTriangles=screw.T[0];int tops=0;for(int i=0;i<screwTriangles.Length;i+=3){var ps=screwTriangles.Skip(i).Take(3).Select(j=>screw.V[j]).ToArray();if(ps.All(p=>p.z>.0648f)){tops++;Check(ps.All(p=>p.x<=SmartContactor.CenterX-.00054f/2.25f)||ps.All(p=>p.x>=SmartContactor.CenterX+.00054f/2.25f),"top face fills screwdriver slot");}}
 Check(tops>=4,"missing slotted head top");
 object Dump(Mesh mesh)=>new{vertices=mesh.V.Select(p=>new[]{p.x,p.y,p.z}),triangles=mesh.T};File.WriteAllText(Path.Combine(args[0],"Art/SmartOutputGeometry.json"),JsonSerializer.Serialize(new{body=Dump(body),screw=Dump(screw)}));
 Console.WriteLine(checks+" Output geometry checks passed: two-slot width, flat fascia, hex slot, screw bounds, display clearance, finite mesh indices.");
 }}