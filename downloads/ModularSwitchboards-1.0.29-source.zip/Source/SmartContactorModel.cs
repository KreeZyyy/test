using System;using System.Collections.Generic;using System.Linq;
using Assets.Scripts;using Assets.Scripts.Objects;using Assets.Scripts.Objects.Pipes;using Assets.Scripts.Objects.Motherboards;using Assets.Scripts.UI;using HarmonyLib;using Rendering;using UnityEngine;using UnityEngine.Rendering;
namespace ModularSwitchboards
{
    internal static class SmartContactorModel
    {
        internal static void Install(SmartContactor module,Transform storage)
        {
            foreach(var renderer in module.GetComponentsInChildren<Renderer>(true))UnityEngine.Object.DestroyImmediate(renderer);
            foreach(var filter in module.GetComponentsInChildren<MeshFilter>(true))UnityEngine.Object.DestroyImmediate(filter);
            foreach(var hit in module.GetComponentsInChildren<Collider>(true))UnityEngine.Object.DestroyImmediate(hit);
            foreach(var animator in module.GetComponentsInChildren<Animator>(true))UnityEngine.Object.DestroyImmediate(animator);
            module.BaseAnimator=null;module.Slots=new List<Slot>();module.OpenEnds=new List<Connection>();module.UseCellPosition=false;
            module.Renderers=new List<ThingRenderer>();module._staticColliders=new List<Collider>();module._dynamicColliders=new List<Collider>();module._selfColliders=new List<Collider>();module.CustomNavMeshFilter=null;module.ForceGridBounds.Clear();module.BrokenBuildStates=new List<BrokenBuildState>();
            module.StructureCollisionType=CollisionType.BlockCustom;module.SelectionDisplay=SelectionHighlightMethod.Bounds;
            module.CustomColor=GameManager.GetColorSwatch((int)Assets.Scripts.Objects.Motherboards.ColorType.White);module.PaintableMaterial=module.CustomColor.Normal;module.HasColorState=false;module.MPBRenderers.Clear();module.UsedPower=5f;
            module.Interactables=module.Interactables.Where(i=>i.Action==InteractableType.OnOff||i.Action==InteractableType.Powered).ToList();
            foreach(var i in module.Interactables){i.Parent=module;i.Collider=null;i.Animator=null;i.FakeCollider=null;i.ParentInteractableIndex=-1;}
            SmartPrefabState.Configure(module,false);
            var model=new GameObject("DinBreakerModel"){layer=module.gameObject.layer};model.transform.SetParent(module.transform,false);model.transform.localScale=DinBreakerModel.VisualScale;
            var mesh=Body();
            model.AddComponent<MeshFilter>().sharedMesh=mesh;var mr=model.AddComponent<MeshRenderer>();mr.sharedMaterials=(Material[])CabinetGeometry.Materials.Clone();
            var collider=model.AddComponent<BoxCollider>();collider.center=mesh.bounds.center;collider.size=mesh.bounds.size;
            var state=module.BuildStates[0];state.Visualizer=mr;state.StateMeshes=new List<Mesh>();state.RendererInstance=null;state.Colliders=new List<Collider>{collider};state.Interactables=module.Interactables;state.LinkedGameObjects=new List<GameObject>();state.RenderMode=BuildStateRenderMode.OnMyState;
            AccessTools.Field(typeof(BuildState),"initialDrawData").SetValue(state,new DrawData{mesh=null,materials=new Material[0]});
            module.Thumbnail=CabinetIcons.Get("DinSmartContactor");module.Thumbnails=new Sprite[0];state.Thumbnail=module.Thumbnail;
            module.Bounds=new Bounds(Vector3.Scale(mesh.bounds.center,DinBreakerModel.VisualScale),Vector3.Scale(mesh.bounds.size,DinBreakerModel.VisualScale));module.GridBounds=new GridBounds(module);module.SurfaceArea=.016f*SmartContactor.SlotCount;
            var view=module.gameObject.AddComponent<SmartContactorView>();
            var digits=new GameObject("OutputAddressDisplay"){layer=module.gameObject.layer};digits.transform.SetParent(model.transform,false);view.Digits=digits.transform;
            var lens=GameObject.CreatePrimitive(PrimitiveType.Sphere);lens.name="OutputStatusLED";lens.layer=module.gameObject.layer;lens.transform.SetParent(model.transform,false);
            lens.transform.localPosition=new Vector3(SmartContactor.CenterX,.017f,.0641f);
            lens.transform.localScale=new Vector3(.006f/DinBreakerModel.VisualScale.x,.006f/DinBreakerModel.VisualScale.y,.0016f/DinBreakerModel.VisualScale.z);
            UnityEngine.Object.DestroyImmediate(lens.GetComponent<Collider>());
            var lensMaterial=SmartOutputElectronics.Material("ControlOutputLED",new Color(.025f,.04f,.025f));lensMaterial.EnableKeyword("_EMISSION");lensMaterial.SetColor("_EmissionColor",Color.black);
            lens.GetComponent<MeshRenderer>().sharedMaterial=lensMaterial;view.Lens=lens.GetComponent<MeshRenderer>();
            // Housing-style hex head with an actual recessed straight slot, not a painted line.
            var screw=new GameObject("OutputAddressScrew"){layer=module.gameObject.layer};screw.transform.SetParent(model.transform,false);
            screw.AddComponent<MeshFilter>().sharedMesh=AddressScrew();screw.AddComponent<MeshRenderer>().sharedMaterial=SmartOutputElectronics.Material("AddressScrew",new Color(.25f,.28f,.28f));
            var controlRoot=new GameObject("OutputAddressTarget"){layer=module.gameObject.layer};controlRoot.transform.SetParent(model.transform,false);
            var addressHit=controlRoot.AddComponent<BoxCollider>();addressHit.center=new Vector3(SmartContactor.CenterX,-.016f,.06455f);addressHit.size=new Vector3(.0048f,.008f,.0012f);
            var addressControl=new Interactable{Parent=module,Action=InteractableType.Mode,Collider=addressHit,JoinInProgressSync=true,CanKeyInteract=true,KeyMap="PrimaryAction"};
            module.Interactables.Add(addressControl);state.Interactables=module.Interactables;state.Colliders.Add(addressHit);
            module.CacheStates(true);
            var bp=new GameObject("SmartContactorBlueprint"){layer=module.gameObject.layer};bp.transform.SetParent(storage,false);var ghost=ModelBlueprint.Build(module.transform);var f=bp.AddComponent<MeshFilter>();f.sharedMesh=ghost;var rr=bp.AddComponent<MeshRenderer>();rr.sharedMaterial=CabinetGeometry.Materials[4];var wire=bp.AddComponent<Wireframe>();wire.BlueprintTransform=bp.transform;wire.BlueprintBounds=ghost.bounds;wire.BlueprintMeshFilter=f;wire.BlueprintRenderer=rr;bp.AddComponent<CabinetBlueprint>();module.Blueprint=bp;module.BlueprintOrientVector=Vector3.zero;
        }
        internal static Mesh Body()
        {
            var body=DinBreakerModel.Build(SmartContactor.BodyWidth,SmartContactor.CenterX,plain:true,bottomOnly:true);
            var v=new List<Vector3>(body.vertices);var n=new List<Vector3>(body.normals);var g=new List<int>[5];for(int i=0;i<5;i++)g[i]=new List<int>(body.GetTriangles(i));
            // Flush display rim and a protected dark screen, on the same fascia as Core/NET.
            DisplayFace(v,n,g[4],.029f,.020f,.009f,.06425f);
            DisplayFace(v,n,g[3],.027f,.018f,.008f,.0646f);
            var mesh=new Mesh{name="DIN.SmartContactor.Body"};mesh.SetVertices(v);mesh.SetNormals(n);mesh.subMeshCount=5;for(int i=0;i<5;i++)mesh.SetTriangles(g[i],i);CabinetGeometry.ApplyNativeUv(mesh);mesh.RecalculateBounds();UnityEngine.Object.DestroyImmediate(body);return mesh;
        }
        private static void DisplayFace(List<Vector3> vertices,List<Vector3> normals,List<int> triangles,float width,float height,float radius,float z)
        {
            var polygon=new List<Vector2>();
            for(int corner=0;corner<4;corner++)
            {
                float cx=(corner==0||corner==3?1:-1)*(width*.5f-radius),cy=(corner<2?1:-1)*(height*.5f-radius);
                for(int step=0;step<=8;step++)
                {
                    float angle=(corner*90+step*90f/8)*Mathf.PI/180;
                    polygon.Add(new Vector2(cx+Mathf.Cos(angle)*radius,cy+Mathf.Sin(angle)*radius));
                }
            }
            int start=vertices.Count;foreach(var p in polygon){vertices.Add(new Vector3(SmartContactor.CenterX+p.x,.001f+p.y,z));normals.Add(Vector3.forward);}
            for(int i=1;i<polygon.Count-1;i++)triangles.AddRange(new[]{start,start+i,start+i+1});
        }
        // A legacy one-slot module retains its placement footprint until rebuilt.
        // Scale only this instance's visuals; never claim a neighbour's saved slot.
        internal static void ApplyWidth(SmartContactor module)
        {
            var model=module.transform.Find("DinBreakerModel");if(model==null)return;
            float width=module.ModuleWidth==SmartContactor.SlotCount?SmartContactor.BodyWidth:.0176f;
            float ratio=width/SmartContactor.BodyWidth;
            model.localScale=new Vector3(DinBreakerModel.VisualScale.x*ratio,DinBreakerModel.VisualScale.y,DinBreakerModel.VisualScale.z);
            model.localPosition=new Vector3((module.ModuleWidth==1?-SmartContactor.CenterX*ratio:0)*DinBreakerModel.VisualScale.x,0,0);
            var mesh=model.GetComponent<MeshFilter>().sharedMesh;
            module.Bounds=CabinetWallMount.TransformedBounds(mesh.bounds,module.transform.worldToLocalMatrix*model.localToWorldMatrix);module.GridBounds=new GridBounds(module);
        }
        private static Mesh AddressScrew()
        {
            var vertices=new List<Vector3>();var normals=new List<Vector3>();var indices=new List<int>();
            var center=new Vector3(SmartContactor.CenterX,-.016f,.0645f);
            // Work in physical front-plane units so the anisotropic housing scale
            // does not stretch a hexagon into an oval. Clip each top triangle on
            // either side of the slot to leave a real recessed channel.
            var polygon=Enumerable.Range(0,6).Select(i=>new Vector2(Mathf.Cos(i*Mathf.PI/3)*.005f,Mathf.Sin(i*Mathf.PI/3)*.005f)).ToList();
            foreach(float side in new[]{-1f,1f})
            {
                var clipped=new List<Vector2>();
                for(int i=0;i<polygon.Count;i++)
                {
                    var a=polygon[i];var b=polygon[(i+1)%polygon.Count];bool keepA=side*a.x>=.00055f,keepB=side*b.x>=.00055f;
                    if(keepA)clipped.Add(a);
                    if(keepA!=keepB){float t=(side*.00055f-a.x)/(b.x-a.x);clipped.Add(a+(b-a)*t);}
                }
                AddFace(clipped,.00035f,center,vertices,normals,indices);
            }
            AddFace(polygon,0,center,vertices,normals,indices);
            for(int i=0;i<6;i++)
            {
                var a=polygon[i];var b=polygon[(i+1)%6];int k=vertices.Count;
                foreach(var p in new[]{a,b,b,a})vertices.Add(center+new Vector3(p.x/DinBreakerModel.VisualScale.x,p.y/DinBreakerModel.VisualScale.y,0));
                vertices[k+2]+=Vector3.forward*.00035f;vertices[k+3]+=Vector3.forward*.00035f;
                for(int j=0;j<4;j++)normals.Add(new Vector3(a.x,a.y,0).normalized);
                indices.AddRange(new[]{k,k+1,k+2,k,k+2,k+3});
            }
            var mesh=new Mesh{name="DIN.Output.AddressScrew.HexSlotted"};mesh.SetVertices(vertices);mesh.SetNormals(normals);mesh.SetTriangles(indices,0);mesh.RecalculateBounds();return mesh;
        }
        private static void AddFace(List<Vector2> polygon,float depth,Vector3 center,List<Vector3> v,List<Vector3> n,List<int> t)
        {
            int start=v.Count;foreach(var p in polygon){v.Add(center+new Vector3(p.x/DinBreakerModel.VisualScale.x,p.y/DinBreakerModel.VisualScale.y,depth));n.Add(Vector3.forward);}
            for(int i=1;i<polygon.Count-1;i++)t.AddRange(new[]{start,start+i,start+i+1});
        }
    }
    public sealed class SmartContactorView:MonoBehaviour
    {
        public Transform Digits;public MeshRenderer Lens;
        private SmartContactor owner;private Material lensMaterial;private int lastAddress=-2;
        private readonly List<GameObject> glyphs=new List<GameObject>();
        private void LateUpdate()
        {
            if(owner==null)owner=GetComponent<SmartContactor>();if(owner==null||Digits==null)return;
            if(lastAddress!=owner.OutputAddress){lastAddress=owner.OutputAddress;RebuildDigits();}
            Digits.gameObject.SetActive(owner.BusPowered);
            if(Lens==null)return;
            if(lensMaterial==null){lensMaterial=new Material(Lens.sharedMaterial);Lens.sharedMaterial=lensMaterial;}
            bool on=owner.Conducting;var color=on?new Color(.035f,.75f,.08f):new Color(.025f,.04f,.025f);var emission=on?DoorLedColours.For(DoorLedColours.GreenName).Emission:Color.black;
            lensMaterial.SetColor("_Color",color);lensMaterial.SetColor("_EmissionColor",emission);
            var block=new MaterialPropertyBlock();block.SetColor("_Color",color);block.SetColor("_EmissionColor",emission);Lens.SetPropertyBlock(block);Lens.SetPropertyBlock(block,0);
        }
        private void RebuildDigits()
        {
            foreach(var go in glyphs)if(go!=null)Destroy(go);glyphs.Clear();
            string value=SmartOutputAddresses.Valid(lastAddress)?"d"+lastAddress:"d-";float offset=0;Bounds bounds=default(Bounds);bool first=true;
            for(int i=value.Length-1;i>=0;i--)
            {
                var digit=GameManager.GetDigitMesh(value[i]);if(digit==null)continue;offset+=GameManager.DigitPixel;
                if(digit.DigitMesh!=null)
                {
                    var go=new GameObject("AddressGlyph"){layer=gameObject.layer};go.transform.SetParent(Digits,false);go.transform.localPosition=new Vector3(offset,0,0);
                    go.AddComponent<MeshFilter>().sharedMesh=digit.DigitMesh;go.AddComponent<MeshRenderer>().sharedMaterial=GameManager.GetColorSwatch((int)Assets.Scripts.Objects.Motherboards.ColorType.Green).Emissive;glyphs.Add(go);
                    var b=digit.DigitMesh.bounds;b.center+=new Vector3(offset,0,0);if(first){bounds=b;first=false;}else bounds.Encapsulate(b);
                }
                offset+=digit.PixelWidth*GameManager.DigitPixel;
            }
            if(first)return;
            float fit=Mathf.Min(.022f*DinBreakerModel.VisualScale.x/Mathf.Max(.0001f,bounds.size.x),.012f*DinBreakerModel.VisualScale.y/Mathf.Max(.0001f,bounds.size.y));
            var scale=new Vector3(fit/DinBreakerModel.VisualScale.x,fit/DinBreakerModel.VisualScale.y,fit/DinBreakerModel.VisualScale.z);
            Digits.localScale=scale;Digits.localPosition=new Vector3(SmartContactor.CenterX,.001f,.0648f)-Vector3.Scale(bounds.center,scale);
        }
        private void OnDestroy(){if(lensMaterial!=null)Destroy(lensMaterial);}
    }
}
