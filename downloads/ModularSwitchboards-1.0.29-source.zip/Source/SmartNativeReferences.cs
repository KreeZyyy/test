using System;
using System.Collections.Generic;
using System.Linq;
using Assets.Scripts;
using Assets.Scripts.Objects;
using UnityEngine;
namespace ModularSwitchboards
{
    // Capture original runtime mesh data for the next front-panel authoring step.
    // These references are not mounted on the first four-slot prototype.
    internal static class SmartNativeReferences
    {
        internal sealed class Part
        {
            internal string Path;
            internal Mesh Mesh;
            internal Material[] Materials;
            internal Matrix4x4 ToPrefab;
            internal Vector3[] Vertices;
            internal Vector2[] Uv;
            internal int[][] Triangles;
        }
        internal static readonly Dictionary<string,Part[]> Models=new Dictionary<string,Part[]>();
        internal static void Capture()
        {
            CaptureHousing();
            foreach(string name in new[]{"StructureAirConditioner","StructureConsoleLED5"})
            {
                if(Models.ContainsKey(name))continue;
                try
                {
                    var source=WorldManager.Instance.SourcePrefabs.FirstOrDefault(p=>p.PrefabName==name);
                    if(source==null&&name=="StructureAirConditioner")source=WorldManager.Instance.SourcePrefabs.FirstOrDefault(p=>p.PrefabName!=null&&p.PrefabName.IndexOf("AirConditioner",StringComparison.OrdinalIgnoreCase)>=0);
                    if(source==null)throw new InvalidOperationException("Native prefab not found: "+name);
                    var parts=new List<Part>();
                    foreach(var renderer in source.GetComponentsInChildren<MeshRenderer>(true))
                    {
                        var mesh=renderer.GetComponent<MeshFilter>()?.sharedMesh;if(mesh==null)continue;
                        CabinetGeometry.ReadNativeMesh(mesh,out var vertices,out var uv,out var groups);
                        var names=new List<string>();for(var t=renderer.transform;t!=null&&t!=source.transform;t=t.parent)names.Insert(0,t.name);
                        parts.Add(new Part{Path=string.Join("/",names),Mesh=mesh,Materials=renderer.sharedMaterials,
                            ToPrefab=source.transform.worldToLocalMatrix*renderer.transform.localToWorldMatrix,Vertices=vertices,Uv=uv,Triangles=groups});
                        Debug.Log("[Modular Switchboards] Smart reference "+name+" / "+string.Join("/",names)+": mesh="+mesh.name+" vertices="+vertices.Length+" submeshes="+groups.Length+" bounds="+mesh.bounds+" materials="+string.Join(",",renderer.sharedMaterials.Select(m=>m==null?"null":m.name)));
                    }
                    if(parts.Count==0)throw new InvalidOperationException("No native mesh parts: "+name);
                    ApcWarning.ExportReference(source,name=="StructureAirConditioner"?"AirConditioner-geometry.json":"ConsoleLED5-geometry.json");
                    Models.Add(name,parts.ToArray());
                }
                catch(Exception ex){Debug.LogWarning("[Modular Switchboards] Smart reference capture deferred: "+ex.Message);}
            }
        }
        private static bool housingCaptured;
        private static void CaptureHousing()
        {
            if(housingCaptured)return;
            try
            {
                var housing=WorldManager.Instance.SourcePrefabs.FirstOrDefault(p=>p!=null&&p.GetType().Name=="CircuitHousing");
                if(housing==null)return;
                ApcWarning.ExportReference(housing,"CircuitHousing-reference.json");
                housingCaptured=true;
            }
            catch(Exception ex){Debug.LogWarning("[Modular Switchboards] Housing reference capture deferred: "+ex.Message);}
        }
    }
}
