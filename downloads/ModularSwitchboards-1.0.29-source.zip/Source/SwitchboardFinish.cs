using Assets.Scripts.Objects;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class SwitchboardFinish
    {
        internal static void Refresh(Thing owner)
        {
            // Scope to our mounted assemblies, never a real inserted battery or
            // another child Thing. Door LED materials have their own live owner.
            if(!(owner is SmartContactor)&&!(owner is SmartModule)&&!(owner is SwitchboardCabinet)&&!(owner is DinRail)&&!(owner is DinBreaker part&&!part.IsDoorPart))return;
            foreach(var renderer in owner.GetComponentsInChildren<MeshRenderer>(true))
            {
                if(renderer.GetComponentInParent<Thing>()!=owner||renderer.GetComponent<TextMesh>()!=null)continue;
                if(owner is SmartContactor&&renderer.name!="DinBreakerModel")continue;
                if(owner is SmartModule&&renderer.name!="DinBreakerModel"&&renderer.name!="NativeLEDBezel")continue;
                if(owner is DinBreaker output&&output.IsSmartOutputModule&&renderer.name=="SmartOutputLens")continue;
                if(owner is DinBreaker nativeOutput&&nativeOutput.IsSmartOutputModule&&renderer.name=="SmartOutputGlass")continue;
                CabinetMatteSurface.Apply(renderer);
                var block=new MaterialPropertyBlock();renderer.GetPropertyBlock(block);
                block.SetFloat(Thing.SmoothnessIndexPropertyID,0f);renderer.SetPropertyBlock(block);
                for(int i=0;i<renderer.sharedMaterials.Length;i++)
                {
                    renderer.GetPropertyBlock(block,i);
                    block.SetFloat(Thing.SmoothnessIndexPropertyID,0f);renderer.SetPropertyBlock(block,i);
                    block.Clear();
                }
            }
        }
    }
}
