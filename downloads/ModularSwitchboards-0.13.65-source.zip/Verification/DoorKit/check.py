from pathlib import Path
import json,struct,math
from PIL import Image
root=Path(__file__).resolve().parents[2];data=json.loads((root/'Art/DoorKit/model.json').read_text());raw=(root/'Assets/DoorKit/Model.meshbin').read_bytes();checks=0
assert raw[:4]==b'MKIT';count,length=struct.unpack_from('<ii',raw,4);assert count==len(data['vertices']) and length==len(data['triangles']['0']);assert count<=250000;off=12
for p,n,uv in zip(data['vertices'],data['normals'],data['uv']):
 assert all(math.isfinite(x)for x in p+n+uv);assert .98<sum(x*x for x in n)<1.02;assert raw[off:off+32]==struct.pack('<8f',*p,*n,*uv);off+=32;checks+=1
indices=list(struct.unpack_from('<'+'i'*length,raw,off));off+=length*4;assert off==len(raw);assert indices==data['triangles']['0'];assert all(0<=i<count for i in indices)
for envelope in [(0.3,.2,.2),(.1,.3,.2),(.4,.12,.18)]:
 lo=[min(p[k]for p in data['vertices'])for k in range(3)];hi=[max(p[k]for p in data['vertices'])for k in range(3)];scale=min(envelope[k]/(hi[k]-lo[k])for k in range(3))*.92
 for p in data['vertices']:
  assert all(abs((p[k]-(hi[k]+lo[k])*.5)*scale)<=envelope[k]*.461 for k in range(3));checks+=1
Image.open(root/'Assets/ModuleKit/Surface.png').verify();Image.open(root/'Assets/Icons/KitDoors.png').verify()
print(f'Door module kit: {checks} checks passed; finite normals/UV/vertices, bounded 32-bit capacity, exact embedded data/indices and fit inside native collision envelope; valid atlas/icon.')

source=json.loads((root/'Art/DoorKit/source.json').read_text())
rail=json.loads((root/'Art/RailKit/source.json').read_text())
assert source['shell']==rail['shell'],'Original crate shell changed'
assert source['supportAudit']['grounded_count']==21 and not source['supportAudit']['ungrounded']
assert len(source['layout'])==21
assert set(p['metadata']['doorVariant'] for p in source['layout'])=={'DoorLed','DoorLedBlue','DoorLedWhite','DoorLedRed','DoorStop','DoorIsolator','DoorBridge'}
assert '16' in source['contents']['triangles'],'Dark red grip missing'
switch=(root/'Source/DoorModules.cs').read_text()
assert 'DoorIsolatorGeometry.Grip(),gripRed' in switch
model=(root/'Source/SwitchboardKitModel.cs').read_text()
assert 'thing.PrefabName==SwitchboardsMod.DoorKitName||' in model
assert 'ModuleKitModel.DoorRendererName' in model
install=(root/'Source/SwitchboardsMod.cs').read_text()
assert 'SwitchboardKitModel.Install(doorKit,SwitchboardKitKind.Doors)' in install
assert 'DoorLedColours.All.Length+4' in install
print('Original crate shell unchanged; 21 grounded decorative pieces, all seven existing variants, dark red grip and door-kit wiring verified.')
