# Oasis Browser 0.1.0

Experimental Chrome webpage projection for a local Stationeers ScriptedScreens panel. See Czech [installation instructions](INSTALACE.txt).

This is a separate mod, not a replacement for Oasis chat/media. It launches installed Chrome with a unique temporary profile, extensions disabled, localhost CDP port 9223, and an authenticated loopback control listener on 18767. Native Chrome handles website/media/audio. The mod captures 1280×720 PNG frames at approximately 3–5 FPS, decodes on Unity's main thread and updates a RawImage attached to reserved ScriptedScreens host `Ui:oasis_browser_view`. Runtime UGUI reflection avoids requiring redistribution of additional game assemblies. Native pointer/scroll handlers convert panel coordinates to CDP input. Lua provides search/URL navigation, text insertion, Enter, home/reload and scrolling.

This projects a separately running browser; it is not an embedded Chromium engine in Unity. An external app window remains available for troubleshooting. It is intentionally a low-frame-rate feasibility prototype. In-game host discovery, pointer routing and texture decode must still be tested with the user's installed ScriptedScreens build. Browser audio does not depend on in-game atmospheric sound simulation. Website autoplay/consent/authentication restrictions still apply.

No personal Chrome profile, saved login or cookies are copied. The temporary profile is removed after normal browser shutdown where possible. No API key, yt-dlp or FFmpeg is required. Keep CDP local and avoid entering credentials in this prototype. One shared browser/session; multiplayer not supported.

Build using the existing game reference configuration:

```sh
dotnet build browser/OasisBrowser.csproj -c Release
dotnet run --project browser/tests/BrowserTests.csproj -c Release
PYTHONPATH=/workspace/tooling/python python browser/tests/test_ui.py
```

Tests exercise real headless Chromium in the Linux cloud against a generated local DOM, not YouTube playback or Unity. The test-only root Linux browser launch disables Chromium's sandbox; the shipped Windows launch uses Chrome's normal sandbox. Validates actual PNG capture, clicks, wheel, text, HTTP authentication/action handling, navigation restrictions, and Lua layouts at five aspect ratios. No claim of in-game integration or YouTube audio validation is made yet.
