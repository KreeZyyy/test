using System.Xml.Serialization;using Assets.Scripts.Objects.Electrical;using LibConstruct;namespace ModularSwitchboards{    public sealed class DinTransformerSaveData:TransformerSaveData
    {
        [XmlElement]public PlacementBoardStructureSaveData RailBoard;
    }}