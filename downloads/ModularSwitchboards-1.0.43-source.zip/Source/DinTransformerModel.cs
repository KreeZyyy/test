using System;
using System.Linq;
using System.Collections.Generic;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Electrical;
using Assets.Scripts.Objects.Motherboards;
using Assets.Scripts.UI;
using Assets.Scripts.Util;
using HarmonyLib;
using Rendering;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class DinTransformerModel
    {
        private sealed class Part {internal Transform Frame;internal Mesh Mesh;internal MeshRenderer Source;internal Material[] Materials;}
        internal static void Install(DinTransformer owner,Transformer source,Transform storage)
        {
            if(source.Needle==null)throw new InvalidOperationException("Native transformer needle missing.");
            bool intact(Transform t)
            {
                for(var part=t;part!=null&&part!=source.transform;part=part.parent)
                    if(new[]{"Destroyed","Construction","Blueprint"}.Any(word=>part.name.IndexOf(word,StringComparison.OrdinalIgnoreCase)>=0))return false;
                return true;
            }
            var completed=source.BuildStates.Last();var batch=completed.InitialDrawData;var bodyFrame=completed.Visualizer!=null?completed.Visualizer.transform:source.transform;
            var parts=source.GetComponentsInChildren<MeshRenderer>(true).Where(r=>r.GetComponent<MeshFilter>()?.sharedMesh!=null&&intact(r.transform)&&!source.OpenEnds.Any(c=>c.HelperRenderer==r)&&(!batch.IsValid()||r.transform!=bodyFrame))
                .Select(r=>new Part{Frame=r.transform,Mesh=r.GetComponent<MeshFilter>().sharedMesh,Source=r,Materials=r.sharedMaterials}).ToList();
            if(batch.IsValid())parts.Add(new Part{Frame=bodyFrame,Mesh=batch.mesh,Materials=batch.materials});
            if(parts.Count==0)throw new InvalidOperationException("Native transformer model missing.");
            Bounds? bounds=null;
            foreach(var part in parts){var b=CabinetWallMount.TransformedBounds(part.Mesh.bounds,source.transform.worldToLocalMatrix*part.Frame.localToWorldMatrix);if(bounds.HasValue){var v=bounds.Value;v.Encapsulate(b);bounds=v;}else bounds=b;}
            var native=bounds.Value;
            var needle=source.transform.InverseTransformPoint(source.Needle.transform.position)-native.center;
            // Native Transformer rotates the needle around its local Y axis. That
            // axis is the gauge normal, even when the dial is off-centre.
            var axis=source.transform.InverseTransformDirection(source.Needle.transform.up).normalized;
            if(Vector3.Dot(axis,needle)<0)axis=-axis;
            var up=Vector3.ProjectOnPlane(Vector3.up,axis);if(up.sqrMagnitude<.001f)up=Vector3.ProjectOnPlane(Vector3.forward,axis);
            var rotation=Quaternion.Inverse(Quaternion.LookRotation(axis,up.normalized));
            var turned=CabinetWallMount.TransformedBounds(native,Matrix4x4.Rotate(rotation));
            float scale=Mathf.Min(.078f/turned.size.x,.098f/turned.size.y,.065f/turned.size.z);
            if(float.IsNaN(scale)||float.IsInfinity(scale)||scale<=0)throw new InvalidOperationException("Invalid native transformer model size.");
            foreach(var r in owner.GetComponentsInChildren<Renderer>(true))UnityEngine.Object.DestroyImmediate(r);
            foreach(var f in owner.GetComponentsInChildren<MeshFilter>(true))UnityEngine.Object.DestroyImmediate(f);
            foreach(var c in owner.GetComponentsInChildren<Collider>(true))UnityEngine.Object.DestroyImmediate(c);
            foreach(var a in owner.GetComponentsInChildren<Animator>(true))UnityEngine.Object.DestroyImmediate(a);
            foreach(var child in owner.transform.Cast<Transform>().ToArray())UnityEngine.Object.DestroyImmediate(child.gameObject);
            owner.BaseAnimator=null;owner.Renderers=new List<ThingRenderer>();owner._staticColliders=new List<Collider>();owner._dynamicColliders=new List<Collider>();owner._selfColliders=new List<Collider>();owner.Slots=new List<Slot>();owner.OpenEnds=new List<Connection>();owner.InputConnection=null;owner.OutputConnection=null;owner.InputNetwork=null;owner.OutputNetwork=null;owner.CustomNavMeshFilter=null;owner.ForceGridBounds.Clear();owner.BrokenBuildStates=new List<BrokenBuildState>();owner.UseCellPosition=false;owner.StructureCollisionType=CollisionType.BlockCustom;owner.SelectionDisplay=SelectionHighlightMethod.Bounds;owner.PaintableMaterial=null;owner.HasColorState=false;owner.MPBRenderers.Clear();owner.UsedPower=0;
            var root=new GameObject("DinBreakerModel"){layer=owner.gameObject.layer};root.transform.SetParent(owner.transform,false);root.transform.localScale=DinBreakerModel.VisualScale;
            var mount=new GameObject("NativeTransformer"){layer=owner.gameObject.layer}.transform;mount.SetParent(root.transform,false);
            root.transform.localScale=Vector3.one;mount.localRotation=rotation;mount.localScale=Vector3.one*scale;
            mount.localPosition=new Vector3(DinLayout.SlotPitch*.5f,0,.035f)-rotation*native.center*scale;
            var frames=new Dictionary<Transform,Transform>{{source.transform,mount}};
            Func<Transform,Transform> frame=null;frame=t=>{if(frames.TryGetValue(t,out var f))return f;var parent=frame(t.parent);var go=new GameObject(t.name){layer=owner.gameObject.layer};go.transform.SetParent(parent,false);go.transform.localPosition=t.localPosition;go.transform.localRotation=t.localRotation;go.transform.localScale=t.localScale;frames[t]=go.transform;return go.transform;};
            foreach(var part in parts){var t=frame(part.Frame);t.gameObject.AddComponent<MeshFilter>().sharedMesh=part.Mesh;var copy=t.gameObject.AddComponent<MeshRenderer>();if(part.Source!=null){copy.shadowCastingMode=part.Source.shadowCastingMode;copy.receiveShadows=part.Source.receiveShadows;NativePortSurface.Capture(part.Source,copy);}else NativePortSurface.Capture(part.Materials,copy);}
            owner.Needle=frame(source.Needle.transform).gameObject;
            owner.Interactables=new List<Interactable>();var hits=new List<Collider>();var copies=new Dictionary<Collider,Collider>();
            Collider collider(Collider c)
            {
                if(copies.TryGetValue(c,out var old))return old;
                var t=frame(c.transform);Collider hit;
                if(c is BoxCollider box){var b=t.gameObject.AddComponent<BoxCollider>();b.center=box.center;b.size=box.size;hit=b;}
                else if(c is MeshCollider mesh){var m=t.gameObject.AddComponent<MeshCollider>();m.sharedMesh=mesh.sharedMesh;m.convex=mesh.convex;hit=m;}
                else if(c is SphereCollider sphere){var v=t.gameObject.AddComponent<SphereCollider>();v.center=sphere.center;v.radius=sphere.radius;hit=v;}
                else if(c is CapsuleCollider capsule){var v=t.gameObject.AddComponent<CapsuleCollider>();v.center=capsule.center;v.radius=capsule.radius;v.height=capsule.height;v.direction=capsule.direction;hit=v;}
                else throw new InvalidOperationException("Unsupported native transformer collider: "+c.GetType().Name);
                copies[c]=hit;hits.Add(hit);return hit;
            }
            foreach(var c in source.Interactables.Where(i=>i.Action==InteractableType.OnOff||i.Action==InteractableType.Button1||i.Action==InteractableType.Button2||i.Action==InteractableType.Powered||i.Action==InteractableType.Error))
            {
                if(c.Collider==null){var passive=new Interactable{Parent=owner,Action=c.Action,JoinInProgressSync=true};AccessTools.Field(typeof(Interactable),"_state").SetValue(passive,c.State);owner.Interactables.Add(passive);continue;}
                var hit=collider(c.Collider);var control=new Interactable{Parent=owner,Action=c.Action,Collider=hit,CanKeyInteract=c.CanKeyInteract,KeyMap=c.KeyMap,JoinInProgressSync=true};
                AccessTools.Field(typeof(Interactable),"_state").SetValue(control,c.State);control.AssociatedAudioEvents=new List<Assets.Scripts.Sound.GameAudioEvent>(c.AssociatedAudioEvents);owner.Interactables.Add(control);
            }
            if(!owner.Interactables.Any(i=>i.Action==InteractableType.OnOff)||!owner.Interactables.Any(i=>i.Action==InteractableType.Button1)||!owner.Interactables.Any(i=>i.Action==InteractableType.Button2))throw new InvalidOperationException("Native transformer controls incomplete.");
            foreach(var c in source.BuildStates.Last().Colliders.Where(c=>c!=null))collider(c);
            NativeTransformerParts.Copy(source,owner,frame,collider);
            var all=ModelBlueprint.Build(owner.transform);owner.Bounds=all.bounds;owner.GridBounds=new GridBounds(owner);owner.SurfaceArea=.032f;
            Vector3 contact(Connection connection,bool input)
            {
                if(connection?.Collider!=null){var c=connection.Collider;var local=c is BoxCollider box?box.center:c is SphereCollider sphere?sphere.center:c is MeshCollider mesh&&mesh.sharedMesh!=null?mesh.sharedMesh.bounds.center:Vector3.zero;return owner.transform.InverseTransformPoint(frame(c.transform).TransformPoint(local));}
                return new Vector3(DinLayout.SlotPitch*.5f,input?.05f:-.05f,.035f);
            }
            owner.InternalInput=contact(source.InputConnection,true);owner.InternalOutput=contact(source.OutputConnection,false);
            var state=owner.BuildStates[0];state.Visualizer=owner.GetComponentsInChildren<MeshRenderer>(true).First();state.StateMeshes=new List<Mesh>();state.RendererInstance=null;state.Colliders=hits;state.Interactables=owner.Interactables;state.LinkedGameObjects=new List<GameObject>();state.RenderMode=BuildStateRenderMode.OnMyState;AccessTools.Field(typeof(BuildState),"initialDrawData").SetValue(state,new DrawData{mesh=null,materials=new Material[0]});owner.Thumbnail=source.Thumbnail;owner.Thumbnails=source.Thumbnails;state.Thumbnail=source.Thumbnail;owner.CacheStates(true);owner.Setting=source.Setting;Debug.Log("[Modular Switchboards] Native transformer fit: source="+source.PrefabName+", parts="+parts.Count+", uniform scale="+scale+", bounds="+owner.Bounds+", maximum="+owner.OutputMaximum+" W.");
            var bp=new GameObject("DinTransformerBlueprint"){layer=owner.gameObject.layer};bp.transform.SetParent(storage,false);var filter=bp.AddComponent<MeshFilter>();filter.sharedMesh=all;var renderer=bp.AddComponent<MeshRenderer>();renderer.sharedMaterial=CabinetGeometry.Materials[4];var wire=bp.AddComponent<Wireframe>();wire.BlueprintTransform=bp.transform;wire.BlueprintBounds=all.bounds;wire.BlueprintMeshFilter=filter;wire.BlueprintRenderer=renderer;bp.AddComponent<CabinetBlueprint>();owner.Blueprint=bp;owner.BlueprintOrientVector=Vector3.zero;
        }
    }
}
