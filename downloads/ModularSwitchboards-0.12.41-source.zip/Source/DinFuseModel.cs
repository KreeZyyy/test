using System.Collections.Generic;
using UnityEngine;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Motherboards;

namespace ModularSwitchboards
{
    internal static class DinFuseModel
    {
        private sealed class Shape
        {
            internal readonly List<Vector3> V=new List<Vector3>(),N=new List<Vector3>();
            internal readonly List<int>[] T={new List<int>(),new List<int>(),new List<int>(),new List<int>(),new List<int>()};
            internal void Box(Vector3 p,Vector3 size,int role)=>RoundedGeometry.Box(V,N,T[role],p,size,.0004f);
            internal void Cylinder(float y,float length,float radius,int role)
            {
                const int count=20;float z=.046f;
                for(int i=0;i<count;i++)
                {
                    float a=i*Mathf.PI*2/count,b=(i+1)*Mathf.PI*2/count;
                    var ra=new Vector3(Mathf.Cos(a)*radius/DinBreakerModel.VisualScale.x,0,Mathf.Sin(a)*radius/DinBreakerModel.VisualScale.z);
                    var rb=new Vector3(Mathf.Cos(b)*radius/DinBreakerModel.VisualScale.x,0,Mathf.Sin(b)*radius/DinBreakerModel.VisualScale.z);
                    var lo=new Vector3(0,y-length*.5f,z);var hi=new Vector3(0,y+length*.5f,z);
                    Triangle(lo+ra,hi+ra,lo+rb,role);Triangle(lo+rb,hi+ra,hi+rb,role);
                    Triangle(lo,lo+ra,lo+rb,role);Triangle(hi,hi+rb,hi+ra,role);
                }
            }
            private void Triangle(Vector3 a,Vector3 b,Vector3 c,int role)
            {int first=V.Count;var normal=Vector3.Cross(b-a,c-a).normalized;V.AddRange(new[]{a,b,c});N.AddRange(new[]{normal,normal,normal});T[role].AddRange(new[]{first,first+1,first+2});}
            internal Mesh Finish(string name){var mesh=new Mesh{name=name};mesh.SetVertices(V);mesh.SetNormals(N);mesh.subMeshCount=5;for(int i=0;i<5;i++)mesh.SetTriangles(T[i],i);CabinetGeometry.ApplyNativeUv(mesh);mesh.RecalculateBounds();return mesh;}
        }
        internal static Mesh Housing()
        {
            var g=new Shape();
            g.Box(new Vector3(0,0,.012f),new Vector3(.0176f,.075f,.022f),1);
            g.Box(new Vector3(0,0,.024f),new Vector3(.0125f,.044f,.001f),3);
            foreach(float sign in new[]{-1f,1f})
            {
                g.Box(new Vector3(sign*.0075f,0,.043f),new Vector3(.0026f,.045f,.040f),1);
                g.Box(new Vector3(0,sign*.030f,.031f),new Vector3(.0176f,.015f,.060f),1);
                g.Box(new Vector3(0,sign*.015f,.036f),new Vector3(.011f,.006f,.010f),4);
                g.Box(new Vector3(0,sign*.030f,.0617f),new Vector3(.009f,.009f,.0014f),4);
                g.Box(new Vector3(0,sign*.030f,.0626f),new Vector3(.006f,.001f,.0004f),3);
                // Wire entries stay at the same physical end-face coordinates.
                g.Box(new Vector3(0,sign*.0376f,.029f),new Vector3(.004f,.0003f,.004f),3);
            }
            return g.Finish("Switchboards.HollowFuseHolder");
        }
        internal static Mesh Cartridge(bool burnt)
        {
            var g=new Shape();
            foreach(float sign in new[]{-1f,1f})g.Cylinder(sign*.014f,.005f,.009f,1);
            if(!burnt)g.Cylinder(0,.024f,.007f,0);
            else
            {
                // Two charred halves with an actual missing section, not an indicator.
                g.Cylinder(-.008f,.008f,.007f,3);g.Cylinder(.008f,.008f,.007f,3);
                g.Box(new Vector3(-.0012f,-.0035f,.048f),new Vector3(.002f,.003f,.003f),3);
                g.Box(new Vector3(.001f,.0035f,.044f),new Vector3(.0018f,.003f,.003f),3);
            }
            return g.Finish(burnt?"Switchboards.BurntFuse":"Switchboards.IntactFuse");
        }
        internal static void Paint(Renderer renderer,float watts)
        {
            int colour=DinModuleColours.Index(watts);
            for(int role=0;role<renderer.sharedMaterials.Length;role++)
            {var block=new MaterialPropertyBlock();block.SetFloat(Thing.DiffuseIndexPropertyID,role==0?colour:CabinetGeometry.PaletteIndices[role]);block.SetColor(Thing.EMISSION_COLOR,Color.black);renderer.SetPropertyBlock(block,role);}
        }
    }
    public sealed class DinFuseView:MonoBehaviour
    {
        public DinBreaker Owner;public GameObject Intact,Burnt;
        private void LateUpdate()
        {
            if(Owner==null)return;
            bool filled=Owner.Conducting;
            Intact.SetActive(filled);Burnt.SetActive(Owner.Tripped);
            if(filled)DinFuseModel.Paint(Intact.GetComponent<MeshRenderer>(),Owner.RatedWatts);
            if(Owner.Tripped)DinFuseModel.Paint(Burnt.GetComponent<MeshRenderer>(),Owner.RatedWatts);
        }
    }
}
