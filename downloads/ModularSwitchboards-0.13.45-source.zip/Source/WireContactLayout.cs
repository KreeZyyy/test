using System;
using System.Collections.Generic;

namespace ModularSwitchboards
{
    // Wire entries are on the end faces. Front screws are separate aiming targets.
    internal static class WireContactLayout
    {
        internal const float TerminalEntryY=.015f,TerminalEntryZ=.019f,TerminalScrewY=.007f,TerminalScrewZ=.033f;
        internal const float BreakerEntryY=.0375f,BreakerEntryZ=.029f,BreakerScrewY=.030f,BreakerScrewZ=.0595f;
        internal static WirePoint TerminalEntry=>new WirePoint(0,TerminalEntryY,TerminalEntryZ);
        internal static WirePoint TerminalAim=>new WirePoint(0,TerminalScrewY,TerminalScrewZ);
        internal static WirePoint BreakerEntry(int pin)=>new WirePoint(0,pin==0?BreakerEntryY:-BreakerEntryY,BreakerEntryZ);
        internal static WirePoint BreakerAim(int pin)=>new WirePoint(0,pin==0?BreakerScrewY:-BreakerScrewY,BreakerScrewZ);
        internal static WirePoint[] EntryLead(WirePoint entry,WirePoint routeAnchor,float side=0)
        {
            if(side!=0)
            {
                float x=entry.X+side*.005f;
                return new[]{entry,new WirePoint(x,entry.Y,entry.Z),new WirePoint(x,entry.Y,routeAnchor.Z),routeAnchor};
            }
            var points=new List<WirePoint>{entry};
            // First leave the end face normally; change routing depth while still
            // inside the reserved lead pocket, before joining shared cable lanes.
            float distance=Math.Min(.006f,Math.Abs(routeAnchor.Y-entry.Y)*.5f);
            float firstY=entry.Y+Math.Sign(routeAnchor.Y-entry.Y)*distance;
            points.Add(new WirePoint(entry.X,firstY,entry.Z));
            points.Add(new WirePoint(routeAnchor.X,firstY,entry.Z));
            points.Add(new WirePoint(routeAnchor.X,firstY,routeAnchor.Z));
            points.Add(routeAnchor);
            var compact=new List<WirePoint>();foreach(var p in points)if(compact.Count==0||(p-compact[compact.Count-1]).Squared>1e-12f)compact.Add(p);
            return compact.ToArray();
        }
    }
}
