using System.Collections.Generic;
using UnityEngine;
namespace ModularSwitchboards
{
    // Only the interior mounting board and inner cover receive these private
    // matte clones. Paint textures/colour blocks stay intact; source materials
    // and exterior/module materials are never modified.
    internal static class CabinetMatteSurface
    {
        private static readonly Dictionary<Material,Material> Copies=new Dictionary<Material,Material>();
        private static readonly HashSet<Material> Owned=new HashSet<Material>();
        internal static void Apply(MeshRenderer renderer)
        {
            var materials=renderer.sharedMaterials;
            for(int i=0;i<materials.Length;i++)
            {
                var source=materials[i];if(source==null||Owned.Contains(source))continue;
                if(!Copies.TryGetValue(source,out var matte))
                {
                    matte=new Material(source){name="Switchboards.MatteInterior."+source.name};
                    foreach(string property in new[]{"_Glossiness","_GlossMapScale","_Metallic","_SpecularHighlights","_GlossyReflections"})
                        if(matte.HasProperty(property))matte.SetFloat(property,0f);
                    matte.EnableKeyword("_SPECULARHIGHLIGHTS_OFF");matte.EnableKeyword("_GLOSSYREFLECTIONS_OFF");
                    Copies[source]=matte;Owned.Add(matte);
                }
                materials[i]=matte;
            }
            renderer.sharedMaterials=materials;
        }
    }
}
