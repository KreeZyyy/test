using System.Collections.Generic;
using System.Linq;
using Assets.Scripts;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Motherboards;
using HarmonyLib;
using Rendering;
using Assets.Scripts.UI;
using UnityEngine;
using UnityEngine.Rendering;

namespace ModularSwitchboards
{
    internal static class DinRailModel
    {
        // TH35/15 section on 4 mm end spacers. The web has real 16 x 6 mm slots.
        internal static Mesh Build(float length)
        {
            var vertices=new List<Vector3>();var indices=new List<int>();var channel=new List<int>();
            const float lift=.004f;
            int slots=System.Math.Max(1,(int)(length/.040f));float pitch=length/slots,edge=-length*.5f;
            for(int slot=0;slot<slots;slot++)
            {
                float center=-length*.5f+pitch*(slot+.5f);
                float left=center-.008f,right=center+.008f;
                WebPatch(vertices,channel,edge,left,-.011f,-.011f,.011f,.011f,lift);
                float previousX=left,previousHeight=0f;
                for(int step=1;step<=17;step++)
                {
                    float x,h;
                    if(step<=8)
                    {
                        float angle=step*(float)System.Math.PI/16f;
                        x=center-.005f-.003f*(float)System.Math.Cos(angle);h=.003f*(float)System.Math.Sin(angle);
                    }
                    else
                    {
                        float angle=(step-9)*(float)System.Math.PI/16f;
                        x=center+.005f+.003f*(float)System.Math.Sin(angle);h=.003f*(float)System.Math.Cos(angle);
                    }
                    WebPatch(vertices,channel,previousX,x,previousHeight,h,.011f,.011f,lift);
                    WebPatch(vertices,channel,previousX,x,-.011f,-.011f,-previousHeight,-h,lift);
                    previousX=x;previousHeight=h;
                }
                edge=right;
            }
            WebPatch(vertices,channel,edge,length*.5f,-.011f,-.011f,.011f,.011f,lift);
            foreach(float side in new[]{-1f,1f})
            {
                AddBox(vertices,indices,new Vector3(0,side*.0115f,lift+.00775f),new Vector3(length,.001f,.0145f));
                AddBox(vertices,indices,new Vector3(0,side*.0145f,lift+.0145f),new Vector3(length,.006f,.001f));
                AddBox(vertices,indices,new Vector3(side*(length*.5f-.004f),0,lift*.5f),new Vector3(.008f,.022f,lift));
            }
            var mesh=new Mesh{name="Switchboards.PerforatedDIN35x15"};mesh.SetVertices(vertices);mesh.subMeshCount=5;
            for(int i=0;i<5;i++)mesh.SetTriangles(i==4?indices.ToArray():i==3?channel.ToArray():new int[0],i);
            mesh.RecalculateNormals();CabinetGeometry.ApplyNativeUv(mesh);
            // Native paint atlas: move two 1/4-width shade cells darker, retaining
            // the grey diffuse layer and the existing matte surface preset.
            var uv=mesh.uv;
            for(int i=0;i<uv.Length;i++)uv[i].x=Mathf.Min(.995f,uv[i].x+.5f);
            mesh.uv=uv;mesh.RecalculateTangents();mesh.RecalculateBounds();return mesh;
        }
        private static void WebPatch(List<Vector3> vertices,List<int> indices,float x0,float x1,float low0,float low1,float high0,float high1,float z)
        {
            var q=new[]{new Vector3(x0,low0,z),new Vector3(x1,low1,z),new Vector3(x1,high1,z),new Vector3(x0,high0,z)};
            var f=q.Select(p=>p+Vector3.forward*.001f).ToArray();
            RailQuad(vertices,indices,f[0],f[1],f[2],f[3]);
            RailQuad(vertices,indices,q[3],q[2],q[1],q[0]);
            for(int i=0;i<4;i++){int j=(i+1)%4;RailQuad(vertices,indices,q[i],q[j],f[j],f[i]);}
        }
        private static void RailQuad(List<Vector3> vertices,List<int> indices,Vector3 a,Vector3 b,Vector3 c,Vector3 d)
        {
            int first=vertices.Count;vertices.AddRange(new[]{a,b,c,d});
            indices.AddRange(new[]{first,first+1,first+2,first,first+2,first+3});
        }
        internal static void AddBox(List<Vector3> v,List<int> t,Vector3 center,Vector3 size)
        {
            // Separate vertices per face keep the thin sheet's edges crisp.
            var normals=new[]{Vector3.right,Vector3.left,Vector3.up,Vector3.down,Vector3.forward,Vector3.back};
            foreach(var normal in normals)
            {
                var u=Mathf.Abs(normal.y)>.5f?Vector3.right:Vector3.up;
                var w=Vector3.Cross(normal,u);
                int first=v.Count;
                foreach(var corner in new[]{-u-w,u-w,u+w,-u+w})
                    v.Add(center+Vector3.Scale(normal+corner,size)*.5f);
                t.AddRange(new[]{first,first+1,first+2,first,first+2,first+3});
            }
        }
        internal static void Install(DinRail rail, Transform storage)
        {
            foreach(var component in rail.GetComponentsInChildren<Renderer>(true)) Object.DestroyImmediate(component);
            foreach(var component in rail.GetComponentsInChildren<MeshFilter>(true)) Object.DestroyImmediate(component);
            foreach(var component in rail.GetComponentsInChildren<Collider>(true)) Object.DestroyImmediate(component);
            foreach(var component in rail.GetComponentsInChildren<Animator>(true)) Object.DestroyImmediate(component);
            rail.BaseAnimator=null;
            rail.Renderers=new List<ThingRenderer>();
            rail.Interactables=new List<Interactable>();rail.Slots=new List<Slot>();
            rail._staticColliders=new List<Collider>();rail._dynamicColliders=new List<Collider>();rail._selfColliders=new List<Collider>();
            rail.CustomNavMeshFilter=null;rail.structureRenderMode=StructureRenderMode.Standard;
            rail.ForceGridBounds.Clear();rail.BrokenBuildStates=new List<BrokenBuildState>();
            rail.StructureCollisionType=CollisionType.BlockCustom;
            rail.SelectionDisplay=SelectionHighlightMethod.Bounds;rail.UseCellPosition=false;
            rail.PaintableMaterial=null;rail.HasColorState=false;rail.MPBRenderers.Clear();
            var model=new GameObject("DinRailModel"){layer=rail.gameObject.layer};model.transform.SetParent(rail.transform,false);
            var mesh=Build(DinLayout.RailLength(DinLayout.CabinetInnerWidth));
            var vertices=mesh.vertices;for(int i=0;i<vertices.Length;i++)vertices[i]+=Vector3.right*(DinLayout.FirstModuleSlot*DinLayout.SlotPitch*.5f);mesh.vertices=vertices;mesh.RecalculateBounds();
            model.AddComponent<MeshFilter>().sharedMesh=mesh;
            var renderer=model.AddComponent<MeshRenderer>();renderer.sharedMaterials=CabinetGeometry.Materials;
            renderer.lightProbeUsage=LightProbeUsage.BlendProbes;renderer.reflectionProbeUsage=ReflectionProbeUsage.BlendProbes;
            renderer.shadowCastingMode=ShadowCastingMode.On;renderer.receiveShadows=true;
            var collider=model.AddComponent<BoxCollider>();collider.center=mesh.bounds.center;collider.size=mesh.bounds.size;
            rail.Bounds=mesh.bounds;rail.SurfaceArea=.025f;
            rail.GridBounds=new GridBounds(rail);
            rail.Thumbnail=CabinetIcons.Get("DinRail");rail.Thumbnails=new Sprite[0];
            var state=rail.BuildStates[0];state.Visualizer=renderer;state.StateMeshes=new List<Mesh>();state.RendererInstance=null;
            state.Colliders=new List<Collider>{collider};state.Interactables=new List<Interactable>();
            state.LinkedGameObjects=new List<GameObject>();state.RenderMode=BuildStateRenderMode.OnMyState;
            state.BlockAir=state.AlwaysBlockAir=state.BlockLight=state.BlockGravity=false;state.Thumbnail=rail.Thumbnail;
            AccessTools.Field(typeof(BuildState),"initialDrawData").SetValue(state,new DrawData{mesh=null,materials=new Material[0]});
            var blueprint=new GameObject("DinRailBlueprint"){layer=rail.gameObject.layer};blueprint.transform.SetParent(storage,false);
            var filter=blueprint.AddComponent<MeshFilter>();filter.sharedMesh=mesh;
            var br=blueprint.AddComponent<MeshRenderer>();br.sharedMaterial=CabinetGeometry.Materials[4];
            var wire=blueprint.AddComponent<Wireframe>();wire.BlueprintTransform=blueprint.transform;
            wire.BlueprintBounds=mesh.bounds;wire.BlueprintMeshFilter=filter;wire.BlueprintRenderer=br;
            blueprint.AddComponent<CabinetBlueprint>();
            rail.Blueprint=blueprint;rail.BlueprintOrientVector=Vector3.zero;
            var moduleOrigin = new GameObject("DinModuleBoard") { layer = rail.gameObject.layer };
            moduleOrigin.transform.SetParent(rail.transform, false);
            float halfSpan = (DinLayout.FullModuleCount(DinLayout.CabinetInnerWidth) - 1) * DinLayout.SlotPitch * .5f;
            moduleOrigin.transform.localPosition = new Vector3(-halfSpan, 0, .018f);
            rail.ModuleOrigin = moduleOrigin.transform;
            rail.ModuleSurface = moduleOrigin.AddComponent<BoxCollider>();
            rail.ModuleSurface.center = new Vector3(halfSpan+DinLayout.FirstModuleSlot*DinLayout.SlotPitch*.5f, 0, .002f);
            rail.ModuleSurface.size = new Vector3(rail.ModuleCapacity * DinLayout.SlotPitch, .105f, .001f);
            state.Colliders.Add(rail.ModuleSurface);
        }
        internal static void Refresh(Thing rail)
        {
            foreach(var renderer in rail.GetComponentsInChildren<MeshRenderer>(true))
            {
                if(renderer.name!="DinRailModel")continue;
                // Use native matte base finish, independent of the cabinet's finish.
                foreach(int role in new[]{3,4})
                {
                    var block=new MaterialPropertyBlock();
                    renderer.GetPropertyBlock(block,role);
                    block.SetFloat(Thing.DiffuseIndexPropertyID,CabinetGeometry.PaletteIndices[4]);
                    block.SetFloat(Thing.SmoothnessIndexPropertyID,0f);
                    block.SetColor(Thing.EMISSION_COLOR,Color.black);renderer.SetPropertyBlock(block,role);
                }
            }
        }
    }
}
