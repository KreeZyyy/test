using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Assets.Scripts;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Structures;
using Assets.Scripts.Objects.Motherboards;
using UnityEngine;
using UnityEngine.Rendering;
namespace ModularSwitchboards
{
    // Keep the round lens on its own shader; reuse only small Lights Kit effects.
    // Do not clone a WallLight device: power and network state belong to the door module.
    internal static class NativeDoorLed
    {
        internal static void Install(DinBreaker owner,DoorLedView fallback)
        {
            // Native atlas materials require native UVs. Our round lens keeps its own Standard material.
            var group=new GameObject("DoorLedGlow"){layer=owner.gameObject.layer};group.transform.SetParent(owner.transform,false);
            var view=group.AddComponent<NativeDoorLedView>();view.Owner=owner;
            var green=GameManager.GetColorSwatch((int)ColorType.Green);
            var off=new Material(fallback.Lens.sharedMaterial){name="Switchboards.Door.Green.Off",color=new Color(.06f,.32f,.035f)};
            off.EnableKeyword("_EMISSION");off.SetColor("_EmissionColor",Color.black);
            var on=new Material(off){name="Switchboards.Door.Green.On",color=new Color(.035f,.75f,.08f)};on.SetColor("_EmissionColor",new Color(.04f,1.4f,.10f));
            fallback.Lens.sharedMaterial=off;
            view.Surfaces=new[]{new NativeLedSurface{Renderer=fallback.Lens,Paint=new[]{true},Off=new[]{off},On=new[]{on}}};
            fallback.enabled=false;
            try
            {
                var sources=WorldManager.Instance.SourcePrefabs;
                var kits=sources.OfType<MultiConstructor>().Where(k=>k.PrefabName.IndexOf("Light",StringComparison.OrdinalIgnoreCase)>=0).ToArray();
                var listed=kits.SelectMany(k=>k.Constructables??new List<Structure>()).OfType<WallLight>().ToArray();
                var source=listed.Where(IsLed).OrderBy(l=>l.PrefabName,StringComparer.Ordinal).FirstOrDefault()??sources.OfType<WallLight>().Where(IsLed).OrderBy(l=>l.PrefabName,StringComparer.Ordinal).FirstOrDefault();
                if(source?.Light==null){Debug.LogWarning("[Modular Switchboards] Native LED glow unavailable; round green lens retained.");return;}
                const float scale=.05f;
                var lightRoot=UnityEngine.Object.Instantiate(source.Light.gameObject,group.transform);
                foreach(var collider in lightRoot.GetComponentsInChildren<Collider>(true))UnityEngine.Object.DestroyImmediate(collider);
                lightRoot.name="NativeLedGlow";lightRoot.transform.localPosition=new Vector3(0,0,.012f);lightRoot.transform.localRotation=Quaternion.identity;lightRoot.transform.localScale=Vector3.one*scale;
                foreach(var script in lightRoot.GetComponentsInChildren<MonoBehaviour>(true))
                {
                    string n=script.GetType().FullName;
                    if(n!="VolumetricLight"&&n!="ch.sycoforge.Flares.EasyFlares")UnityEngine.Object.DestroyImmediate(script);
                    else ReduceEffect(script);
                }
                view.Glow=lightRoot.GetComponent<Light>();
                if(view.Glow!=null){view.Glow.range=Mathf.Min(.12f,source.Light.range*scale);view.Glow.intensity=source.Light.intensity*.01f;view.Glow.shadows=LightShadows.None;var cached=source.Lights.FirstOrDefault(l=>l.Light==source.Light);if(cached!=null)view.Glow.cullingMask=cached.LayerMask;view.Glow.color=green.Light;view.Glow.enabled=false;}
                foreach(var flare in lightRoot.GetComponentsInChildren<LensFlare>(true)){flare.brightness*=.02f;flare.color=green.Light;}
                view.GlowObject=lightRoot;lightRoot.SetActive(false);
                Debug.Log("[Modular Switchboards] Round door LED: dedicated green lens material and tiny glow from "+source.PrefabName);
            }
            catch(Exception ex){Debug.LogWarning("[Modular Switchboards] Native LED glow copy failed; round green lens retained: "+ex);}
        }
        private static bool IsLed(WallLight source)
        {
            if(source.PrefabName.IndexOf("LED",StringComparison.OrdinalIgnoreCase)>=0)return true;
            try{return Localization.GetThingName(source.PrefabName).IndexOf("LED",StringComparison.OrdinalIgnoreCase)>=0;}catch(Exception){return false;}
        }
        private static void ReduceEffect(MonoBehaviour effect)
        {
            foreach(var field in effect.GetType().GetFields(BindingFlags.Instance|BindingFlags.Public|BindingFlags.NonPublic))
            {
                if(!field.IsPublic&&!field.IsDefined(typeof(SerializeField),true))continue;
                string name=field.Name.ToLowerInvariant();
                if(name!="size"&&name!="scale"&&name!="intensity"&&name!="brightness")continue;
                try{if(field.FieldType==typeof(float))field.SetValue(effect,(float)field.GetValue(effect)*.04f);
                else if(field.FieldType==typeof(Vector2))field.SetValue(effect,(Vector2)field.GetValue(effect)*.04f);}catch(Exception){}
            }
        }
    }
    [Serializable]
    public sealed class NativeLedSurface{public MeshRenderer Renderer;public bool[] Paint;public Material[] Off,On;}
    public sealed class NativeDoorLedView:MonoBehaviour
    {
        public DinBreaker Owner;public NativeLedSurface[] Surfaces;
        public Light Glow;public GameObject GlowObject;private bool initialized,last;
        private void LateUpdate()
        {
            if(Owner==null||Surfaces==null)return;bool on=!Owner.IsCursor&&Owner.DoorLit;
            if(!initialized||last!=on){foreach(var surface in Surfaces)surface.Renderer.sharedMaterials=on?surface.On:surface.Off;initialized=true;last=on;}
            foreach(var surface in Surfaces)for(int slot=0;slot<surface.Paint.Length;slot++)
            {
                if(!surface.Paint[slot])continue;
                var block=new MaterialPropertyBlock();surface.Renderer.GetPropertyBlock(block,slot);
                block.SetColor("_Color",on?new Color(.035f,.75f,.08f):new Color(.06f,.32f,.035f));block.SetColor("_EmissionColor",on?new Color(.04f,1.4f,.10f):Color.black);surface.Renderer.SetPropertyBlock(block,slot);
            }
            foreach(var hit in Owner.GetComponentsInChildren<Collider>())Thing._colliderLookup[hit]=Owner;
            if(GlowObject!=null)GlowObject.SetActive(on);if(Glow!=null)Glow.enabled=on;
        }
    }
}
