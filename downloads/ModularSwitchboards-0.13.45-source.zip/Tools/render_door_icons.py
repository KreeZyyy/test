"""Render door module icons from the same dimensions as DoorModules.cs."""
import bpy,math
from pathlib import Path
from mathutils import Vector
root=Path(__file__).resolve().parents[1]
def material(name,rgb):
 m=bpy.data.materials.new(name);m.diffuse_color=(*rgb,1);m.use_nodes=True
 bs=m.node_tree.nodes.get('Principled BSDF');bs.inputs['Base Color'].default_value=(*rgb,1);bs.inputs['Roughness'].default_value=.3
 return m
def cube(center,size,mat):
 bpy.ops.mesh.primitive_cube_add(size=1,location=center);o=bpy.context.object;o.dimensions=size;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.append(mat)
 mod=o.modifiers.new('Edges','BEVEL');mod.width=.0008;mod.segments=2
 return o
def cyl(radius,back,front,mat):
 bpy.ops.mesh.primitive_cylinder_add(vertices=32,radius=radius,depth=front-back,location=(0,0,(front+back)*.5));bpy.context.object.data.materials.append(mat)
for name in ('DoorLed','DoorBridge'):
 bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
 dark=material('Black',(.025,.029,.028));grey=material('Terminal',(.82,.85,.82));green=material('Green',(.015,.5,.025))
 if name=='DoorLed':
  cyl(.016,-.002,.004,dark);cyl(.012,.0038,.009,green)
  cube((0,0,-.025),(.036,.046,.021),dark)
  for pin in (-1,1):
   cube((0,pin*.016,-.0365),(.016,.012,.003),grey);cube((0,pin*.016,-.0385),(.01,.001,.001),dark)
  target=Vector((0,0,-.012));campos=Vector((.08,-.07,.12));scale=.082
 else:
  for x in (-.065,.065):
   cube((x,0,.003),(.0192,.021,.006),dark)
   for i in range(1):
    y=0;cube((x,y,.0114),(.018,.0186,.0156),grey);cube((x,y,.01956),(.0054,.001,.0006),dark)
  for i in range(1):
   y=0;curve=bpy.data.curves.new('Flex','CURVE');curve.dimensions='3D';curve.bevel_depth=.0024;curve.bevel_resolution=2;spline=curve.splines.new('BEZIER');spline.bezier_points.add(3)
   for bp,p in zip(spline.bezier_points,[(-.057,y,.013),(-.025,y,-.08),(.025,y,-.08),(.057,y,.013)]):bp.co=p;bp.handle_left_type=bp.handle_right_type='AUTO'
   obj=bpy.data.objects.new('Flex',curve);bpy.context.collection.objects.link(obj);obj.data.materials.append(dark)
  target=Vector((0,0,0));campos=Vector((.25,-.20,.7));scale=.20
 s=bpy.context.scene;s.render.engine='CYCLES';s.cycles.samples=16;s.cycles.use_denoising=False;s.render.resolution_x=s.render.resolution_y=256;s.render.resolution_percentage=100;s.render.film_transparent=True;s.world.color=(.25,.25,.25);s.view_settings.view_transform='Standard'
 bpy.ops.object.camera_add(location=campos);cam=bpy.context.object;cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=scale;s.camera=cam
 bpy.ops.object.light_add(type='AREA',location=(-.3,-.2,.5));bpy.context.object.data.energy=35;bpy.context.object.data.size=.5
 s.render.filepath=str(root/'Assets/Icons'/f'{name}.png');bpy.ops.render.render(write_still=True)
