using System;using System.Collections.Generic;using ModularSwitchboards;using UnityEngine;
namespace UnityEngine{
 public class Material{public string name;public object Texture,Colour;public static int Copies;public Dictionary<string,float> Values=new();public HashSet<string> Keywords=new();public Material(){}public Material(Material m){Copies++;name=m.name;Texture=m.Texture;Colour=m.Colour;Values=new(m.Values);Keywords=new(m.Keywords);}public bool HasProperty(string p)=>Values.ContainsKey(p);public void SetFloat(string p,float v)=>Values[p]=v;public void EnableKeyword(string k)=>Keywords.Add(k);}
 public class MeshRenderer{public Material[] sharedMaterials;}
}
class Program{
 static int checks;static void Check(bool ok,string m){checks++;if(!ok)throw new Exception(m);}
 static void Main(){
 var source=new Material{name="Original",Texture=new object(),Colour=new object()};
 foreach(string p in new[]{"_Glossiness","_GlossMapScale","_Metallic","_SpecularHighlights","_GlossyReflections"})source.Values[p]=.7f;
 source.Values["_DiffuseIndex"]=6;var outside=new MeshRenderer{sharedMaterials=new[]{source}};var inside=new MeshRenderer{sharedMaterials=new[]{source,null,source}};
 CabinetMatteSurface.Apply(inside);var matte=inside.sharedMaterials[0];Check(matte!=source,"Source borrowed instead of cloned");Check(outside.sharedMaterials[0]==source,"Exterior changed");Check(matte.Texture==source.Texture&&matte.Colour==source.Colour,"Paint texture/colour lost");Check(inside.sharedMaterials[1]==null,"Null slot altered");Check(inside.sharedMaterials[2]==matte,"Duplicate source not cached");
 foreach(string p in new[]{"_Glossiness","_GlossMapScale","_Metallic","_SpecularHighlights","_GlossyReflections"}){Check(source.Values[p]==.7f,"Original material mutated");Check(matte.Values[p]==0,"Reflection preset not applied");}
 Check(matte.Values["_DiffuseIndex"]==6,"Paint index changed");Check(source.Keywords.Count==0,"Original keywords mutated");Check(matte.Keywords.Contains("_SPECULARHIGHLIGHTS_OFF")&&matte.Keywords.Contains("_GLOSSYREFLECTIONS_OFF"),"Shader keywords missing");
 CabinetMatteSurface.Apply(inside);Check(Material.Copies==1&&inside.sharedMaterials[0]==matte,"Repeated application re-cloned");var second=new MeshRenderer{sharedMaterials=new[]{source}};CabinetMatteSurface.Apply(second);Check(second.sharedMaterials[0]==matte&&Material.Copies==1,"Second renderer didn't use private cache");
 var unsupported=new Material{name="NoGlossProperties"};var special=new MeshRenderer{sharedMaterials=new[]{unsupported}};CabinetMatteSurface.Apply(special);Check(special.sharedMaterials[0].Values.Count==0,"Unsupported shader properties added");
 Console.WriteLine($"Production matte material isolation: {checks} checks passed; source/exterior unchanged, paint retained, supported properties only, stable private cache.");
 }
}
