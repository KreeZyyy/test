using System.Collections.Generic;
using UnityEngine;

namespace ModularSwitchboards
{
    internal static class RoundedGeometry
    {
        internal static void Box(List<Vector3> vertices,List<Vector3> normals,List<int> indices,Vector3 center,Vector3 size,float radius)
        {
            var half=size*.5f;
            radius=Mathf.Min(radius,Mathf.Min(half.x,Mathf.Min(half.y,half.z))*.8f);
            var inner=half-Vector3.one*radius;
            foreach(var n in new[]{Vector3.right,Vector3.left,Vector3.up,Vector3.down,Vector3.forward,Vector3.back})
            {
                var u=Mathf.Abs(n.y)>.5f?Vector3.right:Vector3.up;
                var v=Vector3.Cross(n,u);
                float hn=Extent(n,half),hu=Extent(u,half),hv=Extent(v,half);
                var us=Samples(hu,radius);var vs=Samples(hv,radius);int start=vertices.Count;
                for(int j=0;j<vs.Length;j++)for(int i=0;i<us.Length;i++)
                {
                    var p=n*hn+u*us[i]+v*vs[j];
                    var q=new Vector3(Mathf.Clamp(p.x,-inner.x,inner.x),Mathf.Clamp(p.y,-inner.y,inner.y),Mathf.Clamp(p.z,-inner.z,inner.z));
                    var direction=(p-q).normalized;
                    vertices.Add(center+q+direction*radius);normals.Add(direction);
                }
                for(int j=0;j<vs.Length-1;j++)for(int i=0;i<us.Length-1;i++)
                {
                    int a=start+j*us.Length+i,b=a+1,c=b+us.Length,d=a+us.Length;
                    indices.AddRange(new[]{a,b,c,a,c,d});
                }
            }
        }
        private static float Extent(Vector3 axis,Vector3 half)=>Mathf.Abs(axis.x)*half.x+Mathf.Abs(axis.y)*half.y+Mathf.Abs(axis.z)*half.z;
        private static float[] Samples(float half,float radius)=>new[]{-half,-half+radius*.5f,-half+radius,half-radius,half-radius*.5f,half};
    }
}
