Modular Switchboards 0.11.3 — bez zadního korpusu

Vychází přímo z dodaného DLL 0.11.3. Metoda InstallRearBody je změněna
na okamžitý návrat: nevytvoří tmavé zadní tělo ani jeho spodní úchyty.
Ostatní metody DLL jsou byte-for-byte zachované. Kabelové přípojky zůstávají.
Nejde o novou kompilaci zdrojáků. Běh ve Stationeers zde nebyl otestován.

Instalace: vypni hru a zazálohuj původní složku ModularSwitchboards.
Nahraď ji složkou ModularSwitchboards z tohoto ZIPu v:
Documents/My Games/Stationeers/mods/
Ponech stávající závislosti. Pro návrat obnov zálohu. Klient a server musí
mít stejnou verzi. Nejprve ověř na kopii uloženého světa.

Source: InstallRearBody is an empty method; CabinetRearModel.cs removed.
Included DLL was patched from the original binary, not rebuilt.
