using UnityEngine;namespace ModularSwitchboards{    internal sealed class CoverPreviewAnimation:MonoBehaviour
    {
        internal MeshFilter Filter;internal Mesh[] Frames;internal Material OwnedMaterial;private int current=-1;
        private void LateUpdate()
        {
            if(Filter==null||Frames==null||Frames.Length==0)return;
            int frame=CoverPreviewPhase.Frame(Time.unscaledTime);if(frame==current)return;Filter.sharedMesh=Frames[frame];current=frame;
        }
        private void OnDestroy(){if(Frames!=null)foreach(var mesh in Frames)if(mesh!=null)Destroy(mesh);if(OwnedMaterial!=null)Destroy(OwnedMaterial);}
    }
}
