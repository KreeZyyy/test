using System;
using System.Linq;
using UnityEngine;
using UnityEngine.Rendering;
namespace ModularSwitchboards
{
    internal static class CoverPlacementPreview
    {
        internal static bool Apply(GameObject cursor,CoverMemory state)
        {
            var filter=cursor.GetComponent<MeshFilter>();var renderer=cursor.GetComponent<MeshRenderer>();var shader=Shader.Find("Hidden/Internal-Colored");
            if(filter==null||renderer==null||shader==null||!shader.isSupported)return false;
            var cells=InnerCoverLayout.Cells(state.Retained,state.Profile);var frames=new Mesh[CoverPreviewPhase.Count];
            for(int i=0;i<frames.Length;i++)
            {
                // No contours, frames or text: only clipped hatch, built once.
                var data=CoverPreviewGeometry.Build(Array.Empty<InnerCoverLayout.Cell>(),cells,Array.Empty<CoverIconRect>(),CoverPreviewPhase.Offset(i));
                var mesh=new Mesh{name="Switchboards.CoverPlacement.AnimatedHatch."+i,indexFormat=IndexFormat.UInt32};
                mesh.SetVertices(data.Vertices);mesh.SetTriangles(data.Triangles[0],0);mesh.RecalculateBounds();frames[i]=mesh;
            }
            var colour=Color.green;colour.a=.2f;var material=new Material(shader){name="Switchboards.CoverPreview.HatchOnly",color=colour};
            material.SetInt("_SrcBlend",(int)BlendMode.SrcAlpha);material.SetInt("_DstBlend",(int)BlendMode.OneMinusSrcAlpha);material.SetInt("_Cull",(int)CullMode.Off);material.SetInt("_ZWrite",0);
            renderer.sharedMaterial=material;renderer.shadowCastingMode=ShadowCastingMode.Off;renderer.receiveShadows=false;filter.sharedMesh=frames[0];
            var animation=cursor.AddComponent<CoverPreviewAnimation>();animation.Filter=filter;animation.Frames=frames;animation.OwnedMaterial=material;
            return true;
        }
    }
    internal sealed class CoverPreviewAnimation:MonoBehaviour
    {
        internal MeshFilter Filter;internal Mesh[] Frames;internal Material OwnedMaterial;private int current=-1;
        private void LateUpdate()
        {
            if(Filter==null||Frames==null||Frames.Length==0)return;
            int frame=CoverPreviewPhase.Frame(Time.unscaledTime);if(frame==current)return;Filter.sharedMesh=Frames[frame];current=frame;
        }
        private void OnDestroy(){if(Frames!=null)foreach(var mesh in Frames)if(mesh!=null)Destroy(mesh);if(OwnedMaterial!=null)Destroy(OwnedMaterial);}
    }
}
