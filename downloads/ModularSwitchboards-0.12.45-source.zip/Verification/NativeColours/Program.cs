using System;
using UnityEngine;
using Assets.Scripts.Objects.Motherboards;
using ModularSwitchboards;
namespace ModularSwitchboards{static class SwitchboardsMod{public const string BreakerName="StructureDinBreaker1P";}}
static class Program
{
 static void Main()
 {
  if(Enum.GetUnderlyingType(typeof(ColorType))!=typeof(byte))throw new Exception("Native ColorType backing type changed; inspect game version.");
  bool reproduced=false;try{int bad=(int)Enum.Parse(typeof(ColorType),"Green");}catch(InvalidCastException){reproduced=true;}
  if(!reproduced)throw new Exception("Reported original cast wasn't reproduced against native enum.");
  float[] watts={1000,5000,50000,100000,500000};int[] expected={(int)ColorType.Green,(int)ColorType.Yellow,(int)ColorType.Orange,(int)ColorType.Red,(int)ColorType.Purple};
  for(int i=0;i<watts.Length;i++)if(DinModuleColours.Index(watts[i])!=expected[i])throw new Exception("Native palette index mismatch.");
  string[] names={"Green","Yellow","Orange","Red","Purple"};int pixels=0;
  foreach(string name in names){for(int i=0;i<=100;i++){
   float level=i/100f;var grey=new Color(level,level,level,.37f);if(LeverTextures.Recolour(grey,name)!=grey)throw new Exception("Neutral lettering recoloured");
   var original=Color.HSVToRGB(.14f,.8f,level);original.a=.42f;var recoloured=LeverTextures.Recolour(original,name);
   if(Math.Abs(recoloured.a-original.a)>1e-6)throw new Exception("Alpha changed");
   Color.RGBToHSV(recoloured,out float hue,out float sat,out float value);
   if(Math.Abs(value-level*LeverTextures.BrightnessScale(name))>1e-5)throw new Exception("Relative texture shading/tone mismatch");
   if(level>0&&Math.Abs(sat-.8f*LeverTextures.SaturationScale(name))>1e-5)throw new Exception("Plastic saturation mismatch");
   if(level>0&&name!="Yellow"&&Math.Abs(hue-LeverTextures.Hue(name))>1e-5)throw new Exception("Wrong plastic hue");
   if(name=="Yellow"&&recoloured!=original)throw new Exception("Original yellow changed");pixels+=2;
  }}
  Console.WriteLine(pixels+" production texture pixel cases passed: neutral ink, target hue, muted saturation/brightness with relative shading, alpha, original yellow.");
  Console.WriteLine("Native Stationeers ColorType(byte): original InvalidCastException reproduced; all five production palette conversions passed against actual Assembly-CSharp.dll.");
 }
}
