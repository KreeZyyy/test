using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Assets.Scripts.Objects;
using UnityEngine;

namespace ModularSwitchboards
{
    internal static class FuseAppearanceDiagnostics
    {
        [Serializable] internal sealed class Report
        {
            public string version=SwitchboardsMod.Version;
            public List<Sample> samples=new List<Sample>();
        }
        [Serializable] internal sealed class Sample
        {
            public string prefab,state;public float watts;public int frame;
            public List<Surface> surfaces=new List<Surface>();
        }
        [Serializable] internal sealed class Surface
        {
            public string renderer,mesh,material,shader;public int materialIndex,materialId,vertices,submeshes;
            public bool active,enabled,globalEmpty,blockEmpty,hasDiffuseIndex,registered;
            public string shadowCasting;public bool receiveShadows,globalHasDiffuse,indexHasDiffuse;public float globalDiffuse,indexDiffuse;
            public Vector3 scale;public Vector3[] positions,normals;public Vector2[] uv;public int[] triangles;
            public List<ApcRearDiagnostics.Property> global,properties;
        }
        private static readonly HashSet<string> captured=new HashSet<string>();
        private static readonly Report report=new Report();
        internal static void Capture(DinFuseView view)
        {
            if(view.Owner==null||view.Owner.Board==null||!view.gameObject.activeInHierarchy)return;
            string state=view.Owner.Tripped?"burnt":view.Owner.Conducting?"intact":"empty";
            string key=view.Owner.RatedWatts+":"+state;
            if(captured.Contains(key)||captured.Count>=20)return;
            try
            {
                var sample=new Sample{prefab=view.Owner.PrefabName,watts=view.Owner.RatedWatts,state=state,frame=Time.frameCount};
                foreach(var renderer in view.Owner.GetComponentsInChildren<MeshRenderer>(true))
                {
                    if(renderer.GetComponentInParent<Thing>()!=view.Owner)continue;
                    var filter=renderer.GetComponent<MeshFilter>();var mesh=filter==null?null:filter.sharedMesh;
                    var global=new MaterialPropertyBlock();renderer.GetPropertyBlock(global);
                    var materials=renderer.sharedMaterials;
                    for(int i=0;i<materials.Length;i++)
                    {
                        var material=materials[i];if(material==null||material.shader==null)continue;
                        var block=new MaterialPropertyBlock();renderer.GetPropertyBlock(block,i);
                        var surface=new Surface{renderer=renderer.name,mesh=mesh==null?"":mesh.name,material=material.name,shader=material.shader.name,
                            materialIndex=i,materialId=material.GetInstanceID(),vertices=mesh==null?0:mesh.vertexCount,submeshes=mesh==null?0:mesh.subMeshCount,
                            active=renderer.gameObject.activeInHierarchy,enabled=renderer.enabled,globalEmpty=global.isEmpty,blockEmpty=block.isEmpty,
                            hasDiffuseIndex=material.HasProperty(Thing.DiffuseIndexPropertyID),
                            globalHasDiffuse=global.HasProperty(Thing.DiffuseIndexPropertyID),indexHasDiffuse=block.HasProperty(Thing.DiffuseIndexPropertyID),globalDiffuse=global.GetFloat(Thing.DiffuseIndexPropertyID),indexDiffuse=block.GetFloat(Thing.DiffuseIndexPropertyID),registered=view.Owner.Renderers!=null&&view.Owner.Renderers.Any(r=>r.GetRendererTransform()==renderer.transform),
                            shadowCasting=renderer.shadowCastingMode.ToString(),receiveShadows=renderer.receiveShadows,scale=renderer.transform.lossyScale,
                            global=ApcRearDiagnostics.Properties(material,global),properties=ApcRearDiagnostics.Properties(material,block)};
                        if(renderer.name=="FuseCaps"&&mesh!=null&&mesh.isReadable)
                        {surface.positions=mesh.vertices;surface.normals=mesh.normals;surface.uv=mesh.uv;surface.triangles=i<mesh.subMeshCount?mesh.GetTriangles(i):new int[0];}
                        sample.surfaces.Add(surface);
                    }
                }
                report.samples.Add(sample);
                string path=Path.Combine(Application.persistentDataPath,"ModularSwitchboards-fuse-diagnostics.json");
                File.WriteAllText(path,DiagnosticJson.Serialize(report));captured.Add(key);
                Debug.Log("[Modular Switchboards] FUSE DIAG saved: "+path+"; "+key+" surfaces="+sample.surfaces.Count);
            }
            catch(Exception ex)
            {captured.Add(key);Debug.LogWarning("[Modular Switchboards] FUSE DIAG failed: "+ex);}
        }
    }
}
