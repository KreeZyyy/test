using System;
using System.Globalization;
namespace ModularSwitchboards
{
    // Layout changes only the displayed text; the saved CustomName is untouched.
    internal static class LabelTextLayout
    {
        internal struct Size
        {
            internal float Width,Height;
            internal Size(float width,float height){Width=width;Height=height;}
        }
        internal struct Result
        {
            internal string Text;
            internal float Scale;
            internal Result(string text,float scale){Text=text;Scale=scale;}
        }
        internal static string Normalize(string value)
        {
            value=(value??string.Empty).Replace('\r',' ').Replace('\n',' ').Trim();
            if(value.Length==0)return "LABEL";
            var info=new StringInfo(value);
            return info.LengthInTextElements>48?info.SubstringByTextElements(0,47)+"…":value;
        }
        private static float Fit(Size size,float width,float height)
            =>Math.Min(width/Math.Max(.0001f,size.Width),height/Math.Max(.0001f,size.Height));
        internal static Result Arrange(string value,float width,float height,Func<string,Size> measure)
        {
            value=Normalize(value);
            var single=new Result(value,Fit(measure(value),width,height));
            var best=single;
            // Prefer natural word breaks. Split an unbroken identifier only at
            // Unicode text-element boundaries, never through an accented glyph.
            var info=new StringInfo(value);bool hasWords=false;
            for(int i=1;i<value.Length-1;i++)if(char.IsWhiteSpace(value[i])){hasWords=true;break;}
            for(int i=1;i<info.LengthInTextElements;i++)
            {
                string left=info.SubstringByTextElements(0,i),right=info.SubstringByTextElements(i);
                if(hasWords&&!char.IsWhiteSpace(left[left.Length-1])&&!char.IsWhiteSpace(right[0]))continue;
                left=left.TrimEnd();right=right.TrimStart();if(left.Length==0||right.Length==0)continue;
                string text=left+"\n"+right;float scale=Fit(measure(text),width,height);
                if(scale>best.Scale)best=new Result(text,scale);
            }
            // Avoid two lines for a marginal gain or short names that already fit.
            return best.Scale>single.Scale*1.12f?best:single;
        }
    }
}
