namespace ModularSwitchboards
{
    internal static class InnerLabelPlacementHint
    {
        internal static string For(SwitchboardCabinet host)
        {
            if(host==null)return "Internal labels mount on an inner cover above DIN modules.";
            if(!host.IsOpen)return "Open the cabinet to place internal labels.";
            if(!host.HasInnerCover)return "Install an inner cover first. Internal labels mount on the cover.";
            return "Aim above DIN modules on the installed inner cover.";
        }
    }
}
