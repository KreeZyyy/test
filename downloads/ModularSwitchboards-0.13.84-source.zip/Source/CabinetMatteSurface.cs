using System.Collections.Generic;
using UnityEngine;
namespace ModularSwitchboards
{
    // Private matte clones preserve textures, paint and emission without
    // changing borrowed game materials. Live LED materials are configured at creation.
    internal static class CabinetMatteSurface
    {
        internal static bool IsPanel(string name)=>name=="Frame"||name=="Housing"||name=="Door"||name=="DoorReturnLip"||name=="Interior"||name=="InnerCoverModel";
        private static readonly Dictionary<Material,Material> Copies=new Dictionary<Material,Material>();
        private static readonly HashSet<Material> Owned=new HashSet<Material>();
        // Only call directly for materials owned by this mod.
        internal static void Configure(Material material)
        {
            foreach(string property in new[]{"_Glossiness","_Smoothness","_GlossMapScale","_Metallic","_SpecularHighlights","_GlossyReflections"})
                if(material.HasProperty(property))material.SetFloat(property,0f);
            material.EnableKeyword("_SPECULARHIGHLIGHTS_OFF");material.EnableKeyword("_GLOSSYREFLECTIONS_OFF");
        }
        internal static void Apply(MeshRenderer renderer)
        {
            var materials=renderer.sharedMaterials;
            for(int i=0;i<materials.Length;i++)
            {
                var source=materials[i];if(source==null||Owned.Contains(source))continue;
                if(!Copies.TryGetValue(source,out var matte))
                {
                    matte=new Material(source){name="Switchboards.MattePanel."+source.name};
                    Configure(matte);
                    Copies[source]=matte;Owned.Add(matte);
                }
                materials[i]=matte;
            }
            renderer.sharedMaterials=materials;
        }
    }
}
