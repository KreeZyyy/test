using Assets.Scripts.Objects;
using UnityEngine;

namespace ModularSwitchboards
{
    // The game's existing Open interaction is saved and synchronized by Thing.
    // This component only presents that state using the new door geometry.
    [DefaultExecutionOrder(-200)]
    public sealed class CabinetDoor : MonoBehaviour
    {
        public Structure Owner;
        public Transform Hinge,RightHinge;
        private bool initialized;
        private float angle;

        private void LateUpdate()
        {
            if (Owner == null || Hinge == null) return;
            float target = Owner.IsOpen ? -110f : 0f;
            angle = initialized ? Mathf.MoveTowards(angle, target, Time.deltaTime * 220f) : target;
            initialized = true;
            Hinge.localRotation = Quaternion.Euler(0f, angle, 0f);
            if(RightHinge!=null)RightHinge.localRotation=Quaternion.Euler(0,-angle,0);
        }
    }
}
