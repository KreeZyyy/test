using System;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class MediumOutputHousing
    {
        // A continuous comb outline: three socket legs, one crossbar and the rear feed stem.
        internal static Vector2[] Outline(float[] x,float[] bottom,float half,float barBottom,float barTop,float stemTop)
        {
            if(x.Length!=3||bottom.Length!=3||half<=.003f||barTop<=barBottom||stemTop<=barTop||
                x[1]-x[0]<=2*half||x[2]-x[1]<=2*half||Array.Exists(bottom,y=>y>=barBottom))
                throw new InvalidOperationException("Invalid Medium downward output housing dimensions.");
            return new[]{new Vector2(x[0]-half,bottom[0]),new Vector2(x[0]+half,bottom[0]),new Vector2(x[0]+half,barBottom),
                new Vector2(x[1]-half,barBottom),new Vector2(x[1]-half,bottom[1]),new Vector2(x[1]+half,bottom[1]),new Vector2(x[1]+half,barBottom),
                new Vector2(x[2]-half,barBottom),new Vector2(x[2]-half,bottom[2]),new Vector2(x[2]+half,bottom[2]),new Vector2(x[2]+half,barTop),
                new Vector2(half,barTop),new Vector2(half,stemTop),new Vector2(-half,stemTop),new Vector2(-half,barTop),new Vector2(x[0]-half,barTop)};
        }
    }
}
