using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
namespace ModularSwitchboards
{
    public sealed class EmergencyStopLabel:DoorLabel { }
    internal static class EmergencyStopLabelModel
    {
        internal const float Inner=.0213f,Outer=.039f;
        internal static Mesh Build()
        {
            var v=new List<Vector3>();var t=new List<int>();
            for(int i=0;i<64;i++)
            {
                float a=i*Mathf.PI/32,b=(i+1)*Mathf.PI/32;
                var ia=new Vector3(Inner*Mathf.Cos(a),Inner*Mathf.Sin(a),-.0008f);var ib=new Vector3(Inner*Mathf.Cos(b),Inner*Mathf.Sin(b),-.0008f);
                var oa=new Vector3(Outer*Mathf.Cos(a),Outer*Mathf.Sin(a),-.0008f);var ob=new Vector3(Outer*Mathf.Cos(b),Outer*Mathf.Sin(b),-.0008f);
                var iaf=new Vector3(ia.x,ia.y,.0012f);var ibf=new Vector3(ib.x,ib.y,.0012f);var oaf=new Vector3(oa.x,oa.y,.0012f);var obf=new Vector3(ob.x,ob.y,.0012f);
                Quad(v,t,oa,ob,obf,oaf);Quad(v,t,ib,ia,iaf,ibf);Quad(v,t,iaf,oaf,obf,ibf);Quad(v,t,ib,ob,oa,ia);
            }
            var mesh=new Mesh{name="Emergency Stop label ring"};mesh.SetVertices(v);mesh.subMeshCount=5;
            for(int i=0;i<5;i++)mesh.SetTriangles(i==1?t.ToArray():new int[0],i);
            mesh.RecalculateNormals();mesh.RecalculateBounds();return mesh;
        }
        private static void Quad(List<Vector3> v,List<int> t,Vector3 a,Vector3 b,Vector3 c,Vector3 d){int p=v.Count;v.AddRange(new[]{a,b,c,d});t.AddRange(new[]{p,p+1,p+2,p,p+2,p+3});}
        private static Material[] materials;
        internal static void Apply(MeshRenderer renderer)
        {
            if(materials==null)
            {
                var shader=Shader.Find("Standard");if(shader==null||!shader.isSupported)shader=Shader.Find("StandardInstanced");
                if(shader==null||!shader.isSupported)throw new InvalidOperationException("Emergency label shader unavailable.");
                materials=new Material[5];for(int i=0;i<5;i++){var m=new Material(shader){name="Switchboards.EmergencyLabel.Yellow",color=new Color(.95f,.78f,.015f)};CabinetMatteSurface.Configure(m);materials[i]=m;}
            }
            renderer.sharedMaterials=materials;renderer.SetPropertyBlock(null);for(int i=0;i<5;i++)renderer.SetPropertyBlock(null,i);
        }
    }
    public sealed class EmergencyStopLabelView:MonoBehaviour
    {
        private void LateUpdate()
        {
            var surface=transform.Find("InnerCoverModel")?.GetComponent<MeshRenderer>();if(surface!=null)EmergencyStopLabelModel.Apply(surface);
            foreach(var text in GetComponentsInChildren<TextMesh>())DepthLabelText.Apply(text);
        }
        internal static void Install(EmergencyStopLabel label)
        {
            Font font=null;foreach(var name in new[]{"LegacyRuntime.ttf","Arial.ttf"}){try{font=Resources.GetBuiltinResource<Font>(name);}catch(Exception){}if(font!=null)break;}
            if(font==null)font=Resources.FindObjectsOfTypeAll<Font>().FirstOrDefault();if(font==null)throw new InvalidOperationException("Emergency label font unavailable.");
            Arc(label,font,"EMERGENCY",true,64f);Arc(label,font,"STOP",false,24f);label.gameObject.AddComponent<EmergencyStopLabelView>();
        }
        private static void Arc(EmergencyStopLabel label,Font font,string value,bool top,float spread)
        {
            for(int i=0;i<value.Length;i++)
            {
                float angle=-spread+2*spread*i/(value.Length-1),rad=angle*Mathf.Deg2Rad;
                var go=new GameObject("EmergencyLabelGlyph"+value[i]+i){layer=label.gameObject.layer};go.transform.SetParent(label.transform,false);
                go.transform.localPosition=new Vector3(-.0335f*Mathf.Sin(rad),(top?1f:-1f)*.0335f*Mathf.Cos(rad),.0024f);go.transform.localRotation=Quaternion.Euler(0,180,top?-angle:angle);
                var text=go.AddComponent<TextMesh>();text.font=font;text.fontSize=96;text.fontStyle=FontStyle.Bold;text.characterSize=.01f;text.anchor=TextAnchor.MiddleCenter;text.alignment=TextAlignment.Center;text.richText=false;text.color=Color.black;text.text=value[i].ToString();
                var size=text.GetComponent<MeshRenderer>().localBounds.size;go.transform.localScale=Vector3.one*Mathf.Min(.0074f/Mathf.Max(.0001f,size.x),.0088f/Mathf.Max(.0001f,size.y));DepthLabelText.Apply(text);
            }
        }
    }
}
