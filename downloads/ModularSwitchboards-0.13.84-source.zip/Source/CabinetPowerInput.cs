using System;
using System.Collections.Generic;
using System.Linq;
using Assets.Scripts;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Electrical;
using UnityEngine;

namespace ModularSwitchboards
{
    // Electrical endpoint belongs to the cabinet grid; its hitbox belongs to the visible panel.
    internal static class CabinetPowerInput
    {
        internal const string RootName="SwitchboardPowerInput";
        internal static void Install(SwitchboardCabinet cabinet)
        {
            var panel=cabinet.transform.Find("SwitchboardModel/CompletedShell/"+OvenInputPanel.RootName);
            var data=panel==null?null:panel.GetComponent<OvenInputPanelMetadata>();
            if(data==null)throw new InvalidOperationException("Cannot register IN without its measured panel/socket metadata.");
            if(cabinet.transform.Find(RootName)!=null)throw new InvalidOperationException("Duplicate cabinet IN installation.");
            var apc=WorldManager.Instance.SourcePrefabs.OfType<AreaPowerControl>().FirstOrDefault();
            if(apc==null)throw new InvalidOperationException("Native APC collision mask unavailable.");
            var socket=NativeCableLayout.Read(CabinetLayout.InputCell(cabinet.PrefabName),CabinetLayout.InputOutward(cabinet.PrefabName));
            if((socket.Point-data.SocketPoint).sqrMagnitude>1e-8f || Vector3.Dot(socket.Forward,data.SocketAxis)<.999f)
                throw new InvalidOperationException("IN model and native cable layout disagree.");
            var root=new GameObject(RootName){layer=cabinet.gameObject.layer};
            root.transform.SetParent(cabinet.transform,false);
            root.transform.localPosition=socket.Point;
            root.transform.localRotation=Quaternion.LookRotation(socket.Forward,Vector3.forward);
            var hit=data.NativeStyleCollider;
            if(hit==null)
            {
                var target=new GameObject("InputSocketHitbox"){layer=cabinet.gameObject.layer};target.transform.SetParent(panel,false);
                hit=target.AddComponent<BoxCollider>();hit.center=new Vector3(0,0,-.006f);hit.size=new Vector3(.065f,.065f,.024f);
            }
            var input=new Connection(cabinet){Transform=root.transform,Collider=hit,
                ConnectionRole=ConnectionRole.Input,
                ConnectionType=cabinet.IsStructureCompleted?NetworkType.Power:NetworkType.None};
            input.Validate();
            cabinet.OpenEnds=new List<Connection>{input};
            cabinet.SmallCollisionType=apc.SmallCollisionType;
            cabinet.UsedPower=0f;
            cabinet.BuildStates[1].Colliders.Add(hit);
            data.FunctionalConnection=true;
            Debug.Log("[Modular Switchboards] Power IN registered: one Input, no outputs; socket="+socket.Point.ToString("F6")+
                "; axis="+socket.Forward+"; cable cell="+socket.CableCell+"; device cell="+socket.BodyCell+
                "; visual hitbox follows oven socket; internal distribution not installed.");
        }
    }
}
