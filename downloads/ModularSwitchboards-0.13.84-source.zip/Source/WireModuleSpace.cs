using System;
using System.Collections.Generic;

namespace ModularSwitchboards
{
    // Shared placement envelope. Reserve empty rows as well as installed rows:
    // a cable must not spend the space needed by a later DIN module.
    internal static class WireModuleSpace
    {
        internal static IEnumerable<WireRect> Reservations()=>Reservations(DinLayout.CabinetInnerWidth,new[]{-.108f,.108f});
        internal static IEnumerable<WireRect> Reservations(float width,IEnumerable<float> rows)
        {
            int capacity=DinLayout.ModuleCount(width);
            float first=-(DinLayout.FullModuleCount(width)-1)*DinLayout.SlotPitch*.5f+DinLayout.FirstModuleSlot*DinLayout.SlotPitch;
            foreach(float row in rows)
            {
                for(int slot=0;slot<capacity;slot++)
                {
                    float center=first+slot*DinLayout.SlotPitch;
                    var body=At(center,row);
                    yield return new WireRect(body.Left,body.Right,body.Bottom-.010f,body.Top+.010f);
                }
            }
        }
        internal static WireRect At(float x,float y)=>new WireRect(x-DinLayout.ModuleHalfWidth,x+DinLayout.ModuleHalfWidth,
            y-DinLayout.ModuleHalfHeight,y+DinLayout.ModuleHalfHeight);
        internal static bool Overlaps(WireRect a,WireRect b)=>Math.Min(a.Right,b.Right)>Math.Max(a.Left,b.Left)+.0001f&&
            Math.Min(a.Top,b.Top)>Math.Max(a.Bottom,b.Bottom)+.0001f;
        // A short contact lead may enter only its own actual device footprint.
        internal static IEnumerable<WireRect> ForLead(IEnumerable<WireRect> reservations,WireRect? fromBody,WireRect? toBody)
        {
            foreach(var r in reservations)
                if(!(fromBody.HasValue&&Overlaps(r,fromBody.Value))&&!(toBody.HasValue&&Overlaps(r,toBody.Value)))yield return r;
        }
    }
}
