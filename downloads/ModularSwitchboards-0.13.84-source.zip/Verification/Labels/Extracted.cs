using System.Linq;using Assets.Scripts.Objects.Items;using Assets.Scripts.Inventory;using Assets.Scripts.Localization2;using Assets.Scripts.Objects;using UnityEngine;using Assets.Scripts.GridSystem;using LibConstruct;namespace ModularSwitchboards{internal static class LabelLayout
    {
        internal static bool Fits(int x,int y,int z,int rotation,int width)
            =>x%90==0&&x>=0&&x/90+width<=8&&(y==240||y==-240)&&z==0&&rotation==0&&width>=1&&width<=3;
        internal static bool Overlaps(int x,int width,int other,int otherWidth)=>x<other+otherWidth&&other<x+width;
    }public partial class SwitchboardLabel{internal static bool CanSupport(PlacementBoard board,Grid3 position,int rotation,int width)
        {
            if(!(board is SwitchboardLabelBoard)||!(board.PrimaryHost is InnerCoverModule cover)||cover.Host==null||!cover.Host.IsOpen||!LabelLayout.Fits(position.x,position.y,position.z,rotation,width))return false;
            // Every covered position must actually contain a module in the row below.
            for(int slot=position.x/90;slot<position.x/90+width;slot++)
            {
                float x=-3.5f*DinLayout.SlotPitch+slot*DinLayout.SlotPitch;
                float y=position.y>0?.108f:-.108f;
                if(!cover.Host.Wiring.Breakers.Any(b=>{var p=cover.transform.InverseTransformPoint(b.transform.position);return Mathf.Abs(p.y-y)<.01f&&x>=p.x-.01f&&x<p.x+(b.ModuleWidth-1)*DinLayout.SlotPitch+.01f;}))return false;
            }
            return true;
        }internal static bool CanPlace(PlacementBoard board,Grid3 position,int rotation,int width)
        {
            return CanSupport(board,position,rotation,width)&&!board.Structures.OfType<SwitchboardLabel>().Any(l=>{var p=board.WorldToGrid(l.transform.position);return p.y==position.y&&LabelLayout.Overlaps(position.x/90,width,p.x/90,l.Width);});
        }public override CanConstructInfo CanConstruct()
        {
            if(!(Board is SwitchboardLabelBoard)||(IsCursor&&PlacementBoard.CursorBoard!=Board))return CanConstructInfo.InvalidPlacement(InnerLabelPlacementHint.For(SwitchboardCoverInput.Target()));
            var p=Board.WorldToGrid(Transform.position);
            if(IsCursor)
            {
                if(!MountPlacement.TryLockedGrid(this,Board,out var locked))
                {
                    var candidates=Enumerable.Range(0,9-Width).SelectMany(x=>new[]{new Grid3(x*90,-240,0),new Grid3(x*90,240,0)}).Where(g=>CanSupport(Board,g,0,Width));
                    if(!MountSnap.TryNearest(p,candidates,out p))return CanConstructInfo.InvalidPlacement("Aim above installed modules.");
                }
                else p=locked;
                PlacementBoard.CursorGrid=p;PlacementBoard.CursorRotation=0;Transform.SetPositionAndRotation(Board.GridToWorld(p),Board.IndexToRotation(0));
            }
            return CanPlace(Board,p,Board.RotationToIndex(Transform.rotation),Width)?CanConstructInfo.ValidPlacement:CanConstructInfo.InvalidPlacement("Choose free space directly above installed modules.");
        }internal static void SetBounds(SwitchboardLabel label)
        {
            label.ThingTransform=label.transform;
            label.Bounds=new Bounds(new Vector3((label.Width-1)*DinLayout.SlotPitch*.5f,0,0),new Vector3(label.Width*DinLayout.SlotPitch-.004f,.018f,.002f));
            label.GridBounds=new GridBounds(label);
        }public override DelayedActionInstance AttackWith(Attack attack,bool doAction=true)
        {
            if(Cover?.Host==null||!Cover.Host.IsOpen)return new DelayedActionInstance{Duration=0}.Fail("Open the cabinet first.");
            if(attack.SourceItem is Labeller labeller)
            {
                // Match native Device/ItemRenamable, including local UI authority
                // and native rename network/save handling inside Labeller.Rename.
                var action=new DelayedActionInstance{Duration=0f,ActionMessage=ActionStrings.Rename};
                if(!labeller.OnOff)return action.Fail(GameStrings.DeviceNotOn);
                if(!labeller.IsOperable)return action.Fail(GameStrings.DeviceNoPower);
                if(doAction)labeller.Rename(this);
                return action;
            }
            return base.AttackWith(attack,doAction);
        }}}