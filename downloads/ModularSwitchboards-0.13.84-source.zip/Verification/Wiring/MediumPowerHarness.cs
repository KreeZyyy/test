using System;
using System.Collections.Generic;
using System.Linq;
using Assets.Scripts.Networks;
using Assets.Scripts.Objects.Items;
using ModularSwitchboards;
static class MediumPowerHarness
{
 static void Check(bool ok,string message){if(!ok)throw new Exception("Medium power: "+message);}
 static CabinetWireSaveData W(long a,int ap,long b,int bp)=>new(){From=new(a,ap),To=new(b,bp)};
 internal static void Run()
 {
  var host=new SwitchboardCabinet{PrefabName="medium",Output3Connection=new()};
  var input=new CableNetwork{PotentialLoad=900};var outputs=new[]{new CableNetwork{RequiredLoad=300},new CableNetwork{RequiredLoad=300},new CableNetwork{RequiredLoad=300}};
  host.InputConnection.cable.CableNetwork=input;host.Output1Connection.cable.CableNetwork=outputs[0];host.Output2Connection.cable.CableNetwork=outputs[1];host.Output3Connection.cable.CableNetwork=outputs[2];
  var parts=new[]{new DinBreaker{ReferenceId=10,OnOff=true,RatedWatts=600},new DinBreaker{ReferenceId=20,OnOff=true,RatedWatts=400},new DinBreaker{ReferenceId=30,OnOff=true,RatedWatts=700},new DinBreaker{ReferenceId=40,OnOff=true,RatedWatts=400}};
  var wires=new[]{W(0,0,10,0),W(10,1,20,0),W(10,1,30,0),W(20,1,0,1),W(30,1,0,2),W(30,1,40,0),W(40,1,0,3)};
  var power=new CabinetWiringPower();power.Refresh(host,wires,parts);
  Check(outputs.All(n=>Math.Abs(power.Generated(n)-300)<.001f),"Three independent budgets");
  foreach(var network in outputs)power.Use(network,300);Check(Math.Abs(power.Used(input)-900)<.001f,"Consumption must charge input once");
  Check(power.DrainTrips().SequenceEqual(new long[]{10}),"Shared protection must see all three branch loads");power.Receive(input,900);Check(power.Used(input)==0,"Debt repayment");
  parts[3].OnOff=false;power.Refresh(host,wires,parts);Check(power.Generated(outputs[2])==0&&power.Generated(outputs[0])>0&&power.Generated(outputs[1])>0,"Third branch isolation");parts[3].OnOff=true;
  var cell=new BatteryCell{ReferenceId=99,PowerStored=600,PowerMaximum=1000};var battery=new DinBreaker{ReferenceId=100,IsBatteryModule=true,Battery=cell};
  host.InputConnection.cable.CableNetwork=null;foreach(var n in outputs)n.RequiredLoad=100;
  var backup=new CabinetWiringPower();var batteryWires=wires.Where(w=>w.From.Owner!=0).Prepend(W(100,1,10,0)).ToArray();backup.Refresh(host,batteryWires,parts.Append(battery));
  var offered=outputs.Select(n=>backup.Generated(n)).ToArray();Check(Math.Abs(offered.Sum()-600)<.001f,"Battery reservation total");for(int i=0;i<3;i++)backup.Use(outputs[i],offered[i]);Check(cell.PowerStored==0,"Battery not overdrawn/duplicated across third output");
  Check(AnalyserCircuit.Output(55,new[]{W(55,1,0,3)},Array.Empty<long>())==8,"Analyzer third output bit");
  var mediumRows=CabinetShape.Rows("medium");Check(mediumRows.SequenceEqual(new[]{-150,0,150})&&DinLayout.ModuleCount(CabinetShape.RailWidth("medium"))==14,"3x14 DIN capacity");
  Console.WriteLine("Medium power: 3 independent networks, combined protective load, branch isolation, shared battery reservations, analyzer output3 and 3x14 rows passed.");
 }
}
