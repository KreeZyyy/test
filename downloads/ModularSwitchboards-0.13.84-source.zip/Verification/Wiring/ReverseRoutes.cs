using System;
using System.Linq;
using ModularSwitchboards;
partial class RouteHarness
{
    internal static void RunReverse()
    {
        WirePoint Flip(WirePoint q)=>new(q.X,-q.Y,q.Z);
        var jointWire=new[]{new WirePoint(0,.196f,.019f),new WirePoint(0,.190f,.019f),new WirePoint(0,.190f,.06535f),new WirePoint(0,.184f,.06535f),new WirePoint(-.055f,.184f,.06535f)};
        var top=new[]{jointWire};var bottom=new[]{jointWire.Select(Flip).ToArray()};var noBlocks=Array.Empty<WireRect>();
        var topGeometry=new WireRouting.Geometry(noBlocks,top,true);var bottomGeometry=new WireRouting.Geometry(noBlocks,bottom,true);var random=new Random(1380);
        for(int i=0;i<300;i++)
        {
            var a=new WirePoint((float)random.NextDouble()*.12f-.06f,.16f+(float)random.NextDouble()*.075f,.019f+(float)random.NextDouble()*.065f);
            var b=new WirePoint(a.X+(float)random.NextDouble()*.02f-.01f,a.Y+(float)random.NextDouble()*.02f-.01f,a.Z);
            if(WireRouting.Clear(a,b,noBlocks,top,true)!=WireRouting.Clear(Flip(a),Flip(b),noBlocks,bottom,true)||
               topGeometry.Clear(a,b)!=bottomGeometry.Clear(Flip(a),Flip(b))||
               Math.Abs(topGeometry.Visual(a,b,1)-bottomGeometry.Visual(Flip(a),Flip(b),1))>.00001f)throw new Exception("Input joint reflection changes clearance or visual cost");
        }
        // A wire that starts at the bottom must not gain a second free joint at the top.
        var through=new[]{new[]{new WirePoint(0,-.196f,.06535f),new WirePoint(-.05f,-.184f,.06535f),new WirePoint(-.05f,.2f,.06535f),new WirePoint(.05f,.2f,.06535f)}};
        if(WireRouting.Clear(new(0,.19f,.06535f),new(0,.21f,.06535f),noBlocks,through,true))throw new Exception("Opposite joint wrongly exempts wire collision");
        var throughGeometry=new WireRouting.Geometry(noBlocks,through,true);if(throughGeometry.Clear(new(0,.19f,.06535f),new(0,.21f,.06535f)))throw new Exception("Indexed collision exempts wrong joint");
        var h=new RouteHarness();
        h.railObstacles.Add(new(-.162f,.162f,.0905f,.1255f));h.railObstacles.Add(new(-.162f,.162f,-.1255f,-.0905f));
        var input=new CabinetWireEnd(0,0);
        h.contacts[input]=new(){End=input,Position=new(0,-.196f,.033f),Exit=new(0,-.184f,WireRouting.Plane),Bounds=new(-.036f,.036f,-.227f,-.195f)};
        for(int i=1;i<=2;i++)
        {
            float x=i==1?.108f:-.108f;var e=new CabinetWireEnd(0,i);
            h.contacts[e]=new(){End=e,Position=new(x,.196f,.033f),Exit=new(x,.178f,WireRouting.Plane),Bounds=new(x-.036f,x+.036f,.195f,.227f)};
        }
        for(int i=0;i<3;i++)
        {
            float x=-.10125f+i*.0405f;var bounds=new WireRect(x-.0198f,x+.0198f,.108f-.050625f,.108f+.050625f);
            for(int pin=0;pin<2;pin++){var e=new CabinetWireEnd(10+i,pin);h.contacts[e]=new(){End=e,Position=new(x,.108f+(pin==0?.050625f:-.050625f),.06535f),Exit=new(x,pin==0?.174f:.042f,WireRouting.Plane),Bounds=bounds};}
        }
        var pairs=new[]{(input,new CabinetWireEnd(10,0)),(input,new CabinetWireEnd(11,0)),(input,new CabinetWireEnd(12,0)),(new CabinetWireEnd(10,1),new CabinetWireEnd(0,1)),(new CabinetWireEnd(11,1),new CabinetWireEnd(0,2))};
        foreach(var pair in pairs)
        {
            var path=h.MakeRoute(pair.Item1,pair.Item2,out int slot,out var fail);
            if(path==null)throw new Exception("Reverse route failed "+pair.Item1+" -> "+pair.Item2+": "+fail);
            h.VerifyFutureSpace(path,pair.Item1,pair.Item2);
            foreach(var rail in h.railObstacles)for(int i=1;i<path.Length;i++)if(WireRouting.SegmentHitsRect(path[i-1],path[i],rail,WireRouting.Radius+.001f))throw new Exception("Reverse wire crosses DIN rail");
            var from=h.contacts[pair.Item1].Position;var to=h.contacts[pair.Item2].Position;
            if(Math.Abs(path[0].Y-from.y)>.00001f||Math.Abs(path[path.Length-1].Y-to.y)>.00001f)throw new Exception("Reverse contact endpoint lost");
            h.wires.Add(new(){From=pair.Item1,To=pair.Item2,InputSlot=slot,RouteVersion=CurrentRouteVersion,CableUnits=1,Points=Flatten(path)});
        }
        Console.WriteLine("Reverse full routes passed: 3 lower Input branches to upright modules, 2 upper Outputs, rail/module clearance, tube geometry and endpoints.");
    }
}
