using System;
using System.Globalization;
using System.Linq;
using ModularSwitchboards;
class Program
{
    static int checks;
    static void Check(bool value,string message){checks++;if(!value)throw new Exception(message);}
    // Proportional glyph metrics fixture; actual Unity font metrics require game testing.
    static LabelTextLayout.Size Measure(string value)
    {
        var lines=value.Split('\n');float width=0;
        foreach(var line in lines)
        {
            float row=0;var e=StringInfo.GetTextElementEnumerator(line);
            while(e.MoveNext()){var glyph=e.GetTextElement();row+=glyph=="I"||glyph=="l"?.002f:glyph=="W"||glyph=="M"?.009f:glyph==" "?.0025f:.006f;}
            width=Math.Max(width,row);
        }
        return new LabelTextLayout.Size(width,.010f+(lines.Length-1)*.0105f);
    }
    static void Main()
    {
        Check(LabelTextLayout.Normalize(null)=="LABEL","Empty name fallback");
        Check(LabelTextLayout.Normalize("  Pump\r\nA  ")=="Pump  A","Saved line breaks displayed safely");
        Check(new StringInfo(LabelTextLayout.Normalize(new string('x',80))).LengthInTextElements==48,"Long names bounded");
        foreach(int width in new[]{1,2,3})foreach(var value in new[]{"ON","24V","LABEL","Pump A","Output pump pressure","Main circulation pump","WWWWWWWWWWWWWWWWWWWWWWWW","IIIIIIIIIIIIIIII","Záložní čerpadlo","Přívod kyslíku 🚀","123456789012345678901234567890123456789012345678"})
        {
            float available=width*.0405f-.0068f;var fit=LabelTextLayout.Arrange(value,available,.015f,Measure);var size=Measure(fit.Text);
            Check(fit.Text.Split('\n').Length<=2,"Maximum two lines");
            Check(fit.Scale>0&&!float.IsNaN(fit.Scale)&&!float.IsInfinity(fit.Scale),"Finite positive scale");
            Check(size.Width*fit.Scale<=available+.00001f&&size.Height*fit.Scale<=.01501f,"Fits face");
            Check(fit.Text.Replace("\n","").Replace(" ","")==LabelTextLayout.Normalize(value).Replace(" ",""),"Name retained across wrapping");
            var again=LabelTextLayout.Arrange(value,available,.015f,Measure);Check(again.Text==fit.Text&&again.Scale==fit.Scale,"Deterministic layout");
            foreach(var line in fit.Text.Split('\n'))Check(line.Length>0&&!char.IsLowSurrogate(line[0])&&CharUnicodeInfo.GetUnicodeCategory(line,0)!=UnicodeCategory.NonSpacingMark,"Glyph not split");
        }
        var shortName=LabelTextLayout.Arrange("24V",.0337f,.015f,Measure);Check(shortName.Text=="24V","Short name stays on one line");
        var longName=LabelTextLayout.Arrange("Main circulation pump",.0337f,.015f,Measure);Check(longName.Text.Contains('\n'),"Long name wraps at word boundary");
        Check(new[]{"Main\ncirculation pump","Main circulation\npump"}.Contains(longName.Text),"Natural word break");
        var identifier=LabelTextLayout.Arrange("WWWWWWWWWWWWWWWW",.0337f,.015f,Measure);Check(identifier.Text.Contains('\n'),"Unbroken identifier wraps");
        var compact=LabelTextLayout.Arrange("IIIIIIIIIIIIIIII",.0337f,.015f,Measure);Check(compact.Text.IndexOf('\n')<0,"Measured narrow glyphs do not wrap unnecessarily");
        Console.WriteLine($"{checks} production internal label layout checks passed; proportional metric fixture, not Unity rendering.");
    }
}
