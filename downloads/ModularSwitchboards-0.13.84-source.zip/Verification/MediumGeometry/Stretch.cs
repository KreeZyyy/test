using System.Collections.Generic;
using Assets.Scripts.Objects;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class MediumGeometry
    {
        internal static Mesh Stretch(Mesh source,float x,float y,bool mirror=false)
        {
            var mesh=UnityEngine.Object.Instantiate(source);mesh.name="Medium."+source.name;
            var vertices=mesh.vertices;
            for(int i=0;i<vertices.Length;i++)vertices[i]=new Vector3(vertices[i].x*x*(mirror?-1:1),vertices[i].y*y,vertices[i].z);
            mesh.vertices=vertices;
            if(mirror)for(int s=0;s<mesh.subMeshCount;s++){var t=mesh.GetTriangles(s);for(int i=0;i<t.Length;i+=3){int n=t[i+1];t[i+1]=t[i+2];t[i+2]=n;}mesh.SetTriangles(t,s);}
            mesh.RecalculateNormals();mesh.RecalculateTangents();mesh.RecalculateBounds();return mesh;
        }
}}