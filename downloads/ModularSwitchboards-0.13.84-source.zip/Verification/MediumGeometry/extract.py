from pathlib import Path
p=Path(__file__).resolve().parents[2]
s=(p/"Source/MediumGeometry.cs").read_text();s=s[:s.index("        internal static void Install")]+"}}"
(Path(__file__).parent/"Stretch.cs").write_text(s)
