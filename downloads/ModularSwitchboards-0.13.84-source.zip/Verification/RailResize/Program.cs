using System;using System.Linq;using ModularSwitchboards;using UnityEngine;
namespace UnityEngine{
public class Object{public static void Destroy(object o){}}
public struct Vector3{public float x,y,z;public Vector3(float x,float y,float z){this.x=x;this.y=y;this.z=z;}public static Vector3 right=>new(1,0,0);public static Vector3 operator +(Vector3 a,Vector3 b)=>new(a.x+b.x,a.y+b.y,a.z+b.z);public static Vector3 operator *(Vector3 a,float b)=>new(a.x*b,a.y*b,a.z*b);}
public struct Bounds{public Vector3 center,size;}
public class Mesh{public string name;public Vector3[] vertices;public Bounds bounds;public int subMeshCount=1;public int[] GetTriangles(int i)=>new[]{0,1,2};public void SetTriangles(int[] a,int i){}public void RecalculateNormals(){}public void RecalculateBounds(){var v=vertices;bounds=new(){center=new((v.Min(p=>p.x)+v.Max(p=>p.x))*.5f,0,0),size=new(v.Max(p=>p.x)-v.Min(p=>p.x),.035f,.015f)};}}
public class MeshFilter{public Mesh sharedMesh;}
public class BoxCollider{public Vector3 center,size;}
public class Transform{public Vector3 localPosition;public MeshFilter filter;public BoxCollider hit;public Transform model;public Transform Find(string n)=>model;public T GetComponent<T>()where T:class=>typeof(T)==typeof(MeshFilter)?filter as T:hit as T;}
}
namespace ModularSwitchboards{
static class CabinetShape{public static bool Medium(string s)=>s=="medium";public static float RailWidth(string s)=>Medium(s)?.65f:DinLayout.CabinetInnerWidth;public static float HalfSpan(string s)=>(DinLayout.FullModuleCount(RailWidth(s))-1)*DinLayout.SlotPitch*.5f;}
class GridBounds{public GridBounds(DinRail r){}}
class Wireframe{public MeshFilter BlueprintMeshFilter=new();public Bounds BlueprintBounds;}
class DinRail{public string HostName;public float SizedWidth;public Transform ModuleOrigin=new(),transform=new(){model=new()};public BoxCollider ModuleSurface;public Mesh SizedMesh,SizedGhost;public Bounds Bounds;public GridBounds GridBounds;public Wireframe Wireframe=new();public int ModuleCapacity=>DinLayout.ModuleCount(CabinetShape.RailWidth(HostName));}
static class ModelBlueprint{public static int Refreshes;public static void Refresh(DinRail r){Refreshes++;}}
static partial class DinRailModel{internal static Mesh Build(float length){var m=new Mesh{vertices=new[]{new Vector3(-length/2,0,0),new Vector3(length/2,0,0),new Vector3(0,.035f,.015f)}};m.RecalculateBounds();return m;}}
}
class Program{
static int n;static void Check(bool b,string s){n++;if(!b)throw new Exception(s);}static void Near(float a,float b)=>Check(Math.Abs(a-b)<1e-6f,$"{a}!={b}");
static void Main(){foreach(bool stripped in new[]{true,false}){var r=new DinRail{HostName="medium"};if(!stripped){r.ModuleSurface=new();r.transform.model.filter=new();r.transform.model.hit=new();}DinRailModel.Resize(r);Near(r.SizedWidth,.65f);Check(r.ModuleCapacity==14,"Medium capacity");Near(r.ModuleOrigin.localPosition.x,-CabinetShape.HalfSpan("medium"));Check(r.SizedMesh!=null&&r.GridBounds!=null,"sized geometry/bounds");if(stripped)Check(r.SizedGhost!=null&&r.Wireframe.BlueprintMeshFilter.sharedMesh==r.SizedGhost,"stripped cursor blueprint updated");else{Check(r.transform.model.filter.sharedMesh==r.SizedMesh,"placed renderer");Near(r.ModuleSurface.size.x,14*DinLayout.SlotPitch);Near(r.transform.model.hit.size.x,r.Bounds.size.x);}var first=r.SizedMesh;DinRailModel.Resize(r);Check(first==r.SizedMesh,"repeat update idempotent");r.HostName="small";DinRailModel.Resize(r);Near(r.SizedWidth,DinLayout.CabinetInnerWidth);Near(r.ModuleOrigin.localPosition.x,-CabinetShape.HalfSpan("small"));Check(first!=r.SizedMesh,"cursor restores small after medium");r.HostName="medium";DinRailModel.Resize(r);Near(r.SizedWidth,.65f);}
Console.WriteLine($"DIN resize: {n} actual production-method checks passed: stripped cursor without colliders, own ghost, placed hitbox/surface, width changes and idempotence.");}}
