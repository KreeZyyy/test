using System;using System.Linq;using UnityEngine;namespace ModularSwitchboards{static partial class DinRailModel{        internal static void Resize(DinRail rail)
        {
            float width=CabinetShape.RailWidth(rail.HostName);if(rail.SizedWidth==width||rail.ModuleOrigin==null)return;
            var t=rail.transform.Find("DinRailModel");if(t==null)return;
            if(!CabinetShape.Medium(rail.HostName)&&rail.SizedWidth==0){rail.SizedWidth=width;return;}
            var mesh=Build(DinLayout.RailLength(width));var vertices=mesh.vertices;for(int i=0;i<vertices.Length;i++)vertices[i]+=Vector3.right*(DinLayout.FirstModuleSlot*DinLayout.SlotPitch*.5f);mesh.vertices=vertices;mesh.RecalculateBounds();
            var filter=t.GetComponent<MeshFilter>();if(filter!=null)filter.sharedMesh=mesh;var hit=t.GetComponent<BoxCollider>();if(hit!=null){hit.center=mesh.bounds.center;hit.size=mesh.bounds.size;}
            rail.Bounds=mesh.bounds;rail.GridBounds=new GridBounds(rail);
            float half=CabinetShape.HalfSpan(rail.HostName);rail.ModuleOrigin.localPosition=new Vector3(-half,0,.018f);
            // Native placement cursors strip colliders; the placed rail keeps its module surface.
            if(rail.ModuleSurface!=null){rail.ModuleSurface.center=new Vector3(half+DinLayout.FirstModuleSlot*DinLayout.SlotPitch*.5f,0,.002f);rail.ModuleSurface.size=new Vector3(rail.ModuleCapacity*DinLayout.SlotPitch,.105f,.001f);}
            var old=rail.SizedMesh;rail.SizedMesh=mesh;rail.SizedWidth=width;if(old!=null)UnityEngine.Object.Destroy(old);
            if(filter!=null)ModelBlueprint.Refresh(rail);
            else if(rail.Wireframe?.BlueprintMeshFilter!=null)
            {
                var ghost=new Mesh{name="Medium DIN cursor"};ghost.vertices=mesh.vertices;ghost.SetTriangles(Enumerable.Range(0,mesh.subMeshCount).SelectMany(i=>mesh.GetTriangles(i)).ToArray(),0);ghost.RecalculateNormals();ghost.RecalculateBounds();
                rail.Wireframe.BlueprintMeshFilter.sharedMesh=ghost;rail.Wireframe.BlueprintBounds=ghost.bounds;var previous=rail.SizedGhost;rail.SizedGhost=ghost;if(previous!=null)UnityEngine.Object.Destroy(previous);
            }
        }
}}