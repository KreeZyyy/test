using System;
using System.Collections.Generic;
using UnityEngine;
using Assets.Scripts.Objects;
namespace ModularSwitchboards
{
    // Independent procedural geometry for each cable type; no native cable UV atlas.
    internal static class WireVisualGenerator
    {
        private static Material blackMaterial;
        private static Material BlackMaterial
        {
            get
            {
                if(blackMaterial!=null)return blackMaterial;
                var shader=Shader.Find("Standard")??Shader.Find("Unlit/Color");
                if(shader==null)throw new InvalidOperationException("Black wire marking shader unavailable");
                blackMaterial=new Material(shader){name="Switchboards.WireMarking.Black",color=Color.black};
                CabinetMatteSurface.Configure(blackMaterial);return blackMaterial;
            }
        }
        internal static void Surface(MeshRenderer renderer,CabinetWireKind kind)
        {
            var material=CabinetGeometry.Materials[3];
            renderer.sharedMaterials=kind==CabinetWireKind.Normal?new[]{material}:new[]{material,BlackMaterial};
            CabinetMatteSurface.Apply(renderer);
            if(kind==CabinetWireKind.Normal)return;
            var black=new MaterialPropertyBlock();black.SetColor("_Color",UnityEngine.Color.black);black.SetColor(Thing.EMISSION_COLOR,UnityEngine.Color.black);
            renderer.SetPropertyBlock(black,1);
        }
        internal static Mesh Build(WirePoint[] path,CabinetWireKind kind)
        {
            float radius=WireVisualProfiles.Get(kind).Radius;
            path=WireMarkings.Sample(WireTube.Supports(path),kind,out var distances);
            float length=distances[distances.Length-1];
            var v=new List<Vector3>();var normals=new List<Vector3>();var triangles=new List<int>();const int sides=12;
            var bands=new List<int>();
            var right=new WirePoint();var tangent=new WirePoint();
            for(int i=0;i<path.Length;i++)
            {
                var p=CabinetWiring.Vector(path[i]);var ring=WireTube.Ring(path,i,sides,ref right,ref tangent);
                for(int k=0;k<sides;k++){var n=CabinetWiring.Vector(ring[k]);v.Add(p+n*WireMarkings.Radius(kind,distances[i],length,radius));normals.Add(n);}
                var target=i>0&&WireMarkings.Black(kind,(distances[i-1]+distances[i])*.5f,length)?bands:triangles;
                if(i>0)for(int k=0;k<sides;k++){int a=(i-1)*sides+k,b=(i-1)*sides+(k+1)%sides,c=i*sides+k,d=i*sides+(k+1)%sides;target.AddRange(new[]{a,b,c,b,d,c});}
            }
            // Small flat end caps are buried in their contacts.
            for(int k=1;k<sides-1;k++){triangles.AddRange(new[]{0,k+1,k});int n=(path.Length-1)*sides;triangles.AddRange(new[]{n,n+k,n+k+1});}
            var mesh=new Mesh{name="Switchboards.InternalWire"};if(v.Count>65535)mesh.indexFormat=UnityEngine.Rendering.IndexFormat.UInt32;mesh.SetVertices(v);mesh.SetNormals(normals);mesh.subMeshCount=kind==CabinetWireKind.Normal?1:2;mesh.SetTriangles(triangles,0);if(kind!=CabinetWireKind.Normal)mesh.SetTriangles(bands,1);CabinetGeometry.ApplyNativeUv(mesh);mesh.RecalculateBounds();return mesh;
        }
    }
}
