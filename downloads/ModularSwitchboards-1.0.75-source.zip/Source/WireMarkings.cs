using System;
using System.Collections.Generic;
namespace ModularSwitchboards
{
    // Arc-length markings follow bends and keep a constant physical pitch.
    internal static class WireMarkings
    {
        internal static float Pitch(CabinetWireKind kind)=>WireVisualProfiles.Get(kind).Pitch;
        internal static float BandWidth(CabinetWireKind kind)=>WireVisualProfiles.Get(kind).BandWidth;
        internal static bool Black(CabinetWireKind kind,float distance,float length)
        {
            if(kind==CabinetWireKind.Normal)return false;
            if(kind==CabinetWireKind.SuperHeavy&&(distance<WireVisualProfiles.Get(kind).CollarLength||distance>length-WireVisualProfiles.Get(kind).CollarLength))return true;
            float phase=distance%Pitch(kind);
            return phase>=.004f&&phase<.004f+BandWidth(kind);
        }
        internal static float Radius(CabinetWireKind kind,float distance,float length,float radius)
        {
            if(kind!=CabinetWireKind.SuperHeavy)return radius;
            // A short reinforced collar, always within the original route envelope.
            float end=Math.Min(distance,length-distance);
            float t=Math.Max(0,Math.Min(1,(end-(WireVisualProfiles.Get(kind).CollarLength-.002f))/.002f));
            return radius*(1f-(1f-WireVisualProfiles.Get(kind).BodyScale)*t);
        }
        internal static WirePoint[] Sample(WirePoint[] path,CabinetWireKind kind,out float[] distances)
        {
            var original=new float[path.Length];for(int i=1;i<path.Length;i++)original[i]=original[i-1]+(float)Math.Sqrt((path[i]-path[i-1]).Squared);
            float length=original[original.Length-1];var cuts=new List<float>(original);
            if(kind!=CabinetWireKind.Normal)
            {
                float pitch=Pitch(kind);
                for(int i=0;i*pitch<length;i++)foreach(float boundary in new[]{i*pitch+.004f,i*pitch+.004f+BandWidth(kind)})if(boundary<length)cuts.Add(boundary);
                if(kind==CabinetWireKind.SuperHeavy)foreach(float boundary in new[]{WireVisualProfiles.Get(kind).CollarLength-.002f,WireVisualProfiles.Get(kind).CollarLength,length-WireVisualProfiles.Get(kind).CollarLength,length-(WireVisualProfiles.Get(kind).CollarLength-.002f)})if(boundary>0&&boundary<length)cuts.Add(boundary);
            }
            cuts.Sort();var points=new List<WirePoint>();var arc=new List<float>();int segment=1;
            foreach(float d in cuts)
            {
                if(arc.Count>0&&d-arc[arc.Count-1]<.000001f)continue;
                while(segment<path.Length-1&&original[segment]<d)segment++;
                float span=original[segment]-original[segment-1];if(span<.0000001f)continue;
                float t=(d-original[segment-1])/span;
                points.Add(path[segment-1]+(path[segment]-path[segment-1])*t);arc.Add(d);
            }
            distances=arc.ToArray();return points.ToArray();
        }
    }
}
