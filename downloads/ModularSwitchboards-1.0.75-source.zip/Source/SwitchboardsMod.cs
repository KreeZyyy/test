using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Assets.Scripts;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Electrical;
using Assets.Scripts.Objects.Structures;
using Assets.Scripts.Util;
using HarmonyLib;
using LaunchPadBooster;
using Reagents;
using UnityEngine;
using Object = UnityEngine.Object;

namespace ModularSwitchboards
{
    public sealed class SwitchboardsMod : MonoBehaviour
    {
        public const string Version = "1.0.75";
        // Keep the 0.1.0 identity so saved kits continue to work.
        public const string KitName = "ItemKitModularSwitchboard";
        public const string CabinetName = "StructureModularSwitchboard";
        public const string MediumReverseCabinetName="StructureModularSwitchboardMediumReverse";
        public const string MediumCabinetName="StructureModularSwitchboardMedium";
        public const string ReverseCabinetName="StructureModularSwitchboardReverse";
        internal static bool IsCabinetName(string name)=>name==CabinetName||name==ReverseCabinetName||name==MediumCabinetName||name==MediumReverseCabinetName;
        public const string CoverKitName="ItemKitSwitchboardInnerCover";
        public const string CoverName="StructureSwitchboardInnerCover";
        public const string RailKitName = "ItemKitDinRail";
        public const string RailName = "StructureSwitchboardDinRail";
        public const string SmartKitName="ItemKitDinSmartModule";
        public const string BreakerKitName = "ItemKitDinBreaker1P";
        public const string DoorKitName="ItemKitSwitchboardDoorModules";
        public const string DoorRoundSwitchName="StructureSwitchboardDoorRoundSwitch";
        public const string DoorIsolatorName="StructureSwitchboardDoorIsolator";
        public const string DoorStopName="StructureSwitchboardDoorTotalStop";
        public const string DoorBridgeName="StructureSwitchboardDoorPassThrough";
        public const string DoorLedName=DoorLedColours.GreenName;
        public const string DoorLedBlueName=DoorLedColours.BlueName,DoorLedWhiteName=DoorLedColours.WhiteName,DoorLedRedName=DoorLedColours.RedName;
        public const string EmergencyStopLabelName="StructureSwitchboardEmergencyStopLabel";
        public const string DoorLabelName="StructureSwitchboardDoorLabel";
        public const string LabelKitName="ItemKitSwitchboardLabels";
        internal static string LabelName(int width)=>"StructureSwitchboardLabel"+width;
        public const string BreakerName = "StructureDinBreaker1P";
        public static readonly Mod Mod = new Mod("ModularSwitchboards", Version);
        private static bool loaded;
        private static GameObject storage;
        private static readonly MethodInfo CloneMethod = AccessTools.Method(typeof(object), "MemberwiseClone");

        public void OnLoaded(List<GameObject> prefabs)
        {
            if (loaded) return;
            LibConstructDependency.Validate();
            Mod.AddSaveDataType<SwitchboardCabinetSaveData>();
            Mod.AddSaveDataType<DinRailSaveData>();
            Mod.AddSaveDataType<InnerCoverSaveData>();
            Mod.AddSaveDataType<PortableCoverSaveData>();
            Mod.AddSaveDataType<SwitchboardLabelSaveData>();
            Mod.AddSaveDataType<DoorLabelSaveData>();
            Mod.AddSaveDataType<DinBreakerSaveData>();
            Mod.AddSaveDataType<SmartModuleSaveData>();
            Mod.AddSaveDataType<SmartContactorSaveData>();
            Mod.AddSaveDataType<DinTransformerSaveData>();
            var harmony = new Harmony("modularswitchboards.prototype");
            harmony.Patch(AccessTools.Method(typeof(Assets.Scripts.Inventory.InventoryManager),"HandleStructurePrefab"),
                postfix:new HarmonyMethod(typeof(CabinetNativePortHelpers),nameof(CabinetNativePortHelpers.AfterCursorCreated)));
            harmony.Patch(AccessTools.Method(typeof(Assets.Scripts.Objects.Items.ConfigCartridge),"ReadLogicText"),
                prefix:new HarmonyMethod(typeof(SwitchboardTablet),nameof(SwitchboardTablet.BeforeRead)));
            harmony.Patch(AccessTools.Method(typeof(Assets.Scripts.UI.Stationpedia),"AddBindingsInfo"),
                postfix:new HarmonyMethod(typeof(SwitchboardStationpedia),nameof(SwitchboardStationpedia.FormatBindings)));
            harmony.Patch(AccessTools.Method(typeof(Assets.Scripts.UI.Stationpedia),"PopulateLists"),
                postfix:new HarmonyMethod(typeof(SwitchboardStationpedia),nameof(SwitchboardStationpedia.PopulateLists)));
            harmony.Patch(AccessTools.Method(typeof(Assets.Scripts.UI.Stationpedia),"AddBuildStates"),
                postfix:new HarmonyMethod(typeof(SwitchboardStationpedia),nameof(SwitchboardStationpedia.FormatBuildStates)));
            harmony.Patch(AccessTools.Method(typeof(Assets.Scripts.UI.Stationpedia),"AddSlotInfo"),
                postfix:new HarmonyMethod(typeof(SwitchboardStationpedia),nameof(SwitchboardStationpedia.FormatSlots)));
            harmony.Patch(AccessTools.Method(typeof(Assets.Scripts.UI.Stationpedia),"ForceSearch"),
                prefix:new HarmonyMethod(typeof(SwitchboardStationpedia),nameof(SwitchboardStationpedia.ExpandQuery)));
            harmony.Patch(AccessTools.Method(typeof(Assets.Scripts.UI.ImGuiUi.ImguiCreativeSpawnMenu),"ForceSearch"),
                prefix:new HarmonyMethod(typeof(SwitchboardStationpedia),nameof(SwitchboardStationpedia.ExpandQuery)));
            harmony.Patch(AccessTools.Method(typeof(Assets.Scripts.UI.ImGuiUi.ImguiCreativeSpawnMenu),"IsRegexMatch"),
                prefix:new HarmonyMethod(typeof(SwitchboardStationpedia),nameof(SwitchboardStationpedia.CreativeSearch)));
            harmony.Patch(AccessTools.Method(typeof(Assets.Scripts.UI.StationpediaPage),"IsRegexMatch"),
                prefix:new HarmonyMethod(typeof(SwitchboardStationpedia),nameof(SwitchboardStationpedia.Search)));
            harmony.Patch(AccessTools.Method(typeof(Assets.Scripts.Inventory.InventoryManager),"UpdatePrecisionPlacement",new[]{typeof(DynamicThing)}),
                prefix:new HarmonyMethod(typeof(KitItemPlacement),nameof(KitItemPlacement.BeforePrecisionPlacement)),
                postfix:new HarmonyMethod(typeof(KitItemPlacement),nameof(KitItemPlacement.AfterPrecisionPlacement)));
            harmony.Patch(AccessTools.Method(typeof(Assets.Scripts.Inventory.InventoryManager),"SetMultiConstructorItemPlacement"),
                prefix:new HarmonyMethod(typeof(SwitchboardCoverInput),nameof(SwitchboardCoverInput.PlacementPrefix)));
            harmony.Patch(AccessTools.Method(typeof(Assets.Scripts.Objects.Pipes.Device), "OnDestroy"),
                prefix: new HarmonyMethod(typeof(SwitchboardPrefabs), nameof(SwitchboardPrefabs.AllowNativeDestroy)));
            harmony.Patch(AccessTools.Method(typeof(Thing), "OnDestroy"),
                prefix: new HarmonyMethod(typeof(SwitchboardPrefabs), nameof(SwitchboardPrefabs.AllowNativeDestroy)));
            harmony.Patch(AccessTools.Method(typeof(Interactable),"GetSelection"),
                postfix:new HarmonyMethod(typeof(TransformerDialHitbox),nameof(TransformerDialHitbox.AfterSelection)));
            harmony.Patch(AccessTools.Method(typeof(Interactable),"GetSelection"),
                postfix:new HarmonyMethod(typeof(ModuleFrontHitbox),nameof(ModuleFrontHitbox.AfterSelection)));
            harmony.Patch(AccessTools.Method(typeof(Interactable),"GetSelection"),
                postfix:new HarmonyMethod(typeof(SmartOutputScrewTarget),nameof(SmartOutputScrewTarget.AfterSelection)));
            harmony.Patch(AccessTools.Method(typeof(LibConstruct.PlacementBoard),"FinishLoad"),
                prefix:new HarmonyMethod(typeof(TransformerWidthUpgrade),nameof(TransformerWidthUpgrade.BeforeFinishLoad)));
            harmony.Patch(AccessTools.Method(typeof(LibConstruct.PlacementBoard),"FinishLoad"),
                prefix:new HarmonyMethod(typeof(SmartOutputUpgrade),nameof(SmartOutputUpgrade.BeforeFinishLoad)));
            harmony.Patch(AccessTools.Method(typeof(LibConstruct.PlacementBoard), "CreateBoardStructure"),
                prefix: new HarmonyMethod(typeof(SwitchboardsMod), nameof(ValidateRailCreation)));
            harmony.Patch(AccessTools.Method(typeof(Prefab), "LoadAll"),
                prefix: new HarmonyMethod(typeof(SwitchboardsMod), nameof(PreparePrefabs)));
            harmony.Patch(AccessTools.Method(typeof(DynamicThingRecipeComparable), "GenerateRecipieList"),
                prefix: new HarmonyMethod(typeof(SwitchboardsMod), nameof(PrepareRecipe)));
            harmony.Patch(AccessTools.Method(typeof(Localization), "GetThingName"),
                prefix: new HarmonyMethod(typeof(SwitchboardsMod), nameof(LocalizeName)));
            harmony.Patch(AccessTools.Method(typeof(Localization), "GetThingDescription"),
                prefix: new HarmonyMethod(typeof(SwitchboardsMod), nameof(LocalizeDescription)));
            harmony.Patch(AccessTools.Method(typeof(Structure), "CachePrefabBounds"),
                prefix: new HarmonyMethod(typeof(SwitchboardsMod), nameof(CacheCabinetBounds)));
            harmony.Patch(AccessTools.Method(typeof(Thing), "CacheStates"),
                postfix: new HarmonyMethod(typeof(SmartHousingState), nameof(SmartHousingState.AfterCacheStates)));
            harmony.Patch(AccessTools.Method(typeof(Thing), "CanCacheRenderer"),
                prefix: new HarmonyMethod(typeof(CabinetAppearance), nameof(CabinetAppearance.CanCacheRenderer)));
            harmony.Patch(AccessTools.Method(typeof(CursorManager),"SetCursorTarget"),
                prefix:new HarmonyMethod(typeof(SwitchboardCursorTarget),nameof(SwitchboardCursorTarget.BeforeRaycast)),
                postfix:new HarmonyMethod(typeof(SwitchboardCursorTarget),nameof(SwitchboardCursorTarget.AfterRaycast)));
            harmony.Patch(AccessTools.Method(typeof(Assets.Scripts.Objects.Motherboards.ProgrammableChipMotherboard), "OnInsertedToComputer"),
                prefix:new HarmonyMethod(typeof(SmartEditorDropdown),nameof(SmartEditorDropdown.Track)){priority=Priority.First});
            harmony.Patch(AccessTools.Method(typeof(Assets.Scripts.Objects.Motherboards.ProgrammableChipMotherboard), "HandleDeviceListChange"),
                prefix:new HarmonyMethod(typeof(SmartEditorDropdown),nameof(SmartEditorDropdown.Track)){priority=Priority.First});
            harmony.Patch(AccessTools.Method(typeof(UI.Dropdown.ButtonDropdown), "ItemsChanged"),
                prefix:new HarmonyMethod(typeof(SmartEditorDropdown),nameof(SmartEditorDropdown.BeforeItemsChanged)){priority=Priority.Last});
            SmartDisplayStoreHooks.Configure(harmony);
            SmartLuaRuntime.Configure(harmony);
            harmony.Patch(AccessTools.Method(typeof(Computer), "DeviceList"),
                postfix: new HarmonyMethod(typeof(SmartComputerDevices), nameof(SmartComputerDevices.Filter)));
            harmony.Patch(AccessTools.Method(typeof(Thing), "Awake"),
                postfix: new HarmonyMethod(typeof(CabinetAppearance), nameof(CabinetAppearance.RegisterRenderers)));
            harmony.Patch(AccessTools.Method(typeof(Thing), "DeserializeSave"),
                prefix: new HarmonyMethod(typeof(SwitchboardsMod), nameof(MigrateBreakerName)));
            harmony.Patch(AccessTools.Method(typeof(Structure), "DeserializeSave"),
                prefix: new HarmonyMethod(typeof(SwitchboardsMod), nameof(MigrateCabinetSave)));
            harmony.Patch(AccessTools.Method(typeof(Thing), "SetCustomColor", new[] { typeof(int), typeof(bool) }),
                postfix: new HarmonyMethod(typeof(CabinetAppearance), nameof(CabinetAppearance.RefreshPaint)));
            harmony.Patch(AccessTools.Method(typeof(Thing), "SetCustomColor", new[] { typeof(bool) }),
                postfix: new HarmonyMethod(typeof(CabinetAppearance), nameof(CabinetAppearance.RefreshPaint)));
            harmony.Patch(AccessTools.Method(typeof(Structure), "UpdateAllMaterialPropertyBlocks"),
                postfix: new HarmonyMethod(typeof(CabinetAppearance), nameof(CabinetAppearance.RefreshPaint)));
            harmony.Patch(AccessTools.Method(typeof(Structure), "StructureDestroyed"),
                prefix:new HarmonyMethod(typeof(ModuleDismantle),nameof(ModuleDismantle.Refund)));
            harmony.Patch(AccessTools.Method(typeof(Structure), "AttackWith"),
                prefix: new HarmonyMethod(typeof(CabinetAppearance), nameof(CabinetAppearance.BeginBuildColor)),
                postfix: new HarmonyMethod(typeof(CabinetAppearance), nameof(CabinetAppearance.ApplyCompletedWhite)));
            harmony.Patch(AccessTools.Method(typeof(Assets.Scripts.Inventory.InventoryManager),"NormalMode"),
                prefix:new HarmonyMethod(typeof(CabinetWiringInput),nameof(CabinetWiringInput.ModePrefix)));
            harmony.Patch(AccessTools.Method(typeof(Structure),"CanMountOnWall"),
                prefix:new HarmonyMethod(typeof(CabinetMountOrientation),nameof(CabinetMountOrientation.BeforeMount)));
            harmony.Patch(AccessTools.Method(typeof(Assets.Scripts.Inventory.InventoryManager),"PlacementMode"),
                prefix:new HarmonyMethod(typeof(CabinetWiringInput),nameof(CabinetWiringInput.ModePrefix)),
                postfix:new HarmonyMethod(typeof(ModelPreviewCursor),nameof(ModelPreviewCursor.AfterPlacement)));
            harmony.Patch(AccessTools.Method(typeof(Localization),"GetName",new[]{typeof(Slot)}),
                prefix:new HarmonyMethod(typeof(DinModuleAccess),nameof(DinModuleAccess.SlotName)));
            harmony.Patch(AccessTools.Method(typeof(Thing),"CanEnter",new[]{typeof(Slot)}),
                prefix:new HarmonyMethod(typeof(DinModuleAccess),nameof(DinModuleAccess.CanEnter)));
            CabinetOwnTick.Report=ex=>Debug.LogError("[Modular Switchboards] Transformer control-power accounting stopped: "+ex);
            harmony.Patch(AccessTools.Method(typeof(Assets.Scripts.Networks.ElectricityManager),"ElectricityTick"),
                prefix:new HarmonyMethod(typeof(SwitchboardsMod),nameof(BeforeOwnPowerTick)),
                postfix:new HarmonyMethod(typeof(SwitchboardsMod),nameof(AfterOwnPowerTick)));
            harmony.Patch(AccessTools.Method(typeof(Assets.Scripts.Networks.PowerProvider),"ApplyPower"),
                postfix:new HarmonyMethod(typeof(SwitchboardsMod),nameof(ObserveIdleProvider)));
            Mod.Networking.Required = true;
            Prefab.OnPrefabsLoaded += VerifyRegistration;
            WorldManager.OnGameDataLoaded += VerifyRecipe;
            loaded = true;
            Debug.Log("[Modular Switchboards] " + Version + " loaded.");
        }

        private static T Source<T>(IEnumerable<Thing> sources, string name) where T : Thing
        {
            var result = sources.OfType<T>().FirstOrDefault(p => p.PrefabName == name || p.name == name);
            if (result == null) throw new InvalidOperationException("Missing source prefab: " + name);
            return result;
        }

        private static void Identify(Thing thing, string name, string title)
        {
            thing.name = name;
            thing.PrefabName = name;
            thing.PrefabHash = Animator.StringToHash(name);
            thing.CustomName = SwitchboardNames.Default(name)??title;
            thing.HideInStationpedia=false;
        }

        // Called before LoadAll reads SourcePrefabs. Build complete clones before publishing them.
        private static void PreparePrefabs()
        {
            if (WorldManager.Instance == null)
            {
                Debug.LogError("[Modular Switchboards] WorldManager unavailable.");
                return;
            }
            var sources = WorldManager.Instance.SourcePrefabs;
            CabinetCableCoils.Configure(sources);
            if (sources.Any(p => p != null && p.PrefabName == KitName)) return;
            MultiConstructor kit = null;
            Structure cabinet = null, reverseCabinet=null,mediumCabinet=null,mediumReverseCabinet=null;
            MultiConstructor railKit = null;
            DinRail rail = null;
            MultiConstructor coverKit=null;InnerCoverModule cover=null;PortableCoverItem fittedCover=null;
            MultiConstructor breakerKit = null,smartKit=null;
            var moduleVariants=new List<Structure>();
            DoorLabel doorLabel=null;EmergencyStopLabel emergencyLabel=null;MultiConstructor doorKit=null;DinBreaker doorBridge=null,doorStop=null,doorIsolator=null,doorRoundSwitch=null;var doorLeds=new List<DinBreaker>();
            MultiConstructor labelKit=null;var labelVariants=new List<SwitchboardLabel>();
            DinBreaker breaker = null;
            try
            {
                LibConstructDependency.RequireInitialized();
                foreach (var name in new[] { KitName, CabinetName, ReverseCabinetName, MediumCabinetName, MediumReverseCabinetName, RailKitName, RailName, CoverKitName, CoverName,PortableCoverItem.PrefabId, DoorLabelName, EmergencyStopLabelName, SmartKitName, SmartOutputModel.PrefabName, BreakerKitName, BreakerName, DoorKitName, DoorLedName, DoorLedBlueName, DoorLedWhiteName, DoorLedRedName, DoorStopName, DoorBridgeName, DoorIsolatorName, DoorRoundSwitchName })
                    if (sources.Any(p => p != null && p.PrefabHash == Animator.StringToHash(name)))
                        throw new InvalidOperationException("Prefab identity collision: " + name);
                var kitSource = Source<MultiConstructor>(sources, "ItemKitLogicSwitch");
                var locker = sources.OfType<Locker>().FirstOrDefault(p => p.PrefabName == "StructureLockerSmall")
                    ?? sources.OfType<Locker>().FirstOrDefault(p => p.PrefabName == "StructureLocker")
                    ?? sources.OfType<Locker>().Where(p => p.GetType() == typeof(Locker) &&
                        p.BuildStates != null && p.BuildStates.Count > 0)
                        .OrderBy(p => p.PrefabName, StringComparer.Ordinal).FirstOrDefault();
                if (locker == null) throw new InvalidOperationException("No vanilla Locker prefab with build states found.");
                var wrench = Source<Item>(sources, "ItemWrench");
                var drill = Source<Item>(sources, "ItemDrill");
                var sheets = Source<Item>(sources, "ItemIronSheets");
                var plastic=sources.OfType<Assets.Scripts.Objects.Items.PlasticSheet>().FirstOrDefault();
                if(plastic==null)throw new InvalidOperationException("Native Plastic Sheet prefab unavailable.");

                if (storage == null)
                {
                    storage = new GameObject("ModularSwitchboards.SourcePrefabs");
                    storage.SetActive(false);
                    Object.DontDestroyOnLoad(storage);
                }
                kit = Object.Instantiate(kitSource, storage.transform);
                Identify(kit, KitName, "Kit (Switchboard)");
                kit.SetQuantity(1);
                // Do not transfer the temporary vanilla kit's legacy colour to the new shell.
                // Painting is supported on the assembled cabinet itself.
                kit.PaintableMaterial = null;
                kit.RecipeTier = MachineTier.TierOne;
                cabinet=BuildCabinet(locker,kit,wrench,plastic,sheets,drill,CabinetName,"Switchboard Small");
                reverseCabinet=BuildCabinet(locker,kit,wrench,plastic,sheets,drill,ReverseCabinetName,"Switchboard Small (Reverse)");
                mediumCabinet=BuildCabinet(locker,kit,wrench,plastic,sheets,drill,MediumCabinetName,"Switchboard Medium");
                mediumReverseCabinet=BuildCabinet(locker,kit,wrench,plastic,sheets,drill,MediumReverseCabinetName,"Switchboard Medium (Reverse)");
                coverKit=Object.Instantiate(kitSource,storage.transform);
                Identify(coverKit,CoverKitName,"Kit (Switchboard Cover)");coverKit.SetQuantity(1);
                coverKit.PaintableMaterial=null;coverKit.RecipeTier=MachineTier.TierOne;
                cover=SwitchboardPrefabs.ReplaceComponent<InnerCoverModule>(Object.Instantiate<Structure>(locker,storage.transform));
                Identify(cover,CoverName,"Switchboard Cover");
                cover.BuildStates=new List<BuildState>{MakeState(cover.BuildStates.Last(),coverKit,1,null,0,wrench)};
                cover.UpgradePrefab=null;InnerCoverModule.Install(cover,storage.transform);
                fittedCover=SwitchboardPrefabs.ReplaceItem<PortableCoverItem>(Object.Instantiate<Item>(kitSource,storage.transform));
                Identify(fittedCover,PortableCoverItem.PrefabId,"Fitted Switchboard Cover");PortableCoverItem.Install(fittedCover);
                coverKit.Constructables=new List<Structure>{cover};coverKit.LastSelectedIndex=0;
                coverKit.Thumbnail=kitSource.Thumbnail;coverKit.Thumbnails=kitSource.Thumbnails;

                railKit = Object.Instantiate(kitSource, storage.transform);
                Identify(railKit, RailKitName, "Kit (Switchboard Rails)");
                railKit.SetQuantity(1); railKit.PaintableMaterial = null; railKit.RecipeTier = MachineTier.TierOne;
                rail = SwitchboardPrefabs.ReplaceComponent<DinRail>(Object.Instantiate<Structure>(locker, storage.transform));
                Identify(rail, RailName, "Switchboard Rail");
                rail.BuildStates = new List<BuildState> { MakeState(rail.BuildStates.Last(), railKit, 1, null, 0, drill) };
                rail.UpgradePrefab = null;
                DinRailModel.Install(rail, storage.transform);
                railKit.Constructables = new List<Structure> { rail }; railKit.LastSelectedIndex = 0;
                railKit.Thumbnail=kitSource.Thumbnail;railKit.Thumbnails=kitSource.Thumbnails;
                breakerKit = Object.Instantiate(kitSource, storage.transform);
                Identify(breakerKit, BreakerKitName, "Kit (Switchboard Modules)");
                breakerKit.SetQuantity(1); breakerKit.PaintableMaterial = null; breakerKit.RecipeTier = MachineTier.TierOne;
                // Keep the original Logic Kit mesh/icon until Smart has more variants.
                smartKit=Object.Instantiate(kitSource,storage.transform);
                Identify(smartKit,SmartKitName,"Kit (DIN Smart Modules)");
                smartKit.SetQuantity(1);smartKit.PaintableMaterial=null;smartKit.RecipeTier=MachineTier.TierOne;
                smartKit.Thumbnail=kitSource.Thumbnail;smartKit.Thumbnails=kitSource.Thumbnails;
                var moduleSpecs=DinModuleCatalog.Discover(sources);
                foreach(var spec in moduleSpecs)
                {
                    if(spec.Transformer)
                    {
                        var transformers=sources.OfType<Assets.Scripts.Objects.Electrical.Transformer>().Where(t=>t.PrefabName.StartsWith("StructureTransformer",System.StringComparison.Ordinal)).ToArray();
                        var small=transformers.First(t=>t.PrefabName=="StructureTransformerSmall");
                        var transformer=SwitchboardPrefabs.ReplaceComponent<DinTransformer>(Object.Instantiate<Structure>(small,storage.transform));
                        moduleVariants.Add(transformer);Identify(transformer,spec.Name,spec.Title);transformer.MediumVariant=spec.MediumTransformer;transformer.ModuleWidth=transformer.TargetSlots;
                        transformer.BuildStates=new List<BuildState>{MakeState(transformer.BuildStates.Last(),breakerKit,DinTransformer.BuildKits,null,0,drill)};
                        transformer.HideInStationpedia=false;transformer.UpgradePrefab=null;DinTransformerModel.Install(transformer,small,storage.transform,spec.MediumTransformer?transformers.First(t=>t.PrefabName=="StructureTransformerMedium"):small);continue;
                    }
                    if(spec.SmartContactor)
                    {
                        var native=sources.OfType<Assets.Scripts.Objects.Electrical.LogicDisplay>().First(p=>p.PrefabName=="StructureConsoleLED5");
                        var contactor=SwitchboardPrefabs.ReplaceComponent<SmartContactor>(Object.Instantiate<Structure>(native,storage.transform));
                        moduleVariants.Add(contactor);Identify(contactor,spec.Name,spec.Title);
                        contactor.BuildStates=new List<BuildState>{MakeState(contactor.BuildStates.Last(),smartKit,1,null,0,drill)};
                        contactor.HideInStationpedia=false;contactor.UpgradePrefab=null;SmartContactorModel.Install(contactor,storage.transform,moduleVariants.OfType<SmartModule>().Single(),moduleVariants.OfType<DinBreaker>().Single(d=>d.IsSmartOutputModule));ModelBlueprint.Refresh(contactor);continue;
                    }
                    if(spec.Smart)
                    {
                        var nativeDisplay=sources.OfType<Assets.Scripts.Objects.Electrical.LogicDisplay>().First(p=>p.PrefabName=="StructureConsoleLED5");
                        var smart=SwitchboardPrefabs.ReplaceComponent<SmartModule>(Object.Instantiate<Structure>(nativeDisplay,storage.transform));
                        moduleVariants.Add(smart);Identify(smart,spec.Name,spec.Title);
                        smart.BuildStates=new List<BuildState>{MakeState(smart.BuildStates.Last(),smartKit,DinSmartLayout.BuildKits,null,0,drill)};
                        smart.HideInStationpedia=false;smart.UpgradePrefab=null;
                        SmartModuleModel.Install(smart,storage.transform);ModelBlueprint.Refresh(smart);
                        continue;
                    }

                    var module=SwitchboardPrefabs.ReplaceComponent<DinBreaker>(Object.Instantiate<Structure>(locker, storage.transform));
                    moduleVariants.Add(module);Identify(module,spec.Name,spec.Title);
                    module.IsContactor=spec.Contactor;module.HasNormallyClosedContact=spec.NormallyClosed;module.RatedWatts=spec.Watts;module.IsFuseHolder=spec.Fuse;module.IsBatteryModule=spec.Battery;module.IsAnalyserModule=spec.Analyser;module.IsSmartModule=spec.Smart;module.IsSmartOutputModule=spec.SmartOutput;module.AllowedFuseKits=spec.FuseKits;
                    module.BuildStates=new List<BuildState>{MakeState(module.BuildStates.Last(),spec.SmartOutput?smartKit:breakerKit,spec.Width,null,0,drill)};
                    module.HideInStationpedia=!spec.Selectable;module.UpgradePrefab=null;DinBreakerModel.Install(module,storage.transform);DinModuleAccess.Install(module);if(spec.Battery)DinBatteryModel.Install(module);if(spec.Analyser)DinAnalyserModel.Install(module);if(spec.Smart)DinSmartModel.Install(module);if(spec.Contactor)DinContactorModel.Install(module);if(spec.SmartOutput)SmartOutputModel.Install(module,CabinetIcons.Get("DinSmartNet"));ModelBlueprint.Refresh(module);
                    if(spec.Name==BreakerName)breaker=module;
                }
                breakerKit.Constructables=moduleVariants.Where(m=>DinModuleCatalog.Specs[m.PrefabName].Selectable&&!DinModuleCatalog.Specs[m.PrefabName].Smart&&!DinModuleCatalog.Specs[m.PrefabName].SmartOutput&&!DinModuleCatalog.Specs[m.PrefabName].SmartContactor).Cast<Structure>().ToList();breakerKit.LastSelectedIndex=0;
                smartKit.Constructables=moduleVariants.Where(m=>m is SmartModule||m is SmartContactor||m is DinBreaker d&&d.IsSmartOutputModule).ToList();smartKit.LastSelectedIndex=0;
                breakerKit.Thumbnail=kitSource.Thumbnail;breakerKit.Thumbnails=kitSource.Thumbnails;
                doorKit=Object.Instantiate(kitSource,storage.transform);Identify(doorKit,DoorKitName,SwitchboardNames.DoorKitTitle);doorKit.SetQuantity(1);doorKit.RecipeTier=MachineTier.TierOne;
                foreach(var color in DoorLedColours.All)
                {
                    var led=SwitchboardPrefabs.ReplaceComponent<DinBreaker>(Object.Instantiate<Structure>(locker,storage.transform));doorLeds.Add(led);
                    Identify(led,color.Name,color.Title);led.IsDoorLed=true;
                    led.BuildStates=new List<BuildState>{MakeState(led.BuildStates.Last(),doorKit,1,null,0,drill)};led.UpgradePrefab=null;
                    DoorModules.Install(led,storage.transform);
                }
                doorStop=SwitchboardPrefabs.ReplaceComponent<DinBreaker>(Object.Instantiate<Structure>(locker,storage.transform));Identify(doorStop,DoorStopName,"Door TOTAL STOP");doorStop.IsDoorStop=true;
                doorStop.BuildStates=new List<BuildState>{MakeState(doorStop.BuildStates.Last(),doorKit,1,null,0,drill)};doorStop.UpgradePrefab=null;DoorModules.Install(doorStop,storage.transform);
                doorBridge=SwitchboardPrefabs.ReplaceComponent<DinBreaker>(Object.Instantiate<Structure>(locker,storage.transform));Identify(doorBridge,DoorBridgeName,"Door Bridge");doorBridge.IsDoorBridge=true;
                doorBridge.BuildStates=new List<BuildState>{MakeState(doorBridge.BuildStates.Last(),doorKit,1,null,0,drill)};doorBridge.UpgradePrefab=null;DoorModules.Install(doorBridge,storage.transform);
                doorIsolator=SwitchboardPrefabs.ReplaceComponent<DinBreaker>(Object.Instantiate<Structure>(locker,storage.transform));Identify(doorIsolator,DoorIsolatorName,"Door Main Switch");doorIsolator.IsDoorIsolator=true;
                doorIsolator.BuildStates=new List<BuildState>{MakeState(doorIsolator.BuildStates.Last(),doorKit,1,null,0,drill)};doorIsolator.UpgradePrefab=null;DoorModules.Install(doorIsolator,storage.transform);
                doorRoundSwitch=SwitchboardPrefabs.ReplaceComponent<DinBreaker>(Object.Instantiate<Structure>(locker,storage.transform));Identify(doorRoundSwitch,DoorRoundSwitchName,"Door Round Switch");doorRoundSwitch.IsDoorIsolator=true;doorRoundSwitch.IsDoorRoundSwitch=true;
                doorRoundSwitch.BuildStates=new List<BuildState>{MakeState(doorRoundSwitch.BuildStates.Last(),doorKit,1,null,0,drill)};doorRoundSwitch.UpgradePrefab=null;DoorModules.Install(doorRoundSwitch,storage.transform);
                doorKit.Constructables=doorLeds.Take(3).Cast<Structure>().Concat(new Structure[]{doorStop,doorBridge}).Concat(doorLeds.Skip(3)).Concat(new Structure[]{doorIsolator,doorRoundSwitch}).ToList();doorKit.LastSelectedIndex=0;doorKit.Thumbnail=kitSource.Thumbnail;doorKit.Thumbnails=kitSource.Thumbnails;
                labelKit=Object.Instantiate(kitSource,storage.transform);Identify(labelKit,LabelKitName,"Kit (Switchboard Labels)");labelKit.SetQuantity(1);labelKit.PaintableMaterial=null;labelKit.RecipeTier=MachineTier.TierOne;
                foreach(int width in new[]{1,2,3,4,6}){
                    var label=SwitchboardPrefabs.ReplaceComponent<SwitchboardLabel>(Object.Instantiate<Structure>(locker,storage.transform));labelVariants.Add(label);label.Width=width;Identify(label,LabelName(width),SwitchboardNames.LabelTitle(width));label.HideInStationpedia=false;
                    label.BuildStates=new List<BuildState>{MakeState(label.BuildStates.Last(),labelKit,1,null,0,drill)};label.UpgradePrefab=null;InnerCoverModule.Install(label,storage.transform);label.Thumbnail=CabinetIcons.Get("Label"+width);label.BuildStates[0].Thumbnail=label.Thumbnail;SwitchboardLabelView.Install(label);
                }
                doorLabel=SwitchboardPrefabs.ReplaceComponent<DoorLabel>(Object.Instantiate<Structure>(locker,storage.transform));Identify(doorLabel,DoorLabelName,"Door Label");
                doorLabel.BuildStates=new List<BuildState>{MakeState(doorLabel.BuildStates.Last(),labelKit,1,null,0,drill)};doorLabel.UpgradePrefab=null;InnerCoverModule.Install(doorLabel,storage.transform);DoorLabel.SetBounds(doorLabel);doorLabel.Thumbnail=CabinetIcons.Get("DoorLabel");doorLabel.BuildStates[0].Thumbnail=doorLabel.Thumbnail;DoorLabelView.Install(doorLabel);
                emergencyLabel=SwitchboardPrefabs.ReplaceComponent<EmergencyStopLabel>(Object.Instantiate<Structure>(locker,storage.transform));Identify(emergencyLabel,EmergencyStopLabelName,"Emergency Stop Label");
                emergencyLabel.BuildStates=new List<BuildState>{MakeState(emergencyLabel.BuildStates.Last(),labelKit,1,null,0,drill)};emergencyLabel.UpgradePrefab=null;InnerCoverModule.Install(emergencyLabel,storage.transform);DoorLabel.SetBounds(emergencyLabel);emergencyLabel.Thumbnail=CabinetIcons.Get("EmergencyStopLabel");emergencyLabel.BuildStates[0].Thumbnail=emergencyLabel.Thumbnail;EmergencyStopLabelView.Install(emergencyLabel);
                labelKit.Constructables=labelVariants.Cast<Structure>().Concat(new Structure[]{doorLabel,emergencyLabel}).ToList();labelKit.LastSelectedIndex=0;
                labelKit.Thumbnail=kitSource.Thumbnail;labelKit.Thumbnails=kitSource.Thumbnails;SwitchboardKitModel.Install(labelKit,SwitchboardKitKind.Labels);
                kit.Constructables = new List<Structure> { cabinet, reverseCabinet,mediumCabinet,mediumReverseCabinet };
                kit.LastSelectedIndex = 0;
                kit.Thumbnail = kitSource.Thumbnail;
                kit.Thumbnails = kitSource.Thumbnails;
                SwitchboardKitModel.Install(kit,SwitchboardKitKind.Cabinet);
                SwitchboardKitModel.Install(railKit,SwitchboardKitKind.Rails);
                SwitchboardKitModel.Install(breakerKit,SwitchboardKitKind.Modules);
                SwitchboardKitModel.Install(smartKit,SwitchboardKitKind.Smart);
                SwitchboardKitModel.Install(coverKit,SwitchboardKitKind.Cover);
                SwitchboardKitModel.Install(doorKit,SwitchboardKitKind.Doors);
                sources.Add(kit);
                sources.Add(cabinet);sources.Add(reverseCabinet);sources.Add(mediumCabinet);sources.Add(mediumReverseCabinet);
                sources.Add(coverKit);sources.Add(cover);sources.Add(fittedCover);
                sources.Add(labelKit);sources.AddRange(labelVariants);sources.Add(doorLabel);sources.Add(emergencyLabel);
                sources.Add(doorKit);sources.AddRange(doorLeds);sources.Add(doorStop);sources.Add(doorBridge);sources.Add(doorIsolator);sources.Add(doorRoundSwitch);
                sources.Add(railKit);
                sources.Add(rail);
                sources.Add(breakerKit);sources.Add(smartKit);
                sources.AddRange(moduleVariants);
                Debug.Log("[Modular Switchboards] Prepared kit + 2-stage empty cabinet with Blender geometry; native base: " + locker.PrefabName);
            }
            catch (Exception ex)
            {
                // Never publish a partially configured prefab pair.
                if(doorKit!=null){sources.Remove(doorKit);Object.Destroy(doorKit.gameObject);}
                if(doorRoundSwitch!=null){sources.Remove(doorRoundSwitch);Object.Destroy(doorRoundSwitch.gameObject);}
                if(doorIsolator!=null){sources.Remove(doorIsolator);Object.Destroy(doorIsolator.gameObject);}
                if(doorStop!=null){sources.Remove(doorStop);Object.Destroy(doorStop.gameObject);}
                if(doorBridge!=null){sources.Remove(doorBridge);Object.Destroy(doorBridge.gameObject);}
                foreach(var led in doorLeds){sources.Remove(led);if(led!=null)Object.Destroy(led.gameObject);}
                if(emergencyLabel!=null){sources.Remove(emergencyLabel);Object.Destroy(emergencyLabel.gameObject);}
                if(doorLabel!=null){sources.Remove(doorLabel);Object.Destroy(doorLabel.gameObject);}
                if(labelKit!=null){sources.Remove(labelKit);Object.Destroy(labelKit.gameObject);}
                foreach(var label in labelVariants){sources.Remove(label);if(label!=null)Object.Destroy(label.gameObject);}
                if(coverKit!=null){sources.Remove(coverKit);Object.Destroy(coverKit.gameObject);}
                if(cover!=null){sources.Remove(cover);Object.Destroy(cover.gameObject);}
                if(fittedCover!=null){sources.Remove(fittedCover);Object.Destroy(fittedCover.gameObject);}
                if (kit != null) { sources.Remove(kit); Object.Destroy(kit.gameObject); }
                if (cabinet != null) { sources.Remove(cabinet); Object.Destroy(cabinet.gameObject); }
                if(reverseCabinet!=null){sources.Remove(reverseCabinet);Object.Destroy(reverseCabinet.gameObject);}
                if(mediumReverseCabinet!=null){sources.Remove(mediumReverseCabinet);Object.Destroy(mediumReverseCabinet.gameObject);}
                if(mediumCabinet!=null){sources.Remove(mediumCabinet);Object.Destroy(mediumCabinet.gameObject);}
                if (railKit != null) { sources.Remove(railKit); Object.Destroy(railKit.gameObject); }
                if (rail != null) { sources.Remove(rail); Object.Destroy(rail.gameObject); }
                if(smartKit!=null){sources.Remove(smartKit);Object.Destroy(smartKit.gameObject);}
                if (breakerKit != null) { sources.Remove(breakerKit); Object.Destroy(breakerKit.gameObject); }
                foreach(var module in moduleVariants){sources.Remove(module);if(module!=null)Object.Destroy(module.gameObject);}
                Debug.LogError("[Modular Switchboards] Prefab setup failed: " + ex);
            }
        }

        private static SwitchboardCabinet BuildCabinet(Structure locker,MultiConstructor kit,Item wrench,Item plastic,Item sheets,Item drill,string prefabName,string title)
        {
                var cabinet = SwitchboardPrefabs.ReplaceComponent<SwitchboardCabinet>(Object.Instantiate<Structure>(locker, storage.transform));
            try
            {
                Identify(cabinet, prefabName, title);
                if (cabinet.BuildStates == null || cabinet.BuildStates.Count == 0)
                    throw new InvalidOperationException("Locker has no build state visuals.");

                // Copy from the cloned prefab: its renderer/collider references already point to the clone.
                var visual = cabinet.BuildStates[cabinet.BuildStates.Count - 1];
                cabinet.BuildStates = new List<BuildState>
                {
                    MakeState(visual, kit, CabinetShape.FrameKits(prefabName), null, 0, drill),
                    MakeState(visual, wrench, 0, plastic, CabinetShape.PlasticSheets(prefabName), drill)
                };
                cabinet.UpgradePrefab = null;
                // This is a cabinet shell, not a general-purpose storage locker.
                cabinet.Slots = new List<Slot>();
                cabinet.Interactables = cabinet.Interactables.Where(i => i != null && i.Slot == null).ToList();
                CabinetModel.Install(cabinet);
                if(CabinetShape.Medium(prefabName))MediumGeometry.Install(cabinet);
                cabinet.gameObject.AddComponent<CabinetMountOrientation>();
                NativeRearBox.Install((SwitchboardCabinet)cabinet);
                OvenInputPanel.Install((SwitchboardCabinet)cabinet);
                OvenInputSupport.Install((SwitchboardCabinet)cabinet);
                ((SwitchboardCabinet)cabinet).PortBodyGrids=(Assets.Scripts.GridSystem.Grid3[])cabinet.GetLocalSmallGridBounds();
                ExternalCablePorts.InstallRearBody((SwitchboardCabinet)cabinet);
                ExternalCablePorts.TryInstall((SwitchboardCabinet)cabinet);
                CabinetPowerOutputs.TryInstall((SwitchboardCabinet)cabinet);
                CabinetPreview.Install(cabinet);
                CabinetNameplate.Install((SwitchboardCabinet)cabinet);
                CabinetTerminalBlocks.Install((SwitchboardCabinet)cabinet);
                var host = (SwitchboardCabinet)cabinet;
                var origin = new GameObject("DinRailBoard") { layer = cabinet.gameObject.layer };
                origin.transform.SetParent(cabinet.transform.Find("SwitchboardModel/CompletedShell"), false);
                origin.transform.localPosition = new Vector3(0f, 0f, .014f);
                host.RailOrigin = origin.transform;
                host.RailSurface = origin.AddComponent<BoxCollider>();
                host.RailSurface.size = new Vector3(CabinetShape.InnerWidth(prefabName),CabinetShape.Height(prefabName)-.07f,.002f);
                cabinet.BuildStates[1].Colliders.Add(host.RailSurface);
                RailPlacementSurfaces.Install(host,origin.transform);
                // Retain stage 2 solely to read/remove existing 0.12.94 covers.
                var legacyCover=MakeState(cabinet.BuildStates[1],null,0,sheets,1,wrench);
                CabinetInnerCover.Install(host,legacyCover);
                var coverOrigin=new GameObject("InnerCoverBoard"){layer=cabinet.gameObject.layer};
                coverOrigin.transform.SetParent(cabinet.transform.Find("SwitchboardModel/CompletedShell"),false);
                host.CoverOrigin=coverOrigin.transform;host.CoverSurface=coverOrigin.AddComponent<BoxCollider>();
                host.CoverSurface.center=new Vector3(0,0,host.CoverProfile.Depth);
                host.CoverSurface.size=new Vector3(host.CoverProfile.Width,host.CoverProfile.Height,host.CoverProfile.Sheet*.5f);host.CoverSurface.enabled=false;
                cabinet.BuildStates[1].Colliders.Add(host.CoverSurface);legacyCover.Colliders.Add(host.CoverSurface);
                DoorModules.InstallBoard(host);
                return host;
            }
            catch
            {
                if(cabinet.Blueprint!=null&&cabinet.Blueprint.transform.parent==storage.transform)Object.DestroyImmediate(cabinet.Blueprint);
                Object.DestroyImmediate(cabinet.gameObject);throw;
            }
        }

        private static BuildState MakeState(BuildState visual, Item entry, int quantity,
            Item entry2, int quantity2, Item exit)
        {
            // Preserve private batched drawing data, but give each stage its own mutable collections/tool.
            var state = (BuildState)CloneMethod.Invoke(visual, null);
            state.StateMeshes = new List<Mesh>(visual.StateMeshes);
            state.Colliders = new List<Collider>(visual.Colliders);
            state.LinkedGameObjects = new List<GameObject>(visual.LinkedGameObjects);
            state.Interactables = visual.Interactables == null ? new List<Interactable>() :
                visual.Interactables.Where(i => i != null && i.Slot == null).ToList();
            state.RendererInstance = null;
            state.RenderMode = BuildStateRenderMode.OnMyState;
            state.CanManufacture = false;
            state.Tool = new ToolUse
            {
                ToolEntry = entry, EntryQuantity = quantity,
                ToolEntry2 = entry2, EntryQuantity2 = quantity2,
                ToolExit = exit, ExitQuantity = 0, EntryTime = 2f, ExitTime = 2f
            };
            return state;
        }

        // Runs after game/mod recipe files have loaded and before tier lists and recipe hashes are generated.
        private static void PrepareRecipe(DynamicThingRecipeComparable __instance)
        {
            if (!ReferenceEquals(__instance, ElectronicsPrinter.RecipeComparable)) return;
            var smartKit=Prefab.Find<MultiConstructor>(SmartKitName);
            if(smartKit!=null&&!__instance.AllRecipes.ContainsKey(smartKit))__instance.AddRecipe(SmartKitRecipe.Create(),null);
            var doorKit=Prefab.Find<MultiConstructor>(DoorKitName);
            if(doorKit!=null&&!__instance.AllRecipes.ContainsKey(doorKit))__instance.AddRecipe(new WorldManager.RecipeData{PrefabName=DoorKitName,RecipeTier=MachineTier.TierOne,Output=1f,Recipe=new Recipe{Iron=2,Copper=1,Time=3f,Energy=400f}},null);
            var labelKit=Prefab.Find<MultiConstructor>(LabelKitName);
            if(labelKit!=null&&!__instance.AllRecipes.ContainsKey(labelKit))__instance.AddRecipe(new WorldManager.RecipeData{PrefabName=LabelKitName,RecipeTier=MachineTier.TierOne,Output=1f,Recipe=new Recipe{Iron=1,Time=2f,Energy=200f}},null);
            var coverKit=Prefab.Find<MultiConstructor>(CoverKitName);
            var kit = Prefab.Find<MultiConstructor>(KitName);
            var railKit = Prefab.Find<MultiConstructor>(RailKitName);
            if (railKit != null && !__instance.AllRecipes.ContainsKey(railKit))
                __instance.AddRecipe(new WorldManager.RecipeData {
                    PrefabName = RailKitName, RecipeTier = MachineTier.TierOne, Output = 1f,
                    Recipe = new Recipe { Iron = 1, Time = 2f, Energy = 200f }
                }, null);
            if(coverKit!=null&&!__instance.AllRecipes.ContainsKey(coverKit))
                __instance.AddRecipe(new WorldManager.RecipeData{PrefabName=CoverKitName,RecipeTier=MachineTier.TierOne,Output=1f,
                    Recipe=new Recipe{Iron=1,Time=2f,Energy=200f}},null);
            var breakerKit = Prefab.Find<MultiConstructor>(BreakerKitName);
            if (breakerKit != null && !__instance.AllRecipes.ContainsKey(breakerKit))
                __instance.AddRecipe(new WorldManager.RecipeData {
                    PrefabName = BreakerKitName, RecipeTier = MachineTier.TierOne, Output = 1f,
                    Recipe = new Recipe { Iron = 2, Copper = 1, Time = 3f, Energy = 400f }
                }, null);
            if (kit == null || __instance.AllRecipes.ContainsKey(kit)) return;
            var recipe = new WorldManager.RecipeData
            {
                PrefabName = KitName, RecipeTier = MachineTier.TierOne, Output = 1f,
                Recipe = new Recipe { Iron = 10, Copper = 10, Electrum = 10, Time = 5f, Energy = 1000f }
            };
            if (__instance.AddRecipe(recipe, null))
                Debug.Log("[Modular Switchboards] Electronics Printer recipe added: 10 Copper + 10 Iron + 10 Electrum -> 1 kit.");
        }

        private static void BeforeOwnPowerTick(){if(GameManager.RunSimulation)CabinetOwnTick.Begin();}
        private static void AfterOwnPowerTick(){if(GameManager.RunSimulation)CabinetOwnTick.End();}
        private static void ObserveIdleProvider(Assets.Scripts.Networks.PowerProvider __instance)
        {
            if(__instance.Device is SwitchboardCabinet cabinet&&__instance.EnergyUsed<=0)cabinet.Wiring.Power.ObserveIdle(__instance.CableNetwork);
        }

        private static bool LocalizeName(string __0, ref string __result)
        {
            if(__0==PortableCoverItem.PrefabId){__result="Fitted Switchboard Cover";return false;}
            if(__0==DoorKitName)__result=SwitchboardNames.DoorKitTitle;
            else if(__0==DoorRoundSwitchName)__result="Door Round Switch";
            else if(__0==DoorIsolatorName)__result="Door Main Switch";
            else if(__0==DoorStopName)__result="Door TOTAL STOP";
            else if(__0==DoorBridgeName)__result="Door Bridge";
            else if(DoorLedColours.Find(__0) is DoorLedColour ledColor)__result=ledColor.Title;
            else if(__0==EmergencyStopLabelName)__result="Emergency Stop Label";
            else if(__0==DoorLabelName)__result="Door Label";
            else if (__0 == LabelKitName)__result="Kit (Switchboard Labels)";
            else if(__0!=null&&__0.StartsWith("StructureSwitchboardLabel")&&int.TryParse(__0.Substring("StructureSwitchboardLabel".Length),out int labelWidth)&&labelWidth>=1&&(labelWidth<=4||labelWidth==6))__result=SwitchboardNames.LabelTitle(labelWidth);
            else if (__0 == KitName) __result = "Kit (Switchboard)";
            else if(__0==CoverKitName)__result="Kit (Switchboard Cover)";
            else if(__0==CoverName)__result="Switchboard Cover";
            else if (__0 == RailKitName) __result = "Kit (Switchboard Rails)";
            else if (__0 == RailName) __result = "Switchboard Rail";
            else if(__0==SmartKitName)__result="Kit (DIN Smart Modules)";
            else if (__0 == BreakerKitName) __result = "Kit (Switchboard Modules)";
            else if (DinModuleCatalog.Specs.TryGetValue(__0,out var spec)) __result = spec.Title;
            else if (__0 == CabinetName) __result = "Switchboard Small";
            else if(__0==MediumReverseCabinetName)__result="Switchboard Medium (Reverse)";
            else if(__0==MediumCabinetName)__result="Switchboard Medium";
            else if(__0==ReverseCabinetName)__result="Switchboard Small (Reverse)";
            else return true;
            return false;
        }

        private static bool LocalizeDescription(string __0, ref string __result)
        {
            if(__0==DinTransformer.PrefabNameId||__0==DinTransformer.MediumPrefabNameId)
            {
                bool medium=__0==DinTransformer.MediumPrefabNameId;
                __result=Localization.GetThingDescription(medium?"StructureTransformerMedium":"StructureTransformerSmall")+
                    "\n\n<color=yellow>DIN: "+(medium?"6":"4")+" positions.</color> Dial: <color=yellow>100 W steps</color>, or <color=yellow>10 W</color> with the quantity modifier. <color=yellow>Setting 0 stops OUT only.</color> Control electronics still consume power while IN has a supply.";
                return false;
            }
            if(__0==PortableCoverItem.PrefabId){__result="A finished switchboard cover. Preserves its labels, text, colour and label-retained openings. Fit on an open cabinet of the same size; current modules add their own openings. Remove a label to release its retained aperture. An unlabelled cover dismantles into the normal cover kit.";return false;}
            var text=SwitchboardDescriptions.Get(__0);
            if(text==null)return true;
            __result=text;
            return false;
        }

        private static void MigrateBreakerName(Thing __instance, ThingSaveData __0)
        {
            __0.CustomName=SwitchboardNames.Migrate(__instance.PrefabName,__0.CustomName);
            // Previously modules had fixed white casings, while the hidden native
            // color could come from the locker template. Migrate old saves once.
            if(__instance is DinBreaker && __0 is DinBreakerSaveData paintSave && paintSave.BodyPaintVersion<1)
                __0.CustomColorIndex=(int)Assets.Scripts.Objects.Motherboards.ColorType.White;
            // The transformer previously bypassed the module paint registration.
            // Discard that legacy hidden template colour once, as for breakers.
            if(__instance is DinTransformer && __0 is DinTransformerSaveData transformerPaintSave && transformerPaintSave.BodyPaintVersion<1)
                __0.CustomColorIndex=(int)Assets.Scripts.Objects.Motherboards.ColorType.White;


            if(__instance.PrefabName==CabinetName && (__0.CustomName=="Switchboard Cabinet" || __0.CustomName=="Switchboard")) __0.CustomName="Switchboard Small";
            if(DinModuleCatalog.Specs.TryGetValue(__instance.PrefabName,out var spec)&&(__0.CustomName=="DIN Breaker 1P"||__0.CustomName=="DIN Breaker")) __0.CustomName=spec.Title;
            // Migrate only the old default titles; preserve player custom names.
            if((__instance.PrefabName=="StructureDinBatteryBackup"&&__0.CustomName=="DIN Battery Backup (2 slots)")||
                (__instance.PrefabName=="StructureDinCableAnalyser"&&__0.CustomName=="DIN Cable Analyzer (3 slots)"))
                __0.CustomName=DinModuleCatalog.Specs[__instance.PrefabName].Title;
            if(__instance.PrefabName==BreakerKitName && (__0.CustomName=="Kit (DIN Breaker 1P)"||__0.CustomName=="Kit (DIN Breaker)")) __0.CustomName="Kit (Switchboard Modules)";
        }

        private static void MigrateCabinetSave(Structure __instance, ThingSaveData __0)
        {
            if (IsCabinetName(__instance.PrefabName) && __0 is StructureSaveData save && save.CurrentBuildState > 1 && (save.CurrentBuildState>2 || !(__0 is SwitchboardCabinetSaveData coverSave) || coverSave.CoverSchema<1))
            {
                save.CurrentBuildState = 1;
                Debug.Log("[Modular Switchboards] Migrated legacy completed cabinet to simple completed shell.");
            }
        }

        // Validate on the authority before LibConstruct consumes the kit, including multiplayer messages.
        private static bool ValidateRailCreation(LibConstruct.CreateBoardStructureInstance __0)
        {
            if(__0.StructurePrefab is DoorLabel targetLabel)return __0.Constructor!=null&&__0.Constructor.PrefabName==LabelKitName&&DoorLabel.CanPlace(__0.Board,__0.Position,__0.Rotation,targetLabel is EmergencyStopLabel);
            if(__0.StructurePrefab is SwitchboardLabel label)return __0.Constructor!=null&&__0.Constructor.PrefabName==LabelKitName&&SwitchboardLabel.CanPlace(__0.Board,__0.Position,__0.Rotation,label.Width);
            if(__0.StructurePrefab is InnerCoverModule)
                return __0.Constructor!=null&&__0.Constructor.PrefabName==CoverKitName&&InnerCoverModule.CanPlace(__0.Board,__0.Position,__0.Rotation);
            if(__0.StructurePrefab is DinBreaker led&&led.IsDoorPart)return __0.Constructor!=null&&__0.Constructor.PrefabName==DoorKitName&&DoorModules.CanPlace(__0.Board,__0.Position,__0.Rotation,led.IsDoorBridge);
            if(__0.StructurePrefab is SmartContactor)
                return __0.Constructor!=null&&__0.Constructor.PrefabName==SmartKitName&&__0.Board is DinModuleBoard contactorBoard&&SmartBus.CanPlacePowerOutput(contactorBoard,__0.Position,__0.Rotation);
            if(__0.StructurePrefab is DinTransformer targetTransformer)
                return __0.Constructor!=null&&__0.Constructor.PrefabName==BreakerKitName&&__0.Board is DinModuleBoard transformerBoard&&transformerBoard.CanPlace(__0.Position,__0.Rotation,targetTransformer.TargetSlots);
            if(__0.StructurePrefab is SmartModule)
                return __0.Constructor!=null&&__0.Constructor.PrefabName==SmartKitName&&
                    __0.Board is DinModuleBoard smartBoard&&smartBoard.CanPlace(__0.Position,__0.Rotation,4);
            if(__0.StructurePrefab is DinBreaker extension&&extension.IsSmartOutputModule)
                return __0.Constructor!=null&&__0.Constructor.PrefabName==SmartKitName&&__0.Board is DinModuleBoard outputBoard&&SmartBus.CanPlace(outputBoard,__0.Position,__0.Rotation);
            if (__0.StructurePrefab is DinBreaker module)
                return __0.Constructor != null && __0.Constructor.PrefabName == BreakerKitName &&
                    DinBreaker.CanPlace(__0.Board, __0.Position, __0.Rotation,module.ModuleWidth);
            if (!(__0.StructurePrefab is DinRail)) return true;
            return __0.Constructor != null && __0.Constructor.PrefabName == RailKitName &&
                DinRail.CanPlace(__0.Board, __0.Position, __0.Rotation);
        }

        private static bool CacheCabinetBounds(Structure __instance)
        {
            if(__instance is DoorLabel doorLabel){DoorLabel.SetBounds(doorLabel);return false;}
            if(__instance is SwitchboardLabel label){SwitchboardLabel.SetBounds(label);return false;}
            if (!IsCabinetName(__instance.PrefabName)) return true;
            CabinetModel.SetBounds(__instance);
            return false;
        }

        // Register clones source prefabs. Cross-prefab references can still point to the source;
        // compare stable identity instead of Unity object identity.
        private static bool SamePrefab(Structure candidate, Structure registered)
        {
            return candidate != null && registered != null &&
                candidate.PrefabHash == registered.PrefabHash && candidate.PrefabName == registered.PrefabName;
        }

        private static void VerifyRegistration()
        {
            var doorKit=Prefab.Find<MultiConstructor>(DoorKitName);var bridge=Prefab.Find<DinBreaker>(DoorBridgeName);
            var stop=Prefab.Find<DinBreaker>(DoorStopName);
            var isolator=Prefab.Find<DinBreaker>(DoorIsolatorName);
            var round=Prefab.Find<DinBreaker>(DoorRoundSwitchName);
            var leds=DoorLedColours.All.Select(c=>Prefab.Find<DinBreaker>(c.Name)).ToArray();
            if(doorKit==null||bridge==null||!bridge.IsDoorBridge||doorKit.Constructables.Count!=DoorLedColours.All.Length+4||round==null||!round.IsDoorRoundSwitch||!round.IsDoorIsolator||!round.HasOnOffState||!doorKit.Constructables.Any(p=>SamePrefab(p,round))||isolator==null||!isolator.IsDoorIsolator||!isolator.HasOnOffState||isolator.BuildStates[0].Tool.EntryQuantity!=1||!doorKit.Constructables.Any(p=>SamePrefab(p,isolator))||stop==null||!stop.IsDoorStop||!stop.HasOnOffState||stop.BuildStates[0].Tool.EntryQuantity!=1||!doorKit.Constructables.Any(p=>SamePrefab(p,stop))||!doorKit.Constructables.Any(p=>SamePrefab(p,bridge))||bridge.BuildStates[0].Tool.EntryQuantity!=1||leds.Any(led=>led==null||!led.IsDoorLed||led.BuildStates[0].Tool.EntryQuantity!=1||!doorKit.Constructables.Any(p=>SamePrefab(p,led))))
                Debug.LogError("[Modular Switchboards] Door modules registration verification FAILED.");
            else Debug.Log("[Modular Switchboards] Door modules verified: green, blue, white and red LEDs, rotary main switch, TOTAL STOP, 3x3 door positions and 18 individual bidirectional hinge positions.");
            var labelKit=Prefab.Find<MultiConstructor>(LabelKitName);
            if(labelKit==null)Debug.LogError("[Modular Switchboards] Label kit unavailable.");
            if(labelKit!=null&&(labelKit.Constructables.Count!=7||!labelKit.Constructables.Any(p=>p.PrefabName==DoorLabelName)||!labelKit.Constructables.Any(p=>p.PrefabName==EmergencyStopLabelName)||labelKit.Constructables.OfType<SwitchboardLabel>().Any(l=>l.BuildStates[0].Tool.EntryQuantity!=1)))Debug.LogError("[Modular Switchboards] Label variant registration FAILED.");
            var coverKit=Prefab.Find<MultiConstructor>(CoverKitName);var cover=Prefab.Find<InnerCoverModule>(CoverName);
            if(coverKit==null||cover==null||coverKit.Constructables.Count!=1||!SamePrefab(coverKit.Constructables[0],cover)||cover.BuildStates.Count!=1)
                Debug.LogError("[Modular Switchboards] Inner cover kit registration verification FAILED.");
            var kit = Prefab.Find<MultiConstructor>(KitName);
            var cabinet = Prefab.Find<Structure>(CabinetName);
            foreach(var variantName in new[]{CabinetName,ReverseCabinetName,MediumCabinetName,MediumReverseCabinetName})
            {
                var variant=Prefab.Find<SwitchboardCabinet>(variantName);
                float sign=CabinetLayout.YSign(variantName);
                if(variant==null||variant.BuildStates[0].Tool.EntryQuantity!=CabinetShape.FrameKits(variantName)||variant.BuildStates[1].Tool.EntryQuantity2!=CabinetShape.PlasticSheets(variantName))Debug.LogError("[Modular Switchboards] Cabinet build cost verification FAILED: "+variantName);
                bool ports=variant!=null&&variant.OpenEnds?.Count==1+CabinetShape.OutputCount(variantName)&&variant.InputConnection!=null&&variant.Output1Connection!=null&&variant.Output2Connection!=null&&
                    variant.OpenEnds.All(c=>c.Parent==variant&&c.Transform!=null&&c.Collider!=null)&&
                    variant.transform.InverseTransformPoint(variant.InputConnection.Transform.position).y*sign>0&&
                    variant.transform.InverseTransformPoint(variant.Output1Connection.Transform.position).y*sign<0&&
                    variant.transform.InverseTransformPoint(variant.Output2Connection.Transform.position).y*sign<0;
                var blocks=variant==null?new CabinetTerminalBlock[0]:variant.GetComponentsInChildren<CabinetTerminalBlock>(true);
                if(!ports||blocks.Length!=1+CabinetShape.OutputCount(variantName)||blocks.Select(t=>t.TerminalId).Distinct().Count()!=blocks.Length||
                    blocks.Any(t=>t.Owner!=variant||t.ExternalConnection==null||t.transform.localPosition.y*sign*(t.TerminalId==CabinetTerminalId.Input?1:-1)<=0))
                    Debug.LogError("[Modular Switchboards] Cabinet variant registration FAILED: "+variantName);
                if(variant!=null&&CabinetShape.Medium(variantName)&&(variant.Output3Connection==null||variant.RightDoorOrigin==null||variant.RightBridgeOrigin==null||variant.GetComponent<CabinetDoor>().RightHinge==null))Debug.LogError("[Modular Switchboards] Medium doors/output setup FAILED.");
            }
            if(cabinet==null||!(cabinet.BuildStates[1].Tool.ToolEntry2 is Assets.Scripts.Objects.Items.PlasticSheet)||cabinet.BuildStates[1].Tool.EntryQuantity2!=2)
                Debug.LogError("[Modular Switchboards] Cabinet shell material verification FAILED: expected 2 Plastic Sheets.");
            var railKit = Prefab.Find<MultiConstructor>(RailKitName);
            var rail = Prefab.Find<DinRail>(RailName);
            var breakerKit = Prefab.Find<MultiConstructor>(BreakerKitName);
            var breaker = Prefab.Find<DinBreaker>(BreakerName);
            if (breakerKit == null || breaker == null || breakerKit.Constructables.Count != DinModuleCatalog.Specs.Values.Count(s=>s.Selectable&&!s.Smart&&!s.SmartOutput&&!s.SmartContactor) || !breakerKit.Constructables.Any(p=>SamePrefab(p,breaker)))
                Debug.LogError("[Modular Switchboards] Breaker registration verification FAILED.");
            else Debug.Log("[Modular Switchboards] DIN Modules kit registered: "+breakerKit.Constructables.Count+" type/rating variants.");
            var smartKit=Prefab.Find<MultiConstructor>(SmartKitName);
            if(smartKit==null||smartKit.Constructables.Count!=DinModuleCatalog.Specs.Values.Count(s=>s.Selectable&&(s.Smart||s.SmartOutput||s.SmartContactor))||smartKit.Constructables.Any(m=>!(m is SmartModule)&&!(m is SmartContactor)&&!(m is DinBreaker d&&d.IsSmartOutputModule))||breakerKit!=null&&breakerKit.Constructables.Any(m=>m is SmartModule||m is SmartContactor||m is DinBreaker d&&d.IsSmartOutputModule))
                Debug.LogError("[Modular Switchboards] Smart kit registration FAILED.");
            foreach(var spec in DinModuleCatalog.Specs.Values)
            {
                if(spec.Transformer){var transformer=Prefab.Find<DinTransformer>(spec.Name);if(transformer==null||transformer.BuildStates[0].Tool.EntryQuantity!=DinTransformer.BuildKits)Debug.LogError("[Modular Switchboards] DIN transformer registration FAILED.");continue;}
                if(spec.SmartContactor){var contactor=Prefab.Find<SmartContactor>(spec.Name);if(contactor==null||contactor.BuildStates[0].Tool.ToolEntry?.PrefabName!=SmartKitName)Debug.LogError("[Modular Switchboards] Smart contactor registration FAILED.");continue;}
                if(spec.Smart){var smart=Prefab.Find<SmartModule>(spec.Name);if(smart==null||smart.ModuleWidth!=4||smart.Slots.Count!=1||smart.BuildStates[0].Tool.EntryQuantity!=DinSmartLayout.BuildKits||smart.BuildStates[0].Tool.ToolEntry?.PrefabName!=SmartKitName)Debug.LogError("[Modular Switchboards] Smart module registration FAILED.");continue;}
                var module=Prefab.Find<DinBreaker>(spec.Name);
                if(module==null||module.RatedWatts!=spec.Watts||module.IsContactor!=spec.Contactor||module.HasNormallyClosedContact!=spec.NormallyClosed||module.IsFuseHolder!=spec.Fuse||module.IsBatteryModule!=spec.Battery||module.IsAnalyserModule!=spec.Analyser||module.IsSmartOutputModule!=spec.SmartOutput||(spec.SmartOutput&&module.BuildStates[0].Tool.ToolEntry?.PrefabName!=SmartKitName)||module.ModuleWidth!=spec.Width||module.BuildStates.Count!=1||module.BuildStates[0].Tool.EntryQuantity!=spec.Width||
                   (spec.Fuse&&(module.Slots.Count!=1||!module.AllowedFuseKits.SequenceEqual(spec.FuseKits))))
                    Debug.LogError("[Modular Switchboards] Module registration verification FAILED: "+spec.Name);
            }
            if (!(cabinet is SwitchboardCabinet) || railKit == null || rail == null ||
                railKit.Constructables.Count != 1 || !SamePrefab(railKit.Constructables[0], rail) || rail.BuildStates.Count != 1)
                Debug.LogError("[Modular Switchboards] DIN rail registration verification FAILED.");
            else Debug.Log("[Modular Switchboards] DIN rail kit + structure registered; two rows, 8 positions per row.");
            if(cabinet is SwitchboardCabinet host && host.OpenEnds!=null && host.OpenEnds.Count==3 &&
                host.InputConnection!=null && host.Output1Connection!=null && host.Output2Connection!=null &&
                host.OpenEnds.All(p=>p.Transform!=null && p.Collider!=null && p.Parent==host) && host.PortBodyGrids!=null &&
                host.OpenEnds.Select(p=>p.ConnectionRole).Distinct().Count()==3 &&
                host.OpenEnds.Select(p=>host.transform.InverseTransformPoint(p.Transform.position).ToGrid(SmallGrid.SmallGridSize,SmallGrid.SmallGridOffset)).Distinct().Count()==3)
                Debug.Log("[Modular Switchboards] Power registration verified: Input, left Output 1 and right Output 2; separate native cable cells, no internal bridge.");
            else if(cabinet is SwitchboardCabinet inputOnly && inputOnly.OpenEnds?.Count==1 && inputOnly.InputConnection!=null &&
                inputOnly.transform.Find(CabinetPowerOutputs.RootName)==null)
                Debug.LogWarning("[Modular Switchboards] Input remains available, but lower outputs were not installed; see earlier output setup error.");
            else Debug.LogError("[Modular Switchboards] External power port registration verification FAILED.");
            var terminals=cabinet==null?new CabinetTerminalBlock[0]:cabinet.GetComponentsInChildren<CabinetTerminalBlock>(true);
            if(terminals.Length==3 && terminals.Select(t=>t.TerminalId).Distinct().Count()==3 &&
                terminals.All(t=>t.Owner==cabinet && t.FrontContacts?.Length==1 && t.RearContacts?.Length==1 &&
                    t.TerminalCollider!=null && t.ExternalConnection!=null &&
                    t.ExternalRole==(t.TerminalId==CabinetTerminalId.Input?ConnectionRole.Input:t.TerminalId==CabinetTerminalId.Output1?ConnectionRole.Output:ConnectionRole.Output2)) &&
                terminals.Select(t=>t.ExternalConnection).Distinct().Count()==3)
                Debug.Log("[Modular Switchboards] Terminal blocks verified: Input, Output 1, Output 2; independent single front contacts.");
            else Debug.LogError("[Modular Switchboards] Terminal block registration verification FAILED.");
            if (kit == null || cabinet == null || cabinet.BuildStates.Count != 3 ||
                kit.Constructables.Count != 4 || kit.Constructables[0].PrefabHash != cabinet.PrefabHash || !kit.Constructables.Any(c=>c.PrefabName==ReverseCabinetName)||!kit.Constructables.Any(c=>c.PrefabName==MediumCabinetName)||!kit.Constructables.Any(c=>c.PrefabName==MediumReverseCabinetName))
                Debug.LogError("[Modular Switchboards] Registration verification FAILED.");
            else
                Debug.Log("[Modular Switchboards] Registration verified: kit + cabinet, 3 build states (frame/shell/inner cover).");
        }

        private static void VerifyRecipe()
        {
            var smartKit=Prefab.Find<MultiConstructor>(SmartKitName);
            if(smartKit==null||!ElectronicsPrinter.RecipeComparable.AllRecipes.ContainsKey(smartKit)||!ElectronicsPrinter.RecipeComparable.DynamicThings.Contains(smartKit))
                Debug.LogError("[Modular Switchboards] Smart kit Electronics Printer recipe verification FAILED.");
            var doorKit=Prefab.Find<MultiConstructor>(DoorKitName);
            if(doorKit==null||!ElectronicsPrinter.RecipeComparable.AllRecipes.ContainsKey(doorKit)||!ElectronicsPrinter.RecipeComparable.DynamicThings.Contains(doorKit))Debug.LogError("[Modular Switchboards] Door module recipe verification FAILED.");
            var labelKit=Prefab.Find<MultiConstructor>(LabelKitName);
            if(labelKit==null)Debug.LogError("[Modular Switchboards] Label kit unavailable.");
            var coverKit=Prefab.Find<MultiConstructor>(CoverKitName);
            var kit = Prefab.Find<MultiConstructor>(KitName);
            var railKit = Prefab.Find<MultiConstructor>(RailKitName);
            if(coverKit==null||!ElectronicsPrinter.RecipeComparable.AllRecipes.ContainsKey(coverKit)||!ElectronicsPrinter.RecipeComparable.DynamicThings.Contains(coverKit))
                Debug.LogError("[Modular Switchboards] Inner cover recipe verification FAILED.");
            if (railKit == null || !ElectronicsPrinter.RecipeComparable.AllRecipes.ContainsKey(railKit) ||
                !ElectronicsPrinter.RecipeComparable.DynamicThings.Contains(railKit))
                Debug.LogError("[Modular Switchboards] DIN rail Electronics Printer recipe verification FAILED.");
            else Debug.Log("[Modular Switchboards] DIN rail recipe verified: Electronics Printer, 1 Iron -> 1 kit.");
            if (kit == null || !ElectronicsPrinter.RecipeComparable.AllRecipes.ContainsKey(kit) ||
                !ElectronicsPrinter.RecipeComparable.DynamicThings.Contains(kit))
                Debug.LogError("[Modular Switchboards] Electronics Printer recipe verification FAILED.");
            else Debug.Log("[Modular Switchboards] Electronics Printer recipe verified.");
            var breakerKit = Prefab.Find<MultiConstructor>(BreakerKitName);
            if (breakerKit == null || !ElectronicsPrinter.RecipeComparable.AllRecipes.ContainsKey(breakerKit) ||
                !ElectronicsPrinter.RecipeComparable.DynamicThings.Contains(breakerKit))
                Debug.LogError("[Modular Switchboards] Breaker Electronics Printer recipe verification FAILED.");
            else Debug.Log("[Modular Switchboards] Breaker recipe verified: 2 Iron + 1 Copper -> 1 kit.");
        }
    }
}
