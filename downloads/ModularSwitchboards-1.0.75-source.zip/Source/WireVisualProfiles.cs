namespace ModularSwitchboards
{
    internal sealed class WireVisualProfile
    {
        internal readonly float Radius,Pitch,BandWidth,CollarLength,BodyScale;
        internal WireVisualProfile(float radius,float pitch,float width,float collar,float bodyScale){Radius=radius;Pitch=pitch;BandWidth=width;CollarLength=collar;BodyScale=bodyScale;}
    }
    internal static class WireVisualProfiles
    {
        private static readonly WireVisualProfile Basic=new WireVisualProfile(.0016f,0,0,0,1);
        private static readonly WireVisualProfile Heavy=new WireVisualProfile(.0020f,.020f,.006f,0,1);
        private static readonly WireVisualProfile SuperHeavy=new WireVisualProfile(.0024f,.014f,.007f,.012f,.92f);
        internal static WireVisualProfile Get(CabinetWireKind kind)=>kind==CabinetWireKind.SuperHeavy?SuperHeavy:kind==CabinetWireKind.Heavy?Heavy:Basic;
    }
}
