using System;
using Assets.Scripts.Objects.Electrical;
using UnityEngine;
using Object=UnityEngine.Object;
namespace OasisSwitchboard;
// Runtime geometry avoids bundling Unity/game assets. Native ports, colliders,
// needle, knob and interactables stay untouched and accessible.
public sealed class Cabinet:MonoBehaviour
{
    private GameObject? root;
    private Material? material;
    private void Start()
    {
        try
        {
            var device=GetComponent<Transformer>();if(device==null)return;
            root=new GameObject("OasisPrototypeCabinet");root.transform.SetParent(transform,false);
            Bounds b=device.Bounds;Vector3 c=b.center,s=b.size;
            if(s.x<=0 || s.y<=0 || s.z<=0){Plugin.Log.LogWarning("Native bounds empty; keeping native visuals.");return;}
            var shader=Shader.Find("Standard")??Shader.Find("Universal Render Pipeline/Lit");
            if(shader==null){Plugin.Log.LogWarning("No supported material shader; keeping native visuals.");return;}
            material=new Material(shader){color=new Color(.29f,.36f,.38f,1)};
            float edge=Mathf.Max(.006f,Mathf.Min(s.x,s.y)*.04f);
            // Frame fits the existing placement envelope; no fake external sockets.
            Part("Left",new Vector3(c.x-s.x*.47f,c.y,c.z),new Vector3(edge,s.y*.98f,s.z*.96f));
            Part("Right",new Vector3(c.x+s.x*.47f,c.y,c.z),new Vector3(edge,s.y*.98f,s.z*.96f));
            Part("Top",new Vector3(c.x,c.y+s.y*.47f,c.z),new Vector3(s.x*.98f,edge,s.z*.96f));
            Part("Bottom",new Vector3(c.x,c.y-s.y*.47f,c.z),new Vector3(s.x*.98f,edge,s.z*.96f));
            Plugin.Log.LogInfo("Cabinet attached to device "+device.ReferenceId+"; native controls/ports retained.");
        }
        catch(Exception e){Plugin.Log.LogWarning("Cabinet visual failed; native power device remains available: "+e.Message);}
    }
    private void Part(string name,Vector3 position,Vector3 size)
    {
        var go=GameObject.CreatePrimitive(PrimitiveType.Cube);go.name=name;go.transform.SetParent(root!.transform,false);go.transform.localPosition=position;go.transform.localScale=size;
        var collider=go.GetComponent<Collider>();if(collider!=null){collider.enabled=false;Object.Destroy(collider);}
        go.GetComponent<Renderer>().sharedMaterial=material;
    }
    private void OnDestroy(){if(material!=null)Object.Destroy(material);}
}
