using System;
namespace OasisSwitchboard;
public static class Measurement
{
    public static double Clean(double value)=>double.IsNaN(value)||double.IsInfinity(value)||value<0?0:value;
}
