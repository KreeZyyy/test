using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Electrical;
using Assets.Scripts.Objects.Motherboards;
using Assets.Scripts.Networks;
using BepInEx.Logging;
using HarmonyLib;
using StationeersMods.Interface;
using UnityEngine;
using Object=UnityEngine.Object;
namespace OasisSwitchboard;

[StationeersMod("kreezyyy.stationeers.oasisswitchboard","Oasis Switchboard","0.1.0")]
public sealed class Plugin:ModBehaviour
{
    internal const string PrefabName="StructureOasisSwitchboardPrototype";
    internal const string KitName="ItemOasisSwitchboardPrototypeKit";
    internal static ManualLogSource Log=null!;
    internal static int Hash;
    private static Harmony? harmony;
    public override void OnLoaded(ContentHandler handler)
    {
        base.OnLoaded(handler);
        Log=BepInEx.Logging.Logger.CreateLogSource("OasisSwitchboard");
        Hash=Animator.StringToHash(PrefabName);
        harmony=new Harmony("kreezyyy.stationeers.oasisswitchboard");
        harmony.PatchAll(typeof(Plugin).Assembly);
        Prefab.OnPrefabsLoaded+=Register;
        Log.LogInfo("0.1.0: awaiting native prefab registration; single-output hardware prototype.");
    }
    private void OnDestroy(){Prefab.OnPrefabsLoaded-=Register;harmony?.UnpatchSelf();}
    internal static bool IsOurs(Thing thing)=>thing!=null && thing.PrefabName==PrefabName;
    private static void Register()
    {
        try
        {
            if(Prefab.TryFind(PrefabName,out Thing existing))return;
            var natives=Prefab.AllPrefabs.OfType<Transformer>().Where(t=>t.PrefabName!=PrefabName && !t.StrictlyInternal).OrderBy(t=>t.OutputMaximum).ToArray();
            var source=natives.FirstOrDefault(t=>t.PrefabName=="StructureTransformer")??natives.FirstOrDefault(t=>t.PrefabName.StartsWith("StructureTransformer",StringComparison.Ordinal))??natives.FirstOrDefault();
            if(source==null){Log.LogError("No native external Transformer prefab found. Prototype was not registered.");return;}
            // Both source and clone remain children of the game's inactive prefab container.
            // Do not mutate, activate or replace the source prefab.
            var clone=Object.Instantiate(source,source.transform.parent,false);
            clone.gameObject.name=PrefabName;clone.PrefabName=PrefabName;clone.PrefabHash=Hash;
            AccessTools.Field(typeof(Thing),"_originalPrefab")?.SetValue(clone,null);
            AccessTools.Field(typeof(Transformer),"_outputSetting")?.SetValue(clone,Mathf.Min(2000f,clone.OutputMaximum));
            clone.HasOnOffState=true;
            Prefab.RegisterExisting(clone);
            Thing? kitSource=Prefab.AllPrefabs.OfType<MultiConstructor>().FirstOrDefault(k=>k.Constructables!=null && k.Constructables.Any(s=>s is Transformer));
            kitSource??=Prefab.AllPrefabs.OfType<Constructor>().FirstOrDefault(k=>k.BuildStructure is Transformer);
            if(kitSource!=null)
            {
                var kit=Object.Instantiate(kitSource,kitSource.transform.parent,false);
                kit.gameObject.name=KitName;kit.PrefabName=KitName;kit.PrefabHash=Animator.StringToHash(KitName);
                AccessTools.Field(typeof(Thing),"_originalPrefab")?.SetValue(kit,null);
                if(kit is MultiConstructor multi)multi.Constructables=new List<Structure>{clone};
                if(kit is Constructor single)single.BuildStructure=clone;
                Prefab.RegisterExisting(kit);
                Log.LogInfo("Registered creative kit "+KitName);
            }
            else Log.LogWarning("No transformer construction kit found; custom creative kit could not be registered.");
            int kits=0;
            foreach(var kit in Prefab.AllPrefabs.OfType<MultiConstructor>().ToArray())
            {
                if(kit.Constructables==null || !kit.Constructables.Any(s=>s is Transformer))continue;
                kit.Constructables=new List<Structure>(kit.Constructables);
                if(!kit.Constructables.Contains(clone)){kit.Constructables.Add(clone);kits++;}
            }
            Log.LogInfo("Registered "+PrefabName+" hash="+Hash+" using "+source.PrefabName+"; added to "+kits+" transformer kits. Native IN/OUT and save format retained.");
            if(kits==0)Log.LogWarning("No MultiConstructor transformer kit matched. Use creative spawn search Oasis; send this log if the prototype is absent.");
        }
        catch(Exception e){Log.LogError("Prototype registration failed: "+e);}
    }
}

internal static class Meter
{
    // Read actual energy allocation performed by the native power tick. Never merge
    // cable networks, create power, or infer delivered power from a configured limit.
    internal static double Delivered(Transformer t)
    {
        if(!t.OnOff || t.Error==1 || t.InputNetwork==null || t.OutputNetwork==null || t.InputNetwork==t.OutputNetwork)return 0;
        var providers=t.OutputNetwork.PowerTick?.Providers;
        if(providers==null)return 0;
        double sum=0;
        foreach(var p in providers)if(p!=null && p.Device==t)sum+=p.EnergyUsed;
        return Measurement.Clean(sum);
    }
    internal static double Demand(Transformer t)=>t.OutputNetwork==null?0:Measurement.Clean(t.OutputNetwork.RequiredLoad);
}

[HarmonyPatch(typeof(Thing),"get_DisplayName")]
internal static class DisplayNamePatch
{
    static bool Prefix(Thing __instance,ref string __result){if(Plugin.IsOurs(__instance)){__result="Oasis Switchboard Prototype";return false;}if(__instance.PrefabName==Plugin.KitName){__result="Kit (Oasis Switchboard Prototype)";return false;}return true;}
}
[HarmonyPatch(typeof(Transformer),nameof(Transformer.CanLogicRead),new Type[]{typeof(LogicType)})]
internal static class ReadablePatch
{
    static void Postfix(Transformer __instance,LogicType logicType,ref bool __result)
    {if(Plugin.IsOurs(__instance) && (logicType==LogicType.PowerActual || logicType==LogicType.PowerRequired))__result=__instance.IsStructureCompleted;}
}
[HarmonyPatch(typeof(Transformer),nameof(Transformer.GetLogicValue),new Type[]{typeof(LogicType)})]
internal static class ReadPatch
{
    static bool Prefix(Transformer __instance,LogicType logicType,ref double __result)
    {
        if(!Plugin.IsOurs(__instance))return true;
        if(logicType==LogicType.PowerActual){__result=__instance.IsStructureCompleted?Meter.Delivered(__instance):0;return false;}
        if(logicType==LogicType.PowerRequired){__result=__instance.IsStructureCompleted?Meter.Demand(__instance):0;return false;}
        return true;
    }
}
[HarmonyPatch(typeof(Transformer),nameof(Transformer.Awake))]
internal static class AwakePatch
{
    static void Postfix(Transformer __instance)
    {
        if(!Plugin.IsOurs(__instance))return;
        if(__instance.GetComponent<Cabinet>()==null)__instance.gameObject.AddComponent<Cabinet>();
    }
}
[HarmonyPatch(typeof(ElectricalInputOutput),nameof(ElectricalInputOutput.GetPassiveTooltip))]
internal static class TooltipPatch
{
    static void Postfix(ElectricalInputOutput __instance,ref PassiveTooltip __result)
    {
        if(__instance is not Transformer t || !Plugin.IsOurs(t))return;
        __result.Title="Oasis Switchboard Prototype";
        __result.Extended+="\nSingle native IN / OUT • limit "+t.Setting.ToString("F0")+"\nPowerActual: "+Meter.Delivered(t).ToString("F1")+" • PowerRequired: "+Meter.Demand(t).ToString("F1")+"\n0.1.0: fixed output, no removable modules or fuse yet.";
    }
}
