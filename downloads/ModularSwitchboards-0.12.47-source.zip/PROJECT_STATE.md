# Modular Switchboards 0.12.47

Zadní plocha v dutině pod pojistkou používá stejný tmavě šedý povrch jako plocha pod páčkou jističe (stejný materiálový slot3 a stejný barevný index). Hloubka dutiny zůstává stejná, takže nasvícení se může mírně lišit. Bílé koncovky, hladká barevná vložka a samostatné trvalé kontakty jsou zachované z0.12.46, jejichž vzhled uživatel potvrdil ve hře. Elektrika, inventář, kity a ukládání se nemění.

Ověření: Release build bez chyb a varování. Změněný pouze materiálový slot zadní plochy, geometrie beze změny. Diagnostika pojistek zůstává dostupná.

Instalace při vypnuté hře: nahraď složku ModularSwitchboards ve složce mods; server i klienti musí mít stejnou verzi.

Latest published0.12.46 d8bcf06. Prepared0.12.47 awaits exact-version publication consent required by earlier automatic review. Investigation source Verification/Appearance-investigation-0.12.43.json. Source /workspace/work/switchboard-redesign; distribution /workspace/test; packager /workspace/work/package47.py. Preserve BASE-BACKUP.
