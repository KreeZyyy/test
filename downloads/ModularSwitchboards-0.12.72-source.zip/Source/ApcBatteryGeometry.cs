using System.Linq;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Electrical;
using UnityEngine;
namespace ModularSwitchboards
{
    // APC supplies only the functional slot and its original battery pose.
    // All visible socket geometry and materials are local to this mod.
    internal static class ApcBatteryGeometry
    {
        private static Mesh mesh;
        private static Slot nativeSlot;
        private static Matrix4x4 slotMatrix;
        private static Vector3 sourceCenter;
        private static Bounds hitBounds;
        private static float scale;
        internal static readonly Quaternion Turn=Quaternion.identity;
        internal static Vector3 Map(Vector3 p)=>ApcBatteryRegion.Map(p,sourceCenter,0,scale);
        internal static void EnsureLoaded()
        {
            if(mesh!=null)return;
            var apc=WorldManager.Instance.SourcePrefabs.OfType<AreaPowerControl>().First(p=>p.PrefabName=="StructureAreaPowerControl");
            nativeSlot=apc.BatterySlot;
            var frame=Matrix4x4.Rotate(CabinetModel.FrontSign<0?Quaternion.Euler(0,180,0):Quaternion.identity)*apc.transform.worldToLocalMatrix;
            slotMatrix=frame*nativeSlot.Location.localToWorldMatrix;sourceCenter=slotMatrix.MultiplyPoint3x4(Vector3.zero);
            float rear=float.PositiveInfinity;
            foreach(var cell in WorldManager.Instance.SourcePrefabs.OfType<Assets.Scripts.Objects.Items.BatteryCell>())
            {
                if(nativeSlot.SpecificTypePrefabHashes!=null&&nativeSlot.SpecificTypePrefabHashes.Length>0&&!nativeSlot.SpecificTypePrefabHashes.Contains(cell.PrefabHash))continue;
                foreach(var filter in cell.GetComponentsInChildren<MeshFilter>(true))
                {
                    if(filter.sharedMesh==null)continue;var bounds=filter.sharedMesh.bounds;
                    var pose=slotMatrix*cell.transform.worldToLocalMatrix*filter.transform.localToWorldMatrix;
                    foreach(float x in new[]{-.5f,.5f})foreach(float y in new[]{-.5f,.5f})foreach(float z in new[]{-.5f,.5f})
                        rear=Mathf.Min(rear,pose.MultiplyPoint3x4(bounds.center+Vector3.Scale(bounds.size,new Vector3(x,y,z))).z);
                }
            }
            if(!float.IsInfinity(rear))ApcBatteryRegion.RearSource=rear;
            scale=ApcBatteryRegion.FitScale(new Vector3(ApcBatteryRegion.NativeSocketHeight,ApcBatteryRegion.NativeSocketHeight,0));
            mesh=BatterySocketModel.Build(sourceCenter,scale);float height=ApcBatteryRegion.SocketHeight+.0006f;
            hitBounds=new Bounds(new Vector3(DinBatteryLayout.CenterX,0,ApcBatteryRegion.CellFront(scale)+.004f),new Vector3(height/DinBreakerModel.VisualScale.x,height/DinBreakerModel.VisualScale.y,.004f));
        }
        internal static Mesh Install(Transform parent)
        {
            EnsureLoaded();var go=new GameObject("NativeApcBatteryBay"){layer=parent.gameObject.layer};go.transform.SetParent(parent,false);
            go.AddComponent<MeshFilter>().sharedMesh=mesh;go.AddComponent<MeshRenderer>().sharedMaterials=BatterySocketSurfaces.Materials;return mesh;
        }
        internal static Slot CreateSlot(DinBreaker module,Transform model,BoxCollider hit,Interactable action)
        {
            EnsureLoaded();var location=new GameObject("NativeBatterySlot").transform;location.SetParent(module.transform,false);
            location.localPosition=Vector3.Scale(Map(slotMatrix.MultiplyPoint3x4(Vector3.zero)),DinBreakerModel.VisualScale);
            location.localRotation=Turn*slotMatrix.rotation;location.localScale=slotMatrix.lossyScale*scale;
            return new Slot{Parent=module,StringKey=nativeSlot.StringKey,StringHash=nativeSlot.StringHash,Type=nativeSlot.Type,SpecificTypePrefabHashes=(int[])(nativeSlot.SpecificTypePrefabHashes??new int[0]).Clone(),
                Location=location,RealWorldScale=nativeSlot.RealWorldScale,ScaleMultiplier=nativeSlot.ScaleMultiplier,
                HidesOccupant=false,OccupantCastsShadows=nativeSlot.OccupantCastsShadows,UseInternalAtmosphere=nativeSlot.UseInternalAtmosphere,
                IsSwappable=nativeSlot.IsSwappable,AllowDragging=nativeSlot.AllowDragging,IsInteractable=nativeSlot.IsInteractable,Size=nativeSlot.Size,Action=InteractableType.Slot1,Collider=hit,Interactable=action};
        }
        internal static float FaceDepth{get{EnsureLoaded();return ApcBatteryRegion.Front(scale);}}
        internal static Bounds HitBounds{get{EnsureLoaded();return hitBounds;}}
    }
}
