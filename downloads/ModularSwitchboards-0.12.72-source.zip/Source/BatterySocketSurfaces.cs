using System;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class BatterySocketSurfaces
    {
        private static Material[] materials;
        internal static Material[] Materials
        {
            get
            {
                if(materials!=null)return materials;
                var shader=Shader.Find("StandardInstanced");if(shader==null||!shader.isSupported)throw new InvalidOperationException("Battery socket surface shader unavailable");
                materials=new[]{Create(shader,"Cavity",new Color(.15f,.18f,.18f,1),0,.15f),Create(shader,"GoldContacts",new Color(.80f,.61f,.15f,1),.45f,.35f)};return materials;
            }
        }
        private static Material Create(Shader shader,string name,Color colour,float metallic,float gloss)
        {
            var material=new Material(shader){name="Switchboards.BatterySocket."+name};material.SetTexture("_MainTex",Texture2D.whiteTexture);
            material.SetColor("_Color",colour);material.SetColor("_EmissionColor",Color.black);material.SetFloat("_Metallic",metallic);material.SetFloat("_Glossiness",gloss);return material;
        }
    }
}
