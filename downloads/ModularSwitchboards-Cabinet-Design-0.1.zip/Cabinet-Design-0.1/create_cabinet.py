import bpy, math, json, os
from pathlib import Path
from mathutils import Vector
OUT=Path(os.environ.get('SWITCHBOARD_MODEL_OUTPUT', str(Path(__file__).resolve().parent/'generated')))
OUT.mkdir(parents=True, exist_ok=True)
bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
for c in list(bpy.data.collections):
 if c.name != 'Collection' and c.users == 0: bpy.data.collections.remove(c)
scene=bpy.context.scene
scene.unit_settings.system='METRIC'; scene.unit_settings.scale_length=1.0

def material(name, color, metal=0, rough=.4):
 m=bpy.data.materials.new(name); m.diffuse_color=(*color,1); m.use_nodes=True
 bs=m.node_tree.nodes.get('Principled BSDF'); bs.inputs['Base Color'].default_value=(*color,1)
 bs.inputs['Metallic'].default_value=metal; bs.inputs['Roughness'].default_value=rough
 return m
shell=material('Powder coat - warm grey',(.38,.42,.43),.6,.34)
inner=material('Interior - graphite',(.07,.09,.10),.45,.4)
plate=material('Mounting plate - galvanized steel',(.42,.49,.53),.8,.3)
steel=material('DIN rail - brushed steel',(.58,.65,.69),.88,.25)
black=material('Handle and seals',(.018,.025,.029),.05,.38)
duct=material('Cable ducts - light grey',(.53,.58,.58),.1,.55)
orange=material('Safety orange',(.95,.22,.025),.2,.34)
blue=material('Neutral wire - blue',(.015,.16,.7),.05,.36)
brown=material('Live wire - brown',(.22,.07,.025),.05,.36)
earth=material('Protective earth - green',(.06,.4,.08),.05,.4)
yellow=material('Safety yellow',(.95,.63,.025),.1,.4)
window=material('Door window - smoked solid prototype',(.025,.065,.075),.5,.2)
cols={}
for name in ['Stage_0_Housing','Stage_1_Mounting','Stage_2_Wiring']:
 c=bpy.data.collections.new(name); scene.collection.children.link(c); cols[name]=c
root=bpy.data.objects.new('SwitchboardCabinet_ROOT',None); cols['Stage_0_Housing'].objects.link(root)
root['dimensions_metres']='0.40 wide x 0.50 high x 0.18 deep, excluding fittings'
root['kit_cost']=1; root['rail_rows']=2; root['positions_per_row']=12
root['mounting']='Wall; origin at centre of rear mounting plane. Blender front is -Y.'
root['status']='Design mesh only; not integrated into Stationeers asset bundle.'
objects=[]

def move_to(obj,col):
 for c in list(obj.users_collection): c.objects.unlink(obj)
 cols[col].objects.link(obj)

def finish(obj,name,mat,col,parent=root,bevel=0):
 obj.name=name; move_to(obj,col); obj.data.materials.append(mat)
 obj.parent=parent
 if bevel:
  mod=obj.modifiers.new('Small manufactured edge bevel','BEVEL'); mod.width=bevel; mod.segments=2
  bpy.context.view_layer.objects.active=obj; bpy.ops.object.modifier_apply(modifier=mod.name)
 objects.append(obj); return obj

def box(name,loc,size,mat,col='Stage_0_Housing',parent=root,bevel=.001):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc); obj=bpy.context.object
 obj.dimensions=size; bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
 return finish(obj,name,mat,col,parent,bevel)

def screw(name,x,y,z,col='Stage_0_Housing',mat=steel):
 bpy.ops.mesh.primitive_cylinder_add(vertices=12,radius=.0032,depth=.002,location=(x,y,z),rotation=(math.pi/2,0,0))
 return finish(bpy.context.object,name,mat,col,bevel=.0003)

def wire(name,points,mat):
 curve=bpy.data.curves.new(name,'CURVE'); curve.dimensions='3D'; curve.resolution_u=1
 curve.bevel_depth=.0016; curve.bevel_resolution=2
 spline=curve.splines.new('POLY'); spline.points.add(len(points)-1)
 for p,co in zip(spline.points,points): p.co=(*co,1)
 obj=bpy.data.objects.new(name,curve); cols['Stage_2_Wiring'].objects.link(obj); obj.parent=root; obj.data.materials.append(mat)
 bpy.context.view_layer.objects.active=obj; obj.select_set(True)
 for other in bpy.context.selected_objects:
  if other!=obj: other.select_set(False)
 bpy.ops.object.convert(target='MESH'); objects.append(bpy.context.object)

# Housing: 400 x 500 x 180 mm, wall mounting plane at Y=0.
box('Housing_Back',(0,-.003,0),(.4,.006,.5),shell)
box('Housing_Left',(-.197,-.09,0),(.006,.18,.5),shell)
box('Housing_Right',(.197,-.09,0),(.006,.18,.5),shell)
box('Housing_Top',(0,-.09,.247),(.388,.18,.006),shell)
box('Housing_Bottom',(0,-.09,-.247),(.388,.18,.006),shell)
for x in [-.183,.183]:
 for z in [-.23,.23]:
  box('Mounting_Boss',(x,-.012,z),(.018,.014,.018),inner)
  screw('Rear_Mounting_Fastener',x,-.02,z)
for x in [-.19,.19]: box('Front_Gasket',(x,-.181,0),(.006,.005,.48),black)
for z in [-.24,.24]: box('Front_Gasket',(0,-.181,z),(.38,.005,.006),black)
# Door geometry is parented relative to its actual hinge, not the cabinet centre.
pivot=bpy.data.objects.new('Door_Hinge_PIVOT',None); cols['Stage_0_Housing'].objects.link(pivot)
pivot.parent=root; pivot.location=(-.20,-.187,0)
pivot['axis']='Local Z'; pivot['closed_angle_degrees']=0; pivot['open_angle_degrees']=-110
# Door local coordinates span X=0..0.4, front face at local Y=-0.004.
for x in [.017,.383]: box('Door_Vertical_Frame',(x,-.004,0),(.034,.012,.5),shell,parent=pivot)
for z in [-.231,.231]: box('Door_Horizontal_Frame',(.20,-.004,z),(.332,.012,.038),shell,parent=pivot)
box('Door_Smoked_Window',(.20,-.003,0),(.332,.006,.424),window,parent=pivot)
box('Door_Orange_Accent',(.018,-.011,0),(.006,.003,.43),orange,parent=pivot,bevel=.0003)
box('Door_Handle',(.383,-.024,-.035),(.014,.025,.076),black,parent=pivot,bevel=.003)
# A small geometric voltage warning, without font or texture dependencies.
mesh=bpy.data.meshes.new('VoltageWarningTriangle')
mesh.from_pydata([(.178,-.010,.17),(.222,-.010,.17),(.20,-.010,.205)],[],[(0,1,2)]); mesh.update()
obj=bpy.data.objects.new('Door_Warning_Triangle',mesh); cols['Stage_0_Housing'].objects.link(obj)
obj.parent=pivot; obj.data.materials.append(yellow); objects.append(obj)
bolt=[(.201,-.011,.197),(.193,-.011,.184),(.201,-.011,.184),(.198,-.011,.175),(.208,-.011,.188),(.200,-.011,.188)]
mesh=bpy.data.meshes.new('VoltageBolt'); mesh.from_pydata(bolt,[],[tuple(range(6))]); mesh.update()
obj=bpy.data.objects.new('Door_Voltage_Bolt',mesh); cols['Stage_0_Housing'].objects.link(obj);obj.parent=pivot;obj.data.materials.append(black);objects.append(obj)
for z in [-.175,.175]:
 box('Housing_Hinge',(-.204,-.181,z),(.015,.022,.038),steel)
# Stage 1: mounting plate and two empty DIN rails. No fake installed breakers.
col='Stage_1_Mounting'
box('Mounting_Plate',(0,-.022,0),(.354,.004,.438),plate,col)
for x in [-.16,.16]:
 for z in [-.20,.20]: screw('Plate_Fastener',x,-.026,z,col)
for row,z in enumerate([.106,-.106],1):
 box(f'DIN_Row_{row}_Web',(0,-.041,z),(.276,.004,.035),steel,col)
 for dz in [-.0155,.0155]:
  box(f'DIN_Row_{row}_Flange',(0,-.046,z+dz),(.276,.010,.004),steel,col)
 for x in [-.115,.115]: screw(f'DIN_Row_{row}_Fastener',x,-.045,z,col)
 for x in [-.136,.136]: box(f'DIN_Row_{row}_End_Stop',(x,-.053,z),(.008,.014,.04),inner,col)
# Stage 2: wiring preparation, with spare leads ending at the rail edge.
col='Stage_2_Wiring'
for x in [-.165,.165]:
 box('Vertical_Cable_Duct',(x,-.051,0),(.023,.035,.37),duct,col)
 for j in range(16): box('Duct_Slot',(x,-.069,-.165+j*.022),(.012,.001,.0035),inner,col,bevel=.0002)
for z in [-.205,0,.205]:
 box('Horizontal_Cable_Duct',(0,-.051,z),(.31,.035,.025),duct,col)
 for j in range(15): box('Duct_Slot',(-.14+j*.02,-.069,z),(.0035,.001,.013),inner,col,bevel=.0002)
for row,z in enumerate([.106,-.106],1):
 for k,mat in enumerate([brown,blue,earth]):
  zz=z+.027+k*.008
  wire(f'Row_{row}_Spare_Lead_{k}',[(.156,-.057,zz),(.142,-.062,zz),(.123,-.065,zz-.008),(.103,-.065,zz-.008)],mat)
box('Earth_Bond_Pad',(-.13,-.035,-.179),(.025,.013,.02),earth,col)
screw('Earth_Bond_Screw',-.13,-.044,-.179,col,steel)
# Explicit hinge animation exported with every state.
scene.frame_start=1; scene.frame_end=30
pivot.rotation_euler.z=0; pivot.keyframe_insert(data_path='rotation_euler',frame=1)
pivot.rotation_euler.z=math.radians(-110); pivot.keyframe_insert(data_path='rotation_euler',frame=30)
for curve in pivot.animation_data.action.fcurves:
 for point in curve.keyframe_points: point.interpolation='LINEAR'
scene.frame_set(1)
# Keep an uncluttered, material-coloured viewport on opening the blend.
for area in bpy.context.screen.areas:
 if area.type=='VIEW_3D': area.spaces.active.shading.color_type='MATERIAL'
# Export each cumulative construction stage and an editable .blend.
model_objects=[root,pivot]+objects
for stage in range(3):
 bpy.ops.object.select_all(action='DESELECT')
 for obj in model_objects:
  if obj==root or obj==pivot or any(obj.name in cols[n].objects for n in list(cols)[:stage+1]): obj.select_set(True)
 bpy.ops.export_scene.gltf(filepath=str(OUT/f'SwitchboardCabinet_Stage{stage}.glb'),use_selection=True,
  export_format='GLB',export_animations=True,export_yup=True,export_extras=True)
# Studio render setup, excluded from GLB selection.
studio=bpy.data.collections.new('Preview_Studio_NOT_FOR_EXPORT');scene.collection.children.link(studio)
def studio_obj(obj):
 for c in list(obj.users_collection):c.objects.unlink(obj)
 studio.objects.link(obj)
def aim(obj,point):obj.rotation_euler=(Vector(point)-obj.location).to_track_quat('-Z','Y').to_euler()
bpy.ops.object.camera_add(location=(.83,-1.42,.62));cam=bpy.context.object;studio_obj(cam);aim(cam,(-.10,-.18,0));cam.data.type='ORTHO';cam.data.ortho_scale=1.15;scene.camera=cam
for loc,power,size in [((.4,-1.2,1.1),90,1.2),((-.9,-.5,.4),65,.8),((.3,.5,.8),110,.7)]:
 bpy.ops.object.light_add(type='AREA',location=loc);light=bpy.context.object;studio_obj(light);light.data.energy=power;light.data.shape='DISK';light.data.size=size;aim(light,(0,-.1,0))
scene.world.color=(.18,.18,.18)
scene.render.engine='CYCLES';scene.cycles.samples=64;scene.cycles.use_denoising=False
scene.render.resolution_x=1100;scene.render.resolution_y=1100;scene.render.resolution_percentage=100
scene.render.image_settings.file_format='PNG';scene.render.film_transparent=True
scene.view_settings.view_transform='AgX'
bpy.ops.object.select_all(action='DESELECT');root.select_set(True);bpy.context.view_layer.objects.active=root
scene.frame_set(1);bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'SwitchboardCabinet.blend'))
# Render open cabinet for review, and a closed view.
scene.frame_set(30);scene.render.filepath=str(OUT/'SwitchboardCabinet-open.png');bpy.ops.render.render(write_still=True)
scene.frame_set(1);scene.render.filepath=str(OUT/'SwitchboardCabinet-closed.png');bpy.ops.render.render(write_still=True)
verts=sum(len(o.data.vertices) for o in objects if o.type=='MESH')
tris=sum(sum(len(p.vertices)-2 for p in o.data.polygons) for o in objects if o.type=='MESH')
(OUT/'model-info.json').write_text(json.dumps({'version':'design-0.1','units':'metres','width':.4,'height':.5,'depth':.18,'mounting':'wall','kit_quantity':1,'rail_rows':2,'nominal_modular_positions_per_row':12,'construction_stages':3,'meshes':len(objects),'vertices':verts,'triangles':tris,'door_animation':'frames 1-30, closed to 110 degrees open','game_integration':False},indent=2))
print('MODEL_COMPLETE',verts,tris)
