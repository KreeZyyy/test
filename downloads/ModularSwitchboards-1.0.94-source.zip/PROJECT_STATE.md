# Local 1.0.94 (not uploaded)

1.0.94 local verification
Native Release build: 0 warnings, 0 errors.
37 kit placement integration checks passed: independent outline path, immutable source, native alpha, state/cache and controls.
11 production outline/icon raster checks passed: welded cube crease edges, no coplanar quad diagonal, hole perimeter, input immutability, transparent icon background/cutouts, label rectangles and different profiles.
33 production icon/thumbnail checks passed: saved colour, cutout-aware icon creation, texture/cache/alpha guards, native thumbnail dispatch and vanilla pass-through.
6 actual portable appearance checks passed: per-state icons, same-state colour repaint, same-colour shape replacement, old texture cleanup, stable repeated UI calls and 100 untouched ghost frames.
Native DLL inspection confirmed Wireframe.CreateLineMaterial uses Hidden/Internal-Colored with _SrcBlend, _DstBlend, _Cull and _ZWrite. Preview now uses real line primitives, SrcAlpha/OneMinusSrcAlpha, Cull Off and ZWrite0; no filled faces. GPU visual verification still pending.
Per-item 128px icons are front silhouettes with retained cutouts and label rectangles; tiny label text is not drawn. No world cameras or render-texture jobs. Visual sample exported from the actual raster and inspected (/tmp/CoverIcon194.png).
Source193 snapshot verified intact. User confirmed colour icons already work; new shape icons and outlines need native game verification.
Environment /tmp had been reset and SDK missing. Reinstalled SDK8.0.426 from allowed Microsoft host after reading cloud runtime skill/status/network policy. Deleted only2731 verified MSBuild obj caches (~2974MiB), leaving all original sources, release DLLs and ZIP archives intact.

# Local 1.0.93 (not uploaded)

1.0.93 local verification
Native Release build: 0 warnings, 0 errors.
36 production placement checks: full native blueprint material copy (shader/texture/render queue/blend), native configurable alpha, source immutability, cursor cache and controls.
32 actual icon/thumbnail-dispatch checks: saved instance colour, static prefab colour, vanilla-item pass-through, source icon/alpha/cache and unknown-colour fallback.
70 actual cover-transfer checks: recovered payload broadcast flag plus existing transfer/paint/white-emission/rollback guards.
Native DLL inspection: UpdatePrecisionPlacement activates cached item blueprint; ordinary construction PlacementMode colours BlueprintRenderer.material. Thing.GetThumbnail() is sealed virtual and has a separate static GetThumbnail(Thing,int) overload; two narrowly scoped Harmony prefixes handle fitted covers. These are regular class methods, not interface methods. Native CursorAlphaConstructionMesh is an instance field.
Runtime visual/UI and multiplayer confirmation pending. Existing cover saved-state/atlas logic unchanged except recovered-item payload flag. Source192 snapshot verified unchanged.

# Local 1.0.92 (not uploaded)

1.0.92 local verification
Native Release build: 0 warnings, 0 errors.
34 production kit-item placement checks passed: native cursor cache/state, 0.2 alpha, removed cloned construction components, guarded deferred Awake, explicit native cursor shader, cleared property blocks, immutable source and placement controls.
26 production cover-icon checks passed: saved hue, shading and alpha preservation, immutable source, cache reuse and safe unknown-palette fallback.
5 actual extracted portable-cover appearance checks passed: held/world saved appearance, stable assets, same-state repaint, 100 untouched cursor frames and restored real-item finish.
No state/transfer schema changes, new Harmony hooks or per-frame icon/material creation. UI thumbnail is a flat tinted icon, not a live metallic reflection render. Native game preview transparency/red-invalid behaviour and UI refresh still need player verification.

# Local 1.0.91 (not uploaded)

1.0.91 verification
Native Release build: 0 warnings, 0 errors.
48 production material/isolation checks passed. Fixture now differentiates a textured native atlas from legacy swatch materials, checks repaint retains the atlas and fixed hardware, and confirms native surface-index fallback is not overwritten by legacy gloss.
Root cause: CabinetPaintSurface.Apply selected ColorSwatch.Normal rather than retaining CabinetGeometry.Materials[0] (native texture-array clone). This contradicted the already-documented native CustomColorMapping contract in NativeWireReferenceSource. Native texture/material reference is retained; diffuse colour still comes from existing per-submesh palette index writes. SmoothnessIndex is a surface array layer, not a generic gloss float.
Scope: cabinet panels, doors, mounted/portable covers through shared helper. Only production changes from190 are CabinetPaintSurface and version. No UV guessing or geometry changes; native textures/UVs retained, no global material mutations or new per-frame clones.
Screenshot gold/bronze comparison showed surface mismatch. Exact grain/metallic parity requires player visual verification; no game/MP session locally.

# Local 1.0.90 final candidate (not uploaded)

1.0.90 final local verification
Native Release build: 0 warnings, 0 errors.
403095 Medium geometry/door checks passed: unchanged source/handle/seam/bounds, mirrored winding/pivots and sampled 40mm outer-corner arc.
69 actual cover-transfer/paint checks passed, including same-prefab-colour mount, recovery and repeated white transfer to a differently coloured cabinet without emission or loss of saved colour.
52 production paint-emission/lighting checks passed: all physical paint scopes, live door LED/native child exclusion, unchanged paint/materials and shadow reception.
Native DLL inspection confirms Structure.SetStructureData bypasses SetCustomColor for equal indices. Fitted cover transfer now explicitly calls SetCustomColor(savedColour,false) on both recovered item and mounted structure. Cover rendering writes black emission, fixing inherited glow for already-existing covers without requiring repaint. Physical owner emission normalized in existing callbacks; no new Harmony hooks.
All paint materials/smoothness remain189; no broad shader replacement. Small cabinet geometry unchanged. Wire material/colour/geometry/routing/power untouched; only procedural wire casting disabled. Door flex already had casting disabled; normal door wiring did not.
Player confirmed FPS/loading, battery -> 1kW fuse -> output protection and smaller mirrored hinges good. New corners, moved-cover appearance and wire-shadow suppression require native visual verification; no game/MP session locally.
Final scope supersedes the earlier local190 corner-only candidate after user explicitly reopened paint investigation and requested an audit of everything.

# Local 1.0.89 (not uploaded)

1.0.89 verification
Native Release build: 0 warnings, 0 errors.
Medium geometry/door fixture: 382766 checks passed, including Small hardware size, four matching Medium hinges, unchanged non-hardware vertices, source immutability and opposite door rotations.
Material fixture: 48 checks passed, including original native material isolation, native metallic swatch/finish, repaint back to ordinary swatch, fixed material roles and module/live-LED preservation.
Cabinet.meshbin edited only Housing role-4 hinge vertices/normals; Small hinges 10x24x16mm. Medium helper adds mirrored geometry with reversed winding and inverse-scale normals. Updated generator dimensions and retained Blender model.
Metallic cause: matte clones disabled reflection/metallic properties and a later cabinet finish pass forced smoothness to zero. Cabinet paint now restores native materials and selected swatch.Normal; native swatch smoothness/fallback retained. Both mounted and loose covers use their saved independent colour.
No new Harmony hooks or per-frame material clones. No native game/visual/multiplayer run locally; metallic appearance needs player verification. Published188 snapshot verified unchanged.

# Local 1.0.88 (not uploaded)

1.0.88 local verification
Player evidence: about 20 FPS with cabinets versus 50 after deleting them; world loading slower than earlier builds.
Code evidence: per-frame power RefreshNodes repeatedly constructed adjacency graphs and repeated BFS for each module/source/output; hidden marker loops still checked occupancy/capacity. Route revision 9 formerly rerouted all revision-8 wires even where endpoints were unchanged.
Fix: WireCircuitGraph caches adjacency/reachability by exact endpoint/pin/burnt/conducting snapshots. WireCircuitPaths caches module-ID paths and invalidates on eligible-set changes. Live energy budgets/demand/supply/cell charge continue unchanged; no simulation throttling.
Skip hidden marker work; retain revision-8 path arrays and promote only when all endpoints match live contacts. Required moved-contact/older-route searches remain synchronous.
Native Release build: 0 warnings, 0 errors.
99605 differential graph/path/upgrade checks passed. 1000-query isolated benchmark: original 12.74 ms / 32408000 bytes allocated; cached 0.23 ms / 0 bytes. This is not an in-game FPS benchmark.
Full wiring suite passed: 12464 circuit/budget/persistence/routing checks; additionally transformer, own-use, NC, 2023 battery, 1040 overload and async-preview checks passed, plus failed-migration retry regression.
Compiled cover startup regression: 4 checks passed. No Mono/game FPS or loading-time measurement locally; no multiplayer session.

# Local 1.0.87 (not uploaded)

1.0.87 verification
Confirmed code path: failed atomic route migration preserves old paths; periodic 0.15 s RefreshContacts detects the old endpoint mismatch and previously requeued synchronous RerouteLegacy without a failure guard.
Fix: suppress endpoint scheduling while migrationFailure is set, guard RerouteLegacy against stale scheduling, and clear the failure on actual Changed() wiring mutations. No wire loss, automatic refunds or clearance relaxation.
Native Release build: 0 warnings, 0 errors.
Wiring suite: 12464 checks passed, plus regression over 100 idle retries after obstruction removal: failure/message/path references unchanged until real wiring change, then successful retry.
Compiled startup checks: 4 passed. Mono interface patch fix retained.
Player reports persistent lag after 1.0.85/86. No game profiler or FPS measurement is available; this confirms a retry-loop defect, not that it accounts for all reported lag. First successful/cold migration and authoritative commits remain synchronous.

# Local 1.0.86 (not uploaded)

1.0.86 Mono startup fix
User log: Owner can't be an array or an interface, Harmony patch compilation during OnLoaded.
Cause: newly registered static interface ISprayer.DoSpray patch. Removed registration and prefix; no fallback or suppressed exceptions.
Native build: 0 warnings, 0 errors.
66 cover paint/transfer checks pass (two obsolete global hook checks removed).
4 compiled assembly/startup regression checks pass: no hook method/registration and both cover AttackWith implementations directly call CoverPaint.Spray.
Actual Mono/game startup and multiplayer not run locally. All other production code matches 1.0.85 apart from version constants.

# Latest local candidate: 1.0.85 (not uploaded)

1.0.85 local verification
Native Release build: 0 warnings, 0 errors.
CoverTransfer: 68 checks; actual paint/transfer/refresh logic with stubs, not Unity input.
CoverMemory: 8005 checks.
CoverSerialization: 13 checks; two unused-field warnings in test stubs.
TransformerFront: 17091 geometry and actual UpdatePorts checks.
Wiring: 12464 checks, including three incoming and outgoing bridge branches, fourth-wire rejection and serialization. Existing async/overload suites also pass.
No native game or multiplayer session was run. Recipes remain unchanged. No Workshop publication or GitHub upload performed.

# Latest local candidate: 1.0.84 (not uploaded)

UserexplicitlyrequestedactualmodelmountandfirstgreenON/allothersdownOFF. Renderedfreshreferencefrommod'sactualexportedbody/bearings/nativeAPC284vertexflap, exactvisualscale andpivot plusSourceBreakerSwitchPose0/180deg. Reference /workspace/work/BreakerMount-1.0.84-reference.png inspected: centralaxis, ONplateup, OFFplatedown. image_genedited183posterusingthismodelreference. Newmaster /workspace/generated_images/exec-542bfc3b-dde0-4595-b127-5c3a25465a25.png retained; firstgreenONandother4top+2middleOFFcorrectvisually. BothnativeAboutPNGsexported. RuntimeonlyVersion84change; fullArt/Assets/Examplesmatch183, descriptionunchanged, build0warnings/errors. Initial184copyhitdiskfull; repairedallmissing/truncatedunmodifiedfilesandbyte-verifiedArt/Assets/Examples. Deletedonlyregenerable80-83base64sidecarsaftermatchingoriginalarchives,175-184obj/binbuildcachesandSDKdownloadtar(installedSDKretained). AlloriginalZIPs/sources/mastersretained. No upload184authorizationyet; mainstill181.

# Latest local candidate: 1.0.83 (not uploaded)

Userwantedposterleverstomatchactualgameflaps, explicitly"do it". image_genreferenced182masterplusactualDinBreaker1.0.37preview. Replacedoversizedzigzagtoggleswithshortflatcolouredhingedplatesinblackrecesses, lowerhingebarsandpivotdetails. Existingfilledfuses/banner/compositionpreserved. Newmaster /workspace/generated_images/exec-8512a179-f586-47d6-b62f-efe3f45444c5.png retainedalongsideallpreviousmasters. NativePNGexports1600x900/640x360. GameplayunchangedonlyVersion83Sourcechange; metadata/dimensions/descriptionorderchecked; build0warnings/errors. No upload183authorizationyet; mainstill181. Disklow: verifiedanddeletedonlyregenerable177/178/179base64sidecars(83MB); alloriginalarchivesandallsourceversionsremain.

# Latest local candidate: 1.0.82 (not uploaded)

Userapproved181coverstylebutwantedemptyfusefilled and breakerbuttons differentiated. image_genedited181master: greycartridgewithsilvercapsinpreviouslyemptyholder, projectingbreaker togglesonupperandmiddlerows; banner/type/compositionunchanged. Originalnewmaster /workspace/generated_images/exec-5ede8009-0121-48b4-8a6a-c69c438011fc.png retained; bothnativePNGexported1600x900/640x360. Requirementsdescriptionidentical181, runtimeonlyVersion82change. Build0warnings/errors; metadata/dimensions/source-scopechecked. No upload182requestyet. Publishedmainstill181commit9571337180a3250f38e06c0b6a8c67f63d1bd901.

# Latest local candidate: 1.0.81 (not uploaded)

User requested substantially improved preview, orange StationeersLaunchPad banner, prominent loader requirement and installation link at topofdescription. Generated newillustrated artwork from actualcabinet screenshot/referencebanner; originalmasterretained /workspace/generated_images/exec-64b8712a-37d2-44cd-bc5b-25351a302b12.png. NativePNGassets1600x900 and640x360 exportedwithImageMagick256palette; inspected640thumb. NativeAboutdescriptionstartsorangeTMPheading andplainGitHubURL; BepInExrequired + LibConstructReloadedlinkalsoattop; nativeplainbulletsavoidraw[list]tags. SeparateWORKSHOP-DESCRIPTION.txtusesSteamBBCode. Workshopnotpublished. LoaderGitHubURLverifiedreachable.

RuntimeSourceunchanged180exceptVersion81; build0warnings/errors, metadataXML/requirementorder/URLs/dimensionsverified. Player80screenshotsconfirmedredburntinsulation/localdarkends/cores. No previewFPSfeedbackyet. No explicitupload181requestyet. Publishedmainstill180commit3fb35d1583249e40e2abe3d518925670e032f797.

# Latest local candidate: 1.0.80 (not uploaded)

User reported preview freezes and full-length black burnt wires even with menu1.0.79. Preview A* was synchronous with16bendstates/cell and repeated64candidate work; new captured pure WireRoutePlanner + cancellable WireRouteJob + actualCabinetWiringPreview polling cache moves previewsearch offgame thread. Threadstaticworkspaces + edgecache4/cell reduce GC and repeated collision/visual tests. Cold authoritycommit and RerouteLegacy stay synchronous.

Colour:179excludedBurntfromper-frameRefreshColour. NewactualRefreshWireColours includesBurnt, with10simulatedblack-overwrite cycles tested and legitimateblackpaintretained. Newrupturebodymesh hasonlynativebaseMaterialRoles; localdarkends/metal liveincompactseparateMeshRenderer. This fixes observable code asymmetry, but exact cause of userUnityblack render is not proven without runtime capture. Needgameverification80; don'tclaimUnitytested.

Build0warnings/errors;112actualasyncpreviewchecks(firstpoll2.83ms in .NET test, not game FPS), fullwiring12464 plus1040overload etc passed; typed57; mesh66147plusactualburntcolourmaintenance passed. No requestedupload180yet. Publishedmainstill179commit0e166efac7a788bf829fee7218f2b12be8d6d7d5.

# Latest local candidate: 1.0.79 (not uploaded)

Local rupture visuals only: retained saved insulation/type material slots, two local6mm scorched ends with22percent taper and three grey metal strands per end. Power/routing/save/effects semantics unchanged178, already burnt saves update automatically. Build0warnings/errors;66123 actual mesh/material/geometry checks. Visual preview /workspace/work/WireDamage-1.0.79-preview.png is Blender approximation, not Unity verification. No upload request yet for179.

# Current local candidate: 1.0.78

Universal8mm route reservations; native-rated actual per-wire overload and persistent rupture. Local tests/build reports are in Verification. No GitHub upload has been authorized for this candidate yet. Host/clients need matching1.0.78 due packet revision -4 and route revision8. Larger spacing intentionally lowers dense-door capacity; old paths migrate atomically or remain untouched.

# Current build: 0.13.106

UserreportsMedium/MediumReverse internalwireslostafterloadwhileSmallworks. Rootcause productionCabinetWiring.Valid fixedSmallcoordinatebounds .18/.20X,.24Y evenforMediumwidth.8/height1. ValidnowINSTANCE method readsOwner?.PrefabName viaCabinetShape.Width/Height:halfwidth-.02ordinary/fullhalfwidthneutral,halfheight-.01. Smalllimitsunchanged,Medium±.38/±.40Xand±.49Y. AllotherdataguardsandLoadconnectivityunchanged,samevalidatorforXMLworldloadandbinaryReadjoin. No schemachange/rerouteversionbump;restorefromoriginalsavewithrecords,alreadyresavedemptycannotrecoverautomatically.

Verification/Wiring/make-serde.py nowextractsactualupdatedValid/Load/Write/Read,ownerstubexistingSwitchboardCabinet,routeversion6(notstale5). NewVariantSerdeHarness partialSerdeHarness:62checks across4variants XMLarraythenLoad+binaryjoin,exactpoints/endpoints/Output3/Bridge/color/InputSlot/routeversion,invalidwidthheightNaNdepth,provesMediumfixturesfailoldSmallbounds. Fullwiringproductiongeometry/power/routes/migrations/serde suitepassed12464reportedchecks+62newvariantchecks. ProductionRelease0errors/0warnings. No unrelatedtestsneeded. User sentimagegreenstatusIC10running/nativeLEDtext;confirmedin-gamenativeIC10diode/status,NOTLua/106persistence. Lua/poweraudio/preview otherlivevalidationstillpending.

README/PROJECT_STATE/wires106-verification.jsonupdated,106versioncsproj/About/SourceSwitchboardsMod. Existingpreviewimages+example+optionalLua preserved. Packaging/publicationcompletionseehandoff.

## Follow-up editor issue in same release

User105screenshotstill2rowswithonephysicalSmart, plusorangecompilefaultline4lonet (explainedcorrectly). ExtendedSmartComputerDevices.Module resolvesICircuitHolderwrapper.GetLogicableFromIndex(max),InvalidexcludesCabinetnull/inactive. FinalUIguard SmartEditorDropdown: Track onmotherboardOnInserted/HandleDeviceListChange (Firstprefix) bindsprivate_dropdown toSmartEditorOwner; BeforeItemsChanged(Lastprefix) pairsprivate_circuitHolders and_items,filtersand rebuildslabels+holders together,preserves selectedbaseidentity. ScopeonlytrackedICeditordropdowns. LuaEnsurelazyprobe onTrack, optionalpostfixRebuildDeviceList restores selectionagainafterLua'slateItemClicked(oldindex). SourceSortfilterretained. Runtimeidentitydiagnostic writesSmartEditor-devices.txt underpersistentLocalLow/ModularSwitchboards/Diagnostics withassembly-qualifiedholders/IDs/position/Cabinet andbefore/aftercounts. Preciseliverootcauseunknown,don'tcollapsegenuinelydistinctIDsbyname.21actualfilter+finalUIfixturetests pass;23Luaadapterchecks alsoincludeoptionalpostfixmock,metadataagainstsuppliedDLL andNoLuaassemblyreference. NativeIC10greenrunningandorangenativecompilationfaultshowninuserimages,Luastillnotconfirmed. Finalrebuildandpackagingseehandoff.

## Previous version

# Current build: 0.13.105

User uploaded3659911735.rar (StationeersLua1.0), requested optional Lua support AND fullmod-list preview/metadata; author explicitly KreeZy, notGitHubKreeZyyy. Thirdparty archive extracted read-onlyreference via libarchive into work/lua-reference/3659911735; decompiled inspection only, NOTredistributed. Native ModData.GetPreviewImage explicitlyloadsAbout/Preview.png; ModAbout fieldsName/Author/Version/Description/WorkshopHandle/Tags inspected. New ownBlender preview render inTools/render_mod_preview.py,AboutPreview1600x900/thumb640x360;AuthorKreeZy,Description/Tags; nofabricated WorkshopID. Existing LibConstruct dependencies preserved, noLua required. SourceSwitchboardsMod.Version had stale81; now105 matchesDLL/About.

SmartLuaRuntime optionalreflection adapter to uploadedinternal LuaChipRuntimeManager API: TickServerSide(chip,double),UpdateActivityState(long,bool),GetChipErrorTooltip(long),HasActiveRuntime(long),TrySnapshotAndDisposeRuntime(long),SaveInProgress. IsLua knownprefabname prefix ItemIntegratedCircuitLua. No compileReference/mandatorymetadata/copyLuaDLL. Lazy discovery; safeabsence/incompatibleAPI leavesIC10path;missingLua gets explanatory statuserror. Execute selectsLua anddirectoriginalVMtick(.5s) vsIC10Execute128; server/power/on/paused/run guards. SmartLateUpdate updatesLuaactivity includingoff/paused; removal/destruction snapshots throughLuaVM; globalLua chip save patches keepownership. LuaRunStatus usesVMactive notnative_lines;GetPassiveTooltip detail fromLua runtime. NativeICircuitHolder already gives ownmodule(db=2147483647) andscopednetwork. Examples/DinSmartModule.lua counter viaic.writeBASE_UNIT_INDEX Setting,Mode0. No d0-d5 selectors.

LuaNetManager customeditorpath bypassesComputer.DeviceList viaResolveComputerDevices. OptionalHarmony prefix SortCircuitHolderDisplayData filtersSmart duplicateinstance/nonzeroID andnames together. StandardComputerfilter/NormalizeRegistration from104 retained. DecompiledLua host supportgenericDevice/ICircuitHolder confirmed; customeditor supportsICircuitHolder. Editor/import/export delegatedtonativeLua patches. ActualVMprogram notexecutedlocally.23adapter+realDLLmetadata+productionNoLuaAssemblyReference checks,13pairedEditoridentitytests pass. Release0warnings/0errors. Previewrender/packaging andpublication completion see laterentry. Runtime Lua/powercycle/savejoin/ICeditor/modlist tests stillpending.

## Previous version

# Current build: 0.13.104

User screenshot: one physical Smart module, two equal labels in IC editor. Native decompiled Computer.DeviceList returns copy of DataCable.CableNetwork.DataDeviceList; native ProgrammableChipMotherboard.HandleDeviceListChange sorts/iterates it withoutdedupe. Root cause path in liveworld unconfirmed. SmartComputerDevices.Filter postfix on Computer.DeviceList filters only Smart modules: cursor/destroyed/ReferenceId0 omitted; repeated same instance or same positiveID collapsed; distinctID same-name modules kept. Other native devices untouched. SmartDeviceIdentity helper handles seeninstances/seenIDs. SmartModuleNetwork.Refresh begins NormalizeRegistration: under DeviceList lock keep one exactmodule instance, removeextras; dirty nativepower/data caches and RefreshNetworkDevice afterlock to notifycomputers. RegistrationCableHashSet untouched; no networkmerging or branch changes. 9 production filter tests+33 production network tests pass; network fixture models duplicate list and refresh notifications. Release0errors/0warnings. No unchanged103logic retesting. All actual in-game behavior pending. Source/README/smart104-verification updated. No104publication yet.

## Previous version

# Current build: 0.13.103

User explicitly confirms102 still GameAudioEvent.IsValid NRE on power OFF/ON after full restart. No live runtime available. Add PrefabAudioOwner.PrepareInstance(this) before base.Awake in SmartModule: deep clone event objects and condition/buildstate lists, preserve within-instance aliases via dictionary, rebind owner to live instance. Global, interaction and build-state-only paths included; native clip asset/channel/name/hash/StopIfInvalid preserved. Template Rebind remains. 24 owner regression cases include two instances, absent serialized owner and power cycle;10 lifecycle checks pass. Actual power-cycle fix pending in game.

User requests no red; green running, orange fault with detail. New SmartStatusLed lens3.6x1.8mm at(.009,.028,.0738), independent Standard emissive material; no other part repaint. SmartRunStatus priority power/on -> chip -> fault -> active program/instruction range/notpaused. sleep/yield stay green; empty/completed/paused idle unlit. Native GetErrorCode supplies compilation/runtime text+line in passive tooltip. Server refresh .1s, reads native _LinesOfCode count and LineNumber to distinguish completion. runStatus replicated via unused base512flag and join byte; bases checked Thing/Structure/Device/LogicUnitBase/LogicDisplay: base uses1..256, custom512available. Save is derived, no save schema addition. Client power gates stale status. 259 state cases pass; Release0errors/0warnings. Runtime diode and network validation pending. No103publication yet.

## Previous version

# Current build: 0.13.102

User reports native GameAudioEvent.IsValid -> Interactable.PlayInteractableSounds -> PlayScheduledSounds -> AudioManager.LateUpdate NRE on world load. Decompiled IsValid accesses Parent.IsState and Parent.AsStructure. ReplaceComponent rebinds interaction.Parent but left GameAudioEvent.Parent referencing removed source component. New PrefabAudioOwner.Rebind(Structure) called before original DestroyImmediate transfers global, interaction and build-state interaction event owners. No global audio patches or suppressed sounds; conditions/channels/materials/geometry/native state unchanged. Source clone isolation preserved. Native Thing.Awake still initializes AudioSources and private event lookup. 14 regression checks plus10 Smart lifecycle checks passed, Release build0errors/0warnings. In-game worldload/audio check pending.

## Previous version

# Current build: 0.13.101

Socket front now flush with casing fascia z.0736 instead of .0741. No rectangular .15mm perimeter gap. SmartSocketPocket fills four fascia corners and builds an octagonal floor/liner matching the original 2.607mm rim chamfers. Functional native slot follows the same original pose and shifted socket transform. LED/native logic untouched. Tests verify four corner continuity rays, flush rim, original UVs, open pocket and nondegenerate mesh triangles. In-game fit pending.

## Previous build 0.13.100

Visual-only Smart fascia revision, plus matching slot seating transform. AirChipSocketGeometry selects exactly166 complete original Air IC10 socket triangles in prefab bounds x[-.006,.126],y[.703,.846],z[.111,.158]. Full native UV/material groups kept; surrounding panels z>=.205 excluded. Socket fit46x49.5mm, centerX.009, front rimz.0741 over fasciaz.0736. SmartSocketPocket subtracts a pocket and adds closed floor/four lining walls before the native slot is added. Rear depth includes actual native IC10 source bounds. Native slot and original frame use identical uniform map/pose.

LED centerz.0743 (2.7mm closer to fascia), screen remains visible, frame maxz~.077386. LedBezelGeometry excludes10 separate original button pedestal triangles; native state/rendering/logic untouched. User screenshot confirms native text rendering and IC10 appearance in99. SmartPrefabState pre-Awake fix retained.

Verification/SmartGeometry uses actual external original Air/LED Diagnostics JSON and included own procedural CasingFixture, checks332 cases including UV and floor/wall ray clearance. Art/SmartGeometry.json is pocketed actual casing; native-face100.json remains outside source package and is used for the icon render. Source game models/decompiled reference excluded. In-game100 geometry/slot fit still pending.

## Previous lifecycle fix

Hotfix for the reported startup stack: SmartModuleModel.Install -> Interactable.State -> LogicDisplay.OnInteractableUpdated -> Thing.OnOff -> null InteractOnOff. SmartPrefabState seeds serialized _state before Awake without live callbacks and then CacheStates(true). Clone animators removed and ParentInteractableIndex reset so live states have their own native owner. Production SmartPrefabState regression reproduces pre-Awake failure, verifies silent authoring and preserved live callbacks. No native game/decompiled assets bundled.

## Feature state inherited from 0.13.98

DIN Smart Module is a native LogicDisplay + ICircuitHolder, four DIN positions/cost4, native LED glyph rendering and transplanted Air Conditioner IC10 socket. Single upper power/data IN only; no OUT or overload protection. SmartCircuit selects the Input or common feeder/output network, never joins separate data networks. Native device registration lets the selected branch computer IC motherboard discover DIN Smart Module. db addresses the display-owning module; ID/batch reads scoped to selected native network. No physical d0-d5 selectors yet.

Source models are read from native runtime SourcePrefabs. Original uploaded Diagnostics dumps/decompiled reference live outside this package. Native socket and occupant preserve original pose/materials and move together onto fascia. Body paint is separate from native LED color/materials. Standard breaker geometry unchanged.

SmartModuleSaveData extends native LogicBaseSaveData; native base owns settings and inventory. Mount/editor/error added, old prototype mount accepted. Old Smart OUT wires are refunded, IN preserved. Seven save data types registered. Authoritative placement validates4slots before kit consumption; detached/authoring targeting/cover window/label occupancy include Smart.

See README for wiring and test program. Production DLL build + fixture checks complete; actual Unity glyph draw, IC10 seating, motherboard dropdown, multiplayer and game save/load pending user testing.
