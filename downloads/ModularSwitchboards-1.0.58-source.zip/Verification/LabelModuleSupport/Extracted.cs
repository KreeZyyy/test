using System.Linq;using System.Collections.Generic;using UnityEngine;using LibConstruct;using Assets.Scripts.Objects;using Assets.Scripts.GridSystem;namespace ModularSwitchboards{internal static class LabelLayout
    {
        internal static bool Fits(int x,int y,int z,int rotation,int width)
            =>x%90==0&&x>=0&&x/90+width<=8&&(y==240||y==-240)&&z==0&&rotation==0&&width>=1&&(width<=4||width==6);
        internal static bool Overlaps(int x,int width,int other,int otherWidth)=>x<other+otherWidth&&other<x+width;
    }partial class SwitchboardLabel{internal static bool CanSupport(PlacementBoard board,Grid3 position,int rotation,int width)
        {
            if(!(board is SwitchboardLabelBoard)||!(board.PrimaryHost is InnerCoverModule cover)||cover.Host==null||!cover.Host.IsOpen||!(position.x%90==0&&position.x>=0&&position.x/90+width<=DinLayout.FullModuleCount(CabinetShape.RailWidth(cover.Host.PrefabName))&&CabinetShape.Rows(cover.Host.PrefabName).Contains(position.y/4)&&position.y%4==0&&position.z==0&&rotation==0&&width>=1&&(width<=4||width==6)))return false;
            // Every covered position must actually contain a module in the row below.
            for(int slot=position.x/90;slot<position.x/90+width;slot++)
            {
                float x=-CabinetShape.HalfSpan(cover.Host.PrefabName)+slot*DinLayout.SlotPitch;
                float y=position.y*.00045f;
                if(!cover.Host.Wiring.Breakers.Cast<Structure>().Concat(cover.Host.Wiring.SmartModules).Concat(cover.Host.Wiring.Transformers).Concat(cover.Host.Wiring.Contactors).Any(b=>{var p=cover.transform.InverseTransformPoint(b.transform.position);return Mathf.Abs(p.y-y)<.01f&&x>=p.x-.01f&&x<p.x+(DinParts.Width(b)-1)*DinLayout.SlotPitch+.01f;}))return false;
            }
            return true;
        }internal static bool CanPlace(PlacementBoard board,Grid3 position,int rotation,int width)
        {
            return CanSupport(board,position,rotation,width)&&!board.Structures.OfType<SwitchboardLabel>().Any(l=>{var p=board.WorldToGrid(l.transform.position);return p.y==position.y&&LabelLayout.Overlaps(position.x/90,width,p.x/90,l.Width);});
        }internal static void SetBounds(SwitchboardLabel label)
        {
            label.ThingTransform=label.transform;
            label.Bounds=new Bounds(new Vector3((label.Width-1)*DinLayout.SlotPitch*.5f,0,0),new Vector3(label.Width*DinLayout.SlotPitch-.004f,.018f,.002f));
            label.GridBounds=new GridBounds(label);
        }}}