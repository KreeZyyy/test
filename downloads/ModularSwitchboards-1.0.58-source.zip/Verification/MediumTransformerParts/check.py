from pathlib import Path
import json,struct,math
r=Path(__file__).resolve().parents[2];p=json.loads((r/'Art/MediumTransformerReference/ModularSwitchboards-Transformer-Medium-reference.json').read_text())['parts'][0];n=0
for name,report in json.loads((r/'Art/MediumTransformerParts-provenance.json').read_text()).items():
 raw=(r/'Assets/Transformer'/f'{name}.meshbin').read_bytes();nv,ni=struct.unpack_from('<ii',raw);assert len(raw)==8+nv*20+ni*4
 values=[struct.unpack_from('<5f',raw,8+i*20)for i in range(nv)];ids=struct.unpack_from('<'+'i'*ni,raw,8+nv*20);source=report['sourceIndices'];assert[source[i]for i in ids]==report['sourceTriangles'];n+=ni
 for i,k in enumerate(source):
  assert abs(values[i][3]-p['uv'][k]['x'])<1e-7 and abs(values[i][4]-p['uv'][k]['y'])<1e-7;n+=2
 for a,b,c in zip(ids[::3],ids[1::3],ids[2::3]):
  for i,k in[(a,b),(b,c),(c,a)]:
   u=p['vertices'][source[i]];v=p['vertices'][source[k]];assert abs(math.sqrt(sum((u[c]-v[c])**2 for c in 'xyz'))*report['scale']-math.dist(values[i][:3],values[k][:3]))<3e-8;n+=1
assert(r/'Assets/Transformer/MediumAtlas.png').read_bytes()==(r/'Art/MediumTransformerReference/diffuse-0.png').read_bytes()
print(n,'original Medium topology/UV/uniform edge-scale checks passed; atlas byte-identical; cover344v268tri/fins176v104tri/winding572v482tri.')
