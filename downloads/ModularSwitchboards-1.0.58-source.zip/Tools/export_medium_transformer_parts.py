"""Select exact native Medium cover/leads, cooling fins and large winding from the supplied reference."""
from pathlib import Path
from collections import defaultdict
import json,struct
r=Path(__file__).resolve().parents[1];j=json.loads((r/'Art/MediumTransformerReference/ModularSwitchboards-Transformer-Medium-reference.json').read_text());p=j['parts'][0]
keys=[tuple(round(v[c],5)for c in 'xyz')for v in p['vertices']];adj=defaultdict(set)
for s in p['surfaces']:
 for i in range(0,len(s['triangles']),3):
  t=[keys[k]for k in s['triangles'][i:i+3]]
  for a,b in zip(t,t[1:]+t[:1]):adj[a].add(b);adj[b].add(a)
seen=set();groups=[]
for k in adj:
 if k in seen:continue
 seen.add(k);g={k};q=[k]
 while q:
  for v in adj[q.pop()]:
   if v not in seen:seen.add(v);g.add(v);q.append(v)
 groups.append(g)
cover=set();ribs=set();coil=set();main=set()
for g in groups:
 lo=[min(v[i]for v in g)for i in range(3)];hi=[max(v[i]for v in g)for i in range(3)]
 if (len(g)==45 and lo[0]>=0 and lo[2]>.19)or(len(g)==12 and lo[2]>.25)or(len(g)==24 and lo[0]>0 and lo[2]>.19):cover|=g
 if len(g)==16 and lo[0]<0 and lo[2]>.19 and hi[1]>.03:ribs|=g
 if len(g)==250:coil|=g
 if len(g)==290:main=g
assert len(cover)==45+4*12+3*24 and len(ribs)==4*16 and len(coil)==250
alltri=[s['triangles'][i:i+3]for s in p['surfaces']for i in range(0,len(s['triangles']),3)]
def selected(g):return[t for t in alltri if all(keys[k]in g for k in t)]
bands=[t for t in selected(main)if all(abs(p['vertices'][k]['x'])<.161 and -.71<p['vertices'][k]['y']<-.24 and .13<p['vertices'][k]['z']<.26 for k in t)]
print('Medium native winding clamp triangles:',len(bands))
parts={'MediumCover':selected(cover),'MediumRibs':selected(ribs),'MediumWinding':selected(coil)+bands}
prov={}
for name,triangles in parts.items():
 ids=[k for t in triangles for k in t];used=list(dict.fromkeys(ids));lookup={k:i for i,k in enumerate(used)}
 lo=[min(p['vertices'][k][c]for k in used)for c in 'xyz'];hi=[max(p['vertices'][k][c]for k in used)for c in 'xyz']
 if name=='MediumCover':scale=.25;target=(.18225,0,.0736);center=((lo[0]+hi[0])/2,(lo[1]+hi[1])/2,lo[2])
 elif name=='MediumRibs':scale=.15;target=(.10125,-.013,.0736);center=((lo[0]+hi[0])/2,(lo[1]+hi[1])/2,lo[2])
 else:scale=.064/(hi[1]-lo[1]);target=(.02025,0,.0648);center=((lo[0]+hi[0])/2,(lo[1]+hi[1])/2,lo[2])
 v=[[target[a]+(p['vertices'][k][c]-center[a])*scale for a,c in enumerate('xyz')]for k in used];uv=[[p['uv'][k][c]for c in 'xy']for k in used];tri=[lookup[k]for k in ids]
 with(r/'Assets/Transformer'/f'{name}.meshbin').open('wb')as f:
  f.write(struct.pack('<ii',len(v),len(tri)))
  for a,b in zip(v,uv):f.write(struct.pack('<5f',*a,*b))
  f.write(struct.pack('<'+'i'*len(tri),*tri))
 report={'vertices':v,'uv':uv,'triangles':{'0':tri},'sourceIndices':used,'sourceTriangles':ids,'scale':scale,'center':center,'target':target};(r/'Art'/f'{name}.json').write_text(json.dumps(report));prov[name]={k:report[k]for k in ['sourceIndices','sourceTriangles','scale','center','target']}
 print(name,len(v),len(tri)//3,'scale',scale,'bounds',[(min(a[i]for a in v),max(a[i]for a in v))for i in range(3)])
(r/'Art/MediumTransformerParts-provenance.json').write_text(json.dumps(prov))
