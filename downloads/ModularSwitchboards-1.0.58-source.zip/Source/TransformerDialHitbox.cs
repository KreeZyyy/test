using Assets.Scripts.Objects;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class TransformerDialHitbox
    {
        internal static Bounds LocalBounds(bool decrease)
        {
            float radius=TransformerFrontGeometry.KnobRadius;
            return new Bounds(TransformerFrontGeometry.KnobCenter+new Vector3(decrease?radius*.5f:-radius*.5f,0,.0005f),new Vector3(radius,radius*2,TransformerFrontGeometry.KnobDepth*2+.001f));
        }
        internal static void AfterSelection(Interactable __instance,ref SelectionInstance __result)
        {
            if(!(__instance.Parent is DinTransformer)||!(__instance.Collider is BoxCollider box)||
                !((__instance.Action==InteractableType.Button1&&box.name=="TransformerDecrease")||(__instance.Action==InteractableType.Button2&&box.name=="TransformerIncrease")))return;
            var scale=box.transform.lossyScale;
            __result.Bounds=new Bounds(Vector3.Scale(box.center,scale),Vector3.Scale(box.size,new Vector3(Mathf.Abs(scale.x),Mathf.Abs(scale.y),Mathf.Abs(scale.z))));
        }
    }
}
