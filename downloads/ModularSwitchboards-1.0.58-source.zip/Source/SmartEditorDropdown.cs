using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using Assets.Scripts.Objects.Electrical;
using Assets.Scripts.Objects.Motherboards;
using Assets.Scripts.Objects.Pipes;
using HarmonyLib;
using UI.Dropdown;
using UnityEngine;
namespace ModularSwitchboards
{
    public sealed class SmartEditorOwner:MonoBehaviour
    {
        public ProgrammableChipMotherboard Owner;
        internal string LastDiagnostic;
        internal ICircuitHolder RestoreSelection;
    }
    internal static class SmartEditorDropdown
    {
        private static readonly System.Reflection.FieldInfo Dropdown=AccessTools.Field(typeof(ProgrammableChipMotherboard),"_dropdown");
        private static readonly System.Reflection.FieldInfo Holders=AccessTools.Field(typeof(ProgrammableChipMotherboard),"_circuitHolders");
        private static readonly System.Reflection.FieldInfo Items=AccessTools.Field(typeof(ButtonDropdown),"_items");
        internal static void Track(ProgrammableChipMotherboard __instance)
        {
            if(Dropdown==null)return;
            SmartLuaRuntime.TryInitialize();
            var dropdown=Dropdown.GetValue(__instance) as ButtonDropdown;if(dropdown==null)return;
            var binding=dropdown.GetComponent<SmartEditorOwner>()??dropdown.gameObject.AddComponent<SmartEditorOwner>();binding.Owner=__instance;
        }
        internal static void BeforeItemsChanged(ButtonDropdown __instance)
        {
            if(Holders==null||Items==null)return;
            var binding=__instance.GetComponent<SmartEditorOwner>();
            if(binding==null||binding.Owner==null)return;
            binding.RestoreSelection=null;
            var holders=Holders.GetValue(binding.Owner) as List<ICircuitHolder>;
            var items=Items.GetValue(__instance) as List<ButtonDropdownItem>;
            if(holders==null||items==null||holders.Count!=items.Count)return;
            var before=holders.ToArray();var names=items.Select(i=>i.Title).ToList();var oldNames=names.ToArray();
            int selected=__instance.SelectedIndex;var original=selected>=0&&selected<holders.Count?holders[selected]:null;
            SmartComputerDevices.FilterLuaHolders(holders,names);
            if(holders.Count!=items.Count)
            {
                // Rebuild both arrays together so Edit/Import/Export still address
                // the selected chip, not the next row after a removed duplicate.
                __instance.Clear();foreach(var name in names)__instance.AddItem(name);
                int index=original==null?-1:holders.FindIndex(h=>ReferenceEquals(h,original)||SmartComputerDevices.SameModule(h,original));
                if(index>=0){__instance.ItemClicked(index);binding.RestoreSelection=holders[index];}
            }
            WriteDiagnostic(binding,before,oldNames,holders.Count);
        }
        internal static void AfterLuaRebuild(ProgrammableChipMotherboard pcm)
        {
            if(Dropdown==null||Holders==null)return;
            var dropdown=Dropdown.GetValue(pcm) as ButtonDropdown;var binding=dropdown?.GetComponent<SmartEditorOwner>();
            if(binding?.RestoreSelection==null)return;
            var holders=Holders.GetValue(pcm) as List<ICircuitHolder>;var selected=binding.RestoreSelection;binding.RestoreSelection=null;
            int index=holders==null?-1:holders.FindIndex(h=>ReferenceEquals(h,selected)||SmartComputerDevices.SameModule(h,selected));
            if(index>=0)dropdown.ItemClicked(index);
        }
        private static void WriteDiagnostic(SmartEditorOwner owner,ICircuitHolder[] before,string[] names,int remaining)
        {
            if(!before.Any(h=>SmartComputerDevices.Module(h)!=null||h?.GetType().FullName=="ModularSwitchboards.SmartModule"))return;
            var lines=before.Select((h,i)=>
            {
                var m=SmartComputerDevices.Module(h);
                return names[i]+" | holder="+h?.GetType().AssemblyQualifiedName+" | targetID="+(h as ILogicable)?.ReferenceId+(m==null?"":" | SmartID="+m.ReferenceId+" | cabinet="+(m.Cabinet==null?"none":m.Cabinet.ReferenceId.ToString())+" | cursor="+m.IsCursor+" | active="+m.gameObject.activeInHierarchy+" | position="+m.transform.position);
            });
            var diagnostic="Modular Switchboards "+SwitchboardsMod.Version+"; editor rows "+before.Length+" -> "+remaining+Environment.NewLine+string.Join(Environment.NewLine,lines);
            if(diagnostic==owner.LastDiagnostic)return;owner.LastDiagnostic=diagnostic;
            Debug.Log(diagnostic);
        }
    }
}
