using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using Assets.Scripts;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Motherboards;
using Assets.Scripts.Objects.Electrical;
using UnityEngine;
using Object = UnityEngine.Object;

namespace ModularSwitchboards
{
    // Reuse a warning from APC's own texture/UVs, including its original border and bolt.
    // Texture pixels are read only to locate it; rendering retains the native texture and shader.
    internal static class ApcWarning
    {
        private sealed class Patch
        {
            internal Material Material;
            internal Color Tint;
            internal Texture Texture;
            internal string TextureProperty;
            internal Vector2[] Uv;
            internal int Color;
            internal float Score;
            internal float Aspect;
        }
        private static Patch patch;
        private static bool searched;

        internal static void Install(AreaPowerControl apc, Transform door)
        {
            if (ApcWarningGeometry.Install(apc, door)) return;
            if (!searched)
            {
                searched=true;
                Search(apc);
            }
            if(patch==null)
            {
                Debug.LogWarning("[Modular Switchboards] Native APC warning not located; no substitute symbol drawn.");
                return;
            }
            float width=.065f,height=width/patch.Aspect;
            float x=.20f,y=.17f,z=.0155f;
            var mesh=new Mesh { name="Switchboards.NativeApcWarning" };
            // Model front is +Z; +X is left from outside. Right hinge is at X=0, door extends toward +X.
            mesh.vertices=new[] { new Vector3(x+width/2,y-height/2,z),new Vector3(x-width/2,y-height/2,z),new Vector3(x,y+height/2,z) };
            mesh.normals=new[] { Vector3.forward,Vector3.forward,Vector3.forward };
            mesh.uv=patch.Uv;
            mesh.triangles=new[] {0,2,1};
            mesh.RecalculateTangents();mesh.RecalculateBounds();
            var obj=new GameObject("NativeApcWarning") { layer=door.gameObject.layer };
            obj.transform.SetParent(door,false);
            obj.AddComponent<MeshFilter>().sharedMesh=mesh;
            var renderer=obj.AddComponent<MeshRenderer>();renderer.sharedMaterial=patch.Material;
            var block=new MaterialPropertyBlock();
            block.SetTexture(patch.TextureProperty,patch.Texture);
            block.SetColor("_Color",patch.Tint);block.SetColor("_BaseColor",patch.Tint);
            block.SetFloat(Thing.DiffuseIndexPropertyID,patch.Color);
            block.SetFloat(Thing.SmoothnessIndexPropertyID,apc.SmoothnessIndex);
            block.SetColor(Thing.EMISSION_COLOR,Color.black);
            renderer.SetPropertyBlock(block);
            Debug.Log("[Modular Switchboards] Native APC warning reused: "+patch.Material.name+"; UV "+patch.Uv[0]+", "+patch.Uv[1]+", "+patch.Uv[2]);
        }

        private static Mesh NativeMesh(Renderer renderer)
        {
            if(renderer is SkinnedMeshRenderer skinned) return skinned.sharedMesh;
            return renderer.GetComponent<MeshFilter>()?.sharedMesh;
        }

        private static void Search(AreaPowerControl apc)
        {
            var manifest=new System.Text.StringBuilder();
            var visited=new HashSet<string>();
            foreach(var renderer in apc.GetComponentsInChildren<Renderer>(true))
            {
                var mesh=NativeMesh(renderer);
                manifest.AppendLine("Renderer: "+renderer.name+"; mesh: "+(mesh==null?"none":mesh.name));
                var materials=renderer.sharedMaterials;
                for(int sub=0;sub<materials.Length;sub++)
                {
                    var material=materials[sub];if(material==null || material.shader==null) continue;
                    var block=new MaterialPropertyBlock();renderer.GetPropertyBlock(block,sub);
                    var global=new MaterialPropertyBlock();renderer.GetPropertyBlock(global);
                    int nativeIndex=block.HasFloat(Thing.DiffuseIndexPropertyID)?Mathf.RoundToInt(block.GetFloat(Thing.DiffuseIndexPropertyID)):
                        global.HasFloat(Thing.DiffuseIndexPropertyID)?Mathf.RoundToInt(global.GetFloat(Thing.DiffuseIndexPropertyID)):
                        material.HasProperty("_DiffuseIndex")?Mathf.RoundToInt(material.GetFloat("_DiffuseIndex")):GameManager.GetColorIndex(apc.PaintableMaterial);
                    var tint=material.HasProperty("_BaseColor")?material.GetColor("_BaseColor"):
                        material.HasProperty("_Color")?material.GetColor("_Color"):Color.white;
                    if(block.HasColor("_BaseColor")) tint=block.GetColor("_BaseColor");
                    else if(block.HasColor("_Color")) tint=block.GetColor("_Color");
                    else if(global.HasColor("_BaseColor")) tint=global.GetColor("_BaseColor");
                    else if(global.HasColor("_Color")) tint=global.GetColor("_Color");
                    manifest.AppendLine("  Tint: "+tint);
                    manifest.AppendLine("  Material: "+material.name+"; shader: "+material.shader.name+"; native diffuse index: "+nativeIndex);
                    foreach(var property in material.GetTexturePropertyNames())
                    {
                        var texture=block.HasTexture(property)?block.GetTexture(property):global.HasTexture(property)?global.GetTexture(property):material.GetTexture(property);if(texture==null || (!(texture is Texture2D) && !(texture is Texture2DArray))) continue;
                        string name=property.ToLowerInvariant();
                        manifest.AppendLine("    Texture "+property+": "+texture.name+"; type: "+texture.GetType().Name+"; size: "+texture.width+"x"+texture.height+"; scale: "+material.GetTextureScale(property)+"; offset: "+material.GetTextureOffset(property));
                        // Inspect colour maps, not packed normals/metallic maps that may resemble yellow.
                        if(property!=MainTextureProperty(material) && !name.Contains("diffuse") && !name.Contains("albedo") && !name.Contains("base") && !name.Contains("color")) continue;
                        var array=texture as Texture2DArray;
                        var layers=array==null?new[]{0}:Enumerable.Range(0,array.depth)
                            .OrderBy(i=>i==nativeIndex?0:i==GameManager.GetColorIndex(apc.PaintableMaterial)?1:2).ToArray();
                        int candidates=0,used=0;
                        foreach(int layer in layers)
                        {
                            string key=material.GetInstanceID()+":"+property+":"+layer;
                            if(!visited.Add(key)) continue;
                            Texture2D image=null;
                            try
                            {
                                image=Snapshot(texture,layer);
                                var colors=image.GetPixels32();
                                var regions=FindTriangles(colors,image.width,image.height).ToList();
                                for(int i=0;i<colors.Length;i++)
                                {
                                    var pixel=colors[i];
                                    pixel.r=(byte)Mathf.Clamp(pixel.r*tint.r,0f,255f);
                                    pixel.g=(byte)Mathf.Clamp(pixel.g*tint.g,0f,255f);
                                    pixel.b=(byte)Mathf.Clamp(pixel.b*tint.b,0f,255f);
                                    colors[i]=pixel;
                                }
                                if(tint.r!=1f || tint.g!=1f || tint.b!=1f) regions.AddRange(FindTriangles(colors,image.width,image.height));
                                candidates+=regions.Count;
                                foreach(var region in regions)
                                {
                                    var scale=material.GetTextureScale(property);var offset=material.GetTextureOffset(property);
                                    if(Mathf.Abs(scale.x)<.000001f || Mathf.Abs(scale.y)<.000001f) continue;
                                    var center=new Vector2((region.Center.x-offset.x)/scale.x,(region.Center.y-offset.y)/scale.y);
                                    if(!UsedByApc(apc,material,center)) continue;
                                    used++;
                                    if(patch!=null && region.Score<=patch.Score) continue;
                                    var mapped=region.Uv.Select(uv=>new Vector2((uv.x-offset.x)/scale.x,(uv.y-offset.y)/scale.y)).ToArray();
                                    patch=new Patch{Material=material,Tint=tint,Texture=texture,TextureProperty=property,Uv=mapped,Color=layer,Score=region.Score,Aspect=region.Aspect};
                                }
                            }
                            catch(Exception ex){Debug.LogWarning("[Modular Switchboards] APC warning read "+property+" layer "+layer+": "+ex.Message);}
                            finally{if(image!=null) Object.DestroyImmediate(image);}
                            if(patch!=null) break;
                        }
                        string report="APC warning scan: "+renderer.name+" / "+material.name+" / "+property+"; layers="+layers.Length+"; candidates="+candidates+"; within APC UVs="+used;
                        manifest.AppendLine(report);Debug.Log("[Modular Switchboards] "+report);
                        if(patch!=null) return;
                    }
                }
            }
        }

        private static string MainTextureProperty(Material material)
        {
            foreach(var property in material.GetTexturePropertyNames())
                if(material.GetTexture(property)==material.mainTexture) return property;
            return "_MainTex";
        }

        internal static void RestoreColor(Renderer renderer,int smoothness)
        {
            if(ApcWarningGeometry.Restore(renderer)) return;
            if(patch==null) return;
            var block=new MaterialPropertyBlock();renderer.GetPropertyBlock(block,0);
            block.SetTexture(patch.TextureProperty,patch.Texture);
            block.SetColor("_Color",patch.Tint);block.SetColor("_BaseColor",patch.Tint);
            block.SetFloat(Thing.DiffuseIndexPropertyID,patch.Color);
            block.SetFloat(Thing.SmoothnessIndexPropertyID,smoothness);
            block.SetColor(Thing.EMISSION_COLOR,Color.black);renderer.SetPropertyBlock(block,0);
        }

        internal static Texture2D Snapshot(Texture texture,int layer)
        {
            Texture source=texture; Texture2D slice=null;
            RenderTexture previous=RenderTexture.active,rt=null;
            try
            {
                if(texture is Texture2DArray array)
                {
                    slice=new Texture2D(array.width,array.height,array.format,false);
                    Graphics.CopyTexture(array,layer,0,slice,0,0);source=slice;
                }
                int width=Mathf.Min(texture.width,1024),height=Mathf.Min(texture.height,1024);
                rt=RenderTexture.GetTemporary(width,height,0,RenderTextureFormat.ARGB32,RenderTextureReadWrite.sRGB);
                Graphics.Blit(source,rt);RenderTexture.active=rt;
                var image=new Texture2D(width,height,TextureFormat.RGBA32,false);
                image.ReadPixels(new Rect(0,0,width,height),0,0);image.Apply();return image;
            }
            finally
            {
                RenderTexture.active=previous;
                if(rt!=null) RenderTexture.ReleaseTemporary(rt);
                if(slice!=null) Object.Destroy(slice);
            }
        }

        private struct Region
        {
            internal Vector2 Center;
            internal Vector2[] Uv;
            internal float Score,Aspect;
        }
        private static IEnumerable<Region> FindTriangles(Color32[] pixels,int width,int height)
        {
            var seen=new bool[pixels.Length];var queue=new int[pixels.Length];
            for(int start=0;start<pixels.Length;start++)
            {
                if(seen[start] || !Yellow(pixels[start])) continue;
                int head=0,tail=1;queue[0]=start;seen[start]=true;
                int minX=width,minY=height,maxX=0,maxY=0;
                while(head<tail)
                {
                    int i=queue[head++],x=i%width,y=i/width;
                    minX=Math.Min(minX,x);maxX=Math.Max(maxX,x);minY=Math.Min(minY,y);maxY=Math.Max(maxY,y);
                    foreach(int next in new[] { x>0?i-1:-1,x+1<width?i+1:-1,y>0?i-width:-1,y+1<height?i+width:-1 })
                    {
                        if(next<0 || seen[next] || !Yellow(pixels[next])) continue;
                        seen[next]=true;queue[tail++]=next;
                    }
                }
                int w=maxX-minX+1,h=maxY-minY+1;
                float density=(float)tail/(w*h),ratio=(float)w/h;
                if(tail<25 || w<8 || h<8 || ratio<.65f || ratio>1.55f || density<.23f || density>.72f) continue;
                int dark=0;
                for(int y=minY;y<=maxY;y++) for(int x=minX;x<=maxX;x++)
                { var p=pixels[y*width+x];if(p.r<95 && p.g<95 && p.b<95) dark++; }
                if(dark<(w*h)*.04f) continue; // A lightning bolt must be present, not just a painted triangle.
                var bands=new int[4];
                for(int i=0;i<tail;i++)
                {
                    int x=queue[i]%width,y=queue[i]/width;
                    if(y>maxY-h*.2f) bands[0]++;
                    if(x>maxX-w*.2f) bands[1]++;
                    if(y<minY+h*.2f) bands[2]++;
                    if(x<minX+w*.2f) bands[3]++;
                }
                int tip=Array.IndexOf(bands,bands.Min());
                if(bands[tip] >= bands[(tip+2)%4]*.55f) continue;
                int pad=Mathf.Max(2,Mathf.CeilToInt(Mathf.Min(w,h)*.09f));
                var lo=new Vector2(Mathf.Max(0,minX-pad)/(float)width,Mathf.Max(0,minY-pad)/(float)height);
                var hi=new Vector2(Mathf.Min(width,maxX+pad+1)/(float)width,Mathf.Min(height,maxY+pad+1)/(float)height);
                // Corners in outside-view order: bottom-left, bottom-right, apex; rotate UVs to make the native tip upright.
                var points=new[] {new Vector2(0,0),new Vector2(1,0),new Vector2(.5f,1)};
                for(int i=0;i<points.Length;i++)
                {
                    var q=points[i];for(int turn=0;turn<tip;turn++) q=new Vector2(q.y,1-q.x);
                    points[i]=new Vector2(Mathf.Lerp(lo.x,hi.x,q.x),Mathf.Lerp(lo.y,hi.y,q.y));
                }
                float aspect=(tip%2==0)?(float)(w+2*pad)/(h+2*pad):(float)(h+2*pad)/(w+2*pad);
                yield return new Region { Center=(lo+hi)*.5f,Uv=points,Score=tail,Aspect=aspect };
            }
        }
        private static bool Yellow(Color32 c) => c.a>128 && c.r>105 && c.g>85 && c.b<Mathf.Min(c.r,c.g)*.6f && c.r<c.g*1.8f && c.g<c.r*1.4f;

        private static bool UsedByApc(AreaPowerControl apc,Material material,Vector2 point)
        {
            foreach(var renderer in apc.GetComponentsInChildren<Renderer>(true))
            {
                var mesh=NativeMesh(renderer);if(mesh==null) continue;
                var mats=renderer.sharedMaterials;
                for(int sub=0;sub<mats.Length && sub<mesh.subMeshCount;sub++)
                {
                    if(mats[sub]!=material) continue;
                    try
                    {
                        CabinetGeometry.ReadNativeMesh(mesh,out var vertices,out var uv,out var triangles);
                        var t=triangles[sub];
                        for(int j=0;j<t.Length;j+=3)
                        {
                            var a=uv[t[j]];var b=uv[t[j+1]];var c=uv[t[j+2]];
                            float d=Cross(b-a,c-a);if(Mathf.Abs(d)<.000001f) continue;
                            float u=Cross(point-a,c-a)/d,v=Cross(b-a,point-a)/d;
                            if(u>=0 && v>=0 && u+v<=1) return true;
                        }
                    }
                    catch(Exception) { }
                }
            }
            return false;
        }
        private static float Cross(Vector2 a,Vector2 b)=>a.x*b.y-a.y*b.x;
    }
}
