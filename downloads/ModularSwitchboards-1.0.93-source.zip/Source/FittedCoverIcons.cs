using System.Collections.Generic;
using Assets.Scripts;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class FittedCoverIcons
    {
        private static readonly Dictionary<int,Sprite> cache=new Dictionary<int,Sprite>();
        internal static Sprite Get(int colour)
        {
            if(cache.TryGetValue(colour,out var icon))return icon;
            var source=CabinetIcons.Get("InnerCover");
            if(!GameManager.IsValidColor(colour))return source;
            var swatch=GameManager.GetColorSwatch(colour);if(swatch==null)return source;
            var original=source.texture;
            var pixels=original.GetPixels32();var tint=(Color32)swatch.Color;
            for(int i=0;i<pixels.Length;i++)
            {
                var p=pixels[i];pixels[i]=new Color32((byte)(p.r*tint.r/255),(byte)(p.g*tint.g/255),(byte)(p.b*tint.b/255),p.a);
            }
            var texture=new Texture2D(original.width,original.height,TextureFormat.RGBA32,false){name="Switchboards.FittedCover.Icon."+colour};
            texture.SetPixels32(pixels);texture.Apply(false,true);
            icon=Sprite.Create(texture,new Rect(0,0,texture.width,texture.height),new Vector2(.5f,.5f),100f);icon.name=texture.name;
            cache[colour]=icon;return icon;
        }
    }
}
