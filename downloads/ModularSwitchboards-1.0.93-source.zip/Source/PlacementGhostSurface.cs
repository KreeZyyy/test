using Assets.Scripts.Objects;
using Assets.Scripts.UI;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class PlacementGhostSurface
    {
        private static Material template;
        internal static bool Apply(MeshRenderer renderer)
        {
            if(template==null)
            {
                foreach(var name in new[]{"StructureLockerSmall","StructureLocker","StructureAreaPowerControl"})
                {
                    var prefab=Prefab.Find<Structure>(name);var blueprint=prefab?.Blueprint;if(blueprint==null)continue;
                    var source=blueprint.GetComponent<Wireframe>()?.BlueprintRenderer??blueprint.GetComponent<MeshRenderer>();
                    if(source?.sharedMaterial==null)continue;
                    template=source.sharedMaterial;break;
                }
            }
            if(template==null)return false;
            // Preserve the native construction shader, blending, queue, textures
            // and keywords. CursorManager.CursorShader is a selection shader.
            renderer.sharedMaterial=new Material(template){name="Switchboards.NativePlacementGhost"};
            return true;
        }
    }
}
