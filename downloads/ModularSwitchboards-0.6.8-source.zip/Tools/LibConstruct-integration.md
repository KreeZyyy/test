# LibConstruct integration — 0.6.8

User supplied Workshop 3751750326, About ModID LibConstructReloaded, version 0.3.0.
The DLL is named LibConstruct.dll and its runtime Mod ID remains LibConstruct.
SHA256: 18021b2f752c9f1eb7ba167454e67de8991a02727e0bf2cba8c2bc3aae08b8b5
This differs from the original GitHub v0.3.0 binary. Use the supplied Workshop DLL.

Project: -p:LibConstructPath=<path to Workshop LibConstruct.dll>, Private=false.
About.xml requires and loads after LibConstructReloaded / Workshop 3751750326.
Entry point checks API resolution; prefab preparation checks library initialization.
No third-party DLL is bundled. Existing cabinet prefab IDs and save format are unchanged.
Compilation and PlacementBoard/API probe against supplied game and Booster DLLs passed.
Runtime, multiplayer, and host save hooks are not yet tested or implemented here.

Next implementation: cabinet board host, two separately mountable DIN rails,
module occupancy and save/network lifecycle. DIN rail kit: 1 Iron, Electronics Printer only.
