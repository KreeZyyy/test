using System.Collections.Generic;
using UnityEngine;

namespace ModularSwitchboards
{
    internal static class DoorModuleGeometry
    {
        internal static Mesh Cylinder(float radius,float back,float front)
        {
            const int steps=32;
            var vertices=new List<Vector3>();var normals=new List<Vector3>();var triangles=new List<int>();
            for(int i=0;i<steps;i++)
            {
                float a=i*2*Mathf.PI/steps,b=(i+1)*2*Mathf.PI/steps;
                var na=new Vector3(Mathf.Cos(a),Mathf.Sin(a),0);var nb=new Vector3(Mathf.Cos(b),Mathf.Sin(b),0);
                var ab=new Vector3(radius*na.x,radius*na.y,back);var bb=new Vector3(radius*nb.x,radius*nb.y,back);
                var af=new Vector3(ab.x,ab.y,front);var bf=new Vector3(bb.x,bb.y,front);int p=vertices.Count;
                // Radial side normals are continuous around the circumference.
                // Both planar caps own separate vertices: no bevel-like smoothing
                // into a cap and no differently averaged normal in each triangle.
                vertices.AddRange(new[]{ab,bb,af,bf,new Vector3(0,0,back),bb,ab,new Vector3(0,0,front),af,bf});
                normals.AddRange(new[]{na,nb,na,nb,new Vector3(0,0,-1),new Vector3(0,0,-1),new Vector3(0,0,-1),new Vector3(0,0,1),new Vector3(0,0,1),new Vector3(0,0,1)});
                triangles.AddRange(new[]{p,p+1,p+2,p+1,p+3,p+2,p+4,p+5,p+6,p+7,p+8,p+9});
            }
            var mesh=new Mesh{name="Door module smooth cylinder"};mesh.SetVertices(vertices);mesh.SetNormals(normals);mesh.SetTriangles(triangles,0);mesh.RecalculateBounds();return mesh;
        }
    }
}
