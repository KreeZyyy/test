using System;using System.Collections.Generic;using System.Linq;using UnityEngine;using ModularSwitchboards;
namespace UnityEngine{
 public struct Vector3{public float x,y,z;public Vector3(float x,float y,float z){this.x=x;this.y=y;this.z=z;}}
 public static class Mathf{public const float PI=(float)Math.PI;public static float Cos(float x)=>(float)Math.Cos(x);public static float Sin(float x)=>(float)Math.Sin(x);}
 public class Mesh{public string name;public Vector3[] vertices,normals;public int[] triangles;public void SetVertices(List<Vector3> v)=>vertices=v.ToArray();public void SetNormals(List<Vector3> n)=>normals=n.ToArray();public void SetTriangles(List<int> t,int slot)=>triangles=t.ToArray();public void RecalculateBounds(){}}
}
class Program{
 static int checks;static void Check(bool ok,string s){checks++;if(!ok)throw new Exception(s);}
 static void Main(){var shapes=new[]{DoorIsolatorGeometry.Dish(),DoorIsolatorGeometry.Grip()};foreach(var mesh in shapes){
 Check(mesh.vertices.Length==mesh.normals.Length,"Normals count");var edges=new Dictionary<string,int>();double volume=0;
 double R(float v){double r=Math.Round(v,6);return r==0?0:r;}
 string Key(Vector3 p)=>$"{R(p.x)},{R(p.y)},{R(p.z)}";
 for(int i=0;i<mesh.triangles.Length;i+=3){var a=mesh.vertices[mesh.triangles[i]];var b=mesh.vertices[mesh.triangles[i+1]];var c=mesh.vertices[mesh.triangles[i+2]];
 volume+=(a.x*(b.y*c.z-b.z*c.y)+a.y*(b.z*c.x-b.x*c.z)+a.z*(b.x*c.y-b.y*c.x))/6d;
 float ux=b.x-a.x,uy=b.y-a.y,uz=b.z-a.z,vx=c.x-a.x,vy=c.y-a.y,vz=c.z-a.z;var cross=new Vector3(uy*vz-uz*vy,uz*vx-ux*vz,ux*vy-uy*vx);float len=(float)Math.Sqrt(cross.x*cross.x+cross.y*cross.y+cross.z*cross.z);Check(len>1e-10,"Nondegenerate triangle");
 foreach(int k in new[]{0,1,2}){var n=mesh.normals[mesh.triangles[i+k]];Check(float.IsFinite(n.x)&&Math.Abs(n.x*n.x+n.y*n.y+n.z*n.z-1)<1e-4,"Finite unit normal");Check(cross.x*n.x+cross.y*n.y+cross.z*n.z>0,"Winding matches normal");}
 foreach(var pair in new[]{(a,b),(b,c),(c,a)}){var x=Key(pair.Item1);var y=Key(pair.Item2);string key=string.CompareOrdinal(x,y)<0?x+"|"+y:y+"|"+x;edges[key]=edges.GetValueOrDefault(key)+1;}}
 Check(volume>0,"Outward closed solid");
 foreach(var edge in edges)Check(edge.Value==2,"Closed mesh "+edge.Key);
 foreach(var v in mesh.vertices)Check(Math.Abs(v.x)<=.0306&&Math.Abs(v.y)<=.0306&&v.z>=.006&&v.z<=.0451,"Fits model envelope");
 }
 var dish=shapes[0];Check(dish.vertices.Any(v=>v.z>.0309),"Raised continuous outer rim");Check(dish.vertices.Where(v=>v.x*v.x+v.y*v.y>.028f*.028f).All(v=>v.z<=.0311f),"Rim envelope");
 var surfaces=new[]{DoorIsolatorGeometry.Insert(true),DoorIsolatorGeometry.Insert(false),DoorIsolatorGeometry.Mark(true),DoorIsolatorGeometry.Mark(false)};
 foreach(var m in surfaces){foreach(var v in m.vertices)Check(v.x*v.x+v.y*v.y<.0266f*.0266f&&v.z<.028f,"Inserts and marks recessed inside rim");foreach(var normal in m.normals)Check(normal.z>0,"Front-facing white insert/mark winding");}
 Check(surfaces[0].vertices.All(v=>v.y>0)&&surfaces[1].vertices.All(v=>v.x>0),"I above; 0 on screen-left after the actual mirrored door transform");
 Check(shapes[1].vertices.Max(v=>v.z)>.0449f,"Grip projects clearly beyond rim");
 var exported=shapes.Concat(surfaces).ToArray();
 if(Environment.GetEnvironmentVariable("ISOLATOR_EXPORT") is string path)System.IO.File.WriteAllText(path,System.Text.Json.JsonSerializer.Serialize(exported.Select(m=>new {name=m.name,vertices=m.vertices.Select(v=>new[]{v.x,v.y,v.z}),normals=m.normals.Select(v=>new[]{v.x,v.y,v.z}),triangles=m.triangles})));
 Console.WriteLine($"Rotary model: {checks} production geometry checks passed.");
 }
}
