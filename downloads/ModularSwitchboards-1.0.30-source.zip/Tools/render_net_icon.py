"""Render the original DIN Smart Net Module geometry as a catalog thumbnail."""
import bpy,math
from pathlib import Path
from mathutils import Vector
root=Path(__file__).resolve().parents[1]
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
def mat(name,rgb,emit=0):
 m=bpy.data.materials.new(name);m.diffuse_color=(*rgb,1);m.use_nodes=True;n=m.node_tree.nodes.get('Principled BSDF');n.inputs['Base Color'].default_value=(*rgb,1);n.inputs['Roughness'].default_value=.8
 if emit:n.inputs['Emission Color'].default_value=(*rgb,1);n.inputs['Emission Strength'].default_value=emit
 return m
white=mat('Paintable body',(.78,.81,.80));gray=mat('Neutral fascia',(.055,.055,.055));green=mat('PCB',(.045,.19,.035));black=mat('Chip',(.035,.035,.035));silver=mat('Pins',(.48,.50,.46));red=mat('Capacitors',(.43,.018,.012));amber=mat('Amber',(.30,.22,.035));brown=mat('Brown',(.25,.085,.018));led=mat('Network green',(.04,1,.08),1.5);ink=mat('NET lettering',(.85,.88,.85),.35)
scale=(2.25,1.35,1.15)
def point(p):return(-p[0]*scale[0],-p[2]*scale[2],p[1]*scale[1])
def box(name,c,s,m,r=.00015):
 bpy.ops.mesh.primitive_cube_add(size=1,location=point(c));ob=bpy.context.object;ob.name=name;ob.dimensions=(s[0]*scale[0],s[2]*scale[2],s[1]*scale[1]);bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);ob.data.materials.append(m)
 if r:bevel=ob.modifiers.new('Soft edges','BEVEL');bevel.width=r;bevel.segments=2;ob.modifiers.new('Weighted normals','WEIGHTED_NORMAL')
 return ob
box('Main body',(0,0,.029),(.0176,.075,.056),white,.0013)
# Front shell modeled as frame strips around the recessed electronics.
for x in [-.0081,.0081]:box('Painted side',(x,0,.059),(.0014,.052,.008),white,.0005)
for y in [-.024,.024]:box('Painted end',(0,y,.059),(.0176,.004,.008),white,.0005)
box('DATA terminal',(0,-.03,.0577),(.009,.009,.0015),silver,.0005)
box('Terminal slot',(0,-.03,.0586),(.006,.001,.0005),black,.0001)
box('Inner gray backing',(0,-.001,.0595),(.0145,.045,.001),gray)
box('Header',(0,.01505,.06325),(.0127,.0109,.0003),gray)
for x in [-.0068,.0068]:box('Flat gray edge',(x,-.0064,.0632),(.0011,.0325,.0004),gray)
box('Lower gray edge',(0,-.023,.0632),(.0145,.0012,.0004),gray)
def P(u,v,z):return((.5-u)*.0112,.0085-v*.0298,z)
def component(name,u,v,w,h,z,d,m):box(name,P(u,v,z),(w*.0112,h*.0298,d),m,.00008)
outline=[(.06,.53),(.55,.53),(.68,.60),(.95,.60),(.95,.96),(.06,.96)]
pts=[point(P(u,v,.0622))for u,v in outline];me=bpy.data.meshes.new('Notched PCB');me.from_pydata(pts,[],[(5,0,1),(5,1,2),(5,2,3),(5,3,4)]);me.update();ob=bpy.data.objects.new('Original notched board',me);bpy.context.collection.objects.link(ob);me.materials.append(green);solid=ob.modifiers.new('Board thickness','SOLIDIFY');solid.thickness=.0004
component('Upper chip',.5,.255,.86,.335,.0631,.0011,black)
for pin in range(9):
 for row in [.052,.455]:component('Large IC contact',.105+pin*.09875,row,.065,.045,.0629,.0004,silver)
component('Small chip',.285,.755,.28,.18,.0629,.0008,black)
for pin in range(6):
 for row in [.647,.862]:component('Small IC contact',.157+pin*.051,row,.029,.025,.06275,.0003,silver)
for pin in range(4):
 for col in [.126,.444]:component('Side contact',col,.69+pin*.043,.024,.023,.06275,.0003,silver)
for u in [.59,.72]:component('Red capacitor',u,.69,.085,.095,.063,.00085,red)
component('Bottom chip',.655,.862,.24,.095,.0628,.0006,black);component('Amber block',.855,.70,.13,.085,.0628,.0006,amber);component('Brown block',.855,.86,.13,.065,.0628,.0006,brown)
bpy.ops.mesh.primitive_uv_sphere_add(segments=20,ring_count=12,location=point((.0047,.01505,.0641)));ob=bpy.context.object;ob.name='Green network LED';ob.scale=(.003,.001,.003);ob.data.materials.append(led)
bpy.ops.object.text_add(location=point((-.0015,.01505,.06415)),rotation=(math.pi/2,0,0));ob=bpy.context.object;ob.name='NET';ob.data.body='NET';ob.data.align_x='CENTER';ob.data.align_y='CENTER';ob.data.materials.append(ink);bpy.context.view_layer.update();bounds=[Vector(p)for p in ob.bound_box];ob.scale.x=.0058*scale[0]/max(.0001,max(p.x for p in bounds)-min(p.x for p in bounds));ob.scale.y=.0085*scale[1]/max(.0001,max(p.y for p in bounds)-min(p.y for p in bounds))
# Very faint pane, with no opaque rim hiding the original PCB.
glass=bpy.data.materials.new('Clear protective pane');glass.use_nodes=True;nodes=glass.node_tree.nodes;nodes.clear();o=nodes.new('ShaderNodeOutputMaterial');t=nodes.new('ShaderNodeBsdfTransparent');t.inputs[0].default_value=(.98,.99,1,1);glass.node_tree.links.new(t.outputs[0],o.inputs[0]);component('Pane',.5,.5,1.09,1.074,.06395,.00002,glass)
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=48;scene.cycles.use_denoising=False;scene.render.resolution_x=256;scene.render.resolution_y=256;scene.render.resolution_percentage=100;scene.render.film_transparent=True;scene.view_settings.view_transform='Standard';scene.world.color=(.22,.22,.22)
center=Vector((0,-.037,0));bpy.ops.object.camera_add(location=center+Vector((.070,-.28,.075)));cam=bpy.context.object;cam.rotation_euler=(center-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=.125;scene.camera=cam
for pos,power in [((.15,-.22,.25),2.5),((-.20,-.08,.10),.8)]:
 bpy.ops.object.light_add(type='AREA',location=pos);ob=bpy.context.object;ob.data.energy=power;ob.data.size=.35;ob.rotation_euler=(center-ob.location).to_track_quat('-Z','Y').to_euler()
scene.render.filepath=str(root/'Assets/Icons/DinSmartNet.png');bpy.ops.render.render(write_still=True)
