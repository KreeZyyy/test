from pathlib import Path
root=Path(__file__).resolve().parents[1]
def method(s,marker):
 a=s.index(marker);b=s.index('{',a);end=b+1;level=1
 while level:
  level+=(s[end]=='{')-(s[end]=='}');end+=1
 return s[a:end]
out=root/'Verification/SmartOutputGeometry';out.mkdir(exist_ok=True)
base=(root/'Verification/FuseGeometry/Program.cs').read_text();stubs=base[base.index('namespace UnityEngine'):base.index('namespace Assets.Scripts.Objects')]
stubs=stubs.replace('public static float Min(float a,float b)=>MathF.Min(a,b);','public static float Min(float a,float b)=>MathF.Min(a,b);public static float Max(float a,float b)=>MathF.Max(a,b);')
stubs=stubs.replace('public static Vector3 one=>','public static Vector3 zero=>new(0,0,0);public static Vector3 one=>')
stubs=stubs.replace('public Vector3[] vertices=>V.ToArray();','public Vector3[] vertices{get=>V.ToArray();set=>V=value.ToList();}public Vector2[] uv;')
stubs=stubs.replace('public void RecalculateBounds(){}','public Bounds bounds=>new(new Vector3((V.Min(v=>v.x)+V.Max(v=>v.x))/2,(V.Min(v=>v.y)+V.Max(v=>v.y))/2,(V.Min(v=>v.z)+V.Max(v=>v.z))/2),new Vector3(V.Max(v=>v.x)-V.Min(v=>v.x),V.Max(v=>v.y)-V.Min(v=>v.y),V.Max(v=>v.z)-V.Min(v=>v.z)));public void RecalculateBounds(){}')
stubs+='''namespace UnityEngine{public struct Bounds{public Vector3 center,size;public Bounds(Vector3 c,Vector3 s){center=c;size=s;}public Vector3 min=>center-size*.5f;public void Encapsulate(Vector3 p){var lo=new Vector3(Math.Min(min.x,p.x),Math.Min(min.y,p.y),Math.Min(min.z,p.z));var hi0=center+size*.5f;var hi=new Vector3(Math.Max(hi0.x,p.x),Math.Max(hi0.y,p.y),Math.Max(hi0.z,p.z));center=(lo+hi)*.5f;size=hi-lo;}}}'''
(out/'Stubs.cs').write_text('using System;using System.Linq;using System.Collections.Generic;'+stubs+'''namespace ModularSwitchboards{static class CabinetGeometry{internal static void ApplyNativeUv(UnityEngine.Mesh m){}}static class SmartContactor{internal const int SlotCount=2;internal static float CenterX=>.009f;internal static float BodyWidth=>.0356f;}static class ApcBatteryRegion{internal const float SocketHeight=.026f;}}''')
body=(root/'Source/DinBreakerModel.cs').read_text();screw=(root/'Source/HousingAddressScrew.cs').read_text()
(out/'Extracted.cs').write_text('using System;using System.IO;using System.Reflection;using System.Linq;using System.Collections.Generic;using UnityEngine;namespace ModularSwitchboards{static class DinBreakerModel{internal static Vector3 VisualScale=new(2.25f,1.35f,1.15f);'+method(body,'internal static Mesh Build(')+method(body,'private static void EndDisk(')+'}static class HousingAddressScrew{internal static Vector3 Center=new(SmartContactor.CenterX,-.016f,.0615f);'+method(screw,'internal static Mesh Build(')+'}static class WireContactLayout{internal const float BreakerEntryY=.0375f,BreakerEntryZ=.029f;}}')
(out/'Check.csproj').write_text('''<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><OutputType>Exe</OutputType><TargetFramework>net8.0</TargetFramework></PropertyGroup><ItemGroup><Compile Include="../../Source/RoundedGeometry.cs"/><Compile Include="../../Source/BatteryAperture.cs"/><EmbeddedResource Include="../../Assets/HousingAddressScrew.meshbin" LogicalName="ModularSwitchboards.HousingAddressScrew.meshbin"/></ItemGroup></Project>''')
