using System;
using System.Collections.Generic;
using Assets.Scripts.Objects;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class DinContactorModel
    {
        internal const string PrefabName="StructureDinContactor";
        internal static void Install(DinBreaker module)
        {
            var model=module.transform.Find("DinBreakerModel");
            foreach(var name in new[]{"BreakerLever","BreakerIndicator","BreakerControl"}){var t=model.Find(name);if(t!=null)UnityEngine.Object.DestroyImmediate(t.gameObject);}
            var oldView=module.GetComponent<BreakerSwitchView>();if(oldView!=null)UnityEngine.Object.DestroyImmediate(oldView);
            var body=DinBreakerModel.Build(plain:true);
            // Replace the single top terminal with two independently aimed terminals.
            var cropped=NativeMeshCrop.Outside(body,new Bounds(new Vector3(0,.030f,.059f),new Vector3(.011f,.011f,.005f)),"Contactor.Housing");
            var v=new List<Vector3>(cropped.vertices);var n=new List<Vector3>(cropped.normals);var g=new List<int>[5];for(int i=0;i<5;i++)g[i]=new List<int>(cropped.GetTriangles(i));
            foreach(float x in new[]{-.004f,.004f})
            {
                RoundedGeometry.Box(v,n,g[4],new Vector3(x,.030f,.058f),new Vector3(.0057f,.009f,.0015f),.0004f);
                RoundedGeometry.Box(v,n,g[3],new Vector3(x,.030f,.059f),new Vector3(.0035f,.001f,.0005f),.0001f);
                RoundedGeometry.Box(v,n,g[4],new Vector3(x,.03755f,.029f),new Vector3(.0035f,.0003f,.006f),.0001f);
            }
            RoundedGeometry.Box(v,n,g[4],new Vector3(0,0,.0642f),new Vector3(.009f,.022f,.0007f),.0004f);
            RoundedGeometry.Box(v,n,g[4],new Vector3(0,-.022f,.0642f),new Vector3(.010f,.004f,.0007f),.0002f);
            foreach(float x in new[]{-.004f,.004f})RoundedGeometry.Box(v,n,g[4],new Vector3(x,.022f,.0642f),new Vector3(.006f,.004f,.0007f),.0002f);
            var mesh=new Mesh{name="DIN.Contactor.Body"};mesh.SetVertices(v);mesh.SetNormals(n);mesh.subMeshCount=5;for(int i=0;i<5;i++)mesh.SetTriangles(g[i],i);CabinetGeometry.ApplyNativeUv(mesh);mesh.RecalculateBounds();
            model.GetComponent<MeshFilter>().sharedMesh=mesh;UnityEngine.Object.DestroyImmediate(body);UnityEngine.Object.DestroyImmediate(cropped);
            var hit=model.GetComponent<BoxCollider>();hit.center=mesh.bounds.center;hit.size=mesh.bounds.size;
            module.Interactables=new List<Interactable>();module.HasOnOffState=false;module.ContactorClosed=false;
            var state=module.BuildStates[0];state.Interactables=module.Interactables;state.Colliders=new List<Collider>{hit};
            module.Thumbnail=CabinetIcons.Get("DinContactor");module.Thumbnails=new Sprite[0];state.Thumbnail=module.Thumbnail;
            module.CacheStates(true);
            Font font=null;foreach(var name in new[]{"LegacyRuntime.ttf","Arial.ttf"}){try{font=Resources.GetBuiltinResource<Font>(name);}catch(Exception){}if(font!=null)break;}
            if(font!=null)
            {
                Label(model,module.gameObject.layer,font,"IN",.004f,.022f,.0023f);
                Label(model,module.gameObject.layer,font,"A1",-.004f,.022f,.0023f);
                Label(model,module.gameObject.layer,font,"OUT",0,-.022f,.003f);
                var text=Label(model,module.gameObject.layer,font,"OFF",0,0,.004f);
                module.gameObject.AddComponent<DinContactorView>().StateText=text;
            }
        }
        private static TextMesh Label(Transform model,int layer,Font font,string value,float x,float y,float width)
        {
            var go=new GameObject("ContactorLabel."+value){layer=layer};go.transform.SetParent(model,false);go.transform.localPosition=new Vector3(x,y,.065f);go.transform.localRotation=Quaternion.Euler(0,180,0);
            var text=go.AddComponent<TextMesh>();text.font=font;text.fontSize=64;text.characterSize=.002f;text.anchor=TextAnchor.MiddleCenter;text.alignment=TextAlignment.Center;text.text=value;text.color=Color.black;
            var size=go.GetComponent<MeshRenderer>().localBounds.size;go.transform.localScale=Vector3.one*Mathf.Min(width/Mathf.Max(.0001f,size.x),.004f/Mathf.Max(.0001f,size.y));DepthLabelText.Apply(text);return text;
        }
    }
    public sealed class DinContactorView:MonoBehaviour
    {
        public TextMesh StateText;private DinBreaker owner;private bool last,painted;
        private void LateUpdate(){if(owner==null)owner=GetComponent<DinBreaker>();if(owner==null||StateText==null)return;bool on=!owner.IsCursor&&owner.ContactorClosed;if(!painted||on!=last){StateText.text=on?"ON":"OFF";last=on;painted=true;}}
    }
}
