using System.Collections.Generic;
using System.Linq;
using System.Xml.Serialization;
using Assets.Scripts;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Networking;
using Assets.Scripts.Networks;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Pipes;
using Assets.Scripts.Objects.Items;
using Assets.Scripts.Objects.Electrical;
using Assets.Scripts.Objects.Motherboards;
using LibConstruct;
using UnityEngine;
namespace ModularSwitchboards
{
    public sealed class SmartContactorSaveData:StructureSaveData
    {
        [XmlElement]public PlacementBoardStructureSaveData RailBoard;
        [XmlElement]public int OutputAddress=-1;
        [XmlElement]public int ModuleSlots=1;
    }
    public sealed class SmartContactor:Device,IPlacementBoardStructure
    {
        internal const int SlotCount=2;
        internal int ModuleWidth=SlotCount;
        internal static float CenterX=>(SlotCount-1)*DinLayout.SlotPitch*.5f/DinBreakerModel.VisualScale.x;
        internal static float BodyWidth=>.0176f+(SlotCount-1)*DinLayout.SlotPitch/DinBreakerModel.VisualScale.x;
        internal const string PrefabNameId="StructureDinSmartContactor";
        public PlacementBoard Board{get;set;}
        public PlacementBoard.BoardCell[] BoardCells{get;set;}
        public SwitchboardCabinet Cabinet=>(Board?.PrimaryHost as DinRail)?.Board?.PrimaryHost as SwitchboardCabinet;
        private CabinetWiring lastWiring;
        internal CabinetWiring Wiring {get{if(Cabinet!=null)lastWiring=Cabinet.Wiring;return lastWiring;}}
        internal Cable PowerFeed,DataFeed;
        internal CableNetwork OldPower,OldData;
        internal bool BusPowered=>!IsCursor&&!IsBeingDestroyed&&IsStructureCompleted&&PowerFeed?.CableNetwork!=null&&SmartBus.Core(this) is SmartModule core&&core.Powered&&core.OnOff&&SmartBus.OutputAt(core,OutputAddress)==this;
        internal bool Conducting=>BusPowered&&Powered&&OnOff;
        public int OutputAddress=-1;
        private const ushort AddressUpdate=32768;
        private static readonly System.Reflection.FieldInfo AddressState=HarmonyLib.AccessTools.Field(typeof(Interactable),"_state");
        private void RestoreAddressState(){var control=Interactables.FirstOrDefault(i=>i.Action==InteractableType.Mode);if(control!=null)AddressState.SetValue(control,System.Math.Max(0,OutputAddress));}
        private float next;
        public override void Awake(){PrefabAudioOwner.PrepareInstance(this);base.Awake();BoardStructureHooks.Awake(this);}
        public override Grid3 GetLocalGrid()=>Board==null?default(Grid3):Board.WorldToGrid(transform.position);
        public override bool CanLogicRead(LogicType type)=>type==LogicType.On||type==LogicType.Power||type==LogicType.RequiredPower||type==LogicType.PrefabHash||type==LogicType.ReferenceId||type==LogicType.NameHash;
        public override bool CanLogicWrite(LogicType type)=>type==LogicType.On;
        public override void SetLogicValue(LogicType type,double value){if(type==LogicType.On)base.SetLogicValue(type,value);}
        public override PassiveTooltip GetPassiveTooltip(Collider hit)
        {var tip=base.GetPassiveTooltip(hit);tip.Extended=(Conducting?"OUT energized — controls contactor A1.":"OUT de-energized.")+" Command: "+(OnOff?"ON":"OFF")+". Control power: "+(BusPowered?"available":"unavailable")+". Side bus: "+(SmartBus.Core(this)?.DisplayName??"disconnected")+". Address: "+(SmartOutputAddresses.Valid(OutputAddress)?"d"+OutputAddress:"unassigned")+". "+(ModuleWidth<SlotCount?"Compact legacy unit: free one slot at the left end of this bus, then save/reload to expand. ":"")+"Screwdriver selects a free address. Core supplies control power. OUT connects only to a classic contactor A1; no IN or load connection.";return tip;}
        private void LateUpdate()
        {
            if(IsCursor)return;
            if(Time.unscaledTime>=next){next=Time.unscaledTime+.15f;if(GameManager.RunSimulation)SmartBus.AssignAddresses(SmartBus.Core(this));SmartContactorNetwork.Refresh(this);}
            if(BuildStates.Count>0)foreach(var hit in BuildStates[0].Colliders)if(hit!=null)hit.enabled=Cabinet!=null&&Cabinet.IsOpen;
            DinBreakerModel.Refresh(this);SmartPaintSurface.RestoreNative(this);
        }
        internal void ClearSupply()=>AssessPower(null,false);
        public override void OnAddCableNetwork(CableNetwork network){}
        public override void OnRemoveCableNetwork(CableNetwork network){if(network==OldPower)ClearSupply();}
        public override CanConstructInfo CanConstruct()
        {
            if(IsCursor){MountPlacement.AfterRaycast();MountBoardResolver.Resolve(CursorManager.Instance);}
            if(!(Board is DinModuleBoard board))return CanConstructInfo.InvalidPlacement("Attach directly left of Core or its continuous Smart expansion row.");
            var p=board.WorldToGrid(transform.position);
            if(IsCursor)
            {
                if(MountPlacement.TryLockedGrid(this,board,out var locked))p=locked;
                else{var next=SmartBus.NextPosition(board,p,powerOutput:true);if(!next.HasValue)return CanConstructInfo.InvalidPlacement("No free Smart bus expansion position.");p=next.Value;}
                PlacementBoard.CursorGrid=p;PlacementBoard.CursorRotation=0;transform.SetPositionAndRotation(board.GridToWorld(p),board.IndexToRotation(0));
            }
            return SmartBus.CanPlacePowerOutput(board,p,board.RotationToIndex(transform.rotation))?CanConstructInfo.ValidPlacement:CanConstructInfo.InvalidPlacement("Attach to a continuous Core expansion row.");
        }
        protected override CanConstructInfo CanDeconstruct()=>SmartBus.HasLeftNeighbour(this,ModuleWidth)?CanConstructInfo.InvalidPlacement("Remove Smart expansions from the left end first."):Cabinet==null||!Cabinet.CanAccessModules?CanConstructInfo.InvalidPlacement("Open the cabinet and remove the cover first."):Wiring?.HasWires(ReferenceId)==true&&Prefab.Find<Item>("ItemCableCoil")==null?CanConstructInfo.InvalidPlacement("Cable coil prefab unavailable."):CanConstructInfo.ValidPlacement;
        public override DelayedActionInstance AttackWith(Attack attack,bool doAction=true)
        {
            if(IsPaintable&&attack.SourceItem is ISprayer sprayer)return ISprayer.DoSpray(this,sprayer,doAction);
            if(attack.SourceItem?.PrefabName=="ItemScrewdriver")
            {
                var screw=Interactables.FirstOrDefault(i=>i.Action==InteractableType.Mode&&i.Collider!=null&&i.Collider.bounds.Contains(attack.Position));
                if(screw!=null)return AddressAction(screw,doAction);
            }
            return base.AttackWith(attack,doAction);
        }
        internal void SetOutputAddress(int value)
        {
            if(OutputAddress==value)return;
            if(OnOff&&InteractOnOff!=null)OnServer.Interact(InteractOnOff,0);
            OutputAddress=value;RestoreAddressState();NetworkUpdateFlags|=(ushort)(AddressUpdate|2);
        }
        private int NextAddress()=>SmartOutputAddresses.NextFree(OutputAddress,SmartBus.Core(this) is SmartModule core?SmartBus.PowerOutputs(core).Where(o=>o!=this).Select(o=>o.OutputAddress):System.Array.Empty<int>());
        public override string GetContextualName(Interactable interactable)=>interactable.Action==InteractableType.Mode?"Address "+(SmartOutputAddresses.Valid(OutputAddress)?"d"+OutputAddress:"unassigned")+" — screwdriver to next free d":base.GetContextualName(interactable);
        public override DelayedActionInstance InteractWith(Interactable interactable,Interaction interaction,bool doAction=true)
        {
            if(interactable.Action!=InteractableType.Mode)return base.InteractWith(interactable,interaction,doAction);
            if(interaction.SourceSlot?.Get()?.PrefabName!="ItemScrewdriver"&&interaction.SourceThing?.PrefabName!="ItemScrewdriver")return new DelayedActionInstance{Duration=0f}.Fail("Use a screwdriver on the address screw.");
            return AddressAction(interactable,doAction);
        }
        private DelayedActionInstance AddressAction(Interactable control,bool doAction)
        {
            var result=new DelayedActionInstance{Duration=.25f,ActionMessage="Set Output address"};
            if(IsCursor||IsBeingDestroyed||!IsStructureCompleted||Cabinet?.CanAccessModules!=true||SmartBus.Core(this)==null)return result.Fail("Open the cabinet, remove the cover and attach to a Core first.");
            int next=NextAddress();if(next<0||next==OutputAddress)return result.Fail("No other free d0–d5 address.");
            if(doAction)OnServer.Interact(control,next);return result.Succeed();
        }
        public override void OnInteractableUpdated(Interactable interactable)
        {
            base.OnInteractableUpdated(interactable);
            if(interactable.Action!=InteractableType.Mode||!NetworkManager.IsServer)return;
            var core=SmartBus.Core(this);int requested=interactable.State;
            if(core!=null&&Cabinet?.CanAccessModules==true&&SmartOutputAddresses.Valid(requested)&&!SmartBus.PowerOutputs(core).Any(o=>o!=this&&o.OutputAddress==requested))SetOutputAddress(requested);
            RestoreAddressState();NetworkUpdateFlags|=(ushort)(AddressUpdate|2);
        }
        public override void BuildUpdate(RocketBinaryWriter writer,ushort flags){base.BuildUpdate(writer,flags);if(Thing.IsNetworkUpdateRequired(AddressUpdate,flags))writer.WriteInt32(OutputAddress);}
        public override void ProcessUpdate(RocketBinaryReader reader,ushort flags){base.ProcessUpdate(reader,flags);if(Thing.IsNetworkUpdateRequired(AddressUpdate,flags))OutputAddress=reader.ReadInt32();RestoreAddressState();}
        public override void OnDeregistered(){Wiring?.RemoveBreaker(ReferenceId);SmartContactorNetwork.Unbind(this);base.OnDeregistered();if(Board!=null)BoardStructureHooks.OnDeregistered(this);}
        public override void OnDestroy(){Wiring?.RemoveBreaker(ReferenceId);SmartContactorNetwork.Unbind(this);base.OnDestroy();}
        public override ThingSaveData SerializeSave(){ThingSaveData data=new SmartContactorSaveData();InitialiseSaveData(ref data);return data;}
        protected override void InitialiseSaveData(ref ThingSaveData data){base.InitialiseSaveData(ref data);if(data is SmartContactorSaveData save){if(Board!=null)save.RailBoard=BoardStructureHooks.SerializeSave(this);save.OutputAddress=OutputAddress;save.ModuleSlots=ModuleWidth;}}
        public override void DeserializeSave(ThingSaveData data){base.DeserializeSave(data);if(data is SmartContactorSaveData save){ModuleWidth=save.ModuleSlots==SlotCount?SlotCount:1;SmartContactorModel.ApplyWidth(this);OutputAddress=SmartOutputAddresses.Valid(save.OutputAddress)?save.OutputAddress:-1;RestoreAddressState();if(save.RailBoard!=null)BoardStructureHooks.DeserializeSave(this,save.RailBoard);}}
        public override void SerializeOnJoin(RocketBinaryWriter writer){base.SerializeOnJoin(writer);BoardStructureHooks.SerializeOnJoin(writer,this);writer.WriteInt32(OutputAddress);writer.WriteInt32(ModuleWidth);}
        public override void DeserializeOnJoin(RocketBinaryReader reader)
        {
            base.DeserializeOnJoin(reader);
            var savedBoard=new PlacementBoardStructureSaveData{BoardId=reader.ReadInt64(),PrimaryHostId=reader.ReadInt64(),Position=reader.ReadGrid3(),Rotation=reader.ReadSByte()};
            OutputAddress=reader.ReadInt32();ModuleWidth=reader.ReadInt32()==SlotCount?SlotCount:1;SmartContactorModel.ApplyWidth(this);RestoreAddressState();
            // Width must be known before RegisterLoading computes occupancy cells.
            BoardStructureHooks.DeserializeSave(this,savedBoard);
        }
    }
}
