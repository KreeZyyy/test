using System;using System.Collections.Generic;using System.Linq;
using Assets.Scripts;using Assets.Scripts.Objects;using Assets.Scripts.Objects.Pipes;using Assets.Scripts.Objects.Motherboards;using Assets.Scripts.UI;using HarmonyLib;using Rendering;using UnityEngine;using UnityEngine.Rendering;
namespace ModularSwitchboards
{
    internal static class SmartContactorModel
    {
        internal static void Install(SmartContactor module,Transform storage,SmartModule core)
        {
            foreach(var renderer in module.GetComponentsInChildren<Renderer>(true))UnityEngine.Object.DestroyImmediate(renderer);
            foreach(var filter in module.GetComponentsInChildren<MeshFilter>(true))UnityEngine.Object.DestroyImmediate(filter);
            foreach(var hit in module.GetComponentsInChildren<Collider>(true))UnityEngine.Object.DestroyImmediate(hit);
            foreach(var animator in module.GetComponentsInChildren<Animator>(true))UnityEngine.Object.DestroyImmediate(animator);
            module.BaseAnimator=null;module.Slots=new List<Slot>();module.OpenEnds=new List<Connection>();module.UseCellPosition=false;
            module.Renderers=new List<ThingRenderer>();module._staticColliders=new List<Collider>();module._dynamicColliders=new List<Collider>();module._selfColliders=new List<Collider>();module.CustomNavMeshFilter=null;module.ForceGridBounds.Clear();module.BrokenBuildStates=new List<BrokenBuildState>();
            module.StructureCollisionType=CollisionType.BlockCustom;module.SelectionDisplay=SelectionHighlightMethod.Bounds;
            module.CustomColor=GameManager.GetColorSwatch((int)Assets.Scripts.Objects.Motherboards.ColorType.White);module.PaintableMaterial=module.CustomColor.Normal;module.HasColorState=false;module.MPBRenderers.Clear();module.UsedPower=5f;
            module.Interactables=module.Interactables.Where(i=>i.Action==InteractableType.OnOff||i.Action==InteractableType.Powered).ToList();
            foreach(var i in module.Interactables){i.Parent=module;i.Collider=null;i.Animator=null;i.FakeCollider=null;i.ParentInteractableIndex=-1;}
            SmartPrefabState.Configure(module,false);
            var model=new GameObject("DinBreakerModel"){layer=module.gameObject.layer};model.transform.SetParent(module.transform,false);model.transform.localScale=DinBreakerModel.VisualScale;
            var mesh=Body();
            model.AddComponent<MeshFilter>().sharedMesh=mesh;var mr=model.AddComponent<MeshRenderer>();mr.sharedMaterials=(Material[])CabinetGeometry.Materials.Clone();
            var collider=model.AddComponent<BoxCollider>();collider.center=mesh.bounds.center;collider.size=mesh.bounds.size;
            var state=module.BuildStates[0];state.Visualizer=mr;state.StateMeshes=new List<Mesh>();state.RendererInstance=null;state.Colliders=new List<Collider>{collider};state.Interactables=module.Interactables;state.LinkedGameObjects=new List<GameObject>();state.RenderMode=BuildStateRenderMode.OnMyState;
            AccessTools.Field(typeof(BuildState),"initialDrawData").SetValue(state,new DrawData{mesh=null,materials=new Material[0]});
            module.Thumbnail=CabinetIcons.Get("DinSmartContactor");module.Thumbnails=new Sprite[0];state.Thumbnail=module.Thumbnail;
            module.Bounds=new Bounds(Vector3.Scale(mesh.bounds.center,DinBreakerModel.VisualScale),Vector3.Scale(mesh.bounds.size,DinBreakerModel.VisualScale));module.GridBounds=new GridBounds(module);module.SurfaceArea=.016f*SmartContactor.SlotCount;
            var view=module.gameObject.AddComponent<SmartContactorView>();
            SmartOutputCorePanel.Install(module,view,core);
            var lens=GameObject.CreatePrimitive(PrimitiveType.Sphere);lens.name="OutputStatusLED";lens.layer=module.gameObject.layer;lens.transform.SetParent(model.transform,false);
            lens.transform.localPosition=new Vector3(SmartContactor.CenterX,.017f,.0641f);
            lens.transform.localScale=new Vector3(.006f/DinBreakerModel.VisualScale.x,.006f/DinBreakerModel.VisualScale.y,.0016f/DinBreakerModel.VisualScale.z);
            UnityEngine.Object.DestroyImmediate(lens.GetComponent<Collider>());
            var lensMaterial=SmartOutputElectronics.Material("ControlOutputLED",new Color(.025f,.04f,.025f));lensMaterial.EnableKeyword("_EMISSION");lensMaterial.SetColor("_EmissionColor",Color.black);
            lens.GetComponent<MeshRenderer>().sharedMaterial=lensMaterial;view.Lens=lens.GetComponent<MeshRenderer>();
            HousingAddressScrew.Install(model.transform,module.gameObject.layer,out var addressHit);
            var addressControl=new Interactable{Parent=module,Action=InteractableType.Mode,Collider=addressHit,JoinInProgressSync=true,CanKeyInteract=true,KeyMap="PrimaryAction"};
            module.Interactables.Add(addressControl);state.Interactables=module.Interactables;state.Colliders.Add(addressHit);
            module.CacheStates(true);ApplyWidth(module);
            var bp=new GameObject("SmartContactorBlueprint"){layer=module.gameObject.layer};bp.transform.SetParent(storage,false);var ghost=ModelBlueprint.Build(module.transform);var f=bp.AddComponent<MeshFilter>();f.sharedMesh=ghost;var rr=bp.AddComponent<MeshRenderer>();rr.sharedMaterial=CabinetGeometry.Materials[4];var wire=bp.AddComponent<Wireframe>();wire.BlueprintTransform=bp.transform;wire.BlueprintBounds=ghost.bounds;wire.BlueprintMeshFilter=f;wire.BlueprintRenderer=rr;bp.AddComponent<CabinetBlueprint>();module.Blueprint=bp;module.BlueprintOrientVector=Vector3.zero;
        }
        internal static Mesh Body()=>DinBreakerModel.Build(SmartContactor.BodyWidth,SmartContactor.CenterX,plain:true,bottomOnly:true);
        // Legacy width is restored first; the atomic load migration then expands the bus.
        // Scale only this instance's visuals; never claim a neighbour's saved slot.
        internal static void ApplyWidth(SmartContactor module)
        {
            var model=module.transform.Find("DinBreakerModel");if(model==null)return;
            float width=module.ModuleWidth==SmartContactor.SlotCount?SmartContactor.BodyWidth:.0176f;
            float ratio=width/SmartContactor.BodyWidth;
            model.localScale=new Vector3(DinBreakerModel.VisualScale.x*ratio,DinBreakerModel.VisualScale.y,DinBreakerModel.VisualScale.z);
            model.localPosition=new Vector3((module.ModuleWidth==1?-SmartContactor.CenterX*ratio:0)*DinBreakerModel.VisualScale.x,0,0);
            SmartOutputCorePanel.ApplyWidth(module,ratio);
            var mesh=model.GetComponent<MeshFilter>().sharedMesh;
            module.Bounds=CabinetWallMount.TransformedBounds(mesh.bounds,module.transform.worldToLocalMatrix*model.localToWorldMatrix);
            foreach(var renderer in module.GetComponentsInChildren<MeshRenderer>(true))
            {
                var filter=renderer.GetComponent<MeshFilter>();if(filter?.sharedMesh==null)continue;
                module.Bounds.Encapsulate(CabinetWallMount.TransformedBounds(filter.sharedMesh.bounds,module.transform.worldToLocalMatrix*renderer.transform.localToWorldMatrix));
            }
            module.GridBounds=new GridBounds(module);SmartOutputUpgrade.Reindex(module);
        }
    }
    public sealed class SmartContactorView:MonoBehaviour
    {
        public Transform Digits;public MeshRenderer Lens;public int MaxPixels;
        private SmartContactor owner;private Material lensMaterial;private int lastAddress=-2;
        private readonly List<GameObject> glyphs=new List<GameObject>();
        private void LateUpdate()
        {
            if(owner==null)owner=GetComponent<SmartContactor>();if(owner==null||Digits==null)return;
            if(lastAddress!=owner.OutputAddress){lastAddress=owner.OutputAddress;RebuildDigits();}
            Digits.gameObject.SetActive(owner.BusPowered);
            if(Lens==null)return;
            if(lensMaterial==null){lensMaterial=new Material(Lens.sharedMaterial);Lens.sharedMaterial=lensMaterial;}
            bool on=owner.Conducting;var color=on?new Color(.035f,.75f,.08f):new Color(.025f,.04f,.025f);var emission=on?DoorLedColours.For(DoorLedColours.GreenName).Emission:Color.black;
            lensMaterial.SetColor("_Color",color);lensMaterial.SetColor("_EmissionColor",emission);
            var block=new MaterialPropertyBlock();block.SetColor("_Color",color);block.SetColor("_EmissionColor",emission);Lens.SetPropertyBlock(block);Lens.SetPropertyBlock(block,0);
        }
        private void RebuildDigits()
        {
            foreach(var go in glyphs)if(go!=null)Destroy(go);glyphs.Clear();
            string value=SmartOutputAddresses.Valid(lastAddress)?"d"+lastAddress:"d-";
            int pixels=value.Sum(c=>{var mesh=GameManager.GetDigitMesh(c);return mesh==null?0:mesh.PixelWidth+1;});
            float offset=Mathf.FloorToInt((MaxPixels-pixels)*.5f)*GameManager.DigitPixel;
            for(int i=value.Length-1;i>=0;i--)
            {
                var digit=GameManager.GetDigitMesh(value[i]);if(digit==null)continue;offset+=GameManager.DigitPixel;
                if(digit.DigitMesh!=null)
                {
                    var go=new GameObject("AddressGlyph"){layer=gameObject.layer};go.transform.SetParent(Digits,false);go.transform.localPosition=new Vector3(offset,0,.001f);
                    go.AddComponent<MeshFilter>().sharedMesh=digit.DigitMesh;go.AddComponent<MeshRenderer>().sharedMaterial=GameManager.GetColorSwatch((int)Assets.Scripts.Objects.Motherboards.ColorType.Green).Emissive;glyphs.Add(go);
                }
                offset+=digit.PixelWidth*GameManager.DigitPixel;
            }
        }
        private void OnDestroy(){if(lensMaterial!=null)Destroy(lensMaterial);}
    }
}
