"""Icons for the door display and its dedicated label; native LED face uses the captured Core LED mesh."""
import bpy,json
from pathlib import Path
from mathutils import Vector
root=Path(__file__).resolve().parents[1]
reference=json.loads((root/'Art/CoreLED-reference.json').read_text())
def material(name,color):
 m=bpy.data.materials.new(name);m.diffuse_color=(*color,1);m.use_nodes=True;m.node_tree.nodes['Principled BSDF'].inputs['Base Color'].default_value=(*color,1);m.node_tree.nodes['Principled BSDF'].inputs['Roughness'].default_value=.65;return m
def box(name,center,size,mat):
 bpy.ops.mesh.primitive_cube_add(size=1,location=center);obj=bpy.context.object;obj.name=name;obj.dimensions=size;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);obj.data.materials.append(mat);bevel=obj.modifiers.new('Rounded casing','BEVEL');bevel.width=.001;bevel.segments=2;return obj
for job in ['DoorSmartDisplay','DoorDisplayLabel']:
 bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
 white=material('Light grey casing',(.68,.70,.69));black=material('Dark panel',(.015,.019,.018));paper=material('Label inset',(.88,.89,.86))
 if job=='DoorSmartDisplay':
  box('Button-style rear block',(.05,0,-.025),(.036,.046,.021),black)
  box('Single data terminal',(.05,0,-.0365),(.016,.012,.003),white)
  box('Central screw slot',(.05,0,-.0385),(.010,.001,.001),black)
  factor=.150/(.129385-.040615004)
  for part in reference:
   vertices=[((p[0]-.085)*factor+.05,p[1]*factor,(p[2]-.0743)*factor+.003)for p in part['vertices']]
   faces=[];groups=[]
   for group,indices in enumerate(part['triangles']):
    faces.extend([indices[i:i+3]for i in range(0,len(indices),3)]);groups.extend([group]*(len(indices)//3))
   mesh=bpy.data.meshes.new(part['name']);mesh.from_pydata(vertices,[],faces);mesh.update();obj=bpy.data.objects.new(part['name'],mesh);bpy.context.collection.objects.link(obj);mesh.materials.append(white if part['name']=='bezel' else black);mesh.materials.append(black)
   for polygon,group in zip(mesh.polygons,groups):polygon.material_index=group
 else:
  data=json.loads((root/'Art/DoorDisplayLabel.json').read_text());faces=[];groups=[]
  for group,indices in data['triangles'].items():faces.extend([indices[i:i+3]for i in range(0,len(indices),3)]);groups.extend([int(group)]*(len(indices)//3))
  mesh=bpy.data.meshes.new('Widened button label');mesh.from_pydata(data['vertices'],[],faces);mesh.update();obj=bpy.data.objects.new('Widened button label',mesh);bpy.context.collection.objects.link(obj);mesh.materials.append(black);mesh.materials.append(paper)
  for polygon,group in zip(mesh.polygons,groups):polygon.material_index=group
  bpy.ops.object.text_add(location=(.05,.050,.0032));text=bpy.context.object;text.data.body='DISPLAY';text.data.align_x='CENTER';text.data.align_y='CENTER';text.data.size=.014;text.data.materials.append(black)
 scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=24;scene.cycles.use_denoising=False;scene.render.resolution_x=scene.render.resolution_y=256;scene.render.resolution_percentage=100;scene.render.film_transparent=True;scene.world.color=(.25,.25,.25);scene.view_settings.view_transform='Standard'
 target=Vector((.05,.010,0));bpy.ops.object.camera_add(location=target+Vector((.050,-.080,.34)));camera=bpy.context.object;camera.rotation_euler=(target-camera.location).to_track_quat('-Z','Y').to_euler();camera.data.type='ORTHO';camera.data.ortho_scale=.235;scene.camera=camera
 bpy.ops.object.light_add(type='AREA',location=(.0,.15,.4));bpy.context.object.data.energy=5;bpy.context.object.data.size=.3
 out=root/'Assets/Icons'/f'{job}.png';temp=out.with_name(job+'.tmp165.png');scene.render.filepath=str(temp);bpy.ops.render.render(write_still=True);temp.replace(out)
