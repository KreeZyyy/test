using System;using System.Linq;using UnityEngine;
namespace ModularSwitchboards {
 internal static class DoorDisplayContour {
  // Captured native LED silhouette for offline authoring; prefab setup replaces
  // it with the currently installed game's actual transformed bezel contour.
  private static Vector3[] ring=new[]{new Vector3(-0.03417195f,-0.01178264f,0),new Vector3(-0.03118700f,-0.01893825f,0),new Vector3(-0.02589996f,-0.02418809f,0),new Vector3(-0.01869367f,-0.02715205f,0),new Vector3(0.11869367f,-0.02715205f,0),new Vector3(0.12589995f,-0.02418809f,0),new Vector3(0.12714003f,-0.02295676f,0),new Vector3(0.13118699f,-0.01893825f,0),new Vector3(0.13417194f,-0.01178264f,0),new Vector3(0.13417197f,0.00590176f,0),new Vector3(0.13417197f,0.01132057f,0),new Vector3(0.13118703f,0.01847620f,0),new Vector3(0.12589997f,0.02372605f,0),new Vector3(0.11869368f,0.02669002f,0),new Vector3(-0.01869368f,0.02669002f,0),new Vector3(-0.02589998f,0.02372605f,0),new Vector3(-0.03118701f,0.01847620f,0),new Vector3(-0.03417195f,0.01132058f,0)};
  internal static void Set(Vector3[] actual){if(actual==null||actual.Length<3)throw new InvalidOperationException("Door display contour missing.");ring=(Vector3[])actual.Clone();}
  internal static Vector3[] Offset(float distance){
   var result=new Vector3[ring.Length];
   for(int i=0;i<ring.Length;i++){
    var a=ring[(i+ring.Length-1)%ring.Length];var b=ring[i];var c=ring[(i+1)%ring.Length];
    double ux=b.x-a.x,uy=b.y-a.y,vx=c.x-b.x,vy=c.y-b.y;
    double u=Math.Sqrt(ux*ux+uy*uy),v=Math.Sqrt(vx*vx+vy*vy);
    double nx=uy/u,ny=-ux/u,mx=vy/v,my=-vx/v,den=1+nx*mx+ny*my;
    if(den<.00001)throw new InvalidOperationException("Invalid display contour corner.");
    result[i]=new Vector3(b.x+(float)((nx+mx)*distance/den),b.y+(float)((ny+my)*distance/den),0);
   }
   return result;
  }
 }
}
