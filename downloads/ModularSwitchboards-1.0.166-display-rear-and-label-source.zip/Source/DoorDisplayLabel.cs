using System;using System.Linq;using System.Collections.Generic;
using Assets.Scripts.GridSystem;using LibConstruct;using UnityEngine;
namespace ModularSwitchboards {
 public sealed class DoorDisplayLabel:DoorLabel {
  public const string PrefabId="StructureSwitchboardDoorDisplayLabel";
  internal static DoorSmartDisplay TargetDisplay(PlacementBoard board,Grid3 p){var host=board?.PrimaryHost as SwitchboardCabinet;return host?.DoorBoardFor(board)?.Structures.OfType<DoorSmartDisplay>().FirstOrDefault(d=>!d.IsBeingDestroyed&&!d.IsCursor&&d.IsStructureCompleted&&Same(board.WorldToGrid(d.transform.position),p));}
  private static bool Same(Grid3 a,Grid3 b)=>a.x==b.x&&a.y==b.y&&a.z==b.z;
  internal static bool Attached(DoorSmartDisplay display){var board=display.Cabinet?.DoorLabelsFor(display.Board);return board!=null&&board.Structures.OfType<DoorDisplayLabel>().Any(l=>!l.IsBeingDestroyed&&Same(board.WorldToGrid(l.transform.position),display.GetLocalGrid()));}
 }
    internal static class DoorDisplayLabelModel {internal static Mesh Build()=>DoorDisplayOutline.Build(true);}
 public sealed class DoorDisplayLabelView:MonoBehaviour {
  private DoorDisplayLabel owner;private TextMesh text;
  private void LateUpdate(){if(owner==null||owner.gameObject!=gameObject||text==null){owner=GetComponent<DoorDisplayLabel>();text=transform.Find("DisplayLabelText")?.GetComponent<TextMesh>();}if(owner==null||text==null)return;string value=owner.CustomName;if(string.IsNullOrWhiteSpace(value)||value=="Smart Display Label")value="DISPLAY";value=value.Replace('\r',' ').Replace('\n',' ');var info=new System.Globalization.StringInfo(value);if(info.LengthInTextElements>48)value=info.SubstringByTextElements(0,47)+"…";text.text=value;text.transform.localScale=Vector3.one;var size=text.GetComponent<MeshRenderer>().localBounds.size;text.transform.localScale=Vector3.one*Mathf.Min(.170f/Mathf.Max(.0001f,size.x),.015f/Mathf.Max(.0001f,size.y));DepthLabelText.Apply(text);}
  internal static void Install(DoorDisplayLabel label){Font font=null;foreach(var name in new[]{"LegacyRuntime.ttf","Arial.ttf"}){try{font=Resources.GetBuiltinResource<Font>(name);}catch(Exception){}if(font!=null)break;}if(font==null)font=Resources.FindObjectsOfTypeAll<Font>().FirstOrDefault();if(font==null)throw new InvalidOperationException("Display label font unavailable.");var go=new GameObject("DisplayLabelText"){layer=label.gameObject.layer};go.transform.SetParent(label.transform,false);go.transform.localPosition=new Vector3(.05f,.050f,.0032f);go.transform.localRotation=Quaternion.Euler(0,180,0);var text=go.AddComponent<TextMesh>();text.font=font;text.fontSize=96;text.fontStyle=FontStyle.Bold;text.characterSize=.01f;text.anchor=TextAnchor.MiddleCenter;text.alignment=TextAlignment.Center;text.richText=false;text.color=Color.black;text.text="DISPLAY";DepthLabelText.Apply(text);label.gameObject.AddComponent<DoorDisplayLabelView>();}
 }
}
