using Assets.Scripts;
using Assets.Scripts.Objects;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class CabinetPaintSurface
    {
        internal static void Apply(MeshRenderer renderer,int colour)
        {
            var material=GameManager.GetColorSwatch(colour)?.Normal;if(material==null||renderer.sharedMaterial==material)return;
            CabinetMatteSurface.Restore(renderer);
            var materials=renderer.sharedMaterials;
            if(materials.Length>0&&materials[0]!=material){materials[0]=material;renderer.sharedMaterials=materials;}
        }
        internal static float Smoothness(int colour,int fallback)
        {
            var material=GameManager.GetColorSwatch(colour)?.Normal;
            return material!=null&&material.HasProperty(Thing.SmoothnessIndexPropertyID)?material.GetFloat(Thing.SmoothnessIndexPropertyID):fallback;
        }
    }
}
