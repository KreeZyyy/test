using Assets.Scripts.Objects.Items;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Serialization;
using Assets.Scripts;
using Assets.Scripts.Objects;
using Assets.Scripts.Networking;
using Assets.Scripts.UI;
using UnityEngine;
namespace ModularSwitchboards
{
    public sealed class PortableCoverSaveData:DynamicThingSaveData
    {
        [XmlElement] public string CoverPayload;
    }
    public sealed class PortableCoverItem:Item
    {
        internal const string PrefabId="ItemSwitchboardFittedCover";
        [System.NonSerialized] internal CoverMemory State;
        private CoverMemory rendered;
        internal readonly List<Mesh> LabelMeshes=new List<Mesh>();
        internal GameObject OwnedBlueprint;internal Mesh BlueprintMesh;private int generation;
        internal string CursorKey=>"Switchboards.FittedCursor."+ReferenceId+"."+generation;
        internal void RefreshNow(){if(State!=null&&!ReferenceEquals(State,rendered)){PortableCoverVisual.Build(this,State,ref owned);rendered=State;generation++;}}
        private Mesh owned;
        public override void Awake(){base.Awake();}
        private void LateUpdate(){RefreshNow();if(State!=null)PortableCoverVisual.Restore(this,State);}
        public override PassiveTooltip GetPassiveTooltip(Collider hit)
        {
            var tip=base.GetPassiveTooltip(hit);
            if(State!=null)tip.Extended=(State.Width>.5f?"Medium":"Small")+" fitted cover, "+State.Labels.Length+" labels. Hold inside an open cabinet of the same size to fit. Label-retained openings and colour travel with this cover.";
            return tip;
        }
        internal const ushort ColourUpdate=32768;
        public override DelayedActionInstance AttackWith(Attack attack,bool doAction=true)
        {if(attack.SourceItem is ISprayer sprayer)return CoverPaint.Spray(this,sprayer,attack,doAction);return base.AttackWith(attack,doAction);}
        public override void BuildUpdate(RocketBinaryWriter writer,ushort flags){base.BuildUpdate(writer,flags);if(Thing.IsNetworkUpdateRequired(ColourUpdate,flags))writer.WriteString(State?.Pack()??"");}
        public override void ProcessUpdate(RocketBinaryReader reader,ushort flags){base.ProcessUpdate(reader,flags);if(Thing.IsNetworkUpdateRequired(ColourUpdate,flags)){State=CoverMemory.Unpack(reader.ReadString());rendered=null;}}
        public override ThingSaveData SerializeSave(){ThingSaveData data=new PortableCoverSaveData();InitialiseSaveData(ref data);return data;}
        protected override void InitialiseSaveData(ref ThingSaveData data){base.InitialiseSaveData(ref data);if(data is PortableCoverSaveData save)save.CoverPayload=State?.Pack();}
        public override void DeserializeSave(ThingSaveData data){base.DeserializeSave(data);State=CoverMemory.Unpack((data as PortableCoverSaveData)?.CoverPayload);rendered=null;}
        public override void SerializeOnJoin(RocketBinaryWriter writer){base.SerializeOnJoin(writer);writer.WriteString(State?.Pack()??"");}
        public override void DeserializeOnJoin(RocketBinaryReader reader){base.DeserializeOnJoin(reader);State=CoverMemory.Unpack(reader.ReadString());rendered=null;}
        public override void OnDestroy(){if(owned!=null)Destroy(owned);if(BlueprintMesh!=null)Destroy(BlueprintMesh);foreach(var label in LabelMeshes)if(label!=null)Destroy(label);base.OnDestroy();}
        internal static void Install(PortableCoverItem item)
        {
            foreach(var r in item.GetComponentsInChildren<Renderer>(true))DestroyImmediate(r);
            foreach(var f in item.GetComponentsInChildren<MeshFilter>(true))DestroyImmediate(f);
            foreach(var c in item.GetComponentsInChildren<Collider>(true))DestroyImmediate(c);
            foreach(var l in item.GetComponentsInChildren<LODGroup>(true))DestroyImmediate(l);
            item.Interactables=new List<Interactable>();item.Renderers=new List<ThingRenderer>();item.Slots=new List<Slot>();
            item._staticColliders=new List<Collider>();item._dynamicColliders=new List<Collider>();item._selfColliders=new List<Collider>();
            item.EmissionColor=Color.black;
            item.PaintableMaterial=GameManager.GetColorSwatch((int)Assets.Scripts.Objects.Motherboards.ColorType.White).Normal;item.HasColorState=false;
            // Payload is instance-only; an empty catalog prefab is not a free cover.
            item.HideInStationpedia=true;item.Thumbnail=CabinetIcons.Get("InnerCover");item.Thumbnails=new Sprite[0];
            var state=CoverMemory.Fresh(InnerCoverLayout.Small,(int)Assets.Scripts.Objects.Motherboards.ColorType.White);
            Mesh mesh=null;PortableCoverVisual.Build(item,state,ref mesh);item.owned=mesh;
        }
    }
    internal static class PortableCoverVisual
    {
        internal static void Build(PortableCoverItem item,CoverMemory state,ref Mesh owned)
        {
            foreach(var labelMesh in item.LabelMeshes)if(labelMesh!=null)Object.Destroy(labelMesh);item.LabelMeshes.Clear();
            var old=item.transform.Find("FittedCoverModel");if(old!=null){old.gameObject.SetActive(false);Object.Destroy(old.gameObject);}
            var root=new GameObject("FittedCoverModel"){layer=item.gameObject.layer};root.transform.SetParent(item.transform,false);root.transform.localPosition=new Vector3(0,0,-state.Depth);
            var mesh=CabinetInnerCover.Build(state.Retained,state.Profile);root.AddComponent<MeshFilter>().sharedMesh=mesh;
            var renderer=root.AddComponent<MeshRenderer>();renderer.sharedMaterials=CabinetGeometry.Materials;Paint(renderer,state.Colour,item.SmoothnessIndex);
            foreach(var label in state.Labels)
            {
                var child=new GameObject("RetainedLabel"){layer=item.gameObject.layer};child.transform.SetParent(root.transform,false);
                child.transform.localPosition=new Vector3(-state.HalfSpan+label.X*.00045f,.0525f+label.Y*.00045f,state.Depth+.003f);
                var labelMesh=SwitchboardLabel.Mesh(label.Width);item.LabelMeshes.Add(labelMesh);child.AddComponent<MeshFilter>().sharedMesh=labelMesh;var face=child.AddComponent<MeshRenderer>();SwitchboardLabelSurface.Apply(face);
                Text(child.transform,label);
            }
            var hit=item.GetComponent<BoxCollider>()??item.gameObject.AddComponent<BoxCollider>();hit.center=Vector3.zero;hit.size=new Vector3(state.Width,state.Height,.012f);
            item._selfColliders=new List<Collider>{hit};item._dynamicColliders=new List<Collider>{hit};Thing._colliderLookup[hit]=item;
            item.Renderers=new List<ThingRenderer>();foreach(var r in root.GetComponentsInChildren<MeshRenderer>(true))item.Renderers.Add(new ThingRenderer(item,r));
            item.Bounds=new Bounds(Vector3.zero,new Vector3(state.Width,state.Height,.012f));
            if(owned!=null)Object.Destroy(owned);owned=mesh;
            if(item.OwnedBlueprint!=null)Object.Destroy(item.OwnedBlueprint);if(item.BlueprintMesh!=null)Object.Destroy(item.BlueprintMesh);
            var ghost=ModelBlueprint.Build(item.transform);var bp=new GameObject("FittedCoverBlueprint"){layer=item.gameObject.layer};bp.transform.SetParent(item.transform,false);bp.SetActive(false);
            bp.AddComponent<MeshFilter>().sharedMesh=ghost;var br=bp.AddComponent<MeshRenderer>();br.sharedMaterial=CabinetGeometry.Materials[4];
            var wire=bp.AddComponent<Assets.Scripts.UI.Wireframe>();wire.BlueprintTransform=bp.transform;wire.BlueprintBounds=ghost.bounds;wire.BlueprintMeshFilter=bp.GetComponent<MeshFilter>();wire.BlueprintRenderer=br;bp.AddComponent<CabinetBlueprint>();
            item.Blueprint=bp;item.BlueprintOrientVector=Vector3.zero;item.Wireframe=null;item.OwnedBlueprint=bp;item.BlueprintMesh=ghost;
        }
        internal static void Restore(PortableCoverItem item,CoverMemory state)
        {
            var root=item.transform.Find("FittedCoverModel");if(root==null)return;Paint(root.GetComponent<MeshRenderer>(),state.Colour,item.SmoothnessIndex);
            foreach(var renderer in root.GetComponentsInChildren<MeshRenderer>(true))if(renderer.name=="RetainedLabel")SwitchboardLabelSurface.Apply(renderer);
            foreach(var text in root.GetComponentsInChildren<TextMesh>(true))DepthLabelText.Apply(text);
        }
        internal static void Paint(MeshRenderer renderer,int colour,int smoothness){CabinetPaintSurface.Apply(renderer,colour);var block=new MaterialPropertyBlock();block.SetFloat(Thing.DiffuseIndexPropertyID,colour);block.SetFloat(Thing.SmoothnessIndexPropertyID,CabinetPaintSurface.Smoothness(colour,smoothness));block.SetColor(Thing.EMISSION_COLOR,Color.black);renderer.SetPropertyBlock(block,0);}
        private static void Text(Transform parent,CoverLabelMemory label)
        {
            Font font=null;foreach(var name in new[]{"LegacyRuntime.ttf","Arial.ttf"}){try{font=Resources.GetBuiltinResource<Font>(name);}catch(System.Exception){}if(font!=null)break;}if(font==null)return;
            var go=new GameObject("RetainedLabelText"){layer=parent.gameObject.layer};go.transform.SetParent(parent,false);go.transform.localPosition=new Vector3((label.Width-1)*DinLayout.SlotPitch*.5f,0,.0015f);go.transform.localRotation=Quaternion.Euler(0,180,0);
            var text=go.AddComponent<TextMesh>();text.font=font;text.fontSize=96;text.fontStyle=FontStyle.Bold;text.lineSpacing=.85f;text.characterSize=.01f;text.anchor=TextAnchor.MiddleCenter;text.alignment=TextAlignment.Center;text.richText=false;text.color=Color.black;
            var renderer=text.GetComponent<MeshRenderer>();var value=label.Text;if(string.IsNullOrWhiteSpace(value)||value==SwitchboardNames.LabelTitle(label.Width)||value=="Switchboard Label ("+label.Width+" module"+(label.Width==1?"":"s")+")")value="LABEL";var fit=LabelTextLayout.Arrange(value,label.Width*DinLayout.SlotPitch-.0068f,.015f,candidate=>{text.text=candidate;var size=renderer.localBounds.size;return new LabelTextLayout.Size(size.x,size.y);});text.text=fit.Text;text.transform.localScale=Vector3.one*fit.Scale;DepthLabelText.Apply(text);
        }
    }
}
