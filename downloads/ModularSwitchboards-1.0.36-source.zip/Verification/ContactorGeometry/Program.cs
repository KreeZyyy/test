using System;using System.Linq;using System.IO;using System.Text.Json;using UnityEngine;using ModularSwitchboards;
class Program
{
 static int checks;static void Check(bool v,string why){checks++;if(!v)throw new Exception(why);}
 static float Front(Mesh mesh,float x,float y)
 {
  float z=float.NegativeInfinity;var v=mesh.vertices;
  foreach(var t in mesh.T.Values)for(int i=0;i<t.Length;i+=3)
  {
   var a=v[t[i]];var b=v[t[i+1]];var c=v[t[i+2]];float d=(b.y-c.y)*(a.x-c.x)+(c.x-b.x)*(a.y-c.y);if(Math.Abs(d)<1e-12f)continue;
   float u=((b.y-c.y)*(x-c.x)+(c.x-b.x)*(y-c.y))/d,w=((c.y-a.y)*(x-c.x)+(a.x-c.x)*(y-c.y))/d,r=1-u-w;
   if(u>=0&&w>=0&&r>=0)z=Math.Max(z,u*a.z+w*b.z+r*c.z);
  }return z;
 }
 static object Data(Mesh m)=>new{vertices=m.vertices.Select(v=>new[]{v.x,v.y,v.z}),triangles=m.T.ToDictionary(p=>p.Key.ToString(),p=>p.Value)};
 static void EqualRole(Mesh a,Mesh b,int role,string why){var x=a.GetTriangles(role).Select(i=>a.vertices[i]).ToArray();var y=b.GetTriangles(role).Select(i=>b.vertices[i]).ToArray();Check(x.Length==y.Length,why+" count");for(int i=0;i<x.Length;i++)Check((x[i]-y[i]).sqrMagnitude<1e-16f,why);}
 static void Main(string[] args)
 {
  var body=DinContactorModel.Build();var old=PreviousBody.Build(plain:true);
  EqualRole(body,old,1,"contactor white shell exactly preserves breaker rounded geometry");
  var normal=DinBreakerModel.Build();var previous=PreviousBody.Build();for(int role=0;role<5;role++)EqualRole(normal,previous,role,"default builder unchanged for other module callers");
  Check(body.bounds.size.x<.018f,"one DIN footprint");Check(Front(body,0,.03f)>.0569f,"solid native shell between top screws");
  int holes=0;var ids=body.GetTriangles(3);for(int i=0;i<ids.Length;i+=3){var v=ids.Skip(i).Take(3).Select(k=>body.vertices[k]).ToArray();if(v.All(p=>p.y>.0375f)){holes++;Check(v.All(p=>Math.Abs(p.x)>.0025f),"no center top hole or squares");}}
  Check(holes==32,"two round top holes, 16 native disk segments each");
  using var j=JsonDocument.Parse(File.ReadAllText(args[0]));var r=j.RootElement;var source=new Mesh{subMeshCount=1};
  source.vertices=r.GetProperty("vertices").EnumerateArray().Select(p=>new Vector3(p[0].GetSingle(),p[1].GetSingle(),p[2].GetSingle())).ToArray();source.uv=r.GetProperty("uv").EnumerateArray().Select(p=>new Vector2(p[0].GetSingle(),p[1].GetSingle())).ToArray();source.UV=source.uv.ToList();source.SetTriangles(r.GetProperty("triangles").EnumerateArray().Select(x=>x.GetInt32()).ToArray(),0);
  var window=ApcContactorWindow.Build(source,Matrix4x4.identity);
  foreach(var v in window.vertices)Check(Math.Abs(v.z-.0644f)<1e-6f||Math.Abs(v.z-.0648f)<1e-6f,"only flat rim and letters, no hinge blocks or internal steps");
  int legends=0;for(int i=0;i<source.vertices.Length;i++)
  {
   var a=source.vertices[i];if(a.x<0||a.x>.138f||Math.Abs(a.y)<.09f||Math.Abs(a.y)>.14f||Math.Abs(a.z-.17091f)>.00001f)continue;
   var m=ApcContactorWindow.MapLegend(a);bool match=false;
   for(int k=0;k<window.vertices.Length;k++)if((window.vertices[k]-m).sqrMagnitude<1e-12f&&Math.Abs(window.UV[k].x-source.uv[i].x)<1e-5f&&Math.Abs(window.UV[k].y-source.uv[i].y)<1e-5f){match=true;break;}
   Check(match,"original ON/OFF geometry and UV retained");legends++;
  }Check(legends>40,"actual native legend fixture");
  foreach(bool on in new[]{true,false})
  {
   var input=source.vertices.Where(p=>p.x>0&&p.x<.138f&&Math.Abs(p.z-.17091f)<.00001f&&(on?p.y>.09f:p.y<-.09f)).ToArray();var mapped=input.Select(ApcContactorWindow.MapLegend).ToArray();
   float nativeAspect=(input.Max(p=>p.x)-input.Min(p=>p.x))/(input.Max(p=>p.y)-input.Min(p=>p.y));float aspect=(mapped.Max(p=>p.x)-mapped.Min(p=>p.x))*2.25f/((mapped.Max(p=>p.y)-mapped.Min(p=>p.y))*1.35f);Check(Math.Abs(nativeAspect-aspect)<.0001f,"native letter proportions not squashed");
  }
  var slider=DinContactorModel.BuildSlider();var onPanel=DinContactorModel.BuildPanel(true);var offPanel=DinContactorModel.BuildPanel(false);
  Check(slider.bounds.size.y<.015f&&slider.GetTriangles(3).Length==0,"small slider, one grip");
  Check(Front(slider,0,0)>.067f,"single grip raised above letters");
  Check(onPanel.bounds.max.z<.0648f&&offPanel.bounds.max.z<.0648f,"flat coloured plates behind native letters");
  var left=ApcBreakerBearings.Build(source,Matrix4x4.identity,true,.1182598f);var right=ApcBreakerBearings.Build(source,Matrix4x4.identity,false,.1182598f);
  Check(left.GetTriangles(0).Length/3==17&&right.GetTriangles(0).Length/3==17,"two original APC hinge components only");
  Check(Math.Abs(left.bounds.max.x+.006f)<.00015f&&Math.Abs(right.bounds.min.x-.006f)<.00015f,"bearings meet actual flap edges");
  Check(left.UV.Count==left.vertices.Length&&right.UV.Count==right.vertices.Length,"native bearing UVs retained");
  File.WriteAllText(args[1],JsonSerializer.Serialize(new{body=Data(body),nativeWindow=Data(window),slider=Data(slider),onPanel=Data(onPanel),offPanel=Data(offPanel),breakerBody=Data(DinBreakerModel.Build(plain:true)),bearingLeft=Data(left),bearingRight=Data(right)}));
  Console.WriteLine(checks+" contactor/breaker geometry and native surface checks passed; flat window "+window.GetTriangles(0).Length/3+" triangles.");
 }
}
