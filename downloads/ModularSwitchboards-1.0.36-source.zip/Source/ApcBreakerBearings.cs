using System;
using System.Linq;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Electrical;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class ApcBreakerBearings
    {
        private static Mesh[] meshes;private static MeshRenderer source;private static bool attempted;
        internal static Bounds Region(bool left)=>new Bounds(new Vector3(left?.004657f:.132583f,0,.182116f),new Vector3(.0099f,.0224f,.0261f));
        internal static Vector3 Map(Vector3 p,float leverWidth)
        {
            float fit=.012f*DinBreakerModel.VisualScale.x/leverWidth;
            return new Vector3((p.x-.069f)*fit/DinBreakerModel.VisualScale.x,p.y*fit/DinBreakerModel.VisualScale.y,.0675f+(p.z-.18f)*fit/DinBreakerModel.VisualScale.z);
        }
        internal static Mesh Build(Mesh original,Matrix4x4 frame,bool left,float leverWidth)
        {
            var region=Region(left);
            var result=NativeMeshCrop.Read(original,frame,region,"Breaker.OriginalAPCBearing",(a,b,c)=>region.Contains(a)&&region.Contains(b)&&region.Contains(c));
            if(result==null)throw new InvalidOperationException("Original APC spindle bearing missing.");
            var v=result.vertices;for(int i=0;i<v.Length;i++)v[i]=Map(v[i],leverWidth);result.vertices=v;result.RecalculateNormals();result.RecalculateTangents();result.RecalculateBounds();return result;
        }
        internal static bool Ready
        {
            get
            {
                if(!attempted)
                {
                    attempted=true;
                    try
                    {
                        var apc=WorldManager.Instance.SourcePrefabs.OfType<AreaPowerControl>().First(p=>p.PrefabName=="StructureAreaPowerControl");source=apc.GetComponent<MeshRenderer>();
                        var front=Matrix4x4.Rotate(CabinetModel.FrontSign<0?Quaternion.Euler(0,180,0):Quaternion.identity)*apc.transform.worldToLocalMatrix;
                        var lever=apc.GetComponentsInChildren<MeshRenderer>(true).First(r=>r.name=="MasterLever");
                        CabinetGeometry.ReadNativeMesh(lever.GetComponent<MeshFilter>().sharedMesh,out var vertices,out _,out _);
                        var pose=front*lever.transform.localToWorldMatrix;var points=vertices.Select(p=>pose.MultiplyPoint3x4(p)).ToArray();float width=points.Max(p=>p.x)-points.Min(p=>p.x);
                        if(width<=0)throw new InvalidOperationException("Invalid native lever width.");
                        var frame=front*source.transform.localToWorldMatrix;var mesh=source.GetComponent<MeshFilter>().sharedMesh;
                        meshes=new[]{Build(mesh,frame,true,width),Build(mesh,frame,false,width)};
                    }
                    catch(Exception ex){meshes=null;Debug.LogWarning("[Modular Switchboards] Native APC bearings unavailable; retaining original fallback: "+ex.Message);}
                }
                return meshes!=null;
            }
        }
        internal static void Install(Transform parent)
        {
            if(!Ready)return;
            for(int i=0;i<2;i++)
            {
                var go=new GameObject(i==0?"BreakerNativeBearingLeft":"BreakerNativeBearingRight"){layer=parent.gameObject.layer};go.transform.SetParent(parent,false);
                go.AddComponent<MeshFilter>().sharedMesh=meshes[i];NativePortSurface.Capture(source,go.AddComponent<MeshRenderer>());
            }
        }
        internal static void Restore(Thing owner)
        {
            foreach(var surface in owner.GetComponentsInChildren<NativePortSurface>(true))
            {
                if(!surface.name.StartsWith("BreakerNativeBearing"))continue;
                var renderer=surface.GetComponent<MeshRenderer>();if(renderer==null)continue;renderer.SetPropertyBlock(null);surface.Restore();
            }
        }
    }
}
