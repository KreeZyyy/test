using System;
using System.Collections.Generic;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Motherboards;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class DinContactorModel
    {
        internal const string PrefabName="StructureDinContactor";
        internal static void Install(DinBreaker module)
        {
            var model=module.transform.Find("DinBreakerModel");
            foreach(var name in new[]{"BreakerLever","BreakerIndicator","BreakerControl"}){var t=model.Find(name);if(t!=null)UnityEngine.Object.DestroyImmediate(t.gameObject);}
            var oldView=module.GetComponent<BreakerSwitchView>();if(oldView!=null)UnityEngine.Object.DestroyImmediate(oldView);
            var mesh=Build();
            model.GetComponent<MeshFilter>().sharedMesh=mesh;
            var hit=model.GetComponent<BoxCollider>();hit.center=mesh.bounds.center;hit.size=mesh.bounds.size;
            module.Interactables=new List<Interactable>();module.HasOnOffState=false;module.ContactorClosed=false;
            var state=module.BuildStates[0];state.Interactables=module.Interactables;state.Colliders=new List<Collider>{hit};
            module.Thumbnail=CabinetIcons.Get("DinContactor");module.Thumbnails=new Sprite[0];state.Thumbnail=module.Thumbnail;
            module.CacheStates(true);
            var window=ApcContactorWindow.Install(model);
            foreach(bool on in new[]{true,false})
            {
                var panel=new GameObject(on?"ContactorOnPanel":"ContactorOffPanel"){layer=module.gameObject.layer};panel.transform.SetParent(model,false);
                panel.AddComponent<MeshFilter>().sharedMesh=BuildPanel(on);panel.AddComponent<MeshRenderer>().sharedMaterials=CabinetGeometry.Materials;
            }
            var slider=new GameObject("ContactorMechanicalSlider"){layer=module.gameObject.layer};slider.transform.SetParent(model,false);
            slider.transform.localPosition=new Vector3(0,ContactorIndicatorMotion.HalfTravel,0);
            var moving=BuildSlider();
            slider.AddComponent<MeshFilter>().sharedMesh=moving;slider.AddComponent<MeshRenderer>().sharedMaterials=CabinetGeometry.Materials;
            var view=module.gameObject.AddComponent<DinContactorView>();view.Owner=module;view.Slider=slider.transform;view.WindowSurface=window;
            DinBreakerModel.Refresh(module);
            if(module.Blueprint!=null)ModelBlueprint.Refresh(module);
        }

        internal static Mesh BuildSlider()
        {
            var vertices=new List<Vector3>();var normals=new List<Vector3>();var groups=new List<int>[5];for(int i=0;i<5;i++)groups[i]=new List<int>();
            RoundedGeometry.Box(vertices,normals,groups[4],new Vector3(0,0,.0657f),new Vector3(.0092f,.011f,.0012f),.0005f);
            RoundedGeometry.Box(vertices,normals,groups[4],new Vector3(0,0,.0669f),new Vector3(.0068f,.002f,.0015f),.0004f);
            var moving=new Mesh{name="Contactor.CompactSlider"};moving.SetVertices(vertices);moving.SetNormals(normals);moving.subMeshCount=5;for(int i=0;i<5;i++)moving.SetTriangles(groups[i],i);CabinetGeometry.ApplyNativeUv(moving);moving.RecalculateBounds();return moving;
        }

        internal static Mesh Build(){return DinBreakerModel.Build(plain:true,contactor:true);}
        internal static Mesh BuildPanel(bool on)
        {
            var v=new List<Vector3>();var n=new List<Vector3>();var g=new List<int>[5];for(int i=0;i<5;i++)g[i]=new List<int>();
            RoundedGeometry.Box(v,n,g[0],new Vector3(0,on?.0063f:-.0063f,.06445f),new Vector3(.0088f,.0078f,.0003f),.0001f);
            var mesh=new Mesh{name="Contactor.FlatStatePanel"};mesh.SetVertices(v);mesh.SetNormals(n);mesh.subMeshCount=5;for(int i=0;i<5;i++)mesh.SetTriangles(g[i],i);CabinetGeometry.ApplyNativeUv(mesh);mesh.RecalculateBounds();return mesh;
        }

    }
    // Only the visual follows the replicated contact state. Initial load/join/preview
    // snaps silently; subsequent changes animate and play one local native clack.
    public sealed class DinContactorView:MonoBehaviour
    {
        public DinBreaker Owner;
        public Transform Slider;
        public NativePortSurface WindowSurface;
        private ContactorIndicatorMotion motion;
        private void LateUpdate()
        {
            if(Owner==null)Owner=GetComponent<DinBreaker>();
            if(Owner==null||Slider==null)return;
            if(Owner.IsCursor){motion=null;return;}
            if(motion==null)motion=new ContactorIndicatorMotion();
            bool active=!Owner.IsCursor&&!Owner.IsBeingDestroyed&&Owner.Board!=null;
            bool changed=motion.Tick(active,Owner.ContactorClosed,Time.deltaTime);
            Slider.localPosition=new Vector3(0,motion.Offset,0);
            if(WindowSurface!=null)
            {
                var renderer=WindowSurface.GetComponent<MeshRenderer>();
                if(renderer!=null){renderer.SetPropertyBlock(null);WindowSurface.Restore();}
            }
            if(changed)ContactorSwitchAudio.Play(Owner,Owner.ContactorClosed);
        }
    }
}
