from pathlib import Path
root=Path(__file__).resolve().parents[1];s=(root/'Source/DinContactorModel.cs').read_text();a=s.index('    public sealed class DinContactorView:');class_text=s[a:s.rfind('}')];out=root/'Verification/ContactorPreview';out.mkdir(exist_ok=True)
(out/'Extracted.cs').write_text('using UnityEngine;namespace ModularSwitchboards{'+class_text.replace('private void LateUpdate()','internal void LateUpdate()')+'}')
(out/'Check.csproj').write_text('<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><OutputType>Exe</OutputType><TargetFramework>net8.0</TargetFramework></PropertyGroup><ItemGroup><Compile Include="../../Source/ContactorIndicatorMotion.cs"/></ItemGroup></Project>')
