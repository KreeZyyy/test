using System;using System.Linq;using System.Collections.Generic;using ModularSwitchboards;
static class Debug{public static void Log(string s){}public static void LogWarning(string s){}}
struct Vector3{public float x,y,z;public Vector3(float x,float y,float z){this.x=x;this.y=y;this.z=z;}public static Vector3 operator +(Vector3 a,Vector3 b)=>new(a.x+b.x,a.y+b.y,a.z+b.z);}
class RouteHarness{
 internal class Contact{internal CabinetWireEnd End;internal Vector3 Position,Exit;internal WireRect Bounds;}
 internal Dictionary<CabinetWireEnd,Contact> contacts=new();internal List<CabinetWireSaveData> wires=new();internal List<WireRect> railObstacles=new();readonly WireRect[] moduleReservations=WireModuleSpace.Reservations().ToArray();const int CurrentRouteVersion=3;bool needsReroute;string migrationFailure;int changes;void Changed(){changes++;}static float[] Flatten(IList<WirePoint> path)=>path.SelectMany(p=>new[]{p.X,p.Y,p.Z}).ToArray();static WirePoint Point(Vector3 p)=>new(p.x,p.y,p.z);
 static WirePoint[] Expand(float[] p)=>Enumerable.Range(0,p.Length/3).Select(i=>new WirePoint(p[i*3],p[i*3+1],p[i*3+2])).ToArray();
        internal WirePoint[] MakeRoute(CabinetWireEnd from,CabinetWireEnd to,out int slot,out string failure)
        {
            var used=new HashSet<int>(wires.Where(w=>w.From.Equals(from)).Select(w=>w.InputSlot));
            var candidates=Enumerable.Range(0,16).Where(i=>!used.Contains(i)).OrderBy(i=>i==0?0:((contacts[to].Exit.x<=0)==(i%2==1)?i:100+i));
            if(from.Owner!=0)candidates=Enumerable.Repeat(0,1).OrderBy(i=>i);
            failure=null;slot=0;
            foreach(var plane in new[]{WireRouting.Plane,.070f,.078f,.086f})
            foreach(var candidate in candidates)
            {
                var found=MakeRouteSlot(from,to,candidate,plane,out failure);
                if(found!=null){slot=candidate;return found;}
            }
            return null;
        }
        private WirePoint[] MakeRouteSlot(CabinetWireEnd from,CabinetWireEnd to,int slot,float plane,out string failure)
        {
            failure=null;var a=contacts[from];var b=contacts[to];
            bool joint=from.Owner==0&&from.Contact==0;
            float fan=slot==0?0:((slot+1)/2)*.008f*(slot%2==1?1:-1);
            var start=new WirePoint(a.Exit.x+(joint?fan:0),a.Exit.y,plane);var end=new WirePoint(b.Exit.x,b.Exit.y,plane);
            var blocks=contacts.Values.Select(c=>c.Bounds).Concat(railObstacles).Concat(moduleReservations).Distinct().ToList();
            var occupied=wires.Select(w=>Expand(w.Points)).ToList();
            var middle=WireRouting.Find(start,end,blocks,occupied,joint,3);
            if(middle==null){failure="No clear route around devices and installed wires.";return null;}
            var path=new List<WirePoint>(WireContactLayout.EntryLead(Point(a.Position),start));
            path.AddRange(middle.Skip(1));path.AddRange(WireContactLayout.EntryLead(Point(b.Position),end).Reverse().Skip(1));
            // Check contact leads too; the router only controls the central part.
            var leadReservations=WireModuleSpace.ForLead(moduleReservations,from.Owner==0?(WireRect?)null:a.Bounds,to.Owner==0?(WireRect?)null:b.Bounds);
            var exceptOwn=contacts.Values.Where(c=>!c.End.Equals(from)&&!c.End.Equals(to)&&
                    !(c.End.Owner!=0&&(c.End.Owner==from.Owner||c.End.Owner==to.Owner))).Select(c=>c.Bounds).Concat(railObstacles).Concat(leadReservations).Distinct().ToList();
            for(int i=1;i<path.Count;i++)
            {
                if(!WireRouting.Clear(path[i-1],path[i],exceptOwn,occupied,joint)){failure="A contact lead is blocked by another wire or device.";return null;}
            }
            var result=path.Where((p,i)=>i==0||(p-path[i-1]).Squared>1e-12f).ToArray();
            if(result.Length>512){failure="The route is too complex. Move a wire or device first.";return null;}
            if(WireRouting.SelfIntersects(result)){failure="The route would intersect its own contact lead.";return null;}
            // Store the rounded centreline itself: preview, hit testing, saves and
            // subsequent wire clearance all use exactly the rendered route.
            foreach(float cut in new[]{.008f,.006f,.004f})
            {
                var rounded=WireTube.Round(result,cut);
                if(rounded.Length>512||WireRouting.SelfIntersects(rounded))continue;
                bool clear=true;
                for(int i=1;i<rounded.Length;i++)if(!WireRouting.Clear(rounded[i-1],rounded[i],exceptOwn,occupied,joint)){clear=false;break;}
                if(clear)return rounded;
            }
            return result;
        }
        private void RerouteLegacy()
        {
            needsReroute=false;var backup=wires.ToArray();wires.Clear();
            foreach(var old in backup.OrderBy(w=>w.From.Owner==0?0:1))
            {
                var path=MakeRoute(old.From,old.To,out var slot,out var failure);
                if(path==null)
                {
                    wires.Clear();wires.AddRange(backup);migrationFailure="Existing route needs manual rewiring: "+failure;
                    Debug.LogWarning("[Modular Switchboards] "+migrationFailure+" Connections and coil quantities preserved.");return;
                }
                wires.Add(new CabinetWireSaveData{From=old.From,To=old.To,InputSlot=slot,RouteVersion=CurrentRouteVersion,CableUnits=old.CableUnits,Points=Flatten(path)});
            }
            migrationFailure=null;Changed();
            Debug.Log("[Modular Switchboards] Existing wiring rerouted around reserved future module spaces without changing connections or coil quantities.");
        }

 void VerifyFutureSpace(WirePoint[] path,CabinetWireEnd from,CabinetWireEnd to){
  foreach(var reserved in WireModuleSpace.ForLead(moduleReservations,from.Owner==0?(WireRect?)null:contacts[from].Bounds,to.Owner==0?(WireRect?)null:contacts[to].Bounds))
   for(int i=1;i<path.Length;i++)if(WireRouting.SegmentHitsRect(path[i-1],path[i],reserved,WireRouting.Radius+.001f))throw new Exception("Future module or contact entry blocked");
  TubeHarness.AssertSections(path);
 }
 internal static void Run(){var h=new RouteHarness();var input=new CabinetWireEnd(0,0);h.railObstacles.Add(new(-.162f,.162f,.0905f,.1255f));h.railObstacles.Add(new(-.162f,.162f,-.1255f,-.0905f));h.contacts[input]=new(){End=input,Position=new(0,.196f,.033f),Exit=new(0,.184f,WireRouting.Plane),Bounds=new(-.036f,.036f,.195f,.227f)};
 for(int i=1;i<=2;i++){float x=i==1?.108f:-.108f;var e=new CabinetWireEnd(0,i);h.contacts[e]=new(){End=e,Position=new(x,-.196f,.033f),Exit=new(x,-.184f,WireRouting.Plane),Bounds=new(x-.036f,x+.036f,-.227f,-.195f)};}
 for(int i=0;i<3;i++){float x=-.14175f+i*.0405f;var bounds=new WireRect(x-.0198f,x+.0198f,.108f-.050625f,.108f+.050625f);for(int pin=0;pin<2;pin++){var e=new CabinetWireEnd(10+i,pin);h.contacts[e]=new(){End=e,Position=new(x,.108f+(pin==0?.050625f:-.050625f),.06535f),Exit=new(x,pin==0?.174f:.042f,WireRouting.Plane),Bounds=bounds};}}
 for(int i=0;i<3;i++){var target=new CabinetWireEnd(10+i,0);var p=h.MakeRoute(input,target,out int slot,out var fail);if(p==null)throw new Exception("Full contact route "+i+": "+fail);h.VerifyFutureSpace(p,input,target);foreach(var rail in h.railObstacles)for(int j=1;j<p.Length;j++)if(WireRouting.SegmentHitsRect(p[j-1],p[j],rail,WireRouting.Radius+.001f))throw new Exception("IN route crosses DIN rail");var values=p.SelectMany(q=>new[]{q.X,q.Y,q.Z}).ToArray();h.wires.Add(new(){From=input,To=target,InputSlot=slot,Points=values});Console.WriteLine("Production full route "+i+" passed, fan slot "+slot+", vertices "+p.Length);}
 for(int i=0;i<2;i++){var source=new CabinetWireEnd(10+i,1);var target=new CabinetWireEnd(0,i+1);var p=h.MakeRoute(source,target,out int slot,out var fail);if(p==null)throw new Exception("Output route "+i+": "+fail);h.VerifyFutureSpace(p,source,target);foreach(var rail in h.railObstacles)for(int j=1;j<p.Length;j++)if(WireRouting.SegmentHitsRect(p[j-1],p[j],rail,WireRouting.Radius+.001f))throw new Exception("Output route crosses DIN rail");if(p.Any(q=>q.Y>h.contacts[source].Position.y+.003f))throw new Exception("Unnecessary output detour above breaker");if(!p.Any(q=>Math.Abs(q.X)>.164f))throw new Exception("Output did not use side corridor");h.wires.Add(new(){From=source,To=target,InputSlot=slot,Points=p.SelectMany(q=>new[]{q.X,q.Y,q.Z}).ToArray()});Console.WriteLine("Production output route "+i+" passed, max depth "+p.Max(q=>q.Z));}
 var noRails=new RouteHarness();foreach(var c in h.contacts)noRails.contacts[c.Key]=c.Value;
 foreach(var pair in new[]{(input,new CabinetWireEnd(10,0)),(new CabinetWireEnd(10,1),new CabinetWireEnd(0,1))}){
  var p=noRails.MakeRoute(pair.Item1,pair.Item2,out int slot,out var fail);if(p==null)throw new Exception("Missing-rail route: "+fail);noRails.VerifyFutureSpace(p,pair.Item1,pair.Item2);noRails.wires.Add(new(){From=pair.Item1,To=pair.Item2,InputSlot=slot,Points=Flatten(p)});
 }
 var chain=new RouteHarness();foreach(var c in h.contacts)chain.contacts[c.Key]=c.Value;chain.railObstacles.AddRange(h.railObstacles);
 float lx=-.14175f,ly=-.108f;var lower=WireModuleSpace.At(lx,ly);
 for(int pin=0;pin<2;pin++){var e=new CabinetWireEnd(20,pin);chain.contacts[e]=new(){End=e,Position=new(lx,ly+(pin==0?.050625f:-.050625f),.06535f),Exit=new(lx,pin==0?-.042f:-.174f,WireRouting.Plane),Bounds=lower};}
 foreach(var pair in new[]{(input,new CabinetWireEnd(10,0)),(new CabinetWireEnd(10,1),new CabinetWireEnd(20,0)),(new CabinetWireEnd(20,1),new CabinetWireEnd(0,1))}){
  var p=chain.MakeRoute(pair.Item1,pair.Item2,out int slot,out var fail);if(p==null)throw new Exception("Two-row chain route: "+fail);chain.VerifyFutureSpace(p,pair.Item1,pair.Item2);chain.wires.Add(new(){From=pair.Item1,To=pair.Item2,InputSlot=slot,Points=Flatten(p)});
 }
 Console.WriteLine("Production two-row chain passed: IN -> upper breaker -> lower breaker -> Output 1.");
 if(h.moduleReservations.Length!=16)throw new Exception("Future module count mismatch");Console.WriteLine("All 16 module/lead spaces reserved, including absent lower rail; full-route tube sections retain diameter.");
 var before=h.wires.Select(w=>(w.From,w.To,w.CableUnits)).ToArray();h.needsReroute=true;h.RerouteLegacy();if(h.needsReroute||h.changes!=1||h.migrationFailure!=null||h.wires.Any(w=>w.RouteVersion!=CurrentRouteVersion)||!h.wires.Select(w=>(w.From,w.To,w.CableUnits)).SequenceEqual(before))throw new Exception("Legacy rerouting altered connections or coil cost");
 var backup=h.wires.ToArray();h.railObstacles.Add(new(-.2f,.2f,-.18f,.19f));h.needsReroute=true;h.RerouteLegacy();if(h.migrationFailure==null||h.changes!=1||!h.wires.SequenceEqual(backup))throw new Exception("Failed migration did not preserve original wiring");h.railObstacles.RemoveAt(h.railObstacles.Count-1);
 h.wires.Clear();h.wires.Add(new(){From=input,To=new(10,0),Points=new[]{0f,0f,0f,0f,.1f,0f}});h.wires.Add(new(){From=new(10,1),To=new(0,1),Points=new[]{0f,0f,0f,0f,.1f,0f}});h.wires.Add(new(){From=input,To=new(0,2),Points=new[]{0f,0f,0f,0f,.1f,0f}});h.needsReroute=true;h.RerouteLegacy();if(h.migrationFailure!=null||h.wires.Count!=3||h.wires.Any(w=>w.RouteVersion!=CurrentRouteVersion))throw new Exception("Screenshot layout migration failed");Console.WriteLine("Production legacy migration passed: screenshot branches, endpoint/cost preservation and atomic rollback when blocked.");
 }
}
