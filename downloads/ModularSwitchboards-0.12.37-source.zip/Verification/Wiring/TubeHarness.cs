using System;
using System.Linq;
using ModularSwitchboards;
static class TubeHarness
{
 internal static void AssertSections(WirePoint[] path)
 {
  var right=new WirePoint();var tangent=new WirePoint();WirePoint oldRight=default;int rings=0;
  for(int i=0;i<path.Length;i++)
  {
   var ring=WireTube.Ring(path,i,12,ref right,ref tangent);
   foreach(var normal in ring)
   {
    float radius=(float)Math.Sqrt((normal*WireRouting.Radius).Squared);
    if(float.IsNaN(radius)||Math.Abs(radius-.0024f)>1e-7f||Math.Abs(WirePoint.Dot(normal,tangent))>1e-5f)throw new Exception("Tube radius or perpendicular section changed");
   }
   if(i>0&&WirePoint.Dot(oldRight,right)<-.001f)throw new Exception("Tube frame unexpectedly flipped");
   oldRight=right;rings++;
  }
  if(rings<2)throw new Exception("Missing tube sections");
 }
 internal static void Run()
 {
  var sharp=new[]{new WirePoint(0,0,0),new WirePoint(0,.03f,0),new WirePoint(.04f,.03f,0),new WirePoint(.04f,.03f,.03f),new WirePoint(.04f,.06f,.03f)};
  var round=WireTube.Round(sharp,.008f);AssertSections(sharp);AssertSections(round);
  if(round.Length<=sharp.Length||round[0].Squared!=0||(round[round.Length-1]-sharp[sharp.Length-1]).Squared>1e-12f||WireRouting.SelfIntersects(round))throw new Exception("Invalid fillet geometry");
  foreach(int sign in new[]{-1,1})
  {
   var entry=new WirePoint(0,sign*.196f,.033f);var anchor=new WirePoint(.016f,sign*.184f,.078f);var lead=WireContactLayout.EntryLead(entry,anchor);
   if(lead[1].X!=entry.X||lead[1].Z!=entry.Z||Math.Sign(lead[1].Y-entry.Y)!=-sign)throw new Exception("Cable not leaving end face normally");
   AssertSections(lead);
  }
  Console.WriteLine("Production tube geometry passed: constant 4.8 mm sections, transported frames, 3D fillets, straight end-face entries.");
 }
}
