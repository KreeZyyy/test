"""Render door module icons from the same dimensions as DoorModules.cs."""
import bpy,math,sys,json
from pathlib import Path
from mathutils import Vector
root=Path(__file__).resolve().parents[1]
def material(name,rgb):
 m=bpy.data.materials.new(name);m.diffuse_color=(*rgb,1);m.use_nodes=True
 bs=m.node_tree.nodes.get('Principled BSDF');bs.inputs['Base Color'].default_value=(*rgb,1);bs.inputs['Roughness'].default_value=.3
 return m
def cube(center,size,mat):
 bpy.ops.mesh.primitive_cube_add(size=1,location=center);o=bpy.context.object;o.dimensions=size;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.append(mat)
 mod=o.modifiers.new('Edges','BEVEL');mod.width=.0008;mod.segments=2
 return o
def cyl(radius,back,front,mat):
 bpy.ops.mesh.primitive_cylinder_add(vertices=32,radius=radius,depth=front-back,location=(0,0,(front+back)*.5));bpy.context.object.data.materials.append(mat)
names=('DoorLed','DoorLedBlue','DoorLedWhite','DoorLedRed','DoorStop','DoorBridge','DoorIsolator','DoorSwitch','DoorRoundSwitch')
if '--' in sys.argv:names=sys.argv[sys.argv.index('--')+1:]
for name in names:
 bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
 dark=material('Black',(.025,.029,.028));grey=material('Terminal',(.82,.85,.82));green=material('Lens',{'DoorLed':(.015,.5,.025),'DoorLedBlue':(.01,.035,.5),'DoorLedWhite':(.82,.86,.95),'DoorLedRed':(.5,.015,.01)}.get(name,(.015,.5,.025)))
 if name=='DoorRoundSwitch':
  white=material('Face',(.86,.87,.83));cyl(.016,-.002,.002,dark);cyl(.0155,.001,.0055,grey);cyl(.0123,.005,.008,dark)
  shape=next(x for x in json.loads((root/'Art/DoorIsolator.json').read_text()) if 'grip' in x['name'])
  vertices=[[v[0]*1.4,v[1]*.70,v[2]*.80] for v in shape['vertices']];mesh=bpy.data.meshes.new('Round grip');mesh.from_pydata(vertices,[],[shape['triangles'][i:i+3] for i in range(0,len(shape['triangles']),3)]);mesh.update()
  obj=bpy.data.objects.new('Round grip',mesh);bpy.context.collection.objects.link(obj);mesh.materials.append(dark);obj.rotation_euler.z=-math.pi/4
  face=cube((0,.001,.0163),(.0075,.016,.001),white);face.location.x=math.sin(math.pi/4)*.001;face.location.y=math.cos(math.pi/4)*.001;face.rotation_euler.z=-math.pi/4
  cube((0,0,-.025),(.036,.046,.021),dark)
  for pin in (-1,1):
   cube((0,pin*.016,-.0365),(.016,.012,.003),grey);cube((0,pin*.016,-.0385),(.01,.001,.001),dark)
  target=Vector((0,0,-.008));campos=Vector((.08,-.07,.14));scale=.078
 elif name=='DoorSwitch':
  white=material('Plate',(.86,.87,.83))
  cube((0,0,-.001),(.043,.043,.004),dark);cube((0,0,.002),(.040,.040,.006),white);cyl(.012,.004,.007,dark)
  data=json.loads((root/'Art/DoorIsolator.json').read_text())
  for shape in data:
   if 'grip' not in shape['name'] and 'mark' not in shape['name']:continue
   grip='grip' in shape['name'];vertices=[[v[0]*(.75 if grip else .85),v[1]*(.75 if grip else .85),v[2]*.65 if grip else v[2]-.003] for v in shape['vertices']]
   mesh=bpy.data.meshes.new(shape['name']);mesh.from_pydata(vertices,[],[shape['triangles'][i:i+3] for i in range(0,len(shape['triangles']),3)]);mesh.update()
   obj=bpy.data.objects.new(shape['name'],mesh);bpy.context.collection.objects.link(obj);mesh.materials.append(dark)
   if grip:obj.rotation_euler.z=-math.pi/2
  cyl(.002,.013,.014,grey);cube((0,0,.0142),(.0006,.0026,.0004),dark)
  cube((0,0,-.025),(.036,.046,.021),dark)
  for pin in (-1,1):
   cube((0,pin*.016,-.0365),(.016,.012,.003),grey);cube((0,pin*.016,-.0385),(.01,.001,.001),dark)
  target=Vector((0,0,-.008));campos=Vector((.08,-.07,.14));scale=.085
 elif name=='DoorIsolator':
  yellow=material('Yellow',(.95,.66,.015));red=material('Red',(.65,.012,.008));white=material('WhiteInserts',(.86,.87,.83));gripRed=material('GripRed',(.50,.009,.006))
  cube((0,0,-.001),(.054,.054,.004),dark);cube((0,0,.002),(.0495,.0495,.008),yellow)
  data=json.loads((root/'Art/DoorIsolator.json').read_text())
  for shape in data:
   mesh=bpy.data.meshes.new(shape['name']);mesh.from_pydata(shape['vertices'],[],[shape['triangles'][i:i+3] for i in range(0,len(shape['triangles']),3)]);mesh.update();mesh.normals_split_custom_set_from_vertices(shape['normals'])
   obj=bpy.data.objects.new(shape['name'],mesh);bpy.context.collection.objects.link(obj);mesh.materials.append(gripRed if 'grip' in shape['name'] else white if 'insert' in shape['name'] else dark if 'mark' in shape['name'] else red)
   if 'grip' in shape['name'] or 'shutter' in shape['name']:obj.rotation_euler.z=-math.pi/2
  cyl(.0024,.020,.021,grey);cube((0,0,.0212),(.0007,.00285,.0004),dark)
  cube((0,0,-.025),(.036,.046,.021),dark)
  for pin in (-1,1):
   cube((0,pin*.016,-.0365),(.016,.012,.003),grey);cube((0,pin*.016,-.0385),(.01,.001,.001),dark)
  target=Vector((0,0,-.003));campos=Vector((.08,-.07,.14));scale=.11
 elif name=='DoorStop':
  yellow=material('Yellow',(.95,.66,.015));red=material('Red',(.65,.012,.008))
  cyl(.026,-.002,.003,yellow);cyl(.017,.002,.008,dark);cyl(.009,.005,.019,dark);cyl(.021,.016,.030,red)
  guard=json.loads((root/'Art/DoorStopGuard.json').read_text());mesh=bpy.data.meshes.new('ProductionStopGuard');mesh.from_pydata(guard['vertices'],[],[guard['triangles'][i:i+3] for i in range(0,len(guard['triangles']),3)]);mesh.update()
  for face in mesh.polygons:face.use_smooth=True
  mesh.normals_split_custom_set_from_vertices(guard['normals'])
  if hasattr(mesh,'use_auto_smooth'):mesh.use_auto_smooth=True
  obj=bpy.data.objects.new('RaisedYellowGuard',mesh);bpy.context.collection.objects.link(obj);mesh.materials.append(yellow)
  cube((0,0,-.025),(.036,.046,.021),dark)
  for pin in (-1,1):
   cube((0,pin*.016,-.0365),(.016,.012,.003),grey);cube((0,pin*.016,-.0385),(.01,.001,.001),dark)
  target=Vector((0,0,-.003));campos=Vector((.08,-.07,.14));scale=.095
 elif name.startswith('DoorLed'):
  cyl(.016,-.002,.004,dark);cyl(.012,.0038,.009,green)
  cube((0,0,-.025),(.036,.046,.021),dark)
  for pin in (-1,1):
   cube((0,pin*.016,-.0365),(.016,.012,.003),grey);cube((0,pin*.016,-.0385),(.01,.001,.001),dark)
  target=Vector((0,0,-.012));campos=Vector((.08,-.07,.12));scale=.082
 else:
  for x in (-.065,.065):
   cube((x,0,.003),(.0192,.021,.006),dark)
   for i in range(1):
    y=0;cube((x,y,.0114),(.018,.0186,.0156),grey);cube((x,y,.01956),(.0054,.001,.0006),dark)
  for i in range(1):
   y=0;curve=bpy.data.curves.new('Flex','CURVE');curve.dimensions='3D';curve.bevel_depth=.0024;curve.bevel_resolution=2;spline=curve.splines.new('BEZIER');spline.bezier_points.add(3)
   for bp,p in zip(spline.bezier_points,[(-.057,y,.013),(-.025,y,-.08),(.025,y,-.08),(.057,y,.013)]):bp.co=p;bp.handle_left_type=bp.handle_right_type='AUTO'
   obj=bpy.data.objects.new('Flex',curve);bpy.context.collection.objects.link(obj);obj.data.materials.append(dark)
  target=Vector((0,0,0));campos=Vector((.25,-.20,.7));scale=.20
 s=bpy.context.scene;s.render.engine='CYCLES';s.cycles.samples=16;s.cycles.use_denoising=False;s.render.resolution_x=s.render.resolution_y=256;s.render.resolution_percentage=100;s.render.film_transparent=True;s.world.color=(.25,.25,.25);s.view_settings.view_transform='Standard'
 bpy.ops.object.camera_add(location=campos);cam=bpy.context.object;cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=scale;s.camera=cam
 bpy.ops.object.light_add(type='AREA',location=(-.3,-.2,.5));bpy.context.object.data.energy=35;bpy.context.object.data.size=.5
 s.render.filepath=str(root/'Assets/Icons'/f'{name}.png');bpy.ops.render.render(write_still=True)
