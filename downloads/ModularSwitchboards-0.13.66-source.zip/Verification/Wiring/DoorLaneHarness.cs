using System;using System.Linq;using System.Collections.Generic;using System.Diagnostics;using System.IO;using ModularSwitchboards;
static class DoorLaneHarness
{
 static void Check(bool b,string s){if(!b)throw new Exception(s);}
 internal static void Run()
 {
  var source=new WirePoint(-.12f,.1f,.043f);var target=new WirePoint(.12f,.1f,.043f);
  var fast=WireLaneRoutes.Find(source,target,new List<WireRect>(),new List<WirePoint[]>(),0,0);Check(fast!=null&&fast.Length==2,"Free sheet should use one straight span");
  var barrier=new List<WireRect>{new(-.03f,.03f,.09f,.11f)};
  fast=WireLaneRoutes.Find(source,target,barrier,new List<WirePoint[]>(),-1,0);Check(fast!=null&&fast.Length<=4,"Simple obstacle should use bounded dogleg");
  foreach(var pair in fast.Zip(fast.Skip(1)))Check(WireRouting.Clear(pair.First,pair.Second,barrier,new List<WirePoint[]>(),false),"Simple path crosses obstacle");
  var h=new RouteHarness();
  for(int i=0;i<18;i++){float y=(-9+i)*.024f;var e=new CabinetWireEnd(900+i,3);h.contacts[e]=new(){End=e,Door=true,Position=new(.163f,y,.0114f),Exit=new(.153f,y,.043f),Bounds=new(.164f,.181f,y-.011f,y+.011f)};}
  for(int i=0;i<3;i++){float x=.1f-i*.1f,y=.1f;for(int pin=0;pin<2;pin++){var e=new CabinetWireEnd(100+i,pin);float sign=pin==0?1:-1;h.contacts[e]=new(){End=e,Door=true,Position=new(x,y+sign*.023f,.017f),Exit=new(x,y+sign*.043f,.043f),Bounds=new(x-.019f,x+.019f,y-.024f,y+.024f)};}}
  var watch=Stopwatch.StartNew();var paths=new List<WirePoint[]>();
  for(int i=0;i<3;i++)foreach(var ends in new[]{(new CabinetWireEnd(917-i*2,3),new CabinetWireEnd(100+i,0)),(new CabinetWireEnd(100+i,1),new CabinetWireEnd(916-i*2,3))}){
   var path=h.MakeRoute(ends.Item1,ends.Item2,out int slot,out string failure);Check(path!=null,"Three top-row door modules: "+failure);TubeHarness.AssertSections(path);Check(!WireRouting.SelfIntersects(path),"Door route loops into itself");
   paths.Add(path);h.wires.Add(new(){From=ends.Item1,To=ends.Item2,InputSlot=slot,Points=path.SelectMany(p=>new[]{p.X,p.Y,p.Z}).ToArray()});
  }
  watch.Stop();
  var json=System.Text.Json.JsonSerializer.Serialize(paths.Select(path=>path.Select(p=>new[]{p.X,p.Y,p.Z})));File.WriteAllText("/tmp/door-lanes49.json",json);
  float length=paths.Sum(path=>path.Zip(path.Skip(1)).Sum(p=>(float)Math.Sqrt((p.Second-p.First).Squared)));
  Check(watch.ElapsedMilliseconds<3000,"Six door routes took over three seconds");
  Console.WriteLine($"Three top-row door fixture: {watch.ElapsedMilliseconds} ms for six routes; {length:0.000} m total; {paths.Sum(WireLaneRoutes.Score):0.000} length/turn score.");
 }
}
