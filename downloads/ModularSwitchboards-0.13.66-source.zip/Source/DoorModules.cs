using System;
using System.Collections.Generic;
using System.Linq;
using Assets.Scripts;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Objects;
using Assets.Scripts.Localization2;
using Assets.Scripts.UI;
using LibConstruct;
using HarmonyLib;
using Rendering;
using UnityEngine;
using UnityEngine.Rendering;

namespace ModularSwitchboards
{
    public sealed class SwitchboardDoorBoard:PlacementBoard
    {
        public override float GridSize=>DoorModuleLayout.Pitch;
        public override IPlacementBoardStructure EquivalentStructure(Structure structure)
            =>structure is DinBreaker part&&(part.IsDoorLed||part.IsDoorStop||part.IsDoorIsolator)&&PrimaryHost is SwitchboardCabinet host&&host.IsStructureCompleted?part:null;
    }
    public sealed class SwitchboardBridgeBoard:PlacementBoard
    {
        public override float GridSize=>DoorModuleLayout.Spacing;
        public override IPlacementBoardStructure EquivalentStructure(Structure structure)
            =>structure is DinBreaker part&&part.IsDoorBridge&&PrimaryHost is SwitchboardCabinet host&&host.CanFitRails?part:null;
    }
    internal static class DoorModules
    {
        internal const string FrameName="DoorWireFrame";
        internal static Transform Frame(SwitchboardCabinet host)=>host.transform.Find("SwitchboardModel/CompletedShell/DoorHinge/"+FrameName);
        internal static void InstallBoard(SwitchboardCabinet host)
        {
            var shell=host.transform.Find("SwitchboardModel/CompletedShell");var hinge=shell.Find("DoorHinge");
            var origin=new GameObject("DoorModuleBoard"){layer=host.gameObject.layer};origin.transform.SetParent(hinge,false);
            // Door sheet extends from -.002 to +.010 in hinge-local Z.
            origin.transform.localPosition=new Vector3(.2f,0,.0105f);host.DoorOrigin=origin.transform;
            host.DoorSurface=origin.AddComponent<BoxCollider>();host.DoorSurface.size=new Vector3(.29f,.29f,.0005f);
            host.BuildStates[1].Colliders.Add(host.DoorSurface);
            var frame=new GameObject(FrameName){layer=host.gameObject.layer};frame.transform.SetParent(hinge,false);
            frame.transform.localPosition=new Vector3(.2f,0,-.0025f);frame.transform.localRotation=Quaternion.Euler(0,180,0);
            var fixedOrigin=new GameObject("DoorBridgeBoard"){layer=host.gameObject.layer};fixedOrigin.transform.SetParent(shell,false);
            fixedOrigin.transform.localPosition=new Vector3(-.177f,0,.013f);host.BridgeOrigin=fixedOrigin.transform;
            host.BridgeSurface=fixedOrigin.AddComponent<BoxCollider>();host.BridgeSurface.center=new Vector3(0,0,.001f);host.BridgeSurface.size=new Vector3(.016f,.426f,.001f);host.BridgeSurface.enabled=false;
            host.BuildStates[1].Colliders.Add(host.BridgeSurface);
        }
        internal static bool CanPlace(PlacementBoard board,Grid3 p,int rotation,bool bridge=false)
        {
            if(!(board?.PrimaryHost is SwitchboardCabinet host)||!host.IsStructureCompleted)return false;
            if(bridge)
            {
                if(!(board is SwitchboardBridgeBoard)||!host.CanFitRails)return false;
                return DoorModuleLayout.BridgeFits(p.x,p.y,p.z,rotation)&&!board.Structures.OfType<DinBreaker>().Any(m=>board.WorldToGrid(m.transform.position).y==p.y);
            }
            return board is SwitchboardDoorBoard&&DoorModuleLayout.Fits(p.x,p.y,p.z,rotation)&&!board.Structures.OfType<DinBreaker>().Any(m=>{var q=board.WorldToGrid(m.transform.position);return q.x==p.x&&q.y==p.y;});
        }
        internal static CanConstructInfo CanConstruct(DinBreaker part)
        {
            var board=part.Board;
            if(board==null||(part.IsCursor&&PlacementBoard.CursorBoard!=board))return CanConstructInfo.InvalidPlacement(part.IsDoorBridge?"Aim at the mounting plate beside the left hinge.":"Aim at the outside of the small cabinet door.");
            var p=board.WorldToGrid(part.transform.position);
            if(part.IsCursor){p=part.IsDoorBridge?new Grid3(0,DoorModuleLayout.SnapSlot(p.y,-90,80),0):new Grid3(DoorModuleLayout.SnapSlot(p.x,-10,10),DoorModuleLayout.SnapSlot(p.y,-10,10),0);PlacementBoard.CursorGrid=p;PlacementBoard.CursorRotation=0;part.transform.SetPositionAndRotation(board.GridToWorld(p),board.IndexToRotation(0));}
            return CanPlace(board,p,board.RotationToIndex(part.transform.rotation),part.IsDoorBridge)?CanConstructInfo.ValidPlacement:CanConstructInfo.InvalidPlacement("Choose a free door position; the terminal bridge fits only beside the hinge.");
        }
        internal static CanConstructInfo CanDeconstruct(DinBreaker part)
        {
            var host=CabinetWiring.CabinetOf(part);
            if(host==null||!host.CanAccessModules)return CanConstructInfo.InvalidPlacement("Open the cabinet first.");
            if(host.Wiring.HasWires(part.ReferenceId))return CanConstructInfo.InvalidPlacement("Remove connected wires first.");
            return CanConstructInfo.ValidPlacement;
        }
        private static Material black,grey,green,red,yellow,ivory,gripRed;
        private static Material Material(string name,Color colour)
        {
            var shader=Shader.Find("Standard");if(shader==null||!shader.isSupported)shader=Shader.Find("StandardInstanced");
            if(shader==null||!shader.isSupported)throw new InvalidOperationException("Door module shader unavailable.");
            var m=new Material(shader){name=name,color=colour};m.SetFloat("_Glossiness",.27f);m.SetFloat("_Metallic",.1f);return m;
        }
        private static void Materials()
        {
            if(black!=null)return;
            black=Material("Switchboards.Door.Black",new Color(.025f,.029f,.028f));grey=Material("Switchboards.Door.Terminals",new Color(.5f,.53f,.51f));
            red=Material("Switchboards.Door.Stop.Red",new Color(.65f,.012f,.008f));yellow=Material("Switchboards.Door.Stop.Yellow",new Color(.95f,.66f,.015f));
            ivory=Material("Switchboards.Door.Isolator.Inserts",new Color(.86f,.87f,.83f));
            gripRed=Material("Switchboards.Door.Isolator.Grip.Red",new Color(.50f,.009f,.006f));
            green=Material("Switchboards.Door.Green",new Color(.015f,.20f,.025f));green.EnableKeyword("_EMISSION");green.SetColor("_EmissionColor",Color.black);
        }
        private static Mesh Box(Vector3 center,Vector3 size)
        {
            var v=new List<Vector3>();var n=new List<Vector3>();var t=new List<int>();RoundedGeometry.Box(v,n,t,center,size,.001f);
            var mesh=new Mesh{name="Door module body"};mesh.SetVertices(v);mesh.SetNormals(n);mesh.SetTriangles(t,0);mesh.RecalculateBounds();return mesh;
        }
        private static Mesh Cylinder(float radius,float back,float front)=>DoorModuleGeometry.Cylinder(radius,back,front);
        private static MeshRenderer Part(Transform root,string name,Mesh mesh,Material material)
        {
            var go=new GameObject(name){layer=root.gameObject.layer};go.transform.SetParent(root,false);go.AddComponent<MeshFilter>().sharedMesh=mesh;
            var renderer=go.AddComponent<MeshRenderer>();renderer.sharedMaterial=material;return renderer;
        }
        private static Mesh bridgeCube;
        internal static void TerminalCube(Transform root,float inward)
        {
            if(bridgeCube==null)bridgeCube=CabinetTerminalBlocks.BuildBridgeCube();
            var go=new GameObject("BridgeTerminalCube"){layer=root.gameObject.layer};go.transform.SetParent(root,false);
            go.transform.localRotation=Quaternion.Euler(0,0,-90f*inward);go.transform.localScale=Vector3.one*.6f;
            go.AddComponent<MeshFilter>().sharedMesh=bridgeCube;var renderer=go.AddComponent<MeshRenderer>();renderer.sharedMaterials=CabinetGeometry.Materials;renderer.shadowCastingMode=ShadowCastingMode.Off;
            PaintCubes(root);
        }
        internal static void PaintCubes(Transform root)
        {
            foreach(var renderer in root.GetComponentsInChildren<MeshRenderer>(true).Where(r=>r.name=="BridgeTerminalCube"))
                for(int role=0;role<5;role++){var block=new MaterialPropertyBlock();block.SetFloat(Thing.DiffuseIndexPropertyID,CabinetGeometry.PaletteIndices[role]);block.SetColor(Thing.EMISSION_COLOR,Color.black);renderer.SetPropertyBlock(block,role);}
        }
        internal static void Install(DinBreaker part,Transform storage)
        {
            foreach(var c in part.GetComponentsInChildren<Renderer>(true))UnityEngine.Object.DestroyImmediate(c);
            foreach(var c in part.GetComponentsInChildren<MeshFilter>(true))UnityEngine.Object.DestroyImmediate(c);
            foreach(var c in part.GetComponentsInChildren<Collider>(true))UnityEngine.Object.DestroyImmediate(c);
            foreach(var c in part.GetComponentsInChildren<Animator>(true))UnityEngine.Object.DestroyImmediate(c);
            Materials();part.BaseAnimator=null;part.Renderers=new List<ThingRenderer>();part.Interactables=new List<Interactable>();part.Slots=new List<Slot>();
            part._staticColliders=new List<Collider>();part._dynamicColliders=new List<Collider>();part._selfColliders=new List<Collider>();
            part.CustomNavMeshFilter=null;part.structureRenderMode=StructureRenderMode.Standard;part.ForceGridBounds.Clear();part.BrokenBuildStates=new List<BrokenBuildState>();part.StructureCollisionType=CollisionType.BlockCustom;
            part.SelectionDisplay=SelectionHighlightMethod.Bounds;part.UseCellPosition=false;part.PaintableMaterial=null;part.HasColorState=false;part.HasOnOffState=false;part.MPBRenderers.Clear();
            MeshRenderer body;var hit=part.gameObject.AddComponent<BoxCollider>();
            if(part.IsDoorRoundSwitch)
            {
                Part(part.transform,"DoorRoundSwitchMount",Cylinder(.016f,-.002f,.002f),black);
                body=Part(part.transform,"DoorRoundSwitchBezel",Cylinder(.0155f,.001f,.0055f),grey);
                Part(part.transform,"DoorRoundSwitchHub",Cylinder(.0123f,.005f,.008f),black);
                Part(part.transform,"DoorRoundSwitchRear",Box(new Vector3(0,0,-.025f),new Vector3(.036f,.046f,.021f)),black);
                var handle=new GameObject("DoorIsolatorHandle"){layer=part.gameObject.layer};handle.transform.SetParent(part.transform,false);
                var grip=Part(handle.transform,"DoorRoundSwitchGrip",DoorIsolatorGeometry.Grip(),black);grip.transform.localScale=new Vector3(1.4f,.70f,.80f);
                Part(handle.transform,"DoorRoundSwitchWhiteFace",Box(new Vector3(0,.001f,.0163f),new Vector3(.0075f,.016f,.001f)),ivory);
                for(int pin=0;pin<2;pin++){float y=pin==0?.016f:-.016f;Part(part.transform,"Terminal",Box(new Vector3(0,y,-.0365f),new Vector3(.016f,.012f,.003f)),grey);Part(part.transform,"Screw",Box(new Vector3(0,y,-.0385f),new Vector3(.01f,.001f,.001f)),black);}
                hit.center=new Vector3(0,0,-.020f);hit.size=new Vector3(.038f,.048f,.041f);
                var control=part.gameObject.AddComponent<BoxCollider>();control.center=new Vector3(0,0,.009f);control.size=new Vector3(.033f,.033f,.020f);
                part.Interactables.Add(new Interactable{Parent=part,Action=InteractableType.OnOff,Collider=control,JoinInProgressSync=true,CanKeyInteract=true,KeyMap="PrimaryAction"});part.HasOnOffState=true;
                var view=part.gameObject.AddComponent<DoorIsolatorView>();view.Owner=part;view.Handle=handle.transform;DoorIsolatorView.SetInitialPose(handle.transform,true);
            }
            else if(part.IsDoorSwitch)
            {
                Part(part.transform,"DoorSwitchMount",Box(new Vector3(0,0,-.001f),new Vector3(.043f,.043f,.004f)),black);
                body=Part(part.transform,"DoorSwitchPlate",Box(new Vector3(0,0,.002f),new Vector3(.040f,.040f,.006f)),ivory);
                Part(part.transform,"DoorSwitchHub",Cylinder(.012f,.004f,.007f),black);
                Part(part.transform,"DoorSwitchRear",Box(new Vector3(0,0,-.025f),new Vector3(.036f,.046f,.021f)),black);
                var handle=new GameObject("DoorIsolatorHandle"){layer=part.gameObject.layer};handle.transform.SetParent(part.transform,false);
                var grip=Part(handle.transform,"DoorSwitchGrip",DoorIsolatorGeometry.Grip(),black);grip.transform.localScale=new Vector3(.75f,.75f,.65f);
                Part(handle.transform,"DoorSwitchPivot",Cylinder(.002f,.013f,.014f),grey);
                Part(handle.transform,"DoorSwitchPivotSlot",Box(new Vector3(0,0,.0142f),new Vector3(.0026f,.0006f,.0004f)),black);
                foreach(bool on in new[]{false,true})
                {
                    var mark=Part(part.transform,on?"DoorSwitchI":"DoorSwitch0",DoorIsolatorGeometry.Mark(on),black);
                    mark.transform.localScale=new Vector3(.85f,.85f,1);mark.transform.localPosition=new Vector3(0,0,-.003f);
                }
                for(int pin=0;pin<2;pin++){float y=pin==0?.016f:-.016f;Part(part.transform,"Terminal",Box(new Vector3(0,y,-.0365f),new Vector3(.016f,.012f,.003f)),grey);Part(part.transform,"Screw",Box(new Vector3(0,y,-.0385f),new Vector3(.01f,.001f,.001f)),black);}
                hit.center=new Vector3(0,0,-.020f);hit.size=new Vector3(.038f,.048f,.041f);
                var control=part.gameObject.AddComponent<BoxCollider>();control.center=new Vector3(0,0,.007f);control.size=new Vector3(.043f,.043f,.018f);
                part.Interactables.Add(new Interactable{Parent=part,Action=InteractableType.OnOff,Collider=control,JoinInProgressSync=true,CanKeyInteract=true,KeyMap="PrimaryAction"});part.HasOnOffState=true;
                var view=part.gameObject.AddComponent<DoorIsolatorView>();view.Owner=part;view.Handle=handle.transform;
                DoorIsolatorView.SetInitialPose(handle.transform);
            }
            else if(part.IsDoorIsolator)
            {
                Part(part.transform,"DoorIsolatorMount",Box(new Vector3(0,0,-.001f),new Vector3(.054f,.054f,.004f)),black);
                body=Part(part.transform,"DoorIsolatorBase",Box(new Vector3(0,0,.002f),new Vector3(.0495f,.0495f,.008f)),yellow);
                Part(part.transform,"DoorIsolatorDial",DoorIsolatorGeometry.Dish(),red);
                Part(part.transform,"DoorIsolatorRear",Box(new Vector3(0,0,-.025f),new Vector3(.036f,.046f,.021f)),black);
                var handle=new GameObject("DoorIsolatorHandle"){layer=part.gameObject.layer};handle.transform.SetParent(part.transform,false);
                Part(handle.transform,"DoorIsolatorWindowMask",DoorIsolatorGeometry.WindowMask(),red);
                Part(handle.transform,"DoorIsolatorGrip",DoorIsolatorGeometry.Grip(),gripRed);
                Part(handle.transform,"DoorIsolatorPivot",Cylinder(.0024f,.020f,.021f),grey);
                Part(handle.transform,"DoorIsolatorPivotSlot",Box(new Vector3(0,0,.0212f),new Vector3(.00285f,.0007f,.0004f)),black);
                // Large inserts are under the planar shutter inside the simple rim.
                Part(part.transform,"DoorIsolatorWhiteI",DoorIsolatorGeometry.Insert(true),ivory);
                Part(part.transform,"DoorIsolatorI",DoorIsolatorGeometry.Mark(true),black);
                Part(part.transform,"DoorIsolator0",DoorIsolatorGeometry.Mark(false),black);
                for(int pin=0;pin<2;pin++){float y=pin==0?.016f:-.016f;Part(part.transform,"Terminal",Box(new Vector3(0,y,-.0365f),new Vector3(.016f,.012f,.003f)),grey);Part(part.transform,"Screw",Box(new Vector3(0,y,-.0385f),new Vector3(.01f,.001f,.001f)),black);}
                hit.center=new Vector3(0,0,-.020f);hit.size=new Vector3(.038f,.048f,.041f);
                var control=part.gameObject.AddComponent<BoxCollider>();control.center=new Vector3(0,0,.0105f);control.size=new Vector3(.054f,.054f,.025f);
                part.Interactables.Add(new Interactable{Parent=part,Action=InteractableType.OnOff,Collider=control,JoinInProgressSync=true,CanKeyInteract=true,KeyMap="PrimaryAction"});part.HasOnOffState=true;
                var view=part.gameObject.AddComponent<DoorIsolatorView>();view.Owner=part;view.Handle=handle.transform;
                DoorIsolatorView.SetInitialPose(handle.transform);
            }
            else if(part.IsDoorStop)
            {
                body=Part(part.transform,"DoorStopFlange",Cylinder(.026f,-.002f,.003f),yellow);
                var guard=Part(part.transform,"DoorStopGuard",DoorModuleGeometry.StopGuard(),yellow);
                guard.gameObject.AddComponent<MeshCollider>().sharedMesh=guard.GetComponent<MeshFilter>().sharedMesh;
                Part(part.transform,"DoorStopCollar",Cylinder(.017f,.002f,.008f),black);
                var button=new GameObject("DoorStopButton"){layer=part.gameObject.layer};button.transform.SetParent(part.transform,false);
                Part(button.transform,"DoorStopStem",Cylinder(.009f,.005f,.019f),black);
                Part(button.transform,"DoorStopMushroom",Cylinder(.021f,.016f,.030f),red);
                Part(part.transform,"DoorStopRear",Box(new Vector3(0,0,-.025f),new Vector3(.036f,.046f,.021f)),black);
                for(int pin=0;pin<2;pin++){float y=pin==0?.016f:-.016f;Part(part.transform,"Terminal",Box(new Vector3(0,y,-.0365f),new Vector3(.016f,.012f,.003f)),grey);Part(part.transform,"Screw",Box(new Vector3(0,y,-.0385f),new Vector3(.01f,.001f,.001f)),black);}
                hit.center=new Vector3(0,0,-.020f);hit.size=new Vector3(.038f,.048f,.041f);
                var control=part.gameObject.AddComponent<BoxCollider>();control.center=new Vector3(0,0,.016f);control.size=new Vector3(.043f,.043f,.032f);
                part.Interactables.Add(new Interactable{Parent=part,Action=InteractableType.OnOff,Collider=control,JoinInProgressSync=true,CanKeyInteract=true,KeyMap="PrimaryAction"});part.HasOnOffState=true;
                var view=part.gameObject.AddComponent<DoorStopView>();view.Owner=part;view.Button=button.transform;
            }
            else if(part.IsDoorLed)
            {
                body=Part(part.transform,"DoorLedBezel",Cylinder(.016f,-.002f,.004f),black);
                var lens=Part(part.transform,"DoorLedLens",Cylinder(.012f,.0038f,.009f),green);
                Part(part.transform,"DoorLedRear",Box(new Vector3(0,0,-.025f),new Vector3(.036f,.046f,.021f)),black);
                for(int pin=0;pin<2;pin++){float y=pin==0?.016f:-.016f;Part(part.transform,pin==0?"IN":"OUT",Box(new Vector3(0,y,-.0365f),new Vector3(.016f,.012f,.003f)),grey);Part(part.transform,"Screw",Box(new Vector3(0,y,-.0385f),new Vector3(.01f,.001f,.001f)),black);}
                hit.center=new Vector3(0,0,-.014f);hit.size=new Vector3(.038f,.048f,.048f);
                var view=part.gameObject.AddComponent<DoorLedView>();view.Owner=part;view.Lens=lens;NativeDoorLed.Install(part,view);
            }
            else
            {
                TerminalCube(part.transform,1);
                body=part.GetComponentInChildren<MeshRenderer>();hit.center=new Vector3(0,0,.012f);hit.size=new Vector3(.018f,.024f,.026f);
                var view=part.gameObject.AddComponent<DoorBridgeView>();view.Owner=part;
            }
            part.Bounds=part.IsDoorRoundSwitch?new Bounds(new Vector3(0,0,-.011f),new Vector3(.038f,.050f,.060f)):part.IsDoorSwitch?new Bounds(new Vector3(0,0,-.0125f),new Vector3(.048f,.050f,.056f)):part.IsDoorIsolator?new Bounds(new Vector3(0,0,-.009f),new Vector3(.056f,.056f,.064f)):part.IsDoorStop?new Bounds(new Vector3(0,0,-.0025f),new Vector3(.059f,.059f,.079f)):new Bounds(hit.center,hit.size);part.GridBounds=new GridBounds(part);part.SurfaceArea=.01f;part.Thumbnails=new Sprite[0];
            // Existing native item icon is temporary, like the requested Logic Kit model.
            part.Thumbnail=CabinetIcons.Get(part.IsDoorRoundSwitch?"DoorRoundSwitch":part.IsDoorSwitch?"DoorSwitch":part.IsDoorIsolator?"DoorIsolator":part.IsDoorStop?"DoorStop":part.IsDoorLed?DoorLedColours.For(part.PrefabName).Icon:"DoorBridge");
            var state=part.BuildStates[0];state.Visualizer=body;state.StateMeshes=new List<Mesh>();state.RendererInstance=null;state.Colliders=part.GetComponentsInChildren<Collider>(true).ToList();state.Interactables=new List<Interactable>(part.Interactables);state.LinkedGameObjects=new List<GameObject>();state.RenderMode=BuildStateRenderMode.OnMyState;state.BlockAir=state.AlwaysBlockAir=state.BlockLight=state.BlockGravity=false;state.Thumbnail=part.Thumbnail;
            AccessTools.Field(typeof(BuildState),"initialDrawData").SetValue(state,new DrawData{mesh=null,materials=new Material[0]});
            var bp=new GameObject("DoorModuleBlueprint"){layer=part.gameObject.layer};bp.transform.SetParent(storage,false);
            var ghost=ModelBlueprint.Build(part.transform);var filter=bp.AddComponent<MeshFilter>();filter.sharedMesh=ghost;var renderer=bp.AddComponent<MeshRenderer>();renderer.sharedMaterial=grey;
            var wire=bp.AddComponent<Wireframe>();wire.BlueprintTransform=bp.transform;wire.BlueprintBounds=ghost.bounds;wire.BlueprintMeshFilter=filter;wire.BlueprintRenderer=renderer;bp.AddComponent<CabinetBlueprint>();part.Blueprint=bp;part.BlueprintOrientVector=Vector3.zero;
        }
    }
    // One physical flex follows the matching pair of electrically neutral terminals.
    public sealed class DoorBridgeView:MonoBehaviour
    {
        public DinBreaker Owner;
        private GameObject moving;
        private readonly List<MeshFilter> cables=new List<MeshFilter>();
        private Quaternion last;private bool initialized;
        private void LateUpdate()
        {
            var host=Owner==null?null:CabinetWiring.CabinetOf(Owner);
            if(host==null||Owner.IsCursor)return;
            var frame=DoorModules.Frame(host);if(frame==null)return;
            if(moving==null)
            {
                moving=new GameObject("MovingDoorTerminals"){layer=Owner.gameObject.layer};moving.transform.SetParent(transform,false);
                DoorModules.TerminalCube(moving.transform,-1);
                var hit=moving.AddComponent<BoxCollider>();hit.center=new Vector3(0,0,.012f);hit.size=new Vector3(.018f,.024f,.026f);Thing._colliderLookup[hit]=Owner;
                for(int i=0;i<1;i++){var go=new GameObject("DoorFlex "+(i+1)){layer=Owner.gameObject.layer};go.transform.SetParent(transform,false);var filter=go.AddComponent<MeshFilter>();cables.Add(filter);var renderer=go.AddComponent<MeshRenderer>();renderer.sharedMaterial=CabinetGeometry.Materials[3];renderer.shadowCastingMode=ShadowCastingMode.Off;}
            }
            moving.transform.SetPositionAndRotation(frame.TransformPoint(new Vector3(.172f,host.transform.Find("SwitchboardModel/CompletedShell").InverseTransformPoint(Owner.transform.position).y,0)),frame.rotation);
            if(initialized&&Quaternion.Angle(last,frame.rotation)<.05f)return;
            initialized=true;last=frame.rotation;DoorModules.PaintCubes(transform);
            for(int lane=0;lane<cables.Count;lane++)
            {
                float y=0;
                // Red user wires use the outer face; the blue flex uses the opposite face.
                var p0=new Vector3(-.009f,y,.0114f);
                var end=transform.InverseTransformPoint(moving.transform.TransformPoint(new Vector3(.009f,y,.0114f)));
                var p1=p0+new Vector3(-.003f,0,.060f);var p2=end+transform.InverseTransformDirection(frame.TransformDirection(new Vector3(.012f,0,.040f)));
                var path=DoorModuleLayout.DoorFlexGeometry.Build(CabinetWiring.Point(p0),CabinetWiring.Point(p1),CabinetWiring.Point(p2),CabinetWiring.Point(end));
                var mesh=WireMesh.Build(path);var old=cables[lane].sharedMesh;cables[lane].sharedMesh=mesh;if(old!=null)Destroy(old);
            }
        }
        private void OnDestroy()
        {
            foreach(var c in cables)if(c!=null&&c.sharedMesh!=null)Destroy(c.sharedMesh);
            if(moving!=null){foreach(var hit in moving.GetComponentsInChildren<Collider>())if(Thing._colliderLookup.TryGetValue(hit,out var owner)&&owner==Owner)Thing._colliderLookup.Remove(hit);}
        }
    }
}
