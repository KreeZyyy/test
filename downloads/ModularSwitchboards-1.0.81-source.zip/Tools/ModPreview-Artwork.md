# 1.0.81 preview artwork

New artwork generated with image_gen from the user's actual switchboard screenshots and orange LaunchPad banner reference. Original master retained unmodified at /workspace/generated_images/exec-64b8712a-37d2-44cd-bc5b-25351a302b12.png. Native About/Preview.png and thumb.png are the shipped authoritative assets; export_mod_preview.sh produces1600x900 and640x360 palette PNGs from the master. Original legacy render_mod_preview.py remains historical and does not recreate this illustrated design.

The banner indicates the actual BepInEx/StationeersLaunchPad dependency, not a new Workshop publication or official endorsement. Loader URL checked through GitHub. About.Description uses native readable bullets and a TMP orange heading; WORKSHOP-DESCRIPTION.txt is separately prepared Steam BBCode. Do not publish Workshop without explicit user instruction.
