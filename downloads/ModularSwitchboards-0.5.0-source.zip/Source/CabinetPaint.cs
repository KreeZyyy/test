using Assets.Scripts.Objects;
using UnityEngine;

namespace ModularSwitchboards
{
    // Instance-owned, uniform palette: no mesh UV can expose another tile of a game atlas.
    public sealed class CabinetPaint : MonoBehaviour
    {
        private Material paint;
        private Texture2DArray texture;
        private Thing owner;
        internal Material Material => paint;

        internal void Initialize(Thing thing)
        {
            owner = thing;
            paint = new Material(CabinetGeometry.Materials[0]) { name = "Switchboards.InstancePaint" };
            int depth = ((Texture2DArray)paint.mainTexture).depth;
            texture = new Texture2DArray(1, 1, depth, TextureFormat.RGBA32, false, false)
                { name = "Switchboards.UniformPaint", filterMode = FilterMode.Point, wrapMode = TextureWrapMode.Clamp };
            paint.mainTexture = texture;
            Refresh();
        }

        internal void Refresh()
        {
            if (paint == null || texture == null || owner == null) return;
            Color color = owner.CustomColor == null ? new Color(.55f, .58f, .6f) : owner.CustomColor.Light;
            color.a = 1f;
            for (int i = 0; i < texture.depth; i++) texture.SetPixels(new[] { color }, i, 0);
            texture.Apply(false, false);
        }

        private void OnDestroy()
        {
            if (paint != null) Destroy(paint);
            if (texture != null) Destroy(texture);
        }
    }
}
