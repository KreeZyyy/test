using System;
using System.IO;
using Assets.Scripts;
using Assets.Scripts.Objects.Motherboards;
using UnityEngine;

namespace ModularSwitchboards
{
    internal static class CabinetGeometry
    {
        internal static Mesh[] Meshes;
        internal static Material[] Materials;
        internal static int[] PaletteIndices;
        internal const int PaintableMaterialIndex = 0;

        private static Texture2DArray FlatPalette(int depth, Color fixedColor, bool paintable)
        {
            var texture = new Texture2DArray(1, 1, depth, TextureFormat.RGBA32, false, false)
            { name = paintable ? "Switchboards.PaintPalette" : "Switchboards.FixedSurface", filterMode = FilterMode.Point, wrapMode = TextureWrapMode.Clamp };
            for (int i = 0; i < depth; i++)
            {
                var color = fixedColor;
                if (paintable && GameManager.IsValidColor(i)) color = GameManager.GetColorSwatch(i).Light;
                color.a = 1f;
                texture.SetPixels(new[] { color }, i, 0);
            }
            texture.Apply(false, true);
            return texture;
        }

        internal static void EnsureLoaded(Material fallback)
        {
            if (Meshes != null) return;
            var template = GameManager.GetTextureArrayColorMaterial();
            if (template == null || template.shader == null || !template.shader.isSupported)
                throw new InvalidOperationException("Native game paint material unavailable.");
            var nativeArray = template.mainTexture as Texture2DArray;
            int depth = Mathf.Max(nativeArray == null ? 32 : nativeArray.depth, 32);
            using (var stream = typeof(CabinetGeometry).Assembly.GetManifestResourceStream("ModularSwitchboards.Cabinet.meshbin"))
            {
                if (stream == null) throw new InvalidOperationException("Embedded cabinet mesh missing.");
                using (var reader = new BinaryReader(stream))
                {
                    if (new string(reader.ReadChars(4)) != "SBMS" || reader.ReadInt32() != 1)
                        throw new InvalidDataException("Unsupported cabinet format.");
                    int materialCount = reader.ReadInt32(), meshCount = reader.ReadInt32();
                    if (materialCount != 5 || meshCount != 3) throw new InvalidDataException("Expected simple cabinet geometry.");
                    var materials = new Material[materialCount];
                    var colorIndices = new[] { (int)ColorType.Gray, (int)ColorType.White, (int)ColorType.Yellow, (int)ColorType.Black, (int)ColorType.Gray };
                    for (int i = 0; i < materialCount; i++)
                    {
                        var color = new Color(reader.ReadSingle(), reader.ReadSingle(), reader.ReadSingle(), reader.ReadSingle());
                        reader.ReadSingle(); reader.ReadSingle();
                        // Preserve the game's shader/lighting path. A one-pixel palette avoids sampling
                        // unrelated tiles from the native texture atlas on a differently shaped mesh.
                        var material = new Material(template) { name = "Switchboards.SimpleSurface." + i };
                        material.mainTexture = FlatPalette(depth, color, i == PaintableMaterialIndex);
                        if (material.HasProperty("_Color")) material.SetColor("_Color", Color.white);
                        if (material.HasProperty("_BaseColor")) material.SetColor("_BaseColor", Color.white);
                        material.DisableKeyword("_EMISSION"); material.DisableKeyword("_NORMALMAP");
                        if (material.HasProperty("_EmissionColor")) material.SetColor("_EmissionColor", Color.black);
                        if (material.HasProperty("_Glossiness")) material.SetFloat("_Glossiness", .25f);
                        if (material.HasProperty("_Smoothness")) material.SetFloat("_Smoothness", .25f);
                        materials[i] = material;
                    }
                    var meshes = new Mesh[meshCount];
                    for (int i = 0; i < meshCount; i++)
                    {
                        int count = reader.ReadInt32();
                        if (count < 3 || count > 65535) throw new InvalidDataException("Invalid vertex count.");
                        var vertices = new Vector3[count]; var normals = new Vector3[count]; var uv = new Vector2[count];
                        for (int v = 0; v < count; v++)
                        {
                            vertices[v] = new Vector3(reader.ReadSingle(), reader.ReadSingle(), reader.ReadSingle());
                            normals[v] = new Vector3(reader.ReadSingle(), reader.ReadSingle(), reader.ReadSingle());
                            uv[v] = new Vector2(.5f, .5f);
                        }
                        var mesh = new Mesh { name = "Switchboards.Simple." + new[] { "Housing", "Interior", "Door" }[i] };
                        var tangents = new Vector4[count];
                        for (int v = 0; v < count; v++)
                        {
                            var axis = Mathf.Abs(normals[v].y) < .9f ? Vector3.up : Vector3.right;
                            var t = Vector3.Cross(axis, normals[v]).normalized;
                            tangents[v] = new Vector4(t.x, t.y, t.z, 1f);
                        }
                        mesh.vertices = vertices; mesh.normals = normals; mesh.uv = uv; mesh.tangents = tangents;
                        mesh.subMeshCount = materialCount;
                        for (int m = 0; m < materialCount; m++)
                        {
                            int n = reader.ReadInt32();
                            if (n < 0 || n > count * 3 || n % 3 != 0) throw new InvalidDataException("Invalid triangle count.");
                            var indices = new int[n];
                            for (int j = 0; j < n; j++)
                            {
                                indices[j] = reader.ReadInt32();
                                if (indices[j] < 0 || indices[j] >= count) throw new InvalidDataException("Invalid index.");
                            }
                            mesh.SetTriangles(indices, m, false);
                        }
                        mesh.RecalculateBounds(); meshes[i] = mesh;
                    }
                    if (stream.Position != stream.Length) throw new InvalidDataException("Trailing geometry data.");
                    Materials = materials; PaletteIndices = colorIndices; Meshes = meshes;
                }
            }
            Debug.Log("[Modular Switchboards] Simple native surfaces loaded; flat palette, no atlas UV tiles; shader " + template.shader.name);
        }
    }
}
