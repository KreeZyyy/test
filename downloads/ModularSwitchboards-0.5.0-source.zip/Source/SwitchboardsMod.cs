using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Assets.Scripts;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Electrical;
using Assets.Scripts.Objects.Structures;
using Assets.Scripts.Util;
using HarmonyLib;
using LaunchPadBooster;
using Reagents;
using UnityEngine;
using Object = UnityEngine.Object;

namespace ModularSwitchboards
{
    public sealed class SwitchboardsMod : MonoBehaviour
    {
        public const string Version = "0.5.0";
        // Keep the 0.1.0 identity so saved kits continue to work.
        public const string KitName = "ItemKitModularSwitchboard";
        public const string CabinetName = "StructureModularSwitchboard";
        public static readonly Mod Mod = new Mod("ModularSwitchboards", Version);
        private static bool loaded;
        private static GameObject storage;
        private static readonly MethodInfo CloneMethod = AccessTools.Method(typeof(object), "MemberwiseClone");

        public void OnLoaded(List<GameObject> prefabs)
        {
            if (loaded) return;
            var harmony = new Harmony("modularswitchboards.prototype");
            harmony.Patch(AccessTools.Method(typeof(Prefab), "LoadAll"),
                prefix: new HarmonyMethod(typeof(SwitchboardsMod), nameof(PreparePrefabs)));
            harmony.Patch(AccessTools.Method(typeof(DynamicThingRecipeComparable), "GenerateRecipieList"),
                prefix: new HarmonyMethod(typeof(SwitchboardsMod), nameof(PrepareRecipe)));
            harmony.Patch(AccessTools.Method(typeof(Localization), "GetThingName"),
                prefix: new HarmonyMethod(typeof(SwitchboardsMod), nameof(LocalizeName)));
            harmony.Patch(AccessTools.Method(typeof(Localization), "GetThingDescription"),
                prefix: new HarmonyMethod(typeof(SwitchboardsMod), nameof(LocalizeDescription)));
            harmony.Patch(AccessTools.Method(typeof(Structure), "CachePrefabBounds"),
                prefix: new HarmonyMethod(typeof(SwitchboardsMod), nameof(CacheCabinetBounds)));
            harmony.Patch(AccessTools.Method(typeof(Thing), "CanCacheRenderer"),
                prefix: new HarmonyMethod(typeof(CabinetAppearance), nameof(CabinetAppearance.CanCacheRenderer)));
            harmony.Patch(AccessTools.Method(typeof(Thing), "Awake"),
                postfix: new HarmonyMethod(typeof(CabinetAppearance), nameof(CabinetAppearance.RegisterRenderers)));
            harmony.Patch(AccessTools.Method(typeof(Structure), "DeserializeSave"),
                prefix: new HarmonyMethod(typeof(SwitchboardsMod), nameof(MigrateCabinetSave)));
            harmony.Patch(AccessTools.Method(typeof(Thing), "SetCustomColor", new[] { typeof(int), typeof(bool) }),
                postfix: new HarmonyMethod(typeof(CabinetAppearance), nameof(CabinetAppearance.RefreshPaint)));
            Mod.Networking.Required = true;
            Prefab.OnPrefabsLoaded += VerifyRegistration;
            WorldManager.OnGameDataLoaded += VerifyRecipe;
            loaded = true;
            Debug.Log("[Modular Switchboards] " + Version + " loaded.");
        }

        private static T Source<T>(IEnumerable<Thing> sources, string name) where T : Thing
        {
            var result = sources.OfType<T>().FirstOrDefault(p => p.PrefabName == name || p.name == name);
            if (result == null) throw new InvalidOperationException("Missing source prefab: " + name);
            return result;
        }

        private static void Identify(Thing thing, string name, string title)
        {
            thing.name = name;
            thing.PrefabName = name;
            thing.PrefabHash = Animator.StringToHash(name);
            thing.CustomName = title;
        }

        // Called before LoadAll reads SourcePrefabs. Build complete clones before publishing them.
        private static void PreparePrefabs()
        {
            if (WorldManager.Instance == null)
            {
                Debug.LogError("[Modular Switchboards] WorldManager unavailable.");
                return;
            }
            var sources = WorldManager.Instance.SourcePrefabs;
            if (sources.Any(p => p != null && p.PrefabName == KitName)) return;
            MultiConstructor kit = null;
            Structure cabinet = null;
            try
            {
                foreach (var name in new[] { KitName, CabinetName })
                    if (sources.Any(p => p != null && p.PrefabHash == Animator.StringToHash(name)))
                        throw new InvalidOperationException("Prefab identity collision: " + name);
                var kitSource = Source<MultiConstructor>(sources, "ItemKitLogicSwitch");
                var locker = sources.OfType<Locker>().FirstOrDefault(p => p.PrefabName == "StructureLockerSmall")
                    ?? sources.OfType<Locker>().FirstOrDefault(p => p.PrefabName == "StructureLocker")
                    ?? sources.OfType<Locker>().Where(p => p.GetType() == typeof(Locker) &&
                        p.BuildStates != null && p.BuildStates.Count > 0)
                        .OrderBy(p => p.PrefabName, StringComparer.Ordinal).FirstOrDefault();
                if (locker == null) throw new InvalidOperationException("No vanilla Locker prefab with build states found.");
                var wrench = Source<Item>(sources, "ItemWrench");
                var drill = Source<Item>(sources, "ItemDrill");
                var sheets = Source<Item>(sources, "ItemIronSheets");

                if (storage == null)
                {
                    storage = new GameObject("ModularSwitchboards.SourcePrefabs");
                    storage.SetActive(false);
                    Object.DontDestroyOnLoad(storage);
                }
                kit = Object.Instantiate(kitSource, storage.transform);
                Identify(kit, KitName, "Kit (Switchboard)");
                kit.SetQuantity(1);
                // Do not transfer the temporary vanilla kit's legacy colour to the new shell.
                // Painting is supported on the assembled cabinet itself.
                kit.PaintableMaterial = null;
                kit.RecipeTier = MachineTier.TierOne;
                cabinet = Object.Instantiate<Structure>(locker, storage.transform);
                Identify(cabinet, CabinetName, "Switchboard Cabinet");
                if (cabinet.BuildStates == null || cabinet.BuildStates.Count == 0)
                    throw new InvalidOperationException("Locker has no build state visuals.");

                // Copy from the cloned prefab: its renderer/collider references already point to the clone.
                var visual = cabinet.BuildStates[cabinet.BuildStates.Count - 1];
                cabinet.BuildStates = new List<BuildState>
                {
                    MakeState(visual, kit, 1, null, 0, drill),
                    MakeState(visual, wrench, 0, sheets, 2, wrench)
                };
                cabinet.UpgradePrefab = null;
                // This is a cabinet shell, not a general-purpose storage locker.
                cabinet.Slots = new List<Slot>();
                cabinet.Interactables = cabinet.Interactables.Where(i => i != null && i.Slot == null).ToList();
                CabinetModel.Install(cabinet);
                kit.Constructables = new List<Structure> { cabinet };
                kit.LastSelectedIndex = 0;
                sources.Add(kit);
                sources.Add(cabinet);
                Debug.Log("[Modular Switchboards] Prepared kit + 2-stage empty cabinet with Blender geometry; native base: " + locker.PrefabName);
            }
            catch (Exception ex)
            {
                // Never publish a partially configured prefab pair.
                if (kit != null) { sources.Remove(kit); Object.Destroy(kit.gameObject); }
                if (cabinet != null) { sources.Remove(cabinet); Object.Destroy(cabinet.gameObject); }
                Debug.LogError("[Modular Switchboards] Prefab setup failed: " + ex);
            }
        }

        private static BuildState MakeState(BuildState visual, Item entry, int quantity,
            Item entry2, int quantity2, Item exit)
        {
            // Preserve private batched drawing data, but give each stage its own mutable collections/tool.
            var state = (BuildState)CloneMethod.Invoke(visual, null);
            state.StateMeshes = new List<Mesh>(visual.StateMeshes);
            state.Colliders = new List<Collider>(visual.Colliders);
            state.LinkedGameObjects = new List<GameObject>(visual.LinkedGameObjects);
            state.Interactables = visual.Interactables == null ? new List<Interactable>() :
                visual.Interactables.Where(i => i != null && i.Slot == null).ToList();
            state.RendererInstance = null;
            state.RenderMode = BuildStateRenderMode.OnMyState;
            state.CanManufacture = false;
            state.Tool = new ToolUse
            {
                ToolEntry = entry, EntryQuantity = quantity,
                ToolEntry2 = entry2, EntryQuantity2 = quantity2,
                ToolExit = exit, ExitQuantity = 0, EntryTime = 2f, ExitTime = 2f
            };
            return state;
        }

        // Runs after game/mod recipe files have loaded and before tier lists and recipe hashes are generated.
        private static void PrepareRecipe(DynamicThingRecipeComparable __instance)
        {
            if (!ReferenceEquals(__instance, ElectronicsPrinter.RecipeComparable)) return;
            var kit = Prefab.Find<MultiConstructor>(KitName);
            if (kit == null || __instance.AllRecipes.ContainsKey(kit)) return;
            var recipe = new WorldManager.RecipeData
            {
                PrefabName = KitName, RecipeTier = MachineTier.TierOne, Output = 1f,
                Recipe = new Recipe { Iron = 10, Copper = 10, Electrum = 10, Time = 5f, Energy = 1000f }
            };
            if (__instance.AddRecipe(recipe, null))
                Debug.Log("[Modular Switchboards] Electronics Printer recipe added: 10 Copper + 10 Iron + 10 Electrum -> 1 kit.");
        }

        private static bool LocalizeName(string __0, ref string __result)
        {
            if (__0 == KitName) __result = "Kit (Switchboard)";
            else if (__0 == CabinetName) __result = "Switchboard Cabinet";
            else return true;
            return false;
        }

        private static bool LocalizeDescription(string __0, ref string __result)
        {
            if (__0 != KitName && __0 != CabinetName) return true;
            __result = "Empty modular switchboard cabinet. Print one kit in an Electronics Printer " +
                "(10 Copper + 10 Iron + 10 Electrum). Place one kit on a wall, then use a Wrench " +
                "with 2 Iron Sheets in the other hand to complete the shell and solid cover. " +
                "Dismantle with Wrench, then Drill. Paint changes the exterior only; interior stays light grey. " +
                "DIN rails, wiring and electrical modules will be separate future additions.";
            return false;
        }

        private static void MigrateCabinetSave(Structure __instance, ThingSaveData __0)
        {
            if (__instance.PrefabName == CabinetName && __0 is StructureSaveData save && save.CurrentBuildState > 1)
            {
                save.CurrentBuildState = 1;
                Debug.Log("[Modular Switchboards] Migrated legacy completed cabinet to simple completed shell.");
            }
        }

        private static bool CacheCabinetBounds(Structure __instance)
        {
            if (__instance.PrefabName != CabinetName) return true;
            CabinetModel.SetBounds(__instance);
            return false;
        }

        private static void VerifyRegistration()
        {
            var kit = Prefab.Find<MultiConstructor>(KitName);
            var cabinet = Prefab.Find<Structure>(CabinetName);
            if (kit == null || cabinet == null || cabinet.BuildStates.Count != 2 ||
                kit.Constructables.Count != 1 || kit.Constructables[0].PrefabHash != cabinet.PrefabHash)
                Debug.LogError("[Modular Switchboards] Registration verification FAILED.");
            else
                Debug.Log("[Modular Switchboards] Registration verified: kit + cabinet, 2 build states.");
        }

        private static void VerifyRecipe()
        {
            var kit = Prefab.Find<MultiConstructor>(KitName);
            if (kit == null || !ElectronicsPrinter.RecipeComparable.AllRecipes.ContainsKey(kit) ||
                !ElectronicsPrinter.RecipeComparable.DynamicThings.Contains(kit))
                Debug.LogError("[Modular Switchboards] Electronics Printer recipe verification FAILED.");
            else Debug.Log("[Modular Switchboards] Electronics Printer recipe verified.");
        }
    }
}
