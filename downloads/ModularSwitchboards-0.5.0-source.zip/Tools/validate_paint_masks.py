"""Validate the simple cabinet geometry, normals, indices, paint roles and lack of old internals."""
from pathlib import Path
import struct,math
b=(Path(__file__).resolve().parent.parent/'Assets/Cabinet.meshbin').read_bytes()
assert b[:4]==b'SBMS'
version,materials,groups=struct.unpack_from('<iii',b,4)
assert (version,materials,groups)==(1,5,3)
colors=[struct.unpack_from('<6f',b,16+i*24) for i in range(materials)]
assert all(.65<v<.8 for v in colors[1][:3]), 'Interior must be light grey.'
assert colors[2][0]>.9 and colors[2][1]>.6 and colors[2][2]<.03
assert max(colors[3][:3])<.03
pos=16+24*materials;counts=[];total=0
for group in range(groups):
 n,=struct.unpack_from('<i',b,pos);pos+=4
 assert 3<=n<65536
 for _ in range(n):
  x,y,z,nx,ny,nz=struct.unpack_from('<6f',b,pos);pos+=24
  assert all(math.isfinite(v) for v in (x,y,z,nx,ny,nz))
  assert .99<nx*nx+ny*ny+nz*nz<1.01
 per_material=[]
 for m in range(materials):
  count,=struct.unpack_from('<i',b,pos);pos+=4
  assert count%3==0
  indices=struct.unpack_from('<%di'%count,b,pos) if count else []
  assert all(0<=i<n for i in indices)
  pos+=count*4;per_material.append(count//3);total+=count//3
 counts.append(per_material)
assert pos==len(b)
assert [g for g in range(groups) if counts[g][0]>0]==[0,2]
assert counts[1][1]>0 and sum(counts[1])==counts[1][1], 'Empty interior must contain only fixed grey geometry.'
assert counts[2][2]==1 and counts[2][3]>0, 'Separate warning triangle and black symbol required.'
assert total==1085, 'Unexpected geometry; this asset must not contain old rails or wiring.'
print('Simple cabinet validated:',total,'triangles; 3 parts; exterior-only paint mask; fixed grey interior; separate warning.')
