import bpy,math,struct,json
from pathlib import Path
OUT=Path(__file__).resolve().parent.parent/'Art'
OUT.mkdir(parents=True,exist_ok=True)
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
scene=bpy.context.scene;scene.unit_settings.system='METRIC'
def mat(name,rgb):
 m=bpy.data.materials.new(name);m.diffuse_color=(*rgb,1);m.use_nodes=True
 bs=m.node_tree.nodes.get('Principled BSDF');bs.inputs['Base Color'].default_value=(*rgb,1);bs.inputs['Metallic'].default_value=.25;bs.inputs['Roughness'].default_value=.65
 return m
materials=[mat('Paintable_Shell',(.55,.58,.6)),mat('Fixed_LightGrey_Interior',(.72,.74,.76)),mat('Fixed_Warning_Yellow',(.95,.7,.025)),mat('Fixed_Black_Details',(.025,.025,.025)),mat('Fixed_Hinge_Metal',(.42,.44,.46))]
collections=[]
for n in ['Housing','Interior','Door']:
 c=bpy.data.collections.new(n);scene.collection.children.link(c);collections.append(c)
root=bpy.data.objects.new('SimpleSwitchboard_ROOT',None);collections[0].objects.link(root)
pivot=bpy.data.objects.new('Door_Hinge_PIVOT',None);collections[2].objects.link(pivot);pivot.parent=root;pivot.location=(-.2,-.187,0)
def box(name,loc,size,mi,group,parent=root,inner=None):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=bpy.context.object;o.name=name;o.dimensions=size;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
 for c in list(o.users_collection):c.objects.unlink(o)
 collections[group].objects.link(o);o.parent=parent;o.data.materials.append(materials[mi])
 if inner:
  o.data.materials.append(materials[1])
  for p in o.data.polygons:
   if p.normal.dot(inner)>.9:p.material_index=1
 bevel=o.modifiers.new('Manufactured_Edge','BEVEL');bevel.width=.0015;bevel.segments=2
 bpy.context.view_layer.objects.active=o;bpy.ops.object.modifier_apply(modifier=bevel.name)
 return o
from mathutils import Vector
box('Back',(0,-.003,0),(.4,.006,.5),0,0,inner=Vector((0,-1,0)))
box('Left',(-.197,-.09,0),(.006,.18,.5),0,0,inner=Vector((1,0,0)))
box('Right',(.197,-.09,0),(.006,.18,.5),0,0,inner=Vector((-1,0,0)))
box('Top',(0,-.09,.247),(.388,.18,.006),0,0,inner=Vector((0,0,-1)))
box('Bottom',(0,-.09,-.247),(.388,.18,.006),0,0,inner=Vector((0,0,1)))
# An empty, light-grey back plate; no rails, cables, holes or electronic devices.
box('Empty_Interior_Plate',(0,-.011,0),(.35,.004,.44),1,1)
box('Solid_Metal_Door',(.2,-.004,0),(.4,.012,.5),0,2,parent=pivot,inner=Vector((0,1,0)))
box('Handle',(.37,-.025,-.06),(.017,.028,.065),3,2,parent=pivot)
for z in [-.17,.17]:box('Hinge',(-.204,-.18,z),(.014,.023,.035),4,0)
# Clearly separate yellow/black warning sign geometry on the opaque door.
verts=[(.17,-.011,-.16),(.23,-.011,-.16),(.20,-.011,-.108)]
m=bpy.data.meshes.new('WarningTriangle');m.from_pydata(verts,[],[(0,1,2)]);m.update();o=bpy.data.objects.new('Warning_Triangle',m);collections[2].objects.link(o);o.parent=pivot;o.data.materials.append(materials[2])
verts=[(.201,-.012,-.116),(.188,-.012,-.141),(.200,-.012,-.141),(.195,-.012,-.154),(.213,-.012,-.130),(.201,-.012,-.130)]
m=bpy.data.meshes.new('WarningBolt');m.from_pydata(verts,[],[tuple(range(6))]);m.update();o=bpy.data.objects.new('Warning_Bolt',m);collections[2].objects.link(o);o.parent=pivot;o.data.materials.append(materials[3])
pivot.rotation_euler.z=0;pivot.keyframe_insert(data_path='rotation_euler',frame=1)
pivot.rotation_euler.z=math.radians(-110);pivot.keyframe_insert(data_path='rotation_euler',frame=30);scene.frame_end=30;scene.frame_set(1)
root['purpose']='Empty cabinet only; no DIN rails or wiring.'
root['dimensions']='400 x 500 x 180 mm';root['construction']='1 kit, then Wrench + 2 Iron Sheets'
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'SimpleSwitchboard.blend'))
bpy.ops.object.select_all(action='SELECT')
bpy.ops.export_scene.gltf(filepath=str(OUT/'SimpleSwitchboard.glb'),export_format='GLB',use_selection=True)
groups=[]
for g in range(3):
 vv=[];nn=[];ss=[[] for _ in materials]
 for o in collections[g].objects:
  if o.type!='MESH':continue
  mesh=o.data;mesh.calc_loop_triangles();mx=o.matrix_world if g!=2 else pivot.matrix_world.inverted()@o.matrix_world;nm=mx.to_3x3().inverted().transposed()
  for t in mesh.loop_triangles:
   mi=materials.index(o.data.materials[t.material_index]);idx=len(vv)
   for li in t.loops:
    v=mx@mesh.vertices[mesh.loops[li].vertex_index].co;n=(nm@mesh.corner_normals[li].vector).normalized()
    vv.append((v.x,v.z,-v.y));nn.append((n.x,n.z,-n.y))
   ss[mi].extend([idx,idx+2,idx+1])
 groups.append((vv,nn,ss))
out=Path(__file__).resolve().parent.parent/'Assets/Cabinet.meshbin'
out.parent.mkdir(parents=True,exist_ok=True)
with out.open('wb') as f:
 f.write(b'SBMS');f.write(struct.pack('<iii',1,len(materials),3))
 for m in materials:f.write(struct.pack('<6f',*m.diffuse_color,.25,.65))
 for vv,nn,ss in groups:
  f.write(struct.pack('<i',len(vv)))
  for v,n in zip(vv,nn):f.write(struct.pack('<6f',*(v+n)))
  for indices in ss:
   f.write(struct.pack('<i',len(indices)))
   if indices:f.write(struct.pack('<%di'%len(indices),*indices))
print('SIMPLE_MODEL',[(len(v),sum(len(x) for x in s)//3) for v,n,s in groups])
