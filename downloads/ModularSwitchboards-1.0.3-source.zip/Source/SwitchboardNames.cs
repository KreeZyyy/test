namespace ModularSwitchboards
{
    internal static class SwitchboardNames
    {
        internal const string DoorKitTitle="Kit (Switchboard Door Modules)";
        internal static string LabelTitle(int width)=>"Switchboard Label";
        internal static string Default(string prefab)
        {
            if(prefab=="StructureDinSmartModule")return "DIN Smart Module";
            if(prefab==SwitchboardsMod.DoorKitName)return DoorKitTitle;
            if(prefab==SwitchboardsMod.CoverKitName)return "Kit (Switchboard Cover)";
            if(prefab==SwitchboardsMod.RailKitName)return "Kit (Switchboard Rails)";
            if(prefab==SwitchboardsMod.SmartKitName)return "Kit (DIN Smart Modules)";
            if(prefab==SwitchboardsMod.BreakerKitName)return "Kit (Switchboard Modules)";
            if(prefab==SwitchboardsMod.CoverName)return "Switchboard Cover";
            if(prefab==SwitchboardsMod.RailName)return "Switchboard Rail";
            return null;
        }
        internal static string Migrate(string prefab,string saved)
        {
            if(prefab=="StructureDinSmartModule"&&saved=="Smart Module")return Default(prefab);
            for(int width=1;width<=3;width++)if(prefab=="StructureSwitchboardLabel"+width&&(saved=="Switchboard Label ("+width+" module"+(width==1?"":"s")+")"||saved=="Switchboard Label "+width+" module"+(width==1?"":"s")))return LabelTitle(width);
            bool old=(prefab==SwitchboardsMod.DoorKitName&&saved=="Switchboards Doors Module")||
                (prefab==SwitchboardsMod.CoverKitName&&saved=="Kit (Inner Cover)")||
                (prefab==SwitchboardsMod.RailKitName&&saved=="Kit (DIN Rail)")||
                (prefab==SwitchboardsMod.BreakerKitName&&(saved=="Kit (DIN Modules)"||saved=="Kit (DIN Breaker)"||saved=="Kit (DIN Breaker 1P)"))||
                (prefab==SwitchboardsMod.CoverName&&saved=="Switchboard Inner Cover")||
                (prefab==SwitchboardsMod.RailName&&saved=="DIN Rail");
            return old?Default(prefab):saved;
        }
    }
}
