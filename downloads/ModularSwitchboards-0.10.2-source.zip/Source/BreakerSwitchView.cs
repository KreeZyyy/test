using UnityEngine;
using Assets.Scripts.Objects.Motherboards;

namespace ModularSwitchboards
{
    internal static class BreakerSwitchPose
    {
        internal const float Duration = .22f;
        internal static int IndicatorColor(bool on) => (int)(on ? ColorType.Green : ColorType.Red);
        internal static float LeverAngle(bool on) => on ? -35f : 35f;
        internal static float Ease(float t) { t = Mathf.Clamp01(t); return t*t*(3f-2f*t); }
    }

    // Native OnOff owns saved/networked state. Animate only the visual, around a fixed spindle.
    public sealed class BreakerSwitchView : MonoBehaviour
    {
        public DinBreaker Owner;
        public Transform Lever;
        public TextMesh StateText;
        private bool initialized;
        private bool previous;
        private float angle;
        private float startAngle;
        private float elapsed;

        private void LateUpdate()
        {
            if (Owner == null || Lever == null) return;
            Tick(Owner.OnOff, Time.deltaTime);
        }
        internal void Tick(bool on, float deltaTime)
        {
            if (!initialized) { Apply(on); return; }
            if (previous != on)
            {
                previous=on; startAngle=angle; elapsed=0f;
                Refresh(on);
            }
            elapsed=Mathf.Min(BreakerSwitchPose.Duration, elapsed+Mathf.Max(0f,deltaTime));
            float t=BreakerSwitchPose.Ease(elapsed/BreakerSwitchPose.Duration);
            angle=startAngle+(BreakerSwitchPose.LeverAngle(on)-startAngle)*t;
            Pose();
        }
        internal void Apply(bool on)
        {
            if (Lever == null) return;
            angle=startAngle=BreakerSwitchPose.LeverAngle(on);
            elapsed=BreakerSwitchPose.Duration; previous=on; initialized=true;
            Pose(); Refresh(on);
        }
        private void Pose()
        {
            Lever.localPosition=new Vector3(0,0,.064f);
            Lever.localRotation=Quaternion.Euler(angle,0,0);
        }
        private void Refresh(bool on)
        {
            if(StateText!=null) StateText.text=on?"ON":"OFF";
            if(Owner!=null) DinBreakerModel.Refresh(Owner);
        }
    }
}
