using System;
using System.Collections.Generic;
using Assets.Scripts;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Motherboards;
using HarmonyLib;
using UnityEngine;

namespace ModularSwitchboards
{
    internal static class CabinetAppearance
    {
        private static readonly System.Reflection.FieldInfo PaintMappings = AccessTools.Field(typeof(Thing), "_customMaterials");
        internal static bool CanCacheRenderer(Thing __instance, ref bool __result)
        {
            if (__instance.PrefabName != SwitchboardsMod.CabinetName && !(__instance is DinRail) && !(__instance is DinBreaker)) return true;
            __result = false; return false;
        }

        internal static void RefreshPaint(Thing __instance)
        {
            if (__instance is DinBreaker) { DinBreakerModel.Refresh(__instance); return; }
            if (__instance is DinRail) { DinRailModel.Refresh(__instance); return; }
            if (__instance.PrefabName != SwitchboardsMod.CabinetName) return;
            var model = __instance.transform.Find("SwitchboardModel");
            if (model == null) return;
            int color = __instance.CustomColor == null ? (int)ColorType.White : __instance.CustomColor.Index;
            foreach (var renderer in model.GetComponentsInChildren<MeshRenderer>(true))
            {
                if (renderer.GetComponentInParent<Thing>() != __instance || renderer.name=="CabinetLabelText") continue;
                if (renderer.name == "NativeApcWarning") { ApcWarning.RestoreColor(renderer, __instance.SmoothnessIndex); continue; }
                var filter = renderer.GetComponent<MeshFilter>();
                if (filter == null || filter.sharedMesh == null) continue;
                var materials = renderer.sharedMaterials;
                for (int i = 0; i < materials.Length; i++)
                {
                    if (filter.sharedMesh.GetIndexCount(i) == 0) continue;
                    // All our mesh submeshes use the same role ordering. Spacer is a single native cube.
                    int role = renderer.name == "MountingSpacer" ? 4 : i;
                    var block = new MaterialPropertyBlock();
                    renderer.GetPropertyBlock(block, i);
                    block.SetFloat(Thing.DiffuseIndexPropertyID, role == 0 ? color : CabinetGeometry.PaletteIndices[role]);
                    block.SetFloat(Thing.SmoothnessIndexPropertyID, __instance.SmoothnessIndex);
                    block.SetColor(Thing.EMISSION_COLOR, role == 0 ? __instance.EmissionColor : Color.black);
                    renderer.SetPropertyBlock(block, i);
                }
            }
        }

        internal static void BeginBuildColor(Structure __instance,bool __1,out bool __state)
        {
            // Only actual tool actions enter this path; save loading and replication do not.
            // Run on the simulation authority so join-in-progress clients do not overwrite saved paint.
            __state=__instance.PrefabName==SwitchboardsMod.CabinetName && GameManager.RunSimulation &&
                __1 && __instance.CurrentBuildStateIndex==0;
        }
        internal static void ApplyCompletedWhite(Structure __instance,bool __state)
        {
            if(__state && __instance.CurrentBuildStateIndex==1)
                __instance.SetCustomColor((int)ColorType.White);
        }

        internal static void RegisterRenderers(Thing __instance)
        {
            if (__instance is DinRail || __instance is DinBreaker)
            {
                __instance.Renderers = new List<ThingRenderer>();
                foreach (var renderer in __instance.GetComponentsInChildren<MeshRenderer>(true))
                    if (renderer.GetComponentInParent<Thing>() == __instance && renderer.name!="BreakerStateText")
                        __instance.Renderers.Add(new ThingRenderer(__instance, renderer));
                PaintMappings.SetValue(__instance, new List<CustomColorMapping>());
                if (__instance is DinBreaker) DinBreakerModel.Refresh(__instance); else DinRailModel.Refresh(__instance);
                return;
            }
            if (__instance.PrefabName != SwitchboardsMod.CabinetName) return;
            var model = __instance.transform.Find("SwitchboardModel");
            if (model == null) return;
            __instance.Renderers = new List<ThingRenderer>();
            var mappings = new List<CustomColorMapping>();
            foreach (var renderer in model.GetComponentsInChildren<MeshRenderer>(true))
            {
                if (renderer.GetComponentInParent<Thing>() != __instance || renderer.name=="CabinetLabelText") continue;
                var tr = new ThingRenderer(__instance, renderer);
                __instance.Renderers.Add(tr);
                var mesh = tr.MeshFilter.sharedMesh;
                if ((renderer.name == "Housing" || renderer.name == "Door") && mesh.GetIndexCount(0) > 0)
                    mappings.Add(new CustomColorMapping(tr, 0, GameManager.GetColorIndex(__instance.PaintableMaterial)));
            }
            PaintMappings.SetValue(__instance, mappings);
            __instance.HasColorState = false;
            RefreshPaint(__instance);
            Debug.Log("[Modular Switchboards] Native APC texture mapping ready; exterior paint mappings=" + mappings.Count);
        }
    }
}
