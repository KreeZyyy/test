# Station Assistant 0.2.0 — Gemini + hlas Windows

Český palubní chat pro ScriptedScreens. Text odpovědi vytváří Gemini API; hlas generuje lokálně Windows, přednostně Microsoft Jakub. Tato verze nevolá OpenAI ani placenou službu pro syntézu hlasu.

## Instalace / aktualizace

1. Ukonči Stationeers. Rozbal `StationAssistant-0.2.0.zip`.
2. Nahraď složku `Dokumenty/My Games/Stationeers/mods/StationAssistant` složkou ze ZIPu. Nesmaž konfiguraci v `BepInEx/config`, aby zůstal tvůj místní bridge token. Soubor `windows-voice.ps1` musí být vedle `StationAssistant.dll`.
3. Spusť hru a povol Station Assistant v LaunchPadu. Nech mod jednou načíst, aby vytvořil nové položky konfigurace. Potom hru ukonči.
4. V `BepInEx/config/kreezyyy.stationeers.assistant.cfg` vyplň v sekci `[Gemini]` **GeminiApiKey** klíčem z Google AI Studio. **GeminiModel = auto** vybere z modelů dostupných tvému klíči textový model Flash, s předností pro stabilní Lite. Lze zadat konkrétní model z AI Studia. Zůstaň na projektu **Free tier**, nezapínej placené účtování. Dostupnost modelu a bezplatné limity určuje Google; mod nemůže ověřit účtování tvého projektu. Při vyčerpání limitu počkáš, mod nepřepíná na placeného poskytovatele.
5. V `[Audio]` ponech **WindowsVoice = Microsoft Jakub**. Když se nenajde, použije jiný dostupný český hlas; na angličtinu nepřepne. Pokud žádný český hlas není dostupný, zůstane text a panel oznámí chybu hlasu.
6. Z `[Bridge]` zkopíruj pouze **Token** do `TOKEN` na začátku `assistant.lua`. Klíč Gemini do Lua nepatří. Port v Lua a konfiguraci musí být stejný (výchozí 18765).
7. V konfiguraci StationeersLua na hostiteli nastav v `[Features]` **AllowHttp = true** a **AllowHttpLocalhost = true**.
8. Restartuj hru. Nahraj nový `assistant.lua` přes IC10Editor do Lua chipu ve ScriptedScreens konzoli/počítači. Napiš otázku a klikni Odeslat.

API klíče, konfigurační soubory a screenshoty s klíčem nesdílej. Staré položky `[Online AI]` z verze 0.1 nejsou používané. Gemini klíč patří výhradně do `[Gemini] GeminiApiKey`.

## Hlas a kompatibilita

Microsoft Jakub se získává přes Windows Runtime SpeechSynthesizer (OneCore), nikoliv jen klasické SAPI. Není potřeba upravovat registr. Mod spouští místní Windows PowerShell 5.1 na pozadí, předá text v dočasném souboru, převede WAV na mono PCM16/24 kHz a přehraje ho přes Unity. Žádný text se neposílá do online hlasové služby. Hlasitost nastavíš přes `[Audio] Volume` a herní zvuk. Při vypnutém hlasu se PowerShell nespustí.

Text otázky se posílá Googlu na `generativelanguage.googleapis.com`. Žádné senzory, zařízení nebo stav světa mod zatím nečte. Každá otázka je samostatná; nejsou podporované mikrofon, historie konverzace ani řízení základny. Hlas je syntetický. Panel zatím používá základní prvky ScriptedScreens, Vector je volitelný.

Určeno pro Windows 10/11, **singleplayer nebo místního session hostitele**. Lua běží na hostiteli, takže připojeným multiplayerovým klientům se hlas nešíří. Headless server mod nespouští. Listener je pouze na `127.0.0.1`, nezpřístupňuj ho do internetu.

## Co bylo ověřeno

- Sestavení celé verze 0.2 proti dodaným knihovnám BepInEx, StationeersMods.Interface a Unity: bez chyb a varování.
- 16 kontrol bez skutečného API: Gemini payload a hlavička klíče, automatický výběr modelu, text/hlas, zachování textu při chybě hlasu, PCM/WAV převod, lokální autorizace, úlohy a limity.
- Chování skutečného Lua panelu s náhradami herních API: prázdná otázka, duplicitní odeslání, polling, odpověď, přepínač hlasu, chyba, timeout a opožděná odpověď.
- Předchozí verze 0.1 se již načetla u uživatele ve hře.

**Ve verzi 0.2 ještě nebylo ověřeno skutečné Gemini API, generování Jakubova hlasu na Windows ani přehrávání ve hře.** To nyní musí potvrdit test na tvém PC. Pokud hlas selže, nezasílej konfiguraci; pošli pouze text chyby nebo screenshot panelu bez klíče.

## Vývoj

Sestavení vyžaduje .NET SDK 8 a `Stationeers.User.props` vytvořený z `.example` s cestami k tvým herním knihovnám. `dotnet build StationAssistant.csproj -c Release` a `scripts/package.ps1` připraví složku modu. Žádné herní knihovny ani API klíče se do distribuce nepřibalují.

Ověření bez hry a bez kreditu:

```
dotnet run --project tests/CoreTests.csproj
python -m pip install lupa==2.6
python tests/test_ui.py
```
