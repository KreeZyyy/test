from pathlib import Path
import json,struct
root=Path(__file__).resolve().parents[2]
def f32(v):return struct.pack('<f',v)
exports=json.loads((root/'Art/NativeKitGeometry.json').read_text());checks=0
for name,data in exports.items():
 source=json.loads((root/'Art/NativeKits'/data['source']/'reference.json').read_text())['parts'][0]
 for i,old in enumerate(data['sourceVertexIds']):
  for k,c in enumerate('xyz'):assert f32(data['vertices'][i][k])==f32(source['vertices'][old][c]);checks+=1
  for k,c in enumerate('xy'):assert f32(data['uv'][i][k])==f32(source['uv'][old][c]);checks+=1
 for sub,t in data['triangles'].items():
  original=next(s['triangles']for s in source['surfaces']if s['submesh']==int(sub));originalFaces={tuple(original[i:i+3])for i in range(0,len(original),3)}
  translated=[data['sourceVertexIds'][i]for i in t]
  for i in range(0,len(t),3):assert tuple(translated[i:i+3])in originalFaces;checks+=1
  if name=='Frame':assert translated==original;checks+=1
 # Check the actual embedded format rather than only the JSON export.
 raw=(root/'Assets'/f'NativeKit{name}.meshbin').read_bytes();assert raw[:4]==b'NKIT';count,groups=struct.unpack_from('<ii',raw,4);assert count==len(data['vertices']) and groups==len(data['triangles']);off=12
 for v,n,u,u1,u2 in zip(data['vertices'],data['normals'],data['uv'],data['uv1'],data['uv2']):assert raw[off:off+48]==struct.pack('<12f',*v,*n,*u,*u1,*u2);off+=48;checks+=1
 for ts in data['triangles'].values():
  length=struct.unpack_from('<i',raw,off)[0];off+=4;assert length==len(ts);assert list(struct.unpack_from('<'+'i'*length,raw,off))==ts;off+=4*length;checks+=1
 assert off==len(raw)
print(f'Native asset provenance: {checks} checks passed; every retained vertex/UV/triangle matches original source, frame complete, embedded payloads exact.')
