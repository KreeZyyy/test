"""Preserve native topology/UVs; the crate is the connected outer shell plus its four clips.
All label-plate contents are removed by exact connected-component index sets.
The frame package is retained whole, including both original material groups.
"""
from pathlib import Path
import json,struct
root=Path(__file__).resolve().parents[1]
exports={}
for name,key in [('ItemKitModularConsoleLabelPlates','Crate'),('ItemKitModularConsole','Frame')]:
 a=json.loads((root/'Art/NativeKits'/name/'reference.json').read_text())['parts'][0]
 def channel(attribute,dimension):
  desc=next((d for d in a['attributes']if d['attribute']==attribute),None)
  if desc is None:return [[0.0]*dimension for _ in a['vertices']]
  stream=next(t for t in a['streams']if t['stream']==desc['stream']);raw=(root/'Art/NativeKits'/name/stream['file']).read_bytes();fmt='e' if desc['format']=='Float16' else 'f'
  return [list(struct.unpack_from('<'+fmt*dimension,raw,i*stream['stride']+desc['offset']))for i in range(len(a['vertices']))]
 normals=channel('Normal',3);uv1=channel('TexCoord1',2);uv2=channel('TexCoord2',2)
 v=[[p[k]for k in 'xyz']for p in a['vertices']];uv=[[p[k]for k in 'xy']for p in a['uv']]
 groups={s['submesh']:s['triangles'] for s in a['surfaces']}
 if key=='Crate':
  parent=list(range(len(v)));weld={}
  def find(x):
   while parent[x]!=x:parent[x]=parent[parent[x]];x=parent[x]
   return x
  def join(x,y):parent[find(x)]=find(y)
  for i,p in enumerate(v):
   k=tuple(round(x,5)for x in p)
   if k in weld:join(i,weld[k])
   else:weld[k]=i
  t=groups[0]
  for i in range(0,len(t),3):join(t[i],t[i+1]);join(t[i],t[i+2])
  components={}
  for i in range(0,len(t),3):components.setdefault(find(t[i]),[]).extend(t[i:i+3])
  selected=[]
  for ids in components.values():
   lo=[min(v[j][k]for j in ids)for k in range(3)];hi=[max(v[j][k]for j in ids)for k in range(3)]
   shell=len(ids)==624*3 and lo[0]<-.269 and hi[0]>.269
   clip=len(ids)==34*3 and lo[1]>.30 and abs((lo[2]+hi[2])/2)>.25
   if shell or clip:selected+=ids
  assert len(selected)==760*3,'Native outer crate/clip selection changed'
  groups={0:selected}
 ids=sorted({i for t in groups.values() for i in t});remap={old:new for new,old in enumerate(ids)}
 v=[v[i]for i in ids];uv=[uv[i]for i in ids];normals=[normals[i]for i in ids];uv1=[uv1[i]for i in ids];uv2=[uv2[i]for i in ids];groups={k:[remap[i]for i in t]for k,t in groups.items()}
 exports[key]={'vertices':v,'uv':uv,'triangles':groups,'source':name,'sourceVertexIds':ids,'normals':normals,'uv1':uv1,'uv2':uv2}
 with (root/'Assets'/f'NativeKit{key}.meshbin').open('wb')as f:
  f.write(b'NKIT');f.write(struct.pack('<ii',len(v),len(groups)))
  for p,n,u,u1,u2 in zip(v,normals,uv,uv1,uv2):f.write(struct.pack('<12f',*p,*n,*u,*u1,*u2))
  for t in groups.values():f.write(struct.pack('<i',len(t)));f.write(struct.pack('<'+'i'*len(t),*t))
(root/'Art/NativeKitGeometry.json').write_text(json.dumps(exports))
print('Original crate:760 selected triangles; original frame:3226 triangles, two materials; source UVs retained.')
