"""Extract unchanged production rail methods for geometry verification/export without Unity."""
from pathlib import Path
p=Path(__file__).resolve().parents[1]
def method(s,marker):
 start=s.index(marker);i=s.index('{',start)+1;level=1
 while level:level+=(s[i]=='{')-(s[i]=='}');i+=1
 return s[start:i]
s=(p/'Source/DinRailModel.cs').read_text()
(p/'Verification/KitGeometry/RailExtracted.cs').write_text('using System;using System.Linq;using System.Collections.Generic;using UnityEngine;namespace ModularSwitchboards{static class DinRailModel{'+''.join(method(s,m)for m in ['internal static Mesh Build(', 'private static void WebPatch(', 'private static void RailQuad(', 'internal static void AddBox('])+'}}')
