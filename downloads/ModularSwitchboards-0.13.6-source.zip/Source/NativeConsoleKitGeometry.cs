using System;
using System.IO;
using System.Collections.Generic;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class NativeConsoleKitGeometry
    {
        internal static Mesh Load(bool frame)
        {
            string kind=frame?"Frame":"Crate";
            using(var stream=typeof(NativeConsoleKitGeometry).Assembly.GetManifestResourceStream("ModularSwitchboards.NativeKit"+kind+".meshbin"))
            using(var reader=new BinaryReader(stream??throw new InvalidDataException("Missing native kit geometry")))
            {
                if(new string(reader.ReadChars(4))!="NKIT")throw new InvalidDataException("Invalid native kit geometry");
                int count=reader.ReadInt32(),groups=reader.ReadInt32();
                var v=new List<Vector3>();var normals=new List<Vector3>();var uv=new List<Vector2>();var uv1=new List<Vector2>();var uv2=new List<Vector2>();
                for(int i=0;i<count;i++){v.Add(new Vector3(reader.ReadSingle(),reader.ReadSingle(),reader.ReadSingle()));normals.Add(new Vector3(reader.ReadSingle(),reader.ReadSingle(),reader.ReadSingle()));uv.Add(new Vector2(reader.ReadSingle(),reader.ReadSingle()));uv1.Add(new Vector2(reader.ReadSingle(),reader.ReadSingle()));uv2.Add(new Vector2(reader.ReadSingle(),reader.ReadSingle()));}
                var mesh=new Mesh{name="Switchboards.NativeConsoleKit."+kind};mesh.SetVertices(v);mesh.SetNormals(normals);mesh.SetUVs(0,uv);mesh.SetUVs(1,uv1);mesh.SetUVs(2,uv2);mesh.subMeshCount=groups;
                for(int sub=0;sub<groups;sub++)
                {
                    int length=reader.ReadInt32();var indices=new int[length];
                    for(int i=0;i<length;i++){indices[i]=reader.ReadInt32();if(indices[i]<0||indices[i]>=count)throw new InvalidDataException("Invalid native kit index");}
                    mesh.SetTriangles(indices,sub);
                }
                mesh.RecalculateBounds();return mesh;
            }
        }
    }
}
