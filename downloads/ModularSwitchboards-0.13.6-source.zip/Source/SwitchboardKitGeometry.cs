using System.Collections.Generic;
using UnityEngine;
namespace ModularSwitchboards
{
    internal enum SwitchboardKitKind{Cabinet,Rails,Modules,Cover}
    internal static class SwitchboardKitGeometry
    {
        internal static float Fit(Vector3 envelope,Vector3 size)=>Mathf.Min(envelope.x/size.x,Mathf.Min(envelope.y/size.y,envelope.z/size.z))*.92f;
        // Only kit contents are generated here. The outer crate/frame is the
        // preserved original Console kit mesh, with original UVs/materials.
        internal static Mesh Build(SwitchboardKitKind kind)
        {
            var v=new List<Vector3>();var n=new List<Vector3>();var t=new[]{new List<int>(),new List<int>(),new List<int>(),new List<int>(),new List<int>()};
            if(kind==SwitchboardKitKind.Modules)
                foreach(float x in new[]{-.140f,0,.140f})Append(DinBreakerModel.Build(),new Vector3(x,.215f,-.120f),DinBreakerModel.VisualScale*3f,false,v,n,t);
            else if(kind==SwitchboardKitKind.Rails)
            {
                RoundedGeometry.Box(v,n,t[3],new Vector3(0,.155f,0),new Vector3(.410f,.190f,.410f),.006f);
                foreach(float z in new[]{-.140f,0,.140f})
                    Append(DinRailModel.Build(.380f),new Vector3(0,.250f,z),Vector3.one,true,v,n,t);
            }
            else if(kind==SwitchboardKitKind.Cover)
                for(int i=0;i<4;i++)
                {
                    RoundedGeometry.Box(v,n,t[1],new Vector3(-.015f+i*.009f,.105f+i*.040f,0),new Vector3(.370f,.012f,.370f),.003f);
                    foreach(float x in new[]{-.155f,.155f})RoundedGeometry.Box(v,n,t[3],new Vector3(x,.118f+i*.040f,0),new Vector3(.018f,.014f,.300f),.002f);
                }
            var mesh=new Mesh{name="Switchboards.KitContents."+kind};mesh.SetVertices(v);mesh.SetNormals(n);mesh.subMeshCount=5;
            for(int i=0;i<5;i++)mesh.SetTriangles(t[i],i);
            CabinetGeometry.ApplyNativeUv(mesh);mesh.RecalculateBounds();return mesh;
        }
        private static void Append(Mesh source,Vector3 offset,Vector3 scale,bool layFlat,List<Vector3> v,List<Vector3> n,List<int>[] t)
        {
            int first=v.Count;var vertices=source.vertices;var normals=source.normals;
            for(int i=0;i<vertices.Length;i++)
            {
                var p=Vector3.Scale(vertices[i],scale);var normal=new Vector3(normals[i].x/scale.x,normals[i].y/scale.y,normals[i].z/scale.z).normalized;
                if(layFlat){p=new Vector3(p.x,p.z,-p.y);normal=new Vector3(normal.x,normal.z,-normal.y);}
                v.Add(p+offset);n.Add(normal);
            }
            for(int sub=0;sub<source.subMeshCount;sub++)foreach(int index in source.GetTriangles(sub))t[sub].Add(first+index);
            Object.DestroyImmediate(source);
        }
    }
}
