using System;
using System.Collections.Generic;
using System.Linq;
using Assets.Scripts.Objects;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class NativeConsoleKitSurface
    {
        private sealed class Surface{internal Material[] Materials;internal MaterialPropertyBlock[] Blocks;}
        private static readonly Dictionary<bool,Surface> Sources=new Dictionary<bool,Surface>();
        private static Surface Get(bool frame)
        {
            if(Sources.TryGetValue(frame,out var found))return found;
            string name=frame?"ItemKitModularConsole":"ItemKitModularConsoleLabelPlates";
            var kit=WorldManager.Instance.SourcePrefabs.OfType<MultiConstructor>().FirstOrDefault(k=>k.PrefabName==name);
            var renderer=kit?.GetComponentsInChildren<MeshRenderer>(true).FirstOrDefault(r=>r.GetComponent<MeshFilter>()?.sharedMesh!=null);
            if(renderer==null)throw new InvalidOperationException("Original native console kit unavailable: "+name);
            var global=new MaterialPropertyBlock();renderer.GetPropertyBlock(global);
            var source=new Surface{Materials=renderer.sharedMaterials,Blocks=new MaterialPropertyBlock[renderer.sharedMaterials.Length]};
            for(int i=0;i<source.Blocks.Length;i++){var b=new MaterialPropertyBlock();renderer.GetPropertyBlock(b,i);source.Blocks[i]=b.isEmpty?global:b;}
            Sources[frame]=source;return source;
        }
        internal static void Apply(MeshRenderer renderer,bool frame)
        {
            var source=Get(frame);renderer.sharedMaterials=source.Materials;
            renderer.SetPropertyBlock(null);
            for(int i=0;i<source.Blocks.Length;i++)renderer.SetPropertyBlock(source.Blocks[i],i);
        }
    }
}
