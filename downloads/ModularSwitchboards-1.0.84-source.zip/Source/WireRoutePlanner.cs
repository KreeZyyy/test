using System;
using System.Linq;
using System.Collections.Generic;
using System.Threading;
namespace ModularSwitchboards
{
    // Isolated geometry only: no Unity objects, world state or mutable live lists.
    internal sealed class WireRoutePlanner
    {
        internal sealed class Contact {internal CabinetWireEnd End;internal WirePoint Position,Exit;internal WireRect Bounds;internal bool Door;internal int Leaf;internal float LeadSide;}
        internal readonly Dictionary<CabinetWireEnd,Contact> contacts=new Dictionary<CabinetWireEnd,Contact>();
        internal readonly Dictionary<CabinetWireEnd,int> capacities=new Dictionary<CabinetWireEnd,int>();
        internal readonly List<CabinetWireSaveData> wires=new List<CabinetWireSaveData>();
        internal readonly List<WireRect> railObstacles=new List<WireRect>();
        internal WireRect[] moduleReservations;
        internal string prefabName;
        internal float routingHalfWidth,routingHalfHeight;
        internal CancellationToken cancellation;
        private int Capacity(CabinetWireEnd end)=>capacities[end];
        private static int Surface(Contact c)=>c.Door?c.Leaf+1:0;
        private int WireSurface(CabinetWireSaveData w)=>contacts.TryGetValue(w.From,out var c)?Surface(c):0;
        private static WirePoint[] Expand(float[] values){var p=new WirePoint[values.Length/3];for(int i=0;i<p.Length;i++)p[i]=new WirePoint(values[i*3],values[i*3+1],values[i*3+2]);return p;}
        internal WirePoint[] MakeRoute(CabinetWireEnd from,CabinetWireEnd to,out int slot,out string failure,CabinetWireKind kind=CabinetWireKind.Normal)
        {
            float own=WireVisualProfiles.Get(kind).Radius;
            float other=wires.Where(w=>WireSurface(w)==Surface(contacts[from])).Select(w=>WireVisualProfiles.Get(w.CableKind).Radius).DefaultIfEmpty(0).Max();
            using(WireRouting.ForWire(own,other))return MakeRouteCore(from,to,out slot,out failure);
        }
        private WirePoint[] MakeRouteCore(CabinetWireEnd from,CabinetWireEnd to,out int slot,out string failure)
        {
            var used=new HashSet<int>(wires.Where(w=>w.From.Equals(from)).Select(w=>w.InputSlot));
            var candidates=Enumerable.Range(0,16).Where(i=>!used.Contains(i)).OrderBy(i=>i==0?0:((contacts[to].Exit.X<=0)==(i%2==0)?i:100+i));
            if(from.Owner!=0)candidates=Enumerable.Range(0,Capacity(from)).Where(i=>!used.Contains(i)).OrderBy(i=>i);
            failure=null;slot=0;
            if(contacts[from].Door)
            {
                WirePoint[] best=null;float score=float.PositiveInfinity;
                // Compare cheap, simple lanes across depths before launching any
                // lattice search. Do not accept the first cramped depth blindly.
                foreach(float depth in new[]{.0266f,.0357f,.0448f,.0539f,.063f})
                foreach(int candidate in candidates)
                {
                    var simple=MakeRouteSlot(from,to,candidate,depth,out _,true);
                    if(simple==null)continue;
                    float value=WireLaneRoutes.Score(simple);
                    if(value<score){best=simple;score=value;slot=candidate;}
                }
                if(best!=null)return best;
            }
            foreach(var plane in contacts[from].Door?new[]{.0266f,.0357f,.0448f,.0539f,.063f}:new[]{WireRouting.Plane,.08135f,.09735f,.11335f})
            foreach(var candidate in candidates)
            {
                var found=MakeRouteSlot(from,to,candidate,plane,out failure);
                if(found!=null){slot=candidate;return found;}
            }
            return null;
        }
        private WirePoint[] MakeRouteSlot(CabinetWireEnd from,CabinetWireEnd to,int slot,float plane,out string failure,bool simpleOnly=false)
        {
            cancellation.ThrowIfCancellationRequested();
            failure=null;var a=contacts[from];var b=contacts[to];
            bool joint=from.Owner==0&&from.Contact==0;bool door=a.Door;
            bool branch=from.Owner!=0&&Capacity(from)>1;
            float fan=slot==0?0:((slot+1)/2)*.010f*(slot%2==1?1:-1);
            var start=new WirePoint(a.Exit.X+(joint?fan:branch?(a.Exit.X>0?-1f:1f)*fan*1.5f:0),a.Exit.Y,plane);var end=new WirePoint(b.Exit.X,b.Exit.Y,plane);
            var reservations=door?DoorModuleLayout.Reservations(prefabName):moduleReservations;
            var rails=door?Enumerable.Empty<WireRect>():railObstacles;
            var blocks=contacts.Values.Where(c=>Surface(c)==Surface(a)).Select(c=>c.Bounds).Concat(rails).Concat(reservations).Distinct().ToList();
            var same=wires.Where(w=>WireSurface(w)==Surface(a)).ToArray();
            var shared=branch?same.Where(w=>w.From.Equals(from)).Select(w=>Expand(w.Points)).ToList():new List<WirePoint[]>();
            var other=same.Where(w=>!branch||!w.From.Equals(from)).Select(w=>Expand(w.Points)).ToList();
            var fork=new WireRect(a.Position.X-.019f,a.Position.X+.019f,Math.Min(a.Position.Y,a.Exit.Y)-.009f,Math.Max(a.Position.Y,a.Exit.Y)+.009f);
            // Protect unused door terminals too: a first wire must not occupy
            // the depth-change pocket needed to connect the next channel.
            other.AddRange(contacts.Values.Where(c=>Surface(c)==Surface(a)&&!c.End.Equals(from)&&!c.End.Equals(to)&&!same.Any(w=>w.From.Equals(c.End)||w.To.Equals(c.End))).Select(c=>WireContactLayout.EntryLead(c.Position,new WirePoint(c.Exit.X,c.Exit.Y,door?.063f:.11335f),c.LeadSide,!door&&c.End.Owner==0&&c.End.Contact>0&&Math.Abs(c.Position.X-c.Exit.X)>.001f)));
            other.AddRange(contacts.Values.Where(c=>Surface(c)==Surface(a)&&!c.End.Equals(from)&&!c.End.Equals(to)&&!same.Any(w=>w.From.Equals(c.End)||w.To.Equals(c.End))).Select(c=>new[]{new WirePoint(c.Exit.X,c.Exit.Y,door?.0266f:WireRouting.Plane),new WirePoint(c.Exit.X,c.Exit.Y,door?.063f:.11335f)}));
            var occupied=other.Concat(shared.SelectMany(w=>WireBranchJoint.Outside(w,fork))).ToList();
            WirePoint[] Lead(Contact c,WirePoint anchor)
            {
                // Offset reverse terminal lanes change depth behind the socket,
                // then move sideways on the reserved deepest layer. The anchor
                // column keeps all shallower routing layers available afterwards.
                if(!door&&c.End.Owner==0&&c.End.Contact>0&&Math.Abs(c.Position.X-anchor.X)>.001f)
                {
                    var fixedLead=WireContactLayout.EntryLead(c.Position,new WirePoint(anchor.X,anchor.Y,.11335f),c.LeadSide,true);
                    return Math.Abs(anchor.Z-.11335f)<1e-6f?fixedLead:fixedLead.Concat(new[]{anchor}).ToArray();
                }
                return WireContactLayout.EntryLead(c.Position,anchor,c.LeadSide);
            }
            var sourceLead=Lead(a,start);
            var targetLead=Lead(b,end);
            // The central route must avoid its own fixed leads, just like other cables.
            // Leave only a small join pocket around each anchor.
            occupied.AddRange(WireBranchJoint.Outside(sourceLead,new WireRect(start.X-.014f,start.X+.014f,start.Y-.014f,start.Y+.014f)));
            occupied.AddRange(WireBranchJoint.Outside(targetLead,new WireRect(end.X-.014f,end.X+.014f,end.Y-.014f,end.Y+.014f)));
            int departure=WireContactLayout.ExitDirection(sourceLead),arrival=WireContactLayout.ExitDirection(targetLead);
            if(arrival>=0)arrival=(arrival+2)%4;
            var middle=simpleOnly?WireLaneRoutes.Find(start,end,blocks,occupied,arrival,departure,door?WireRouting.HalfWidth:routingHalfWidth,routingHalfHeight):WireRouting.Find(start,end,blocks,occupied,joint,arrival,departure,door?WireRouting.HalfWidth:routingHalfWidth,routingHalfHeight,cancellation);
            if(middle==null){failure="No clear route around devices and installed wires.";return null;}
            var path=new List<WirePoint>(sourceLead);
            path.AddRange(middle.Skip(1));path.AddRange(targetLead.Reverse().Skip(1));
            // Check contact leads too; the router only controls the central part.
            var leadReservations=WireModuleSpace.ForLead(reservations,from.Owner==0?(WireRect?)null:a.Bounds,to.Owner==0?(WireRect?)null:b.Bounds);
            var exceptOwn=contacts.Values.Where(c=>Surface(c)==Surface(a)&&!c.End.Equals(from)&&!c.End.Equals(to)&&
                    !(c.End.Owner!=0&&(c.End.Owner==from.Owner||c.End.Owner==to.Owner))).Select(c=>c.Bounds).Concat(rails).Concat(leadReservations).Distinct().ToList();
            Func<WirePoint,WirePoint,bool> clear=(p,q)=>WireRouting.Clear(p,q,exceptOwn,other,joint)&&
                WireBranchJoint.Clear(p,q,shared,fork);
            for(int i=1;i<path.Count;i++)
            {
                if(!clear(path[i-1],path[i])){failure="A contact lead is blocked by another wire or device.";return null;}
            }
            var result=path.Where((p,i)=>i==0||(p-path[i-1]).Squared>1e-12f).ToArray();
            result=WireTube.Clean(result,clear);
            if(result.Length>512){failure="The route is too complex. Move a wire or device first.";return null;}
            if(WireRouting.SelfIntersects(result)){failure="The route would intersect its own contact lead.";return null;}
            // Store the rounded centreline itself: preview, hit testing, saves and
            // subsequent wire clearance all use exactly the rendered route.
            foreach(float cut in new[]{.008f,.006f,.004f})
            {
                var rounded=WireTube.Round(result,cut);
                if(rounded.Length>512||WireRouting.SelfIntersects(rounded))continue;
                bool roundedClear=true;
                for(int i=1;i<rounded.Length;i++)if(!clear(rounded[i-1],rounded[i])){roundedClear=false;break;}
                if(roundedClear)return rounded;
            }
            // A quick lane must not trade smooth bends for a square dogleg.
            // Let the lattice fallback find more room if no fillet fits.
            return simpleOnly?null:result;
        }
    }
}
