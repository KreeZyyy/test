namespace ModularSwitchboards
{
    // Visible F1 help is specific to the selected item; search aliases live separately.
    internal static class SwitchboardDescriptions
    {
        internal static string Get(string name)
        {
            if(name==null)return null;
            if(name==SwitchboardsMod.DoorKitName)return "Fits door modules in 9 positions (3 x 3) on a completed small switchboard. Builds green, blue or white LEDs, a latching TOTAL STOP, or individual bidirectional hinge bridges. Each LED or single bridge uses 1 kit; remove with a Hand Drill. Electronics Printer: 2 g Iron + 1 g Copper. Temporary native Logic Kit model.";
            if(name==SwitchboardsMod.DoorStopName)return "Latching TOTAL STOP for one of the 9 door positions; 1 kit. Normally connects the upper IN to the lower OUT. Press the red mushroom to open the circuit; it stays pressed until you hold the control for 1.2 seconds to twist and reset. Reset reconnects power immediately. Can be used without power, with the door open or closed. Wire the rear through hinge bridges. No overload protection; affects only the circuit routed through it. Remove wires before dismantling with a Hand Drill.";
            if(name==SwitchboardsMod.DoorBridgeName)return "One bidirectional pass-through between the mounting plate and moving door. Place individually in up to 18 positions beside the left hinge; 1 kit per bridge. Either end can be the supply or load side. The two ends are joined, with no prescribed IN/OUT and no connection to other bridges. Remove attached wires before dismantling.";
            if(name==SwitchboardsMod.DoorLabelName)return "Label holder for a door LED or round selector. One editable name line on LEDs; editable name plus fixed 0/I row on round switches. Rename with a Labeller. One label kit; remove the label before dismantling its control.";
            if(name==SwitchboardsMod.DoorRoundSwitchName)return "Compact round manual door selector with a metal bezel and black handle with a light face. Left is 0/OFF; right is I/ON. No overload protection. Rear IN/OUT contacts, one door module kit. Operates without power, with the door open or closed.";
            if(name==SwitchboardsMod.DoorIsolatorName)return "Manual rotary main switch for the cabinet door. 0 disconnects IN from OUT; I connects them. No overload protection. Operates without power, with the door open or closed. Wire rear contacts from inside using Cable Coil and the hinge bridge. One door module kit; remove connected wires before dismantling.";
            if(DoorLedColours.Find(name)!=null)return "Power indicator on the door. Open the cabinet and remove the inner cover to wire IN from the door terminal bridge with Cable Coil. Lights when its IN has an available supply, even without a load or an OUT wire. OUT passes the supply onward. No overload protection. Breaker and fuse OUT contacts accept two wires. Remove with a Hand Drill.";
            if(name==SwitchboardsMod.LabelKitName)return "Builds a label above installed modules on an inner cover. Right-click with the kit and choose a 1-, 2- or 3-module width. Each label costs 1 kit. Rename it with a Labeller; a Hand Drill removes it and returns the kit. Electronics Printer: 1 g Iron.";
            if(name==SwitchboardsMod.LabelName(1)||name==SwitchboardsMod.LabelName(2)||name==SwitchboardsMod.LabelName(3))return "Identifies the modules directly below it. Use a Labeller to set your own text. Mounts only above modules on an installed inner cover. Remove with a Hand Drill to recover 1 kit. Remove labels before removing the cover.";
            if(name==SwitchboardsMod.KitName)
                return "Builds one wall-mounted switchboard. Place the kit, then finish the frame with a Wrench and 2 Plastic Sheets in the other hand. Open the cabinet to add DIN rails, modules and internal wiring; these use separate kits.";
            if(name==SwitchboardsMod.CabinetName)
                return "Houses two DIN rails with 7 module positions each. Open the door to access the modules. Remove the inner cover to wire it: hold Cable Coil and left-click two contacts to connect them; right-click cancels. Route the input through modules to Output 1 or 2. Wire Cutters remove wires.";
            if(name==SwitchboardsMod.RailKitName)
                return "Builds one 8-position DIN rail. Open a finished switchboard, remove its inner cover, then right-click with the kit to place a rail on the upper or lower half of the mounting plate. Each row costs 1 kit.";
            if(name==SwitchboardsMod.RailName)
                return "Holds up to 7 module positions inside a switchboard. Fit modules using Kit (Switchboard Modules). Battery Backup uses 2 positions; Cable Analyzer uses 3. Remove all modules, then use a Hand Drill to recover the rail kit.";
            if(name==SwitchboardsMod.CoverKitName)
                return "Fits one inner cover over the switchboard wiring. Hold the kit, aim inside an open, finished cabinet and hold left click for 2 seconds. The cover fits around installed modules automatically. A Wrench removes it and returns the kit.";
            if(name==SwitchboardsMod.CoverName)
                return "Covers internal wiring while leaving module controls accessible. Use a Wrench to remove it and recover 1 Kit (Switchboard Cover). Remove it before changing wiring, rails or modules; existing wires stay connected.";
            if(name==SwitchboardsMod.BreakerKitName)
                return "Builds modules on an installed DIN rail. Open the cabinet and remove its inner cover; right-click with the kit and use the placement variant selector to choose type and kW rating. Breaker or Fuse Holder: 1 kit; Battery Backup: 2; Cable Analyzer: 3. Wire top inputs and bottom outputs with Cable Coil.";
            if(!DinModuleCatalog.Specs.TryGetValue(name,out var spec))return null;
            if(spec.Analyser)
                return "Shows Actual, Required and Potential power. Fit on a DIN rail (3 positions, 3 module kits). Before a breaker/fuse it reads Input; after protection it reads the wired Output. Direct Input -> Analyzer -> Output reads Output. An unprotected Input-only tap also reads Input. Aim at the display to see which network is measured. Reads the whole network, not one branch.";
            if(spec.Battery)
                return "Stores energy in a removable battery and supplies its wired output when input power is insufficient. Fit on a DIN rail (2 positions, 2 module kits). Connect top IN to the charging supply and bottom OUT to the backed-up output with Cable Coil. Open the cabinet and use the battery slot to insert or swap a battery.";
            string rating=DinModuleCatalog.Rating(spec.Watts);
            if(spec.Fuse)
                return "Protects a circuit up to "+rating+" using a replaceable Cable Fuse. Fit on a DIN rail (1 module kit); wire top IN and bottom OUT with Cable Coil (up to two wires on OUT). Open the cabinet and insert 1 matching "+rating+" Cable Fuse kit into its slot. An overload burns the fuse and cuts power; remove the blown fuse and insert a new one after fixing the overload.";
            return "Switches a circuit on/off and trips OFF when actual power through it exceeds "+rating+". Fit on a DIN rail (1 module kit); wire top IN and bottom OUT with Cable Coil. OUT accepts up to two wires, sharing the same protection rating. Click the lever to switch it. After a trip, reduce the load and switch it ON again; no replacement fuse needed.";
        }
    }
}
