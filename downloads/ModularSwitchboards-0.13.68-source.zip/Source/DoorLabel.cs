using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Serialization;
using Assets.Scripts;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Inventory;
using Assets.Scripts.Localization2;
using Assets.Scripts.Networking;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Items;
using LibConstruct;
using UnityEngine;
namespace ModularSwitchboards
{
    public sealed class DoorLabelSaveData:StructureSaveData
    {
        [XmlElement] public PlacementBoardStructureSaveData Mount;
    }
    public sealed class DoorLabelBoard:PlacementBoard
    {
        public override float GridSize=>DoorModuleLayout.Pitch;
        public override IPlacementBoardStructure EquivalentStructure(Structure structure)
            =>structure is DoorLabel&&PrimaryHost is SwitchboardCabinet host&&host.IsStructureCompleted?structure as IPlacementBoardStructure:null;
    }
    public sealed class DoorLabel:Structure,IPlacementBoardStructure
    {
        public PlacementBoard Board{get;set;}
        public PlacementBoard.BoardCell[] BoardCells{get;set;}
        internal SwitchboardCabinet Host=>Board?.PrimaryHost as SwitchboardCabinet;
        internal static DinBreaker Target(PlacementBoard board,Grid3 p)
        {
            var host=board?.PrimaryHost as SwitchboardCabinet;
            return host?.DoorBoard?.Structures.OfType<DinBreaker>().FirstOrDefault(m=>!m.IsBeingDestroyed&&m.IsStructureCompleted&&!m.IsCursor&&(m.IsDoorLed||m.IsDoorRoundSwitch)&&Same(host.DoorBoard.WorldToGrid(m.transform.position),p));
        }
        private static bool Same(Grid3 a,Grid3 b)=>a.x==b.x&&a.y==b.y&&a.z==b.z;
        internal static bool CanPlace(PlacementBoard board,Grid3 p,int rotation)
            =>board is DoorLabelBoard&&board.PrimaryHost is SwitchboardCabinet host&&host.IsStructureCompleted&&DoorModuleLayout.Fits(p.x,p.y,p.z,rotation)&&Target(board,p)!=null&&!board.Structures.OfType<DoorLabel>().Any(l=>Same(board.WorldToGrid(l.transform.position),p));
        internal static bool Attached(DinBreaker owner)
        {
            var host=CabinetWiring.CabinetOf(owner);var board=host?.DoorLabels;
            if(board==null||owner.Board!=host.DoorBoard)return false;
            var p=owner.Board.WorldToGrid(owner.transform.position);
            return board.Structures.OfType<DoorLabel>().Any(l=>!l.IsBeingDestroyed&&Same(board.WorldToGrid(l.transform.position),p));
        }
        public override void Awake(){base.Awake();BoardStructureHooks.Awake(this);}
        public override Grid3 GetLocalGrid()=>Board==null?default(Grid3):Board.WorldToGrid(Transform.position);
        public override CanConstructInfo CanConstruct()
        {
            if(!(Board is DoorLabelBoard)||(IsCursor&&PlacementBoard.CursorBoard!=Board))return CanConstructInfo.InvalidPlacement("Aim at a door LED or round switch.");
            var p=Board.WorldToGrid(transform.position);
            if(IsCursor){p=new Grid3(DoorModuleLayout.SnapSlot(p.x,-10,10),DoorModuleLayout.SnapSlot(p.y,-10,10),0);PlacementBoard.CursorGrid=p;PlacementBoard.CursorRotation=0;transform.SetPositionAndRotation(Board.GridToWorld(p),Board.IndexToRotation(0));}
            return CanPlace(Board,p,Board.RotationToIndex(transform.rotation))?CanConstructInfo.ValidPlacement:CanConstructInfo.InvalidPlacement("Choose a door LED or round switch without a label.");
        }
        protected override CanConstructInfo CanDeconstruct()=>Host!=null&&Host.IsStructureCompleted?CanConstructInfo.ValidPlacement:CanConstructInfo.InvalidPlacement("Install on a completed cabinet first.");
        public override DelayedActionInstance AttackWith(Attack attack,bool doAction=true)
        {
            if(Host==null||!Host.IsStructureCompleted)return new DelayedActionInstance{Duration=0}.Fail("Install on a completed cabinet first.");
            if(attack.SourceItem is Labeller labeller)
            {
                var result=new DelayedActionInstance{Duration=0,ActionMessage=ActionStrings.Rename};
                if(!labeller.OnOff)return result.Fail(GameStrings.DeviceNotOn);
                if(!labeller.IsOperable)return result.Fail(GameStrings.DeviceNoPower);
                if(doAction)labeller.Rename(this);return result;
            }
            return base.AttackWith(attack,doAction);
        }
        public override void OnDeregistered(){base.OnDeregistered();if(Board!=null)BoardStructureHooks.OnDeregistered(this);}
        public override ThingSaveData SerializeSave(){ThingSaveData data=new DoorLabelSaveData();InitialiseSaveData(ref data);return data;}
        protected override void InitialiseSaveData(ref ThingSaveData data){base.InitialiseSaveData(ref data);if(data is DoorLabelSaveData save&&Board!=null)save.Mount=BoardStructureHooks.SerializeSave(this);}
        public override void DeserializeSave(ThingSaveData data){base.DeserializeSave(data);if(data is DoorLabelSaveData save&&save.Mount!=null)BoardStructureHooks.DeserializeSave(this,save.Mount);}
        public override void SerializeOnJoin(RocketBinaryWriter writer){base.SerializeOnJoin(writer);BoardStructureHooks.SerializeOnJoin(writer,this);}
        public override void DeserializeOnJoin(RocketBinaryReader reader){base.DeserializeOnJoin(reader);BoardStructureHooks.DeserializeOnJoin(reader,this);}
        internal static void SetBounds(DoorLabel label){label.ThingTransform=label.transform;label.Bounds=new Bounds(new Vector3(0,.015f,.001f),new Vector3(.044f,.072f,.006f));label.GridBounds=new GridBounds(label);}
    }
}
