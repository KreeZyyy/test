using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class DoorLabelModel
    {
        internal static Mesh Build()
        {
            var v=new List<Vector3>();var border=new List<int>();var face=new List<int>();
            for(int i=0;i<32;i++)
            {
                float a=i*Mathf.PI/16,b=(i+1)*Mathf.PI/16;
                var ia=new Vector3(.0163f*Mathf.Cos(a),.0163f*Mathf.Sin(a),-.0008f);var ib=new Vector3(.0163f*Mathf.Cos(b),.0163f*Mathf.Sin(b),-.0008f);
                var oa=new Vector3(.020f*Mathf.Cos(a),.020f*Mathf.Sin(a),-.0008f);var ob=new Vector3(.020f*Mathf.Cos(b),.020f*Mathf.Sin(b),-.0008f);
                var iaf=new Vector3(ia.x,ia.y,.0012f);var ibf=new Vector3(ib.x,ib.y,.0012f);var oaf=new Vector3(oa.x,oa.y,.0012f);var obf=new Vector3(ob.x,ob.y,.0012f);
                Quad(v,border,oa,ob,obf,oaf);Quad(v,border,ib,ia,iaf,ibf);Quad(v,border,iaf,oaf,obf,ibf);Quad(v,border,ib,ob,oa,ia);
            }
            DinRailModel.AddBox(v,border,new Vector3(0,.034f,0),new Vector3(.044f,.032f,.003f));
            DinRailModel.AddBox(v,face,new Vector3(0,.034f,.0018f),new Vector3(.039f,.027f,.001f));
            var mesh=new Mesh{name="Door Label holder"};mesh.SetVertices(v);mesh.subMeshCount=5;
            for(int i=0;i<5;i++)mesh.SetTriangles(i==0?border.ToArray():i==1?face.ToArray():new int[0],i);
            mesh.RecalculateNormals();mesh.RecalculateBounds();return mesh;
        }
        private static void Quad(List<Vector3> v,List<int> t,Vector3 a,Vector3 b,Vector3 c,Vector3 d){int p=v.Count;v.AddRange(new[]{a,b,c,d});t.AddRange(new[]{p,p+1,p+2,p,p+2,p+3});}
    }
    public sealed class DoorLabelView:MonoBehaviour
    {
        private DoorLabel owner;private TextMesh nameText,row;private MeshRenderer surface;
        private void Bind(){owner=GetComponent<DoorLabel>();nameText=transform.Find("DoorLabelName")?.GetComponent<TextMesh>();row=transform.Find("DoorLabelPositions")?.GetComponent<TextMesh>();surface=transform.Find("InnerCoverModel")?.GetComponent<MeshRenderer>();}
        private void LateUpdate()
        {
            if(owner==null||owner.gameObject!=gameObject||nameText==null||row==null)Bind();
            if(owner==null||nameText==null||row==null)return;
            bool selector=DoorLabel.Target(owner.Board,owner.GetLocalGrid())?.IsDoorRoundSwitch==true;
            string value=owner.CustomName;if(string.IsNullOrWhiteSpace(value)||value=="Door Label")value="LABEL";
            value=value.Replace('\r',' ').Replace('\n',' ');var info=new System.Globalization.StringInfo(value);if(info.LengthInTextElements>48)value=info.SubstringByTextElements(0,47)+"…";
            nameText.transform.localPosition=new Vector3(0,selector ? .041f : .034f,.0032f);nameText.text=value;Fit(nameText,.034f,selector ? .010f : .017f);
            row.gameObject.SetActive(selector);row.text="0          I";Fit(row,.033f,.0075f);
            if(surface!=null)SwitchboardLabelSurface.Apply(surface);
        }
        private static void Fit(TextMesh text,float width,float height)
        {
            text.transform.localScale=Vector3.one;var size=text.GetComponent<MeshRenderer>().localBounds.size;
            text.transform.localScale=Vector3.one*Mathf.Min(1f,Mathf.Min(width/Mathf.Max(.0001f,size.x),height/Mathf.Max(.0001f,size.y)));DepthLabelText.Apply(text);
        }
        internal static void Install(DoorLabel label)
        {
            Font font=null;foreach(var name in new[]{"LegacyRuntime.ttf","Arial.ttf"}){try{font=Resources.GetBuiltinResource<Font>(name);}catch(Exception){}if(font!=null)break;}
            if(font==null)font=Resources.FindObjectsOfTypeAll<Font>().FirstOrDefault();if(font==null)throw new InvalidOperationException("Door label font unavailable.");
            foreach(var part in new[]{"DoorLabelName","DoorLabelPositions"})
            {
                var go=new GameObject(part){layer=label.gameObject.layer};go.transform.SetParent(label.transform,false);go.transform.localPosition=new Vector3(0,part=="DoorLabelName" ? .034f : .026f,.0032f);go.transform.localRotation=Quaternion.Euler(0,180,0);
                var text=go.AddComponent<TextMesh>();text.font=font;text.fontSize=64;text.characterSize=.01f;text.anchor=TextAnchor.MiddleCenter;text.alignment=TextAlignment.Center;text.richText=false;text.color=Color.black;text.text=part=="DoorLabelName"?"LABEL":"0          I";DepthLabelText.Apply(text);
            }
            label.gameObject.AddComponent<DoorLabelView>();
        }
    }
}
