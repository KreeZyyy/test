from pathlib import Path
p=Path(__file__).resolve().parents[2]
s=(p/'Source/DoorLabel.cs').read_text();a=s.index('        internal static DinBreaker Target');b=s.index('        public override void Awake',a)
(Path(__file__).parent/'Policy.cs').write_text('using System;using System.Linq;using Assets.Scripts.GridSystem;using LibConstruct; namespace ModularSwitchboards{public partial class DoorLabel{'+s[a:b]+'}}')
s=(p/'Source/DoorLabelModel.cs').read_text();s=s[:s.index('    public sealed class DoorLabelView')]+ '}\n';(Path(__file__).parent/'Geometry.cs').write_text(s)
s=(p/'Source/DinRailModel.cs').read_text();a=s.index('        internal static void AddBox');b=s.index('        internal static void Install',a)
(Path(__file__).parent/'Box.cs').write_text('using System.Collections.Generic;using UnityEngine;namespace ModularSwitchboards{static class DinRailModel{'+s[a:b]+'}}')
s=(p/'Source/DoorModuleLayout.cs').read_text();a=s.index('        internal const float GridOffsetY');b=s.index('        internal static WireRect HarnessWindow',a)
(Path(__file__).parent/'Layout.cs').write_text('using System;namespace ModularSwitchboards{static class DoorModuleLayout{'+s[a:b]+'}}')
