using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class DoorLabelModel
    {
        internal static Mesh Build()
        {
            var v=new List<Vector3>();var border=new List<int>();var face=new List<int>();
            for(int i=0;i<32;i++)
            {
                float a=i*Mathf.PI/16,b=(i+1)*Mathf.PI/16;
                var ia=new Vector3(.0163f*Mathf.Cos(a),.0163f*Mathf.Sin(a),-.0008f);var ib=new Vector3(.0163f*Mathf.Cos(b),.0163f*Mathf.Sin(b),-.0008f);
                var oa=new Vector3(.020f*Mathf.Cos(a),.020f*Mathf.Sin(a),-.0008f);var ob=new Vector3(.020f*Mathf.Cos(b),.020f*Mathf.Sin(b),-.0008f);
                var iaf=new Vector3(ia.x,ia.y,.0012f);var ibf=new Vector3(ib.x,ib.y,.0012f);var oaf=new Vector3(oa.x,oa.y,.0012f);var obf=new Vector3(ob.x,ob.y,.0012f);
                Quad(v,border,oa,ob,obf,oaf);Quad(v,border,ib,ia,iaf,ibf);Quad(v,border,iaf,oaf,obf,ibf);Quad(v,border,ib,ob,oa,ia);
            }
            DinRailModel.AddBox(v,border,new Vector3(0,.034f,0),new Vector3(.044f,.032f,.003f));
            DinRailModel.AddBox(v,face,new Vector3(0,.034f,.0018f),new Vector3(.039f,.027f,.001f));
            var mesh=new Mesh{name="Door Label holder"};mesh.SetVertices(v);mesh.subMeshCount=5;
            for(int i=0;i<5;i++)mesh.SetTriangles(i==0?border.ToArray():i==1?face.ToArray():new int[0],i);
            mesh.RecalculateNormals();mesh.RecalculateBounds();return mesh;
        }
        private static void Quad(List<Vector3> v,List<int> t,Vector3 a,Vector3 b,Vector3 c,Vector3 d){int p=v.Count;v.AddRange(new[]{a,b,c,d});t.AddRange(new[]{p,p+1,p+2,p,p+2,p+3});}
    }
}
