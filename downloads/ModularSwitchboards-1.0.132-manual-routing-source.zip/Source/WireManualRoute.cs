using System;
using System.Collections.Generic;
using System.Linq;
namespace ModularSwitchboards
{
    // Manual XY path with a raised, continuous centreline at projected crossings.
    // Every segment is subsequently checked by the planner's normal 3D clearance rules.
    internal static class WireManualRoute
    {
        internal const int MaxPoints=8;
        internal static WirePoint[] Find(WirePoint start,WirePoint end,IList<WirePoint> points,IList<WireRect> blocks,IList<WirePoint[]> occupied,float halfWidth,float halfHeight,float maxDepth)
        {
            if(points==null||points.Count==0||points.Count>MaxPoints)return null;
            var anchors=new List<WirePoint>{start};
            foreach(var p in points)
            {
                if(float.IsNaN(p.X)||float.IsInfinity(p.X)||float.IsNaN(p.Y)||float.IsInfinity(p.Y)||Math.Abs(p.X)>halfWidth||Math.Abs(p.Y)>halfHeight)return null;
                anchors.Add(new WirePoint(p.X,p.Y,start.Z));
            }
            anchors.Add(end);var result=new List<WirePoint>{start};
            float gap=WireRouting.Clearance+.002f;
            for(int i=1;i<anchors.Count;i++)
            {
                var a=anchors[i-1];var b=anchors[i];float length=(float)Math.Sqrt((b-a).Squared);
                if(length<.004f)return null;
                if(blocks.Any(r=>WireRouting.SegmentHitsRect(a,b,r,WireRouting.Radius+.001f)))return null;
                int steps=Math.Max(1,(int)Math.Ceiling(length/.003f));if(result.Count+steps>480)return null;
                for(int j=1;j<=steps;j++)
                {
                    var p=a+(b-a)*(j/(float)steps);float z=start.Z;
                    foreach(var wire in occupied)for(int k=1;k<wire.Length;k++)
                    {
                        var c=wire[k-1];var d=wire[k];var xy=new WirePoint(p.X,p.Y,0);var u=new WirePoint(c.X,c.Y,0);var v=new WirePoint(d.X,d.Y,0);
                        float distance=(float)Math.Sqrt(WireRouting.SegmentDistanceSquared(xy,xy,u,v));
                        float influence=gap+.020f;if(distance>=influence)continue;
                        float top=Math.Max(c.Z,d.Z)+gap;if(top<=start.Z)continue;
                        float t=Math.Max(0,Math.Min(1,(influence-distance)/.020f));float blend=t*t*(3-2*t);
                        z=Math.Max(z,start.Z+(top-start.Z)*blend);
                    }
                    if(z>maxDepth)return null;
                    // Contact anchors cannot move: retain the native terminal leads.
                    if(i==anchors.Count-1&&j==steps)p=end;else p.Z=z;
                    result.Add(p);
                }
            }
            // Reject blocked hops (including parallel stacking and steep transitions).
            for(int i=1;i<result.Count;i++)if(!WireRouting.Clear(result[i-1],result[i],blocks,occupied,false))return null;
            if(WireRouting.SelfIntersects(result.ToArray()))return null;
            return result.ToArray();
        }
    }
}
