using System;
using System.Collections.Generic;
using Assets.Scripts;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Items;
using Assets.Scripts.Objects.Motherboards;
using UnityEngine;
namespace ModularSwitchboards
{
    public sealed partial class CabinetWiring
    {
        private readonly List<GameObject> routePointMarkers=new List<GameObject>();
        private bool TryRoutePoint(Attack attack,long actor,bool doAction,Thing.DelayedActionInstance result)
        {
            if(!pending.TryGetValue(actor,out var selected)||!contacts.TryGetValue(selected,out var contact))
            {result.Fail("Choose a highlighted contact first. Right click cancels.");return true;}
            if(!WireEndpointReady(selected)){result.Fail("Complete the selected module first.");return true;}
            var local=Frame(contact).InverseTransformPoint(attack.Position);
            float width=contact.Door?WireRouting.HalfWidth:routingHalfWidth;
            if(float.IsNaN(local.x)||float.IsInfinity(local.x)||float.IsNaN(local.y)||float.IsInfinity(local.y)||Math.Abs(local.x)>width||Math.Abs(local.y)>routingHalfHeight||local.z<-.003f||local.z>.16f)
            {result.Fail("Choose a routing point on the same cabinet panel.");return true;}
            pendingPoints.TryGetValue(actor,out var points);
            int count=points?.Count??0;
            if(count>=WireManualRoute.MaxPoints){result.Fail("Routing point limit reached. Choose the destination contact or right click to cancel.");return true;}
            var point=new WirePoint(local.x,local.y,0);
            if(count>0&&(point-points[count-1]).Squared<.000144f){result.Fail("Move the next routing point farther away.");return true;}
            var blocks=contact.Door?DoorModuleLayout.Reservations(Owner.PrefabName):moduleReservations;
            foreach(var block in blocks)if(block.Contains(point,WireRouting.Radius+.001f)){result.Fail("Routing points must stay clear of module spaces.");return true;}
            foreach(var c in contacts.Values)if(c.Door==contact.Door&&c.Leaf==contact.Leaf&&c.Bounds.Contains(point,WireRouting.Radius+.001f))
            {result.Fail("Choose free space between modules and contacts.");return true;}
            result.ActionMessage="Add cable routing point ("+(count+1)+"/"+WireManualRoute.MaxPoints+")";
            result.AppendStateMessage("Click the destination contact to finish. Right click cancels the whole route.");
            if(doAction&&GameManager.RunSimulation)
            {
                if(points==null){points=new List<WirePoint>();pendingPoints[actor]=points;}
                points.Add(point);pendingUntil[actor]=Time.unscaledTime+60;
                revision++;routeRevision=-1;previewRouteJob.Cancel();Owner.NetworkUpdateFlags|=UpdateFlag;
            }
            return true;
        }
        private void ShowRoutePoints(long actor,bool show)
        {
            List<WirePoint> points=null;Contact contact=null;
            if(show&&pending.TryGetValue(actor,out var selected)&&contacts.TryGetValue(selected,out contact))pendingPoints.TryGetValue(actor,out points);
            int count=points?.Count??0;
            for(int i=0;i<routePointMarkers.Count;i++)routePointMarkers[i].SetActive(i<count);
            for(int i=0;i<count;i++)
            {
                if(i>=routePointMarkers.Count)
                {
                    var marker=GameObject.CreatePrimitive(PrimitiveType.Sphere);marker.name="WireContact";marker.layer=Owner.gameObject.layer;
                    var collider=marker.GetComponent<Collider>();if(collider!=null){collider.enabled=false;UnityEngine.Object.Destroy(collider);}
                    marker.GetComponent<MeshRenderer>().sharedMaterial=CabinetGeometry.Materials[3];Color(marker.GetComponent<MeshRenderer>(),ColorType.Yellow);routePointMarkers.Add(marker);
                }
                var item=routePointMarkers[i];item.transform.SetParent(Frame(contact),false);item.transform.localPosition=new Vector3(points[i].X,points[i].Y,contact.Door?.063f:WireRouting.Plane);item.transform.localScale=Vector3.one*.007f;item.SetActive(true);
            }
        }
        private void ClearRoutePoints(){foreach(var marker in routePointMarkers)if(marker!=null)UnityEngine.Object.Destroy(marker);routePointMarkers.Clear();}
    }
}
