using System;using System.Collections.Generic;using System.Linq;using ModularSwitchboards;
class Program{
 static int checks;static void Check(bool c,string m){checks++;if(!c)throw new Exception(m);}
 static void Main(){
 foreach(float radius in new[]{.0012f,.0022f,.004f})foreach(float oldRadius in new[]{.0012f,.0022f,.004f})foreach(float depth in new[]{.0266f,.0357f,.0448f,.0539f,.063f,.06535f,.08135f,.09735f}){
 using(WireRouting.ForWire(radius,oldRadius)){
 var a=new WirePoint(-.12f,0,depth);var b=new WirePoint(.12f,0,depth);var old=new[]{new WirePoint(0,-.1f,depth),new WirePoint(0,.1f,depth)};var occupied=new List<WirePoint[]>{old};var blocks=new List<WireRect>();
 var p=WireManualRoute.Find(a,b,new[]{new WirePoint(-.06f,0,0)},blocks,occupied,.17f,.22f,.14f);
 Check(p!=null,"crossing route exists");Check((p[0]-a).Squared<1e-12&&(p[^1]-b).Squared<1e-12,"native anchors remain exact");Check(p.Max(q=>q.Z)>depth+radius+oldRadius,"visible raised crossing");Check(p.Length<=512,"save path bound");
 for(int j=1;j<p.Length;j++)Check(WireRouting.Clear(p[j-1],p[j],blocks,occupied,false),"every stored segment clears existing cable");
 Check(!WireRouting.SelfIntersects(p),"no self intersection");Check(old[0].Z==depth&&old[1].Z==depth,"existing wire unchanged");
 Check(WireManualRoute.Find(a,b,new[]{new WirePoint(0,0,0)},new[]{new WireRect(-.02f,.02f,-.02f,.02f)},occupied,.17f,.22f,.14f)==null,"cannot cross module");
 Check(WireManualRoute.Find(a,b,new[]{new WirePoint(0,0,0)},blocks,occupied,.17f,.22f,depth+.001f)==null,"cannot exceed enclosure depth");
 }}
 var start=new WirePoint(-.1f,-.1f,.06535f);var end=new WirePoint(.1f,.1f,.06535f);var way=new[]{new WirePoint(-.1f,.1f,0)};var route=WireManualRoute.Find(start,end,way,new List<WireRect>(),new List<WirePoint[]>(),.17f,.22f,.14f);Check(route!=null&&route.Any(p=>Math.Abs(p.X+.1f)<.0001f&&Math.Abs(p.Y-.1f)<.0001f),"manual bend retained");
 Check(WireManualRoute.Find(start,end,new[]{new WirePoint(float.NaN,0,0)},new List<WireRect>(),new List<WirePoint[]>(),.17f,.22f,.14f)==null,"NaN rejected");
 Check(WireManualRoute.Find(start,end,new[]{new WirePoint(.5f,0,0)},new List<WireRect>(),new List<WirePoint[]>(),.17f,.22f,.14f)==null,"outside panel rejected");
 Check(WireManualRoute.Find(start,end,Enumerable.Repeat(new WirePoint(0,0,0),9).ToArray(),new List<WireRect>(),new List<WirePoint[]>(),.17f,.22f,.14f)==null,"point limit enforced");Console.WriteLine("Manual route geometry: "+checks+" checks passed.");}}
