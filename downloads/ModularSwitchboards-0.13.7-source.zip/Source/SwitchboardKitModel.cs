using System.Collections.Generic;
using System.Linq;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Motherboards;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class SwitchboardKitModel
    {
        internal static bool IsKit(Thing thing)=>thing is MultiConstructor&&(thing.PrefabName==SwitchboardsMod.KitName||thing.PrefabName==SwitchboardsMod.RailKitName||thing.PrefabName==SwitchboardsMod.BreakerKitName||thing.PrefabName==SwitchboardsMod.CoverKitName);
        internal static void Install(MultiConstructor kit,SwitchboardKitKind kind)
        {
            var original=kit.Bounds;
            if(original.size.x<.001f||original.size.y<.001f||original.size.z<.001f)
            {
                bool first=true;
                foreach(var filter in kit.GetComponentsInChildren<MeshFilter>(true))
                {
                    if(filter.sharedMesh==null)continue;
                    var b=CabinetWallMount.TransformedBounds(filter.sharedMesh.bounds,kit.transform.worldToLocalMatrix*filter.transform.localToWorldMatrix);
                    if(first){original=b;first=false;}else original.Encapsulate(b);
                }
            }
            if(original.size.x<=0||original.size.y<=0||original.size.z<=0)throw new System.InvalidOperationException("Kit visual bounds unavailable: "+kit.PrefabName);
            foreach(var lod in kit.GetComponentsInChildren<LODGroup>(true))Object.DestroyImmediate(lod);
            foreach(var renderer in kit.GetComponentsInChildren<MeshRenderer>(true))Object.DestroyImmediate(renderer);
            bool frame=kind==SwitchboardKitKind.Cabinet;
            var shell=SwitchboardKitMesh.Load(frame);
            var contents=frame?null:SwitchboardKitGeometry.Build(kind);
            var bounds=shell.bounds;if(contents!=null)bounds.Encapsulate(contents.bounds);
            float fit=SwitchboardKitGeometry.Fit(original.size,bounds.size);
            var root=new GameObject("SwitchboardKitVisual"){layer=kit.gameObject.layer};root.transform.SetParent(kit.transform,false);
            root.transform.localScale=Vector3.one*fit;root.transform.localPosition=original.center-bounds.center*fit;
            var native=new GameObject(frame?"SwitchboardKitFrame":"SwitchboardKitCrate"){layer=kit.gameObject.layer};native.transform.SetParent(root.transform,false);
            native.AddComponent<MeshFilter>().sharedMesh=shell;
            SwitchboardKitSurface.Apply(native.AddComponent<MeshRenderer>(),frame);
            if(contents!=null)
            {
                var model=new GameObject("SwitchboardKitModel"){layer=kit.gameObject.layer};model.transform.SetParent(root.transform,false);
                model.AddComponent<MeshFilter>().sharedMesh=contents;SwitchboardKitSurface.ApplyContents(model.AddComponent<MeshRenderer>());
            }
            kit.Renderers=root.GetComponentsInChildren<MeshRenderer>(true).Select(r=>new ThingRenderer(kit,r)).ToList();
            kit.PaintableMaterial=null;kit.HasColorState=false;
            kit.Thumbnail=CabinetIcons.Get("Kit"+kind);kit.Thumbnails=new Sprite[0];
            // Native kit identity, hand poses, stack behaviour, rigidbody and
            // collision envelope remain intact. Only the fitted visual is replaced.
            Refresh(kit);
        }
        internal static void Refresh(Thing kit)
        {
            foreach(var renderer in kit.GetComponentsInChildren<MeshRenderer>(true))
            {
                if(renderer.name=="SwitchboardKitCrate"||renderer.name=="SwitchboardKitFrame")
                {SwitchboardKitSurface.Apply(renderer,renderer.name=="SwitchboardKitFrame");continue;}
                if(renderer.name!="SwitchboardKitModel")continue;
                SwitchboardKitSurface.ApplyContents(renderer);
            }
        }
    }
}
