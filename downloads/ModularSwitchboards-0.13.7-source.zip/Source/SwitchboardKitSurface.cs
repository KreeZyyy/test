using System;
using System.IO;
using UnityEngine;
namespace ModularSwitchboards
{
    // Private mod-owned textures/materials. Never reads a Console prefab or
    // borrows its Material, Texture or MaterialPropertyBlock instances.
    internal static class SwitchboardKitSurface
    {
        private static Material[] crate,frame,contents;
        private static Texture2D surface,panel;
        private static Shader shader;
        private static Material Create(string name,Texture texture,Color color,float gloss)
        {
            if(shader==null){shader=Shader.Find("Standard");if(shader==null||!shader.isSupported)shader=Shader.Find("StandardInstanced");}
            if(shader==null||!shader.isSupported)throw new InvalidOperationException("Standard surface shader unavailable for switchboard kits");
            var material=new Material(shader){name="Switchboards.Kit."+name,color=color,mainTexture=texture};
            material.SetFloat("_Glossiness",gloss);material.SetFloat("_Metallic",0f);
            material.SetColor("_EmissionColor",Color.black);return material;
        }
        private static Texture2D Texture(string name)
        {
            using(var stream=typeof(SwitchboardKitSurface).Assembly.GetManifestResourceStream("ModularSwitchboards.KitTextures."+name+".png"))
            {
                if(stream==null)throw new InvalidDataException("Missing bundled kit texture: "+name);
                using(var bytes=new MemoryStream())
                {
                    stream.CopyTo(bytes);var texture=new Texture2D(2,2,TextureFormat.RGBA32,true,false){name="Switchboards.Kit."+name};
                    if(!ImageConversion.LoadImage(texture,bytes.ToArray(),true)){UnityEngine.Object.Destroy(texture);throw new InvalidDataException("Invalid bundled kit texture: "+name);}
                    texture.wrapMode=TextureWrapMode.Repeat;texture.filterMode=FilterMode.Bilinear;return texture;
                }
            }
        }
        private static void Ensure()
        {
            if(crate!=null)return;
            surface=Texture("KitSurface");panel=Texture("KitFramePanel");
            var exterior=Create("Exterior",surface,Color.white,.5f);
            crate=new[]{exterior};frame=new[]{exterior,Create("FramePanel",panel,Color.white,0f)};
            contents=new[]{Create("Black",null,new Color(.018f,.024f,.025f),.35f),Create("White",null,new Color(.78f,.81f,.80f),.35f),Create("Insert",null,new Color(.78f,.81f,.80f),.35f),Create("Dark",null,new Color(.018f,.024f,.025f),.35f),Create("Metal",null,new Color(.31f,.36f,.36f),.35f)};
        }
        private static void Assign(MeshRenderer renderer,Material[] materials)
        {
            renderer.SetPropertyBlock(null);
            for(int i=0;i<renderer.sharedMaterials.Length;i++)renderer.SetPropertyBlock(null,i);
            renderer.sharedMaterials=materials;
        }
        internal static void Apply(MeshRenderer renderer,bool isFrame){Ensure();Assign(renderer,isFrame?frame:crate);}
        internal static void ApplyContents(MeshRenderer renderer){Ensure();Assign(renderer,contents);}
    }
}
