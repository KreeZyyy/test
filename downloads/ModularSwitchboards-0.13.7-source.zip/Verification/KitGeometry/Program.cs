using System;using System.Linq;using System.Collections.Generic;using System.IO;using System.Text.Json;using ModularSwitchboards;using UnityEngine;
class Program{
 static int checks;static void Check(bool ok,string message){checks++;if(!ok)throw new Exception(message);}
 static void Main(){
 var exports=new Dictionary<string,object>();
 foreach(SwitchboardKitKind kind in Enum.GetValues<SwitchboardKitKind>()){
 var shell=SwitchboardKitMesh.Load(kind==SwitchboardKitKind.Cabinet);
 Check(shell.T.Values.Sum(t=>t.Length)==(kind==SwitchboardKitKind.Cabinet?3226:760)*3,"Native topology changed");
 Check(shell.UV.Count==shell.V.Count,"Original native UVs missing");
 var mesh=SwitchboardKitGeometry.Build(kind);Check(mesh.V.Count<65536,"Kit contents exceed 16-bit mesh index capacity");
 if(kind!=SwitchboardKitKind.Cabinet){
 Check(mesh.V.Count>100&&mesh.N.Count==mesh.V.Count,"Missing kit contents");
 foreach(var v in mesh.V)Check(Math.Abs(v.x)<.235f&&Math.Abs(v.z)<.235f&&v.y>=.055f&&v.y<=.380f,"Contents intersect native crate walls/bottom");
 }
 var points=shell.V.Concat(mesh.V).ToArray();
 var min=new Vector3(points.Min(p=>p.x),points.Min(p=>p.y),points.Min(p=>p.z));var max=new Vector3(points.Max(p=>p.x),points.Max(p=>p.y),points.Max(p=>p.z));var size=max-min;var center=(max+min)*.5f;
 foreach(var part in new[]{shell,mesh})foreach(var ts in part.T.Values)foreach(int i in ts)Check(i>=0&&i<part.V.Count,"Invalid kit index");
 foreach(var envelope in new[]{new Vector3(.3f,.2f,.2f),new Vector3(.1f,.3f,.2f),new Vector3(.4f,.12f,.18f)}){
 float fit=SwitchboardKitGeometry.Fit(envelope,size);
 foreach(var v in points){var q=(v-center)*fit;Check(Math.Abs(q.x)<=envelope.x*.461f&&Math.Abs(q.y)<=envelope.y*.461f&&Math.Abs(q.z)<=envelope.z*.461f,"Native kit exceeds collision envelope");}
 }
 exports[kind.ToString()]=new{vertices=mesh.V.Select(v=>new[]{v.x,v.y,v.z}),triangles=mesh.T};
 }
 if(Environment.GetEnvironmentVariable("KIT_GEOMETRY_EXPORT")is string path)File.WriteAllText(path,JsonSerializer.Serialize(exports));
 Console.WriteLine($"Native kit geometry: {checks} checks passed; original crate/frame topology and UV streams, production module/rail contents, crate clearance, native collision-envelope fitting.");
 }
}
