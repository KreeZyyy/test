using System;using System.Collections.Generic;using ModularSwitchboards;using UnityEngine;
namespace UnityEngine{
 public class Object{public static void Destroy(object o){}}
 public class Texture{public string name;}
 public class Texture2D:Texture{public TextureWrapMode wrapMode;public FilterMode filterMode;public bool Loaded;public Texture2D(int w,int h,TextureFormat f,bool mip,bool linear){}}
 public enum TextureWrapMode{Repeat}public enum FilterMode{Bilinear}public enum TextureFormat{RGBA32}
 public struct Color{public float r,g,b,a;public Color(float r,float g,float b,float a=1){this.r=r;this.g=g;this.b=b;this.a=a;}public static Color white=>new(1,1,1);public static Color black=>new(0,0,0);}
 public static class ImageConversion{public static int Loads;public static bool LoadImage(Texture2D t,byte[] b,bool nonReadable){Loads++;t.Loaded=b.Length>100&&b[0]==137&&b[1]==80&&b[2]==78&&b[3]==71;return t.Loaded;}}
 public class Shader{public static string Mode;public bool isSupported;public string name;public static Shader Find(string n){if(Mode=="missing")return null;if(n=="Standard"&&Mode=="fallback")return new(){name=n,isSupported=false};return new(){name=n,isSupported=true};}}
 public class Material{public string name;public Color color;public Texture mainTexture;public Shader shader;public Dictionary<string,float> Floats=new();public Material(Shader shader){this.shader=shader;}public void SetFloat(string n,float v)=>Floats[n]=v;public void SetColor(string n,Color c){}}
 public class MeshRenderer{public Material[] sharedMaterials=Array.Empty<Material>();public Dictionary<int,object> Blocks=new();public void SetPropertyBlock(object b){if(b==null)Blocks.Remove(-1);else Blocks[-1]=b;}public void SetPropertyBlock(object b,int i){if(b==null)Blocks.Remove(i);else Blocks[i]=b;}}
}
class Program{
 static int checks;static void Check(bool ok,string m){checks++;if(!ok)throw new Exception(m);}
 static void Main(string[] args){Shader.Mode=args.Length==0?"standard":args[0];
 var old=new Material(new Shader()){name="ExternalMaterial",mainTexture=new Texture(){name="ExternalTexture"}};
 var crate=new MeshRenderer{sharedMaterials=new[]{old,old,old}};crate.Blocks[-1]=new();crate.Blocks[0]=new();crate.Blocks[2]=new();
 if(Shader.Mode=="missing"){
 bool rejected=false;try{SwitchboardKitSurface.Apply(crate,false);}catch(InvalidOperationException){rejected=true;}
 Check(rejected,"Missing shader not rejected");Console.WriteLine("Kit surface missing-shader guard passed");return;}
 SwitchboardKitSurface.Apply(crate,false);Check(crate.Blocks.Count==0,"Inherited property blocks retained");Check(crate.sharedMaterials.Length==1,"Wrong crate slots");Check(crate.sharedMaterials[0]!=old,"Borrowed external material");Check(crate.sharedMaterials[0].mainTexture!=old.mainTexture,"Borrowed external texture");Check(((Texture2D)crate.sharedMaterials[0].mainTexture).Loaded,"Bundled PNG not read");
 var frame=new MeshRenderer();SwitchboardKitSurface.Apply(frame,true);Check(frame.sharedMaterials.Length==2,"Missing frame panel");Check(frame.sharedMaterials[0]==crate.sharedMaterials[0],"Private exterior cache missing");Check(frame.sharedMaterials[1].mainTexture!=frame.sharedMaterials[0].mainTexture,"Panel texture not separate");Check(frame.sharedMaterials[1].Floats["_Glossiness"]==0,"Panel surface preset wrong");
 var contents=new MeshRenderer();SwitchboardKitSurface.ApplyContents(contents);Check(contents.sharedMaterials.Length==5,"Contents role materials missing");foreach(var m in contents.sharedMaterials){Check(m!=old&&m.mainTexture==null,"Contents borrowed source material/texture");Check(m.shader.isSupported,"Unsupported shader retained");}
 SwitchboardKitSurface.Apply(crate,false);Check(ImageConversion.Loads==2,"Textures loaded repeatedly");Check(crate.sharedMaterials[0].shader.name==(Shader.Mode=="fallback"?"StandardInstanced":"Standard"),"Shader fallback failed");
 Console.WriteLine($"Independent kit surfaces: {checks} checks passed ({Shader.Mode}); own resources/materials, property-block isolation, texture cache, shader selection. No game prefab API available in this harness.");
 }
}
