using System;
using System.Runtime.CompilerServices;
using System.Text;
using Assets.Scripts;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Items;
using Assets.Scripts.Objects.Pipes;
using Assets.Scripts.Objects.Motherboards;
namespace ModularSwitchboards
{
    // DIN power modules deliberately remain passive Structures. The configuration
    // cartridge normally only accepts Device, so adapt this readout at the UI edge
    // without registering another powered device or a synthetic cable network.
    internal static class DinAnalyserTablet
    {
        private sealed class Selection{internal long Id;}
        private static readonly ConditionalWeakTable<ConfigCartridge,Selection> Selections=new ConditionalWeakTable<ConfigCartridge,Selection>();
        internal static bool BeforeRead(ConfigCartridge __instance,ref string ____selectedText,ref string ____outputText,ref bool ____needTopScroll,
            ref Device ____scannedDevice,ref Device ____lastScannedDevice)
        {
            var selection=Selections.GetValue(__instance,_=>new Selection());
            if(!__instance.RootParent||!__instance.RootParent.HasAuthority||!(CursorManager.CursorThing is DinBreaker module)||!module.IsAnalyserModule||module.IsCursor||module.IsBeingDestroyed)
            {selection.Id=0;return true;}
            var text=Text(module);
            var sync=____outputText??string.Empty;
            lock(sync)
            {
                if(selection.Id!=module.ReferenceId)____needTopScroll=true;
                selection.Id=module.ReferenceId;
                ____scannedDevice=null;____lastScannedDevice=null;
                ____selectedText=module.DisplayName.ToUpper();____outputText=text;
            }
            return false;
        }
        internal static string Text(DinBreaker module)
        {
            var network=CabinetWiring.CabinetOf(module)?.Wiring.AnalysedNetwork(module,out _,out _);
            var text=new StringBuilder();
            text.Append("ReferenceId ... ");text.AppendFormat("<color=#20B2AA>${0}</color>",module.ReferenceId.ToString("X"));
            Append(text,LogicType.PowerActual,network?.CurrentLoad??0);
            Append(text,LogicType.PowerPotential,network?.PotentialLoad??0);
            Append(text,LogicType.PowerRequired,network?.RequiredLoad??0);
            return text.ToString();
        }
        private static void Append(StringBuilder text,LogicType type,double value)
        {
            text.Append('\n');text.Append(type);text.Append(" ... <color=green>");
            text.Append(Math.Round(value,3,MidpointRounding.AwayFromZero));text.Append("</color>");
        }
    }
}
