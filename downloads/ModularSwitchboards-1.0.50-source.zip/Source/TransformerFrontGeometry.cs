using System;
using System.Collections.Generic;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class TransformerFrontGeometry
    {
        internal const float KnobRadius=.010f,KnobDepth=.005284f;
        internal static readonly Vector3 KnobCenter=new Vector3(TransformerPanelLayout.CenterX,.0185f,.080683f);
        internal static readonly Bounds Pocket=new Bounds(new Vector3(TransformerPanelLayout.CenterX,-.0125f,.0818f),new Vector3(.057f,.0324f,.037f));
        internal static readonly Bounds LeftPocket=new Bounds(new Vector3(.10125f,0,.071f),new Vector3(.030f,.066f,.018f));
        internal static Mesh Body(int slots=DinTransformer.SlotCount)
        {
            var s=DinBreakerModel.VisualScale;
            var hole=new Bounds(new Vector3(Pocket.center.x/s.x,Pocket.center.y/s.y,Pocket.center.z/s.z),new Vector3(Pocket.size.x/s.x,Pocket.size.y/s.y,Pocket.size.z/s.z));
            var body=TransformerPanelLayout.Body(slots);
            // Replace the original dark fascia with one shared inset gray face.
            // Keep terminal slots; only the front fascia lies beyond local z .0629.
            var vertices=body.vertices;var dark=body.GetTriangles(3);var kept=new List<int>();
            for(int i=0;i<dark.Length;i+=3)
                if(!(vertices[dark[i]].z>.0629f&&vertices[dark[i+1]].z>.0629f&&vertices[dark[i+2]].z>.0629f))
                    kept.AddRange(new[]{dark[i],dark[i+1],dark[i+2]});
            body.SetTriangles(kept,3);body=TransformerCasePocket.Cut(body,hole);
            if(slots>=4){var p=LeftPocket;body=TransformerCasePocket.Cut(body,new Bounds(new Vector3(p.center.x/s.x,p.center.y/s.y,p.center.z/s.z),new Vector3(p.size.x/s.x,p.size.y/s.y,p.size.z/s.z)));}
            return body;
        }
        internal static Mesh Face(int slots=DinTransformer.SlotCount)
        {
            var v=new List<Vector3>();var n=new List<Vector3>();var t=new List<int>[5];for(int i=0;i<t.Length;i++)t[i]=new List<int>();
            float x=TransformerPanelLayout.CenterX;
            RoundedGeometry.Box(v,n,t[0],new Vector3(TransformerPanelLayout.PortCenterX(slots),0,.0727f),new Vector3(TransformerPanelLayout.WidthFor(slots)*DinBreakerModel.VisualScale.x-.010f,.068f,.0018f),.0013f);
            var mesh=new Mesh{name="Switchboards.TransformerOwnMountingPlate"};mesh.SetVertices(v);mesh.SetNormals(n);mesh.subMeshCount=t.Length;for(int i=0;i<t.Length;i++)mesh.SetTriangles(t[i],i);mesh.RecalculateBounds();var cut=TransformerCasePocket.Cut(mesh,Pocket);if(slots>=4)cut=TransformerCasePocket.Cut(cut,LeftPocket);
            // Add the closed gray liner AFTER cutting the aperture. Cutting a rear
            // seat on the pocket boundary could remove its visible face as well.
            v=new List<Vector3>(cut.vertices);n=new List<Vector3>(cut.normals);for(int i=0;i<t.Length;i++)t[i]=new List<int>(cut.GetTriangles(i));
            RoundedGeometry.Box(v,n,t[0],new Vector3(x,-.0125f,.0637f),new Vector3(.058f,.0334f,.001f),.0001f);
            if(slots>=4)RoundedGeometry.Box(v,n,t[0],new Vector3(.10125f,0,.0612f),new Vector3(.031f,.067f,.001f),.0001f);
            float back=.0642f,front=.0736f,depth=front-back;
            foreach(float sign in new[]{-1f,1f})
            {
                RoundedGeometry.Box(v,n,t[0],new Vector3(x+sign*.02835f,-.0125f,(back+front)*.5f),new Vector3(.0003f,.0324f,depth),.00002f);
                RoundedGeometry.Box(v,n,t[0],new Vector3(x,-.0125f+sign*.01615f,(back+front)*.5f),new Vector3(.057f,.0001f,depth),.00002f);
            }
            var result=new Mesh{name="Switchboards.TransformerGrayClosedLiner"};result.SetVertices(v);result.SetNormals(n);result.subMeshCount=t.Length;for(int i=0;i<t.Length;i++)result.SetTriangles(t[i],i);result.RecalculateBounds();return result;
        }
        internal static Mesh Knob()=>TransformerReferenceMesh.Load("Dial");
    }
}
