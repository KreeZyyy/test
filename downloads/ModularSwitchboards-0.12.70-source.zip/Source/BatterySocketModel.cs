using System.Collections.Generic;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class BatterySocketModel
    {
        internal static Mesh Build()
        {
            var v=new List<Vector3>();var n=new List<Vector3>();var t=new[]{new List<int>(),new List<int>(),new List<int>()};
            float half=(ApcBatteryRegion.SocketHeight+.0006f)*.5f,front=ApcBatteryRegion.DinFace;
            var rings=new[]{Ring(half,.003f,front),Ring(half-.0018f,.001f,front-.001f),Ring(half-.0018f,.001f,.0048f)};
            System.Action<Vector3,Vector3,Vector3,int> tri=(a,b,c,role)=>{int k=v.Count;var normal=Vector3.Cross(b-a,c-a).normalized;v.AddRange(new[]{a,b,c});n.AddRange(new[]{normal,normal,normal});t[role].AddRange(new[]{k,k+1,k+2});};
            for(int ring=0;ring<2;ring++)for(int i=0;i<8;i++)
            {
                int next=(i+1)%8;var a=rings[ring][i];var b=rings[ring][next];var c=rings[ring+1][next];var d=rings[ring+1][i];
                tri(a,b,c,ring==0?1:0);tri(a,c,d,ring==0?1:0);
            }
            var center=new Vector3(DinBatteryLayout.CenterX,0,.0048f);
            for(int i=0;i<8;i++)tri(center,rings[2][i],rings[2][(i+1)%8],0);
            // Dark square rear coverage also closes the corners outside the octagon.
            RoundedGeometry.Box(v,n,t[0],new Vector3(DinBatteryLayout.CenterX,0,.0044f),new Vector3(half*2/DinBreakerModel.VisualScale.x,half*2/DinBreakerModel.VisualScale.y,.0004f),.0001f);
            // Six independent gold contacts in two horizontal rows.
            foreach(float row in new[]{-1f,1f})foreach(float column in new[]{-1f,0f,1f})
                RoundedGeometry.Box(v,n,t[2],new Vector3(DinBatteryLayout.CenterX+column*.008f/DinBreakerModel.VisualScale.x,row*.012f/DinBreakerModel.VisualScale.y,.0063f),new Vector3(.0045f/DinBreakerModel.VisualScale.x,.005f/DinBreakerModel.VisualScale.y,.0018f),.0002f);
            var mesh=new Mesh{name="Switchboards.CustomBatterySocket"};mesh.SetVertices(v);mesh.SetNormals(n);mesh.subMeshCount=3;
            for(int i=0;i<3;i++)mesh.SetTriangles(t[i],i);mesh.RecalculateBounds();return mesh;
        }
        private static Vector3[] Ring(float half,float cut,float z)
        {
            // Counter-clockwise seen from the front; the recessed rings keep normals
            // facing into the cavity, independent of any imported APC mesh/UV data.
            var xy=new[]{new Vector2(-half+cut,-half),new Vector2(half-cut,-half),new Vector2(half,-half+cut),new Vector2(half,half-cut),new Vector2(half-cut,half),new Vector2(-half+cut,half),new Vector2(-half,half-cut),new Vector2(-half,-half+cut)};
            var result=new Vector3[8];for(int i=0;i<8;i++)result[i]=new Vector3(DinBatteryLayout.CenterX+xy[i].x/DinBreakerModel.VisualScale.x,xy[i].y/DinBreakerModel.VisualScale.y,z);return result;
        }
    }
}
