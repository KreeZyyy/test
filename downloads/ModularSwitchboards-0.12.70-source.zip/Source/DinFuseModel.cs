using System.Collections.Generic;
using UnityEngine;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Motherboards;

namespace ModularSwitchboards
{
    internal static class DinFuseModel
    {
        private sealed class Shape
        {
            internal readonly List<Vector3> V=new List<Vector3>(),N=new List<Vector3>();
            internal readonly List<int>[] T={new List<int>(),new List<int>(),new List<int>(),new List<int>(),new List<int>()};
            internal void Box(Vector3 p,Vector3 size,int role)=>RoundedGeometry.Box(V,N,T[role],p,size,.0004f);
            internal void Cylinder(float y,float length,float radius,int role)
            {
                const int count=32;float z=.046f;
                for(int i=0;i<count;i++)
                {
                    float a=i*Mathf.PI*2/count,b=(i+1)*Mathf.PI*2/count;
                    var ra=new Vector3(Mathf.Cos(a)*radius/DinBreakerModel.VisualScale.x,0,Mathf.Sin(a)*radius/DinBreakerModel.VisualScale.z);
                    var rb=new Vector3(Mathf.Cos(b)*radius/DinBreakerModel.VisualScale.x,0,Mathf.Sin(b)*radius/DinBreakerModel.VisualScale.z);
                    var lo=new Vector3(0,y-length*.5f,z);var hi=new Vector3(0,y+length*.5f,z);
                    var na=new Vector3(Mathf.Cos(a)*DinBreakerModel.VisualScale.x,0,Mathf.Sin(a)*DinBreakerModel.VisualScale.z).normalized;
                    var nb=new Vector3(Mathf.Cos(b)*DinBreakerModel.VisualScale.x,0,Mathf.Sin(b)*DinBreakerModel.VisualScale.z).normalized;
                    SmoothTriangle(lo+ra,hi+ra,lo+rb,na,na,nb,role);SmoothTriangle(lo+rb,hi+ra,hi+rb,nb,na,nb,role);
                    Triangle(lo,lo+ra,lo+rb,role);Triangle(hi,hi+rb,hi+ra,role);
                }
            }
            internal void Contact(float end)
            {
                const float outer=.0055f,inner=.0042f,lo=.014f,bridge=.0177f,hi=.0186f,back=.041f,front=.0525f;
                var outline=new[]{new Vector2(-outer,lo),new Vector2(-inner,lo),new Vector2(-inner,bridge),new Vector2(inner,bridge),new Vector2(inner,lo),new Vector2(outer,lo),new Vector2(outer,hi-.0004f),new Vector2(outer-.0004f,hi),new Vector2(-outer+.0004f,hi),new Vector2(-outer,hi-.0004f)};
                // One extruded U profile: no rounded joints between separate bars.
                for(int i=0;i<outline.Length;i++)
                {
                    var p=outline[i];var q=outline[(i+1)%outline.Length];
                    var a=new Vector3(p.x,p.y*end,back);var b=new Vector3(q.x,q.y*end,back);var c=new Vector3(q.x,q.y*end,front);var d=new Vector3(p.x,p.y*end,front);
                    if(end>0){Triangle(a,b,c,4);Triangle(a,c,d,4);}else{Triangle(a,c,b,4);Triangle(a,d,c,4);}
                }
                foreach(var rect in new[]{new[]{-outer,-inner,lo,hi},new[]{inner,outer,lo,hi},new[]{-inner,inner,bridge,hi}})
                foreach(bool forward in new[]{false,true})
                {
                    float z=forward?front:back;var a=new Vector3(rect[0],rect[2]*end,z);var b=new Vector3(rect[1],rect[2]*end,z);var c=new Vector3(rect[1],rect[3]*end,z);var d=new Vector3(rect[0],rect[3]*end,z);
                    if(forward==(end>0)){Triangle(a,b,c,4);Triangle(a,c,d,4);}else{Triangle(a,c,b,4);Triangle(a,d,c,4);}
                }
            }
            private void SmoothTriangle(Vector3 a,Vector3 b,Vector3 c,Vector3 na,Vector3 nb,Vector3 nc,int role)
            {int first=V.Count;V.AddRange(new[]{a,b,c});N.AddRange(new[]{na,nb,nc});T[role].AddRange(new[]{first,first+1,first+2});}
            private void Triangle(Vector3 a,Vector3 b,Vector3 c,int role)
            {int first=V.Count;var normal=Vector3.Cross(b-a,c-a).normalized;V.AddRange(new[]{a,b,c});N.AddRange(new[]{normal,normal,normal});T[role].AddRange(new[]{first,first+1,first+2});}
            internal Mesh Finish(string name){var mesh=new Mesh{name=name};mesh.SetVertices(V);mesh.SetNormals(N);mesh.subMeshCount=5;for(int i=0;i<5;i++)mesh.SetTriangles(T[i],i);CabinetGeometry.ApplyNativeUv(mesh);mesh.RecalculateBounds();return mesh;}
        }
        internal static Mesh Housing()
        {
            // Same continuous casing as the breaker, with a narrow fuse aperture.
            // Separate rounded rails and end blocks would leave visible seams.
            var mesh=DinBreakerModel.Build(.0176f,0,true,.0125f,.044f);
            mesh.name="Switchboards.HollowFuseHolder";return mesh;
        }
        internal static Mesh Contacts()
        {
            var g=new Shape();
            foreach(float end in new[]{-1f,1f})g.Contact(end);
            return g.Finish("Switchboards.FixedFuseContacts");
        }
        internal static Mesh Cartridge(bool burnt)
        {
            var g=new Shape();
            if(!burnt)g.Cylinder(0,.024f,.007f,0);
            else
            {
                // Two charred halves with an actual missing section, not an indicator.
                g.Cylinder(-.008f,.008f,.007f,3);g.Cylinder(.008f,.008f,.007f,3);
                g.Box(new Vector3(-.0012f,-.0035f,.048f),new Vector3(.002f,.003f,.003f),3);
                g.Box(new Vector3(.001f,.0035f,.044f),new Vector3(.0018f,.003f,.003f),3);
            }
            return g.Finish(burnt?"Switchboards.BurntFuse":"Switchboards.IntactFuse");
        }
        internal static Mesh Caps()
        {
            var g=new Shape();foreach(float sign in new[]{-1f,1f})g.Cylinder(sign*.014f,.005f,.0082f,1);
            return g.Finish("Switchboards.WhiteFuseCaps");
        }
        internal static Material[] CapMaterials()=>FuseSurfaces.White;
        internal static void PaintCaps(Renderer renderer)
        {
            // Dedicated plain material owns the colour; do not send palette indices to it.
            renderer.SetPropertyBlock(null);
            for(int role=0;role<renderer.sharedMaterials.Length;role++)renderer.SetPropertyBlock(null,role);
        }
        internal static void Paint(Renderer renderer,float watts)
        {
            int colour=DinModuleColours.Index(watts);
            for(int role=0;role<renderer.sharedMaterials.Length;role++)
            {var block=new MaterialPropertyBlock();block.SetFloat(Thing.DiffuseIndexPropertyID,role==0?colour:CabinetGeometry.PaletteIndices[role]);block.SetColor(Thing.EMISSION_COLOR,Color.black);renderer.SetPropertyBlock(block,role);}
        }
    }
    public sealed class DinFuseView:MonoBehaviour
    {
        public DinBreaker Owner;public GameObject Intact,Burnt,Caps;
        private bool appearanceReady,lastFilled,lastTripped;
        private float lastWatts;
        private void LateUpdate()
        {
            if(Owner==null)return;
            bool filled=Owner.Conducting;
            if(appearanceReady&&filled==lastFilled&&Owner.Tripped==lastTripped&&Owner.RatedWatts==lastWatts)return;
            appearanceReady=true;lastFilled=filled;lastTripped=Owner.Tripped;lastWatts=Owner.RatedWatts;
            Intact.SetActive(filled);Burnt.SetActive(Owner.Tripped);Caps.SetActive(filled||Owner.Tripped);
            if(filled||Owner.Tripped)DinFuseModel.PaintCaps(Caps.GetComponent<MeshRenderer>());
            if(filled)DinFuseModel.Paint(Intact.GetComponent<MeshRenderer>(),Owner.RatedWatts);
            if(Owner.Tripped)DinFuseModel.Paint(Burnt.GetComponent<MeshRenderer>(),Owner.RatedWatts);
        }
    }
}
