using System;using ModularSwitchboards;using Assets.Scripts.Objects;using UnityEngine;
namespace UnityEngine{
 public class GameObject{public Transform transform;public GameObject(){transform=new Transform{gameObject=this};}}
 public struct Vector3{public float x,y,z;public Vector3(float x,float y,float z){this.x=x;this.y=y;this.z=z;}}
 public struct Quaternion{public float z;public static Quaternion Euler(float x,float y,float z)=>new(){z=z};}
 public static class Time{public static float deltaTime=.016f;}
 public static class Mathf{public static float Max(float x,float y)=>Math.Max(x,y);public static float MoveTowards(float a,float b,float d)=>Math.Abs(b-a)<=d?b:a+Math.Sign(b-a)*d;}
 public class Transform{public GameObject gameObject;public Transform parent,child;public Vector3 localPosition;public Quaternion localRotation;public Transform Find(string name)=>child;}
 public class MonoBehaviour{public GameObject gameObject;public Transform transform=>gameObject.transform;public DinBreaker actual;public T GetComponent<T>() where T:class=>actual as T;}
}
namespace Assets.Scripts.Objects{public class Thing{public class DelayedActionInstance{public float Duration;public string ActionMessage;public bool Success;public DelayedActionInstance Fail(string s){Success=false;return this;}public DelayedActionInstance Succeed(){Success=true;return this;}}}public class Interactable{public DinBreaker Parent;}}
namespace Assets.Scripts.Networking{public static class OnServer{public static int Calls,Last;public static bool Apply=true;public static void Interact(Interactable c,int state){Calls++;Last=state;if(Apply)c.Parent.OnOff=state==1;}}}
namespace Assets.Scripts.Objects{public class MultiConstructor{public int Quantity=1,PrefabHash;public void RemoveQuantity(int n){Quantity-=n;}}public class Slot{public object Get()=>null;}}
namespace ModularSwitchboards{public static class GameManager{public static bool RunSimulation=true;}public static class DinFuseAudio{public static void Play(DinBreaker owner){}}public class Board{public object PrimaryHost;}public class SwitchboardCabinet{public bool IsStructureCompleted=true;}public partial class DinBreaker{public bool IsCursor,IsBeingDestroyed,IsStructureCompleted=true;private bool onOff;public bool StateReady=true;public int StateReads,StateWrites;public bool OnOff{get{StateReads++;if(!StateReady)throw new Exception("Native state not initialized");return onOff;}set{StateWrites++;if(!StateReady)throw new Exception("Native state not initialized");onOff=value;}}public bool IsDoorIsolator=true,IsDoorBridge,IsDoorLed,IsDoorStop,IsBatteryModule,IsAnalyserModule,IsFuseHolder,Tripped;public int fuseBurnSequence;public ushort NetworkUpdateFlags;private const ushort ModuleUpdate=32768;public int[] AllowedFuseKits=Array.Empty<int>();public System.Collections.Generic.List<Slot> Slots=new();public Board Board;public GameObject gameObject=new();}}
class Program{
 static int n;static void Check(bool ok,string text){n++;if(!ok)throw new Exception(text);}
 static void Tick(DoorIsolatorView view)=>typeof(DoorIsolatorView).GetMethod("LateUpdate",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).Invoke(view,null);
 static void Main(){
 // Native Thing.OnOff throws during prefab setup; lifecycle/initial geometry must not access it.
 var unready=new DinBreaker{StateReady=false};var initialHandle=new GameObject().transform;initialHandle.parent=unready.gameObject.transform;unready.gameObject.transform.child=initialHandle;
 var initialView=new DoorIsolatorView{gameObject=unready.gameObject,actual=unready};
 DoorIsolatorView.SetInitialPose(initialHandle);
 foreach(var method in new[]{"Awake","OnEnable"})typeof(DoorIsolatorView).GetMethod(method,System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).Invoke(initialView,null);
 Check(initialHandle.localRotation.z==90&&unready.StateReads==0&&unready.StateWrites==0,"Prefab pose/Awake/OnEnable do not touch unavailable native state");
 unready.StateReady=true;unready.OnOff=true;Tick(initialView);Check(initialHandle.localRotation.z==0&&unready.OnOff,"Loaded ON state replaces default OFF pose without resetting state");
 var host=new SwitchboardCabinet();var part=new DinBreaker{Board=new(){PrimaryHost=host}};var control=new Interactable{Parent=part};
 Check(!part.Conducting,"New isolator is electrically OFF");
 var wires=new[]{new CabinetWireSaveData{From=new(0,0),To=new(7,0)},new CabinetWireSaveData{From=new(7,1),To=new(0,1)}};
 Check(!WireCircuit.Reachable(new(0,0),new(0,1),wires,part.Conducting?new long[]{7}:Array.Empty<long>()),"OFF opens real graph");
 var preview=DoorIsolatorControl.Interact(part,control,false);Check(preview.Success&&preview.Duration==0&&!part.OnOff&&Assets.Scripts.Networking.OnServer.Calls==0,"OFF preview never changes state");
 DoorIsolatorControl.Interact(part,control,true);Check(part.OnOff&&Assets.Scripts.Networking.OnServer.Last==1,"ON uses native server path");
 Check(part.Conducting&&WireCircuit.Reachable(new(0,0),new(0,1),wires,new long[]{7}),"ON closes real graph");part.Trip();Check(part.Conducting&&!part.Tripped&&part.NetworkUpdateFlags==0,"Manual isolator never trips on overload");
 for(int i=0;i<20;i++){var p=DoorIsolatorControl.Interact(part,control,false);Check(p.Success&&p.Duration==0&&part.OnOff,"Cancelled interactions leave ON");}
 Check(DoorIsolatorControl.ActionName(true).Contains("OFF")&&DoorIsolatorControl.ActionName(false).Contains("ON"),"Prompts show next position");
 DoorIsolatorControl.Interact(part,control,true);Check(!part.OnOff&&!part.Conducting&&Assets.Scripts.Networking.OnServer.Last==0,"OFF uses native server path");
 Assets.Scripts.Networking.OnServer.Apply=false;DoorIsolatorControl.Interact(part,control,true);Check(!part.OnOff&&Assets.Scripts.Networking.OnServer.Last==1,"Client only sends request");Assets.Scripts.Networking.OnServer.Apply=true;
 foreach(int invalid in new[]{0,1,2,3,4}){part.IsCursor=invalid==0;part.IsBeingDestroyed=invalid==1;part.IsStructureCompleted=invalid!=2;host.IsStructureCompleted=invalid!=3;if(invalid==4)part.Board=null;int before=Assets.Scripts.Networking.OnServer.Calls;Check(!DoorIsolatorControl.Interact(part,control,true).Success&&before==Assets.Scripts.Networking.OnServer.Calls,"Preview/destroyed/incomplete/uninstalled cannot switch");part.IsCursor=part.IsBeingDestroyed=false;part.IsStructureCompleted=host.IsStructureCompleted=true;part.Board=new(){PrimaryHost=host};}
 var handle=new GameObject().transform;handle.parent=part.gameObject.transform;part.gameObject.transform.child=handle;var view=new DoorIsolatorView{gameObject=part.gameObject,actual=part};
 Tick(view);Check(handle.localRotation.z==90&&!part.OnOff,"Fresh OFF position horizontal");part.OnOff=true;Tick(view);Check(handle.localRotation.z>0&&handle.localRotation.z<90,"Quarter-turn animation");for(int i=0;i<30;i++)Tick(view);Check(handle.localRotation.z==0,"ON position vertical");
 var loaded=new DoorIsolatorView{gameObject=part.gameObject,actual=part};Tick(loaded);Check(handle.localRotation.z==0&&part.OnOff,"Loaded ON position never resets state");
 part.OnOff=false;for(int i=0;i<30;i++)Tick(view);Check(handle.localRotation.z==90,"OFF rotates back");
 var another=new DinBreaker{Board=part.Board,OnOff=true};var ownHandle=new GameObject().transform;ownHandle.parent=another.gameObject.transform;another.gameObject.transform.child=ownHandle;var clone=new DoorIsolatorView{gameObject=another.gameObject,actual=another,Owner=part,Handle=handle};Tick(clone);Check(clone.Owner==another&&clone.Handle==ownHandle&&ownHandle.localRotation.z==0&&handle.localRotation.z==90,"Cloned prefab rebinds own instance");
 part.OnOff=true;part.IsBeingDestroyed=true;Check(!part.Conducting,"Destroyed module cannot conduct");
 Console.WriteLine($"Rotary isolator: {n} production control/pose checks passed.");
 }
}
