using System;
using System.Collections.Generic;
using UnityEngine;
namespace ModularSwitchboards
{
    // Original model drawn in front-view coordinates, from the user's reference.
    // u increases to the viewer's right; v increases downwards inside the glass.
    internal static class SmartPanelLayout
    {
        internal static Vector3 Point(float u,float v,float z)=>new Vector3((.5f-u)*.0112f,.0085f-v*.0298f,z);
        internal static void Build(List<Vector3> vertices,List<Vector3> normals,List<int>[] groups)
        {
            Action<int,float,float,float,float,float,float> box=(role,u,v,w,h,z,depth)=>RoundedGeometry.Box(vertices,normals,groups[role],Point(u,v,z),new Vector3(w*.0112f,h*.0298f,depth),.00008f);
            box(5,.5f,.5f,1.04f,1.04f,.0618f,.0004f);
            // Board outline: raised upper-left edge, diagonal notch and lower right lip.
            var outline=new[]{Point(.06f,.53f,.0622f),Point(.55f,.53f,.0622f),Point(.68f,.60f,.0622f),Point(.95f,.57f,.0622f),Point(.95f,.96f,.0622f),Point(.06f,.96f,.0622f)};
            Action<Vector3,Vector3,Vector3,Vector3> triangle=(a,b,c,n)=>
            {
                int start=vertices.Count;vertices.AddRange(new[]{a,b,c});normals.AddRange(new[]{n,n,n});
                bool forward=Vector3.Dot(Vector3.Cross(b-a,c-a),n)>0;
                groups[0].AddRange(forward?new[]{start,start+1,start+2}:new[]{start,start+2,start+1});
            };
            for(int i=0;i<outline.Length-2;i++)
            {
                triangle(outline[5],outline[i],outline[i+1],Vector3.forward);
                triangle(outline[5]-Vector3.forward*.00045f,outline[i]-Vector3.forward*.00045f,outline[i+1]-Vector3.forward*.00045f,Vector3.back);
            }
            for(int i=0;i<outline.Length;i++)
            {
                var a=outline[i];var b=outline[(i+1)%outline.Length];var backA=a-Vector3.forward*.00045f;var backB=b-Vector3.forward*.00045f;
                var n=Vector3.Cross(b-a,Vector3.forward).normalized;triangle(a,backA,b,n);triangle(b,backA,backB,n);
            }
            // Upper package and nine silver contacts on each of its two rows.
            box(1,.5f,.255f,.86f,.335f,.0631f,.0011f);
            for(int pin=0;pin<9;pin++)foreach(float row in new[]{.052f,.455f})
                box(2,.105f+pin*.09875f,row,.065f,.045f,.0629f,.0004f);
            // Lower-left IC: the board stays visible around the package.
            box(1,.285f,.755f,.28f,.18f,.0629f,.0008f);
            for(int pin=0;pin<6;pin++)foreach(float row in new[]{.647f,.862f})
                box(2,.157f+pin*.051f,row,.029f,.025f,.06275f,.0003f);
            for(int pin=0;pin<4;pin++)foreach(float column in new[]{.126f,.444f})
                box(2,column,.69f+pin*.043f,.024f,.023f,.06275f,.0003f);
            // Two red capacitors above the small horizontal IC and right-hand blocks.
            foreach(float u in new[]{.59f,.72f})
            {
                box(4,u,.69f,.085f,.095f,.063f,.00085f);
                box(2,u,.632f,.025f,.018f,.0627f,.00025f);
            }
            box(1,.655f,.862f,.24f,.095f,.0628f,.0006f);
            box(3,.855f,.70f,.13f,.085f,.0628f,.0006f);
            box(6,.855f,.86f,.13f,.065f,.0628f,.0006f);
        }
    }
}
