using System;
using System.Collections.Generic;
using System.Linq;
using Assets.Scripts;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Structures;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class SmartOutputElectronics
    {
        // Original geometry. The vending machine is a visual reference only.
        internal static void Install(Transform model,int layer)
        {
            var v=new List<Vector3>();var nrm=new List<Vector3>();var groups=new List<int>[7];for(int i=0;i<7;i++)groups[i]=new List<int>();
            SmartPanelLayout.Build(v,nrm,groups);
            var mesh2=new Mesh{name="Smart.Output.ElectronicsInsert"};mesh2.SetVertices(v);mesh2.SetNormals(nrm);mesh2.subMeshCount=7;
            for(int i=0;i<7;i++)mesh2.SetTriangles(groups[i],i);mesh2.RecalculateBounds();
            var root=new GameObject("SmartOutputElectronics"){layer=layer};root.transform.SetParent(model,false);root.AddComponent<MeshFilter>().sharedMesh=mesh2;
            root.AddComponent<MeshRenderer>().sharedMaterials=new[]{Material("PCB",new Color(.045f,.19f,.035f)),Material("Chip",new Color(.055f,.055f,.055f)),Material("Contacts",new Color(.48f,.5f,.46f)),Material("AmberBlock",new Color(.30f,.22f,.035f)),Material("Capacitors",new Color(.43f,.018f,.012f)),Material("Backing",new Color(.018f,.022f,.023f)),Material("BrownBlock",new Color(.25f,.085f,.018f))};
            // Real recess in our own casing, with a shallow protective window.
            var casing=model.GetComponent<MeshFilter>();var old=casing.sharedMesh;
            casing.sharedMesh=SmartSocketPocket.Cut(old,new Bounds(new Vector3(0,-.0064f,.0645f),new Vector3(.0125f,.0325f,.007f)));
            UnityEngine.Object.DestroyImmediate(old);
            var glassV=new List<Vector3>();var glassN=new List<Vector3>();var glassT=new List<int>();
            RoundedGeometry.Box(glassV,glassN,glassT,new Vector3(0,-.0064f,.0648f),new Vector3(.0122f,.032f,.00035f),.0003f);
            var glassMesh=new Mesh{name="NET.AuthoredProtectiveGlass"};glassMesh.SetVertices(glassV);glassMesh.SetNormals(glassN);glassMesh.SetTriangles(glassT,0);glassMesh.RecalculateBounds();
            var glass=new GameObject("SmartOutputGlass"){layer=layer};glass.transform.SetParent(model,false);glass.AddComponent<MeshFilter>().sharedMesh=glassMesh;
            var window=Material("ProtectiveGlass",new Color(.55f,.57f,.58f,.025f));
            window.SetFloat("_Mode",3f);window.SetOverrideTag("RenderType","Transparent");window.SetInt("_SrcBlend",(int)UnityEngine.Rendering.BlendMode.SrcAlpha);window.SetInt("_DstBlend",(int)UnityEngine.Rendering.BlendMode.OneMinusSrcAlpha);window.SetInt("_ZWrite",0);
            window.EnableKeyword("_ALPHABLEND_ON");window.renderQueue=(int)UnityEngine.Rendering.RenderQueue.Transparent;
            var surface=glass.AddComponent<MeshRenderer>();surface.sharedMaterial=window;surface.shadowCastingMode=UnityEngine.Rendering.ShadowCastingMode.Off;surface.receiveShadows=false;

        }
        internal static Material Material(string name,Color color)
        {
            var shader=Shader.Find("Standard");if(shader==null||!shader.isSupported)throw new InvalidOperationException("NET panel shader unavailable");
            var m=new Material(shader){name="Switchboards.NET."+name,color=color};CabinetMatteSurface.Configure(m);return m;
        }
    }
}
