using System;
using System.Collections.Generic;
using System.Linq;
using Assets.Scripts;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Objects;
using UnityEngine;

namespace ModularSwitchboards
{
    // Descriptive placement data only. This component does not register a port.
    public sealed class OvenInputPanelMetadata : MonoBehaviour
    {
        public Vector3 SocketPoint, SocketAxis, CableCell, BodyCell, PanelFaceAxis;
        public Vector3 NativeSocketPoint, NativeSocketAxis;
        public bool FunctionalConnection;
    }

    internal static class OvenInputPanel
    {
        internal const string RootName="OvenInputPanel";
        private static Mesh cached;
        private static MeshRenderer source;
        private static Vector3 nativeAnchor,nativeAxis;

        internal static void Install(SwitchboardCabinet cabinet)
        {
            GameObject root=null;
            try
            {
                if(cached==null)Capture();
                var socket=NativeCableLayout.Read(new Vector3(0,.5f,0),Vector3.up);
                root=new GameObject(RootName){layer=cabinet.gameObject.layer};
                root.transform.SetParent(cabinet.transform.Find("SwitchboardModel/CompletedShell"),false);
                // Flip the visual body 180 degrees about its native width axis.
                // Keep the future logical socket point and axis unchanged.
                root.transform.localRotation=Quaternion.FromToRotation(Vector3.forward,socket.Forward)*Quaternion.Euler(180f,0f,0f);
                root.AddComponent<MeshFilter>().sharedMesh=cached;
                var renderer=root.AddComponent<MeshRenderer>();NativePortSurface.Capture(source,renderer);
                renderer.lightProbeUsage=source.lightProbeUsage;renderer.reflectionProbeUsage=source.reflectionProbeUsage;
                renderer.shadowCastingMode=source.shadowCastingMode;renderer.receiveShadows=source.receiveShadows;
                var marker=root.AddComponent<OvenInputPanelMetadata>();
                marker.SocketPoint=socket.Point;marker.SocketAxis=socket.Forward;
                marker.PanelFaceAxis=root.transform.localRotation*Vector3.forward;
                marker.CableCell=socket.CableCell.ToVector3();marker.BodyCell=socket.BodyCell.ToVector3();
                marker.NativeSocketPoint=nativeAnchor;marker.NativeSocketAxis=nativeAxis;
                marker.FunctionalConnection=false;
                var collider=root.AddComponent<MeshCollider>();collider.sharedMesh=cached;
                cabinet.BuildStates[1].Colliders.Add(collider);
                Align(cabinet);CabinetModel.SetBounds(cabinet);
                Debug.Log("[Modular Switchboards] IN model only: original Oven panel size; socket="+socket.Point.ToString("F6")+
                    " axis="+socket.Forward+" cableCell="+marker.CableCell+" bodyCell="+marker.BodyCell+
                    "; native oven anchor="+nativeAnchor.ToString("F6")+"; no Connection registered.");
            }
            catch(Exception ex)
            {
                if(root!=null)
                {
                    var collider=root.GetComponent<MeshCollider>();
                    if(collider!=null)cabinet.BuildStates[1].Colliders.Remove(collider);
                    UnityEngine.Object.DestroyImmediate(root);
                }
                Debug.LogError("[Modular Switchboards] Oven IN model unavailable; cabinet preserved: "+ex);
            }
        }

        private static void Capture()
        {
            var oven=WorldManager.Instance.SourcePrefabs.OfType<SmallGrid>().First(p=>p.GetType().Name=="AutomatedOven");
            source=oven.GetComponentsInChildren<MeshRenderer>(true).First(r=>r.GetComponent<MeshFilter>()?.sharedMesh?.name=="StructureAutomatedOven");
            var mesh=source.GetComponent<MeshFilter>().sharedMesh;
            CabinetGeometry.ReadNativeMesh(mesh,out var points,out var uv,out var groups);
            var frame=oven.transform.worldToLocalMatrix*source.transform.localToWorldMatrix;
            for(int i=0;i<points.Length;i++)points[i]=frame.MultiplyPoint3x4(points[i]);
            var expected=new Vector3(-.5f,0,.317412257f);
            var anchor=oven.OpenEnds.Where(p=>p?.Transform!=null)
                .OrderBy(p=>(oven.transform.InverseTransformPoint(p.Transform.position)-expected).sqrMagnitude).First();
            nativeAnchor=oven.transform.InverseTransformPoint(anchor.Transform.position);
            nativeAxis=oven.transform.InverseTransformDirection(anchor.Transform.forward);
            if((nativeAnchor-expected).sqrMagnitude>.0001f)throw new InvalidOperationException("Oven power anchor differs from reference");
            var vertices=new List<Vector3>();var texcoords=new List<Vector2>();var remap=new Dictionary<int,int>();
            var triangles=new List<int>[groups.Length];int count=0;
            for(int s=0;s<groups.Length;s++)
            {
                triangles[s]=new List<int>();
                for(int i=0;i<groups[s].Length;i+=3)
                {
                    int a=groups[s][i],b=groups[s][i+1],c=groups[s][i+2];
                    if(!Inside(points[a])||!Inside(points[b])||!Inside(points[c]))continue;
                    count++;
                    foreach(int id in new[]{a,b,c})
                    {
                        if(!remap.TryGetValue(id,out var n)){n=vertices.Count;remap.Add(id,n);vertices.Add(points[id]-nativeAnchor);texcoords.Add(uv[id]);}
                        triangles[s].Add(n);
                    }
                }
            }
            if(count!=92)throw new InvalidOperationException("Oven panel selection differs from verified 92 triangles: "+count);
            var panel=new Mesh{name="Switchboards.NativeOvenInputPanel"};panel.SetVertices(vertices);panel.SetUVs(0,texcoords);panel.subMeshCount=groups.Length;
            for(int s=0;s<groups.Length;s++)panel.SetTriangles(triangles[s],s);
            panel.RecalculateNormals();panel.RecalculateTangents();panel.RecalculateBounds();cached=panel;
        }

        private static bool Inside(Vector3 p)=>p.x>=-.549f && p.x<=-.448f && p.y>=-.053f && p.y<=.126f && p.z>=.127f && p.z<=.256f;

        internal static void Align(Structure cabinet)
        {
            var root=cabinet.transform.Find("SwitchboardModel/CompletedShell/"+RootName);
            if(root==null)return;var data=root.GetComponent<OvenInputPanelMetadata>();
            if(data==null)return;
            // Cancel visual wall-fit translation so the original power anchor,
            // now the mesh origin, remains on the cable-grid socket position.
            root.localPosition=root.parent.InverseTransformPoint(cabinet.transform.position)+data.SocketPoint;
        }

        internal static void IncludeBounds(Structure cabinet,ref Bounds bounds)
        {
            var root=cabinet.transform.Find("SwitchboardModel/CompletedShell/"+RootName);
            var mesh=root==null?null:root.GetComponent<MeshFilter>()?.sharedMesh;
            if(mesh!=null)bounds.Encapsulate(CabinetWallMount.TransformedBounds(mesh.bounds,
                cabinet.transform.worldToLocalMatrix*root.localToWorldMatrix));
        }
    }
}
