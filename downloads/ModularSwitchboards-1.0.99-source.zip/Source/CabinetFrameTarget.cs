using System;
using Assets.Scripts.Objects;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class CabinetFrameTarget
    {
        internal static void Install(Structure cabinet)
        {
            // Install after variant geometry: these bounds already include Medium
            // dimensions. Parenting to the model retains reverse/wall orientation.
            var model=cabinet.transform.Find("SwitchboardModel");
            if(model==null)throw new InvalidOperationException("Cabinet frame model is missing.");
            var left=Edge(model,"FrameLeft");var right=Edge(model,"FrameRight");
            var bottom=Edge(model,"FrameBottom");var top=Edge(model,"FrameTop");
            float x0=left.center.x+left.size.x*.5f,x1=right.center.x-right.size.x*.5f;
            float y0=bottom.center.y+bottom.size.y*.5f,y1=top.center.y-top.size.y*.5f;
            if(x1<=x0||y1<=y0)throw new InvalidOperationException("Cabinet frame opening is invalid.");
            var target=new GameObject("FrameConstructionTarget"){layer=cabinet.gameObject.layer};
            target.transform.SetParent(model,false);
            var hit=target.AddComponent<BoxCollider>();
            hit.center=new Vector3((x0+x1)*.5f,(y0+y1)*.5f,left.center.z);
            hit.size=new Vector3(x1-x0,y1-y0,.002f);
            // Native cursor raycasts include triggers. A trigger adds no solid
            // collision; native CacheColliders registers it to the cabinet.
            hit.isTrigger=true;hit.enabled=false;
            // OnMyState switches it on for frame-only state 0, and off after
            // construction (also on load/network updates and dismantling).
            cabinet.BuildStates[0].Colliders.Add(hit);
        }
        private static BoxCollider Edge(Transform model,string name)
        {
            var edge=model.Find(name)?.GetComponent<BoxCollider>();
            if(edge==null)throw new InvalidOperationException("Cabinet frame edge is missing: "+name);
            return edge;
        }
    }
}
