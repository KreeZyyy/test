using UnityEngine;
using UnityEngine.Rendering;
namespace ModularSwitchboards
{
    internal static class PlacementOutline
    {
        internal static bool Apply(GameObject cursor)
        {
            var filter=cursor.GetComponent<MeshFilter>();var source=filter?.sharedMesh;var renderer=cursor.GetComponent<MeshRenderer>();if(source==null||renderer==null)return false;
            var fillInk=PlacementPreviewStyle.NativeFill();var edgeInk=PlacementPreviewStyle.Ink(.85f,CullMode.Off);if(fillInk==null||edgeInk==null)return false;
            var vertices=source.vertices;var edges=new Mesh{name="Switchboards.ItemPreview.Edges",indexFormat=source.indexFormat};edges.vertices=vertices;edges.SetIndices(PlacementOutlineGeometry.Build(vertices,source.triangles),MeshTopology.Lines,0);edges.RecalculateBounds();
            // Borrow the original full model for fill; never modify/destroy it.
            PlacementPreviewStyle.Surface(renderer,new[]{fillInk});var child=new GameObject("StaticItemEdges"){layer=cursor.layer};child.transform.SetParent(cursor.transform,false);child.AddComponent<MeshFilter>().sharedMesh=edges;var edgeRenderer=child.AddComponent<MeshRenderer>();PlacementPreviewStyle.Surface(edgeRenderer,new[]{edgeInk});
            var owner=cursor.AddComponent<PlacementPreviewResources>();owner.Edges=edges;owner.Materials=new[]{fillInk,edgeInk};return true;
        }
    }
}
