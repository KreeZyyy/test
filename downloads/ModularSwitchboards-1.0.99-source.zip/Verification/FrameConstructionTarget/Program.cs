using System;
using System.Collections.Generic;
using ModularSwitchboards;
using UnityEngine;
using Assets.Scripts.Objects;
class Program
{
    static int checks;
    static void Check(bool ok,string message){checks++;if(!ok)throw new Exception(message);}
    static void Near(float a,float b,string message)=>Check(Math.Abs(a-b)<.00001f,message);
    static BoxCollider Edge(Transform model,string name,Vector3 center,Vector3 size)
    {var go=new GameObject(name);go.transform.SetParent(model,false);var hit=go.AddComponent<BoxCollider>();hit.center=center;hit.size=size;return hit;}
    static void SelectionChecks()
    {
        foreach(float scale in new[]{1f,2f})foreach(bool reverse in new[]{false,true})foreach(float wallOffset in new[]{.02f,.1f})
        {
            var cabinet=new SwitchboardCabinet();cabinet.transform.worldToLocalMatrix=Matrix4x4.Translate(-3,-4,-5);
            var model=new GameObject("SwitchboardModel");model.transform.SetParent(cabinet.transform,false);
            var frame=new GameObject("Frame");frame.transform.SetParent(model.transform,false);
            var filter=frame.AddComponent<MeshFilter>();filter.sharedMesh=new Mesh{bounds=new Bounds(new Vector3(0,0,.015f),new Vector3(.39f*scale,.48f*scale,.03f))};
            frame.transform.localToWorldMatrix=Matrix4x4.Translate(3,4,5+wallOffset)*Matrix4x4.Flip(reverse);
            var result=new SelectionInstance{Bounds=new Bounds(new Vector3(),new Vector3(9,9,9)),ParentThingRefernceId=42,InteractableId=-1,Position=new Vector3(3,4,5)};
            CabinetFrameSelection.AfterSelection(cabinet,ref result);
            Near(result.Bounds.size.x,.39f*scale,"selection fits frame width");Near(result.Bounds.size.y,.48f*scale,"selection fits frame height");Near(result.Bounds.size.z,.03f,"selection fits thin frame depth");
            Near(result.Bounds.center.z,wallOffset+(reverse?-.015f:.015f),"selection follows current wall fit/orientation");
            Check(result.ParentThingRefernceId==42&&result.InteractableId==-1&&result.Position.x==3,"native selection identity/pose retained");
            foreach(int state in new[]{1,2,-1}){cabinet.CurrentBuildStateIndex=state;result.Bounds=new Bounds(new Vector3(),new Vector3(9,9,9));CabinetFrameSelection.AfterSelection(cabinet,ref result);Near(result.Bounds.size.x,9,"completed/legacy/damaged cabinet selection unchanged");}
            cabinet.CurrentBuildStateIndex=0;cabinet.IsCursor=true;CabinetFrameSelection.AfterSelection(cabinet,ref result);Near(result.Bounds.size.x,9,"construction cursor unchanged");
            CabinetFrameSelection.AfterSelection(new Thing(),ref result);Near(result.Bounds.size.x,9,"vanilla thing unchanged");
        }
        var missing=new SwitchboardCabinet();var original=new SelectionInstance{Bounds=new Bounds(new Vector3(),new Vector3(9,9,9))};CabinetFrameSelection.AfterSelection(missing,ref original);Near(original.Bounds.size.x,9,"missing frame preserves native selection");
    }
    static void Main()
    {
        foreach(bool medium in new[]{false,true})foreach(bool reverse in new[]{false,true})
        {
            float k=medium?2:1;
            var cabinet=new Structure();cabinet.gameObject.layer=17;
            var model=new GameObject("SwitchboardModel");model.transform.SetParent(cabinet.transform,false);
            // Both reverse variants use this same model-local geometry; their
            // model transform carries the orientation in the native game.
            model.transform.RotationMarker=reverse?180:0;
            var left=Edge(model.transform,"FrameLeft",new Vector3(-.185f*k,0,.015f),new Vector3(.02f*k,.48f*k,.03f));
            var right=Edge(model.transform,"FrameRight",new Vector3(.185f*k,0,.015f),new Vector3(.02f*k,.48f*k,.03f));
            var top=Edge(model.transform,"FrameTop",new Vector3(0,.23f*k,.015f),new Vector3(.35f*k,.02f*k,.03f));
            var bottom=Edge(model.transform,"FrameBottom",new Vector3(0,-.23f*k,.015f),new Vector3(.35f*k,.02f*k,.03f));
            cabinet.BuildStates[0].Colliders.AddRange(new[]{left,right,top,bottom});
            CabinetFrameTarget.Install(cabinet);
            var target=model.transform.Find("FrameConstructionTarget");var hit=target.GetComponent<BoxCollider>();
            Near(hit.size.x,.35f*k,"opening width");Near(hit.size.y,.44f*k,"opening height");Near(hit.size.z,.002f,"thin selection plane");
            Near(hit.center.x,0,"horizontal center");Near(hit.center.y,0,"vertical center");Near(hit.center.z,.015f,"frame plane");
            Check(hit.isTrigger,"selection must not create a solid obstruction");Check(!hit.enabled,"prefab/cursor target starts disabled");
            Check(target.gameObject.layer==17,"native cursor hit layer");Check(target.parent==model.transform,"orientation inheritance");Check(target.parent.RotationMarker==(reverse?180:0),"reverse orientation retained");
            Check(target.gameObject.Components.Count==1,"no renderer or extra physical component");
            Check(cabinet.BuildStates[0].Colliders.Count==5,"four physical frame edges retained");
            Check(cabinet.BuildStates[1].Colliders.Count==0&&cabinet.BuildStates[2].Colliders.Count==0,"completed/legacy cover states do not own target");
            // Exercise native OnMyState collider-list semantics through complete,
            // legacy cover, dismantle and restore transitions.
            foreach(int state in new[]{0,1,2,1,0,1,0})
            {
                for(int i=0;i<cabinet.BuildStates.Count;i++)foreach(var c in cabinet.BuildStates[i].Colliders)c.enabled=i==state;
                Check(hit.enabled==(state==0),"frame-only activation across build/deconstruct/load states");
            }
            // Centre and near-corner aim points are all within the opening.
            foreach(float x in new[]{-.174f*k,0,.174f*k})foreach(float y in new[]{-.219f*k,0,.219f*k})
                Check(Math.Abs(x-hit.center.x)<hit.size.x*.5f&&Math.Abs(y-hit.center.y)<hit.size.y*.5f,"full opening aim coverage");
        }
        SelectionChecks();
        Console.WriteLine($"{checks} frame construction target and tight selection checks passed for Small, Medium and both reverse variants.");
    }
}
namespace UnityEngine
{
    public struct Vector3 {public float x,y,z;public Vector3(float x,float y,float z){this.x=x;this.y=y;this.z=z;}}
    public class Component {public GameObject gameObject;public Transform transform=>gameObject.transform;public T GetComponent<T>() where T:Component=>gameObject.GetComponent<T>();}
    public class Transform:Component
    {
        public Matrix4x4 worldToLocalMatrix=Matrix4x4.Identity,localToWorldMatrix=Matrix4x4.Identity;
        public Transform parent;public int RotationMarker;public readonly List<Transform> Children=new();
        public void SetParent(Transform value,bool worldPositionStays){parent=value;value.Children.Add(this);}
        public Transform Find(string name){var parts=name.Split('/');Transform t=this;foreach(var part in parts){t=t.Children.Find(c=>c.gameObject.name==part);if(t==null)return null;}return t;}
    }
    public class GameObject
    {
        public string name;public int layer;public Transform transform;public readonly List<Component> Components=new();
        public GameObject(string name){this.name=name;transform=new Transform{gameObject=this};}
        public T AddComponent<T>() where T:Component,new(){var c=new T{gameObject=this};Components.Add(c);return c;}
        public T GetComponent<T>() where T:Component=>(T)Components.Find(c=>c is T);
    }
    public class Collider:Component {public bool enabled=true,isTrigger;}
    public class BoxCollider:Collider {public Vector3 center,size;}
}
namespace Assets.Scripts.Objects
{
    public class BuildState {public List<Collider> Colliders=new();}
    public class Thing:Component {}
    public class SelectionInstance {public Bounds Bounds;public long ParentThingRefernceId;public int InteractableId;public Vector3 Position;}
    public class Structure:Thing
    {
        public List<BuildState> BuildStates=new(){new(),new(),new()};
        public Structure(){gameObject=new GameObject("Cabinet");}
    }
}

namespace UnityEngine
{
    public struct Bounds {public Vector3 center,size;public Bounds(Vector3 c,Vector3 s){center=c;size=s;}}
    public class Mesh {public Bounds bounds;}
    public class MeshFilter:Component {public Mesh sharedMesh;}
    public struct Matrix4x4
    {
        internal System.Numerics.Matrix4x4 Value;
        public static Matrix4x4 Identity=>new(){Value=System.Numerics.Matrix4x4.Identity};
        public static Matrix4x4 Translate(float x,float y,float z)=>new(){Value=System.Numerics.Matrix4x4.CreateTranslation(x,y,z)};
        public static Matrix4x4 Flip(bool reverse)=>new(){Value=System.Numerics.Matrix4x4.CreateScale(reverse?-1:1,1,reverse?-1:1)};
        public static Matrix4x4 operator *(Matrix4x4 a,Matrix4x4 b)=>new(){Value=b.Value*a.Value};
    }
}
namespace ModularSwitchboards
{
    public class SwitchboardCabinet:Structure {public int CurrentBuildStateIndex;public bool IsCursor;}
    public static class CabinetWallMount
    {
        public static Bounds TransformedBounds(Bounds b,Matrix4x4 matrix)
        {
            var min=new System.Numerics.Vector3(float.MaxValue);var max=new System.Numerics.Vector3(float.MinValue);
            foreach(int x in new[]{-1,1})foreach(int y in new[]{-1,1})foreach(int z in new[]{-1,1})
            {
                var v=System.Numerics.Vector3.Transform(new System.Numerics.Vector3(b.center.x+x*b.size.x*.5f,b.center.y+y*b.size.y*.5f,b.center.z+z*b.size.z*.5f),matrix.Value);
                min=System.Numerics.Vector3.Min(min,v);max=System.Numerics.Vector3.Max(max,v);
            }
            return new Bounds(new Vector3((max.X+min.X)*.5f,(max.Y+min.Y)*.5f,(max.Z+min.Z)*.5f),new Vector3(max.X-min.X,max.Y-min.Y,max.Z-min.Z));
        }
    }
}
