# Local 1.0.99 — frame targeting (not uploaded)

Base: accepted/published 1.0.98. The abandoned native-tool-material experiment is stored in work/abandoned-native-tool-preview199 and is not included.

Added CabinetFrameTarget.Install after MediumGeometry.Install. A thin trigger fills the actual opening derived from four edge colliders, parented to SwitchboardModel. Only build-state 0 owns it; native UpdateStateVisualizer enables/disables it. Native CacheColliders registers all child colliders. CursorManager native raycast uses default trigger query behavior; reference Assembly-CSharp does not override Physics.queriesHitTriggers. Trigger adds no solid collision.

Native-reference Release build: 0 warnings/errors.
201 actual helper checks (Unity/native stubs): Small/Medium/reverse dimensions, inherited orientation, full opening coverage, trigger/nonphysical setup, initial disabled state, only-state-0 registration, four physical frame edges preserved, native-style transition sequences 0/1/2/1/0.
In-game aiming, native runtime state transitions, save reload and multiplayer are not executable locally and remain to confirm. Accepted 1.0.98 preview source checked byte-for-byte unchanged.

Latest steering: tighten the yellow frame selection box. CabinetFrameSelection postfix on regular Thing.GetSelection() modifies only result.Bounds for actual SwitchboardCabinet state0 (not cursor). Derives current root-local bounds from frame mesh/transform; follows reverse orientation and wall-fit shifts. Actual object bounds/grid/physics untouched. Selection checks cover Small/Medium, reverse, wall shifts, unchanged owner/action/pose, exclusion of states1/2/-1, cursors and vanilla objects.
