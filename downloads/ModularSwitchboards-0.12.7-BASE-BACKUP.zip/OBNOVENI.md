# Záloha potvrzeného základu — Modular Switchboards 0.12.7

Datum: 17. 10. 2026. Uživatel potvrdil vzhled ve hře jako základ před další prací na IN.

Obsah: původní instalační test ZIP, původní source ZIP, jejich dokumentace a SHA-256 kontrolní součty. ZIPy jsou beze změny oproti publikované 0.12.7.

Stav: bílá skříň s původním vnitřkem, integrovaná šedá zadní část podle APC včetně zkosení, původní zadní krabička se symbolem blesku a šrouby, celé zaoblení a zaslepené boky po konektorech. Žádné vnější přípojky; vstup IN se teprve bude řešit. Elektrické propojení ani ochrana jističů nejsou implementované.

Obnovení modu: vypni hru, rozbal z této zálohy ModularSwitchboards-0.12.7-test.zip a nahraď složku ModularSwitchboards v Documents/My Games/Stationeers/mods/. Zachovej původní závislosti. Klient i server musí mít stejný mod.

Tato záloha obsahuje mod a jeho zdrojáky; uložený herní svět v ní není, nebyl nám dodán.
