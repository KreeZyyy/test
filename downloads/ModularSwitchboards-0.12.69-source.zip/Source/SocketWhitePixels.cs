using System;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class SocketWhitePixels
    {
        internal static Color Grey(Color pixel)
        {
            float hi=Math.Max(pixel.r,Math.Max(pixel.g,pixel.b)),lo=Math.Min(pixel.r,Math.Min(pixel.g,pixel.b));
            // Preserve gold contacts, dark recesses and transparency. Only neutral
            // light casing pixels are recoloured; source UVs and shader stay native.
            if(pixel.a<=0||lo<.15f||hi-lo>.09f)return pixel;
            return new Color(pixel.r*.25f,pixel.g*.25f,pixel.b*.25f,pixel.a);
        }
    }
}
