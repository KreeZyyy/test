using System;using System.Linq;using ModularSwitchboards;using UnityEngine;using Assets.Scripts.Objects;
namespace UnityEngine{public struct Vector3{public float x,y,z;public Vector3(float a,float b,float c){x=a;y=b;z=c;}public override string ToString()=>$"{x},{y},{z}";}public struct Bounds{public Vector3 center,size;public Bounds(Vector3 c,Vector3 s){center=c;size=s;}}public static class Debug{public static void Log(string s){}}}
namespace Assets.Scripts.Objects{public enum ConnectionRole{Input,Output,Output2,Waste}public class Structure{public string PrefabName;public Bounds Bounds;}}
namespace ModularSwitchboards{public static class SwitchboardsMod{public const string MediumCabinetName="medium",MediumReverseCabinetName="mediumreverse",MediumCombinerName="mediumcombiner",MediumCombinerReverseName="mediumcombinerreverse";}internal static class DoorModuleLayout{internal const float Pitch=.1f,Spacing=.024f;}public struct WireRect{public float Left,Right,Bottom,Top;public WireRect(float l,float r,float b,float t){Left=l;Right=r;Bottom=b;Top=t;}}}
class Program{static int n;static void Check(bool v,string why){n++;if(!v)throw new Exception(why);}static void Main(){
const string large="StructureModularSwitchboardLarge";
foreach(float width in new[]{.8f,1f,1.2f})foreach(float height in new[]{1.5f,1.8f,2f}){
var bounds=new Bounds(new Vector3(0,height*.5f,.25f),new Vector3(width,height,.5f));LargeCabinetDimensions.Measure(new Structure{PrefabName="StructureStorageLocker",Bounds=bounds});
Check(CabinetShape.Width(large)==width&&CabinetShape.Height(large)==height,"Locker dimensions changed");Check(CabinetShape.OffsetY(large)==height*.5f,"standing origin lost");
var ports=LargeCabinetDimensions.TopBodyCells();Check(ports.Length==4&&ports.Select(v=>v.ToString()).Distinct().Count()==4,"top port body cells overlap");Check(ports.All(v=>v.y==ports[0].y),"ports are not all at the top");
var rows=CabinetShape.Rows(large);Check(rows.Length==4&&rows.Distinct().Count()==4&&rows.SequenceEqual(rows.OrderBy(x=>x)),"four ordered rows");
Check(rows.All(r=>Math.Abs(r*.0018f)+.08f<height*.5f-.10f),"row overlaps terminal strip or frame");
Check(CabinetShape.FrameKits(large)==6&&CabinetShape.PlasticSheets(large)==10,"prototype costs");Check(CabinetShape.OutputCount(large)==3,"port count");
var cover=CoverMemory.Fresh(new InnerCoverLayout.Panel(LargeCabinetDimensions.CoverWidth,LargeCabinetDimensions.CoverHeight,.1015f,.002f),4);
Check(cover.Width<width*.97f&&cover.Height<height*.976f,"Large cover intersects stretched housing/frame");
Check(cover.FullSlots==DinLayout.FullModuleCount(CabinetShape.RailWidth(large)),"cover/rail slot mismatch");Check(cover.LabelRows.SequenceEqual(rows.Select(y=>y*4)),"cover/rail row mismatch");
foreach(var y in rows){cover.Labels=new[]{new CoverLabelMemory{X=90,Y=y*4,Width=2,Text="Large"}};cover.Validate();var restored=CoverMemory.Unpack(cover.Pack());Check(restored.Pack()==cover.Pack(),"Large cover save/round trip");}
for(int i=0;i<4;i++){var t=CabinetShape.Terminal(large,i);Check(t.y>rows.Max()*.0018f+.1f&&Math.Abs(t.x)<width*.5f-.05f,"terminal outside cabinet or at lower edge");}
}
Check(CabinetShape.Rows("small").SequenceEqual(new[]{-60,60}),"Small changed");Check(CabinetShape.Rows("medium").SequenceEqual(new[]{-150,0,150}),"Medium changed");Check(CabinetShape.FrameKits("small")==1&&CabinetShape.FrameKits("medium")==3,"existing economy changed");
foreach(var size in new[]{new Vector3(0,2,.5f),new Vector3(1,float.NaN,.5f),new Vector3(1,2,-1)}){bool rejected=false;try{LargeCabinetDimensions.Configure(new Bounds(new Vector3(),size));}catch(InvalidOperationException){rejected=true;}Check(rejected,"invalid dimensions accepted");}
Console.WriteLine(n+" Large layout, unchanged Small/Medium, terminal, cover/save checks passed.");}}
