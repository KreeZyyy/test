"""Layered face-up modules plus Cable Analyzer; fixed offline layout with full clearance."""
from pathlib import Path
import json,subprocess,sys,random
from kit_layout import rotate,add,bounds,obb,separate,inside
root=Path(__file__).resolve().parents[1];f=root/'Art/ModuleKit/source.json';data=json.loads(f.read_text())
packed=json.loads((root/'Art/ModuleKit/packed-contents.json').read_text());pv=packed['vertices']
def group(x):return 0 if x<-.106 else 1 if x<.005 else 2
parts={}
for groupid in range(3):
 ids=[i for i,p in enumerate(pv)if group(p[0])==groupid];mapping={old:i for i,old in enumerate(ids)}
 center=[sum(pair)*.5 for pair in bounds([pv[i]for i in ids])]
 points=[[q*.66 for q in rotate([pv[i][k]-center[k]for k in range(3)],[-75,0,0])]for i in ids]
 ts={}
 for role,indices in packed['triangles'].items():
  ts[role]=[mapping[j]for j in indices if group(pv[j][0])==groupid]
 parts[groupid]={'vertices':points,'triangles':ts}
# Add the original production Analyzer body and display/lightning face, not the yellow native casing.
geo=json.loads((root/'Art/CatalogGeometry.json').read_text());front=geo['analyserFront'];ts=front['triangles']['0'];components=[]
for i in range(0,len(ts),3):
 points={tuple(round(v,6)for v in front['vertices'][j])for j in ts[i:i+3]};hits=[k for k,c in enumerate(components)if points&c[0]]
 if not hits:components.append((points,{i//3}))
 else:
  n=hits[0];components[n][0].update(points);components[n][1].add(i//3)
  for k in reversed(hits[1:]):components[n][0].update(components[k][0]);components[n][1].update(components[k][1]);components.pop(k)
lightning=next(c[1]for c in components if len(c[1])==20)
an={'vertices':[],'triangles':{str(k):[]for k in range(9)}}
for name in ['analyserBody','analyserFront']:
 d=geo[name];offset=len(an['vertices']);an['vertices'].extend([[p[k]*[2.25,1.35,1.15][k]*2.45*.66 for k in range(3)]for p in d['vertices']])
 for role,indices in d['triangles'].items():
  for i in range(0,len(indices),3):
   r=int(role)if name=='analyserBody'else 7 if int(role)==2 else 8 if i//3 in lightning else 5
   an['triangles'][str(r)].extend(offset+j for j in indices[i:i+3])
center=[sum(b)*.5 for b in bounds(an['vertices'])];an['vertices']=[rotate([p[k]-center[k]for k in range(3)],[-90,0,0])for p in an['vertices']];parts[3]=an
rng=random.Random(1315)
for restart in range(40):
 layout=[];packed_boxes=[]
 for groupid in [2,1,0,0,0]:
  for attempt in range(1500):
   x,z=rng.uniform(-.145,.145),rng.uniform(-.145,.145);yaw=rng.uniform(-80,80);floor=rng.uniform(.077,.089)
   points=parts[groupid]['vertices'];rotated=[rotate(p,[0,yaw,0])for p in points];low=min(p[1]for p in rotated)
   body=obb(points,[0,yaw,0],[x,floor-low,z])
   if not inside(body['corners'])or not all(separate(body,other)for other in packed_boxes):continue
   packed_boxes.append(body);layout.append((groupid,[x,z],yaw,floor));break
  else:break
 if len(layout)==5:break
assert len(layout)==5
# Two upper pieces rest above the lower parts and make the crate visibly fuller.
layout.extend([(3,[-.075,-.025],-5,.244),(0,[.118,.012],9,.244)])
contents={'vertices':[],'triangles':{str(k):[]for k in range(9)}};placed=[];description=[]
for groupid,(x,z),yaw,floor in layout:
 part=parts[groupid];points=part['vertices'];angles=[0,yaw,0];rotated=[rotate(p,angles)for p in points];low=min(p[1]for p in rotated);shift=[x,floor-low,z]
 world=[add(p,shift)for p in rotated];body=obb(points,angles,shift)
 assert inside(body['corners']),('wall',groupid,bounds(world))
 assert all(separate(body,other)for other in placed),('overlap',groupid,x,z)
 placed.append(body);offset=len(contents['vertices']);contents['vertices'].extend(world)
 for role,indices in part['triangles'].items():contents['triangles'][role].extend(offset+j for j in indices)
 description.append({'part':['breaker','empty fuse holder','empty battery backup','Cable Analyzer'][groupid],'yaw':yaw,'floor':floor,'positionXZ':[x,z],'obb':body})
data['contents']=contents;data['layout']=description;data['layoutPolicy']='Five lower and two upper face-up pieces including Analyzer; conservative wall/corner and pair separation.'
f.write_text(json.dumps(data));subprocess.run([sys.executable,str(root/'Tools/create_module_kit.py')],check=True)
print('Seven layered modules including Analyzer: wall/corner and 21 pair separations passed.')
