# Original APC socket in0.12.81

The user requested the original APC appearance including gold contacts. Gray rectangular pad replacements were removed. BatterySocket.meshbin now uses BS02:4-byte magic, int32 triangleCount=134, then byte role plus3vertices of5float32 values each (xyzuv). All86casing/48contact triangles retain their original positions and winding. Per-corner UVs were matched to the unique original APC root triangle in the supplied reference using xyz rounded to7decimals. No UV seams were merged.

Reference:ModularSwitchboards-APC-reference.json, version0.12.2, prefabStructureAreaPowerControl. SHA256:9fbc7208f82984751f879ee86ab237a6480d1734bf2b125c7cda74a1634288ac.

BatterySocketSurfaces captures the actual sourceAPC MeshRenderer material, global/index0property blocks and lighting/shadow flags. Both visible submeshes use that exact native material. No shader/material/texture/RGB overrides or cabinet palette blocks are applied. The original APC assets are not modified. The functional slot transform and its fitting rules are unchanged.
