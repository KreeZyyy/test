using System;using System.Collections.Generic;using UnityEngine;namespace ModularSwitchboards {static class DinBatteryModel{
        internal static Mesh Build()
        {
            // Build the actual breaker casing at two-position width. The builder
            // omits spindle bearings and cuts only the native battery aperture.
            return BatterySocketSurround.Add(DinBreakerModel.Build(DinBatteryLayout.Width,DinBatteryLayout.CenterX,true),new Vector3(-.0968359262f,-.115021147f,.129955426f),ApcBatteryRegion.FitScale(new Vector3(ApcBatteryRegion.NativeSocketHeight,ApcBatteryRegion.NativeSocketHeight,0)));
        }
}
    internal static class ModuleLayout
    {
        internal static bool Fits(int x, int y, int z, int rotation, int width, int capacity)
            => x % 10 == 0 && y == 0 && z == 0 && rotation == 0 && width > 0 &&
                x >= 0 && x / 10 + width <= capacity;
        internal static bool Overlaps(int start, int width, int other, int otherWidth)
            => start < other + otherWidth && other < start + width;
    }

}