using System;
using UnityEngine;
using UnityEngine.Rendering;
namespace ModularSwitchboards
{
    // Use the actual APC surface, including its atlas, shader state and blocks.
    // The gold comes from the original texture/UVs, not an invented RGB material.
    internal static class BatterySocketSurfaces
    {
        private static Material material;
        private static MaterialPropertyBlock global,indexed;
        private static bool receiveShadows;
        private static ShadowCastingMode shadowCasting;
        private static LightProbeUsage lightProbes;
        private static ReflectionProbeUsage reflectionProbes;
        internal static void Capture(MeshRenderer renderer)
        {
            if(material!=null)return;
            if(renderer==null||renderer.sharedMaterials.Length!=1||renderer.sharedMaterials[0]==null)
                throw new InvalidOperationException("Original APC socket renderer/material layout unavailable");
            material=renderer.sharedMaterials[0];
            global=new MaterialPropertyBlock();renderer.GetPropertyBlock(global);
            indexed=new MaterialPropertyBlock();renderer.GetPropertyBlock(indexed,0);
            receiveShadows=renderer.receiveShadows;shadowCasting=renderer.shadowCastingMode;
            lightProbes=renderer.lightProbeUsage;reflectionProbes=renderer.reflectionProbeUsage;
        }
        internal static void Apply(MeshRenderer renderer)
        {
            if(material==null)throw new InvalidOperationException("Original APC material not captured");
            renderer.sharedMaterials=new[]{material,material};renderer.SetPropertyBlock(global);
            for(int i=0;i<2;i++)renderer.SetPropertyBlock(indexed.isEmpty?null:indexed,i);
            renderer.receiveShadows=receiveShadows;renderer.shadowCastingMode=shadowCasting;
            renderer.lightProbeUsage=lightProbes;renderer.reflectionProbeUsage=reflectionProbes;
        }
    }
}
