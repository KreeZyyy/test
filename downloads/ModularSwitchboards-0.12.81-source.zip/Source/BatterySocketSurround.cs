using System.Collections.Generic;
using UnityEngine;
namespace ModularSwitchboards
{
    // Close the gap between the rectangular DIN cutout and the native octagonal
    // APC rim. The original socket and the opening inside it remain untouched.
    internal static class BatterySocketSurround
    {
        internal static Mesh Add(Mesh mesh,Vector3 sourceCenter,float scale)
        {
            var v=new List<Vector3>(mesh.vertices);var n=new List<Vector3>(mesh.normals);
            var t=new List<int>[5];for(int i=0;i<5;i++)t[i]=new List<int>(mesh.GetTriangles(i));
            float x=(ApcBatteryRegion.SocketHeight+.0006f)*.5f/DinBreakerModel.VisualScale.x;
            float y=(ApcBatteryRegion.SocketHeight+.0006f)*.5f/DinBreakerModel.VisualScale.y;
            float cx=DinBatteryLayout.CenterX,z=ApcBatteryRegion.RimPlane,back=z-.001f;
            var outer=new[]{new Vector3(cx-x,-y,z),new Vector3(cx+x,-y,z),new Vector3(cx+x,-y,z),new Vector3(cx+x,y,z),
                new Vector3(cx+x,y,z),new Vector3(cx-x,y,z),new Vector3(cx-x,y,z),new Vector3(cx-x,-y,z)};
            // Boundary edges of the original APC mesh at sourceZ .1980004.
            var source=new[]{new Vector3(-.1400558f,-.1690452f,.1980004f),new Vector3(-.0536169f,-.1690452f,.1980004f),
                new Vector3(-.0428130f,-.1582416f,.1980004f),new Vector3(-.0428130f,-.0718014f,.1980004f),
                new Vector3(-.0536169f,-.0609978f,.1980004f),new Vector3(-.1400558f,-.0609978f,.1980004f),
                new Vector3(-.1508597f,-.0718014f,.1980004f),new Vector3(-.1508597f,-.1582416f,.1980004f)};
            var inner=new Vector3[8];for(int i=0;i<8;i++)inner[i]=ApcBatteryRegion.Map(source[i],sourceCenter,0,scale);
            for(int i=0;i<8;i++)
            {
                int j=(i+1)%8;
                var a=outer[i];var b=outer[j];var c=inner[j];var d=inner[i];
                Quad(v,n,t[3],a,b,c,d,Vector3.forward);
                var ab=new Vector3(a.x,a.y,back);var bb=new Vector3(b.x,b.y,back);
                var cb=new Vector3(c.x,c.y,back);var db=new Vector3(d.x,d.y,back);
                Quad(v,n,t[3],ab,bb,cb,db,Vector3.back);
                var outward=new Vector3((a.x+b.x)*.5f-cx,(a.y+b.y)*.5f,0);
                Quad(v,n,t[3],a,ab,bb,b,outward);
                var inward=new Vector3(cx-(c.x+d.x)*.5f,-(c.y+d.y)*.5f,0);
                Quad(v,n,t[3],d,c,cb,db,inward);
            }
            mesh.SetVertices(v);mesh.SetNormals(n);for(int i=0;i<5;i++)mesh.SetTriangles(t[i],i);
            CabinetGeometry.ApplyNativeUv(mesh);mesh.RecalculateBounds();return mesh;
        }
        private static void Quad(List<Vector3> v,List<Vector3> n,List<int> t,Vector3 a,Vector3 b,Vector3 c,Vector3 d,Vector3 desired)
        {Triangle(v,n,t,a,b,c,desired);Triangle(v,n,t,a,c,d,desired);}
        private static void Triangle(List<Vector3> v,List<Vector3> n,List<int> t,Vector3 a,Vector3 b,Vector3 c,Vector3 desired)
        {
            var cross=Vector3.Cross(b-a,c-a);if(cross.x*cross.x+cross.y*cross.y+cross.z*cross.z<1e-20f)return;
            if(cross.x*desired.x+cross.y*desired.y+cross.z*desired.z<0){var swap=b;b=c;c=swap;cross=Vector3.Cross(b-a,c-a);}
            int start=v.Count;v.AddRange(new[]{a,b,c});var normal=cross.normalized;n.AddRange(new[]{normal,normal,normal});t.AddRange(new[]{start,start+1,start+2});
        }
    }
}
