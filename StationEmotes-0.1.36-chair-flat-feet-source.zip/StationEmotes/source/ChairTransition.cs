using System;
using Assets.Scripts;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Inventory;
using Assets.Scripts.UI;
using Assets.Scripts.Util;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Entities;
using Assets.Scripts.Objects.Structures;
using HarmonyLib;
using UnityEngine;
using UnityEngine.Animations;
using UnityEngine.Experimental.Animations;
using UnityEngine.Playables;
namespace StationEmotes
{
 [DefaultExecutionOrder(32000)]
 public sealed class ChairTransition:MonoBehaviour
 {
  internal sealed class Snapshot
  {
   internal Human Human;internal Animator Animator;internal Transform Visual;internal Seat Seat;internal bool Entering;
   internal Vector3 Position,Root,LocalPosition,Front,CameraPosition;internal Quaternion Rotation,LocalRotation,CameraRotation;
   internal Transform[] Bones;internal Quaternion[] Rotations;internal ChairPoseAnchor TargetPose;internal ChairPlan Plan;internal ChairStandingPose Standing;internal Vector3 HipPosition,SourceTorsoDirection;internal Vector3[] LegUpper=new Vector3[2],LegKnee=new Vector3[2];internal Quaternion HipRotation;internal Quaternion[] SourceTorso;
   internal Vector3 HipsLocal,LeftFootPosition,RightFootPosition;internal Quaternion LeftFootRotation,RightFootRotation;
  }
  private static readonly HumanBodyBones[] Body={HumanBodyBones.Hips,HumanBodyBones.Spine,HumanBodyBones.Chest,HumanBodyBones.Head,
   HumanBodyBones.LeftUpperArm,HumanBodyBones.LeftLowerArm,HumanBodyBones.LeftHand,
   HumanBodyBones.RightUpperArm,HumanBodyBones.RightLowerArm,HumanBodyBones.RightHand,
   HumanBodyBones.LeftUpperLeg,HumanBodyBones.LeftLowerLeg,HumanBodyBones.LeftFoot,
   HumanBodyBones.RightUpperLeg,HumanBodyBones.RightLowerLeg,HumanBodyBones.RightFoot};
  private PlayableGraph graph;private AnimationScriptPlayable playable;private ChairJob job;
  private Snapshot snapshot;private Human human;private Slot expectedSlot;private Vector3 endRoot;private float elapsed,waitTime;private bool paused,slow;private int stableFrames,lastNativeEvaluation;private Quaternion facing;
  private ChairCamera overview;private ChairFootwork footwork;
  private Transform visual;private Vector3 baseLocal;private Quaternion baseRotation;private bool visualApplied;
  internal bool Active=>graph.IsValid();
  internal string Description=>snapshot==null?"":(snapshot.TargetPose==null?"capture native pose":snapshot.Plan.Stage(elapsed))+(paused?" | PAUSED":slow?" | 0.25x":"");
  internal static bool Ordinary(Thing thing)=>thing!=null&&thing.GetType()==typeof(Seat);
  internal static Vector3 FrontPoint(Seat seat)=>seat.ExitPosition;
  internal static bool InFront(Human h,Seat seat)
  {
   if(!h.IsGrounded(h.AllButPlayerImmune,.12f))return false;
   var point=FrontPoint(seat);var forward=Vector3.ProjectOnPlane(point-seat.ThingTransform.position,Vector3.up);
   if(forward.sqrMagnitude<.01f)forward=Vector3.ProjectOnPlane(seat.ThingTransform.forward,Vector3.up);
   if(forward.sqrMagnitude<.01f)return false;
   forward.Normalize();var right=Vector3.Cross(Vector3.up,forward);var delta=h.ThingTransform.position-point;
   return ChairTransitionPolicy.Front(Vector3.Dot(delta,right),Vector3.Dot(delta,forward),delta.y);
  }
  internal static Snapshot Capture(DynamicThing thing,Seat seat,bool entering)
  {
   if(GameManager.IsBatchMode||GameManager.GameState!=GameState.Running||!(thing is Human h)||h.State!=EntityState.Alive||h.EmoteController==null)return null;
   try
   {
    var previous=h.GetComponent<ChairTransition>();
    if(previous?.Active==true){previous.Stop();return null;}
    if(entering&&(h.EmoteController.GetComponent<HeldEmote>()?.Active==true||h.EmoteController.GetComponent<GesturePose>()?.Active==true||h.EmoteController.GetComponent<HandsUpPose>()?.Active==true||h.EmoteController.GetComponent<RobotDance>()?.Active==true))
    {Plugin.Log.LogInfo("Chair uses native entry while another emote is active; standing calibration skipped.");return null;}
    var a=Plugin.BodyAnimator.GetValue(h.EmoteController) as Animator;var root=h.CharacterRotationY;
    if(a==null||!a.isHuman||!a.isActiveAndEnabled||root==null||root==h.ThingTransform||!root.IsChildOf(h.ThingTransform))return null;
    // Move the common visual parent, not the pelvis alone: head, hair, helmet and suit stay together.
    if(h.HeadBone==null||!h.HeadBone.IsChildOf(root)){Plugin.Log.LogWarning("Chair skipped: head is outside the common visual root.");return null;}
    var s=new Snapshot{Human=h,Animator=a,Visual=root,Seat=seat,Entering=entering,Position=root.position,Rotation=root.rotation,
     Root=h.ThingTransform.position,LocalPosition=root.localPosition,LocalRotation=root.localRotation,
     Front=FrontPoint(seat)+(root.position-h.ThingTransform.position),Bones=new Transform[Body.Length],Rotations=new Quaternion[Body.Length]};
    for(int i=0;i<Body.Length;i++){s.Bones[i]=a.GetBoneTransform(Body[i]);if(s.Bones[i]!=null)s.Rotations[i]=s.Bones[i].localRotation;}
    if(s.Bones[0]==null||s.Bones[10]==null||s.Bones[11]==null||s.Bones[12]==null||s.Bones[13]==null||s.Bones[14]==null||s.Bones[15]==null)return null;s.HipsLocal=s.Bones[0].localPosition;
    s.LegUpper[0]=s.Bones[10].position;s.LegUpper[1]=s.Bones[13].position;
    s.LegKnee[0]=s.Bones[11].position;s.LegKnee[1]=s.Bones[14].position;
    s.LeftFootPosition=s.Bones[12].position;s.RightFootPosition=s.Bones[15].position;
    s.LeftFootRotation=s.Bones[12].rotation;s.RightFootRotation=s.Bones[15].rotation;
    s.HipPosition=s.Bones[0].position;s.HipRotation=s.Bones[0].rotation;
    s.SourceTorsoDirection=(Quaternion.Inverse(ChairPoseFrame.Upright(s.Rotation))*(s.Bones[3].position-s.HipPosition)).normalized;
    s.Standing=entering?ChairStandingPose.Capture(s):ChairStandingPose.Get(h);
    if(s.Standing==null){Plugin.Log.LogInfo("Chair exit uses native movement: enter a chair once to calibrate the standing pose.");return null;}
    s.SourceTorso=new Quaternion[s.Standing.Torso.Length];
    for(int i=0;i<s.SourceTorso.Length;i++)s.SourceTorso[i]=s.Standing.Torso[i].localRotation;
    if(h==InventoryManager.ParentHuman&&CameraController.CurrentCamera!=null){s.CameraPosition=CameraController.CurrentCamera.transform.position;s.CameraRotation=CameraController.CurrentCamera.transform.rotation;}
    return s;
   }
   catch(Exception e){Plugin.Log.LogWarning("Chair capture skipped: "+e);return null;}
  }
  internal static void Complete(Snapshot s,bool success)
  {
   if(s==null||!success||s.Human==null||!ChairTransitionPolicy.SafeDistance((s.Human.ThingTransform.position-s.Root).sqrMagnitude))return;
   var c=s.Human.GetComponent<ChairTransition>()??s.Human.gameObject.AddComponent<ChairTransition>();c.Begin(s);
  }
  private void Begin(Snapshot s)
  {
   Stop();snapshot=s;human=s.Human;visual=s.Visual;expectedSlot=human.ParentSlot;endRoot=human.ThingTransform.position;
   baseLocal=s.LocalPosition;baseRotation=s.Entering?Quaternion.identity:visual.localRotation;
   facing=s.Entering?s.Seat.ThingTransform.rotation:s.Rotation;
   var travel=s.Entering?s.Front-s.Position:visual.position-s.Front;travel.y=0;
   float distance=travel.magnitude;
   if(!s.Entering)
   {
    var left=s.LeftFootPosition;var right=s.RightFootPosition;Vector3 tuck;
    for(int side=0;side<2;side++)
    {
     var ankle=side==0?left:right;
     float floor=s.Seat.ThingTransform.position.y+s.Standing.FloorRelativeToSeat[side]+s.Standing.Sole[side];
     if(ChairExitPlacement.TryTarget(s.LegUpper[side],s.LegKnee[side],ankle,floor,out tuck)){if(side==0)left=tuck;else right=tuck;}
    }
    var current=(left+right)*.5f;
    var expected=visual.position+facing*((s.Standing.Feet[0]+s.Standing.Feet[1])*.5f);
    var footTravel=expected-current;footTravel.y=0;distance=Mathf.Max(distance,footTravel.magnitude);
   }
   s.Plan=new ChairPlan(s.Entering,distance,Quaternion.Angle(s.Rotation,facing));
   if(s.Entering)ChairStandingPose.Remember(human,s.Standing);
   try
   {
    human.EmoteController.GetComponent<EmoteTransition>()?.Cancel();EmoteTransition.StopBody(human.EmoteController);
    job=new ChairJob{StartHips=s.HipsLocal};
    for(int i=0;i<s.Bones.Length;i++)if(s.Bones[i]!=null)job.Set(i,new PoseSlot{Handle=s.Animator.BindStreamTransform(s.Bones[i]),Rotation=s.Rotations[i]});
    job.Torso.Count=s.Standing.Torso.Length;
    for(int i=0;i<job.Torso.Count;i++)job.Torso.Set(i,new ChairTorsoSlot{Handle=s.Animator.BindStreamTransform(s.Standing.Torso[i])});
    graph=PlayableGraph.Create("StationEmotes staged chair transition");graph.SetTimeUpdateMode(DirectorUpdateMode.GameTime);
    playable=AnimationScriptPlayable.Create(graph,job,0);playable.SetProcessInputs(false);
    var output=AnimationPlayableOutput.Create(graph,"Chair transition",s.Animator);
    output.SetAnimationStreamSource(AnimationStreamSource.PreviousInputs);output.SetSortingOrder(1100);output.SetWeight(1);output.SetSourcePlayable(playable);
    elapsed=waitTime=0;stableFrames=lastNativeEvaluation=0;paused=false;slow=false;playable.Play();graph.Play();
    if(!s.Entering&&human==InventoryManager.ParentHuman&&CameraController.Instance!=null)CameraController.Instance.RotationY=s.Rotation.eulerAngles.y;
    overview=ChairCamera.Begin(human,s.Seat);footwork=null;
    Plugin.Log.LogInfo("Chair transition 0.1.36: waiting for the native "+(s.Entering?"seated":"standing")+" endpoint.");
   }
   catch(Exception e){Stop();Plugin.Log.LogWarning("Chair transition skipped: "+e);}
  }
  private bool Valid()=>human!=null&&human.State==EntityState.Alive&&GameManager.GameState==GameState.Running&&human.ParentSlot==expectedSlot&&(human.ThingTransform.position-endRoot).sqrMagnitude<=.09f&&snapshot.Seat!=null;
  private void RestoreVisual(){if(visualApplied&&visual!=null){visual.localPosition=baseLocal;visual.localRotation=baseRotation;}visualApplied=false;}
  private void Update()
  {
   if(!Active)return;RestoreVisual();
   if(!Valid()){Stop();return;}
   if(human==InventoryManager.ParentHuman&&Application.isFocused&&!InputWindowBase.IsInputWindow&&!ConsoleWindow.IsOpen)
   {
    if(Input.GetKeyDown(KeyCode.F8)){slow=!slow;Plugin.Log.LogInfo("Chair speed="+(slow?"quarter":"normal"));}
    if(Input.GetKeyDown(KeyCode.F7)){paused=!paused;Plugin.Log.LogInfo("Chair "+(paused?"paused":"resumed")+" at "+snapshot.Plan.Stage(elapsed));}
   }
   if(!paused&&!WorldManager.IsGamePaused)
   {
    if(snapshot.TargetPose==null)waitTime+=Time.deltaTime;
    else elapsed+=Time.deltaTime*(slow?.25f:1f);
   }
   var previousJob=playable.GetJobData<ChairJob>();job.Native=previousJob.Native;job.Torso=previousJob.Torso;job.NativeLocals=previousJob.NativeLocals;job.Evaluations=previousJob.Evaluations;
   job.Blend=ChairBodyPath.Posture(snapshot.Plan.Body(elapsed));
   job.UseEndpoint=snapshot.TargetPose!=null;
   if(job.UseEndpoint){job.FixedTarget=snapshot.TargetPose.Locals;job.EndpointRelease=snapshot.Plan.EndRelease(elapsed);}
   playable.SetJobData(job);
  }
  private void LateUpdate()
  {
   if(!Active)return;if(!Valid()){Stop();return;}
   float t=elapsed;var plan=snapshot.Plan;
   // Sample the canonical visual transform AFTER the game's camera/IK updates.
   baseLocal=visual.localPosition;baseRotation=visual.localRotation;
   var target=visual.position;var rotation=visual.rotation;
   var ran=playable.GetJobData<ChairJob>();var native=ran.Native;
   if(snapshot.TargetPose==null)
   {
    int wanted=snapshot.Entering?(int)MovementController.Mode.Seated:(int)MovementController.Mode.Animation;
    bool stable=snapshot.Animator.GetInteger(MovementController.ControlModeHash)==wanted;
    for(int layer=0;layer<snapshot.Animator.layerCount;layer++)stable&=!snapshot.Animator.IsInTransition(layer);
    if(!stable||!native.Ready)stableFrames=0;
    else if(ran.Evaluations>lastNativeEvaluation)stableFrames++;
    lastNativeEvaluation=ran.Evaluations;
    if(stableFrames>=2)
    {
     snapshot.TargetPose=new ChairPoseAnchor(native,ran.Torso,ran.NativeLocals,target,rotation);
     facing=ChairPoseFrame.Upright(rotation);
     float distance=snapshot.Plan.Distance;
     if(!snapshot.Entering)
     {
      for(int side=0;side<2;side++)
      {
       var ankle=side==0?snapshot.LeftFootPosition:snapshot.RightFootPosition;Vector3 tucked;
       float floor=snapshot.Seat.ThingTransform.position.y+snapshot.Standing.FloorRelativeToSeat[side]+snapshot.Standing.Sole[side];
       if(ChairExitPlacement.TryTarget(snapshot.LegUpper[side],snapshot.LegKnee[side],ankle,floor,out tucked))
       {var delta=(side==0?native.Left:native.Right)-tucked;delta.y=0;distance=Mathf.Max(distance,delta.magnitude);}
      }
     }
     snapshot.Plan=new ChairPlan(snapshot.Entering,distance,Quaternion.Angle(ChairPoseFrame.Upright(snapshot.Rotation),facing));
     footwork=new ChairFootwork(snapshot);
     Plugin.Log.LogInfo("Chair pose plan: walk="+snapshot.Plan.WalkSteps+", turn="+snapshot.Plan.TurnSteps+", duration="+snapshot.Plan.Duration.ToString("F2")+"; F8 slow / F7 pause");
     Plugin.Log.LogInfo("Chair anchors captured: source root up="+(snapshot.Rotation*Vector3.up).ToString("F3")+", target root up="+(rotation*Vector3.up).ToString("F3")+", body frame up="+(ChairPoseFrame.Upright(rotation)*Vector3.up).ToString("F3")+", target pelvis="+native.Hips.ToString("F3"));
    }
    else
    {
     if(waitTime>2f){Plugin.Log.LogWarning("Chair transition skipped: native endpoint did not settle.");Stop();return;}
     visual.SetPositionAndRotation(snapshot.Position,snapshot.Rotation);visualApplied=true;
     snapshot.Bones[0].SetPositionAndRotation(snapshot.HipPosition,snapshot.HipRotation);
     for(int i=0;i<snapshot.SourceTorso.Length;i++)if(snapshot.Standing.Torso[i]!=null)snapshot.Standing.Torso[i].localRotation=snapshot.SourceTorso[i];
     if(overview!=null)overview.Apply(visual,snapshot.Bones[0]);return;
    }
   }
   Vector3 p;Quaternion q;
   var front=snapshot.Front;front.y=snapshot.Entering?snapshot.Position.y:target.y;
   if(snapshot.Entering)
   {
    p=Vector3.Lerp(Vector3.Lerp(snapshot.Position,front,plan.Walk(t)),target,plan.Body(t));
    q=Quaternion.Slerp(snapshot.Rotation,facing,plan.Turn(t));
   }
   else
   {
    p=Vector3.Lerp(Vector3.Lerp(snapshot.Position,front,plan.Body(t)),target,plan.Walk(t));
    q=Quaternion.Slerp(snapshot.Rotation,facing,plan.Turn(t));
   }
   q=Quaternion.Slerp(q,rotation,plan.EndRelease(t));
   var camera=human==InventoryManager.ParentHuman&&!CameraController.CinematicMode?CameraController.CurrentCamera:null;
   Vector3 cameraP=Vector3.zero;Quaternion cameraQ=Quaternion.identity;
   if(camera!=null){cameraP=camera.transform.position;cameraQ=camera.transform.rotation;}
   if(!native.Ready&&t>.2f){Plugin.Log.LogWarning("Chair transition stopped: native pose stream unavailable.");Stop();return;}
   if(footwork!=null&&!footwork.Prepare(target,facing,native)){Stop();return;}
   if(footwork!=null)p+=footwork.WeightShift(t,q);
   visual.SetPositionAndRotation(p,q);visualApplied=true;
   footwork?.Apply(t,visual,facing,native,ran.Torso);
   if(overview!=null)overview.Apply(visual,snapshot.Bones[0]);
   else if(camera!=null)
   {
    float total=ChairTransitionPolicy.Ease(t/plan.Duration);
    if(CameraController.IsThirdPerson)camera.transform.position=cameraP+(p-target);
    else
    {
     var initial=Quaternion.Inverse(snapshot.Rotation)*(snapshot.CameraPosition-snapshot.Position);
     var final=Quaternion.Inverse(rotation)*(cameraP-target);
     var initialQ=Quaternion.Inverse(snapshot.Rotation)*snapshot.CameraRotation;
     var finalQ=Quaternion.Inverse(rotation)*cameraQ;
     var offset=Vector3.Lerp(initial,final,total);
     offset.y=Mathf.Lerp(initial.y,final.y,plan.Body(t));
     camera.transform.SetPositionAndRotation(p+q*offset,q*Quaternion.Slerp(initialQ,finalQ,total));
    }
    CameraController.CameraPosition=camera.transform.position;CameraController.CameraRotation=camera.transform.rotation;
   }
   if(t>=plan.Duration)Stop(true);
  }
  internal void Stop(bool completed=false)
  {
   var hips=completed&&snapshot!=null?snapshot.Bones[0]:null;
   var position=hips!=null?hips.position:Vector3.zero;var rotation=hips!=null?hips.rotation:Quaternion.identity;
   RestoreVisual();
   // Restoring a pitched native parent must not rotate the completed world-space endpoint a second time.
   if(hips!=null)hips.SetPositionAndRotation(position,rotation);
   if(graph.IsValid())graph.Destroy();overview?.Dispose();overview=null;footwork=null;human=null;snapshot=null;visual=null;
  }
  private void OnDisable()=>Stop();private void OnDestroy()=>Stop();
 }
 internal struct ChairJob:IAnimationJob
 {
  public Vector3 StartHips;public float Blend;public int Evaluations;public ChairNativePose Native;public ChairTorsoStream Torso;public ChairLocalPose NativeLocals,FixedTarget;public bool UseEndpoint;public float EndpointRelease;
  public PoseSlot A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P;
  public void Set(int i,PoseSlot s){switch(i){case 0:A=s;break;case 1:B=s;break;case 2:C=s;break;case 3:D=s;break;case 4:E=s;break;case 5:F=s;break;case 6:G=s;break;case 7:H=s;break;case 8:I=s;break;case 9:J=s;break;case 10:K=s;break;case 11:L=s;break;case 12:M=s;break;case 13:N=s;break;case 14:O=s;break;case 15:P=s;break;}}
  private PoseSlot Get(int i){switch(i){case 0:return A;case 1:return B;case 2:return C;case 3:return D;case 4:return E;case 5:return F;case 6:return G;case 7:return H;case 8:return I;case 9:return J;case 10:return K;case 11:return L;case 12:return M;case 13:return N;case 14:return O;default:return P;}}
  public void ProcessRootMotion(AnimationStream stream){}
  public void ProcessAnimation(AnimationStream stream)
  {
   Evaluations++;
   // Read the native endpoints before replacing any rotations or pelvis coordinates.
   Torso.Capture(stream);
   Native.Ready=false;
   if(A.Handle.IsValid(stream)&&D.Handle.IsValid(stream)&&K.Handle.IsValid(stream)&&L.Handle.IsValid(stream)&&M.Handle.IsValid(stream)&&N.Handle.IsValid(stream)&&O.Handle.IsValid(stream)&&P.Handle.IsValid(stream))
   {
    A.Handle.Resolve(stream);D.Handle.Resolve(stream);K.Handle.Resolve(stream);L.Handle.Resolve(stream);M.Handle.Resolve(stream);N.Handle.Resolve(stream);O.Handle.Resolve(stream);P.Handle.Resolve(stream);
    Native=new ChairNativePose{Ready=true,Head=D.Handle.GetPosition(stream),LeftUpper=K.Handle.GetPosition(stream),LeftKnee=L.Handle.GetPosition(stream),RightUpper=N.Handle.GetPosition(stream),RightKnee=O.Handle.GetPosition(stream),Hips=A.Handle.GetPosition(stream),HipRotation=A.Handle.GetRotation(stream),
     Left=M.Handle.GetPosition(stream),Right=P.Handle.GetPosition(stream),LeftRotation=M.Handle.GetRotation(stream),RightRotation=P.Handle.GetRotation(stream)};
   }
   for(int i=0;i<16;i++)
   {
    var bone=Get(i);if(!bone.Handle.IsValid(stream))continue;bone.Handle.Resolve(stream);
    var nativeLocal=bone.Handle.GetLocalRotation(stream);NativeLocals.Set(i,nativeLocal);
    var target=UseEndpoint?Quaternion.Slerp(FixedTarget.Get(i),nativeLocal,EndpointRelease):nativeLocal;
    var rotation=Quaternion.Slerp(bone.Rotation,target,Blend);
    bone.Handle.SetLocalRotation(stream,rotation);
    if(i==0)bone.Handle.SetLocalPosition(stream,Vector3.Lerp(StartHips,bone.Handle.GetLocalPosition(stream),Blend));
   }
  }
 }
 [HarmonyPatch(typeof(Seat),"InteractWith")]
 internal static class ChairFrontPatch
 {
  static bool Prefix(Seat __instance,Interactable __0,Interaction __1,ref Thing.DelayedActionInstance __result)
  {
   if(!ChairTransition.Ordinary(__instance)||__0.Action!=InteractableType.Slot1||__instance.SeatSlot.Get()!=null||!(__1.SourceThing is Human human))return true;
   if(ChairTransition.InFront(human,__instance))return true;
   __result=new Thing.DelayedActionInstance{Duration=2f,ActionMessage=ActionStrings.GetIn};
   __result.ExtendedMessage="Stand directly in front of the chair to sit down.";__result.Fail();return false;
  }
 }
 [HarmonyPatch(typeof(DynamicThing),"MoveToSlot",new Type[]{typeof(Slot),typeof(Thing),typeof(bool)})]
 internal static class ChairEnterPatch
 {
  static void Prefix(DynamicThing __instance,Slot __0,out ChairTransition.Snapshot __state)
  {__state=__0!=null&&ChairTransition.Ordinary(__0.Parent)&&__instance.ParentSlot==null?ChairTransition.Capture(__instance,(Seat)__0.Parent,true):null;}
  static void Postfix(bool __result,ChairTransition.Snapshot __state)=>ChairTransition.Complete(__state,__result);
 }
 [HarmonyPatch(typeof(DynamicThing),"MoveToWorld",new Type[]{typeof(Vector3),typeof(Quaternion),typeof(Vector3),typeof(Vector3),typeof(float)})]
 internal static class ChairExitPatch
 {
  static void Prefix(DynamicThing __instance,out ChairTransition.Snapshot __state)
  {__state=ChairTransition.Ordinary(__instance.ParentSlot?.Parent)?ChairTransition.Capture(__instance,(Seat)__instance.ParentSlot.Parent,false):null;}
  static void Postfix(bool __result,ChairTransition.Snapshot __state)=>ChairTransition.Complete(__state,__result);
 }
}
