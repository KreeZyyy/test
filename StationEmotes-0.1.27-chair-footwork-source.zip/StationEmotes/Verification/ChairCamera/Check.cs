using System;using StationEmotes;using UnityEngine;using Assets.Scripts;using Assets.Scripts.Inventory;using Assets.Scripts.Objects.Entities;using Assets.Scripts.Objects.Structures;
class Check{
 static int n;static void A(bool b){n++;if(!b)throw new Exception("camera check "+n);}static Human Setup(bool third=false){GameManager.IsBatchMode=false;CameraController.CinematicMode=false;CameraController.Instance=new CameraController{Third=third,RotationX=4,RotationY=20};CameraController.CurrentCamera=new Camera();var h=new Human();InventoryManager.ParentHuman=h;return h;}
 static void Main(){
 var seat=new Seat();var h=Setup();var c=CameraController.Instance;var v=ChairCamera.Begin(h,seat);A(v!=null&&c.Third&&c.Calls==1);v.Apply(new Transform());A(c.RotationX==4&&c.RotationY==20);A(CameraController.CurrentCamera.transform.position.magnitude>2);v.Dispose();A(!c.Third&&c.Calls==2&&c.Refresh==1);v.Dispose();A(c.Calls==2);
 h=Setup(true);c=CameraController.Instance;v=ChairCamera.Begin(h,seat);A(v!=null&&c.Calls==0);v.Dispose();A(c.Third&&c.Calls==0);
 h=Setup();c=CameraController.Instance;A(ChairCamera.Begin(new Human(),seat)==null&&c.Calls==0);CameraController.CinematicMode=true;A(ChairCamera.Begin(h,seat)==null);CameraController.CinematicMode=false;GameManager.IsBatchMode=true;A(ChairCamera.Begin(h,seat)==null);GameManager.IsBatchMode=false;
 h=Setup();c=CameraController.Instance;v=ChairCamera.Begin(h,seat);Physics.Hit=true;v.Apply(new Transform());A(CameraController.CurrentCamera.transform.position.magnitude<2);Physics.Hit=false;v.Dispose();
 h=Setup();c=CameraController.Instance;v=ChairCamera.Begin(h,seat);InventoryManager.ParentHuman=new Human();int before=c.Calls;v.Dispose();A(c.Calls==before);
 h=Setup();c=CameraController.Instance;v=ChairCamera.Begin(h,seat);c.Third=false;v.Apply(new Transform());A(c.Third);v.Dispose();A(!c.Third);
 Console.WriteLine(n+" production chair camera lifecycle checks passed (game/camera stubs; no rendering).");}}
namespace UnityEngine{
 public struct Vector3{public float x,y,z;public Vector3(float a,float b,float c){x=a;y=b;z=c;}public static Vector3 up=>new Vector3(0,1,0);public float magnitude=>(float)Math.Sqrt(x*x+y*y+z*z);public Vector3 normalized=>this/magnitude;public static Vector3 operator +(Vector3 a,Vector3 b)=>new Vector3(a.x+b.x,a.y+b.y,a.z+b.z);public static Vector3 operator *(Vector3 a,float b)=>new Vector3(a.x*b,a.y*b,a.z*b);public static Vector3 operator /(Vector3 a,float b)=>a*(1/b);}
 public struct Quaternion{public static Quaternion Euler(float a,float b,float c)=>new Quaternion();public static Vector3 operator *(Quaternion a,Vector3 b)=>b;}
 public class Transform{public Vector3 position;public Quaternion rotation;public Vector3 forward=>new Vector3(0,0,1);public void LookAt(Vector3 p){}}
 public class Camera{public Transform transform=new Transform();}public class RaycastHit{public float distance;}public enum QueryTriggerInteraction{Ignore}public static class Physics{public static bool Hit;public static bool Raycast(Vector3 a,Vector3 b,out RaycastHit hit,float c,int d,QueryTriggerInteraction e){hit=new RaycastHit{distance=.5f};return Hit;}}public static class Mathf{public static float Max(float a,float b)=>Math.Max(a,b);}
}
namespace Assets.Scripts{public static class GameManager{public static bool IsBatchMode;}public class CameraController{public static CameraController Instance;public static bool CinematicMode;public static Camera CurrentCamera;public static Vector3 CameraPosition,EffectiveCameraPosition;public static Quaternion CameraRotation;public object ThirdController=new object();public bool Third;public int Calls,Refresh;public float RotationX,RotationY;public static bool IsThirdPerson=>Instance.Third;public void SetThirdPersonCamera(bool show){Calls++;Third=show;}public static void SetCameraPosition(){Instance.Refresh++;}}}
namespace Assets.Scripts.Inventory{public static class InventoryManager{public static Human ParentHuman;}}
namespace Assets.Scripts.Objects.Entities{public class Human{public int AllButPlayerImmune;}}
namespace Assets.Scripts.Objects.Structures{public class Seat{public Transform ThingTransform=new Transform();}}
namespace StationEmotes{internal static class Plugin{internal static LogStub Log=new LogStub();}internal class LogStub{public void LogInfo(string s){}public void LogWarning(string s){}}}
