using System;using StationEmotes;
class Check{
 static int n;static void A(bool b){n++;if(!b)throw new Exception("footwork check "+n);}static bool Near(float a,float b)=>Math.Abs(a-b)<.0001;
 static void Main(){
 A(ChairStepPolicy.Lift(0)==0);A(ChairStepPolicy.Lift(1)==0);A(Near(ChairStepPolicy.Lift(.5f),.075f));
 foreach(bool entering in new[]{true,false}){
 float previousEnd=entering?0:ChairTransitionPolicy.Sit;
 for(int i=0;i<8;i++){float start,duration,advance;bool turning;ChairStepPolicy.Timing(entering,i,out start,out duration,out advance,out turning);A(Near(start,previousEnd));A(duration>.2f);A(advance>0&&advance<=1);A(turning==(entering?i>=2:i<6));previousEnd=start+duration;}
 A(Near(previousEnd,entering?ChairTransitionPolicy.Approach+ChairTransitionPolicy.Turn:ChairTransitionPolicy.Duration));
 for(int tick=0;tick<3100;tick++){float time=tick*.001f;int active=0;for(int i=0;i<8;i++){float start,duration,advance;bool turning;ChairStepPolicy.Timing(entering,i,out start,out duration,out advance,out turning);if(time>=start+.00001f&&time<start+duration-.00001f)active++;}A(active<=1);}
 }
 foreach(float a in new[]{.35f,.45f,.55f})foreach(float b in new[]{.35f,.45f,.55f})foreach(float t in new[]{.2f,.4f,.6f,.8f,.95f}){float d=Math.Abs(a-b)+.0001f+(a+b-Math.Abs(a-b)-.0002f)*t,x,y;ChairStepPolicy.Knee(a,b,d,out x,out y);A(!float.IsNaN(x)&&!float.IsNaN(y));A(Near((float)Math.Sqrt(x*x+y*y),a));A(Near((float)Math.Sqrt((d-x)*(d-x)+y*y),b));}
 for(int i=0;i<=100;i++){float p=i/100f;A(ChairStepPolicy.Lift(p)>=0&&ChairStepPolicy.Lift(p)<=.07501f);}
 A(ChairStepPolicy.Release(true,0)==0);A(Near(ChairStepPolicy.Release(true,ChairTransitionPolicy.Duration),1));A(ChairStepPolicy.Release(false,ChairTransitionPolicy.Duration)==0);
 Console.WriteLine(n+" production footwork timing/contact/triangle checks passed (no Unity rendering).");}}
