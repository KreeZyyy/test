using UnityEngine;
namespace StationEmotes
{
 // Alternating world-space contacts. This runs after the common visual root has moved.
 internal sealed class ChairFootwork
 {
  private sealed class Step{internal int Foot;internal float Start,Duration;internal Vector3 Position;internal Quaternion Rotation;}
  private readonly ChairTransition.Snapshot s;
  private readonly Step[] steps=new Step[ChairStepPolicy.Count];
  private readonly Vector3[] initial=new Vector3[2],stance=new Vector3[2];
  private readonly Quaternion[] initialRotation=new Quaternion[2],restRotation=new Quaternion[2];
  private readonly float[] sole=new float[2];private bool prepared,warned;
  internal ChairFootwork(ChairTransition.Snapshot snapshot)
  {
   s=snapshot;initial[0]=s.LeftFootPosition;initial[1]=s.RightFootPosition;
   initialRotation[0]=s.LeftFootRotation;initialRotation[1]=s.RightFootRotation;
   for(int i=0;i<2;i++)
   {
    stance[i]=Quaternion.Inverse(s.Rotation)*(initial[i]-s.Position);
    if(!s.Entering)stance[i].z=.04f; // Seated feet extend forward; a standing stance is under the pelvis.
    restRotation[i]=Quaternion.Inverse(s.Rotation)*initialRotation[i];
    RaycastHit hit;sole[i]=Physics.Raycast(initial[i]+Vector3.up*.25f,Vector3.down,out hit,.8f,s.Human.AllButPlayerImmune,QueryTriggerInteraction.Ignore)?Mathf.Clamp(initial[i].y-hit.point.y,.025f,.18f):.08f;
   }
  }
  internal void Prepare(Vector3 end,Quaternion facing)
  {
   if(prepared)
   {
    if(!s.Entering)
    {
     // The last two steps converge exactly to the now-standing native pose.
     for(int i=ChairStepPolicy.TurnSteps;i<steps.Length;i++)
     {int index=steps[i].Foot==0?12:15;steps[i].Position=s.Bones[index].position;steps[i].Rotation=s.Bones[index].rotation;}
    }
    return;
   }
   prepared=true;
   var front=s.Front;front.y=s.Entering?s.Position.y:end.y;
   for(int i=0;i<steps.Length;i++)
   {
    float start,duration,advance;bool turning;
    ChairStepPolicy.Timing(s.Entering,i,out start,out duration,out advance,out turning);
    int foot=i%2;Vector3 root;Quaternion rotation;
    if(turning){root=front;rotation=Quaternion.Slerp(s.Rotation,facing,advance);}
    else{root=Vector3.Lerp(s.Entering?s.Position:front,s.Entering?front:end,advance);rotation=s.Entering?s.Rotation:facing;}
    var point=root+rotation*stance[foot];point.y=initial[foot].y;
    // Preserve measured ankle-to-floor clearance; never use seat height for the standing feet.
    RaycastHit hit;
    if(Physics.Raycast(point+Vector3.up*.3f,Vector3.down,out hit,.9f,s.Human.AllButPlayerImmune,QueryTriggerInteraction.Ignore)&&hit.normal.y>.65f)point.y=hit.point.y+sole[foot];
    else point.y=initial[foot].y+(s.Entering?0:end.y-front.y);
    steps[i]=new Step{Foot=foot,Start=start,Duration=duration,Position=point,Rotation=rotation*restRotation[foot]};
   }
  }
  internal Vector3 WeightShift(float elapsed,Quaternion rotation)
  {
   if(!prepared)return Vector3.zero;
   foreach(var step in steps)if(elapsed>=step.Start&&elapsed<step.Start+step.Duration)
   {
    float p=ChairStepPolicy.Progress(elapsed,step.Start,step.Duration);
    return rotation*Vector3.right*((step.Foot==0?1:-1)*.025f*Mathf.Sin(p*Mathf.PI));
   }
   return Vector3.zero;
  }
  internal void Apply(float elapsed,Transform visual,Quaternion facing)
  {
   if(!prepared)return;
   var left=initial[0];var right=initial[1];var lr=initialRotation[0];var rr=initialRotation[1];
   foreach(var step in steps)
   {
    if(elapsed<step.Start)break;
    float p=ChairStepPolicy.Progress(elapsed,step.Start,step.Duration);
    var old=step.Foot==0?left:right;var oldRotation=step.Foot==0?lr:rr;
    var goal=Vector3.Lerp(old,step.Position,p)+Vector3.up*ChairStepPolicy.Lift(p);
    var rotation=Quaternion.Slerp(oldRotation,step.Rotation,p);
    if(step.Foot==0){left=goal;lr=rotation;}else{right=goal;rr=rotation;}
    if(p<1)break;
   }
   float release=ChairStepPolicy.Release(s.Entering,elapsed);
   // Blend back to the native seated feet only at the very end, avoiding a hard release snap.
   left=Vector3.Lerp(left,s.Bones[12].position,release);right=Vector3.Lerp(right,s.Bones[15].position,release);
   lr=Quaternion.Slerp(lr,s.Bones[12].rotation,release);rr=Quaternion.Slerp(rr,s.Bones[15].rotation,release);
   Solve(s.Bones[10],s.Bones[11],s.Bones[12],left,lr,visual.forward);
   Solve(s.Bones[13],s.Bones[14],s.Bones[15],right,rr,visual.forward);
   // Head and chest anticipate the pelvis during the turn, then settle back to the native pose.
   float turn=s.Entering?ChairTransitionPolicy.Rotate(elapsed):ChairTransitionPolicy.Ease((elapsed-ChairTransitionPolicy.Sit)/ChairTransitionPolicy.Turn);
   float lead=Mathf.Clamp(Vector3.SignedAngle(visual.forward,facing*Vector3.forward,Vector3.up),-25,25)*Mathf.Sin(turn*Mathf.PI);
   if(s.Bones[2]!=null)s.Bones[2].rotation=Quaternion.AngleAxis(lead*.35f,Vector3.up)*s.Bones[2].rotation;
   if(s.Bones[3]!=null)s.Bones[3].rotation=Quaternion.AngleAxis(lead*.65f,Vector3.up)*s.Bones[3].rotation;
  }
  private void Solve(Transform upper,Transform lower,Transform foot,Vector3 target,Quaternion rotation,Vector3 forward)
  {
   if(upper==null||lower==null||foot==null)return;
   var a=upper.position;var b=lower.position;var c=foot.position;
   float u=(b-a).magnitude,l=(c-b).magnitude,d=(target-a).magnitude;
   if(u<.01f||l<.01f||d<.001f)return;
   var direction=(target-a)/d;
   var pole=Vector3.ProjectOnPlane(b-a,direction);
   if(pole.sqrMagnitude<.0001f)pole=Vector3.ProjectOnPlane(forward,direction);
   if(pole.sqrMagnitude<.0001f)return;
   float axial,lateral;ChairStepPolicy.Knee(u,l,d,out axial,out lateral);
   var knee=a+direction*axial+pole.normalized*lateral;
   upper.rotation=Quaternion.FromToRotation(b-a,knee-a)*upper.rotation;
   lower.rotation=Quaternion.FromToRotation(foot.position-lower.position,target-lower.position)*lower.rotation;
   foot.rotation=rotation;
   if(!warned&&(foot.position-target).sqrMagnitude>.0064f){warned=true;Plugin.Log.LogWarning("Chair foot contact is outside leg reach; send this log and a third-person view.");}
  }
 }
}
