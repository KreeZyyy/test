using System;
namespace StationEmotes
{
 internal static class ChairStepPolicy
 {
  internal const int ApproachSteps=2,TurnSteps=6,Count=8;
  internal static float Progress(float time,float start,float duration)=>ChairTransitionPolicy.Ease((time-start)/duration);
  internal static float Lift(float progress)=>progress<=0||progress>=1?0:.075f*(float)Math.Sin(Math.PI*progress);
  internal static float Release(bool entering,float elapsed)
  {
   if(!entering)return 0;
   float sit=ChairTransitionPolicy.Blend(elapsed);
   return ChairTransitionPolicy.Ease((sit-.8f)/.2f);
  }
  internal static void Timing(bool entering,int index,out float start,out float duration,out float advance,out bool turning)
  {
   turning=entering?index>=ApproachSteps:index<TurnSteps;
   if(entering)
   {
    duration=turning?ChairTransitionPolicy.Turn/TurnSteps:ChairTransitionPolicy.Approach/ApproachSteps;
    int local=turning?index-ApproachSteps:index;
    start=turning?ChairTransitionPolicy.Approach+local*duration:local*duration;
    advance=turning?Math.Min(1,(local+1f)/(TurnSteps-1)):(local+1f)/ApproachSteps;
   }
   else
   {
    duration=turning?ChairTransitionPolicy.Turn/TurnSteps:ChairTransitionPolicy.Approach/ApproachSteps;
    int local=turning?index:index-TurnSteps;
    start=ChairTransitionPolicy.Sit+(turning?local*duration:ChairTransitionPolicy.Turn+local*duration);
    advance=turning?Math.Min(1,(local+1f)/(TurnSteps-1)):(local+1f)/ApproachSteps;
   }
  }
  internal static void Knee(float upper,float lower,float distance,out float axial,out float lateral)
  {
   float min=Math.Abs(upper-lower)+.0001f,max=upper+lower-.0001f;
   float d=Math.Max(min,Math.Min(max,distance));
   axial=(upper*upper-lower*lower+d*d)/(2*d);
   lateral=(float)Math.Sqrt(Math.Max(0,upper*upper-axial*axial));
  }
 }
}
