using System;
using Assets.Scripts;
using Assets.Scripts.Inventory;
using Assets.Scripts.Objects.Entities;
using Assets.Scripts.Objects.Structures;
using UnityEngine;
namespace StationEmotes
{
 // A short local inspection view. No camera ownership or messages for remote players.
 internal sealed class ChairCamera:IDisposable
 {
  private Human owner;private CameraController controller;private bool changedMode;private Vector3 direction;
  private float pitch,yaw;
  internal static ChairCamera Begin(Human human,Seat seat)
  {
   var c=CameraController.Instance;
   if(GameManager.IsBatchMode||human!=InventoryManager.ParentHuman||CameraController.CinematicMode||c==null||c.ThirdController==null||CameraController.CurrentCamera==null)return null;
   var view=new ChairCamera{owner=human,controller=c,pitch=c.RotationX,yaw=c.RotationY};
   view.direction=Quaternion.Euler(0,135,0)*seat.ThingTransform.forward;
   try
   {
    if(!CameraController.IsThirdPerson){view.changedMode=true;c.SetThirdPersonCamera(true);}
    Plugin.Log.LogInfo("Chair inspection camera: third person; restore="+(view.changedMode?"first person":"third person"));
    return view;
   }
   catch(Exception e){view.Dispose();Plugin.Log.LogWarning("Chair inspection camera unavailable: "+e);return null;}
  }
  internal void Apply(Transform visual)
  {
   if(owner==null||owner!=InventoryManager.ParentHuman||controller!=CameraController.Instance||CameraController.CinematicMode||visual==null)return;
   var camera=CameraController.CurrentCamera;if(camera==null)return;
   if(!CameraController.IsThirdPerson)controller.SetThirdPersonCamera(true);
   // Aim at the animated model rather than its already seated physical root.
   var focus=visual.position+Vector3.up*.9f;
   var offset=direction.normalized*2.7f+Vector3.up*.65f;
   RaycastHit hit;
   float distance=offset.magnitude;
   if(Physics.Raycast(focus,offset/distance,out hit,distance,owner.AllButPlayerImmune,QueryTriggerInteraction.Ignore))distance=Mathf.Max(.25f,hit.distance-.15f);
   camera.transform.position=focus+offset.normalized*distance;
   camera.transform.LookAt(focus);
   CameraController.CameraPosition=camera.transform.position;CameraController.EffectiveCameraPosition=camera.transform.position;CameraController.CameraRotation=camera.transform.rotation;
   // Native orbit code can copy its angle into character look; this temporary view must not turn the player.
   controller.RotationX=pitch;controller.RotationY=yaw;
  }
  public void Dispose()
  {
   var c=controller;controller=null;
   if(c==null||c!=CameraController.Instance||owner==null||owner!=InventoryManager.ParentHuman)return;
   try
   {
    if(changedMode)c.SetThirdPersonCamera(false);
    c.RotationX=pitch;c.RotationY=yaw;
    if(!CameraController.CinematicMode)CameraController.SetCameraPosition();
   }
   catch(Exception e){Plugin.Log.LogWarning("Chair camera restore: "+e);}
   finally{owner=null;changedMode=false;}
  }
 }
}
