using System;
using Assets.Scripts;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Inventory;
using Assets.Scripts.Objects.Entities;
using Assets.Scripts.UI;
using Assets.Scripts.Util;
using HarmonyLib;
using ImGuiNET;
using UnityEngine;
using UnityEngine.Rendering;
namespace StationEmotes
{
    internal static class EmoteWheel
    {
        internal static bool Open {get;private set;}
        [ThreadStatic] internal static bool ReadingMouse;
        private static Human owner;
        private static Vector2 pointer;
        private static readonly string[] Labels={"Wave","Salute","Sit","Hands up","Point","Robot dance","Meme dance","Agree","Disagree","Facepalm"};
        internal static void Close(){Open=false;owner=null;pointer=Vector2.zero;}
        private static bool CanUse()=>Application.isFocused&&!WorldManager.IsGamePaused&&InventoryManager.AllowMouseControl&&!Cursor.visible&&!InputWindowBase.IsInputWindow&&!ConsoleWindow.IsOpen&&!ImGuiLoadingScreen.IsShowing;
        internal static void Tick(Human human)
        {
            if(!CanUse()){Close();return;}
            if(!Open&&Input.GetKeyDown(KeyCode.F10)){Open=true;owner=human;pointer=Vector2.zero;return;}
            if(!Open)return;
            if(owner!=human||Input.GetKeyDown(KeyCode.Escape)){Close();return;}
            if(!Input.GetKey(KeyCode.F10))
            {
                int selected=EmoteWheelPolicy.Select(pointer.x,pointer.y);Close();
                Plugin.TriggerSelection(human,selected);return;
            }
            // Read the game's existing mouse axes while the OS pointer stays locked.
            var input=Singleton<InputManager>.Instance;
            ReadingMouse=true;
            try{pointer+=new Vector2(input.GetAxis("LookX"),-input.GetAxis("LookY"))*24f;}
            finally{ReadingMouse=false;}
            pointer=Vector2.ClampMagnitude(pointer,225f);
        }
        private static uint Color(float r,float g,float b,float a=1f)=>ImGui.GetColorU32(new Vector4(r,g,b,a));
        private static void Text(ImDrawListPtr draw,Vector2 p,string text,uint color)
        {draw.AddText(p-ImGui.CalcTextSize(text)*.5f,color,text);}
        private static Vector2 Direction(float angle)=>new Vector2(Mathf.Cos(angle*Mathf.Deg2Rad),Mathf.Sin(angle*Mathf.Deg2Rad));
        private static void Sector(ImDrawListPtr d,Vector2 c,float inner,float outer,float from,float to,uint color)
        {
            for(int k=0;k<18;k++)
            {
                float a=from+(to-from)*k/18f,b=from+(to-from)*(k+1)/18f;
                var p=c+Direction(a)*inner;var q=c+Direction(a)*outer;
                var r=c+Direction(b)*outer;var s=c+Direction(b)*inner;
                d.AddTriangleFilled(p,q,r,color);d.AddTriangleFilled(p,r,s,color);
            }
        }
        // Vector pictograms: no fonts, external textures or Unicode glyph dependencies.
        private static void Icon(ImDrawListPtr d,Vector2 c,int id,uint color)
        {
            Action<float,float,float,float> line=(x,y,u,v)=>d.AddLine(c+new Vector2(x,y),c+new Vector2(u,v),color,2.5f);
            d.AddCircle(c+new Vector2(0,-14),5,color,20,2f);
            line(0,-8,0,9);
            if(id==2){line(0,9,12,9);line(12,9,12,22);line(-7,12,9,12);}
            else{line(0,9,-9,22);line(0,9,9,22);}
            if(id==0){line(0,-4,-12,4);line(0,-4,11,-9);line(11,-9,11,-22);line(16,-23,19,-19);}
            else if(id==1||id==9){line(0,-4,-12,5);line(0,-4,13,0);line(13,0,id==9?0:5,-15);}
            else if(id==3){line(0,-4,-13,-10);line(-13,-10,-13,-24);line(0,-4,13,-10);line(13,-10,13,-24);}
            else if(id==4){line(0,-4,-10,6);line(0,-4,22,-4);line(22,-4,17,-8);}
            else if(id==5){line(0,-4,-13,-4);line(-13,-4,-13,-15);line(0,-4,13,-4);line(13,-4,13,7);}
            else if(id==6){line(0,-4,-18,-12);line(0,-4,18,6);line(-22,-8,-25,-3);line(22,-3,25,-8);}
            else{line(0,-4,-12,6);line(0,-4,12,6);if(id==7){line(-6,-26,-1,-22);line(-1,-22,8,-30);}else{line(-5,-28,5,-20);line(5,-28,-5,-20);}}
        }
        internal static void Draw()
        {
            if(!Open||GameManager.IsBatchMode||GameManager.GameState!=GameState.Running||ImGui.GetCurrentContext()==IntPtr.Zero)return;
            try
            {
                var center=new Vector2(Screen.width*.5f,Screen.height*.5f);
                ImGui.SetNextWindowPos(center-new Vector2(290,310),ImGuiCond.Always);
                ImGui.SetNextWindowSize(new Vector2(580,620),ImGuiCond.Always);
                bool visible=ImGui.Begin("##StationEmotesWheel",ImGuiWindowFlags.NoDecoration|ImGuiWindowFlags.NoBackground|ImGuiWindowFlags.NoSavedSettings|ImGuiWindowFlags.NoInputs|ImGuiWindowFlags.NoFocusOnAppearing);
                try
                {
                    if(!visible)return;
                    var d=ImGui.GetWindowDrawList();int selected=EmoteWheelPolicy.Select(pointer.x,pointer.y);
                    d.AddCircleFilled(center,246,Color(0,0,0,.32f),100);
                    d.AddCircleFilled(center,240,Color(.025f,.045f,.06f,.96f),100);
                    for(int i=0;i<EmoteWheelPolicy.Count;i++)
                    {
                        float angle=-90f+i*36f;bool hot=i==selected;
                        Sector(d,center,96,238,angle-17.3f,angle+17.3f,hot?Color(.88f,.43f,.10f,.96f):Color(.065f,.105f,.13f,.97f));
                        var axis=Direction(angle);
                        uint ink=hot?Color(1,.96f,.87f):Color(.72f,.85f,.89f);
                        Icon(d,center+axis*157f,i,ink);
                        string label=Labels[i].Replace(" ","\n");
                        Text(d,center+axis*202f,label,ink);
                    }
                    d.AddCircle(center,240,Color(.16f,.48f,.57f),100,2f);
                    d.AddCircleFilled(center,91,Color(.025f,.045f,.06f,.99f),64);
                    d.AddCircle(center,92,selected>=0?Color(1,.59f,.22f):Color(.22f,.46f,.53f),64,2f);
                    Text(d,center+new Vector2(0,-34),"STATION EMOTES",Color(.4f,.68f,.74f));
                    Text(d,center+new Vector2(0,-2),selected<0?"Choose emote":Labels[selected],Color(1,.92f,.79f));
                    Text(d,center+new Vector2(0,29),selected<0?"Move mouse":"Release F10",Color(.65f,.75f,.79f));
                    var human=InventoryManager.ParentHuman;
                    bool needsHands=selected>=3&&human!=null&&(human.LeftHandSlot?.Get()!=null||human.RightHandSlot?.Get()!=null);
                    Text(d,center+new Vector2(0,263),needsHands?"Empty BOTH hands for this emote":"F10  RELEASE TO PLAY    |    F11  STOP",needsHands?Color(1,.65f,.25f):Color(.85f,.9f,.92f));
                    Text(d,center+new Vector2(0,284),"CENTER / ESC  CLOSE MENU",Color(.62f,.74f,.79f));
                    d.AddCircleFilled(center+pointer,6,Color(0,0,0,.7f),20);
                    d.AddCircleFilled(center+pointer,3,Color(1,.75f,.35f),20);
                }
                finally{ImGui.End();}
            }
            catch(Exception e){Close();Plugin.Log.LogWarning("Emote menu closed: "+e);}
        }
    }
    [HarmonyPatch(typeof(ImGuiManager),"RenderImGuiTo")]
    internal static class EmoteWheelDraw
    {
        [HarmonyPrepare] static bool Prepare()=>!GameManager.IsBatchMode;
        static void Prefix(CommandBuffer cb,CommandBuffer ___commandBuffer)
        {if(ReferenceEquals(cb,___commandBuffer))EmoteWheel.Draw();}
    }
    [HarmonyPatch(typeof(InputManager),"GetAxis",new Type[]{typeof(string)})]
    internal static class EmoteWheelCamera
    {
        [HarmonyPrepare] static bool Prepare()=>!GameManager.IsBatchMode;
        static bool Prefix(string __0,ref float __result)
        {
            if(!EmoteWheel.Open||EmoteWheel.ReadingMouse||(__0!="LookX"&&__0!="LookY"))return true;
            __result=0f;return false;
        }
    }
}
