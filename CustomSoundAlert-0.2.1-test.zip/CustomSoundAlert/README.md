# Custom SoundAlert 0.2.1

Adds custom SoundAlert IDs **100–199** to Speakers, Suits and Advanced Tablets. Supports WAV, OGG and MP3 files named `<id>_<name>.<extension>` in the mod's `sounds` folder, for example `100_test.wav`.

## Installation

Requires StationeersLaunchPad, BepInEx and LaunchPadBooster. Disable/remove the previous `CustomSpeakerSounds` mod folder before installing this renamed mod; loading both copies is unsupported. Extract the test ZIP into your local mod directory, keeping the `CustomSoundAlert` folder intact. The DLL belongs directly in that folder alongside `About` and `sounds`. This build has no published Workshop association.

Restart the game after editing sound files. Keep IDs unique and between 100 and 199. Existing IC10 SoundAlert/Mode numbers remain unchanged. The included test scripts demonstrate Speaker and suit selection. Native power, volume and stop behavior are retained; set SoundAlert to 0 to stop suit/tablet playback.

## Changes in 0.2.1

- Renamed the display name, mod folder, assembly, source project and mod/network identifiers to Custom SoundAlert / CustomSoundAlert.
- Removed the previous Workshop item association.
- Cached the game's existing AudioManager. Once loading completes, normal updates perform no scene discovery or sound-file decoding. A destroyed manager can be discovered again. The mod never calls the singleton getter to create an AudioManager.
- Replaced the custom event's LINQ scan with weak, identity-based ownership tracking. Old custom events remain blocked after a catalog reset without retaining their decoded clips.
- Removed an unchanged multiplayer catalog's per-frame lock.
- On catalog/role changes, detach and stop custom events, remove only this mod's exact native lookup entries, and release its decoded AudioClips. This avoids duplicate registrations and retained audio after reconnecting. Other mods' entries are not removed.

## Multiplayer status

**Experimental catalog prototype. Automatic audio file transfer is not implemented.** The server shares IDs, labels, sizes and SHA256 hashes. Clients select only matching, verified files from their separate `server-cache` folder; private local sounds are not substituted. Without a matching cached file, custom server audio is silent. Dedicated servers publish metadata without loading audio. See `MULTIPLAYER_STATUS.md`.

The renamed mod uses a new network identity. Use the same build on client and server. Live multiplayer joins, role changes and playback still need testing.

## Validation

Built against the supplied native game/LaunchPad APIs for .NET Framework 4.7.2. Passed 16 ID policy, 58 shared catalog and 128 manifest/cache checks. A fixture executing the actual Update method completed 100,000 loaded frames with no further scene searches, reloads or managed allocations; 200,000 event ownership lookups also allocated no managed memory. These fixtures use API stubs and do not measure live game FPS.

Large songs are decoded once while loading and can still use substantial PCM memory. This update removes recurring discovery/lookup work; it does not claim that all sources of game frame drops are resolved.

## Source and credits

Matching source, build instructions and verification fixtures are provided in the separate source ZIP. Original supplied sound files are preserved byte-for-byte in the test ZIP.

Inspired by Sovana122's implementation: https://github.com/Sovana122/Sationeers-CustomSound/tree/speaker
See `LICENSE-Sovana.txt` for the original license and attribution.
