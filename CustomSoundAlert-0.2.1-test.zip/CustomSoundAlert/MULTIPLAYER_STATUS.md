# Custom SoundAlert 0.2.1 — multiplayer status

This is an experimental server-catalog prototype, not a completed audio distribution system.

- Server join data contains IDs, labels, extensions, byte counts and SHA256 hashes.
- IDs are restricted to 100–199, at most 100 entries. Each encoded file is limited to 32 MiB, the catalog to 128 MiB of source files and labels to 96 characters. These limits do not bound decoded PCM memory.
- A remote client ignores its private local sounds directory. Audio can play only from a size/hash-verified file in `<persistentDataPath>/CustomSoundAlert/server-cache/<sha256>.<extension>`.
- Automatic file transfer, download progress and synchronized late-join playback are not implemented. Without a matching cached file, custom server audio is silent.
- Dedicated servers scan metadata and publish the catalog without discovering AudioManager or decoding clips.
- Catalog/role changes stop custom events, invalidate old registrations, release owned decoded clips and remove only their exact native lookup entries. Disconnect resets pending server metadata.
- The renamed mod/network identity requires the same Custom SoundAlert build on participating peers.

Automated checks cover manifest parsing, limits, Unicode, invalid entries, cache hashing, local-folder isolation, shared catalog preservation, ownership invalidation, cleanup and Update discovery behavior. Native API compilation passes. Live Unity joins, reconnects, SP→MP→SP transitions, dedicated-server playback and real FPS remain unverified for this build.
