using UnityEngine;
namespace StationEmotes
{
 // A native endpoint in a yaw-only reference frame, independent of seat-slot pitch/roll.
 internal sealed class ChairPoseAnchor
 {
  private Vector3 origin;private Quaternion frame;private ChairNativePose pose;
  internal ChairLocalPose Locals;internal ChairTorsoStream Torso;internal Vector3 TorsoDirection,HipAboveFeet;
  internal ChairPoseAnchor(ChairNativePose native,ChairTorsoStream torso,ChairLocalPose locals,Vector3 root,Quaternion rotation)
  {
   origin=root;frame=ChairPoseFrame.Upright(rotation);var inverse=Quaternion.Inverse(frame);pose=native;
   pose.Hips=inverse*(native.Hips-root);pose.Head=inverse*(native.Head-root);pose.Left=inverse*(native.Left-root);pose.Right=inverse*(native.Right-root);
   pose.LeftUpper=inverse*(native.LeftUpper-root);pose.LeftKnee=inverse*(native.LeftKnee-root);pose.RightUpper=inverse*(native.RightUpper-root);pose.RightKnee=inverse*(native.RightKnee-root);
   pose.HipRotation=inverse*native.HipRotation;pose.LeftRotation=inverse*native.LeftRotation;pose.RightRotation=inverse*native.RightRotation;
   Locals=locals;Torso=torso;TorsoDirection=(pose.Head-pose.Hips).normalized;HipAboveFeet=pose.Hips-(pose.Left+pose.Right)*.5f;
  }
  internal ChairNativePose World()
  {
   var p=pose;p.Hips=origin+frame*pose.Hips;p.Head=origin+frame*pose.Head;p.Left=origin+frame*pose.Left;p.Right=origin+frame*pose.Right;
   p.LeftUpper=origin+frame*pose.LeftUpper;p.LeftKnee=origin+frame*pose.LeftKnee;p.RightUpper=origin+frame*pose.RightUpper;p.RightKnee=origin+frame*pose.RightKnee;
   p.HipRotation=frame*pose.HipRotation;p.LeftRotation=frame*pose.LeftRotation;p.RightRotation=frame*pose.RightRotation;return p;
  }
  internal ChairNativePose Resolve(ChairNativePose live,float release)
  {
   var p=World();p.Hips=Vector3.Lerp(p.Hips,live.Hips,release);p.Head=Vector3.Lerp(p.Head,live.Head,release);
   p.Left=Vector3.Lerp(p.Left,live.Left,release);p.Right=Vector3.Lerp(p.Right,live.Right,release);
   p.HipRotation=Quaternion.Slerp(p.HipRotation,live.HipRotation,release);p.LeftRotation=Quaternion.Slerp(p.LeftRotation,live.LeftRotation,release);p.RightRotation=Quaternion.Slerp(p.RightRotation,live.RightRotation,release);return p;
  }
  internal ChairTorsoStream ResolveTorso(ChairTorsoStream live,float release)
  {
   var result=Torso;for(int i=0;i<result.Count;i++){var slot=result.Get(i);var current=live.Get(i);if(current.Ready)slot.NativeRotation=Quaternion.Slerp(slot.NativeRotation,current.NativeRotation,release);result.Set(i,slot);}return result;
  }
 }
}
