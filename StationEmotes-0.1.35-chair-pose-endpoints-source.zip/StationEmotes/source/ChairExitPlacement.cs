using UnityEngine;
namespace StationEmotes
{
 internal static class ChairExitPlacement
 {
  internal static bool TryTarget(Vector3 upper,Vector3 knee,Vector3 ankle,float floorAnkleY,out Vector3 target)
  {
   target=new Vector3(knee.x,floorAnkleY,knee.z);
   float reach=(knee-upper).magnitude+(ankle-knee).magnitude;
   float safe=reach-Mathf.Max(.008f,reach*.025f),vertical=Mathf.Abs(upper.y-floorAnkleY);
   if(float.IsNaN(reach)||float.IsInfinity(reach)||float.IsNaN(vertical)||float.IsInfinity(vertical)||safe<=0||vertical>safe)return false;
   float radius=Mathf.Sqrt(Mathf.Max(0,safe*safe-vertical*vertical));
   var horizontal=new Vector3(target.x-upper.x,0,target.z-upper.z);
   if(horizontal.magnitude>radius){horizontal=horizontal.normalized*radius;target.x=upper.x+horizontal.x;target.z=upper.z+horizontal.z;}
   return true;
  }
  internal static Vector3 Sample(Vector3 source,Vector3 floorTarget,float elapsed)
  {
   var tucked=new Vector3(floorTarget.x,source.y,floorTarget.z);
   if(elapsed<=.28f)return Vector3.Lerp(source,tucked,ChairTransitionPolicy.Ease(elapsed/.28f));
   return Vector3.Lerp(tucked,floorTarget,ChairTransitionPolicy.Ease((elapsed-.28f)/.24f));
  }
  internal static Vector3 ReverseSample(Vector3 seated,Vector3 floorTarget,float elapsed)
  {return Sample(seated,floorTarget,.52f-Mathf.Clamp(elapsed,0,.52f));}
  internal static float RequiredDrop(Vector3 joint,Vector3 target,float reach)
  {
   float safe=reach-Mathf.Max(.002f,reach*.005f);
   var delta=joint-target;float horizontal=delta.x*delta.x+delta.z*delta.z;
   if(safe<=0||horizontal>=safe*safe)return 0;
   return Mathf.Max(0,delta.y-Mathf.Sqrt(safe*safe-horizontal));
  }
 }
}
