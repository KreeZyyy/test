using System;using System.Collections.Generic;using System.Reflection;using UnityEngine;using StationEmotes;using Assets.Scripts;using Assets.Scripts.Objects;using Assets.Scripts.Objects.Entities;using Assets.Scripts.GridSystem;using Objects.Structures;
class Check
{
 static int count;static void A(bool b,string m){count++;if(!b)throw new Exception(m);}
 static bool Invoke(StructureToilet t,Interactable c,Human h,bool action,bool alt,out Thing.DelayedActionInstance result)
 {object[] args={t,c,new Interaction{SourceThing=h,AltKey=alt},action,null};var pass=(bool)typeof(ToiletInteractPatch).GetMethod("Prefix",BindingFlags.Static|BindingFlags.NonPublic).Invoke(null,args);result=(Thing.DelayedActionInstance)args[4];return pass;}
 static void Main()
 {
  var t=new StructureToilet();var slot=new Slot{Parent=t,StringKey=ToiletSeating.Marker,Location=new Transform(),Type=Slot.Class.Entity,Action=InteractableType.Slot1};
  t.Slots.Add(slot);var bowl=new Interactable{Parent=t,Action=InteractableType.Activate};var h=new Human{State=EntityState.Alive,SuitWorn=true};
  GameManager.RunSimulation=true;Thing.DelayedActionInstance r;
  A(!Invoke(t,bowl,h,false,false,out r)&&r.ActionMessage=="Sit down"&&r.Success,"visible bowl must offer Sit even with suit");
  A(OnServer.Moves==0,"hover seated actor");A(!Invoke(t,bowl,h,true,false,out r)&&OnServer.Moves==1,"bowl action must enter native slot");
  A(h.ParentSlot==slot,"actor did not enter selected slot");
  var state=new ToiletOccupancy{Occupant=h,ReadyAt=4};t.StateObject=state;h.Transition.Active=true;Time.time=1;
  A(!Invoke(t,bowl,h,true,false,out r)&&!r.Success,"using during transition");
  h.Transition.Active=false;Time.time=4;
  A(Invoke(t,bowl,h,true,false,out r)&&h.SuitWorn,"native suit/water/use handler must receive seated use unchanged");
  A(!Invoke(t,bowl,h,false,true,out r)&&r.ActionMessage=="Stand up","modifier must expose Stand on visible bowl");
  A(ToiletSeating.Exits==0,"hover stood up");A(!Invoke(t,bowl,h,true,true,out r)&&ToiletSeating.Exits==1,"modifier did not stand up");
  h.ParentSlot=null;slot.Occupant=new Human();A(!Invoke(t,bowl,h,true,false,out r)&&!r.Success&&OnServer.Moves==1,"occupied toilet accepted actor");
  slot.Occupant=null;h.InFront=false;A(!Invoke(t,bowl,h,true,false,out r)&&!r.Success,"rear entry accepted");h.InFront=true;
  h.ParentSlot=new Slot();A(!Invoke(t,bowl,h,true,false,out r)&&!r.Success,"actor entered while seated elsewhere");h.ParentSlot=null;
  h.State=EntityState.Dead;A(!Invoke(t,bowl,h,true,false,out r)&&!r.Success,"dead actor entry");h.State=EntityState.Alive;
  t.IsStructureCompleted=false;A(!Invoke(t,bowl,h,true,false,out r)&&!r.Success,"unfinished toilet entry");t.IsStructureCompleted=true;
  GameManager.RunSimulation=false;A(!Invoke(t,bowl,h,true,false,out r)&&OnServer.Moves==1,"client performed authoritative slot move");GameManager.RunSimulation=true;
  var other=new Interactable{Action=InteractableType.OnOff};A(Invoke(t,other,h,false,false,out r),"unrelated control intercepted");
  // Both seat actions are registered even when the native prefab has no interactables.
  var chair=new Thing();var left=new Slot{Parent=chair,Type=Slot.Class.Entity,Location=new Transform{position=new Vector3(-.24f,0,0)}};
  var right=new Slot{Parent=chair,Type=Slot.Class.Entity,Location=new Transform{position=new Vector3(.24f,0,0)}};
  chair.Slots.Add(left);chair.Slots.Add(right);SeatInteractionRouting.Ensure(chair);SeatInteractionRouting.Ensure(chair);
  A(chair.Interactables.Count==2&&left.Interactable!=null&&right.Interactable!=null,"missing or duplicate seat controls");
  A(left.Interactable.Slot==left&&right.Interactable.Slot==right,"actions do not bind their own slot");
  A(chair.Actions[InteractableType.Slot1]==left.Interactable&&chair.Actions[InteractableType.Slot2]==right.Interactable,"network action lookup mismatch");
  var surface=new BoxCollider{center=new Vector3(0,.35f,0),size=new Vector3(1,.7f,1)};
  CursorManager.CursorHit=new RaycastHit{collider=surface,point=new Vector3(-.2f,.4f,0)};
  var picked=SeatInteractionRouting.FromSurface(chair,surface,null);
  A(picked==left.Interactable&&picked.Collider==surface,"real left surface has no Sit action");
  CursorManager.CursorHit=new RaycastHit{collider=surface,point=new Vector3(.2f,.4f,0)};
  A(SeatInteractionRouting.FromSurface(chair,surface,left.Interactable)==right.Interactable,"shared native collider prevents right seat selection");
  right.Occupant=new Human();A(SeatInteractionRouting.FromSurface(chair,surface,null)==right.Interactable,"occupied target silently changed seats");
  A(SeatInteractionRouting.FromSurface(chair,surface,other)==other,"power/other control lost");
  A(SeatInteractionRouting.FromSurface(t,surface,bowl)==bowl,"toilet bowl was remapped to a hidden trigger");
  A(chair.Slots.Count==2&&chair.Slots[0]==left&&chair.Slots[1]==right,"slot indices changed during hover");
  // Anatomical correction is independent of the pelvis bone's bind axes.
  foreach(float yaw in new[]{0f,90f,180f,270f})foreach(float wantedYaw in new[]{0f,90f,180f,270f})
   foreach(float lean in new[]{0f,15f,45f})foreach(float bind in new[]{0f,73f,180f})
  {
   var body=Quaternion.Yaw(yaw)*Quaternion.Pitch(lean);var pelvis=body*Quaternion.Yaw(bind);
   var shoulders=body*Vector3.right;var up=body*Vector3.up;var wanted=Quaternion.Yaw(wantedYaw)*Vector3.forward;
   var corrected=ChairBodyFacing.Align(pelvis,shoulders,up,wanted);var delta=corrected*Quaternion.Inverse(pelvis);
   var forward=ChairBodyFacing.Forward(delta*shoulders,delta*up).normalized;
   A(Vector3.Dot(forward,wanted)>.9999f,"trunk still faces backwards");
   A(Math.Abs((delta*up).y-up.y)<.0001f,"yaw correction changed torso lean");
   A(Math.Abs((delta*shoulders).magnitude-shoulders.magnitude)<.0001f,"yaw correction changed rig scale");
  }
  var pose=Quaternion.Yaw(73);var unchanged=ChairBodyFacing.Align(pose,new Vector3(),Vector3.up,Vector3.forward);
  A((unchanged*Vector3.forward-pose*Vector3.forward).magnitude<.0001f,"degenerate rig invented a turn");
  A(ChairLayoutPolicy.DoubleFurniture("StructureSofaDouble"),"decorative sofa fallback absent");
  A(!ChairLayoutPolicy.DoubleFurniture("StructureBedDouble"),"double bed became chair");
  Console.WriteLine(count+" production interaction-prefix/surface-routing and anatomical-facing checks passed (game/math stubs).");
 }
}
namespace UnityEngine
{
 public struct Vector3{
  public float x,y,z;public Vector3(float a,float b,float c){x=a;y=b;z=c;}public float sqrMagnitude=>x*x+y*y+z*z;public float magnitude=>(float)Math.Sqrt(sqrMagnitude);public Vector3 normalized=>magnitude<.000001f?new Vector3():this*(1/magnitude);
  public static Vector3 up=>new Vector3(0,1,0);public static Vector3 right=>new Vector3(1,0,0);public static Vector3 forward=>new Vector3(0,0,1);
  public static Vector3 operator +(Vector3 a,Vector3 b)=>new Vector3(a.x+b.x,a.y+b.y,a.z+b.z);public static Vector3 operator -(Vector3 a,Vector3 b)=>new Vector3(a.x-b.x,a.y-b.y,a.z-b.z);public static Vector3 operator *(Vector3 a,float b)=>new Vector3(a.x*b,a.y*b,a.z*b);
  public static float Dot(Vector3 a,Vector3 b)=>a.x*b.x+a.y*b.y+a.z*b.z;public static Vector3 Cross(Vector3 a,Vector3 b)=>new Vector3(a.y*b.z-a.z*b.y,a.z*b.x-a.x*b.z,a.x*b.y-a.y*b.x);public static Vector3 ProjectOnPlane(Vector3 a,Vector3 normal)=>a-normal*(Dot(a,normal)/normal.sqrMagnitude);
 }
 public struct Quaternion{
  internal System.Numerics.Quaternion Value;public static Quaternion Yaw(float d)=>new Quaternion{Value=System.Numerics.Quaternion.CreateFromAxisAngle(System.Numerics.Vector3.UnitY,d*(float)Math.PI/180)};public static Quaternion Pitch(float d)=>new Quaternion{Value=System.Numerics.Quaternion.CreateFromAxisAngle(System.Numerics.Vector3.UnitX,d*(float)Math.PI/180)};
  public static Quaternion operator *(Quaternion a,Quaternion b)=>new Quaternion{Value=a.Value*b.Value};public static Quaternion Inverse(Quaternion q)=>new Quaternion{Value=System.Numerics.Quaternion.Inverse(q.Value)};
  public static Vector3 operator *(Quaternion q,Vector3 v){var r=System.Numerics.Vector3.Transform(new System.Numerics.Vector3(v.x,v.y,v.z),q.Value);return new Vector3(r.X,r.Y,r.Z);}
  public static Quaternion FromToRotation(Vector3 from,Vector3 to){float angle=(float)Math.Atan2(Vector3.Cross(from,to).y,Vector3.Dot(from,to));return new Quaternion{Value=System.Numerics.Quaternion.CreateFromAxisAngle(System.Numerics.Vector3.UnitY,angle)};}
 }
 public struct Bounds{public Vector3 center,size;public Bounds(Vector3 c,Vector3 s){center=c;size=s;}}
 public class Transform{public Vector3 position;public Vector3 InverseTransformPoint(Vector3 p)=>p-position;}
 public class Collider{public Transform transform=new Transform();public Bounds bounds;}public class BoxCollider:Collider{public Vector3 center,size;}public class MeshCollider:Collider{public Mesh sharedMesh;}public class Mesh{public Bounds bounds;}
 public struct RaycastHit{public Collider collider;public Vector3 point;}public static class Time{public static float time;}public static class Resources{public static T[] FindObjectsOfTypeAll<T>()=>new T[0];}
}
namespace Assets.Scripts{
 public static class GameManager{public static bool RunSimulation;}
 public static class CursorManager{public static RaycastHit CursorHit;}
 public static class MovementController{public enum Mode{Seated}}
}
namespace Assets.Scripts.Inventory{}
namespace HarmonyLib{}
namespace Assets.Scripts.GridSystem{public enum EntityState{Alive,Dead}}
namespace Assets.Scripts.Localization2{public static class GameStrings{public const string Use="Use";}}
namespace Assets.Scripts.Objects{
 public enum InteractableType{Activate,Slot1,Slot2,OnOff}
 public class Thing{
  public List<Slot> Slots=new List<Slot>();public List<Interactable> Interactables=new List<Interactable>();public Dictionary<InteractableType,Interactable> Actions=new Dictionary<InteractableType,Interactable>();public object StateObject;public bool IsStructureCompleted=true;
  public T GetComponent<T>()where T:class=>StateObject as T;
  public class DelayedActionInstance{public float Duration;public string ActionMessage,ExtendedMessage;public bool Success;public DelayedActionInstance Succeed(){Success=true;return this;}public DelayedActionInstance Fail(){Success=false;return this;}}
 }
 public class Slot{public enum Class{Entity}public Class Type;public Assets.Scripts.MovementController.Mode EntityControlMode;public Thing Parent;public Transform Location;public InteractableType Action;public string StringKey;public int StringHash;public bool IsLocked;public BoxCollider Collider;public Interactable Interactable;public Thing Occupant;public Thing Get()=>Occupant;}
 public class Interactable{public Thing Parent;public Slot Slot;public InteractableType Action;public string StringKey;public int StringHash;public Collider Collider;public Bounds Bounds,OriginalBounds;public void Initialize(){Slot=Parent.Slots.Find(s=>s.Action==Action);if(Slot!=null)Slot.Interactable=this;}}
 public struct Interaction{public Thing SourceThing;public bool AltKey;}
}
namespace Assets.Scripts.Objects.Entities{
 public class Human:Thing{public Slot ParentSlot;public Assets.Scripts.GridSystem.EntityState State;public bool SuitWorn,InFront=true;public ChairTransition Transition=new ChairTransition();public new T GetComponent<T>()where T:class=>Transition as T;}
}
namespace Objects.Structures{public class StructureToilet:Thing{}}
namespace StationEmotes{
 public class ChairTransition{public bool Active;public static bool InFront(Human h,Thing t)=>h.InFront;}
 internal class ToiletOccupancy{public Human Occupant;public float ReadyAt;}
 internal static class ToiletSeating{public const string Marker="StationEmotesToiletSeat";public static int Exits;public static Slot Slot(StructureToilet t)=>t.Slots.Find(s=>s.StringKey==Marker);public static bool Exit(Human h,StructureToilet t){Exits++;h.ParentSlot=null;return true;}public static void Register(Thing t,string f,object k,object v){if(f=="_interactableLookup")t.Actions[(InteractableType)k]=(Interactable)v;}}
 internal static class ChairSeatRouting{public static bool Supported(Thing t)=>true;public static bool Supported(Slot s)=>s!=null&&s.Location!=null;}
}
public static class OnServer{public static int Moves;public static void MoveToSlot(Human h,Slot s){Moves++;h.ParentSlot=s;s.Occupant=h;}}
