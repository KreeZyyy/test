using System;
using Assets.Scripts;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Emotes;
using Assets.Scripts.Objects.Entities;
using UnityEngine;
namespace StationEmotes
{
 internal enum TransitionDecision{Wait,Play,Abort}
 internal static class EmoteTransitionPolicy
 {
  internal static TransitionDecision Decide(int frames,float seconds,bool oldClip)
  {
   if(float.IsNaN(seconds)||seconds<0||frames<0)return TransitionDecision.Abort;
   if(seconds>=3.5f)return TransitionDecision.Abort;
   return frames<2||oldClip?TransitionDecision.Wait:TransitionDecision.Play;
  }
 }
 // A new pose is captured only after the old body emote has returned to idle.
 public sealed class EmoteTransition:MonoBehaviour
 {
  internal bool Applying {get;private set;}
  internal bool Pending=>pending;
  private bool pending;private int frame;private float time;
  private EmoteController controller;private EmoteData request;
  internal static void StopBody(EmoteController emotes)
  {
   if(emotes==null)return;
   emotes.GetComponent<GesturePose>()?.Stop();emotes.GetComponent<RobotDance>()?.Stop();emotes.GetComponent<HandsUpPose>()?.Stop();emotes.GetComponent<HeldEmote>()?.Stop(false);
   var a=Plugin.BodyAnimator.GetValue(emotes) as Animator;
   if(a!=null&&a.HasParameter(EmoteController.EmoteIndexHash))
   {int id=a.GetInteger(EmoteController.EmoteIndexHash);if(id>=1&&id<=3)a.SetInteger(EmoteController.EmoteIndexHash,0);}
  }
  internal void Schedule(EmoteController emotes,EmoteData data)
  {
   controller=emotes;pending=false;StopBody(emotes);
   request=data;frame=Time.frameCount;time=Time.unscaledTime;pending=true;
  }
  internal void Cancel(){pending=false;StopBody(controller!=null?controller:GetComponent<EmoteController>());}
  private void Update()
  {
   if(!pending)return;
   var human=controller!=null?Plugin.HumanField.GetValue(controller) as Human:null;
   if(human==null||human.State!=EntityState.Alive||GameManager.GameState!=GameState.Running){Cancel();return;}
   if(HeldEmote.MovingLocally(human))
   {Cancel();human.EmoteController.OnEmote(new EmoteData(Plugin.Cancel,0,EmoteType.Body));return;}
   var a=Plugin.BodyAnimator.GetValue(controller) as Animator;
   if(a==null){Cancel();return;}
   bool old=false;
   for(int layer=0;layer<a.layerCount;layer++)
   {
    old|=a.IsInTransition(layer);
    foreach(var c in a.GetCurrentAnimatorClipInfo(layer))
     if(c.clip!=null&&c.weight>.05f&&(HeldEmotePolicy.Matches(1,c.clip.name)||HeldEmotePolicy.Matches(2,c.clip.name)||HeldEmotePolicy.Matches(3,c.clip.name)))old=true;
   }
   var decision=EmoteTransitionPolicy.Decide(Time.frameCount-frame,Time.unscaledTime-time,old);
   if(decision==TransitionDecision.Wait)return;
   pending=false;
   if(decision==TransitionDecision.Abort){StopBody(controller);Plugin.Log.LogWarning("Emote switch timed out waiting for previous animation; press F9 and send log.");return;}
   Applying=true;
   try{controller.DoEmote(request);}
   catch(Exception e){StopBody(controller);Plugin.Log.LogWarning("Emote switch failed: "+e);}
   finally{Applying=false;}
  }
  private void OnDisable(){Cancel();}
  private void OnDestroy(){Cancel();}
 }
}
