using System;
namespace StationEmotes
{
 internal static class HeldEmotePolicy
 {
  internal static bool Matches(int id,string clip)=>id==1?clip.StartsWith("Salute",StringComparison.OrdinalIgnoreCase):id==2?string.Equals(clip,"wave",StringComparison.OrdinalIgnoreCase):id==3&&string.Equals(clip,"Sitting",StringComparison.OrdinalIgnoreCase);
  internal static float? TargetTime(int id,float normalized)
  {
   if(float.IsNaN(normalized)||float.IsInfinity(normalized)||normalized<0)return null;
   if(id==2)return normalized>=.68f?(float?).28f:null;
   float hold=id==1?.45f:id==3?.85f:float.PositiveInfinity;
   return normalized>=hold?(float?)hold:null;
  }
 }
}
