using System;
using System.Linq;
using Assets.Scripts;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Objects.Entities;
using UnityEngine;
namespace StationEmotes
{
    [DefaultExecutionOrder(10000)]
    public sealed class HandsUpPose:MonoBehaviour
    {
        internal bool Active=>active;
        private bool pointing;private NativePose pose;
        internal int Index=>active?(pointing?Plugin.Point:Plugin.HandsUp):0;
        private Human owner;private Transform[] bones;
        private Quaternion[] rest,target;private bool active;
        private float started;private Vector3 position;
        internal static bool TryRig(Animator animator,out Transform[] rig,out string why)
        {
            rig=null;why="Animator unavailable";if(animator==null||animator.runtimeAnimatorController==null)return false;
            if(animator.isHuman)
                rig=new[]{animator.GetBoneTransform(HumanBodyBones.LeftUpperArm),animator.GetBoneTransform(HumanBodyBones.LeftLowerArm),animator.GetBoneTransform(HumanBodyBones.LeftHand),animator.GetBoneTransform(HumanBodyBones.RightUpperArm),animator.GetBoneTransform(HumanBodyBones.RightLowerArm),animator.GetBoneTransform(HumanBodyBones.RightHand)};
            else
            {
                var all=animator.GetComponentsInChildren<Transform>(true);
                string[][] names={new[]{"leftupperarm","upperarml","lupperarm","bip001lupperarm","mixamorigleftarm","leftarm"},new[]{"leftlowerarm","lowerarml","lforearm","bip001lforearm","mixamorigleftforearm","leftforearm"},new[]{"lefthand","handl","lhand","bip001lhand","mixamoriglefthand"},new[]{"rightupperarm","upperarmr","rupperarm","bip001rupperarm","mixamorigrightarm","rightarm"},new[]{"rightlowerarm","lowerarmr","rforearm","bip001rforearm","mixamorigrightforearm","rightforearm"},new[]{"righthand","handr","rhand","bip001rhand","mixamorigrighthand"}};
                rig=new Transform[6];
                for(int i=0;i<6;i++)
                {
                    var matches=all.Where(t=>names[i].Contains(new string(t.name.Where(char.IsLetterOrDigit).ToArray()).ToLowerInvariant())).ToArray();
                    if(matches.Length!=1){why="Generic rig bone "+i+" has "+matches.Length+" matches; F9 report needed";return false;}
                    rig[i]=matches[0];
                }
            }
            if(rig.Any(t=>t==null)||rig.Distinct().Count()!=6){why="Arm bones missing or ambiguous";return false;}
            for(int i=0;i<6;i+=3)
                if(!rig[i+1].IsChildOf(rig[i])||!rig[i+2].IsChildOf(rig[i+1])||rig[i].parent==null||rig[i+1].parent==null||(rig[i+1].position-rig[i].position).sqrMagnitude<.000001f||(rig[i+2].position-rig[i+1].position).sqrMagnitude<.000001f)
                {why="Unsupported arm hierarchy or zero-length bones";return false;}
            why=null;return true;
        }
        internal void Begin(Human human,Animator animator,bool point=false)
        {
            Stop();if(!TryRig(animator,out var rig,out _))return;
            pointing=point;owner=human;bones=point?new[]{rig[3],rig[4],rig[5]}:new[]{rig[0],rig[1],rig[2],rig[3],rig[4],rig[5]};rest=bones.Select(t=>t.localRotation).ToArray();target=new Quaternion[bones.Length];
            var facing=human.CharacterRotationY!=null?human.CharacterRotationY:human.transform;
            for(int side=0;side<2;side++)
            {
                if(point&&side==0)continue;
                int j=side*3,k=point?0:side*3;var upper=rig[j];var lower=rig[j+1];var hand=rig[j+2];
                float sign=side==0?-1f:1f;
                // Elbows out at shoulder height, wrists above them rather than
                // both arms squeezed alongside the helmet.
                var desiredDirection=point?(facing.forward+facing.right*.06f-facing.up*.08f).normalized:(facing.up*.18f+facing.right*(sign*.98f)+facing.forward*.06f).normalized;
                var delta=Quaternion.FromToRotation(lower.position-upper.position,desiredDirection);
                var upperWorld=delta*upper.rotation;
                target[k]=Quaternion.Inverse(upper.parent.rotation)*upperWorld;
                var forearmDirection=point?facing.forward:(facing.up*.98f-facing.right*(sign*.10f)+facing.forward*.12f).normalized;
                var lowerWorld=Quaternion.FromToRotation(hand.position-lower.position,forearmDirection)*lower.rotation;
                target[k+1]=Quaternion.Inverse(delta*lower.parent.rotation)*lowerWorld;
                target[k+2]=hand.localRotation;
                if(animator.isHuman)
                {
                    var index=animator.GetBoneTransform(side==0?HumanBodyBones.LeftIndexProximal:HumanBodyBones.RightIndexProximal);
                    var little=animator.GetBoneTransform(side==0?HumanBodyBones.LeftLittleProximal:HumanBodyBones.RightLittleProximal);
                    var middle=animator.GetBoneTransform(side==0?HumanBodyBones.LeftMiddleProximal:HumanBodyBones.RightMiddleProximal);
                    if(index!=null&&little!=null&&middle!=null)
                    {
                        var fingers=middle.position-hand.position;
                        var normal=Vector3.Cross(index.position-hand.position,little.position-hand.position);
                        if(fingers.sqrMagnitude>.000001f&&normal.sqrMagnitude>.00000001f)
                        {
                            if(side==1)normal=-normal;
                            var frame=Quaternion.LookRotation(normal.normalized,fingers.normalized);
                            var desiredHand=(point?Quaternion.LookRotation(-facing.up,facing.forward):Quaternion.LookRotation(facing.forward,facing.up))*Quaternion.Inverse(frame)*hand.rotation;
                            var lowerDelta=lowerWorld*Quaternion.Inverse(lower.rotation);
                            target[k+2]=Quaternion.Inverse(lowerDelta*hand.parent.rotation)*desiredHand;
                        }
                    }
                }
            }
            pose=new NativePose();if(!pose.Attach(animator,bones)){pose.Dispose();pose=null;Plugin.Log.LogWarning("Native animation output unavailable; pose skipped.");return;}
            position=human.transform.position;started=Time.unscaledTime;active=true;enabled=true;
        }
        void Update()
        {
            if(!active)return;
            if(owner==null||owner.IsBeingDestroyed||owner.State!=EntityState.Alive||GameManager.GameState!=GameState.Running){Stop();return;}
            if(owner.LeftHandSlot?.Get()!=null||owner.RightHandSlot?.Get()!=null||HeldEmote.MovingLocally(owner)||(owner.transform.position-position).sqrMagnitude>.01f){Stop(true);return;}
            float t=Time.unscaledTime-started;
            float weight=Mathf.SmoothStep(0,1,Mathf.Clamp01(t/.55f));
            for(int i=0;i<bones.Length;i++)pose.Set(i,target[i],weight);
            if(!pose.Submit(owner,false))Stop(true);
        }
        internal void Stop(bool notify=false)
        {
            bool send=active&&notify&&owner!=null&&owner==Assets.Scripts.Inventory.InventoryManager.ParentHuman&&GameManager.GameState==GameState.Running;
            var emotes=owner?.EmoteController;
            pose?.Dispose();pose=null;
            active=false;bones=null;rest=null;target=null;owner=null;
            if(send&&emotes!=null)try{emotes.OnEmote(new Assets.Scripts.Emotes.EmoteData(Plugin.Cancel,0,Assets.Scripts.Emotes.EmoteType.Body));}
            catch(Exception e){Plugin.Log.LogWarning("Hands-up cancel relay failed: "+e);}
        }
        void OnDisable(){Stop();}
        void OnDestroy(){Stop();}
    }
}
