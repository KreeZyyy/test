using System;
namespace StationEmotes
{
 internal static class MemeDancePolicy
 {
  internal const float Period=1.6f;
  private static double Phase(float seconds)
   =>float.IsNaN(seconds)||float.IsInfinity(seconds)||seconds<0?0:(seconds%Period)/Period*Math.PI*2;
  internal static float Angle(int channel,float seconds)
  {
   double p=Phase(seconds);float swing=(float)Math.Sin(p),doubleBeat=(float)Math.Sin(p*2);
   return channel==0||channel==1?38f*swing:channel==2||channel==3?-8f:
    channel==4?-12f*swing:channel==5?-4f*doubleBeat:channel==6?4f*doubleBeat:
    channel==7||channel==8?6f*Math.Abs(doubleBeat):channel==9?-8f*swing:0f;
  }
  internal static float ShoulderPitch(int channel,float seconds)
  {
   float pass=(float)Math.Cos(Phase(seconds));
   return channel==0?-28f*(.5f+.5f*pass):channel==1?28f*(.5f-.5f*pass):0;
  }
 }
}
