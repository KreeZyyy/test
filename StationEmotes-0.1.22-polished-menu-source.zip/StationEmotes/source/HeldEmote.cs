using System;
using Assets.Scripts;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Inventory;
using Assets.Scripts.Objects.Entities;
using Assets.Scripts.Emotes;
using Assets.Scripts.UI;
using UnityEngine;
namespace StationEmotes
{
    [DefaultExecutionOrder(-100)]
    public sealed class HeldEmote:MonoBehaviour
    {
        internal bool Active {get;private set;}
        private Human owner;private Animator animator;private EmoteController controller;
        private Vector3 origin;
        internal int Index {get;private set;}
        private float started;private bool foundClip;
        internal static bool MovingLocally(Human human)
        {
            return human==InventoryManager.ParentHuman&&!Cursor.visible&&!InputWindowBase.IsInputWindow&&
                KeyManager.InputState==KeyInputState.Game&&
                (Math.Abs(KeyManager.GetForwardAxis())>.05f||Math.Abs(KeyManager.GetRightAxis())>.05f||
                 Math.Abs(KeyManager.GetAscend())>.05f||Math.Abs(KeyManager.GetDescend())>.05f);
        }
        internal void Begin(Human human,Animator body,EmoteController emotes,int index=3)
        {
            Stop(false);if(body==null||!body.HasParameter(EmoteController.EmoteIndexHash))return;
            owner=human;animator=body;controller=emotes;origin=human.transform.position;
            Index=index;started=Time.unscaledTime;foundClip=false;
            Active=true;animator.SetInteger(EmoteController.EmoteIndexHash,Index);
        }
        private void Update(){if(Active)CheckCancel();}
        private void LateUpdate()
        {
            if(!Active||CheckCancel())return;
            // A previous native short emote may still have an asynchronous reset.
            // Keep this held state until an explicit cancel/new emote/movement.
            if(animator.GetInteger(EmoteController.EmoteIndexHash)!=Index)animator.SetInteger(EmoteController.EmoteIndexHash,Index);
            for(int layer=0;layer<animator.layerCount;layer++)
            {
                if(animator.IsInTransition(layer))continue;
                bool match=false;float clipLength=1f;
                foreach(var clip in animator.GetCurrentAnimatorClipInfo(layer))
                    if(clip.clip!=null&&clip.weight>.05f&&HeldEmotePolicy.Matches(Index,clip.clip.name)){match=true;clipLength=clip.clip.length;break;}
                if(!match)continue;
                foundClip=true;var state=animator.GetCurrentAnimatorStateInfo(layer);
                float? time=HeldEmotePolicy.TargetTime(Index,state.normalizedTime);
                if(time.HasValue)
                {
                    if(Index==2)animator.CrossFadeInFixedTime(state.fullPathHash,.06f,layer,time.Value*clipLength);
                    else animator.Play(state.fullPathHash,layer,time.Value);
                }
            }
            if(!foundClip&&Time.unscaledTime-started>3f)
            {Plugin.Log.LogWarning("Held emote clip not found: ID="+Index+"; cancelling. F9 report needed.");Stop(true);}
        }
        private bool CheckCancel()
        {
            if(owner==null||owner.IsBeingDestroyed||owner.State!=EntityState.Alive||animator==null||
               GameManager.GameState!=GameState.Running){Stop(false);return true;}
            if(MovingLocally(owner)||(owner.transform.position-origin).sqrMagnitude>.01f){Stop(true);return true;}
            return false;
        }
        internal void Stop(bool notify)
        {
            if(!Active)return;
            bool send=notify&&owner!=null&&owner==InventoryManager.ParentHuman&&GameManager.GameState==GameState.Running;
            var emotes=controller;
            Active=false;
            if(animator!=null&&animator.GetInteger(EmoteController.EmoteIndexHash)==Index)animator.SetInteger(EmoteController.EmoteIndexHash,0);
            owner=null;animator=null;controller=null;
            if(send&&emotes!=null)
                try{emotes.OnEmote(new EmoteData(Plugin.Cancel,0,EmoteType.Body));}
                catch(Exception e){Plugin.Log.LogWarning("Sit cancel relay failed: "+e);}
        }
        private void OnDisable(){Stop(false);}
        private void OnDestroy(){Stop(false);}
    }
    internal static class SitAnimatorExtensions
    {
        internal static bool HasParameter(this Animator animator,int hash)
        {
            foreach(var p in animator.parameters)if(p.nameHash==hash&&p.type==AnimatorControllerParameterType.Int)return true;
            return false;
        }
    }
}
