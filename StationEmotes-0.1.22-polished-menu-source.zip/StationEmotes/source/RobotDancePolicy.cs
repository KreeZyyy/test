using System;
namespace StationEmotes
{
 internal static class RobotDancePolicy
 {
  internal const float Period=2f;
  private static readonly float[] Beats={0,1,1,0,0,-1,-1,0,0};
  internal static float Sample(float seconds)
  {
   if(float.IsNaN(seconds)||float.IsInfinity(seconds)||seconds<0)return 0;
   float beat=(seconds%Period)*4f;int index=(int)beat;
   float t=beat-index;t=t*t*(3f-2f*t);
   return Beats[index]+(Beats[index+1]-Beats[index])*t;
  }
 }
}
