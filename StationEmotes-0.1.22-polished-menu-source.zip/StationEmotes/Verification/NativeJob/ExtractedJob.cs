using System;using UnityEngine;using UnityEngine.Animations;
namespace StationEmotes {
 internal struct PoseSlot
 {
  public TransformStreamHandle Handle;public Quaternion Rotation;public float Weight;
  public bool Apply(AnimationStream stream)
  {if(!Handle.IsValid(stream))return false;Handle.Resolve(stream);Handle.SetLocalRotation(stream,Quaternion.Slerp(Handle.GetLocalRotation(stream),Rotation,Weight));return true;}
 }
 internal struct PoseJob:IAnimationJob
 {
  public int Count,Frames,HumanFrames,LastApplied;public bool Feet,Dance,Facepalm,FaceHandBound;public TransformStreamHandle FaceHand;public bool FaceCalibrated;public Vector3 FaceGoalOffset;public float FaceGoalAngle;public Vector3 PalmOffset;public Quaternion PalmRotation;public float PalmRotationWeight;public float LeftFloor,RightFloor,Sway,Bend,Blend;
  public PoseSlot A,B,C,D,E,F,G,H,I,J;
  public PoseSlot Get(int i){switch(i){case 0:return A;case 1:return B;case 2:return C;case 3:return D;case 4:return E;case 5:return F;case 6:return G;case 7:return H;case 8:return I;default:return J;}}
  public void Set(int i,PoseSlot s){switch(i){case 0:A=s;break;case 1:B=s;break;case 2:C=s;break;case 3:D=s;break;case 4:E=s;break;case 5:F=s;break;case 6:G=s;break;case 7:H=s;break;case 8:I=s;break;default:J=s;break;}}
  public void ProcessRootMotion(AnimationStream stream){} // Original root motion passes through unchanged.
  public void ProcessAnimation(AnimationStream stream)
  {
   Frames++;LastApplied=0;
   bool humanoid=stream.isHumanStream;
   if(humanoid)HumanFrames++;
   // Bone animation is valid for both generic and humanoid streams.
   // The Animator avatar being humanoid does not establish this stream's type.
   var human=humanoid?stream.AsHuman():default(AnimationHumanStream);
   // Capture the native stance BEFORE changing hips/legs. Let Unity solve knees/ankles.
   var left=humanoid?human.GetGoalPositionFromPose(AvatarIKGoal.LeftFoot):Vector3.zero;
   var right=humanoid?human.GetGoalPositionFromPose(AvatarIKGoal.RightFoot):Vector3.zero;
   var lr=humanoid?human.GetGoalRotationFromPose(AvatarIKGoal.LeftFoot):Quaternion.identity;var rr=humanoid?human.GetGoalRotationFromPose(AvatarIKGoal.RightFoot):Quaternion.identity;
   if(Feet&&humanoid)
   {
    if(Dance)
    {
     // Change the human pose BEFORE solving feet. Raw leg rotations would
     // either be discarded by SolveIK or undo its grounding if written after it.
     var body=human.bodyLocalPosition;
     body.x+=.018f*Sway*Blend;body.y-=.025f*Bend*Blend;
     human.bodyLocalPosition=body;
     human.bodyLocalRotation=human.bodyLocalRotation*Quaternion.AngleAxis(4f*Sway*Blend,Vector3.forward);
     var l=new MuscleHandle(HumanPartDof.LeftLeg,LegDof.LegCloseOpen);
     var r=new MuscleHandle(HumanPartDof.RightLeg,LegDof.LegCloseOpen);
     human.SetMuscle(l,Mathf.Clamp(human.GetMuscle(l)-.12f*Bend*Blend,-1f,1f));
     human.SetMuscle(r,Mathf.Clamp(human.GetMuscle(r)-.12f*Bend*Blend,-1f,1f));
    }
    left.y=LeftFloor+human.leftFootHeight;right.y=RightFloor+human.rightFootHeight;
    human.SetGoalPosition(AvatarIKGoal.LeftFoot,left);human.SetGoalPosition(AvatarIKGoal.RightFoot,right);
    human.SetGoalRotation(AvatarIKGoal.LeftFoot,lr);human.SetGoalRotation(AvatarIKGoal.RightFoot,rr);
    human.SetGoalWeightPosition(AvatarIKGoal.LeftFoot,1f);human.SetGoalWeightPosition(AvatarIKGoal.RightFoot,1f);
    human.SetGoalWeightRotation(AvatarIKGoal.LeftFoot,1f);human.SetGoalWeightRotation(AvatarIKGoal.RightFoot,1f);
    human.SolveIK();
   }
   if(Facepalm&&humanoid&&A.Handle.IsValid(stream)&&FaceHandBound&&FaceHand.IsValid(stream))
   {
    var anchor=A.Handle;anchor.Resolve(stream);
    // Use the head pose that will be applied AFTER SolveIK, so the palm follows
    // the face/helmet tilt rather than aiming at the previous head rotation.
    var local=anchor.GetLocalRotation(stream);
    var rotation=anchor.GetRotation(stream)*Quaternion.Inverse(local)*Quaternion.Slerp(local,A.Rotation,A.Weight);
    var hand=FaceHand;hand.Resolve(stream);
    var boneRotation=hand.GetRotation(stream);var bonePosition=hand.GetPosition(stream);
    var nativeGoalPosition=human.GetGoalPositionFromPose(AvatarIKGoal.RightHand);
    var nativeGoalRotation=human.GetGoalRotationFromPose(AvatarIKGoal.RightHand);
    var boneToGoalPosition=Quaternion.Inverse(boneRotation)*(nativeGoalPosition-bonePosition);
    var boneToGoalRotation=Quaternion.Inverse(boneRotation)*nativeGoalRotation;
    FaceGoalOffset=boneToGoalPosition;FaceGoalAngle=Quaternion.Angle(boneRotation,nativeGoalRotation);FaceCalibrated=true;
    var desiredBoneRotation=rotation*PalmRotation;
    var desiredBonePosition=anchor.GetPosition(stream)+rotation*PalmOffset;
    // The Avatar IK goal frame is NOT necessarily the imported wrist-bone frame.
    // Preserve their measured relationship instead of feeding a bone pose to the goal.
    human.SetGoalPosition(AvatarIKGoal.RightHand,desiredBonePosition+desiredBoneRotation*boneToGoalPosition);
    human.SetGoalRotation(AvatarIKGoal.RightHand,desiredBoneRotation*boneToGoalRotation);
    human.SetGoalWeightPosition(AvatarIKGoal.RightHand,A.Weight);
    human.SetGoalWeightRotation(AvatarIKGoal.RightHand,A.Weight*PalmRotationWeight);
    human.SolveIK();
   }
   // SolveIK rebuilds the humanoid pose: apply upper-body transforms AFTER it.
   // Dance slots 5..9 are legs/hips, now owned by the human pose + foot solver.
   int transforms=Feet&&humanoid&&Dance?Math.Min(Count,5):Count;
   for(int i=0;i<transforms;i++)if(Get(i).Apply(stream))LastApplied++;

  }
 }
}
