using System;using StationEmotes;
class Check{
 static int n;static void A(bool b,string m){n++;if(!b)throw new Exception(m);}
 static void Main(){
 A(RobotDancePolicy.Sample(0)==0,"nonzero start");A(RobotDancePolicy.Sample(.25f)==1,"first beat");A(RobotDancePolicy.Sample(1.25f)==-1,"opposite beat");A(RobotDancePolicy.Sample(2)==0,"loop seam");
 for(int i=0;i<100;i++){float t=i*.019f;float s=RobotDancePolicy.Sample(t);A(s>=-1&&s<=1,"range");A(Math.Abs(s-RobotDancePolicy.Sample(t+2))<.00001f,"period mismatch");}
 A(Math.Abs(RobotDancePolicy.Sample(1.9999f)-RobotDancePolicy.Sample(.0001f))<.001f,"loop discontinuity");
 A(RobotDancePolicy.Sample(-1)==0,"negative time");A(RobotDancePolicy.Sample(float.NaN)==0,"NaN");A(RobotDancePolicy.Sample(float.PositiveInfinity)==0,"infinity");
 Console.WriteLine(n+" production robot-rhythm checks passed.");
 }
}
