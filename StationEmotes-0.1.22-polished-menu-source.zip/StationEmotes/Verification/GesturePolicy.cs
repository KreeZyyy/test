using System;namespace StationEmotes{ internal static class GesturePolicy
 {
  // Two gentle nods/shakes, followed by a pause. Continuous until cancelled.
  internal static float Sample(float seconds)
  {
   if(float.IsNaN(seconds)||float.IsInfinity(seconds)||seconds<0)return 0;
   float phase=seconds%2.6f;
   return phase<1.6f?(float)Math.Sin(phase/1.6f*Math.PI*4)* (float)Math.Sin(phase/1.6f*Math.PI):0;
  }
 }
}