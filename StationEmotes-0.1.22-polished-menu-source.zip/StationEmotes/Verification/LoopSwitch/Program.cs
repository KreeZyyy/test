using System;using StationEmotes;
class Check{
 static int n;static void A(bool b,string m){n++;if(!b)throw new Exception(m);}
 static void Main(){
 A(HeldEmotePolicy.TargetTime(2,.67f)==null,"wave loops too soon");A(HeldEmotePolicy.TargetTime(2,.68f)==.28f,"middle wave segment incorrect");A(HeldEmotePolicy.TargetTime(2,.99f)==.28f,"wave restarts entry");A(HeldEmotePolicy.TargetTime(1,.6f)==.45f,"salute phase changed");A(HeldEmotePolicy.TargetTime(3,.9f)==.85f,"sit phase changed");
 A(EmoteTransitionPolicy.Decide(0,0,false)==TransitionDecision.Wait,"switch same frame");A(EmoteTransitionPolicy.Decide(1,.02f,false)==TransitionDecision.Wait,"insufficient settling");A(EmoteTransitionPolicy.Decide(2,.04f,false)==TransitionDecision.Play,"idle switch blocked");A(EmoteTransitionPolicy.Decide(100,2f,true)==TransitionDecision.Wait,"old pose captured");A(EmoteTransitionPolicy.Decide(200,3.5f,true)==TransitionDecision.Abort,"stuck old animation not cancelled");A(EmoteTransitionPolicy.Decide(200,4f,false)==TransitionDecision.Abort,"expired request played later");A(EmoteTransitionPolicy.Decide(-1,0,false)==TransitionDecision.Abort,"invalid frame accepted");A(EmoteTransitionPolicy.Decide(2,float.NaN,false)==TransitionDecision.Abort,"invalid time accepted");
 Console.WriteLine(n+" loop/transition policy checks passed.");
 }
}
