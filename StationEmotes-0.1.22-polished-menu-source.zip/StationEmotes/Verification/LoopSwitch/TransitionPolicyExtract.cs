namespace StationEmotes{
 internal enum TransitionDecision{Wait,Play,Abort}
 internal static class EmoteTransitionPolicy
 {
  internal static TransitionDecision Decide(int frames,float seconds,bool oldClip)
  {
   if(float.IsNaN(seconds)||seconds<0||frames<0)return TransitionDecision.Abort;
   if(seconds>=3.5f)return TransitionDecision.Abort;
   return frames<2||oldClip?TransitionDecision.Wait:TransitionDecision.Play;
  }
 }

}