using System;using StationEmotes;
class Check{
 static int n;static void A(bool b,string m){n++;if(!b)throw new Exception(m);}
 static void Main(){
 foreach(int channel in new[]{0,1,2,3,4,5,6,7,8,9}){
  for(int i=0;i<20;i++){
   float t=i*.071f,a=MemeDancePolicy.Angle(channel,t),p=MemeDancePolicy.ShoulderPitch(channel,t);
   A(!float.IsNaN(a)&&Math.Abs(a)<=38f,"joint amplitude invalid");A(!float.IsNaN(p)&&Math.Abs(p)<=28.001f,"shoulder pitch invalid");
   A(Math.Abs(a-MemeDancePolicy.Angle(channel,t+MemeDancePolicy.Period))<.001f,"joint period mismatch");
  }
 }
 A(MemeDancePolicy.Angle(4,.4f)*MemeDancePolicy.Angle(0,.4f)<0,"torso not counter-moving");
 A(MemeDancePolicy.Angle(5,.2f)==-MemeDancePolicy.Angle(6,.2f),"legs not opposed");
 A(MemeDancePolicy.Angle(99,1)==0,"unknown channel moves");
 foreach(float t in new[]{float.NaN,float.PositiveInfinity,-1f})A(!float.IsNaN(MemeDancePolicy.Angle(0,t)),"invalid time creates NaN");
 Console.WriteLine(n+" production meme-rhythm checks passed.");
 }
}
