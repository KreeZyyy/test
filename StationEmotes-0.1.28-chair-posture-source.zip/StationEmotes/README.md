# Station Emotes 0.1.28
Requires BepInEx and StationeersLaunchPad. Replace the previous mod version, do not enable duplicate versions.

Hold F10 and select with the mouse; release to play. F11 or movement cancels. Esc closes the menu only. Native Wave loops; Salute and Sit hold. Custom Hands up, Point, Robot dance, Meme dance, Agree, Disagree and Facepalm require empty hands. Agree repeats a gentle nod, Disagree repeats a head shake, Facepalm holds the right palm in front of the visor. All persist until cancelled, switched or the same entry selected again. Observing clients should use the same version.

0.1.22 refines the radial menu with larger filled spacesuit silhouettes and helmet visors, icon-only sectors, central gesture names, opaque convex sector fills to avoid antialiased triangle seams, an orange selection arc and quieter footer hints. Selection policy, F10 controls, animations and network behavior are unchanged from 0.1.21. Live game appearance remains unverified.

The previous0.1.16 update corrects Facepalm wrist/IK-goal frame conversion. The job samples the native hand bone and native humanoid hand goal from the same animation stream, preserves their relative position/rotation, and maps the desired wrist pose into the correct goal frame. Imported bone axes are no longer treated as AvatarIKGoal axes.

The target height uses actual eye_l/eye_r landmarks where uniquely available. Named index/middle bones still calibrate the palm. Head-relative offsets remain in world distance units, and the palm follows the head tilt applied after the solver. Helmet detection and mesh-aware forward clearance remain separate from the bare-head profile. Unknown rigs use bounded fallback profiles. No guarantee is made for visual fit across every head/helmet: check both helmet and no-helmet appearances in game. Other gestures/dances are unchanged.

0.1.13 added three gestures and a larger ten-item wheel. IDs Agree41006, Disagree41007 and Facepalm41008 use the existing game emote message and cancellation/transition path. Facepalm uses humanoid right-hand IK; nod/shake use head transforms in the same owned overlay. No new root movement or game simulation is added.

The dance baseline from 0.1.12 keeps the 0.1.11 owned PreviousInputs overlay graph (confirmed live for Hands up and Point). It corrects dance ordering: humanoid pelvis/knee motion is submitted before SolveIK, then five upper-body transform slots are applied after SolveIK. Raw leg/hip transform slots are not applied over solved feet. This prevents the IK pass from rebuilding away the visible upper-body dance and prevents subsequent raw leg rotations from undoing foot support. The character root is not moved.

The 0.1.11 user log recorded 49 processed humanoid frames and 9/9 or 10/10 bone updates for dances despite their lack of visible motion. These counters prove execution, not visual correctness. The IK pass is the code path that distinguishes dance from working arm poses. The change requires another live visual test.

Custom poses still use procedural stream bone updates, with humanoid foot IK for dance where available. No imported animation clip or new physical movement is included. Native animations and cancellation policies are unchanged.

The earlier 0.1.10 scheduling failure was addressed in 0.1.11. Execution counters remain logged after one second; actual Unity rendering, graph evaluation, foot IK and multiplayer appearance still require live verification.

Build: source/StationEmotes.csproj, net472. Set GameManagedDirectory, BepInExDirectory and LaunchPadDirectory. Use the installed game UnityEngine.AnimationModule (including UnityEngine.Experimental.Animations output extensions) and PhysicsModule. Do not ship game or loader DLLs.


## Chair transitions — 0.1.28 prototype
Replaces the failed 0.1.23 pelvis-world-position interpolation. Ordinary chair entry is staged: a short alignment step (0.35s), turn toward the native seated facing direction (0.55s), then sit (0.85s). Exit reverses these phases. The body pose remains upright through alignment/turn; only the final phase blends toward the native seated pose. A small opposing thigh swing accompanies the alignment step; this is procedural, not a walking clip or foot IK.

Get In is accepted only while grounded directly in front of an empty ordinary Seat. Uses the chair's native ExitPosition as the front anchor, with ±0.45m lateral tolerance, -0.15..0.75m forward tolerance and ±0.55m height tolerance. Other positions return a disabled interaction with an English explanation. Native occupancy/entry validation remains intact; special seats and placing other items are not redesigned.

The common CharacterRotationY visual parent moves the complete skeleton, including HeadBone and its helmet/hair attachments. Runtime validation requires that the head belongs to that hierarchy; otherwise the transition is skipped and logged. Hips are blended in local space only. The main camera in first person is mapped through the same staged visual parent. Third-person camera translates by the visual offset, retaining its orbit. Visual offsets are restored before each animation update and on cancellation.

Native server root position, collider and slot ownership still change immediately. This is a staged visual transition, not collision-aware character locomotion, root-motion import or pathfinding. No new network messages. Every client needs the same build for consistent rendering; multiplayer timing and live visual quality remain unverified. Large native moves over 1.5m skip smoothing. F11/new emote/movement/death/slot change/unload cancel the transition.

Only ordinary exact Seat is enabled. Toilets, atmospheric/control/rocket seats and beds remain unchanged. No new wheel entry: use the chair normally.

Test in-game: stand on the floor directly before a normal empty chair and use Get In; observe the short alignment, turn, head/helmet attachment, camera and final sit. Exit and check the reverse sequence. Repeat from the sides/back to verify the front-only message; repeat with another player observing. Feet and staged orientation still require live validation.


## 0.1.28 standing-plane height fix
The 0.1.24 user test showed the full transition playing above the floor. The front/exit marker was allowed to contribute world Y to the alignment path. The final visual root Y now uses the captured entry standing height throughout approach and turn, blending to the native seat height only during the sit phase. On exit it reaches the native standing target height during rise, then holds it for turn/step. The first-person camera's relative vertical offset follows the same phase policy. Horizontal alignment, facing, head hierarchy, front-only entry gate and native physics/network ownership are unchanged. This is not a new foot IK solution. Live height/contact verification remains required.


## 0.1.28 temporary third-person chair inspection camera
The local player switches to third person during the chair transition, using the native SetThirdPersonCamera API so the head, helmet and wear visibility are updated. A temporary three-quarter overview tracks the animated visual root rather than the already seated physical root. A raycast shortens its desired 2.7m distance for walls; tight rooms can still restrict visibility. The native seated camera path does not consistently invoke the free third-person orbit, so the inspection view positions the camera after native updates.

On completion/cancel/disable/unload the prior view mode is restored. An existing third-person view remains third person. Camera control is scoped to the current local human and camera controller; remote players, dedicated servers and cinematic mode do not start an inspection view. No changes to emote-wheel animations, chair timing, height policy, physics or networking. Live appearance and restoration still need in-game validation.


## Current chair prototype: 0.1.28 footwork
Replaces the small thigh swing with alternating world-space foot contacts and a two-bone leg solve after moving the visual parent. Entry uses two alignment steps (0.70s total), six turning steps (1.35s), then sit (1.05s): 3.10s total. Exit rises, turns with six steps, then takes two alignment steps. The support foot retains its world contact while the swing foot follows an eased trajectory with up to 7.5cm lift. Measured ankle-to-floor clearance and local ground probes supply contact height. Small lateral weight transfer follows the support foot; head/chest anticipate the turn.

The final sit phase eases leg control back to the native seat pose. The last two exit steps converge to the live native standing feet. Missing leg bones skip the transition. A one-time warning reports contacts outside reachable leg length. This is still a procedural animation, not an imported authored walking clip, full pathfinding or an authoritative movement simulation. Ground raycasts and an analytical two-bone solver are used; natural appearance and foot reach need live testing.

The temporary third-person inspection camera from 0.1.26 remains enabled during chair transitions and restores the prior mode afterward. Front-only entry and standing-height policy remain; physics/slot/network behavior is unchanged. Test in a clear area before a standard chair, inspecting the planted foot, lifted foot, knee bending, turn direction, head and final settle, then repeat exit and multiplayer observation.


## 0.1.28 sit/rise posture refinement
User reports excessive leaning on sitting and a falling impression on standing. The previous rise used the same easing for native body-pose blend, height and full horizontal root travel. Rise now has an initial 18% hold before extending the native pose, and forward root travel begins at 32% of the rise interval. Sitting starts bending first; pelvis/root travel starts 12% into the sit phase. Both reach exact native endpoints within the existing 1.05s sit/rise interval. Approach, six turning steps, camera and total 3.1s timing remain.

During the interior of sit/rise, the anatomical hips-to-head direction is corrected toward a maximum 12-degree torso lean in world space. The correction ramps in/out over the first/last 15% of pose progress; native endpoints remain untouched. The leg solver runs after the correction so it can retain the planned support contacts. This limits anatomical torso lean, not rig-specific Euler angles. It is still a procedural prototype: natural motion, leg reach and actual rendering require live validation.
