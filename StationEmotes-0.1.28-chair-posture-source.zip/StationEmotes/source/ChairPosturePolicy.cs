using System;
namespace StationEmotes
{
 internal static class ChairPosturePolicy
 {
  internal const float MaxLean=12f;
  // Let the legs begin to extend before translating the whole visual root forward.
  internal static float Rise(float elapsed)=>ChairTransitionPolicy.Ease((elapsed/ChairTransitionPolicy.Sit-.18f)/.82f);
  internal static float Advance(float elapsed)=>ChairTransitionPolicy.Ease((elapsed/ChairTransitionPolicy.Sit-.32f)/.68f);
  // Start bending before taking the pelvis back over the seat.
  internal static float SeatTravel(float elapsed)=>ChairTransitionPolicy.Ease(((elapsed-ChairTransitionPolicy.Approach-ChairTransitionPolicy.Turn)/ChairTransitionPolicy.Sit-.12f)/.88f);
  // Keep exact native endpoints; apply the lean limit only within the transition.
  internal static float Window(float phase)=>ChairTransitionPolicy.Ease(Math.Min(phase/.15f,(1-phase)/.15f));
 }
}
