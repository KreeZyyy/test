using System;using StationEmotes;
class Check{
 static int n;static void A(bool b){n++;if(!b)throw new Exception("posture check "+n);}static bool Near(float a,float b)=>Math.Abs(a-b)<.00001;
 static void Main(){
 float duration=ChairTransitionPolicy.Sit,begin=ChairTransitionPolicy.Approach+ChairTransitionPolicy.Turn;
 A(ChairPosturePolicy.Rise(0)==0);A(ChairPosturePolicy.Advance(duration*.3f)==0);A(ChairPosturePolicy.Rise(duration*.3f)>0);
 A(Near(ChairPosturePolicy.Rise(duration),1));A(Near(ChairPosturePolicy.Advance(duration),1));A(ChairPosturePolicy.SeatTravel(begin)==0);A(ChairPosturePolicy.SeatTravel(begin+.1f*duration)==0);A(Near(ChairPosturePolicy.SeatTravel(begin+duration),1));
 float oldRise=0,oldAdvance=0,oldSeat=0;
 for(int i=0;i<=100;i++){float t=i*duration/100,r=ChairPosturePolicy.Rise(t),a=ChairPosturePolicy.Advance(t),s=ChairPosturePolicy.SeatTravel(begin+t);A(r>=oldRise-.00001&&a>=oldAdvance-.00001&&s>=oldSeat-.00001);A(a<=r+.00001);A(s<=ChairTransitionPolicy.Blend(begin+t)+.00001);oldRise=r;oldAdvance=a;oldSeat=s;}
 A(ChairPosturePolicy.Window(0)==0);A(ChairPosturePolicy.Window(1)==0);A(ChairPosturePolicy.Window(.5f)==1);A(ChairPosturePolicy.MaxLean==12);
 foreach(float angle in new[]{5f,12f,25f,45f,80f}){float middle=angle-Math.Max(0,angle-ChairPosturePolicy.MaxLean)*ChairPosturePolicy.Window(.5f);A(Near(middle,Math.Min(angle,ChairPosturePolicy.MaxLean)));A(Near(angle-Math.Max(0,angle-12)*ChairPosturePolicy.Window(1),angle));}
 Console.WriteLine(n+" production chair posture timing/envelope checks passed (no Unity rendering).");}}
