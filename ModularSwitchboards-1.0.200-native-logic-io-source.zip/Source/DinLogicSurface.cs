using System;using Assets.Scripts.Objects;using Assets.Scripts.Objects.Motherboards;using UnityEngine;
namespace ModularSwitchboards {
 // MPBs are not serialized by Unity cloning. Restore owned role colours after native colour writes and instance Awake.
 internal static class DinLogicSurface {
  internal static bool Fixed(string name)=>name.StartsWith("AuthoredLogicFace",StringComparison.Ordinal)||name.StartsWith("AuthoredLogicScrew",StringComparison.Ordinal)||name.StartsWith("AuthoredLogicCableEntry",StringComparison.Ordinal);
  internal static void Restore(Thing owner){
   if(!(owner is IDinLogic))return;
   foreach(var r in owner.GetComponentsInChildren<MeshRenderer>(true)){
    if(r.GetComponentInParent<Thing>(true)!=owner)continue;
    bool body=r.name=="DinBreakerModel",fixedRoles=Fixed(r.name),led=r.name=="AuthoredLogicLED";
    bool terminal=r.name=="LogicDataIn"||r.name=="LogicDataOut"||r.name=="LogicPower";
    bool black=r.name=="ScrewRecess"||r.name=="ScrewSlot"||r.name.StartsWith("CableSocket",StringComparison.Ordinal);
    if(!body&&!fixedRoles&&!led&&!terminal&&!black)continue;
    r.shadowCastingMode=body?UnityEngine.Rendering.ShadowCastingMode.On:UnityEngine.Rendering.ShadowCastingMode.Off;
    r.receiveShadows=body;
    r.SetPropertyBlock(null);int slots=r.sharedMaterials.Length;for(int i=0;i<slots;i++)r.SetPropertyBlock(null,i);
    // The native status controller owns the LED material/state. Never replace it with a body swatch.
    if(led)continue;
    for(int i=0;i<slots;i++){
     int color=black||r.name=="AuthoredLogicFaceTerminals"?(int)ColorType.Black:terminal?(i==3?(int)ColorType.Black:(int)ColorType.Gray):body?(i==1?(int)ColorType.White:CabinetGeometry.PaletteIndices[i]):i==0||i==3?(int)ColorType.Black:i==2?(int)ColorType.White:(int)ColorType.Gray;
     var b=new MaterialPropertyBlock();b.SetFloat(Thing.DiffuseIndexPropertyID,color);b.SetFloat(Thing.SmoothnessIndexPropertyID,0f);b.SetColor(Thing.EMISSION_COLOR,Color.black);r.SetPropertyBlock(b,i);
    }
   }
  }
 }
}
