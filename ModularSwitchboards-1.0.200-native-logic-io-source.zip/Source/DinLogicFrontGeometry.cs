using System;using System.Collections.Generic;using UnityEngine;
namespace ModularSwitchboards {
 // All vertices are generated here: our panel, pads, lettering, screw heads and LED lens.
 internal static class DinLogicFrontGeometry {
  private sealed class Builder {
   internal List<Vector3> V=new List<Vector3>(),N=new List<Vector3>();internal List<int>[] T={new List<int>(),new List<int>(),new List<int>(),new List<int>(),new List<int>()};
   internal void Box(int role,Vector3 p,Vector3 size,float r=.0004f)=>RoundedGeometry.Box(V,N,T[role],p,size,r);
   internal void Quad(int role,float left,float right,float bottom,float top,float z){int i=V.Count;V.AddRange(new[]{new Vector3(left,bottom,z),new Vector3(right,bottom,z),new Vector3(right,top,z),new Vector3(left,top,z)});N.AddRange(new[]{Vector3.forward,Vector3.forward,Vector3.forward,Vector3.forward});T[role].AddRange(new[]{i,i+1,i+2,i,i+2,i+3});}
   internal void Ring(int role,int sides,float radius0,float z0,float radius1,float z1){for(int j=0;j<sides;j++){float a=j*Mathf.PI*2/sides,b=(j+1)*Mathf.PI*2/sides;int i=V.Count;var n=new Vector3(Mathf.Cos((a+b)*.5f),Mathf.Sin((a+b)*.5f),0);V.AddRange(new[]{new Vector3(radius0*Mathf.Cos(a),radius0*Mathf.Sin(a),z0),new Vector3(radius0*Mathf.Cos(b),radius0*Mathf.Sin(b),z0),new Vector3(radius1*Mathf.Cos(b),radius1*Mathf.Sin(b),z1),new Vector3(radius1*Mathf.Cos(a),radius1*Mathf.Sin(a),z1)});N.AddRange(new[]{n,n,n,n});T[role].AddRange(new[]{i,i+1,i+2,i,i+2,i+3});}}
   internal void Cap(int role,int sides,float radius,float z){for(int j=0;j<sides;j++){float a=j*Mathf.PI*2/sides,b=(j+1)*Mathf.PI*2/sides;int i=V.Count;V.AddRange(new[]{new Vector3(0,0,z),new Vector3(radius*Mathf.Cos(a),radius*Mathf.Sin(a),z),new Vector3(radius*Mathf.Cos(b),radius*Mathf.Sin(b),z)});N.AddRange(new[]{Vector3.forward,Vector3.forward,Vector3.forward});T[role].AddRange(new[]{i,i+1,i+2});}}
   internal Mesh Finish(string name){var m=new Mesh{name=name};m.SetVertices(V);m.SetNormals(N);m.subMeshCount=5;for(int i=0;i<5;i++)m.SetTriangles(T[i],i);CabinetGeometry.ApplyNativeUv(m);m.RecalculateBounds();return m;}
  }
  internal static Mesh Front(string native){var b=new Builder();b.Box(1,new Vector3(0,0,.076f),new Vector3(.072f,.071f,.004f),.001f);b.Box(0,new Vector3(0,0,.079f),new Vector3(.066f,.066f,.002f),.0006f);
   for(int side=-1;side<=1;side+=2)for(int i=0;i<8;i++)b.Box(4,new Vector3(side*.0345f,(i-3.5f)*.0075f,.079f),new Vector3(.004f,.0054f,.0014f),.00025f);
   string shortName=native.Substring("StructureLogic".Length);
   return b.Finish("Switchboards.AuthoredLogicFront."+shortName);
  }
  internal static Mesh Screw(){var b=new Builder();b.Ring(4,6,.0033f,0,.0033f,.0022f);b.Ring(4,6,.0033f,.0022f,.0029f,.0027f);b.Cap(4,6,.0029f,.0027f);b.Box(3,new Vector3(0,0,.00285f),new Vector3(.0046f,.00075f,.00025f),.00008f);return b.Finish("Switchboards.AuthoredLogicScrew");}
  internal static Mesh Lens(){var b=new Builder();b.Ring(0,12,.0028f,0,.0028f,.001f);b.Ring(0,12,.0028f,.001f,.0023f,.0022f);b.Ring(0,12,.0023f,.0022f,.0012f,.0028f);b.Cap(0,12,.0012f,.0028f);return b.Finish("Switchboards.AuthoredLogicLED");}
 }
}
