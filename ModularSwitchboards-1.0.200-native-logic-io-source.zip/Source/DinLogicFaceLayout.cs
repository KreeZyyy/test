using UnityEngine;
namespace ModularSwitchboards {
 internal static class DinLogicFaceLayout {
  internal const float OriginZ=.059f,ScaleY=.94f,ScaleZ=.18f,ControlZ=.074f,PrintZ=.07365f;
  internal static Vector3 Scale=>new Vector3(1,ScaleY,ScaleZ);
 }
}
