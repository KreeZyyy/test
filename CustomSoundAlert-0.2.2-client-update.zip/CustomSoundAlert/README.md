# Custom SoundAlert 0.2.2 — empty-server isolation test

This test separates singleplayer sounds from the server's catalog. Audio transfer is not implemented.

## Server

Install `CustomSoundAlert-0.2.2-server.zip` alongside the required StationeersLaunchPad/BepInEx/LaunchPadBooster dependencies. Start the server once. The mod creates `sounds` next to `CustomSoundAlert.dll` automatically and logs its absolute path and entry count. This ZIP includes no sound files. Leave that directory empty for this test. An empty server catalog means only the game's original sounds are available to joining clients. Restart after adding files later.

## Client

Close the game and extract `CustomSoundAlert-0.2.2-client-update.zip` over the existing `CustomSoundAlert` folder. Keep your existing `sounds` directory and all its files. The update contains no audio and does not replace or delete your sounds. Disable any old `CustomSpeakerSounds` installation so only one mod copy loads. Use 0.2.2 on both client and server.

1. Start singleplayer: your local custom IDs and sounds should remain available.
2. Join the server with an empty sounds folder: only original game sounds should appear; your private local custom sounds must not be listed or played.
3. Disconnect and reopen singleplayer: your local custom sounds should return after loading.
4. Reconnect to the empty server: the list should return to original sounds again.

The mod removes custom registrations when changing contexts, without deleting private audio files. Remote clients use only the received server catalog and its separate SHA256-verified cache; an empty catalog uses no cached sounds either. A client waiting for a catalog also hides local custom entries.

This build retains the 0.2.1 AudioManager caching and event-lookup performance fixes. Dedicated servers create/scan the sounds folder and publish metadata without audio decoding or AudioManager discovery. Large local songs still require memory when decoded in singleplayer.

Native API compilation and regression fixtures are included in the source ZIP. Live dedicated-server joins and reconnects need testing. This build has no published Workshop association.

## Credits

Inspired by Sovana122's implementation: https://github.com/Sovana122/Sationeers-CustomSound/tree/speaker
Original attribution and license are preserved in LICENSE-Sovana.txt.
