using System;
using System.Collections.Generic;
using System.Reflection;
using ModularSwitchboards;
using UnityEngine;
namespace UnityEngine {
 public class SerializeField:Attribute{}
 public class Object { public static void Destroy(object x){} }
 public class MonoBehaviour:Object {public Transform transform=new Transform();}
 public struct Vector3 {public float x,y,z;public Vector3(float a,float b,float c){x=a;y=b;z=c;}}
 public class GameObject{}
 public class Transform {public Dictionary<string,Transform> children=new Dictionary<string,Transform>();public MeshFilter filter; public Vector3 localPosition;public Transform Find(string n)=>children.TryGetValue(n,out var t)?t:null;public T GetComponent<T>()where T:class=>filter as T;}
 public class MeshFilter {public Mesh sharedMesh;public GameObject gameObject=new GameObject();}
 public class Mesh {public object bounds=new object();}
}
namespace ModularSwitchboards {
 public class DinBreaker {public bool IsCursor;public Wireframe Wireframe;public Host host;}
 public class Host {public string PrefabName;public bool IsOpen;}
 public class Wireframe {public MeshFilter BlueprintMeshFilter;public object BlueprintBounds;}
 static class CabinetWiring {internal static Host CabinetOf(DinBreaker o)=>o.host;}
 static class CabinetShape {internal static bool Medium(string n)=>n=="Medium";}
 static class DoorContactLayout {internal static float PlungerX(bool m)=>m?-.008f:.004f;}
 static class DoorContactModel {public static Mesh Small=new Mesh(),Medium=new Mesh();public static bool Empty;internal static Mesh Body(bool m)=>m?Medium:Small;internal static Mesh Blueprint(DinBreaker o)=>Empty?null:new Mesh();}
 static class FittedModelCollider {public static int Calls;internal static void Rebuild(DinBreaker o){Calls++;}}
 static class PlacementOutline {internal static void Refresh(GameObject g,Mesh m){}}
 static class DoorModules {public static int Paints;internal static void PaintCubes(Transform t){Paints++;}}
 static class Program {
 static int checks;
 static void Check(bool ok,string msg){checks++;if(!ok)throw new Exception(msg);}
 static void Tick(DoorContactView v)=>typeof(DoorContactView).GetMethod("LateUpdate",BindingFlags.Instance|BindingFlags.NonPublic).Invoke(v,null);
 static DoorContactView Make(bool refs,bool hierarchy){var v=new DoorContactView{Owner=new DinBreaker(),Plunger=new Transform()};var h=new Transform{filter=new MeshFilter()};var c=new Transform();var a=new Transform();if(refs){v.Housing=h.filter;v.Collar=c;v.Actuator=a;}if(hierarchy){var root=new Transform();v.transform.children["DoorContactRimAssembly"]=root;root.children["DoorContactHousing"]=h;root.children["DoorContactPlungerCollar"]=c;v.Plunger.children["DoorContactActuator"]=a;}return v;}
 static void Main(){
  var empty=new DoorContactView();Tick(empty);Check(true,"uninitialized spawn");
  var v=Make(false,false);for(int i=0;i<100;i++){v.RefreshProfile();Tick(v);}Check(FittedModelCollider.Calls==0,"missing graphics do not rebuild");
  var root=new Transform();v.transform.children["DoorContactRimAssembly"]=root;root.children["DoorContactHousing"]=new Transform();for(int i=0;i<100;i++)Tick(v);Check(FittedModelCollider.Calls==0,"missing MeshFilter");
  v=Make(true,false);v.Owner.host=new Host{PrefabName="Medium"};Tick(v);Check(v.Housing.sharedMesh==DoorContactModel.Medium,"serialized refs survive missing/renamed hierarchy");Check(v.Collar.localPosition.x==-.008f&&v.Actuator.localPosition.x==-.008f,"Medium fit");int rebuilds=FittedModelCollider.Calls;for(int i=0;i<100;i++)Tick(v);Check(FittedModelCollider.Calls==rebuilds,"no per-frame rebuild");
  v.Owner.host.IsOpen=true;Tick(v);Check(v.Plunger.localPosition.z==0,"open plunger");v.Owner.host.IsOpen=false;Tick(v);Check(v.Plunger.localPosition.z==-.008f,"closed plunger");
  v.Owner.host=null;Tick(v);Check(v.Housing.sharedMesh==DoorContactModel.Medium,"unbound keeps previous profile");v.Owner.host=new Host{PrefabName="Small"};Tick(v);Check(v.Housing.sharedMesh==DoorContactModel.Small&&v.Actuator.localPosition.x==.004f,"Small fit");
  v=Make(false,true);Tick(v);Check(v.Housing!=null&&v.Collar!=null&&v.Actuator!=null,"fallback binds complete model");
  v.Owner.IsCursor=true;v.Owner.Wireframe=new Wireframe();Tick(v);Check(true,"preview filter not yet created");v.Owner.Wireframe.BlueprintMeshFilter=new MeshFilter();DoorContactModel.Empty=true;Tick(v);Check(v.Owner.Wireframe.BlueprintMeshFilter.sharedMesh==null,"empty preview deferred");DoorContactModel.Empty=false;Tick(v);var mesh=v.Owner.Wireframe.BlueprintMeshFilter.sharedMesh;Check(mesh!=null,"preview retries when ready");Tick(v);Check(v.Owner.Wireframe.BlueprintMeshFilter.sharedMesh==mesh,"stable preview reused");
  Console.WriteLine(checks+" lifecycle checks passed (actual DoorContactView source; Unity API stubs).");
 }
 }
}
