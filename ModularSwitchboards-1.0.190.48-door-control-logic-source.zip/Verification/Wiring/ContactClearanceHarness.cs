using System;using System.Linq;using ModularSwitchboards;
static class ContactClearanceHarness
{
 internal static void Run()
 {
  int checks=0;
  foreach(bool medium in new[]{false,true})foreach(int side in new[]{-1,1})foreach(bool reverse in new[]{false,true})foreach(var kind in new[]{CabinetWireKind.Normal,CabinetWireKind.Heavy,CabinetWireKind.SuperHeavy})
  {
   var p=new WireRoutePlanner{prefabName=medium?"medium":"small",routingHalfWidth=medium?.366f:.168f,routingHalfHeight=medium?.477f:.228f,moduleReservations=Array.Empty<WireRect>()};
   var sensor=new CabinetWireEnd(101,0);var source=new CabinetWireEnd(102,1);var unused=new CabinetWireEnd(101,1);
   float center=side*(medium?.357f:.177f),x=center-side*.009f,exit=center-side*.030f;
   var box=new WireRect(x-(side==1?.009f:.018f),x+(side==1?.018f:.009f),-.011f,.011f);
   p.contacts[sensor]=new(){End=sensor,Position=new(x,0,.0244f),Exit=new(exit,0,WireRouting.Plane),LeadSide=-side,Bounds=box};
   p.contacts[unused]=new(){End=unused,Position=new(x,-.024f,.0244f),Exit=new(exit,-.024f,WireRouting.Plane),LeadSide=-side,Bounds=new(box.Left,box.Right,-.035f,-.013f)};
   p.contacts[source]=new(){End=source,Position=new(0,.09f,.029f),Exit=new(0,.07f,WireRouting.Plane),Bounds=new(-.02f,.02f,.09f,.16f)};
   var obstacle=side==-1?new WireRect(exit-.006f,exit+.075f,-.015f,.015f):new WireRect(exit-.075f,exit+.006f,-.015f,.015f);
   p.railObstacles.Add(obstacle);p.capacities[sensor]=1;p.capacities[source]=1;p.capacities[unused]=1;
   var from=reverse?sensor:source;var to=reverse?source:sensor;
   if(p.MakeRoute(from,to,out _,out _,kind)!=null)throw new Exception("fixture failed to reproduce straight sensor lead blockage");checks++;
   p.contacts[sensor].DoorContact=true;p.contacts[unused].DoorContact=true;
   var path=p.MakeRoute(from,to,out _,out var error,kind);
   if(path==null)throw new Exception("sensor side escape failed "+medium+" "+side+" "+reverse+" "+kind+": "+error);checks++;
   if((path[0]-p.contacts[from].Position).Squared>1e-10f||(path[path.Length-1]-p.contacts[to].Position).Squared>1e-10f)throw new Exception("sensor route changed endpoints");checks++;
   foreach(var pair in path.Zip(path.Skip(1)))if(WireRouting.SegmentHitsRect(pair.First,pair.Second,obstacle,.005f))throw new Exception("escape crosses real obstruction");checks++;
   p.railObstacles.Clear();p.contacts[sensor].DoorContact=false;p.contacts[unused].DoorContact=false;
   p.wires.Add(new CabinetWireSaveData{From=new CabinetWireEnd(999,1),To=new CabinetWireEnd(1000,0),Points=new[]{exit,0f,.02f,exit,0f,.12f},CableKind=kind});
   if(p.MakeRoute(from,to,out _,out _,kind)!=null)throw new Exception("wire fixture does not block the straight contact lead");checks++;
   p.contacts[sensor].DoorContact=true;p.contacts[unused].DoorContact=true;
   if(p.MakeRoute(from,to,out _,out _,kind)==null)throw new Exception("side escape failed to avoid installed wire");checks++;
   p.wires.Clear();p.railObstacles.Add(new WireRect(-.4f,.4f,-.09f,.03f));
   if(p.MakeRoute(from,to,out _,out _,kind)!=null)throw new Exception("fully blocked sensor socket was accepted");checks++;
  }
  Console.WriteLine("Door Contact side escape: "+checks+" production planner checks passed (sizes/sides/directions/wire kinds, real blockage rejected).");
 }
}
