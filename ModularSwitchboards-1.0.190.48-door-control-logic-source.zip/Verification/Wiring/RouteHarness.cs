using System;using System.Linq;using System.Collections.Generic;using ModularSwitchboards;
static class Debug{public static void Log(string s){}public static void LogWarning(string s){}}
struct Vector3{public float x,y,z;public Vector3(float x,float y,float z){this.x=x;this.y=y;this.z=z;}public static Vector3 operator +(Vector3 a,Vector3 b)=>new(a.x+b.x,a.y+b.y,a.z+b.z);}
partial class RouteHarness{
 internal readonly HashSet<long> PowerModules=new();
 private bool WireEndpointReady(CabinetWireEnd e)=>true;
 internal class Contact{internal CabinetWireEnd End;internal Vector3 Position,Exit;internal WireRect Bounds;internal bool Door;internal int Leaf;private float? side;internal float LeadSide{get=>side??(End?.IsNeutral==true?-1:0);set=>side=value;}}
 internal IEnumerable<DinTransformer> Transformers=Array.Empty<DinTransformer>();internal IEnumerable<SmartContactor> Contactors=Array.Empty<SmartContactor>();internal IEnumerable<long> SmartIds=Array.Empty<long>();internal IEnumerable<long> NetIds=>Breakers.Where(m=>m.IsSmartOutputModule).Select(m=>m.ReferenceId);
 internal IEnumerable<DinBreaker> Breakers=Array.Empty<DinBreaker>();internal SwitchboardCabinet Owner=new();internal float routingHalfWidth=WireRouting.HalfWidth,routingHalfHeight=WireRouting.HalfHeight;private static int Surface(Contact c)=>c.Door?c.Leaf+1:0;private int WireSurface(CabinetWireSaveData w)=>contacts.TryGetValue(w.From,out var c)?Surface(c):0;internal Dictionary<CabinetWireEnd,Contact> contacts=new();internal int Capacity(CabinetWireEnd e)=>PowerModules.Contains(e.Owner)&&(e.Contact==0||e.Contact==1)?3:e.IsNeutral&&Breakers.Any(m=>m.ReferenceId==e.Owner&&m.IsDoorBridge)?3:Breakers.Any(m=>m.ReferenceId==e.Owner&&m.IsDoorPart)?1:e.Capacity;bool IsDoorWire(CabinetWireSaveData w)=>contacts[w.From].Door;internal List<CabinetWireSaveData> wires=new();internal List<WireRect> railObstacles=new();WireRect[] moduleReservations=WireModuleSpace.Reservations().ToArray();const int CurrentRouteVersion=9;bool needsReroute;string migrationFailure;int changes;void Changed(){migrationFailure=null;changes++;}static float[] Flatten(IList<WirePoint> path)=>path.SelectMany(p=>new[]{p.X,p.Y,p.Z}).ToArray();static WirePoint Point(Vector3 p)=>new(p.x,p.y,p.z);
 static WirePoint[] Expand(float[] p)=>Enumerable.Range(0,p.Length/3).Select(i=>new WirePoint(p[i*3],p[i*3+1],p[i*3+2])).ToArray();
        private WireRoutePlanner CaptureRoutePlanner()
        {
            var planner=new WireRoutePlanner{prefabName=Owner.PrefabName,routingHalfWidth=routingHalfWidth,routingHalfHeight=routingHalfHeight,moduleReservations=(WireRect[])moduleReservations.Clone()};
            foreach(var c in contacts.Values)
            {
                var end=new CabinetWireEnd(c.End.Owner,c.End.Contact);
                planner.contacts[end]=new WireRoutePlanner.Contact{End=end,Position=Point(c.Position),Exit=Point(c.Exit),Bounds=c.Bounds,Door=c.Door,BridgePlate=!c.Door&&end.Contact==2&&Breakers.Any(m=>m.ReferenceId==end.Owner&&m.IsDoorBridge),DoorContact=!c.Door&&Breakers.Any(m=>m.ReferenceId==end.Owner&&m.IsDoorContact),Leaf=c.Leaf,LeadSide=c.LeadSide};
                planner.capacities[end]=Capacity(c.End)+(WireDataTap.Output(end)?1:0); // geometry slots only; power capacity remains unchanged
            }
            planner.railObstacles.AddRange(railObstacles);
            foreach(var w in wires)planner.wires.Add(new CabinetWireSaveData{From=new CabinetWireEnd(w.From.Owner,w.From.Contact),To=new CabinetWireEnd(w.To.Owner,w.To.Contact),Points=(float[])w.Points.Clone(),CableKind=w.CableKind,InputSlot=w.InputSlot});
            return planner;
        }
        internal WirePoint[] MakeRoute(CabinetWireEnd from,CabinetWireEnd to,out int slot,out string failure,CabinetWireKind kind=CabinetWireKind.Normal)
            =>CaptureRoutePlanner().MakeRoute(from,to,out slot,out failure,kind);
        private void RerouteLegacy()
        {
            needsReroute=false;
            // A failed atomic migration needs an actual wiring change before retrying.
            // Periodic contact refresh must not restart synchronous A* on unchanged saved paths.
            if(migrationFailure!=null)return;
            if(WireRouteUpgrade.TryPromote(wires,end=>contacts.TryGetValue(end,out var c)?(WirePoint?)Point(c.Position):null,CurrentRouteVersion)){Changed();return;}
            var backup=wires.ToArray();wires.Clear();
            foreach(var old in backup.OrderBy(w=>w.From.Owner==0?0:1))
            {
                var path=MakeRoute(old.From,old.To,out var slot,out var failure,old.CableKind);
                if(path==null)
                {
                    wires.Clear();wires.AddRange(backup);migrationFailure="Existing route needs manual rewiring: "+failure;
                    Debug.LogWarning("[Modular Switchboards] "+migrationFailure+" Connections and coil quantities preserved.");return;
                }
                wires.Add(new CabinetWireSaveData{From=old.From,To=old.To,InputSlot=slot,RouteVersion=CurrentRouteVersion,CableUnits=old.CableUnits,CableKind=old.CableKind,ColorIndex=old.ColorIndex,Burnt=old.Burnt,Points=Flatten(path)});
            }
            migrationFailure=null;Changed();
            Debug.Log("[Modular Switchboards] Existing wiring rerouted around reserved future module spaces without changing connections or coil quantities.");
        }
        internal bool CanConnectContacts(CabinetWireEnd a,CabinetWireEnd b,out string reason)
        {
            reason=null;
            if(!WireEndpointReady(a)||!WireEndpointReady(b)){reason="Complete the module before connecting cables.";return false;}
            if(!contacts.TryGetValue(a,out var ca)||!contacts.TryGetValue(b,out var cb)){reason="Contact unavailable.";return false;}
            if(Surface(ca)!=Surface(cb)){reason="Wire the plate and door separately through the Door Terminal Bridge.";return false;}
            if(!SmartContactorCircuit.Allowed(a,b,Contactors.Select(c=>c.ReferenceId),Breakers.Where(c=>c.IsContactor).Select(c=>c.ReferenceId)))
            {reason="Smart Output OUT connects only to a classic contactor A1.";return false;}
            foreach(var end in new[]{a,b})if(end.Contact==2&&Breakers.Any(c=>c.ReferenceId==end.Owner&&c.IsContactor))
            {
                var other=end.Equals(a)?b:a;
                if(!other.IsSource&&!Breakers.Any(m=>m.ReferenceId==other.Owner&&m.IsDoorBridge))
                {reason="Connect A1 to a supply contact or a door terminal bridge; the coil is not a power output.";return false;}
            }
            return WireCircuit.CanConnect(a,b,wires,Breakers.Select(m=>m.ReferenceId).Concat(Transformers.Select(t=>t.ReferenceId)).Concat(SmartIds).Concat(Contactors.Select(c=>c.ReferenceId)),out reason,capacity:Capacity,passages:Breakers.Where(m=>m.IsDoorBridge).Select(m=>m.ReferenceId),normallyClosed:Breakers.Where(m=>m.HasNormallyClosedContact).Select(m=>m.ReferenceId),dataTaps:NetIds);
        }

 void VerifyFutureSpace(WirePoint[] path,CabinetWireEnd from,CabinetWireEnd to){
  foreach(var reserved in WireModuleSpace.ForLead(moduleReservations,from.Owner==0?(WireRect?)null:contacts[from].Bounds,to.Owner==0?(WireRect?)null:contacts[to].Bounds))
   for(int i=1;i<path.Length;i++)if(WireRouting.SegmentHitsRect(path[i-1],path[i],reserved,WireRouting.Radius+.001f))throw new Exception("Future module or contact entry blocked");
  TubeHarness.AssertSections(path);
 }
 internal static void Run(){var h=new RouteHarness();var input=new CabinetWireEnd(0,0);h.railObstacles.Add(new(-.162f,.162f,.0905f,.1255f));h.railObstacles.Add(new(-.162f,.162f,-.1255f,-.0905f));h.contacts[input]=new(){End=input,Position=new(0,.196f,.033f),Exit=new(0,.178f,WireRouting.Plane),Bounds=new(-.036f,.036f,.195f,.227f)};
 for(int i=1;i<=2;i++){float x=i==1?.108f:-.108f;var e=new CabinetWireEnd(0,i);h.contacts[e]=new(){End=e,Position=new(x,-.196f,.033f),Exit=new(x,-.184f,WireRouting.Plane),Bounds=new(x-.036f,x+.036f,-.227f,-.195f)};}
 for(int i=0;i<3;i++){float x=-.14175f+i*.0405f;var bounds=new WireRect(x-.0198f,x+.0198f,.108f-.050625f,.108f+.050625f);for(int pin=0;pin<2;pin++){var e=new CabinetWireEnd(10+i,pin);h.contacts[e]=new(){End=e,Position=new(x,.108f+(pin==0?.050625f:-.050625f),.06535f),Exit=new(x,pin==0?.174f:.042f,WireRouting.Plane),Bounds=bounds};}}
 for(int i=0;i<3;i++){var target=new CabinetWireEnd(10+i,0);var p=h.MakeRoute(input,target,out int slot,out var fail);if(p==null)throw new Exception("Full contact route "+i+": "+fail);if(i>0&&slot%2!=0)throw new Exception("Input fan initially leaves to the wrong side");h.VerifyFutureSpace(p,input,target);foreach(var rail in h.railObstacles)for(int j=1;j<p.Length;j++)if(WireRouting.SegmentHitsRect(p[j-1],p[j],rail,WireRouting.Radius+.001f))throw new Exception("IN route crosses DIN rail");var values=p.SelectMany(q=>new[]{q.X,q.Y,q.Z}).ToArray();h.wires.Add(new(){From=input,To=target,InputSlot=slot,Points=values});Console.WriteLine("Production full route "+i+" passed, fan slot "+slot+", vertices "+p.Length);}
 for(int i=0;i<2;i++){var source=new CabinetWireEnd(10+i,1);var target=new CabinetWireEnd(0,i+1);var p=h.MakeRoute(source,target,out int slot,out var fail);if(p==null)throw new Exception("Output route "+i+": "+fail);h.VerifyFutureSpace(p,source,target);foreach(var rail in h.railObstacles)for(int j=1;j<p.Length;j++)if(WireRouting.SegmentHitsRect(p[j-1],p[j],rail,WireRouting.Radius+.001f))throw new Exception("Output route crosses DIN rail");if(p.Any(q=>q.Y>h.contacts[source].Position.y+.003f))throw new Exception("Unnecessary output detour above breaker");if(!p.Any(q=>Math.Abs(q.X)>.164f))throw new Exception("Output did not use side corridor");h.wires.Add(new(){From=source,To=target,InputSlot=slot,Points=p.SelectMany(q=>new[]{q.X,q.Y,q.Z}).ToArray()});Console.WriteLine("Production output route "+i+" passed, max depth "+p.Max(q=>q.Z));}
 var noRails=new RouteHarness();foreach(var c in h.contacts)noRails.contacts[c.Key]=c.Value;
 foreach(var pair in new[]{(input,new CabinetWireEnd(10,0)),(new CabinetWireEnd(10,1),new CabinetWireEnd(0,1))}){
  var p=noRails.MakeRoute(pair.Item1,pair.Item2,out int slot,out var fail);if(p==null)throw new Exception("Missing-rail route: "+fail);noRails.VerifyFutureSpace(p,pair.Item1,pair.Item2);noRails.wires.Add(new(){From=pair.Item1,To=pair.Item2,InputSlot=slot,Points=Flatten(p)});
 }
 var chain=new RouteHarness();foreach(var c in h.contacts)chain.contacts[c.Key]=c.Value;chain.railObstacles.AddRange(h.railObstacles);
 float lx=-.14175f,ly=-.108f;var lower=WireModuleSpace.At(lx,ly);
 for(int pin=0;pin<2;pin++){var e=new CabinetWireEnd(20,pin);chain.contacts[e]=new(){End=e,Position=new(lx,ly+(pin==0?.050625f:-.050625f),.06535f),Exit=new(lx,pin==0?-.042f:-.174f,WireRouting.Plane),Bounds=lower};}
 foreach(var pair in new[]{(input,new CabinetWireEnd(10,0)),(new CabinetWireEnd(10,1),new CabinetWireEnd(20,0)),(new CabinetWireEnd(20,1),new CabinetWireEnd(0,1))}){
  var p=chain.MakeRoute(pair.Item1,pair.Item2,out int slot,out var fail);if(p==null)throw new Exception("Two-row chain route: "+fail);chain.VerifyFutureSpace(p,pair.Item1,pair.Item2);chain.wires.Add(new(){From=pair.Item1,To=pair.Item2,InputSlot=slot,Points=Flatten(p)});
 }
 Console.WriteLine("Production two-row chain passed: IN -> upper breaker -> lower breaker -> Output 1.");
 if(h.moduleReservations.Length!=14)throw new Exception("Future module count mismatch");Console.WriteLine("All 14 module/lead spaces reserved, including absent lower rail; full-route tube sections retain diameter.");
 foreach(var w in h.wires)w.ColorIndex=7;var before=h.wires.Select(w=>(w.From,w.To,w.CableUnits,w.ColorIndex)).ToArray();h.needsReroute=true;h.RerouteLegacy();if(h.needsReroute||h.changes!=1||h.migrationFailure!=null||h.wires.Any(w=>w.RouteVersion!=CurrentRouteVersion)||!h.wires.Select(w=>(w.From,w.To,w.CableUnits,w.ColorIndex)).SequenceEqual(before))throw new Exception("Legacy rerouting altered connections or coil cost");
 var backup=h.wires.ToArray();h.railObstacles.Add(new(-.2f,.2f,-.18f,.19f));h.needsReroute=true;h.RerouteLegacy();if(h.migrationFailure==null||h.changes!=1||!h.wires.SequenceEqual(backup))throw new Exception("Failed migration did not preserve original wiring");h.railObstacles.RemoveAt(h.railObstacles.Count-1);
 // The obstruction is now gone: any retry would succeed and mutate the old paths.
 // Periodic endpoint checks must leave the failed snapshot untouched until wiring changes.
 var failedMessage=h.migrationFailure;
 for(int tick=0;tick<100;tick++){h.needsReroute=true;h.RerouteLegacy();if(h.needsReroute||h.migrationFailure!=failedMessage||h.changes!=1||!h.wires.SequenceEqual(backup))throw new Exception("Failed migration retried on idle contact refresh");}
 h.Changed();h.needsReroute=true;h.RerouteLegacy();if(h.migrationFailure!=null||h.changes!=3)throw new Exception("Real wiring change did not permit migration retry");
 Console.WriteLine("Production migration retry checks passed: 100 idle refreshes preserve failed paths, a wiring change permits one successful retry.");
 h.wires.Clear();h.wires.Add(new(){From=input,To=new(10,0),Points=new[]{0f,0f,0f,0f,.1f,0f}});h.wires.Add(new(){From=new(10,1),To=new(0,1),Points=new[]{0f,0f,0f,0f,.1f,0f}});h.wires.Add(new(){From=input,To=new(0,2),Points=new[]{0f,0f,0f,0f,.1f,0f}});h.needsReroute=true;h.RerouteLegacy();if(h.migrationFailure!=null||h.wires.Count!=3||h.wires.Any(w=>w.RouteVersion!=CurrentRouteVersion))throw new Exception("Screenshot layout migration failed");Console.WriteLine("Production legacy migration passed: screenshot branches, endpoint/cost preservation and atomic rollback when blocked.");
 }
}
