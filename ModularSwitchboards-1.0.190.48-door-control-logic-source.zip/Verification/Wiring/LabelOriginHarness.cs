using System;using ModularSwitchboards;
static class LabelOriginHarness
{
 internal static void Run()
 {
  int n=0;
  foreach(string name in new[]{"small","medium"})foreach(float depth in new[]{.08f,.13f,.17f})
  {
   var p=LabelBoardOrigin.Position(name,depth);int slots=DinLayout.FullModuleCount(CabinetShape.RailWidth(name));
   if(Math.Abs(p.Y-.0525f)>.000001f||Math.Abs(p.Z-depth-.003f)>.000001f)throw new Exception("label mounting plane changed");n++;
   for(int slot=0;slot<slots;slot++)
   {
    float fromLabelGrid=p.X+(slot*90)*.00045f;
    float fromModuleGrid=-CabinetShape.HalfSpan(name)+slot*DinLayout.SlotPitch;
    if(Math.Abs(fromLabelGrid-fromModuleGrid)>.000001f)throw new Exception("label slot no longer aligns with module slot");n++;
   }
   if(Math.Abs(p.X+(slots-1)*DinLayout.SlotPitch*.5f)>.000001f)throw new Exception("label board is not centered");n++;
  }
  var small=LabelBoardOrigin.Position("small",.13f);var medium=LabelBoardOrigin.Position("medium",.13f);
  if(Math.Abs(small.X-medium.X)<.1f)throw new Exception("fixture does not reproduce the Small/Medium origin mismatch");n++;
  Console.WriteLine(n+" production label-origin alignment checks passed (both sizes/all slots/cover depths).");
 }
}
