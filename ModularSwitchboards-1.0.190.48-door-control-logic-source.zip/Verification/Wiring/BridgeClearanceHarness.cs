using System;using System.Linq;using ModularSwitchboards;
static class BridgeClearanceHarness {
 internal static void Run(){int checks=0;
 foreach(float side in new[]{1f,-1f}) foreach(bool reverse in new[]{false,true}) foreach(CabinetWireKind kind in Enum.GetValues<CabinetWireKind>()){
 var p=new WireRoutePlanner{prefabName="medium",routingHalfWidth=.366f,routingHalfHeight=.477f,moduleReservations=Array.Empty<WireRect>()};
 var bridge=new CabinetWireEnd(900,2);var output=new CabinetWireEnd(100,1);
 p.contacts[bridge]=new(){End=bridge,Position=new(-side*.348f,0,.0244f),Exit=new(-side*.333f,0,WireRouting.Plane),LeadSide=side,BridgePlate=true,Bounds=new(-side*.357f-.009f,-side*.357f+.008f,-.011f,.011f)};
 p.contacts[output]=new(){End=output,Position=new(0,.10f,.029f),Exit=new(0,.13f,WireRouting.Plane),Bounds=new(-.02f,.02f,.05f,.1f)};
 var obstacle=new WireRect(side>0?-.334f:.25f,side>0?-.25f:.334f,-.02f,.02f);
 var blocked=new CabinetWireEnd(200,0);p.contacts[blocked]=new(){End=blocked,Position=new(side>0?-.29f:.29f,-.02f,.03f),Exit=new(side>0?-.29f:.29f,-.055f,WireRouting.Plane),Bounds=obstacle};
 p.capacities[bridge]=1;p.capacities[output]=1;p.capacities[blocked]=1;
 var path=p.MakeRoute(reverse?output:bridge,reverse?bridge:output,out _,out string failure,kind);
 if(path==null)throw new Exception("Bridge escape failed "+side+" "+reverse+" "+kind+": "+failure);
 foreach(var pair in path.Zip(path.Skip(1)))if(WireRouting.SegmentHitsRect(pair.First,pair.Second,obstacle,.005f))throw new Exception("Wire crosses real device");
 checks++;
 // The fallback must not turn off collisions at the physical terminal.
 p.contacts[blocked].Bounds=new(-.365f,.365f,-.08f,.08f);
 if(p.MakeRoute(reverse?output:bridge,reverse?bridge:output,out _,out _,kind)!=null)throw new Exception("Blocked socket was accepted");checks++;
 }
 Console.WriteLine("Bridge clearance: "+checks+" checks passed (both sides, both directions, all cable sizes; real blockage rejected).");
 }
}
