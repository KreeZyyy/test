// Exercises the production read-only view. Stubs do not simulate Unity or IC10 execution.
using System;using System.Collections.Generic;using System.Linq;using ModularSwitchboards;
public interface IReferencable{string DisplayName{get;}ushort NetworkUpdateFlags{get;set;}long ReferenceId{get;set;}bool BeingDestroyed{get;set;}void PrintDebugInfo(bool verbose=false);void OnAssignedReference();}
namespace Assets.Scripts.GridSystem {public enum LogicType{Activate,On,PrefabHash,ReferenceId,NameHash,Setting,Power}public enum LogicSlotType{Quantity}}
namespace Assets.Scripts.Objects {public class Thing {}}
namespace Assets.Scripts.Objects.Motherboards {public class Slot {}}
namespace Assets.Scripts.Objects.Pipes {
 using Assets.Scripts.GridSystem;using Assets.Scripts.Objects.Motherboards;
 public interface ILogicable:IReferencable {int TotalSlots{get;}Thing GetAsThing{get;}bool HasAnySlots{get;}Slot GetSlot(int i);int GetPrefabHash();int GetNextSlotId(int i,bool f);string ToTooltip();bool IsLogicSlotReadable();bool IsLogicReadable();bool IsLogicWritable();bool CanLogicRead(LogicType t);bool CanLogicWrite(LogicType t);void SetLogicValue(LogicType t,double v);double GetLogicValue(LogicType t);bool CanLogicRead(LogicSlotType t,int i);double GetLogicValue(LogicSlotType t,int i);int GetNameHash();}
}
namespace ModularSwitchboards {
 class Board {public object PrimaryHost;}
 class Wiring {public List<DinBreaker> Breakers=new();}
 class SwitchboardCabinet {public bool IsStructureCompleted=true;public Wiring Wiring=new();}
 class SmartModule {public bool IsCursor,IsBeingDestroyed,IsStructureCompleted=true;public SwitchboardCabinet Cabinet;}
 class DinBreaker:Assets.Scripts.Objects.Thing,IReferencable {
  public bool IsDoorButton,IsDoorIsolator,IsDoorStop,IsCursor,IsBeingDestroyed,IsStructureCompleted=true,OnOff;public int PrefabHash=17,NameHash=31;public Board Board;
  public string DisplayName=>"control";public ushort NetworkUpdateFlags{get;set;}public long ReferenceId{get;set;}public bool BeingDestroyed{get=>IsBeingDestroyed;set=>IsBeingDestroyed=value;}public void PrintDebugInfo(bool v=false){}public void OnAssignedReference(){}public int GetNameHash()=>NameHash;
 }
}
class Check {
 static int n;static void A(bool b,string why){n++;if(!b)throw new Exception(why);}
 static void Main(){
  var cabinet=new SwitchboardCabinet();var foreign=new SwitchboardCabinet();var core=new SmartModule{Cabinet=cabinet};
  foreach(int kind in new[]{0,1,2}){
   var control=new DinBreaker{ReferenceId=100+kind,Board=new Board{PrimaryHost=cabinet},IsDoorButton=kind==0,IsDoorIsolator=kind==1,IsDoorStop=kind==2};cabinet.Wiring.Breakers.Add(control);
   var view=DoorControlLogic.Local(core).Single(x=>x.ReferenceId==control.ReferenceId);
   A(view.CanLogicRead(Assets.Scripts.GridSystem.LogicType.Activate),"requested control not readable");
   foreach(bool state in new[]{false,true,false}){control.OnOff=state;A(view.GetLogicValue(Assets.Scripts.GridSystem.LogicType.Activate)==(state?1:0),"Activate not live native state");}
   A(!view.CanLogicWrite(Assets.Scripts.GridSystem.LogicType.Activate)&&!view.IsLogicWritable(),"control became writable");
   bool blocked=false;try{view.SetLogicValue(Assets.Scripts.GridSystem.LogicType.Activate,1);}catch(InvalidOperationException){blocked=true;}A(blocked&&!control.OnOff,"logic write changed physical state");
   A(view.GetLogicValue(Assets.Scripts.GridSystem.LogicType.PrefabHash)==17&&view.GetLogicValue(Assets.Scripts.GridSystem.LogicType.ReferenceId)==control.ReferenceId,"native identity lost");
   control.NameHash=99;A(view.GetNameHash()==99&&view.GetLogicValue(Assets.Scripts.GridSystem.LogicType.NameHash)==99,"rename hash was cached");
   A(ReferenceEquals(view,DoorControlLogic.Local(core).Single(x=>x.ReferenceId==control.ReferenceId)),"read view is not stable");
   A(ReferenceEquals(view.GetAsThing,control),"view fabricated another Thing");
   control.IsCursor=true;A(!DoorControlLogic.Local(core).Any(x=>x.ReferenceId==control.ReferenceId),"cursor visible");control.IsCursor=false;
   control.IsBeingDestroyed=true;A(!DoorControlLogic.Local(core).Any(x=>x.ReferenceId==control.ReferenceId),"destroyed control visible");control.IsBeingDestroyed=false;
   control.IsStructureCompleted=false;A(!DoorControlLogic.Local(core).Any(x=>x.ReferenceId==control.ReferenceId),"unfinished control visible");control.IsStructureCompleted=true;
  }
  cabinet.Wiring.Breakers.Add(new DinBreaker{ReferenceId=999,IsDoorButton=true,Board=new Board{PrimaryHost=foreign}});
  cabinet.Wiring.Breakers.Add(new DinBreaker{ReferenceId=998,Board=new Board{PrimaryHost=cabinet}});
  A(DoorControlLogic.Local(core).Count()==3,"foreign cabinet or non-control exposed");
  core.IsCursor=true;A(!DoorControlLogic.Local(core).Any(),"cursor core exposed controls");core.IsCursor=false;
  core.IsBeingDestroyed=true;A(!DoorControlLogic.Local(core).Any(),"destroyed core exposed controls");core.IsBeingDestroyed=false;
  core.IsStructureCompleted=false;A(!DoorControlLogic.Local(core).Any(),"unfinished core exposed controls");core.IsStructureCompleted=true;
  cabinet.IsStructureCompleted=false;A(!DoorControlLogic.Local(core).Any(),"unfinished cabinet exposed controls");
  Console.WriteLine(n+" production door-control read-view checks passed (native-state semantics, read-only access, cabinet scope, rename, lifetime).");
 }
}
