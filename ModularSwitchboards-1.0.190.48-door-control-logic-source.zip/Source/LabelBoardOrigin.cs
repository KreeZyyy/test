namespace ModularSwitchboards
{
    // One origin for placement, cover transfer, saves and multiplayer joins.
    internal static class LabelBoardOrigin
    {
        internal static WirePoint Position(string prefab,float depth)
            =>new WirePoint(-CabinetShape.HalfSpan(prefab),.0525f,depth+.003f);
    }
}
