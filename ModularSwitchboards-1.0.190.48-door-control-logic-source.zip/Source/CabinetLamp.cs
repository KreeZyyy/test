using System.Linq;
using System.Xml.Serialization;
using Assets.Scripts;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Networking;
using Assets.Scripts.Objects;
using LibConstruct;
using UnityEngine;
namespace ModularSwitchboards
{
    public sealed class CabinetLampSaveData:StructureSaveData{[XmlElement]public PlacementBoardStructureSaveData Mount;}
    public sealed class CabinetLamp:Structure,IPlacementBoardStructure
    {
        public const string PrefabId="StructureSwitchboardCabinetLamp",KitId="ItemKitSwitchboardCabinetLamp";
        internal const float Watts=50f;
        private PlacementBoard board;
        public PlacementBoard Board{get=>board;set{board=value;CabinetLampModel.Resize(this);}}
        internal float LayoutWidth,GhostWidth;internal bool LayoutLegacyTerminal;
        internal Mesh LeadMesh,GhostMesh,BodyMesh,LensMesh;
        public PlacementBoard.BoardCell[] BoardCells{get;set;}
        internal SwitchboardCabinet Cabinet=>Board?.PrimaryHost as SwitchboardCabinet;
        internal bool Lit;
        private const ushort LightUpdate=32768;
        private float nextPowerCheck;
        internal static Grid3 MountGrid(string name)=>new Grid3(0,CabinetShape.Medium(name)?250:110,0);
        internal static bool BlocksBridgeSlot(SwitchboardCabinet host,PlacementBoard bridge,int y,int count)
            =>host!=null&&bridge==host.BridgeBoard&&CabinetLampWiringGeometry.ReservesSlot(CabinetShape.Medium(host.PrefabName),y,count)&&host.RailBoard!=null&&host.RailBoard.Structures.OfType<CabinetLamp>().Any(l=>!l.IsBeingDestroyed&&!l.IsCursor);
        internal static bool BridgeSlotFree(SwitchboardCabinet host)
        {
            return host.BridgeBoard!=null&&!host.BridgeBoard.Structures.OfType<DinBreaker>().Any(m=>m.IsBridgeMounted&&!m.IsBeingDestroyed&&!m.IsCursor&&CabinetLampWiringGeometry.ReservesSlot(CabinetShape.Medium(host.PrefabName),host.BridgeBoard.WorldToGrid(m.transform.position).y,m.IsDoorContact?2:1));
        }
        internal static bool CanPlace(PlacementBoard board,Grid3 grid,int rotation)
        {
            if(!(board is CabinetRailBoard)||!(board.PrimaryHost is SwitchboardCabinet host)||!host.CanFitRails||rotation!=0)return false;
            var target=MountGrid(host.PrefabName);
            return BridgeSlotFree(host)&&grid.x==target.x&&grid.y==target.y&&grid.z==0&&!board.Structures.OfType<CabinetLamp>().Any(l=>!l.IsBeingDestroyed&&!l.IsCursor);
        }
        public override void Awake(){base.Awake();BoardStructureHooks.Awake(this);CabinetLampModel.Resize(this);}
        public override void UpdateStateVisualizer(bool visualOnly=false){base.UpdateStateVisualizer(visualOnly);GetComponent<CabinetLampView>()?.Invalidate();}
        public override Grid3 GetLocalGrid()=>Board==null?default(Grid3):Board.WorldToGrid(transform.position);
        public override CanConstructInfo CanConstruct()
        {
            if(IsCursor)MountBoardResolver.Resolve(CursorManager.Instance);
            if(!(Board is CabinetRailBoard)||Cabinet==null||(IsCursor&&PlacementBoard.CursorBoard!=Board))return CanConstructInfo.InvalidPlacement("Open a completed switchboard and aim inside it.");
            if(!BridgeSlotFree(Cabinet))return CanConstructInfo.InvalidPlacement("Free the top LEFT Door Bridge position for the cabinet light terminal first.");
            var p=Board.WorldToGrid(transform.position);
            if(IsCursor){p=MountGrid(Cabinet.PrefabName);PlacementBoard.CursorGrid=p;PlacementBoard.CursorRotation=0;transform.SetPositionAndRotation(Board.GridToWorld(p),Board.IndexToRotation(0));}
            return CanPlace(Board,p,Board.RotationToIndex(transform.rotation))?CanConstructInfo.ValidPlacement:CanConstructInfo.InvalidPlacement("One cabinet light fits beneath the upper rim. Remove the inner cover first.");
        }
        protected override CanConstructInfo CanDeconstruct()=>Cabinet!=null&&Cabinet.CanFitRails&&!Cabinet.Wiring.HasWires(ReferenceId)?CanConstructInfo.ValidPlacement:CanConstructInfo.InvalidPlacement("Open the cabinet, remove the cover and disconnect the light first.");
        public override DelayedActionInstance AttackWith(Attack attack,bool doAction=true)
        {
            if(Cabinet!=null&&Cabinet.Wiring.TryAttack(attack,doAction,out var wireAction))return wireAction;
            return Cabinet!=null&&Cabinet.CanFitRails?base.AttackWith(attack,doAction):null;
        }
        private void Update()
        {
            CabinetLampModel.Resize(this);
            if(!GameManager.RunSimulation||Time.unscaledTime<nextPowerCheck)return;
            nextPowerCheck=Time.unscaledTime+.1f;
            bool next=!IsCursor&&!IsBeingDestroyed&&IsStructureCompleted&&Cabinet!=null&&Cabinet.Wiring.Power.ServicePowered(ReferenceId);
            if(Lit!=next){Lit=next;NetworkUpdateFlags|=LightUpdate;}
        }
        public override void BuildUpdate(RocketBinaryWriter writer,ushort flags){base.BuildUpdate(writer,flags);if(Thing.IsNetworkUpdateRequired(LightUpdate,flags))writer.WriteBoolean(Lit);}
        public override void ProcessUpdate(RocketBinaryReader reader,ushort flags){base.ProcessUpdate(reader,flags);if(Thing.IsNetworkUpdateRequired(LightUpdate,flags))Lit=reader.ReadBoolean();}
        public override void OnDestroy(){if(BodyMesh!=null)Destroy(BodyMesh);if(LensMesh!=null)Destroy(LensMesh);if(LeadMesh!=null)Destroy(LeadMesh);if(GhostMesh!=null)Destroy(GhostMesh);base.OnDestroy();}
        public override void OnDeregistered(){Cabinet?.Wiring.RemoveBreaker(ReferenceId);base.OnDeregistered();if(Board!=null)BoardStructureHooks.OnDeregistered(this);}
        public override ThingSaveData SerializeSave(){ThingSaveData data=new CabinetLampSaveData();InitialiseSaveData(ref data);return data;}
        protected override void InitialiseSaveData(ref ThingSaveData data){base.InitialiseSaveData(ref data);if(data is CabinetLampSaveData save&&Board!=null)save.Mount=BoardStructureHooks.SerializeSave(this);}
        public override void DeserializeSave(ThingSaveData data){base.DeserializeSave(data);Lit=false;if(data is CabinetLampSaveData save&&save.Mount!=null)BoardStructureHooks.DeserializeSave(this,save.Mount);}
        public override void SerializeOnJoin(RocketBinaryWriter writer){base.SerializeOnJoin(writer);BoardStructureHooks.SerializeOnJoin(writer,this);writer.WriteBoolean(Lit);}
        public override void DeserializeOnJoin(RocketBinaryReader reader){base.DeserializeOnJoin(reader);BoardStructureHooks.DeserializeOnJoin(reader,this);Lit=reader.ReadBoolean();}
    }
}
