namespace ModularSwitchboards
{
    internal static class CabinetLampWiringGeometry
    {
        // The front lamp and fixed lead are not solid blockers in the plate routing
        // plane. Reserve only the real Door Bridge terminal footprint, not the
        // huge bounding box spanning plate terminal and front-mounted housing.
        internal static float PlateX(bool medium,bool legacy=false)=>legacy?.300f:medium?-.357f:-.177f;
        internal static float LeadSide(bool medium,bool legacy=false)=>legacy?0f:1f;
        internal static WirePoint FixedLeadControl(WirePoint start,bool medium,bool legacy=false)=>start+(legacy?new WirePoint(.018f,0,.005f):new WirePoint(-.003f,0,.050f));
        internal const int SmallBridgeSlot=80,MediumBridgeSlot=180;
        internal static int BridgeSlot(bool medium)=>medium?MediumBridgeSlot:SmallBridgeSlot;
        internal static float ProfileX(float x,bool medium,bool legacy=false)=>legacy?x:-x;
        internal static void MatchWinding(int[] ids,bool medium,bool legacy=false)
        {
            if(legacy)return;
            for(int i=0;i<ids.Length;i+=3){int swap=ids[i+1];ids[i+1]=ids[i+2];ids[i+2]=swap;}
        }
        internal static float EntryX(bool medium,bool legacy=false)=>legacy?-.009f:.009f;
        internal static float AimX(bool medium,bool legacy=false)=>legacy?-.0042f:.0042f;
        internal static float TerminalRotation(bool medium,bool legacy=false)=>legacy?180f:0f;
        internal static bool ReservesSlot(bool medium,int y,int count)=>DoorContactLayout.Overlaps(y,count,BridgeSlot(medium),1);
        internal static WireRect PlateBounds(WirePoint center)=>new WireRect(center.X-.011f,center.X+.011f,center.Y-.012f,center.Y+.012f);
        internal static WirePoint Exit(WirePoint entry,bool medium=true,bool legacy=false)=>new WirePoint(entry.X+(legacy?-.020f:.020f),entry.Y,WireRouting.Plane);
    }
}
