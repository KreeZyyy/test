namespace ModularSwitchboards
{
    internal static class DoorContactLayout
    {
        // Bridge board Z=.013, closed door rear Z=.185; compressed tip=.104+.008-.008.
        internal const float FrontOffset=.068f;
        internal static bool Closed(bool ready,bool doorsOpen)=>ready&&doorsOpen;
        internal static bool Fits(int y,int min,int max,int slots)=>y>=min&&y+(slots-1)*10<=max&&y%10==0;
        internal static bool Overlaps(int a,int countA,int b,int countB)=>a<=b+(countB-1)*10&&b<=a+(countA-1)*10;
    }
}
