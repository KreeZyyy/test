using UnityEngine;
namespace ModularSwitchboards
{
    internal static class DoorContactModel
    {
        internal static MeshRenderer Install(DinBreaker owner,Material black,Material grey)
        {
            for(int pin=0;pin<2;pin++)
            {
                var terminal=new GameObject("DoorContactTerminal"+pin){layer=owner.gameObject.layer};terminal.transform.SetParent(owner.transform,false);terminal.transform.localPosition=new Vector3(0,pin*.024f,0);DoorModules.TerminalCube(terminal.transform,1);
                var a=new WirePoint(-.009f,pin*.024f,.0114f);var end=new WirePoint(-.014f,.004f+pin*.016f,.064f+DoorContactLayout.FrontOffset);
                var path=DoorModuleLayout.DoorFlexGeometry.Build(a,a+new WirePoint(-.012f,0,.014f),end+new WirePoint(.006f,0,-.015f),end);
                var wire=DoorModules.Part(owner.transform,"DoorContactFixedLead"+pin,WireMesh.Build(path),CabinetGeometry.Materials[3]);WireVisualLighting.Apply(wire);
            }
            var assembly=new GameObject("DoorContactRimAssembly"){layer=owner.gameObject.layer};assembly.transform.SetParent(owner.transform,false);assembly.transform.localPosition=new Vector3(0,0,DoorContactLayout.FrontOffset);
            var root=assembly.transform;
            var body=DoorModules.Part(root,"DoorContactHousing",DoorModules.Box(new Vector3(-.014f,.012f,.080f),new Vector3(.018f,.044f,.028f)),black);
            DoorModules.Part(root,"DoorContactMount",DoorModules.Box(new Vector3(-.021f,.012f,.078f),new Vector3(.004f,.046f,.038f)),grey);
            for(int side=-1;side<=1;side+=2)
            {
                var screw=DoorModules.Part(root,"DoorContactMountScrew",DoorModuleGeometry.Cylinder(.0028f,.094f,.096f),grey);screw.transform.localPosition=new Vector3(-.014f,.012f+side*.017f,0);
                DoorModules.Part(root,"DoorContactScrewSlot",DoorModules.Box(new Vector3(-.014f,.012f+side*.017f,.0961f),new Vector3(.0038f,.0007f,.0004f)),black);
            }
            DoorModules.Part(root,"DoorContactIdentificationPlate",DoorModules.Box(new Vector3(-.0045f,.012f,.080f),new Vector3(.001f,.027f,.017f)),grey);
            for(int line=0;line<5;line++)DoorModules.Part(root,"DoorContactLabelLine",DoorModules.Box(new Vector3(-.0039f,.012f,.074f+line*.0027f),new Vector3(.0003f,line==0?.022f:.016f,.00065f)),black);
            for(int pin=0;pin<2;pin++)
            {
                var inlet=DoorModules.Part(root,"DoorContactCableInlet",DoorModuleGeometry.Cylinder(.0032f,.062f,.068f),black);inlet.transform.localPosition=new Vector3(-.014f,.004f+pin*.016f,0);
            }
            var collar=DoorModules.Part(root,"DoorContactPlungerCollar",DoorModuleGeometry.Cylinder(.0055f,.093f,.099f),black);collar.transform.localPosition=new Vector3(-.014f,.012f,0);
            var plunger=new GameObject("DoorContactPlunger"){layer=owner.gameObject.layer};plunger.transform.SetParent(root,false);
            var actuator=DoorModules.Part(plunger.transform,"DoorContactActuator",DoorModuleGeometry.Cylinder(.0033f,.098f,.112f),grey);actuator.transform.localPosition=new Vector3(-.014f,.012f,0);
            var view=owner.gameObject.AddComponent<DoorContactView>();view.Owner=owner;view.Plunger=plunger.transform;return body;
        }
    }
    public sealed class DoorContactView:MonoBehaviour
    {
        public DinBreaker Owner;public Transform Plunger;
        private bool initialized,last;
        private void LateUpdate()
        {
            if(Owner==null||Plunger==null)return;
            bool open=CabinetWiring.CabinetOf(Owner)?.IsOpen==true;
            if(initialized&&open==last)return;initialized=true;last=open;
            Plunger.localPosition=new Vector3(0,0,open?0:-.008f);
            DoorModules.PaintCubes(transform);
        }
    }
}
