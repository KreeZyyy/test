# Verification

Requires .NET SDK 8. Run each fixture with `dotnet run --project <path> -c Release`:

- `source/tests/Check.csproj`: 16 custom alert ID checks.
- `Verification/Catalog/Check.csproj`: 58 shared enum/catalog checks.
- `Verification/Manifest/Check.csproj`: 128 manifest/cache checks using temporary files.
- `Verification/Cleanup/Check.csproj`: actual ReleaseClips body, 8 cleanup checks against native API stubs.
- `Verification/Performance/Check.csproj`: actual Update/IsReady bodies against API stubs, 100,000 stable updates and 200,000 ownership lookups, no managed allocations in the measured loops.

Performance/ExtractedUpdate.cs is copied from Plugin.cs between `void Update()` and `IEnumerator Load(`. Cleanup/ExtractedCleanup.cs is copied between `static void ReleaseClips()` and `bool loading;`. Refresh these files after implementation changes. Fixtures model Unity null/destroyed behavior but are not a live Unity runtime or an FPS benchmark. RESULTS.txt records this build's results.

- `Verification/EmptyServer/Check.csproj`: executes actual Configure/Serialize/Deserialize and RefreshCatalogContext using networking/Unity stubs. Creates a missing server sounds folder, publishes an empty manifest, exercises MP waiting/empty/reconnect/SP role restoration and verifies private file bytes. The actual local audio reload remains a live game check. ExtractedContext.cs is copied from Plugin.cs between RefreshCatalogContext() and float nextCheck.

- `Verification/Storage/Check.csproj`: 12 production filesystem checks: empty sounds beside BepInEx, empty separate cache, no Workshop import or migration marker, manual files preserved on restart, independent empty server and logged paths. Run with .NET SDK 8.
