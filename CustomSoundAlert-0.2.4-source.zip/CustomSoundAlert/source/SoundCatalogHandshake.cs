using System;
using Assets.Scripts.Networking;
using LaunchPadBooster;
using LaunchPadBooster.Networking;
namespace CustomSoundAlert
{
 [HarmonyLib.HarmonyPatch(typeof(NetworkManager),"EndConnection")]
 internal static class SoundCatalogDisconnect {static void Prefix(){SoundCatalogHandshake.Clear();}}
 internal sealed class SoundCatalogHandshake:IJoinPrefixSerializer
 {
  internal static readonly object Gate=new object();
  internal static SoundEntry[] Local=Array.Empty<SoundEntry>(),Pending;
  internal static long Revision;
  static Action<string> diagnostics;
  internal static int ResetRequested;
  internal static void Configure(string soundDirectory,Action<string> log=null){diagnostics=log;Local=ServerSoundCatalog.Scan(soundDirectory);var mod=new Mod("CustomSoundAlert","0.2.4");mod.Networking.Required=false;mod.Networking.JoinPrefixSerializer=new SoundCatalogHandshake();diagnostics?.Invoke("Join catalog serializer registered: CustomSoundAlert 0.2.4; local entries="+Local.Length+". Sent with world join data, after connection/password validation.");}
  public void SerializeJoinPrefix(RocketBinaryWriter writer){var payload=ServerSoundCatalog.Encode(Local);writer.WriteString(payload);diagnostics?.Invoke("SERVER: wrote join catalog; entries="+Local.Length+"; payload characters="+payload.Length+".");}
  public void DeserializeJoinPrefix(RocketBinaryReader reader){var entries=ServerSoundCatalog.Decode(reader.ReadString());lock(Gate){Pending=entries;System.Threading.Interlocked.Increment(ref Revision);}diagnostics?.Invoke("CLIENT: received and validated server join catalog; entries="+entries.Length+".");}
  internal static void Clear(){lock(Gate){Pending=null;System.Threading.Interlocked.Increment(ref Revision);}System.Threading.Interlocked.Exchange(ref ResetRequested,1);}
 }
}
