using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using BepInEx.Logging;
using HarmonyLib;
using StationeersMods.Interface;
using UnityEngine;
using UnityEngine.Networking;
using Assets.Scripts;
using Assets.Scripts.Networking;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Electrical;
using Assets.Scripts.Objects.Clothing;
using Assets.Scripts.Objects.Items;
using Assets.Scripts.Objects.Motherboards;
using Assets.Scripts.Sound;
using Assets.Scripts.Serialization;
using Assets.Scripts.UI;

namespace CustomSoundAlert
{
    [StationeersMod("kreezy.customsoundalert", "Custom SoundAlert", "0.2.4")]
    public class Plugin : ModBehaviour
    {
        static readonly SortedDictionary<int, GameAudioClipsData> clips = new SortedDictionary<int, GameAudioClipsData>();
        static readonly FieldInfo lookup = AccessTools.Field(typeof(Thing), "_audioEventLookup");
        static ManualLogSource log;
        static readonly SortedDictionary<int, string> labels = new SortedDictionary<int, string>();
        static EnumCollection<SoundAlert,int> originalAlerts;
        static string[] originalNames;
        static int[] originalHashes;
        static string[] modeNames;
        static readonly HashSet<StationpediaPage> speakerPages = new HashSet<StationpediaPage>();
        AudioManager registeredManager, existingManager;
        static readonly CustomClipRegistry<GameAudioClipsData> clipRegistry = new CustomClipRegistry<GameAudioClipsData>();
        static readonly Dictionary<GameAudioClipsData,AudioManager> ownedClips = new Dictionary<GameAudioClipsData,AudioManager>();
        static readonly FieldInfo managerClips = AccessTools.Field(typeof(AudioManager), "_clipsDataHashLookup");
        static void ReleaseClips()
        {
            clipRegistry.Clear();
            foreach(var pair in ownedClips)
            {
                var data=pair.Key;var manager=pair.Value;
                if(manager!=null && managerClips.GetValue(manager) is Dictionary<int,GameAudioClipsData> index &&
                    index.TryGetValue(data.NameHash,out var current) && ReferenceEquals(current,data))index.Remove(data.NameHash);
                foreach(var clip in data.Clips)if(clip!=null)UnityEngine.Object.Destroy(clip);
            }
            ownedClips.Clear();clips.Clear();
        }
        bool loading;
        bool serverCatalogCommitted;
        static bool roleInitialized,selectedRemote;
        static int loadEpoch;
        static SoundEntry[] remoteCatalog=Array.Empty<SoundEntry>();
        long seenCatalog=-1;
        static bool Remote=>NetworkManager.IsClient&&!NetworkManager.IsServer;
        static bool CatalogMatchesRole=>System.Threading.Volatile.Read(ref SoundCatalogHandshake.ResetRequested)==0&&roleInitialized&&selectedRemote==Remote;
        static SoundStorage storage;
        static string SoundsDirectory=>storage.Sounds;
        static string CacheDirectory=>storage.Cache;
        void ClearCustomState()
        {
            loadEpoch++;StopAllCoroutines();loading=false;registeredManager=null;serverCatalogCommitted=false;
            if(!GameManager.IsBatchMode)foreach(var speaker in UnityEngine.Object.FindObjectsOfType<Speaker>())
            {
                var dict=lookup.GetValue(speaker) as Dictionary<int,GameAudioEvent>;
                foreach(var ev in speaker.AudioEvents.Where(e=>e?.ClipsData?.Name?.StartsWith("KreeZy.CustomSoundAlert.",StringComparison.Ordinal)==true).ToArray())
                {ev.Stop(true);speaker.InteractMode?.AssociatedAudioEvents?.Remove(ev);speaker.AudioEvents.Remove(ev);dict?.Remove(ev.NameHash);}
            }
            if(!GameManager.IsBatchMode)
            {
                foreach(var host in UnityEngine.Object.FindObjectsOfType<Thing>().Where(t=>t is SuitBase||t is AdvancedTablet))
                {
                    int alert=host is SuitBase suit?suit.SoundAlert:((AdvancedTablet)host).SoundAlert;
                    if(alert<100||alert>199)continue;
                    var field=AccessTools.Field(host is SuitBase?typeof(SuitBase):typeof(AdvancedTablet),"_playingAudio");
                    var playing=field?.GetValue(host) as Sound.PooledAudioSource;
                    if(playing!=null){playing.Stop(true);field.SetValue(host,null);}
                }
            }
            ReleaseClips();labels.Clear();BuildModes();nextCheck=0;
        }
        void RefreshCatalogContext()
        {
            if(System.Threading.Interlocked.Exchange(ref SoundCatalogHandshake.ResetRequested,0)!=0)roleInitialized=false;
            bool remote=Remote;
            if(!roleInitialized||remote!=selectedRemote)
            {
                bool leaving=roleInitialized&&selectedRemote&&!remote;
                ClearCustomState();selectedRemote=remote;roleInitialized=true;remoteCatalog=Array.Empty<SoundEntry>();seenCatalog=-1;

                Info(remote?"Multiplayer: local sounds hidden; waiting for server catalog.":"Singleplayer/local host: using local sounds folder.");
            }
            if(remote)
            {
                if(System.Threading.Interlocked.Read(ref SoundCatalogHandshake.Revision)==seenCatalog)return;
                SoundEntry[] pending;long revision;lock(SoundCatalogHandshake.Gate){pending=SoundCatalogHandshake.Pending;revision=SoundCatalogHandshake.Revision;}
                if(pending!=null&&seenCatalog!=revision)
                {
                    ClearCustomState();remoteCatalog=pending;seenCatalog=revision;
                    foreach(var e in pending)labels[e.Id]=e.Name;BuildModes();
                    int cached=pending.Count(e=>ServerSoundCatalog.Cached(CacheDirectory,e));
                    Info("Server catalog: "+pending.Length+" sounds; verified cache "+cached+". File transfer is not implemented in this catalog prototype.");
                }
            }
        }
        float nextCheck;
        static void Info(string message) => log?.LogInfo(message);
        static void Warn(string message) => log?.LogWarning(message);
        static void Error(string message) => log?.LogError(message);
        public override void OnLoaded(ContentHandler contentHandler)
        {
            base.OnLoaded(contentHandler);
            log = BepInEx.Logging.Logger.CreateLogSource("CustomSoundAlert");
            originalAlerts=EnumCollections.SpeakerSounds;
            originalNames = (string[])((string[])AccessTools.Field(typeof(Speaker), "modeStrings").GetValue(null)).Clone();
            originalHashes = (int[])((int[])AccessTools.Field(typeof(Speaker), "ModeHashes").GetValue(null)).Clone();
            try
            {
                storage=SoundStorage.Prepare(BepInEx.Paths.BepInExRootPath,Info);
                SoundCatalogHandshake.Configure(SoundsDirectory,Info);
                Info("Sounds folder ready: " + SoundsDirectory + "; " + SoundCatalogHandshake.Local.Length + " local catalog entries. Empty folder publishes only vanilla sounds.");
                new Harmony("kreezy.customsoundalert").PatchAll(typeof(Plugin).Assembly);
                Info("0.2.4 catalog prototype loaded; waiting for the game's existing initialized AudioManager. No singleton creation. IDs 100..199; sounds/<id>_<name>.<ext>");
            }
            catch (Exception ex) { enabled = false; Error("Initialization failed: " + ex); }
        }
        void Update()
        {
            RefreshCatalogContext();
            if(GameManager.IsBatchMode){if(!serverCatalogCommitted){labels.Clear();foreach(var e in SoundCatalogHandshake.Local)labels[e.Id]=e.Name;BuildModes();serverCatalogCommitted=true;}return;}
            if(selectedRemote&&seenCatalog<0)return;
            // The manager persists across scenes. Once registered, do no scene scans,
            // file reads or decoding until that Unity object is destroyed or the role resets.
            if (loading || IsReady(registeredManager) || Time.unscaledTime < nextCheck) return;
            nextCheck = Time.unscaledTime + 0.5f;
            // Singleton.Instance calls Create() in the game; never use it for a readiness check.
            if(existingManager==null)existingManager=UnityEngine.Object.FindObjectOfType<AudioManager>();
            var manager = existingManager;
            if (!IsReady(manager) || manager == registeredManager) return;
            Info("Existing AudioManager is ready; starting custom file loading.");
            if(clips.Count>0)ClearCustomState();
            loading = true;
            StartCoroutine(Load(manager));
        }
        static bool IsReady(AudioManager manager) => manager != null &&
            manager.AudioSourcePrefab != null && manager.LoadedChannelData != null &&
            manager.LoadedChannelData.Count > 0 && manager.MixerGroups != null && manager.MixerGroups.Count > 0;
        IEnumerator Load(AudioManager manager)
        {
            try { yield return LoadFiles(manager); }
            finally { loading = false; }
        }
        IEnumerator LoadFiles(AudioManager manager)
        {
            int epoch=loadEpoch;
            string dir = selectedRemote?CacheDirectory:SoundsDirectory;
            string[] files;
            try { Directory.CreateDirectory(dir); files = selectedRemote?remoteCatalog.Where(e=>ServerSoundCatalog.Cached(dir,e)).Select(e=>ServerSoundCatalog.CachePath(dir,e)).ToArray():Directory.GetFiles(dir).OrderBy(x => x, StringComparer.Ordinal).ToArray(); }
            catch (Exception ex) { Error("Cannot read sounds folder: " + ex); registeredManager = manager; yield break; }
            clips.Clear(); labels.Clear();if(selectedRemote)foreach(var e in remoteCatalog)labels[e.Id]=e.Name;
            Info("Scanning sounds folder: " + dir);
            var seen = new HashSet<int>();
            foreach (string file in files)
            {
                string ext = Path.GetExtension(file).ToLowerInvariant();
                if (ext != ".wav" && ext != ".ogg" && ext != ".mp3") continue;
                string name = Path.GetFileNameWithoutExtension(file);
                var remoteEntry=selectedRemote?remoteCatalog.First(e=>ServerSoundCatalog.CachePath(dir,e)==file):null;
                string number = remoteEntry==null?name.Split('_')[0]:remoteEntry.Id.ToString();
                if (!int.TryParse(number, out int id) || id < 100 || id > 199 || !seen.Add(id))
                { Warn("[CustomSoundAlert] Invalid or duplicate ID: " + Path.GetFileName(file)); continue; }
                using (var req = UnityWebRequestMultimedia.GetAudioClip(new Uri(file).AbsoluteUri,
                    ext == ".wav" ? AudioType.WAV : ext == ".ogg" ? AudioType.OGGVORBIS : AudioType.MPEG))
                {
                    yield return req.SendWebRequest();
                    if(epoch!=loadEpoch||!CatalogMatchesRole)yield break;
                    if (req.result != UnityWebRequest.Result.Success)
                    { Error("Failed loading ID " + id + " / " + Path.GetFileName(file) + ": " + req.error); continue; }
                    if (!IsReady(manager)) { Warn("AudioManager disappeared during file loading; registration postponed."); yield break; }
                    AudioClip clip = DownloadHandlerAudioClip.GetContent(req);
                    if (clip == null) { Error("Decoder returned no clip for " + Path.GetFileName(file)); continue; }
                    clip.name = "KreeZy.CustomSoundAlert." + id;
                    var data = new GameAudioClipsData { Name = clip.name, NameHash = Animator.StringToHash(clip.name), ChannelName = "Large", Looping = false, RandomStartTime = false, ConcurrencyIds = new List<int>() };
                    data.Clips.Add(clip);
                    var audio = new AudioData(); audio.AudioClipsData.Add(data);
                    try
                    {
                        manager.LoadAudioData(new[] { audio });
                        ownedClips.Add(data,manager);
                        clipRegistry.Register(data);
                        clips.Add(id, data);
                        string label = name.Substring(number.Length).TrimStart('_');
                        labels[id]=remoteEntry?.Name??(string.IsNullOrWhiteSpace(label) ? name : label);
                        Info("[CustomSoundAlert] Ready: ID " + id + " -> " + Path.GetFileName(file) + " (" + clip.length + " s)");
                    }
                    catch (Exception ex) { if(!ownedClips.ContainsKey(data))UnityEngine.Object.Destroy(clip); Error("Registration failed for ID " + id + " / " + Path.GetFileName(file) + ": " + ex); }
                }
            }
            BuildModes();
            registeredManager = manager;
            foreach (Speaker speaker in UnityEngine.Object.FindObjectsOfType<Speaker>()) Attach(speaker);
            Info("[CustomSoundAlert] Ready, " + clips.Count + " custom sounds. Restart after editing files.");
        }
        // Both wearable hosts use this native shared sound lookup; keep their
        // existing main-thread playback, volume, stop and replication code.
        [HarmonyPatch(typeof(AudioManager), "Find", new Type[] { typeof(SoundAlert) })]
        class CustomAlertLookupPatch
        {
            static bool Prefix(SoundAlert soundAlert, ref GameAudioClipsData __result)
            {
                if((int)soundAlert>=100&&(int)soundAlert<=199&&!CatalogMatchesRole){__result=null;return false;}
                if (!clips.TryGetValue((int)soundAlert, out var data)) return true;
                __result = data; return false;
            }
        }
        static bool SetCustomAlert(Thing host, LogicType logicType, double value)
        {
            if (logicType != LogicType.SoundAlert || !CustomAlertPolicy.TryId(value, out int id)) return true;
            if (!CatalogMatchesRole||!(GameManager.IsBatchMode?labels.ContainsKey(id):clips.ContainsKey(id))) { Warn("Custom SoundAlert " + id + " is not loaded; request ignored."); return false; }
            return true; // Native setter now accepts the expanded shared catalog range.
        }
        [HarmonyPatch(typeof(SuitBase), "SetLogicValue")]
        class SuitAlertPatch
        { static bool Prefix(SuitBase __instance, LogicType logicType, double value) => SetCustomAlert(__instance, logicType, value); }
        [HarmonyPatch(typeof(AdvancedTablet), "SetLogicValue")]
        class TabletAlertPatch
        { static bool Prefix(AdvancedTablet __instance, LogicType logicType, double value) => SetCustomAlert(__instance, logicType, value); }
        static void BuildModes()
        {
            // Build one table from all successful loads, rather than resizing readonly statics per file.
            var names = ModeCatalog.BuildNames(originalNames, labels);
            var hashes = (int[])originalHashes.Clone();
            if (labels.Count > 0)
            {
                int length = Math.Max(names.Length, labels.Keys.Max() + 1);
                Array.Resize(ref names, length); Array.Resize(ref hashes, length);
                foreach (var entry in labels) { names[entry.Key] = entry.Value; hashes[entry.Key] = clips.TryGetValue(entry.Key,out var clipData)?clipData.NameHash:Animator.StringToHash("KreeZy.CustomSoundAlert."+entry.Key); }
            }
            var sharedAlerts=SoundAlertCatalog.Expand(originalAlerts,labels);
            AccessTools.Field(typeof(EnumCollections),"SpeakerSounds").SetValue(null,sharedAlerts);
            modeNames = names;
            AccessTools.Field(typeof(Speaker), "modeStrings").SetValue(null, names);
            AccessTools.Field(typeof(Speaker), "ModeHashes").SetValue(null, hashes);
            foreach (var page in speakerPages) RefreshPage(page);
            Info("Shared SoundAlert length="+sharedAlerts.Length+"; sound list committed: " + string.Join(", ", labels.Select(x => x.Key + "=" + x.Value)));
        }
        static IEnumerable<KeyValuePair<int, string>> VisibleModes() => ModeCatalog.Visible(originalNames, labels);
        static void RefreshPage(StationpediaPage page)
        {
            page.ModeInsert.Clear();
            foreach (var entry in VisibleModes())
                page.ModeInsert.Add(new StationLogicInsert { LogicAccessTypes = entry.Key.ToString(), LogicName = entry.Value });
        }
        [HarmonyPatch(typeof(GameAudioEvent),"Trigger")]
        class CustomEventGate
        {
            static bool Prefix(GameAudioEvent __instance)
            {
                var data=__instance.ClipsData;
                if(!clipRegistry.IsCustom(data,out bool active))return true;
                return active&&CatalogMatchesRole;
            }
        }
        [HarmonyPatch(typeof(Speaker), "get_ModeStrings")]
        class ModesPatch { static void Postfix(ref string[] __result) { if (modeNames != null) __result = modeNames; } }
        [HarmonyPatch(typeof(Stationpedia), "AddLogicModeInfo")]
        class StationpediaModesPatch
        {
            static bool Prefix(Thing __0, ref StationpediaPage __1)
            {
                if (!(__0 is Speaker) || originalNames == null) return true;
                speakerPages.Add(__1);
                RefreshPage(__1);
                return false;
            }
        }
        [HarmonyPatch(typeof(Stationpedia), "AddModeStrings")]
        class StationpediaTextPatch
        {
            static bool Prefix(Thing __0, ref StationpediaPage __1)
            {
                if (!(__0 is Speaker) || originalNames == null) return true;
                if (Stationpedia.ModeStringItem != null)
                    foreach (var entry in VisibleModes())
                        __1.Text += string.Format("\n" + Stationpedia.ModeStringItem.Parsed, entry.Key, entry.Value);
                return false;
            }
        }
        static void Attach(Speaker speaker)
        {
            if (speaker == null || clips.Count == 0) return;
            try
            {
                var mode = speaker.InteractMode;
                if (mode == null || mode.AssociatedAudioEvents == null || lookup == null) return;
                var dict = lookup.GetValue(speaker) as Dictionary<int, GameAudioEvent>;
                if (dict == null) return;
                foreach (var pair in clips)
                {
                    var data = pair.Value;
                    if (dict.ContainsKey(data.NameHash)) continue;
                    var ev = new GameAudioEvent { Name = data.Name, NameHash = data.NameHash, Parent = speaker, ClipsData = data, StopIfInvalid = true };
                    ev.Conditions.Add(new SoundEffectCondition { Type = InteractableType.Mode, Value = pair.Key });
                    ev.Conditions.Add(new SoundEffectCondition { Type = InteractableType.OnOff, Value = 1 });
                    ev.Conditions.Add(new SoundEffectCondition { Type = InteractableType.Powered, Value = 1 });
                    mode.AssociatedAudioEvents.Add(ev);
                    if (!ReferenceEquals(mode.AssociatedAudioEvents, speaker.AudioEvents)) speaker.AudioEvents.Add(ev);
                    dict.Add(data.NameHash, ev);
                }
            }
            catch (Exception ex) { Error("[CustomSoundAlert] Speaker attach failed: " + ex); }
        }
        [HarmonyPatch(typeof(Thing), "Awake")]
        class SpawnPatch { static void Postfix(Thing __instance) { if (__instance is Speaker s) Attach(s); } }
        [HarmonyPatch(typeof(Speaker), "GetContextualName")]
        class NamePatch
        {
            static bool Prefix(Speaker __instance, Interactable interactable, ref string __result)
            {
                if (interactable.Action != InteractableType.Button1 || !clips.ContainsKey(__instance.Mode)) return true;
                __result = labels[__instance.Mode]; return false;
            }
        }
        [HarmonyPatch(typeof(Speaker), "SetLogicValue")]
        class SelectPatch
        {
            static bool Prefix(Speaker __instance, LogicType logicType, double value)
            {
                if((logicType==LogicType.SoundAlert||logicType==LogicType.Mode)&&CustomAlertPolicy.TryId(value,out int wanted)&&(!CatalogMatchesRole||!(GameManager.IsBatchMode?labels.ContainsKey(wanted):clips.ContainsKey(wanted))))return false;
                if ((logicType != LogicType.SoundAlert && logicType != LogicType.Mode) ||
                    double.IsNaN(value) || double.IsInfinity(value) || !(GameManager.IsBatchMode?labels.ContainsKey((int)value):clips.ContainsKey((int)value))) return true;
                Attach(__instance);
                OnServer.Interact(__instance.InteractMode, (int)value, false);
                return false;
            }
        }
    }
}
