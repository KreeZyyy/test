using System;
using System.IO;
namespace CustomSoundAlert
{
    internal sealed class SoundStorage
    {
        internal string Sounds { get; private set; }
        internal string Cache { get; private set; }
        internal static SoundStorage Prepare(string bepinexRoot,Action<string> log=null)
        {
            if(string.IsNullOrWhiteSpace(bepinexRoot))throw new ArgumentException("BepInEx root is required.",nameof(bepinexRoot));
            string root=Path.GetDirectoryName(Path.GetFullPath(bepinexRoot).TrimEnd(Path.DirectorySeparatorChar,Path.AltDirectorySeparatorChar));
            if(string.IsNullOrEmpty(root))throw new ArgumentException("BepInEx must have a parent directory.",nameof(bepinexRoot));
            var storage=new SoundStorage{Sounds=Path.Combine(root,"sounds"),Cache=Path.Combine(root,"CustomSoundAlertData","server-cache")};
            // First setup only: create empty directories. Never import or modify audio files.
            Directory.CreateDirectory(storage.Sounds);Directory.CreateDirectory(storage.Cache);
            log?.Invoke("Persistent sounds: "+storage.Sounds);
            log?.Invoke("Separate server cache: "+storage.Cache);
            return storage;
        }
    }
}
