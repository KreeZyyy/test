using UnityEngine;
namespace StationEmotes
{
 internal static class ChairBodyPath
 {
  internal static float Settle(float body)=>ChairTransitionPolicy.Ease((body-.35f)/.65f);
  internal static float Posture(float body)=>ChairTransitionPolicy.Ease(body);
  internal static float Lean(bool entering,float preparation,float body)=>entering?5f*Mathf.Sin(body*Mathf.PI):4f*preparation*(1-body);
  internal static Vector3 Support(Vector3 left,Vector3 right,int swinging,float progress)
  {
   var middle=(left+right)*.5f;middle.y=Mathf.Min(left.y,right.y);
   if(swinging>=0){var planted=swinging==0?right:left;float shift=.35f*Mathf.Sin(progress*Mathf.PI);middle.x=Mathf.Lerp(middle.x,planted.x,shift);middle.z=Mathf.Lerp(middle.z,planted.z,shift);}
   return middle;
  }
  internal static Vector3 Pelvis(bool entering,Vector3 seated,Vector3 support,Vector3 native,float preparation,float body,float release)
  {
   if(entering)
   {
    var result=Vector3.Lerp(support,native,ChairTransitionPolicy.Ease((body-.18f)/.82f));
    result.y=Mathf.Lerp(support.y,native.y,body);return result;
   }
   var p=Vector3.Lerp(seated,support,ChairTransitionPolicy.Ease(.55f*preparation+.45f*body));
   p.y=Mathf.Lerp(seated.y,support.y,body);return Vector3.Lerp(p,native,release);
  }
 }
}
