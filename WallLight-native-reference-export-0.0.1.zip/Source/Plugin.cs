using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using Assets.Scripts;
using Assets.Scripts.Objects.Structures;
using StationeersMods.Interface;
using UnityEngine;
namespace WallLightReference {
 [StationeersMod("kreezy.walllightreference","Wall Light Reference Export","0.0.1")]
 public sealed class Plugin:ModBehaviour {
  bool done;float next;
  public override void OnLoaded(ContentHandler content){base.OnLoaded(content);if(Application.isBatchMode)enabled=false;}
  void Update(){if(done||Time.realtimeSinceStartup<next)return;next=Time.realtimeSinceStartup+3;
   var world=UnityEngine.Object.FindObjectOfType<WorldManager>();if(world==null||world.SourcePrefabs==null)return;
   var lamps=world.SourcePrefabs.OfType<WallLight>().ToArray();if(lamps.Length==0)return;done=true;
   try{var asm=AppDomain.CurrentDomain.GetAssemblies().First(a=>a.GetName().Name=="ModularSwitchboards");var read=asm.GetType("ModularSwitchboards.CabinetGeometry").GetMethod("ReadNativeMesh",BindingFlags.NonPublic|BindingFlags.Static);
    string folder=Path.Combine(Application.persistentDataPath,"WallLightReference");Directory.CreateDirectory(folder);
    foreach(var lamp in lamps){var report=new Report{prefab=lamp.PrefabName,fields=Fields(lamp),bounds=lamp.Bounds};
     foreach(var c in lamp.GetComponentsInChildren<Component>(true))if(c!=null)report.components.Add(new ComponentInfo{path=PathOf(c.transform,lamp.transform),type=c.GetType().FullName,localPosition=c.transform.localPosition,localRotation=c.transform.localRotation,localScale=c.transform.localScale,fields=Fields(c)});
     foreach(var mf in lamp.GetComponentsInChildren<MeshFilter>(true)){if(mf.sharedMesh==null)continue;var part=new Part{path=PathOf(mf.transform,lamp.transform),name=mf.sharedMesh.name,matrix=lamp.transform.worldToLocalMatrix*mf.transform.localToWorldMatrix};
      try{object[] args={mf.sharedMesh,null,null,null};read.Invoke(null,args);part.vertices=(Vector3[])args[1];part.uv=(Vector2[])args[2];foreach(var ids in (int[][])args[3])part.triangles.Add(new Indices{values=ids});}catch(Exception e){part.error=e.ToString();}
      var renderer=mf.GetComponent<Renderer>();if(renderer!=null)foreach(var m in renderer.sharedMaterials){var mat=new MaterialInfo();if(m!=null){mat.name=m.name;mat.shader=m.shader==null?null:m.shader.name;if(m.shader!=null)for(int i=0;i<m.shader.GetPropertyCount();i++){string n=m.shader.GetPropertyName(i);var t=m.shader.GetPropertyType(i);string v;switch(t){case UnityEngine.Rendering.ShaderPropertyType.Color:v=m.GetColor(n).ToString("R");break;case UnityEngine.Rendering.ShaderPropertyType.Vector:v=m.GetVector(n).ToString("R");break;case UnityEngine.Rendering.ShaderPropertyType.Texture:var tex=m.GetTexture(n);v=tex==null?"null":tex.name+" "+tex.width+"x"+tex.height;break;default:v=m.GetFloat(n).ToString(System.Globalization.CultureInfo.InvariantCulture);break;}mat.properties.Add(new Field{name=n,value=v});}}part.materials.Add(mat);}report.parts.Add(part);}
     foreach(var l in lamp.GetComponentsInChildren<Light>(true))report.lights.Add(new LightInfo{path=PathOf(l.transform,lamp.transform),position=lamp.transform.InverseTransformPoint(l.transform.position),rotation=Quaternion.Inverse(lamp.transform.rotation)*l.transform.rotation,type=l.type.ToString(),color=l.color,intensity=l.intensity,range=l.range,spotAngle=l.spotAngle,shadows=l.shadows.ToString(),cullingMask=l.cullingMask});
     File.WriteAllText(Path.Combine(folder,lamp.PrefabName+".json"),JsonUtility.ToJson(report,true));}
    Debug.Log("[Wall Light Reference] Exported "+lamps.Length+" native wall light prefabs to "+folder);
   }catch(Exception e){Debug.LogError("[Wall Light Reference] "+e);}}
  static string PathOf(Transform t,Transform root){if(t==root)return ".";return t.parent==null?t.name:PathOf(t.parent,root)+"/"+t.name;}
  static List<Field> Fields(object obj){var list=new List<Field>();for(var type=obj.GetType();type!=null&&type!=typeof(UnityEngine.Object);type=type.BaseType)foreach(var f in type.GetFields(BindingFlags.Instance|BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.DeclaredOnly)){if(f.IsStatic||f.IsNotSerialized)continue;try{var v=f.GetValue(obj);if(v==null)continue;if(v is UnityEngine.Object u){list.Add(new Field{name=type.Name+"."+f.Name,value=u.name+" ("+u.GetType().Name+")"});continue;}if(f.FieldType.IsPrimitive||f.FieldType.IsEnum||v is string||v is Vector3||v is Vector2||v is Color||v is Bounds||v is Quaternion)list.Add(new Field{name=type.Name+"."+f.Name,value=Convert.ToString(v,System.Globalization.CultureInfo.InvariantCulture)});}catch{}}return list;}
  [Serializable]public class Field{public string name,value;}
  [Serializable]public class ComponentInfo{public string path,type;public Vector3 localPosition,localScale;public Quaternion localRotation;public List<Field> fields;}
  [Serializable]public class Indices{public int[] values;}
  [Serializable]public class MaterialInfo{public string name,shader;public List<Field> properties=new List<Field>();}
  [Serializable]public class Part{public string path,name,error;public Matrix4x4 matrix;public Vector3[] vertices;public Vector2[] uv;public List<Indices> triangles=new List<Indices>();public List<MaterialInfo> materials=new List<MaterialInfo>();}
  [Serializable]public class LightInfo{public string path,type,shadows;public Vector3 position;public Quaternion rotation;public Color color;public float intensity,range,spotAngle;public int cullingMask;}
  [Serializable]public class Report{public string prefab;public Bounds bounds;public List<Field> fields;public List<Part> parts=new List<Part>();public List<ComponentInfo> components=new List<ComponentInfo>();public List<LightInfo> lights=new List<LightInfo>();}
 }
}
