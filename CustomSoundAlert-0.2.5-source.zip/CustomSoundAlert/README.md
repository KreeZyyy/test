# Custom SoundAlert 0.2.5 — server audio download test

Custom SoundAlert IDs 100–199 for Speakers, Suits and Advanced Tablets. One identical mod for client and dedicated server. Requires StationeersLaunchPad, BepInEx and LaunchPadBooster. Use 0.2.5 on both peers for this transfer test.

Workshop: https://steamcommunity.com/sharedfiles/filedetails/?id=3844423968

## Files outside Workshop

```text
Stationeers/ (or the dedicated server installation)
  BepInEx/
  sounds/                         # your local or server audio
    100_server_test.wav
  CustomSoundAlertData/
    server-cache/                 # downloaded and verified server audio
    .legacy-import-v1             # completed one-time migration
```

The mod resolves the parent of the actual BepInEx folder, independent of the current working directory. Each installation has its own files. Add WAV, OGG or MP3 files named `<id>_<label>.<extension>`, with unique IDs 100–199, to that installation's sounds folder. Restart after editing files. The mod ZIP contains no songs.

## First setup and migration

If the new folders do not exist, the mod creates them. On first launch it copies supported audio from the old sounds folder beside its DLL, and hash-named cache files from the previous application persistent-data cache, into the new locations. If old folders do not exist, the new folders remain empty. Existing destination files are never overwritten, originals are never deleted. A completed migration is marked once so future Workshop bundles cannot repeatedly re-import audio. Failed copies clean temporary files and can retry on restart. Logs show migration counts and absolute paths. Keep the old server sounds folder empty before first migration if you want a vanilla-only server.

Files already manually added beside BepInEx stay untouched. Downloaded sounds go only into server-cache, never into your local sounds folder. Server cache filenames use the manifest's SHA256 and allowed extension; server labels are not used as paths.

## Speaker screwdriver selection

The sound selector skips unassigned numeric slots. For example, 45 advances directly to 100 and previous from 100 returns to 45. Gaps between custom IDs are skipped as well, and the Cycle to preview uses the same target. Existing native end clamping, tool requirement, volume control, numeric IC10 IDs and normal adjacent selection are preserved.

## Automatic server downloads

After the world join, the client verifies existing server-cache files on a worker task. Missing or corrupt files are requested from the host in 8 KiB chunks. Downloads use one outstanding chunk request per client, a bounded fair server queue and a shared server limit of 256 KiB/s of audio payload with a 32 KiB burst. Actual wire traffic includes Base64/protocol overhead. A chunk times out after 10 seconds and is retried twice before that file fails. Other files can continue after one fails.

The client checks every chunk's size and order, verifies the full byte count and SHA256, then atomically publishes the verified file. Corrupt/incomplete data is never registered for playback. The server serves only its startup catalog's indexed files and refuses sources changed since that snapshot. Client responses are accepted only from the current host and must match the active file's random token, ID and offset.

On-screen messages show checking, downloading, filename, percentage, byte counts, retry, verification, loading and ready-to-play states. Detailed failures also go to BepInEx/LogOutput.log. The overlay remains for 12 seconds after a status update. Cancellation/disconnect removes the current partial file; completed cache files persist. An abruptly terminated process can leave an unused .part file, which is never treated as playable audio.

Remote clients use only the server catalog and verified server cache. A private local file with the same ID is never substituted. A server with no custom sounds remains vanilla-only. Rejoining with a valid cache needs no new download. After all download attempts finish, available verified files are loaded and attached using the game's native audio paths. Download completion and ready-to-play are separate notifications.

## Installation and live test

Close the game/server. Extract the common mod ZIP over the existing CustomSoundAlert mod folder; keep a single installed copy. Keep your installation-level sounds and cache directories. No personal audio is bundled. Update both client and server before testing.

1. Leave a short, valid `100_server_test.wav` only in the server's sounds folder; restart the server.
2. Join with the client. Its own local ID 100 may contain a different song; do not copy the server file into local sounds.
3. Expect the server label, download/progress/verified/loading/ready messages, a SHA-named file in server-cache, and playback of the server WAV.
4. Reconnect after a clean game restart. Expect cache verification without another download, and correct playback.
5. Test an empty server separately: no local or cached custom sound should become available.

This is the first live transfer test build. Synchronizing playback position for late joiners is not implemented. Previously reported freezes/crashes while switching sessions without restarting remain unresolved and are not addressed here. Large songs still consume decoded PCM memory; encoded file limits do not bound decoded memory.

## Verification and limits

Native .NET Framework 4.7.2 API build passes. Production-code fixtures cover 34 transfer cases and 28 network-adapter checks with real temporary files and mocked game/network APIs, including roundtrips, SHA failure, corrupt cache replacement, sender authority, queue/rate limits, ordering, retries, cancellation, UI status and idle allocations. 417 sparse-dial checks cover the actual preview/action patch, both directions, holes, bounds, screwdriver requirements and native control passthrough. Storage/migration/catalog/manifest/audio registration regressions also pass. Live Unity audio decoding, overlay layout, RakNet/Steam transport and multiplayer behavior still require testing.

Catalog bounds: IDs 100–199, at most 100 entries, 32 MiB per source file, 128 MiB source bytes total, 96-character labels and 64 KiB manifest payload. Normal game sounds keep their native handling.

## Credits

Inspired by Sovana122: https://github.com/Sovana122/Sationeers-CustomSound/tree/speaker
Original license and attribution are preserved in LICENSE-Sovana.txt. Matching source and verification fixtures are provided separately.
