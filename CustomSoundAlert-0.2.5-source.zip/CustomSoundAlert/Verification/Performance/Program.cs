using System;
using System.Collections;
using System.Collections.Generic;
using CustomSoundAlert;
namespace UnityEngine {
 static class Time {internal static float unscaledTime;}
 static class Object {internal static AudioManager Current;internal static int Searches;internal static T FindObjectOfType<T>()where T:class{Searches++;return Current as T;}}
}
class AudioManager {
 internal bool Destroyed;
 internal object AudioSourcePrefab=new object();
 internal Dictionary<int,int> LoadedChannelData=new Dictionary<int,int>{{1,1}},MixerGroups=new Dictionary<int,int>{{1,1}};
 public static bool operator ==(AudioManager a,AudioManager b){bool x=ReferenceEquals(a,null)||a.Destroyed,y=ReferenceEquals(b,null)||b.Destroyed;return x||y?x==y:ReferenceEquals(a,b);}
 public static bool operator !=(AudioManager a,AudioManager b)=>!(a==b);
 public override bool Equals(object x)=>ReferenceEquals(this,x);
 public override int GetHashCode()=>base.GetHashCode();
}
namespace CustomSoundAlert {
 static class GameManager{internal static bool IsBatchMode;}
 class SoundEntry{internal int Id;internal string Name;}
 static class SoundCatalogHandshake{internal static SoundEntry[] Local=Array.Empty<SoundEntry>();}
 static class SoundTransferNetwork {internal static bool Ready=true;internal static void Tick(){}internal static void Loading(){}}
 partial class Plugin {
 AudioManager existingManager,registeredManager;bool loading,serverCatalogCommitted,selectedRemote;long seenCatalog=-1;float nextCheck;
 Dictionary<int,int> clips=new Dictionary<int,int>();Dictionary<int,string> labels=new Dictionary<int,string>();
 int Loads;
 void RefreshCatalogContext(){} void BuildModes(){} static void Info(string m){}
 void ClearCustomState(){clips.Clear();registeredManager=null;}
 IEnumerator Load(AudioManager manager){yield break;}
 void StartCoroutine(IEnumerator load){Loads++;registeredManager=existingManager;loading=false;}
 public static void Verify(){
  UnityEngine.Object.Searches=0;UnityEngine.Object.Current=new AudioManager();UnityEngine.Time.unscaledTime=1;
  var p=new Plugin();p.Update();Check(p.Loads==1&&UnityEngine.Object.Searches==1,"initial load");
  long before=GC.GetAllocatedBytesForCurrentThread();for(int i=0;i<100000;i++){UnityEngine.Time.unscaledTime++;p.Update();}long allocation=GC.GetAllocatedBytesForCurrentThread()-before;
  Check(p.Loads==1&&UnityEngine.Object.Searches==1,"steady state must not rescan/reload");Check(allocation==0,"steady state allocated "+allocation);
  p.registeredManager=null;p.Update();Check(p.Loads==2&&UnityEngine.Object.Searches==1,"role reload reuses existing manager");
  UnityEngine.Object.Current.Destroyed=true;UnityEngine.Object.Current=new AudioManager();UnityEngine.Time.unscaledTime++;p.Update();Check(p.Loads==3&&UnityEngine.Object.Searches==2,"destroyed manager replacement");
  p=new Plugin();UnityEngine.Object.Searches=0;UnityEngine.Object.Current=new AudioManager{AudioSourcePrefab=null};for(int i=0;i<100;i++){UnityEngine.Time.unscaledTime++;p.Update();}Check(UnityEngine.Object.Searches==1&&p.Loads==0,"unready manager cached");
  UnityEngine.Object.Current.AudioSourcePrefab=new object();UnityEngine.Time.unscaledTime++;p.Update();Check(p.Loads==1,"late initialization");
  p=new Plugin();GameManager.IsBatchMode=true;UnityEngine.Object.Searches=0;p.Update();Check(UnityEngine.Object.Searches==0&&p.Loads==0,"DS must not seek audio");GameManager.IsBatchMode=false;
  p=new Plugin{selectedRemote=true};p.Update();Check(UnityEngine.Object.Searches==0&&p.Loads==0,"wait for server manifest");
  Console.WriteLine("Actual Update: 100000 warm frames, 0 scene searches/reloads/allocated bytes; replacement, readiness, role reload and DS checks passed.");
 }
 static void Check(bool ok,string m){if(!ok)throw new Exception(m);}
 }
 class Program {
 static void Check(bool b,string m){if(!b)throw new Exception(m);}
 static void Main(){Plugin.Verify();var registry=new CustomClipRegistry<object>();var clip=new object();var vanilla=new object();registry.Register(clip);Check(registry.IsCustom(clip,out bool active)&&active,"active clip");Check(!registry.IsCustom(vanilla,out _)&&!registry.IsCustom(null,out _),"native/null bypass");registry.Clear();Check(registry.IsCustom(clip,out active)&&!active,"stale event blocked");var next=new object();registry.Register(next);Check(registry.IsCustom(next,out active)&&active,"new context clip");for(int i=0;i<1000;i++)registry.IsCustom(next,out _);long before=GC.GetAllocatedBytesForCurrentThread();for(int i=0;i<100000;i++){registry.IsCustom(next,out _);registry.IsCustom(vanilla,out _);}Check(GC.GetAllocatedBytesForCurrentThread()==before,"event ownership allocation");Console.WriteLine("CustomClipRegistry: active/stale/vanilla/null checks and 200000 ownership lookups without allocations passed.");}
 }
}
