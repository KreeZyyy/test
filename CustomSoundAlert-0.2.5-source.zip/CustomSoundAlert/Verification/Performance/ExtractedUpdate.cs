using UnityEngine;
namespace CustomSoundAlert {partial class Plugin {
        void Update()
        {
            RefreshCatalogContext();
            SoundTransferNetwork.Tick();
            if(GameManager.IsBatchMode){if(!serverCatalogCommitted){labels.Clear();foreach(var e in SoundCatalogHandshake.Local)labels[e.Id]=e.Name;BuildModes();serverCatalogCommitted=true;}return;}
            if(selectedRemote&&(seenCatalog<0||!SoundTransferNetwork.Ready))return;
            // The manager persists across scenes. Once registered, do no scene scans,
            // file reads or decoding until that Unity object is destroyed or the role resets.
            if (loading || IsReady(registeredManager) || Time.unscaledTime < nextCheck) return;
            nextCheck = Time.unscaledTime + 0.5f;
            // Singleton.Instance calls Create() in the game; never use it for a readiness check.
            if(existingManager==null)existingManager=UnityEngine.Object.FindObjectOfType<AudioManager>();
            var manager = existingManager;
            if (!IsReady(manager) || manager == registeredManager) return;
            Info("Existing AudioManager is ready; starting custom file loading.");
            if(clips.Count>0)ClearCustomState();
            loading = true;
            if(selectedRemote)SoundTransferNetwork.Loading();
            StartCoroutine(Load(manager));
        }
        static bool IsReady(AudioManager manager) => manager != null &&
            manager.AudioSourcePrefab != null && manager.LoadedChannelData != null &&
            manager.LoadedChannelData.Count > 0 && manager.MixerGroups != null && manager.MixerGroups.Count > 0;
}}
