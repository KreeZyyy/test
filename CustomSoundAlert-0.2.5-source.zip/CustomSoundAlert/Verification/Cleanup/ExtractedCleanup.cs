using System;using System.Collections.Generic;
namespace CustomSoundAlert {partial class Plugin {
        static void ReleaseClips()
        {
            clipRegistry.Clear();
            foreach(var pair in ownedClips)
            {
                var data=pair.Key;var manager=pair.Value;
                if(manager!=null && managerClips.GetValue(manager) is Dictionary<int,GameAudioClipsData> index &&
                    index.TryGetValue(data.NameHash,out var current) && ReferenceEquals(current,data))index.Remove(data.NameHash);
                foreach(var clip in data.Clips)if(clip!=null)UnityEngine.Object.Destroy(clip);
            }
            ownedClips.Clear();clips.Clear();
        }
}}
