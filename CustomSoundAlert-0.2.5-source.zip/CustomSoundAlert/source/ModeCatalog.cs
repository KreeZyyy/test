using System;
using System.Collections.Generic;
using System.Linq;
namespace CustomSoundAlert
{
    public static class ModeCatalog
    {
        public static string[] BuildNames(string[] original, IReadOnlyDictionary<int, string> custom)
        {
            var names = (string[])original.Clone();
            int length = custom.Count == 0 ? names.Length : Math.Max(names.Length, custom.Keys.Max() + 1);
            Array.Resize(ref names, length);
            foreach (var entry in custom) names[entry.Key] = entry.Value;
            return names;
        }
        public static int Step(string[] names,int current,bool previous)
        {
            if(names==null||names.Length==0)return current;
            int direction=previous?-1:1;
            long next=(long)current+direction;
            if(previous&&next>=names.Length)next=names.Length-1;
            if(!previous&&next<0)next=0;
            while(next>=0&&next<names.Length)
            {
                if(!string.IsNullOrEmpty(names[(int)next]))return (int)next;
                next+=direction;
            }
            // Preserve native clamping at the first/last usable entry.
            for(int i=previous?0:names.Length-1;i>=0&&i<names.Length;i-=direction)
                if(!string.IsNullOrEmpty(names[i]))return i;
            return current;
        }
        public static IEnumerable<KeyValuePair<int, string>> Visible(string[] original, IReadOnlyDictionary<int, string> custom)
        {
            for (int i = 0; i < original.Length; i++)
                if (!string.IsNullOrEmpty(original[i])) yield return new KeyValuePair<int, string>(i, original[i]);
            foreach (var entry in custom.OrderBy(x => x.Key)) yield return entry;
        }
    }
}
