using System;
using System.Runtime.CompilerServices;
namespace CustomSoundAlert
{
    // Weak keys keep stale audio events blocked without retaining old decoded clips.
    internal sealed class CustomClipRegistry<T> where T:class
    {
        sealed class State {internal long Generation;}
        readonly ConditionalWeakTable<T,State> entries=new ConditionalWeakTable<T,State>();
        long generation;
        internal void Register(T clip){entries.Remove(clip);entries.Add(clip,new State{Generation=generation});}
        internal void Clear(){generation++;}
        internal bool IsCustom(T clip,out bool active)
        {
            active=false;
            if(clip==null||!entries.TryGetValue(clip,out var state))return false;
            active=state.Generation==generation;return true;
        }
    }
}
