using System;
using System.IO;
namespace CustomSoundAlert
{
    internal sealed class SoundStorage
    {
        internal string Sounds { get; private set; }
        internal string Cache { get; private set; }
        internal static SoundStorage Prepare(string bepinexRoot,Action<string> log=null,string legacySounds=null,string legacyCache=null)
        {
            if(string.IsNullOrWhiteSpace(bepinexRoot))throw new ArgumentException("BepInEx root is required.",nameof(bepinexRoot));
            string root=Path.GetDirectoryName(Path.GetFullPath(bepinexRoot).TrimEnd(Path.DirectorySeparatorChar,Path.AltDirectorySeparatorChar));
            if(string.IsNullOrEmpty(root))throw new ArgumentException("BepInEx must have a parent directory.",nameof(bepinexRoot));
            var storage=new SoundStorage{Sounds=Path.Combine(root,"sounds"),Cache=Path.Combine(root,"CustomSoundAlertData","server-cache")};
            Directory.CreateDirectory(storage.Sounds);Directory.CreateDirectory(storage.Cache);
            string marker=Path.Combine(root,"CustomSoundAlertData",".legacy-import-v1");
            if(!File.Exists(marker))
            {
                int sounds=CopyLegacy(legacySounds,storage.Sounds,false);
                int cached=CopyLegacy(legacyCache,storage.Cache,true);
                string temporary=marker+"."+Guid.NewGuid().ToString("N")+".tmp";
                try
                {
                    File.WriteAllText(temporary,"Legacy import completed. Originals retained; existing destination files preserved.\n");
                    try{File.Move(temporary,marker);}catch(IOException){if(!File.Exists(marker))throw;}
                }
                finally{if(File.Exists(temporary))File.Delete(temporary);}
                log?.Invoke("Legacy migration complete: "+sounds+" sounds and "+cached+" cache files copied; existing files and originals preserved.");
            }
            log?.Invoke("Persistent sounds: "+storage.Sounds);
            log?.Invoke("Separate server cache: "+storage.Cache);
            return storage;
        }
        static int CopyLegacy(string source,string destination,bool cacheOnly)
        {
            if(string.IsNullOrWhiteSpace(source)||!Directory.Exists(source)||
                string.Equals(Path.GetFullPath(source).TrimEnd(Path.DirectorySeparatorChar,Path.AltDirectorySeparatorChar),
                Path.GetFullPath(destination).TrimEnd(Path.DirectorySeparatorChar,Path.AltDirectorySeparatorChar),StringComparison.OrdinalIgnoreCase))return 0;
            int copied=0;
            foreach(string file in Directory.GetFiles(source))
            {
                string extension=Path.GetExtension(file).ToLowerInvariant();
                if(extension!=".wav"&&extension!=".ogg"&&extension!=".mp3")continue;
                if(cacheOnly)
                {
                    string name=Path.GetFileNameWithoutExtension(file);if(name.Length!=64)continue;
                    bool valid=true;foreach(char c in name)if(!(c>='0'&&c<='9'||c>='a'&&c<='f')){valid=false;break;}
                    if(!valid)continue;
                }
                string target=Path.Combine(destination,Path.GetFileName(file));if(File.Exists(target))continue;
                string temporary=target+"."+Guid.NewGuid().ToString("N")+".importing";
                try
                {
                    File.Copy(file,temporary,false);
                    try{File.Move(temporary,target);copied++;}catch(IOException){if(!File.Exists(target))throw;}
                }
                finally{if(File.Exists(temporary))File.Delete(temporary);}
            }
            return copied;
        }
    }
}
