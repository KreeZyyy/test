# Custom SoundAlert 0.2.5 — initial automatic download implementation

The existing LaunchPadBooster world-join prefix publishes the server catalog. Two registered INetworkMessage types carry bounded chunk requests and responses after world join. This build requires matching client/server versions.

Implemented: worker-side cache verification, host-only response acceptance, per-file random tokens, indexed server-only source selection, 8 KiB ordered chunks, one outstanding request per client, bounded 32-client pending queue, server rate limiting (256 KiB/s audio payload / 32 KiB burst), 10-second timeout with two retries, incremental SHA256 verification, atomic cache publication, partial cleanup on cancellation, separate local/private storage, native registration after verified downloads, on-screen status and throttled progress logs.

Storage: sounds beside BepInEx; remote cache in CustomSoundAlertData/server-cache. Missing directories are created. Optional old mod-level sounds and old application cache are copied once without overwriting destination files or removing originals. Missing old locations result in empty new folders. Repeated launches do not repeat a completed migration.

A failed file is unavailable for playback; other verified files can load. Server files changed since startup are refused until restart. An empty manifest exposes no custom audio. Hash-matching cache can be reused across servers without using private local files. The mod does not transfer client sounds to the server. File edits require restart.

Not implemented: synchronized playback offsets for late joiners, persistent resume across disconnects, or a fix for previously reported session-transition crashes. Current partial files are discarded on normal cancellation; abrupt process termination can leave unused .part files. Encoded source-size bounds do not cap decoded PCM memory.

Native game API compilation and production-code filesystem/network-stub fixtures pass; actual Unity/Steam/RakNet transfer, decoding, overlay rendering and live performance are pending user testing. Previous live evidence covers local playback, empty-server isolation and correct nonempty server catalog labels only.
