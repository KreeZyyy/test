// Control-flow regression harness only. Does not simulate the Unity engine/IK solver.
using System;using StationEmotes;using UnityEngine;using UnityEngine.Animations;
namespace UnityEngine {
 public struct Vector3 {public float x,y,z;public static Vector3 zero=>default;public static Vector3 forward=>new Vector3{z=1};public static Vector3 operator+(Vector3 a,Vector3 b)=>new Vector3{x=a.x+b.x,y=a.y+b.y,z=a.z+b.z};}
 public struct Quaternion {
  public float x,y,z,w;
  static Quaternion Wrap(System.Numerics.Quaternion q)=>new Quaternion{x=q.X,y=q.Y,z=q.Z,w=q.W};
  static System.Numerics.Quaternion N(Quaternion q)=>new System.Numerics.Quaternion(q.x,q.y,q.z,q.w);
  public static Quaternion identity=>new Quaternion{w=1};
  public static Quaternion Inverse(Quaternion q)=>Wrap(System.Numerics.Quaternion.Inverse(N(q)));
  public static Quaternion AngleAxis(float angle,Vector3 axis)=>Wrap(System.Numerics.Quaternion.CreateFromAxisAngle(new System.Numerics.Vector3(axis.x,axis.y,axis.z),angle*(float)Math.PI/180));
  public static Quaternion operator*(Quaternion a,Quaternion b)=>Wrap(N(a)*N(b));
  public static Vector3 operator*(Quaternion q,Vector3 v){var x=System.Numerics.Vector3.Transform(new System.Numerics.Vector3(v.x,v.y,v.z),N(q));return new Vector3{x=x.X,y=x.Y,z=x.Z};}
  public static Quaternion Slerp(Quaternion a,Quaternion b,float w)=>Wrap(System.Numerics.Quaternion.Slerp(N(a),N(b),w));
 }

 public static class Mathf {public static float Clamp(float x,float a,float b)=>Math.Max(a,Math.Min(b,x));}
 public enum AvatarIKGoal {LeftFoot,RightFoot,RightHand}
}
namespace UnityEngine.Animations {
 public enum HumanPartDof {LeftLeg,RightLeg}
 public enum LegDof {LegCloseOpen}
 public struct MuscleHandle {public MuscleHandle(HumanPartDof p,LegDof d){}}
 public interface IAnimationJob {void ProcessAnimation(AnimationStream s);void ProcessRootMotion(AnimationStream s);}
 public struct AnimationStream {public bool isHumanStream;public AnimationHumanStream AsHuman(){if(!isHumanStream)throw new Exception("AsHuman on generic stream");return new AnimationHumanStream();}}
 public struct TransformStreamHandle {
  public bool Valid;public bool IsValid(AnimationStream s)=>Valid;public void Resolve(AnimationStream s){}
  public Quaternion GetRotation(AnimationStream s)=>Quaternion.identity;public Vector3 GetPosition(AnimationStream s)=>new Vector3{x=2,y=3};public Quaternion GetLocalRotation(AnimationStream s)=>Quaternion.identity;public void SetLocalRotation(AnimationStream s,Quaternion r){Check.Writes++;if(Check.Monitor)Check.Order+="B";}
 }
 public struct AnimationHumanStream {
  public Vector3 bodyLocalPosition {get;set;}public Quaternion bodyLocalRotation {get;set;}public float GetMuscle(MuscleHandle m)=>0;public void SetMuscle(MuscleHandle m,float v){Check.Muscles++;}
  public float leftFootHeight=>.1f;public float rightFootHeight=>.2f;
  public Vector3 GetGoalPositionFromPose(AvatarIKGoal g)=>new Vector3{y=99};public Quaternion GetGoalRotationFromPose(AvatarIKGoal g)=>Quaternion.identity;
  public void SetGoalPosition(AvatarIKGoal g,Vector3 p){if(g==AvatarIKGoal.RightHand){Check.HandX=p.x;Check.HandY=p.y;Check.HandGoals++;}else if(g==AvatarIKGoal.LeftFoot)Check.Left=p.y;else Check.Right=p.y;}
  public void SetGoalRotation(AvatarIKGoal g,Quaternion q){}public void SetGoalWeightPosition(AvatarIKGoal g,float w){}public void SetGoalWeightRotation(AvatarIKGoal g,float w){if(g==AvatarIKGoal.RightHand)Check.HandRotationWeight=w;}
  public void SolveIK(){Check.Solves++;if(Check.Monitor)Check.Order+="I";}
 }
}
class Check {
 public static int Writes,Solves,Muscles,HandGoals;public static float HandX,HandY,HandRotationWeight;public static bool Monitor;public static string Order="";public static float Left,Right;
 static void A(bool b,string why){if(!b)throw new Exception(why);}
 static void Main(){
  var j=new PoseJob{Count=3,Feet=true,LeftFloor=2,RightFloor=3};
  j.Set(0,new PoseSlot{Handle=new TransformStreamHandle{Valid=true},Rotation=Quaternion.identity,Weight=1});
  j.Set(1,new PoseSlot{Handle=new TransformStreamHandle{Valid=true},Rotation=Quaternion.identity,Weight=1});
  j.Set(2,new PoseSlot{Handle=new TransformStreamHandle{Valid=false},Weight=1});
  j.ProcessAnimation(new AnimationStream{isHumanStream=false});
  A(Writes==2,"generic stream dropped valid bone poses");A(Solves==0,"generic stream attempted human IK");A(j.Frames==1&&j.HumanFrames==0&&j.LastApplied==2,"generic diagnostics wrong");
  j.ProcessAnimation(new AnimationStream{isHumanStream=true});
  A(Writes==4&&Solves==1,"human stream did not apply poses and IK");A(Math.Abs(Left-2.1f)<.0001f&&Math.Abs(Right-3.2f)<.0001f,"floor/foot-height goals wrong");A(j.Frames==2&&j.HumanFrames==1,"human counters wrong");
  j.Feet=false;j.ProcessAnimation(new AnimationStream{isHumanStream=true});A(Writes==6&&Solves==1,"arm pose invoked foot IK");
  j.ProcessRootMotion(default);A(Writes==6,"root motion handler changes transforms");
  Monitor=true;Writes=0;Order="";
  var dance=new PoseJob{Count=10,Feet=true,Dance=true,Sway=.5f,Bend=.8f,Blend=1};
  for(int i=0;i<10;i++)dance.Set(i,new PoseSlot{Handle=new TransformStreamHandle{Valid=true},Rotation=Quaternion.identity,Weight=1});
  dance.ProcessAnimation(new AnimationStream{isHumanStream=true});
  A(Order=="IBBBBB","IK overwrites upper-body pose or raw legs overwrite solved feet");
  A(Writes==5&&Muscles==2,"dance must use five upper-body transforms and humanoid legs");
  Writes=0;Order="";HandGoals=0;
  var face=new PoseJob{Count=1,Facepalm=true,PalmRotationWeight=1,PalmRotation=Quaternion.identity,PalmOffset=new Vector3{x=.1f,y=.2f}};
  face.Set(0,new PoseSlot{Handle=new TransformStreamHandle{Valid=true},Rotation=Quaternion.identity,Weight=1});
  face.ProcessAnimation(new AnimationStream{isHumanStream=true});
  A(Order=="IB"&&HandGoals==1,"facepalm IK must precede head pose");
  A(Math.Abs(HandX-2.1f)<.001f&&Math.Abs(HandY-3.2f)<.001f,"palm does not follow head anchor");
  HandGoals=0;Order="";face.ProcessAnimation(new AnimationStream{isHumanStream=false});
  A(Order=="B"&&HandGoals==0,"generic facepalm attempted humanoid IK");
  A(HandRotationWeight==1,"mapped fingers should allow palm alignment");
  HandGoals=0;HandRotationWeight=-1;Order="";face.PalmRotationWeight=0;
  face.ProcessAnimation(new AnimationStream{isHumanStream=true});
  A(HandGoals==1&&Order=="IB","missing fingers must not disable facepalm position IK");
  A(HandRotationWeight==0,"missing fingers must not force unknown wrist alignment");
  HandGoals=0;Order="";face.PalmRotationWeight=1;
  var slot=face.Get(0);slot.Rotation=Quaternion.AngleAxis(30,Vector3.forward);face.Set(0,slot);
  face.ProcessAnimation(new AnimationStream{isHumanStream=true});
  A(Math.Abs(HandX-(2+.1*Math.Cos(Math.PI/6)-.2*Math.Sin(Math.PI/6)))<.001,"palm uses old head rotation horizontally");
  A(Math.Abs(HandY-(3+.1*Math.Sin(Math.PI/6)+.2*Math.Cos(Math.PI/6)))<.001,"palm uses old head rotation vertically");
  Monitor=false;
  Console.WriteLine("18 production-job control-flow checks passed (Unity stubs; no live IK execution).");
 }
}
