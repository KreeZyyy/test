using UnityEngine.Experimental.Animations;
using System;
using UnityEngine;
using UnityEngine.Animations;
using UnityEngine.Playables;
using Assets.Scripts.Objects.Entities;
namespace StationEmotes
{
 // Owned overlay graph reads the Animator's preceding output via PreviousInputs.
 // The native controller/graph is never rewired, played or destroyed by this class.
 internal sealed class NativePose:IDisposable
 {
  private Animator animator;private PlayableGraph graph;private AnimationScriptPlayable playable;
  private PoseJob data;private bool attached,reported;private float attachedAt;
  internal bool Attach(Animator a,Transform[] bones)
  {
   if(a==null||!a.isHuman||bones.Length>10)return false;
   animator=a;data=new PoseJob{Count=bones.Length};
   try
   {
    for(int i=0;i<bones.Length;i++)data.Set(i,new PoseSlot{Handle=a.BindStreamTransform(bones[i]),Rotation=bones[i].localRotation});
    graph=PlayableGraph.Create("StationEmotes overlay "+a.GetInstanceID());
    graph.SetTimeUpdateMode(DirectorUpdateMode.GameTime);
    playable=AnimationScriptPlayable.Create(graph,data,0);
    playable.SetProcessInputs(false);
    var output=AnimationPlayableOutput.Create(graph,"StationEmotes pose",a);
    output.SetAnimationStreamSource(AnimationStreamSource.PreviousInputs);
    output.SetSortingOrder(1000);output.SetWeight(1f);output.SetSourcePlayable(playable);
    playable.Play();graph.Play();attached=true;attachedAt=Time.unscaledTime;
    Plugin.Log.LogInfo("Pose overlay started: playing="+graph.IsPlaying()+", source=PreviousInputs, human="+a.isHuman+", bones="+bones.Length);
    return true;
   }
   catch(Exception e){Dispose();Plugin.Log.LogWarning("Pose overlay attachment failed: "+e);return false;}
  }
  internal void Set(int i,Quaternion rotation,float weight)
  {var slot=data.Get(i);slot.Rotation=rotation;slot.Weight=weight;data.Set(i,slot);}
  internal void SetFacepalm(Vector3 offset,Quaternion rotation,bool orient)
  {data.Facepalm=true;data.PalmOffset=offset;data.PalmRotation=rotation;data.PalmRotationWeight=orient?1f:0f;}
  internal void SetDance(float sway,float bend,float blend)
  {data.Dance=true;data.Sway=sway;data.Bend=bend;data.Blend=blend;}
  internal bool Submit(Human human,bool feet)
  {
   if(!attached||animator==null||!playable.IsValid())return false;
   var ran=playable.GetJobData<PoseJob>();
   data.Frames=ran.Frames;data.HumanFrames=ran.HumanFrames;data.LastApplied=ran.LastApplied;
   if(!reported&&Time.unscaledTime-attachedAt>1f)
   {
    reported=true;
    Plugin.Log.LogInfo("Native pose execution: frames="+ran.Frames+", humanFrames="+ran.HumanFrames+", appliedBones="+ran.LastApplied+"/"+data.Count);
    if(ran.Frames==0||ran.LastApplied==0)Plugin.Log.LogWarning("Native pose did not produce bone updates; send this log with F9 rig report.");
    else if(ran.HumanFrames==0)Plugin.Log.LogWarning("Animator supplies a non-human stream: pose remains enabled, humanoid foot IK is unavailable.");
   }
   data.Feet=false;
   if(feet)
   {
    if(!human.IsGrounded(human.AllButPlayerImmune,.08f)){Plugin.Log.LogInfo("Dance stopped: character is not grounded.");return false;}
    var left=animator.GetBoneTransform(HumanBodyBones.LeftFoot);var right=animator.GetBoneTransform(HumanBodyBones.RightFoot);
    if(left==null||right==null){Plugin.Log.LogWarning("Dance stopped: missing foot bones.");return false;}
    RaycastHit l,r;
    if(!Physics.Raycast(left.position+Vector3.up*.3f,Vector3.down,out l,.8f,human.AllButPlayerImmune,QueryTriggerInteraction.Ignore)||
       !Physics.Raycast(right.position+Vector3.up*.3f,Vector3.down,out r,.8f,human.AllButPlayerImmune,QueryTriggerInteraction.Ignore)||l.normal.y<.7f||r.normal.y<.7f){Plugin.Log.LogInfo("Dance stopped: foot support probe failed.");return false;}
    data.LeftFloor=l.point.y;data.RightFloor=r.point.y;data.Feet=true;
   }
   playable.SetJobData(data);return true;
  }
  public void Dispose()
  {
   attached=false;
   // This graph was created by Attach; it is never Animator.playableGraph.
   if(graph.IsValid())graph.Destroy();
   animator=null;
  }
 }

 internal struct PoseSlot
 {
  public TransformStreamHandle Handle;public Quaternion Rotation;public float Weight;
  public bool Apply(AnimationStream stream)
  {if(!Handle.IsValid(stream))return false;Handle.Resolve(stream);Handle.SetLocalRotation(stream,Quaternion.Slerp(Handle.GetLocalRotation(stream),Rotation,Weight));return true;}
 }
 internal struct PoseJob:IAnimationJob
 {
  public int Count,Frames,HumanFrames,LastApplied;public bool Feet,Dance,Facepalm;public Vector3 PalmOffset;public Quaternion PalmRotation;public float PalmRotationWeight;public float LeftFloor,RightFloor,Sway,Bend,Blend;
  public PoseSlot A,B,C,D,E,F,G,H,I,J;
  public PoseSlot Get(int i){switch(i){case 0:return A;case 1:return B;case 2:return C;case 3:return D;case 4:return E;case 5:return F;case 6:return G;case 7:return H;case 8:return I;default:return J;}}
  public void Set(int i,PoseSlot s){switch(i){case 0:A=s;break;case 1:B=s;break;case 2:C=s;break;case 3:D=s;break;case 4:E=s;break;case 5:F=s;break;case 6:G=s;break;case 7:H=s;break;case 8:I=s;break;default:J=s;break;}}
  public void ProcessRootMotion(AnimationStream stream){} // Original root motion passes through unchanged.
  public void ProcessAnimation(AnimationStream stream)
  {
   Frames++;LastApplied=0;
   bool humanoid=stream.isHumanStream;
   if(humanoid)HumanFrames++;
   // Bone animation is valid for both generic and humanoid streams.
   // The Animator avatar being humanoid does not establish this stream's type.
   var human=humanoid?stream.AsHuman():default(AnimationHumanStream);
   // Capture the native stance BEFORE changing hips/legs. Let Unity solve knees/ankles.
   var left=humanoid?human.GetGoalPositionFromPose(AvatarIKGoal.LeftFoot):Vector3.zero;
   var right=humanoid?human.GetGoalPositionFromPose(AvatarIKGoal.RightFoot):Vector3.zero;
   var lr=humanoid?human.GetGoalRotationFromPose(AvatarIKGoal.LeftFoot):Quaternion.identity;var rr=humanoid?human.GetGoalRotationFromPose(AvatarIKGoal.RightFoot):Quaternion.identity;
   if(Feet&&humanoid)
   {
    if(Dance)
    {
     // Change the human pose BEFORE solving feet. Raw leg rotations would
     // either be discarded by SolveIK or undo its grounding if written after it.
     var body=human.bodyLocalPosition;
     body.x+=.018f*Sway*Blend;body.y-=.025f*Bend*Blend;
     human.bodyLocalPosition=body;
     human.bodyLocalRotation=human.bodyLocalRotation*Quaternion.AngleAxis(4f*Sway*Blend,Vector3.forward);
     var l=new MuscleHandle(HumanPartDof.LeftLeg,LegDof.LegCloseOpen);
     var r=new MuscleHandle(HumanPartDof.RightLeg,LegDof.LegCloseOpen);
     human.SetMuscle(l,Mathf.Clamp(human.GetMuscle(l)-.12f*Bend*Blend,-1f,1f));
     human.SetMuscle(r,Mathf.Clamp(human.GetMuscle(r)-.12f*Bend*Blend,-1f,1f));
    }
    left.y=LeftFloor+human.leftFootHeight;right.y=RightFloor+human.rightFootHeight;
    human.SetGoalPosition(AvatarIKGoal.LeftFoot,left);human.SetGoalPosition(AvatarIKGoal.RightFoot,right);
    human.SetGoalRotation(AvatarIKGoal.LeftFoot,lr);human.SetGoalRotation(AvatarIKGoal.RightFoot,rr);
    human.SetGoalWeightPosition(AvatarIKGoal.LeftFoot,1f);human.SetGoalWeightPosition(AvatarIKGoal.RightFoot,1f);
    human.SetGoalWeightRotation(AvatarIKGoal.LeftFoot,1f);human.SetGoalWeightRotation(AvatarIKGoal.RightFoot,1f);
    human.SolveIK();
   }
   if(Facepalm&&humanoid&&A.Handle.IsValid(stream))
   {
    var anchor=A.Handle;anchor.Resolve(stream);
    // Use the head pose that will be applied AFTER SolveIK, so the palm follows
    // the face/helmet tilt rather than aiming at the previous head rotation.
    var local=anchor.GetLocalRotation(stream);
    var rotation=anchor.GetRotation(stream)*Quaternion.Inverse(local)*Quaternion.Slerp(local,A.Rotation,A.Weight);
    human.SetGoalPosition(AvatarIKGoal.RightHand,anchor.GetPosition(stream)+rotation*PalmOffset);
    human.SetGoalRotation(AvatarIKGoal.RightHand,rotation*PalmRotation);
    human.SetGoalWeightPosition(AvatarIKGoal.RightHand,A.Weight);
    human.SetGoalWeightRotation(AvatarIKGoal.RightHand,A.Weight*PalmRotationWeight);
    human.SolveIK();
   }
   // SolveIK rebuilds the humanoid pose: apply upper-body transforms AFTER it.
   // Dance slots 5..9 are legs/hips, now owned by the human pose + foot solver.
   int transforms=Feet&&humanoid&&Dance?Math.Min(Count,5):Count;
   for(int i=0;i<transforms;i++)if(Get(i).Apply(stream))LastApplied++;

  }
 }
}
