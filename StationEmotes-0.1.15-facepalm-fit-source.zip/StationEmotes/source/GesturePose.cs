using System;
using Assets.Scripts;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Inventory;
using Assets.Scripts.Objects.Entities;
using Assets.Scripts.Emotes;
using UnityEngine;
namespace StationEmotes
{
 internal static class GesturePolicy
 {
  // Two gentle nods/shakes, followed by a pause. Continuous until cancelled.
  internal static float Sample(float seconds)
  {
   if(float.IsNaN(seconds)||float.IsInfinity(seconds)||seconds<0)return 0;
   float phase=seconds%2.6f;
   return phase<1.6f?(float)Math.Sin(phase/1.6f*Math.PI*4)* (float)Math.Sin(phase/1.6f*Math.PI):0;
  }
 }
 [DefaultExecutionOrder(10000)]
 public sealed class GesturePose:MonoBehaviour
 {
  internal bool Active {get;private set;}
  internal int Index {get;private set;}
  private Human owner;private NativePose pose;private Quaternion rest;private Vector3 axis,origin;
  private float started;
  private Transform faceHead;private Quaternion faceHandRotation;private Vector3 facePalm,faceForward,faceUp,faceRight;
  private bool faceOrient,profileReady;private float faceScale=1f;
  private UnityEngine.Object faceHelmet;private Mesh faceMesh;
  internal void Begin(Human human,Animator animator,int kind)
  {
   Stop();if(animator==null||!animator.isHuman)return;
   var head=animator.GetBoneTransform(HumanBodyBones.Head);
   if(head==null||head.parent==null){Plugin.Log.LogWarning("Gesture skipped: humanoid head missing.");return;}
   var facing=human.CharacterRotationY!=null?human.CharacterRotationY:human.transform;
   owner=human;Index=kind;rest=head.localRotation;origin=human.transform.position;
   axis=Quaternion.Inverse(head.parent.rotation)*(kind==Plugin.Disagree?facing.up:facing.right);
   pose=new NativePose();
   if(!pose.Attach(animator,new[]{head})){Stop();return;}
   if(kind==Plugin.Facepalm&&!PrepareFacepalm(human,animator,head,facing)){Stop();return;}
   started=Time.unscaledTime;Active=true;
   Plugin.Log.LogInfo("Gesture started: id="+kind+", human="+human.ReferenceId);
  }
  private bool PrepareFacepalm(Human human,Animator animator,Transform head,Transform facing)
  {
   var hand=animator.GetBoneTransform(HumanBodyBones.RightHand);
   if(hand==null||animator.GetBoneTransform(HumanBodyBones.RightUpperArm)==null||animator.GetBoneTransform(HumanBodyBones.RightLowerArm)==null){Plugin.Log.LogWarning("Facepalm skipped: right arm or hand missing.");return false;}
   // This game's rig has index_01_r/middle_01_r even when optional humanoid
   // finger mappings are absent. Use only verified, direct hand children.
   var index=animator.GetBoneTransform(HumanBodyBones.RightIndexProximal)??hand.Find("index_01_r");
   var middle=animator.GetBoneTransform(HumanBodyBones.RightMiddleProximal)??hand.Find("middle_01_r");
   var little=animator.GetBoneTransform(HumanBodyBones.RightLittleProximal)??hand.Find("pinky_01_r");
   faceHead=head;faceOrient=false;facePalm=Vector3.zero;
   var desiredHand=hand.rotation;
   if(index!=null&&middle!=null&&index.IsChildOf(hand)&&middle.IsChildOf(hand))
   {
    var edge=little!=null&&little.IsChildOf(hand)?little:middle;
    var fingers=middle.position-hand.position;
    var normal=-Vector3.Cross(index.position-hand.position,edge.position-hand.position);
    if(fingers.sqrMagnitude>.000001f&&normal.sqrMagnitude>.00000001f)
    {
     var frame=Quaternion.LookRotation(normal.normalized,fingers.normalized);
     desiredHand=Quaternion.LookRotation(-facing.forward,facing.up)*Quaternion.Inverse(frame)*hand.rotation;
     // Target the palm, not the wrist: finger length no longer lifts the hand above the forehead.
     facePalm=Quaternion.Inverse(hand.rotation)*((index.position+middle.position)*.5f-hand.position)*.55f;
     faceOrient=true;
    }
   }
   var inverseHead=Quaternion.Inverse(head.rotation);
   faceHandRotation=inverseHead*desiredHand;
   faceForward=inverseHead*facing.forward;faceUp=inverseHead*facing.up;faceRight=inverseHead*facing.right;
   faceScale=animator.humanScale;if(float.IsNaN(faceScale)||float.IsInfinity(faceScale)||faceScale<=0)faceScale=1;
   profileReady=false;RefreshFacepalm();return true;
  }
  private void RefreshFacepalm()
  {
   var helmet=(UnityEngine.Object)owner.HeadAsSpaceHelmet;
   var filter=owner.HelmetShadowMesh;var mesh=filter!=null?filter.sharedMesh:null;
   if(profileReady&&helmet==faceHelmet&&mesh==faceMesh)return;
   bool worn=helmet!=null;float front=float.NaN;
   if(worn&&mesh!=null&&filter!=null)
   {
    var bounds=mesh.bounds;var forward=faceHead.rotation*faceForward;float maximum=float.NegativeInfinity;
    for(int i=0;i<8;i++)
    {
     var point=bounds.center+new Vector3((i&1)==0?-bounds.extents.x:bounds.extents.x,(i&2)==0?-bounds.extents.y:bounds.extents.y,(i&4)==0?-bounds.extents.z:bounds.extents.z);
     maximum=Mathf.Max(maximum,Vector3.Dot(filter.transform.TransformPoint(point)-faceHead.position,forward));
    }
    front=maximum/faceScale;
   }
   float distance=FacepalmLayout.Forward(worn,front)*faceScale;
   float height=(faceOrient?FacepalmLayout.PalmHeight(worn):FacepalmLayout.WristHeight(worn))*faceScale;
   // Rotation-relative world distances, not scaled Transform-local positions.
   var offset=faceForward*distance+faceUp*height+faceRight*(.02f*faceScale)-faceHandRotation*facePalm;
   pose.SetFacepalm(offset,faceHandRotation,faceOrient);
   faceHelmet=helmet;faceMesh=mesh;profileReady=true;
   Plugin.Log.LogInfo("Facepalm profile: helmet="+worn+", palm alignment="+faceOrient+", forward="+distance.ToString("F3")+", height="+height.ToString("F3"));
  }
  private void Update()
  {
   if(!Active)return;
   if(owner==null||owner.IsBeingDestroyed||owner.State!=EntityState.Alive||GameManager.GameState!=GameState.Running){Stop();return;}
   if(HeldEmote.MovingLocally(owner)||owner.LeftHandSlot?.Get()!=null||owner.RightHandSlot?.Get()!=null||(owner.transform.position-origin).sqrMagnitude>.01f){Stop(true);return;}
   if(Index==Plugin.Facepalm){if(faceHead==null){Stop(true);return;}RefreshFacepalm();}
   float t=Time.unscaledTime-started,blend=Mathf.SmoothStep(0,1,Mathf.Clamp01(t/.55f));
   float angle=Index==Plugin.Facepalm?9f:GesturePolicy.Sample(t)*(Index==Plugin.Disagree?18f:13f);
   pose.Set(0,Quaternion.AngleAxis(angle,axis)*rest,blend);
   if(!pose.Submit(owner,false))Stop(true);
  }
  internal void Stop(bool notify=false)
  {
   bool send=Active&&notify&&owner!=null&&owner==InventoryManager.ParentHuman&&GameManager.GameState==GameState.Running;
   var emotes=owner?.EmoteController;Active=false;Index=0;pose?.Dispose();pose=null;owner=null;faceHead=null;faceHelmet=null;faceMesh=null;profileReady=false;
   if(send&&emotes!=null)try{emotes.OnEmote(new EmoteData(Plugin.Cancel,0,EmoteType.Body));}catch(Exception e){Plugin.Log.LogWarning("Gesture cancel relay failed: "+e);}
  }
  private void OnDisable(){Stop();}private void OnDestroy(){Stop();}
 }
}
