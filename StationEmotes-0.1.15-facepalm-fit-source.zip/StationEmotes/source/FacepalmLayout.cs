using System;
namespace StationEmotes
{
 internal static class FacepalmLayout
 {
  // Distances are normalized by the humanoid scale. A helmet keeps the glove
  // outside its front-most mesh corner, with a conservative fallback profile.
  internal static float Forward(bool helmet,float measuredFront)
  {
   if(!helmet)return .135f;
   if(float.IsNaN(measuredFront)||float.IsInfinity(measuredFront)||measuredFront<.06f||measuredFront>.38f)return .23f;
   return Math.Max(.225f,measuredFront+.045f);
  }
  internal static float PalmHeight(bool helmet)=>helmet?.070f:.055f;
  internal static float WristHeight(bool helmet)=>helmet?-.005f:-.025f;
 }
}
