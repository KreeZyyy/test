using System;using System.Collections.Generic;using StationEmotes;using UnityEngine;
class Check{
 static int n;static void A(bool b,string m){n++;if(!b)throw new Exception(m);}
 static void Main(){
 float y;var a=new Vector3(-.2f,1,.15f);var b=new Vector3(.2f,1,.15f);var c=new Vector3(0,1,.3f);
 A(SeatContactMath.Surface(a,b,c,new Vector3(0,0,.2f),0,2,out y)&&Math.Abs(y-1)<.00001,"rim triangle missed");
 A(SeatContactMath.Surface(c,b,a,new Vector3(0,0,.2f),0,2,out y),"mirrored winding rejected");
 A(!SeatContactMath.Surface(a,b,c,new Vector3(0,0,0),0,2,out y),"opening filled by triangle bounding box");
 A(!SeatContactMath.Surface(a,b,c,new Vector3(1,0,.2f),0,2,out y),"outside triangle accepted");
 A(!SeatContactMath.Surface(a,b,c,new Vector3(0,0,.2f),1.1f,2,out y),"surface outside bowl height band accepted");
 A(!SeatContactMath.Surface(new Vector3(0,0,0),new Vector3(0,1,0),new Vector3(0,0,1),new Vector3(),-1,2,out y),"vertical wall treated as seat");
 A(!SeatContactMath.Surface(a,a,a,a,0,2,out y),"degenerate face accepted");
 A(SeatContactMath.Surface(new Vector3(-1,1,0),new Vector3(1,1,0),new Vector3(0,2,1),new Vector3(0,0,.5f),0,3,out y)&&Math.Abs(y-1.5f)<.0001,"sloped surface interpolation");
 A(SeatContactMath.Posterior(new Vector3(.07f,-.06f,-.04f),Vector3.right,Vector3.forward,1),"posterior pelvic crop excluded");
 A(!SeatContactMath.Posterior(new Vector3(.07f,-.25f,-.04f),Vector3.right,Vector3.forward,1),"lower leg entered pelvic crop");
 A(!SeatContactMath.Posterior(new Vector3(.07f,-.06f,.2f),Vector3.right,Vector3.forward,1),"front body entered posterior crop");
 A(!SeatContactMath.Posterior(new Vector3(.3f,-.06f,-.04f),Vector3.right,Vector3.forward,1),"far arm entered pelvic crop");
 var points=new List<Vector3>();for(int i=19;i>=0;i--)points.Add(new Vector3(0,i*.1f,0));
 float minimum;var bottom=SeatContactMath.Bottom(points,out minimum);A(minimum==0&&Math.Abs(bottom.y-.1f)<.0001,"lower patch statistic unstable");
 A(SeatContactMath.Bottom(new List<Vector3>(),out minimum).sqrMagnitude==0&&float.IsNaN(minimum),"missing body sample invented contact");
 float delta;
 A(SeatContactMath.SupportCorrection(true,true,true,.52f,.51f,.5f,.5f,out delta)&&Math.Abs(delta-.015f)<.0001,"two-sided correction value");
 A(!SeatContactMath.SupportCorrection(false,true,true,.52f,.51f,.5f,.5f,out delta),"missing support inferred correction");
 A(!SeatContactMath.SupportCorrection(true,true,false,.52f,.51f,.5f,.5f,out delta),"unweighted crop treated as precise anatomy");
 A(!SeatContactMath.SupportCorrection(true,true,true,.6f,.5f,.5f,.5f,out delta),"asymmetric supports forced same correction");
 A(!SeatContactMath.SupportCorrection(true,true,true,.9f,.9f,.5f,.5f,out delta),"large correction inferred");
 A(!SeatContactMath.SupportCorrection(true,true,true,float.NaN,.51f,.5f,.5f,out delta),"invalid surface inferred correction");
 Console.WriteLine(n+" production geometry sampling/contact-confidence checks passed (synthetic geometry/math stubs).");
 }}
namespace UnityEngine{public static class Mathf{public static float Abs(float n)=>Math.Abs(n);}}
