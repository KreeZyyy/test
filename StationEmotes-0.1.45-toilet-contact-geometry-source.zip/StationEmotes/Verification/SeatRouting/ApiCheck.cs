using System;
using System.IO;
using System.Reflection;
using System.Runtime.Loader;
using System.Linq;
class ApiCheck
{
 static int count;static void A(bool b,string m){count++;if(!b)throw new Exception(m);}
 static void Main()
 {
  var managed="/workspace/work/build-deps/Stationeers/rocketstation_Data/Managed";
  AssemblyLoadContext.Default.Resolving+=(context,name)=>{
   foreach(var dir in new[]{managed,"/tmp/emote-deps","/workspace/work/build-deps/Stationeers/BepInEx/core","/tmp/station-emotes-0145/StationEmotes/Assemblies"})
   {var p=Path.Combine(dir,name.Name+".dll");if(File.Exists(p))return context.LoadFromAssemblyPath(p);}return null;};
  var game=Assembly.LoadFrom(Path.Combine(managed,"Assembly-CSharp.dll"));
  foreach(var pair in new[]{
   ("Assets.Scripts.Objects.Thing","Awake"),
   ("Assets.Scripts.Objects.Thing","InteractWith"),
   ("Assets.Scripts.Objects.Structures.Seat","InteractWith"),
   ("Assets.Scripts.Objects.Structures.Seat","GetExitPosition"),
   ("Assets.Scripts.Objects.Structures.Seat","Exit"),
   ("Assets.Scripts.Objects.Electrical.AtmosphericSeat","GetExitPosition"),
   ("Assets.Scripts.Objects.Electrical.AtmosphericSeat","Exit"),
   ("Objects.Rockets.CrewModuleChair","InteractWith"),
   ("Objects.Rockets.CrewModuleChair","GetExitPosition"),
   ("Objects.Structures.StructureToilet","InteractWith"),
   ("Assets.Scripts.Objects.Entities.Human","ExitAnything"),
   ("Assets.Scripts.Objects.Entities.Human","SeatedInFreeLook")})
  {var t=game.GetType(pair.Item1,true);A(t.GetMethods(BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.Instance).Any(m=>m.Name==pair.Item2),pair.Item1+"."+pair.Item2);}
  var thing=game.GetType("Assets.Scripts.Objects.Thing",true);
  A(thing.GetMethods().Any(m=>m.Name=="GetInteractable"&&m.GetParameters().Length==1&&m.GetParameters()[0].ParameterType.FullName=="UnityEngine.Collider"),"cursor GetInteractable(Collider) missing");
  A(game.GetType("Assets.Scripts.Objects.Interaction").GetProperty("AltKey")!=null,"native quantity modifier missing");
  A(game.GetType("Assets.Scripts.CursorManager").GetProperty("CursorHit")!=null,"native cursor hit missing");
  A(game.GetType("Assets.Scripts.Objects.Interactable").GetMethod("Initialize")!=null,"native action-slot initialization missing");
  foreach(var name in new[]{"_slotLookup","_interactableLookup","_interactableColliderLookup"})
  {
   var f=thing.GetField(name,BindingFlags.Instance|BindingFlags.NonPublic);
   A(f!=null,name);A(typeof(System.Collections.IDictionary).IsAssignableFrom(f.FieldType),name+" dictionary");
  }
  A(game.GetType("Objects.Rockets.CrewModuleChair").GetField("_exitTransform",BindingFlags.Instance|BindingFlags.NonPublic)!=null,"rocket exit transform");
  var mod=Assembly.LoadFrom("/tmp/station-emotes-0145/StationEmotes/Assemblies/StationEmotes.dll");
  var prefix=mod.GetType("StationEmotes.ToiletSeatPreparationPatch",true).GetMethod("Prefix",BindingFlags.Static|BindingFlags.NonPublic);
  var priority=prefix.GetCustomAttributesData().Single(a=>a.AttributeType.FullName=="HarmonyLib.HarmonyPriority");
  var harmony=Assembly.LoadFrom("/workspace/work/build-deps/Stationeers/BepInEx/core/0Harmony.dll");
  var expected=harmony.GetType("HarmonyLib.Priority",true).GetField("First").GetRawConstantValue();
  A(Convert.ToInt32(priority.ConstructorArguments[0].Value)==Convert.ToInt32(expected),"toilet alignment does not run before source snapshot/native entry");
  var restOrder=mod.GetType("StationEmotes.ToiletRestPose",true).GetCustomAttributesData().Single(a=>a.AttributeType.FullName=="UnityEngine.DefaultExecutionOrder");
  var transitionOrder=mod.GetType("StationEmotes.ChairTransition",true).GetCustomAttributesData().Single(a=>a.AttributeType.FullName=="UnityEngine.DefaultExecutionOrder");
  A(Convert.ToInt32(restOrder.ConstructorArguments[0].Value)>Convert.ToInt32(transitionOrder.ConstructorArguments[0].Value),"rest pose must run after entry transition");
  A(mod.GetType("StationEmotes.SeatSurfaceInteractionPatch")==null,"removed seat surface interaction returned");
  Console.WriteLine(count+" real-game API metadata checks passed (reflection only; no Unity runtime).");
 }
}
