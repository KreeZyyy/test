namespace StationEmotes{
 internal static class ToiletRelaxPolicy
 {
  internal static float LegContact(float body,float release)=>(1-ChairTransitionPolicy.Ease(body))*ChairFootContact.LegWeight(release);
 }
}