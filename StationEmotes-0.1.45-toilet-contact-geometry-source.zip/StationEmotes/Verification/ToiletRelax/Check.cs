using System;using StationEmotes;
class Check{
 static int n;static void A(bool b,string m){n++;if(!b)throw new Exception(m);}
 static void Main(){
 float previous=1;
 foreach(float body in new[]{0f,.1f,.25f,.5f,.75f,.9f,1f}){
 float weight=ToiletRelaxPolicy.LegContact(body,0);
 A(weight>=0&&weight<=1&&weight<=previous,"toilet leg control is not a smooth release");previous=weight;
 A(ToiletRelaxPolicy.LegContact(body,1)==0,"completed sitting still pins legs to ground");
 }
 A(ToiletRelaxPolicy.LegContact(0,0)==1,"approach lost standing contact");
 A(ToiletRelaxPolicy.LegContact(1,0)==0,"seated toilet legs still pinned before handover");
 A(Math.Abs(ToiletRelaxPolicy.LegContact(.5f,0)-.5f)<.0001f,"mid-sit release discontinuity");
 Console.WriteLine(n+" production relaxed-toilet contact-release checks passed.");}}
namespace UnityEngine{public static class Mathf{public static float Clamp(float x,float a,float b)=>Math.Max(a,Math.Min(b,x));}public struct Vector3{public static Vector3 operator +(Vector3 a,Vector3 b)=>a;public static Vector3 operator *(Quaternion q,Vector3 v)=>v;}public struct Quaternion{public static Quaternion operator *(Quaternion a,Quaternion b)=>a;public static Quaternion Slerp(Quaternion a,Quaternion b,float t)=>a;}}
