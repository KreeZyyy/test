Historical 0.1.43 forced-ground policy fixture. That policy was explicitly removed in 0.1.44 and this fixture is not current-release validation. See Verification/RESULTS.txt and ToiletRelax.
