using System;
using Assets.Scripts;
using Assets.Scripts.Inventory;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Networking;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Entities;
using Assets.Scripts.UI;
using ImGuiNET;
using Objects.Structures;
using UnityEngine;
namespace StationEmotes
{
 internal static class ToiletUseHud
 {
  private static Human owner;private static StructureToilet toilet;private static Interactable control;
  private static bool visible,available,pending;private static float started,duration,messageUntil;private static string message="";
  internal static void Clear(){owner=null;toilet=null;control=null;visible=available=pending=false;message="";}
  private static bool InputAllowed()=>Application.isFocused&&!WorldManager.IsGamePaused&&InventoryManager.AllowMouseControl&&!Cursor.visible&&!InputWindowBase.IsInputWindow&&!ConsoleWindow.IsOpen&&!InputControlBase.IsRecording&&!ImGuiLoadingScreen.IsShowing&&!EmoteWheel.Open;
  private static bool Context(Human human,out StructureToilet target)
  {
   target=human?.ParentSlot?.Parent as StructureToilet;if(target==null||human.State!=EntityState.Alive||human.ParentSlot!=ToiletSeating.Slot(target))return false;
   var state=target.GetComponent<ToiletOccupancy>();
   return state!=null&&state.Occupant==human&&ToiletUsePolicy.Ready(true,human.GetComponent<ChairTransition>()?.Active==true,Time.time,state.ReadyAt);
  }
  private static Thing.DelayedActionInstance Preview(Human human,StructureToilet target,Interactable action,out Interaction interaction)
  {
   interaction=new Interaction(human,InventoryManager.ActiveHandSlot,target,false);
   if(InventoryManager.ActiveHandSlot==null)return null;
   if(target.PreventInteraction(out var failure,action,interaction))return failure;
   return target.InteractWith(action,interaction,false);
  }
  private static string Plain(string text)
  {
   if(string.IsNullOrWhiteSpace(text))return "";
   var result=new System.Text.StringBuilder();bool tag=false;
   foreach(char c in text){if(c=='<'){tag=true;continue;}if(c=='>'){tag=false;continue;}if(!tag&&c!='\r')result.Append(c);}
   var value=result.ToString().Trim();return value;
  }
  private static void Explain(Thing.DelayedActionInstance preview)
  {
   message=Plain((preview?.ExtendedMessage??"")+"\n"+(preview?.GetStateMessage()??""));
   if(message.Length==0)message="The toilet cannot be used right now.";
   messageUntil=Time.time+4;
  }
  internal static void Tick(Human human)
  {
   if(GameManager.IsBatchMode||GameManager.GameState!=GameState.Running||!InputAllowed()||!Context(human,out var target)){Clear();return;}
   if(owner!=human||toilet!=target){Clear();owner=human;toilet=target;}
   control=target.Interactables.Find(c=>c.Action==InteractableType.Activate);
   if(control==null){Clear();return;}
   visible=true;
   var preview=Preview(human,target,control,out var interaction);available=preview!=null&&!preview.IsDisabled;
   if(!available){pending=false;if(Input.GetKeyDown(KeyCode.K))Explain(preview);return;}
   if(pending)
   {
    if(Time.time-started<duration)return;
    pending=false;
    // Both local and authoritative handlers revalidate suit/water/sanitation/seat state at completion.
    if(GameManager.RunSimulation)OnServer.InteractWith(control,interaction);
    else NetworkClient.InteractWith(control,interaction);
    return;
   }
   if(Input.GetKeyDown(KeyCode.K))
   {
    duration=Mathf.Clamp(preview.Duration,0,5);started=Time.time;pending=true;
   }
  }
  private static uint Colour(float r,float g,float b,float a=1)=>ImGui.GetColorU32(new Vector4(r,g,b,a));
  internal static void Draw()
  {
   if(!visible||GameManager.IsBatchMode||GameManager.GameState!=GameState.Running||ImGui.GetCurrentContext()==IntPtr.Zero)return;
   float s=Mathf.Clamp(Screen.height/1080f,.7f,1.8f);
   var c=new Vector2(Screen.width-42*s,152*s);var top=new Vector2(Mathf.Max(0,Screen.width-760*s),78*s);
   ImGui.SetNextWindowPos(top,ImGuiCond.Always);ImGui.SetNextWindowSize(new Vector2(Mathf.Min(750*s,Screen.width),Mathf.Min(320*s,Screen.height-78*s)),ImGuiCond.Always);
   bool show=ImGui.Begin("##StationEmotesToiletUse",ImGuiWindowFlags.NoDecoration|ImGuiWindowFlags.NoBackground|ImGuiWindowFlags.NoSavedSettings|ImGuiWindowFlags.NoInputs|ImGuiWindowFlags.NoFocusOnAppearing);
   try
   {
    if(!show)return;var d=ImGui.GetWindowDrawList();
    d.AddCircleFilled(c,21*s,available?Colour(.12f,.47f,.78f,.95f):Colour(.24f,.29f,.34f,.9f),40);
    d.AddCircle(c,21*s,Colour(.65f,.83f,.96f,.7f),40,1*s);
    uint white=available?Colour(.96f,.98f,1):Colour(.6f,.65f,.69f);
    // Compact waste pictogram, drawn as a white three-tier silhouette like the native action badges.
    d.AddRectFilled(c+new Vector2(-11,5)*s,c+new Vector2(11,11)*s,white,3*s);
    d.AddRectFilled(c+new Vector2(-8,-2)*s,c+new Vector2(9,6)*s,white,4*s);
    d.AddRectFilled(c+new Vector2(-4,-8)*s,c+new Vector2(6,0)*s,white,4*s);
    d.AddCircleFilled(c+new Vector2(3,-10)*s,4*s,white,20);
    d.AddLine(c+new Vector2(4,-12)*s,c+new Vector2(1,-16)*s,white,3*s);
    d.AddText(c+new Vector2(-39,-8)*s,Colour(.94f,.96f,.98f),"K");
    if(pending)
    {
     float p=duration<=0?1:Mathf.Clamp01((Time.time-started)/duration);
     d.AddRectFilled(c+new Vector2(-19,25)*s,c+new Vector2(19,29)*s,Colour(.08f,.13f,.18f),2*s);
     d.AddRectFilled(c+new Vector2(-19,25)*s,c+new Vector2(-19+38*p,29)*s,Colour(.35f,.85f,.95f),2*s);
    }
    if(Time.time<messageUntil&&message.Length>0)
    {
     float width=Mathf.Min(570*s,Screen.width-110*s);
     var text=ToiletHudText.Wrap(message,width,value=>ImGui.CalcTextSize(value).x);
     var size=ImGui.CalcTextSize(text);var p=new Vector2(Screen.width-85*s-size.x,132*s);
     d.AddRectFilled(p-new Vector2(8,5)*s,p+size+new Vector2(8,5)*s,Colour(.04f,.055f,.07f,.88f),5*s);
     d.AddText(p,Colour(1,.82f,.51f),text);
    }
   }
   finally{ImGui.End();}
  }
 }
}
