using System;
using System.Collections.Generic;
namespace StationEmotes
{
 internal static class ToiletHudText
 {
  internal static string Wrap(string text,float width,Func<string,float> measure)
  {
   if(string.IsNullOrEmpty(text))return "";
   width=Math.Max(1,width);var lines=new List<string>();
   foreach(var paragraph in text.Replace("\r","").Split('\n'))
   {
    string line="";
    foreach(var word in paragraph.Split(new[]{' '},StringSplitOptions.RemoveEmptyEntries))
    {
     var candidate=line.Length==0?word:line+" "+word;
     if(measure(candidate)<=width){line=candidate;continue;}
     if(line.Length>0){lines.Add(line);line="";}
     string remaining=word;
     while(measure(remaining)>width&&remaining.Length>1)
     {
      int count=1;while(count<remaining.Length&&measure(remaining.Substring(0,count+1))<=width)count++;
      lines.Add(remaining.Substring(0,count));remaining=remaining.Substring(count);
     }
     line=remaining;
    }
    lines.Add(line);
   }
   return string.Join("\n",lines);
  }
 }
}
