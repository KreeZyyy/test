using System;
using System.Collections.Generic;
using UnityEngine;
namespace StationEmotes
{
 internal static class SeatContactMath
 {
  internal static bool Surface(Vector3 a,Vector3 b,Vector3 c,Vector3 query,float minY,float maxY,out float height)
  {
   height=0;var normal=Vector3.Cross(b-a,c-a);
   if(normal.sqrMagnitude<.000000000001f||Mathf.Abs(normal.normalized.y)<.65f)return false;
   float det=(b.z-c.z)*(a.x-c.x)+(c.x-b.x)*(a.z-c.z);
   if(Mathf.Abs(det)<.000000001f)return false;
   float wa=((b.z-c.z)*(query.x-c.x)+(c.x-b.x)*(query.z-c.z))/det;
   float wb=((c.z-a.z)*(query.x-c.x)+(a.x-c.x)*(query.z-c.z))/det;
   float wc=1-wa-wb;
   if(wa<-.0001f||wb<-.0001f||wc<-.0001f)return false;
   height=wa*a.y+wb*b.y+wc*c.y;
   return !float.IsNaN(height)&&!float.IsInfinity(height)&&height>=minY&&height<=maxY;
  }
  internal static bool Posterior(Vector3 delta,Vector3 right,Vector3 forward,float scale)
   =>Mathf.Abs(Vector3.Dot(delta,right))<=.17f*scale&&Vector3.Dot(delta,forward)>=-.16f*scale&&Vector3.Dot(delta,forward)<=.035f*scale&&delta.y>=-.16f*scale&&delta.y<=.025f*scale;
  internal static Vector3 Bottom(List<Vector3> points,out float minimum)
  {
   minimum=float.NaN;if(points.Count==0)return Vector3.zero;
   points.Sort((a,b)=>a.y.CompareTo(b.y));minimum=points[0].y;
   int count=Math.Max(1,(int)Math.Ceiling(points.Count*.15));var total=Vector3.zero;
   for(int i=0;i<count;i++)total+=points[i];
   return total/count;
  }
  internal static bool SupportCorrection(bool left,bool right,bool weighted,float ly,float ry,float lbody,float rbody,out float delta)
  {
   delta=0;if(!left||!right||!weighted)return false;
   float l=ly-lbody,r=ry-rbody;
   if(float.IsNaN(l)||float.IsNaN(r)||Mathf.Abs(l-r)>.025f||Mathf.Abs(l)>.2f||Mathf.Abs(r)>.2f)return false;
   delta=(l+r)*.5f;return true;
  }
 }
}
