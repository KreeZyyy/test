using Assets.Scripts;
using Assets.Scripts.Objects.Entities;
using Objects.Structures;
using UnityEngine;
namespace StationEmotes
{
 // Toilet-only relaxed pose. Legs retain the native seated bend; no floor IK or pelvis lowering.
 [DefaultExecutionOrder(33000)]
 internal sealed class ToiletRestPose:MonoBehaviour
 {
  private Human human;private Animator animator;private ChairStandingPose reference;private ChairLocalPose locals;private ChairTorsoStream torso,toePose;
  private readonly Transform[] bones=new Transform[16],toes=new Transform[2];private bool captured;private float blendTime;
  private static readonly HumanBodyBones[] ids={HumanBodyBones.Hips,HumanBodyBones.Spine,HumanBodyBones.Chest,HumanBodyBones.Head,
   HumanBodyBones.LeftUpperArm,HumanBodyBones.LeftLowerArm,HumanBodyBones.LeftHand,HumanBodyBones.RightUpperArm,HumanBodyBones.RightLowerArm,HumanBodyBones.RightHand,
   HumanBodyBones.LeftUpperLeg,HumanBodyBones.LeftLowerLeg,HumanBodyBones.LeftFoot,HumanBodyBones.RightUpperLeg,HumanBodyBones.RightLowerLeg,HumanBodyBones.RightFoot};
  internal static void Begin(Human h)
  {
   if(GameManager.IsBatchMode||h==null||h.EmoteController==null)return;
   var p=h.GetComponent<ToiletRestPose>()??h.gameObject.AddComponent<ToiletRestPose>();
   p.human=h;p.animator=Plugin.BodyAnimator.GetValue(h.EmoteController) as Animator;
   if(p.animator==null||!p.animator.isHuman)return;
   for(int i=0;i<ids.Length;i++)p.bones[i]=p.animator.GetBoneTransform(ids[i]);
   for(int side=0;side<2;side++)p.toes[side]=ChairToeContact.Find(p.animator,p.bones[side==0?12:15],side==0);
  }
  internal static ChairNativePose Endpoint(ChairTransition.Snapshot s,ChairNativePose native,ChairTorsoStream nativeTorso,ChairLocalPose nativeLocals,ChairTorsoStream nativeToes)
  {
   Begin(s.Human);var p=s.Human.GetComponent<ToiletRestPose>();if(p==null)return native;
   p.reference=s.Standing;p.locals=nativeLocals;p.torso=nativeTorso;p.toePose=nativeToes;p.captured=true;p.blendTime=0;
   return native;
  }
  private void LateUpdate()
  {
   var t=human?.ParentSlot?.Parent as StructureToilet;
   if(human==null||t==null||human.ParentSlot!=ToiletSeating.Slot(t)){Destroy(this);return;}
   if(animator==null||human.State!=EntityState.Alive||human.GetComponent<ChairTransition>()?.Active==true)return;
   if(!captured)
   {
    reference=ChairStandingPose.Get(human);
    for(int i=0;i<bones.Length;i++)if(bones[i]!=null)locals.Set(i,bones[i].localRotation);
    if(reference!=null){torso.Count=reference.Torso.Length;for(int i=0;i<torso.Count;i++)torso.Set(i,new ChairTorsoSlot{Ready=true,NativeRotation=reference.Torso[i].localRotation});}
    toePose.Count=2;for(int i=0;i<2;i++)if(toes[i]!=null)toePose.Set(i,new ChairTorsoSlot{Ready=true,NativeRotation=toes[i].localRotation});
    captured=true;
   }
   blendTime+=Time.deltaTime;float blend=ChairTransitionPolicy.Ease(blendTime/.45f);
   // Reapply the actual seated leg locals; do not pin ankles, knees or hips to world-floor targets.
   for(int i=10;i<16;i++)if(bones[i]!=null)bones[i].localRotation=locals.Get(i);
   var facing=ChairSeatRouting.Facing(human.ParentSlot);var right=facing*Vector3.right;var forward=facing*Vector3.forward;
   for(int side=0;side<2;side++)
   {
    var foot=bones[side==0?12:15];if(foot!=null)foot.rotation=Quaternion.AngleAxis(8*blend,right)*foot.rotation;
    var toe=toePose.Get(side);if(toes[side]!=null&&toe.Ready)toes[side].localRotation=toe.NativeRotation;
   }
   if(reference!=null&&reference.Torso.Length>0&&bones[0]!=null&&bones[3]!=null)
   {
    for(int i=0;i<Mathf.Min(2,reference.Torso.Length);i++)if(torso.Get(i).Ready&&reference.Torso[i]!=null)reference.Torso[i].localRotation=torso.Get(i).NativeRotation;
    var spine=reference.Torso[0];var up=bones[3].position-bones[0].position;
    if(spine!=null&&up.sqrMagnitude>.000001f)spine.rotation=Quaternion.Slerp(Quaternion.identity,Quaternion.FromToRotation(up.normalized,Quaternion.AngleAxis(5,right)*Vector3.up),blend)*spine.rotation;
   }
   // Only empty hands rest on the thighs; held tools retain native hand/item IK.
   for(int side=0;side<2;side++)
   {
    if((side==0?human.LeftHandSlot:human.RightHandSlot)?.Get()!=null)continue;
    int arm=side==0?4:7,leg=side==0?10:13;
    if(bones[arm]==null||bones[arm+1]==null||bones[arm+2]==null||bones[leg]==null||bones[leg+1]==null)continue;
    var hand=bones[arm+2];var target=Vector3.Lerp(bones[leg].position,bones[leg+1].position,.55f)+Vector3.up*(animator.humanScale*.055f);
    Solve(bones[arm],bones[arm+1],hand,Vector3.Lerp(hand.position,target,blend),hand.rotation,right*(side==0?-1:1)-forward*.3f);
   }
  }
  private static void Solve(Transform upper,Transform lower,Transform hand,Vector3 target,Quaternion rotation,Vector3 poleAxis)
  {
   var a=upper.position;var b=lower.position;var c=hand.position;float u=(b-a).magnitude,l=(c-b).magnitude,d=(target-a).magnitude;
   if(u<.01f||l<.01f||d<.001f)return;
   var direction=(target-a)/d;var pole=Vector3.ProjectOnPlane(poleAxis,direction);if(pole.sqrMagnitude<.0001f)return;
   float axial,lateral;ChairStepPolicy.Knee(u,l,d,out axial,out lateral);
   var desired=a+direction*axial+pole.normalized*lateral;
   upper.rotation=Quaternion.FromToRotation(b-a,desired-a)*upper.rotation;
   lower.rotation=Quaternion.FromToRotation(hand.position-lower.position,target-lower.position)*lower.rotation;hand.rotation=rotation;
  }
 }
 internal static class ToiletRelaxPolicy
 {
  internal static float LegContact(float body,float release)=>(1-ChairTransitionPolicy.Ease(body))*ChairFootContact.LegWeight(release);
 }
}
