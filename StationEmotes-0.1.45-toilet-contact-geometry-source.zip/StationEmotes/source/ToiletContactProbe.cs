using System;
using System.Collections.Generic;
using Assets.Scripts;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Entities;
using Objects.Structures;
using UnityEngine;
namespace StationEmotes
{
 // On-demand geometry observation only. Never changes seating anchors, bones, meshes or colliders.
 [DefaultExecutionOrder(34000)]
 internal sealed class ToiletContactProbe:MonoBehaviour
 {
  private Human human;
  internal static void Request(Human h)
  {
   if(GameManager.IsBatchMode||h==null)return;
   (h.GetComponent<ToiletContactProbe>()??h.gameObject.AddComponent<ToiletContactProbe>()).human=h;
  }
  private void LateUpdate()
  {
   try{if(human!=null&&human.ParentSlot?.Parent is StructureToilet toilet)Measure(human,toilet);}
   catch(Exception e){Plugin.Log.LogWarning("TOILET CONTACT: measurement unavailable: "+e.Message);}
   finally{Destroy(this);}
  }
  private static float Weight(BoneWeight w,int bone)
   =>bone<0?0:(w.boneIndex0==bone?w.weight0:0)+(w.boneIndex1==bone?w.weight1:0)+(w.boneIndex2==bone?w.weight2:0)+(w.boneIndex3==bone?w.weight3:0);
  private static string Height(bool valid,float y)=>valid?y.ToString("F3"):"none";
  private static void Measure(Human h,StructureToilet toilet)
  {
   var animator=Plugin.BodyAnimator.GetValue(h.EmoteController) as Animator;if(animator==null||!animator.isHuman)return;
   var hips=animator.GetBoneTransform(HumanBodyBones.Hips);var head=animator.GetBoneTransform(HumanBodyBones.Head);if(hips==null||head==null)return;
   var facing=ChairSeatRouting.Facing(h.ParentSlot);var forward=facing*Vector3.forward;var right=facing*Vector3.right;
   var shoulderL=animator.GetBoneTransform(HumanBodyBones.LeftUpperArm);var shoulderR=animator.GetBoneTransform(HumanBodyBones.RightUpperArm);
   if(shoulderL!=null&&shoulderR!=null)
   {
    var actual=ChairBodyFacing.Forward(shoulderR.position-shoulderL.position,head.position-hips.position);
    if(actual.sqrMagnitude>.000001f){forward=actual.normalized;right=Vector3.Cross(Vector3.up,forward).normalized;}
   }
   var weighted=new[]{new List<Vector3>(),new List<Vector3>()};var crop=new[]{new List<Vector3>(),new List<Vector3>()};
   int baked=0,unreadableWeights=0;bool hiddenBody=false;float scale=Mathf.Clamp(animator.humanScale/.507f,.5f,2);
   var thighL=animator.GetBoneTransform(HumanBodyBones.LeftUpperLeg);var thighR=animator.GetBoneTransform(HumanBodyBones.RightUpperLeg);
   foreach(var renderer in h.GetComponentsInChildren<SkinnedMeshRenderer>(true))
   {
    if(renderer.sharedMesh==null||!renderer.gameObject.activeInHierarchy||renderer.name.IndexOf("shadow",StringComparison.OrdinalIgnoreCase)>=0)continue;
    var joints=renderer.bones;int hip=Array.IndexOf(joints,hips);if(hip<0)continue;
    var mesh=new Mesh();
    try
    {
     renderer.BakeMesh(mesh,false);var vertices=mesh.vertices;
     BoneWeight[] weights=null;
     if(renderer.sharedMesh.isReadable)try{weights=renderer.sharedMesh.boneWeights;}catch{}
     bool canWeight=weights!=null&&weights.Length==vertices.Length;
     int left=Array.IndexOf(joints,thighL),other=Array.IndexOf(joints,thighR),accepted=0;
     for(int i=0;i<vertices.Length;i++)
     {
      var point=renderer.transform.TransformPoint(vertices[i]);var delta=point-hips.position;
      if(!SeatContactMath.Posterior(delta,right,forward,scale))continue;
      int side=Vector3.Dot(delta,right)<=0?0:1;crop[side].Add(point);accepted++;
      if(canWeight&&Weight(weights[i],hip)>=.35f&&Weight(weights[i],hip)>=Weight(weights[i],left)+Weight(weights[i],other))weighted[side].Add(point);
     }
     if(!canWeight&&accepted>0)unreadableWeights++;
     if(!renderer.enabled&&accepted>0)hiddenBody=true;
     baked++;Plugin.Log.LogInfo("TOILET MESH: body="+renderer.name+", enabled="+renderer.enabled+", vertices="+vertices.Length+", pelvic crop="+accepted+", readable weights="+canWeight);
    }
    catch(Exception e){Plugin.Log.LogWarning("TOILET MESH: body="+renderer.name+", unavailable="+e.Message);}
    finally{Destroy(mesh);}
   }
   bool trusted=weighted[0].Count>=8&&weighted[1].Count>=8&&unreadableWeights==0&&!hiddenBody;
   var selected=trusted?weighted:crop;
   if(selected[0].Count<3||selected[1].Count<3)
   {Plugin.Log.LogWarning("TOILET CONTACT: insufficient posterior pelvis vertices; baked="+baked+", unreadable weights="+unreadableWeights);return;}
   float minL,minR;var contactL=SeatContactMath.Bottom(selected[0],out minL);var contactR=SeatContactMath.Bottom(selected[1],out minR);
   var bowl=toilet.Interactables.Find(c=>c.Action==InteractableType.Activate)?.Collider;
   if(bowl==null){Plugin.Log.LogWarning("TOILET CONTACT: original bowl collider unavailable.");return;}
   var bounds=bowl.bounds;var centre=bounds.center;var seatForward=facing*Vector3.forward;var seatRight=facing*Vector3.right;
   float depth=Mathf.Abs(seatForward.x)*bounds.extents.x+Mathf.Abs(seatForward.z)*bounds.extents.z;
   float width=Mathf.Abs(seatRight.x)*bounds.extents.x+Mathf.Abs(seatRight.z)*bounds.extents.z;
   var queries=new List<Vector3>{contactL,contactR};
   foreach(float z in new[]{.45f,.65f,.85f,.98f,1.08f})foreach(float x in new[]{-.6f,0,.6f})
    queries.Add(centre+seatForward*(depth*z)+seatRight*(width*x));
   var visual=new float[queries.Count];var hasVisual=new bool[queries.Count];var physical=new float[queries.Count];var hasPhysical=new bool[queries.Count];
   int meshes=0,unreadableMeshes=0,triangles=0;
   float low=bounds.min.y-.03f,high=bounds.max.y+.03f;
   foreach(var filter in toilet.GetComponentsInChildren<MeshFilter>(true))
   {
    var renderer=filter.GetComponent<Renderer>();var mesh=filter.sharedMesh;
    if(mesh==null||renderer==null||!filter.gameObject.activeInHierarchy||filter.GetComponentInParent<Thing>()!=toilet)continue;
    Plugin.Log.LogInfo("TOILET MESH: fixture="+mesh.name+", readable="+mesh.isReadable+", enabled="+renderer.enabled);
    if(!mesh.isReadable){unreadableMeshes++;continue;}
    try
    {
     var vertices=mesh.vertices;var indices=mesh.triangles;for(int i=0;i<vertices.Length;i++)vertices[i]=filter.transform.TransformPoint(vertices[i]);
     if(triangles+indices.Length/3>200000){Plugin.Log.LogWarning("TOILET CONTACT: triangle budget reached; geometry coverage incomplete.");unreadableMeshes++;break;}
     triangles+=indices.Length/3;meshes++;
     for(int i=0;i+2<indices.Length;i+=3)for(int q=0;q<queries.Count;q++)
     {
      float y;if(!SeatContactMath.Surface(vertices[indices[i]],vertices[indices[i+1]],vertices[indices[i+2]],queries[q],low,high,out y))continue;
      if(!hasVisual[q]||y>visual[q]){hasVisual[q]=true;visual[q]=y;}
     }
    }
    catch(Exception e){unreadableMeshes++;Plugin.Log.LogWarning("TOILET MESH: "+mesh.name+", unavailable="+e.Message);}
   }
   foreach(var collider in toilet.GetComponentsInChildren<MeshCollider>(true))
   {
    if(collider.isTrigger||!collider.enabled||!collider.gameObject.activeInHierarchy)continue;
    for(int q=0;q<queries.Count;q++)
    {
     var origin=queries[q];origin.y=high+.4f;RaycastHit hit;
     if(!collider.Raycast(new Ray(origin,Vector3.down),out hit,high-low+.8f)||hit.normal.y<.65f||hit.point.y<low||hit.point.y>high)continue;
     if(!hasPhysical[q]||hit.point.y>physical[q]){hasPhysical[q]=true;physical[q]=hit.point.y;}
    }
   }
   var transition=h.GetComponent<ChairTransition>();string pose=transition?.Active==true?transition.Description:"rest";
   Plugin.Log.LogInfo("TOILET CONTACT: pose="+pose+", body="+(trusted?"weighted posterior pelvis":"geometric crop estimate")+", samples="+selected[0].Count+"/"+selected[1].Count+", visual meshes="+meshes+", unreadable meshes="+unreadableMeshes+", hidden anatomy="+hiddenBody);
   Plugin.Log.LogInfo("TOILET CONTACT L: patch="+contactL.ToString("F3")+", minimumY="+minL.ToString("F3")+", visual supportY="+Height(hasVisual[0],visual[0])+", collision supportY="+Height(hasPhysical[0],physical[0]));
   Plugin.Log.LogInfo("TOILET CONTACT R: patch="+contactR.ToString("F3")+", minimumY="+minR.ToString("F3")+", visual supportY="+Height(hasVisual[1],visual[1])+", collision supportY="+Height(hasPhysical[1],physical[1]));
   var rim=new List<float>();for(int i=2;i<queries.Count;i++)if(hasVisual[i])rim.Add(visual[i]);rim.Sort();
   Plugin.Log.LogInfo("TOILET CONTACT: front rim samples="+rim.Count+", candidateY="+(rim.Count>=3?rim[rim.Count/2].ToString("F3"):"unavailable")+"; collider supports are approximate, not visual geometry.");
   float correction;
   if(SeatContactMath.SupportCorrection(hasVisual[0],hasVisual[1],trusted&&unreadableMeshes==0,visual[0],visual[1],contactL.y,contactR.y,out correction))
    Plugin.Log.LogInfo("TOILET CONTACT: candidate vertical correction="+correction.ToString("F3")+" m; OBSERVATION ONLY, no pose changes applied.");
   else Plugin.Log.LogWarning("TOILET CONTACT: no reliable two-sided visual contact; no correction inferred. A hole, lateral mismatch or unreadable mesh may prevent measurement.");
  }
 }
}
