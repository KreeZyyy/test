using System;
namespace StationEmotes
{
 internal static class ChairLayoutPolicy
 {
  internal static bool DoubleName(string name)
  {
   if(string.IsNullOrEmpty(name))return false;
   name=name.ToLowerInvariant();return name.Contains("double")||name.Contains("twoseat")||name.Contains("2seat");
  }
  internal static float HalfSpacing(float width)=>float.IsNaN(width)||float.IsInfinity(width)? .24f:Math.Max(.18f,Math.Min(.35f,width*.22f));
 }
}
