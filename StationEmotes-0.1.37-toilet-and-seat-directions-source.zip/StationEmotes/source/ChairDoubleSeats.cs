using System;
using System.Collections.Generic;
using Assets.Scripts;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Structures;
using UnityEngine;
namespace StationEmotes
{
 internal static class ChairDoubleSeats
 {
  private const string Marker="StationEmotesDoubleSeat";
  private static readonly HashSet<string> reported=new HashSet<string>();
  internal static void InstallLoaded()
  {
   foreach(var seat in Resources.FindObjectsOfTypeAll<Seat>())Ensure(seat,true);
   foreach(var thing in Resources.FindObjectsOfTypeAll<Thing>())
   {
    if(!ChairSeatRouting.Supported(thing)||thing.Slots==null)continue;
    var name=string.IsNullOrEmpty(thing.PrefabName)?thing.name:thing.PrefabName;if(!reported.Add(name))continue;
    var seats=thing.Slots.FindAll(ChairSeatRouting.Supported);
    Plugin.Log.LogInfo("Seat layout: "+name+", seats="+seats.Count);
    foreach(var slot in seats)Plugin.Log.LogInfo("Seat position "+slot.SlotIndex+": local="+slot.Location.localPosition.ToString("F3")+", yaw="+ChairSeatRouting.Facing(slot).eulerAngles.y.ToString("F1")+", front="+ChairSeatRouting.Front(slot).ToString("F3"));
   }
  }
  internal static void Ensure(Seat seat,bool initialized)
  {
   var name=string.IsNullOrEmpty(seat.PrefabName)?seat.name:seat.PrefabName;
   if(!ChairLayoutPolicy.DoubleName(name)||seat.Slots==null)return;
   var seats=seat.Slots.FindAll(s=>s.Type==Slot.Class.Entity&&s.EntityControlMode==MovementController.Mode.Seated&&s.Location!=null);
   // Native two-position prefabs keep both original anchors and interactables.
   if(seats.Count!=1||seat.Slots.Exists(s=>s.StringKey==Marker))return;
   var first=seats[0];if(first.Get()!=null)return;first.Parent=seat;first.Action=(InteractableType)Enum.Parse(typeof(InteractableType),"Slot"+(seat.Slots.IndexOf(first)+1));
   var existing=seat.Interactables.Find(i=>i.Action==first.Action);
   if(existing==null||existing.Collider==null)return;
   float width=0;
   foreach(var renderer in seat.GetComponentsInChildren<Renderer>())
   {
    var bounds=renderer.bounds;
    for(int i=0;i<8;i++)
    {
     var p=bounds.center+Vector3.Scale(bounds.extents,new Vector3((i&1)==0?-1:1,(i&2)==0?-1:1,(i&4)==0?-1:1));
     var local=first.Location.InverseTransformPoint(p);width=Mathf.Max(width,Mathf.Abs(local.x)*2);
    }
   }
   float spacing=ChairLayoutPolicy.HalfSpacing(width);
   var origin=first.Location.position;var orientation=first.Location.rotation;
   var left=new GameObject(Marker+"Left").transform;left.SetParent(seat.transform,false);left.SetPositionAndRotation(origin-orientation*Vector3.right*spacing,orientation);
   var right=new GameObject(Marker+"Right").transform;right.SetParent(seat.transform,false);right.SetPositionAndRotation(origin+orientation*Vector3.right*spacing,orientation);
   first.Location=left;
   var action=(InteractableType)Enum.Parse(typeof(InteractableType),"Slot"+(seat.Slots.Count+1));
   var colliderObject=new GameObject(Marker+"Control");colliderObject.layer=existing.Collider.gameObject.layer;colliderObject.transform.SetParent(right,false);colliderObject.transform.localPosition=new Vector3(0,.32f,.28f);
   var collider=colliderObject.AddComponent<BoxCollider>();collider.size=new Vector3(spacing*1.6f,.22f,.12f);collider.isTrigger=true;
   var leftControlObject=new GameObject(Marker+"LeftControl");leftControlObject.layer=existing.Collider.gameObject.layer;leftControlObject.transform.SetParent(left,false);leftControlObject.transform.localPosition=new Vector3(0,.32f,.28f);
   var leftCollider=leftControlObject.AddComponent<BoxCollider>();leftCollider.size=collider.size;leftCollider.isTrigger=true;
   first.Collider=leftCollider;existing.Collider=leftCollider;existing.Bounds=new Bounds(leftCollider.center,leftCollider.size);existing.OriginalBounds=existing.Bounds;
   var second=new Slot{Parent=seat,StringKey=Marker,StringHash=Animator.StringToHash(Marker),Type=Slot.Class.Entity,
    Location=right,EntityControlMode=MovementController.Mode.Seated,RealWorldScale=first.RealWorldScale,ScaleMultiplier=first.ScaleMultiplier,
    IsInteractable=true,IsSwappable=false,OccupantCastsShadows=first.OccupantCastsShadows,Action=action,Collider=collider};
   var control=new Interactable{Parent=seat,StringKey=Marker,StringHash=Animator.StringToHash(Marker),Action=action,Collider=collider,Bounds=new Bounds(collider.center,collider.size),OriginalBounds=new Bounds(collider.center,collider.size)};
   seat.Slots=new List<Slot>(seat.Slots);seat.Slots.Add(second);
   seat.Interactables=new List<Interactable>(seat.Interactables);seat.Interactables.Add(control);
   if(initialized)
   {
    second.Initialize();control.Initialize();
    ToiletSeating.Register(seat,"_slotLookup",leftCollider,first);
    ToiletSeating.Register(seat,"_interactableColliderLookup",leftCollider,existing);
    ToiletSeating.Register(seat,"_slotLookup",collider,second);
    ToiletSeating.Register(seat,"_interactableLookup",action,control);
    ToiletSeating.Register(seat,"_interactableColliderLookup",collider,control);
   }
   Plugin.Log.LogInfo("Double seat expanded: "+name+", left/right spacing="+spacing.ToString("F3"));
  }
 }
}
