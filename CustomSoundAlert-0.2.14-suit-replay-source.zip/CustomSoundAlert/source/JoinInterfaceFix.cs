using System;
using Assets.Scripts;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Networking;
using Assets.Scripts.UI;
using Cysharp.Threading.Tasks;
using HarmonyLib;
using UnityEngine.Rendering;
using UnityEngine;
namespace CustomSoundAlert
{
    // Draw inside the game's active Dear ImGui frame, before it is submitted.
    [HarmonyPatch(typeof(ImGuiManager),"RenderImGuiTo")]
    internal static class SoundTransferPanelHook
    {
        [HarmonyPrepare] static bool Prepare()=>!GameManager.IsBatchMode;
        static void Prefix(CommandBuffer cb,CommandBuffer ___commandBuffer)
        {
            if(ReferenceEquals(cb,___commandBuffer))SoundTransferNetwork.Draw();
        }
    }
    // The native join can hide MainMenuCanvas before VerifyPlayerRequest
    // creates a PasswordWindow below that canvas. Reveal only that existing UI.
    [HarmonyPatch(typeof(PasswordWindow),"PromptPassword")]
    internal static class JoinPasswordVisibility
    {
        static Action pendingReveal;
        static double revealAt;
        static int generation;
        internal static void Tick()
        {
            if(pendingReveal==null)return;
            if(!NetworkManager.IsClient||GameManager.GameState!=GameState.Joining)
            {pendingReveal=null;generation++;return;}
            if(Time.unscaledTime<revealAt)return;
            var reveal=pendingReveal;pendingReveal=null;reveal();
        }
        [HarmonyPrepare] static bool Prepare()=>!GameManager.IsBatchMode;
        static void Prefix(ref Action<string> onConfirm,ref Action onCancelled,out Action __state)
        {
            __state=null;
            if(GameManager.IsBatchMode||!NetworkManager.IsClient||GameManager.GameState!=GameState.Joining)return;
            var menu=MainMenu.Instance;
            var canvas=menu==null?null:menu.MainMenuCanvas;
            if(canvas==null||canvas.enabled&&!ImGuiLoadingScreen.IsShowing)return;
            int ticket=++generation;
            bool wasCanvas=canvas.enabled,wasLoading=ImGuiLoadingScreen.IsShowing;
            string loadingState=ImGuiLoadingScreen.State;float progress=ImGuiLoadingScreen.Progress;
            bool restored=false,completed=false;
            Action restore=()=>{
                if(restored||generation!=ticket)return;restored=true;pendingReveal=null;
                if(canvas!=null)canvas.enabled=wasCanvas;
                if(wasLoading&&NetworkManager.IsClient&&GameManager.GameState==GameState.Joining)
                {
                    ImGuiLoadingScreen.SetActive(true);
                    ImGuiLoadingScreen.SetState(loadingState??"Connecting to Server",false).Forget();
                    ImGuiLoadingScreen.Progress=progress;
                }
            };
            var confirm=onConfirm;var cancel=onCancelled;
            onConfirm=password=>{if(completed)return;completed=true;restore();SoundTransferNetwork.Trace("Join password submitted to native verification.");confirm?.Invoke(password);};
            onCancelled=()=>{if(completed)return;completed=true;restore();cancel?.Invoke();};
            __state=restore;
            revealAt=Time.unscaledTime+2d;
            pendingReveal=()=>{
                if(generation!=ticket||restored||canvas==null)return;
                canvas.enabled=true;if(wasLoading)ImGuiLoadingScreen.SetActive(false);
                SoundTransferNetwork.Trace("Join password prompt made visible after 2-second delay ("+NetworkClient.ConnectionMethod+"); waiting for native password confirmation.");
            };
            SoundTransferNetwork.Trace("Join password prompt scheduled after 2 seconds; loading remains unchanged while waiting.");
        }
        static Exception Finalizer(Exception __exception,Action __state)
        {
            if(__exception!=null)__state?.Invoke();return __exception;
        }
    }
}
