using System;
using System.Runtime.CompilerServices;
namespace CustomSoundAlert
{
    // A saved ID is state, not a new playback request. No Unity references here.
    internal static class SuitAlertPlayback
    {
        private sealed class Request {internal int Id;internal bool Requested,Pending;}
        private static readonly object gate=new object();
        private static ConditionalWeakTable<object,Request> requests=new ConditionalWeakTable<object,Request>();
        [ThreadStatic] private static int joinDepth,snapshotDepth;
        internal static void EnterJoin(){joinDepth++;}
        internal static void ExitJoin(){joinDepth--;}
        internal static void EnterSnapshot(){snapshotDepth++;}
        internal static void ExitSnapshot(){snapshotDepth--;}
        internal static void Reset(){lock(gate)requests=new ConditionalWeakTable<object,Request>();}
        internal static void RequestSound(object host,int previous,int id,bool running)
        {
            lock(gate)
            {
                // A join-triggered full snapshot must neither replay old audio
                // nor erase a genuine request still waiting for its download.
                if(joinDepth==0&&snapshotDepth>0&&previous==id&&
                    requests.TryGetValue(host,out var existing)&&existing.Id==id)return;
                requests.Remove(host);
                if(id<100||id>199)return;
                requests.Add(host,new Request{Id=id,Requested=running&&joinDepth==0&&!(snapshotDepth>0&&previous==id)});
            }
        }
        internal static bool ShouldPlay(object host,int id,bool available)
        {
            if(id<100||id>199)return true;
            lock(gate)
            {
                if(!requests.TryGetValue(host,out var request)||request.Id!=id||!request.Requested)return false;
                if(!available){request.Pending=true;return false;}
                request.Requested=false;request.Pending=false;return true;
            }
        }
        internal static bool Waiting(object host,int id)
        {
            lock(gate)return requests.TryGetValue(host,out var r)&&r.Id==id&&r.Requested&&r.Pending;
        }
    }
}
