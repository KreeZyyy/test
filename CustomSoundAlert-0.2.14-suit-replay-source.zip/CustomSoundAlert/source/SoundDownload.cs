using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Threading.Tasks;
namespace CustomSoundAlert
{
    internal sealed class SoundRequest {internal string Token;internal int Id;internal long Offset;}
    internal sealed class SoundResponse {internal string Token;internal int Id,Status;internal long Offset;internal byte[] Data=Array.Empty<byte>();}
    internal sealed class SoundDownload:IDisposable
    {
        internal const int ChunkSize=8192;
        internal const double Timeout=10;
        readonly string cache;
        readonly SoundEntry[] entries;
        readonly Action<SoundRequest> send;
        readonly Action<string> report;
        readonly HashSet<string> verified=new HashSet<string>();
        readonly Task<bool[]> checking;
        bool stopped,scanned;
        int index=-1,retries,failed,missing,completed;
        long offset;
        double sentAt,nextProgress;
        string token,temporary;
        FileStream output;
        SHA256 hash;
        internal bool Ready {get;private set;}
        internal int CatalogCount=>entries.Length;
        internal bool IsVerified(SoundEntry entry)=>verified.Contains(entry.Sha256+entry.Extension);
        internal SoundDownload(string folder,SoundEntry[] catalog,Action<SoundRequest> sender,Action<string> status)
        {
            ServerSoundCatalog.Validate(catalog);cache=folder;entries=(SoundEntry[])catalog.Clone();send=sender;report=status;
            Directory.CreateDirectory(cache);
            report("Checking server sounds: "+entries.Length+" entries...");
            checking=Task.Run(()=>{
                var result=new bool[entries.Length];
                for(int i=0;i<entries.Length;i++)try{result[i]=ServerSoundCatalog.Cached(cache,entries[i]);}catch(IOException){}catch(UnauthorizedAccessException){}
                return result;
            });
            checking.ContinueWith(task=>{var observed=task.Exception;},TaskContinuationOptions.OnlyOnFaulted);
        }
        internal void Tick(double now)
        {
            if(stopped||Ready)return;
            if(!scanned)
            {
                if(!checking.IsCompleted)return;
                if(checking.IsFaulted){var observed=checking.Exception;Ready=true;report("Failed to check server sounds. See the log.");return;}
                bool[] present=checking.Result;
                for(int i=0;i<entries.Length;i++)if(present[i])verified.Add(entries[i].Sha256+entries[i].Extension);else{missing++;}
                scanned=true;Next(now);return;
            }
            if(output!=null&&now-sentAt>=Timeout)
            {
                if(retries++<2){report("Retrying sound download: "+entries[index].Name);Request(now);}
                else Fail("server did not respond",now);
            }
        }
        void Next(double now)
        {
            ClosePartial();
            while(++index<entries.Length&&IsVerified(entries[index])){}
            if(index>=entries.Length)
            {
                Ready=true;
                report(entries.Length==0?"Server has no custom sounds.":failed>0?"Sound downloads finished: "+completed+" downloaded, "+failed+" failed.":missing==0?"Server sounds verified in cache.":"All server sounds downloaded and verified.");
                return;
            }
            try
            {
                token=Guid.NewGuid().ToString("N");offset=0;retries=0;nextProgress=now;
                temporary=ServerSoundCatalog.CachePath(cache,entries[index])+"."+token+".part";
                output=new FileStream(temporary,FileMode.CreateNew,FileAccess.Write,FileShare.None,ChunkSize);
                hash=SHA256.Create();report("Downloading ["+(completed+failed+1)+"/"+missing+"] "+entries[index].Name+": 0%\n"+FileCounts);
                Request(now);
            }
            catch(Exception ex)when(ex is IOException||ex is UnauthorizedAccessException){Fail(ex.Message,now);}
        }
        void Request(double now)
        {
            sentAt=now;
            try{send(new SoundRequest{Token=token,Id=entries[index].Id,Offset=offset});}
            catch(Exception ex){report("Waiting to send sound request: "+ex.Message);}
        }
        internal void Receive(SoundResponse response,double now)
        {
            if(stopped||Ready||output==null||response.Token!=token||response.Id!=entries[index].Id||response.Offset!=offset)return;
            if(response.Status!=0){Fail("server refused this file ("+response.Status+")",now);return;}
            int expected=(int)Math.Min(ChunkSize,entries[index].Bytes-offset);
            if(response.Data==null||response.Data.Length!=expected){Fail("invalid chunk length",now);return;}
            try
            {
                output.Write(response.Data,0,expected);hash.TransformBlock(response.Data,0,expected,null,0);offset+=expected;retries=0;
                if(offset==entries[index].Bytes)
                {
                    hash.TransformFinalBlock(Array.Empty<byte>(),0,0);
                    string actual=BitConverter.ToString(hash.Hash).Replace("-","").ToLowerInvariant();
                    if(actual!=entries[index].Sha256){Fail("SHA256 mismatch; file discarded",now);return;}
                    output.Flush(true);output.Dispose();output=null;hash.Dispose();hash=null;
                    string destination=ServerSoundCatalog.CachePath(cache,entries[index]);
                    if(File.Exists(destination))File.Replace(temporary,destination,null);else File.Move(temporary,destination);
                    temporary=null;verified.Add(entries[index].Sha256+entries[index].Extension);completed++;
                    report("Verified: "+entries[index].Name);Next(now);return;
                }
                if(now>=nextProgress)
                {
                    nextProgress=now+.25;
                    report("Downloading ["+(completed+failed+1)+"/"+missing+"] "+entries[index].Name+": "+(offset*100/entries[index].Bytes)+"%\n"+FileCounts);
                }
                Request(now);
            }
            catch(Exception ex)when(ex is IOException||ex is UnauthorizedAccessException){Fail(ex.Message,now);}
        }
        string FileCounts=>"Downloaded files: "+completed+" / "+missing+(failed>0?"; failed: "+failed:"");

        void Fail(string message,double now){failed++;report("Failed sound "+entries[index].Name+": "+message);Next(now);}
        void ClosePartial()
        {
            output?.Dispose();output=null;hash?.Dispose();hash=null;
            if(temporary!=null){try{File.Delete(temporary);}catch(IOException){}catch(UnauthorizedAccessException){}temporary=null;}
        }
        public void Dispose(){stopped=true;ClosePartial();if(checking.IsFaulted){var observed=checking.Exception;}}
    }
    internal sealed class SoundFileServer
    {
        sealed class Source{internal SoundEntry Entry;internal string File;internal DateTime Modified;}
        readonly Dictionary<int,Source> sources=new Dictionary<int,Source>();
        internal SoundFileServer(string folder,SoundEntry[] catalog)
        {
            foreach(var file in Directory.GetFiles(folder).OrderBy(f=>f,StringComparer.Ordinal))
            {
                string extension=Path.GetExtension(file).ToLowerInvariant();string prefix=Path.GetFileNameWithoutExtension(file).Split('_')[0];
                if(!int.TryParse(prefix,out int id)||sources.ContainsKey(id))continue;
                foreach(var entry in catalog)if(entry.Id==id&&entry.Extension==extension){sources[id]=new Source{Entry=entry,File=file,Modified=File.GetLastWriteTimeUtc(file)};break;}
            }
        }
        internal SoundResponse Read(SoundRequest request)
        {
            var response=new SoundResponse{Token=request.Token,Id=request.Id,Offset=request.Offset,Status=1};
            if(!sources.TryGetValue(request.Id,out var source)||request.Offset<0||request.Offset>=source.Entry.Bytes||request.Offset%SoundDownload.ChunkSize!=0)return response;
            try
            {
                var info=new FileInfo(source.File);
                if(info.Length!=source.Entry.Bytes||info.LastWriteTimeUtc!=source.Modified){response.Status=2;return response;}
                using(var input=File.OpenRead(source.File))
                {
                    input.Position=request.Offset;int length=(int)Math.Min(SoundDownload.ChunkSize,source.Entry.Bytes-request.Offset);var data=new byte[length];int read=0;
                    while(read<length){int n=input.Read(data,read,length-read);if(n==0)throw new EndOfStreamException();read+=n;}
                    response.Data=data;response.Status=0;return response;
                }
            }
            catch(IOException){response.Status=2;return response;}catch(UnauthorizedAccessException){response.Status=2;return response;}
        }
    }
}
