using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Assets.Scripts;
using Assets.Scripts.Objects.Electrical;
namespace CustomSoundAlert
{
    public static class SoundAlertCatalog
    {
        public static EnumCollection<SoundAlert,int> Expand(EnumCollection<SoundAlert,int> original,IReadOnlyDictionary<int,string> custom)
        {
            foreach(int id in custom.Keys)
                if(id<100||id>199||id<original.Length)throw new ArgumentOutOfRangeException(nameof(custom),"Custom SoundAlert IDs must be100..199 and must not overlap vanilla.");
            int length=custom.Count==0?original.Length:Math.Max(original.Length,custom.Keys.Max()+1);
            var values=new SoundAlert[length];var ints=new int[length];var names=new string[length];
            Array.Copy(original.Values,values,original.Length);Array.Copy(original.ValuesAsInts,ints,original.Length);Array.Copy(original.Names,names,original.Length);
            for(int i=original.Length;i<length;i++){values[i]=(SoundAlert)i;ints[i]=i;names[i]=string.Empty;}
            foreach(var item in custom)names[item.Key]=ModeCatalog.DisplayName(item.Value);
            string longest=names.OrderByDescending(n=>(n??"").Length).FirstOrDefault()??"";
            var padded=names.Select(n=>(n??"").PadRight(longest.Length,' ')).ToArray();
            var type=typeof(EnumCollection<SoundAlert,int>);
            var copy=(EnumCollection<SoundAlert,int>)typeof(object).GetMethod("MemberwiseClone",BindingFlags.Instance|BindingFlags.NonPublic).Invoke(original,null);
            copy.Values=values;copy.ValuesAsInts=ints;
            foreach(var item in new[]{new KeyValuePair<string,object>("Names",names),new KeyValuePair<string,object>("PaddedNames",padded),new KeyValuePair<string,object>("LongestName",longest),new KeyValuePair<string,object>("<Length>k__BackingField",length)})
                type.GetField(item.Key,BindingFlags.Instance|BindingFlags.Public|BindingFlags.NonPublic).SetValue(copy,item.Value);
            return copy;
        }
    }
}
