using System;using System.Collections.Generic;using CustomSoundAlert;using Assets.Scripts.Objects;using Assets.Scripts.Objects.Clothing;using Assets.Scripts.Objects.Items;
namespace Assets.Scripts.Objects{public class Thing{public bool IsBeingDestroyed,IsCursor;}}
namespace Assets.Scripts.Objects.Clothing{public class SuitBase:Thing{
 byte id;public bool Powered=true,Running=true;public byte SoundVolume=42;public int Plays;public Func<int,bool> Available=_=>true;
 public byte SoundAlert{get=>id;set{SuitAlertPlayback.RequestSound(this,id,value,Running);id=value;Attempt();}}
 public void Attempt(){if(SuitAlertPlayback.ShouldPlay(this,id,Available(id)))Plays++;}
}}
namespace Assets.Scripts.Objects.Items{public class AdvancedTablet:Thing{byte id;public bool Powered=true,OnOff=true;public byte SoundVolume=67;public int Plays;public byte SoundAlert{get=>id;set{id=value;Plays++;}}}}
class Program{
 static int n;static void Check(bool b,string m){n++;if(!b)throw new Exception(m);}
 static int Refresh(params Thing[] hosts)=>SoundAlertRefresh.Refresh(hosts,_=>true,null,(s,id)=>SuitAlertPlayback.Waiting(s,id));
 static void Join(SuitBase s,byte id){SuitAlertPlayback.EnterJoin();try{s.SoundAlert=id;}finally{SuitAlertPlayback.ExitJoin();}}
 static void Snapshot(SuitBase s,byte id){SuitAlertPlayback.EnterSnapshot();try{s.SoundAlert=id;}finally{SuitAlertPlayback.ExitSnapshot();}}
 static void Main(){
 SuitAlertPlayback.Reset();
 var ready=new HashSet<int>();var s=new SuitBase{Available=ready.Contains};Join(s,100);
 Check(s.SoundAlert==100&&s.Plays==0,"join changed ID or played missing audio");
 ready.Add(100);Check(Refresh(s)==0&&s.Plays==0,"old join ID replayed after download");
 s.Attempt();Check(s.Plays==0,"power/interaction callback replayed join state");
 s.SoundAlert=100;Check(s.Plays==1,"fresh same-ID gameplay request rejected");
 s.Attempt();Check(s.Plays==1,"completed request replayed by callback");
 Snapshot(s,100);Check(s.Plays==1&&s.SoundAlert==100,"full state replayed same ID");
 s.SoundAlert=100;Check(s.Plays==2,"explicit repeat suppressed");
 var other=new SuitBase();other.SoundAlert=101;Check(other.Plays==1,"other player initial request failed");
 // Joining player causes full native updates of all suits, not a broadcast trigger.
 var joining=new SuitBase();Join(joining,102);Snapshot(s,100);Snapshot(other,101);Snapshot(joining,102);
 Check(s.Plays==2&&other.Plays==1&&joining.Plays==0,"another player joining replayed suits");
 Snapshot(other,103);Check(other.Plays==2&&other.SoundAlert==103,"new authoritative ID incorrectly dropped");
 s.SoundAlert=104;Check(s.Plays==2&&SuitAlertPlayback.Waiting(s,104),"missing live request not deferred");
 Snapshot(s,104);Check(SuitAlertPlayback.Waiting(s,104),"full snapshot erased real waiting event");
 ready.Add(104);Check(Refresh(s)==1&&s.Plays==3,"download did not resume real live request once");
 Check(Refresh(s)==0&&s.Plays==3,"pending request replayed twice");
 s.SoundAlert=105;s.SoundAlert=0;ready.Add(105);int before=s.Plays;
 Check(Refresh(s)==0&&s.Plays==before&&!SuitAlertPlayback.Waiting(s,105),"stop did not cancel pending audio");
 s.SoundAlert=106;s.SoundAlert=107;ready.Add(106);Check(!SuitAlertPlayback.Waiting(s,106)&&SuitAlertPlayback.Waiting(s,107),"replaced request survived");
 ready.Add(107);Check(Refresh(s)==1&&s.SoundAlert==107,"latest request not resumed");
 var loading=new SuitBase{Running=false};loading.SoundAlert=108;Check(loading.Plays==0&&Refresh(loading)==0,"loading state treated as new event");
 var off=new SuitBase{Available=_=>false};off.SoundAlert=109;off.Powered=false;
 Check(Refresh(off)==0,"unpowered suit resumed");
 off.Powered=true;off.Available=_=>true;Check(Refresh(off)==1&&off.Plays==1,"pending powered suit did not resume");
 Check(s.SoundVolume==42&&off.SoundVolume==42,"volumes changed");
 var tablet=new AdvancedTablet{SoundAlert=101};int tabletBefore=tablet.Plays;Check(Refresh(tablet)==1&&tablet.Plays==tabletBefore+1,"tablet behavior changed");
 var cursor=new SuitBase{IsCursor=true,Available=_=>false};cursor.SoundAlert=100;
 var destroyed=new SuitBase{IsBeingDestroyed=true,Available=_=>false};destroyed.SoundAlert=100;
 Check(Refresh(cursor,destroyed,null,new Thing())==0,"invalid hosts resumed");
 s.SoundAlert=110;SuitAlertPlayback.Reset();ready.Add(110);Check(Refresh(s)==0,"old session request leaked");
 foreach(int id in new[]{0,1,45,99,200,255})Check(SuitAlertPlayback.ShouldPlay(new object(),id,false),"vanilla handling intercepted");
 Console.WriteLine(n+" checks passed: join/rejoin, multi-player full snapshots, intentional repeats, live download deferral, stop/replacement, session reset, power, vanilla and tablet compatibility.");
 }
}
