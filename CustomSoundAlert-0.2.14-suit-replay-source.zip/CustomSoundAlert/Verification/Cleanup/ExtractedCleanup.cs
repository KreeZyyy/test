using System;using System.Collections.Generic;
namespace CustomSoundAlert {partial class Plugin {
        static void RemoveClipIndices(AudioManager manager,GameAudioClipsData data)
        {
            if(manager==null)return;
            var hashes=managerClips.GetValue(manager) as Dictionary<int,GameAudioClipsData>;
            var alerts=managerAlerts.GetValue(manager) as Dictionary<int,GameAudioClipsData>;
            if(hashes!=null&&hashes.TryGetValue(data.NameHash,out var byHash)&&ReferenceEquals(byHash,data))hashes.Remove(data.NameHash);
            int id=(int)data.SoundAlert;
            if(id>=100&&id<=199&&alerts!=null&&alerts.TryGetValue(id,out var byId)&&ReferenceEquals(byId,data))alerts.Remove(id);
        }
        static void RegisterClip(AudioManager manager,int id,GameAudioClipsData data)
        {
            if(id<100||id>199)throw new ArgumentOutOfRangeException(nameof(id));
            var hashes=managerClips.GetValue(manager) as Dictionary<int,GameAudioClipsData>;
            var alerts=managerAlerts.GetValue(manager) as Dictionary<int,GameAudioClipsData>;
            if(hashes==null||alerts==null)throw new InvalidOperationException("Native audio lookup unavailable.");
            if(hashes.ContainsKey(data.NameHash)||alerts.ContainsKey(id))throw new InvalidOperationException("Native audio registration collision for SoundAlert "+id);
            data.SoundAlert=(SoundAlert)id;
            var audio=new AudioData();audio.AudioClipsData.Add(data);
            try
            {
                manager.LoadAudioData(new[]{audio});
                if(!hashes.TryGetValue(data.NameHash,out var byHash)||!ReferenceEquals(byHash,data)||
                    !alerts.TryGetValue(id,out var byId)||!ReferenceEquals(byId,data))throw new InvalidOperationException("Native SoundAlert lookup verification failed for "+id);
            }
            catch{RemoveClipIndices(manager,data);throw;}
        }
        static void ReleaseClips()
        {
            clipRegistry.Clear();
            foreach(var pair in ownedClips)
            {
                var data=pair.Key;var manager=pair.Value;
                RemoveClipIndices(manager,data);
                foreach(var clip in data.Clips)if(clip!=null)UnityEngine.Object.Destroy(clip);
            }
            ownedClips.Clear();clips.Clear();
        }
}}
