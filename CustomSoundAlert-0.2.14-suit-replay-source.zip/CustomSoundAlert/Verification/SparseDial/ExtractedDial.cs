using HarmonyLib;using UnityEngine;using Assets.Scripts;using Assets.Scripts.Objects;using Assets.Scripts.Objects.Items;using Assets.Scripts.Objects.Electrical;using Assets.Scripts.Networking;using DelayedActionInstance=Assets.Scripts.Objects.Thing.DelayedActionInstance;
namespace CustomSoundAlert{partial class Plugin{
        [HarmonyPatch(typeof(Speaker), "InteractWith")]
        class SparseDialPatch
        {
            internal static bool Prefix(Speaker __instance,Interactable interactable,Interaction interaction,bool doAction,ref DelayedActionInstance __result)
            {
                if(interactable.Action!=InteractableType.Button1||modeNames==null)return true;
                var names=CatalogMatchesRole?modeNames:originalNames;
                int target=ModeCatalog.Step(names,__instance.Mode,interaction.AltKey);
                var action=new DelayedActionInstance{Duration=0f,ActionMessage=interactable.ContextualName};
                if(interaction.SourceSlot==null||!(interaction.SourceSlot.Get() is Screwdriver))
                {__result=action.Fail(Assets.Scripts.Localization2.GameStrings.RequiresScrewdriver?.DisplayString??"Requires screwdriver");return false;}
                string name=target>=0&&target<names.Length?names[target]:null;
                if(string.IsNullOrEmpty(name))name="Sound "+target;
                action.AppendStateMessage(ModeCatalog.CycleMessage(Assets.Scripts.Localization2.GameStrings.GlobalChangeSettingTo?.DisplayString,name));
                if(!KeyManager.GetButton(KeyMap.QuantityModifier))action.ExtendedMessage=InterfaceStrings.HoldForPreviousObject;
                if(!doAction){__result=action.Succeed();return false;}
                if(GameManager.RunSimulation)OnServer.Interact(__instance.InteractMode,target);
                __result=DelayedActionInstance.Success(interactable.ContextualName);return false;
            }
        }
}}
