# Custom SoundAlert 0.2.4

Custom SoundAlert IDs 100–199 for Speakers, Suits and Advanced Tablets. One identical mod for client and dedicated server. Requires StationeersLaunchPad, BepInEx and LaunchPadBooster.

Workshop: https://steamcommunity.com/sharedfiles/filedetails/?id=3844423968

## Sound files outside Workshop

The mod creates `sounds` **beside the BepInEx folder**, in the same game/server installation. It resolves the installed BepInEx root rather than the working directory or Workshop path. For example:

```text
Stationeers/
  BepInEx/
  sounds/
    100_test.wav
    101_my_song.mp3
  CustomSoundAlertData/
    server-cache/
```

A dedicated server uses the same layout in its own installation. Each installation has its own sounds directory. A local host publishes its local catalog; a remote multiplayer client uses only its server's catalog. Workshop updates update the mod files, while these user files live outside the Workshop item.

Add WAV, OGG or MP3 files named `<id>_<label>.<extension>`, with unique IDs 100–199. Restart after changing files. The log prints absolute paths under `Persistent sounds`, `Separate server cache` and `Sounds folder ready`. An empty server sounds directory publishes no custom entries. Source/test ZIPs include no personal audio.

## First setup

On first launch the mod creates an empty `sounds` folder beside `BepInEx` and an empty separate cache. Nothing is copied or imported from Workshop or old locations. No audio or migration marker is bundled or created. Add your own sound files manually to the new sounds directory. Existing user files are never overwritten, moved or removed by setup. Later launches preserve those files. Keep the server directory empty for a vanilla-only server catalog.

## Installation and update

Close the client/server, then extract the common mod ZIP over its existing `CustomSoundAlert` mod folder. Keep only one mod installation; disable obsolete `CustomSpeakerSounds` copies. Use the same build on both peers. This release does not bundle audio or replace the installation-level sounds folder.

## Multiplayer

The server catalog is sent via LaunchPadBooster's world-join prefix. Logs identify serializer registration, SERVER write and CLIENT validated receipt. Private client sounds are hidden during remote multiplayer. Clients use only server-manifest entries and matching SHA256-verified cached files.

Automatic audio transfer, download progress and synchronized late-join playback are not implemented. An empty server catalog remains vanilla-only regardless of the client's local songs or cached audio. Missing cache means custom server audio is silent.

## Verification

Native .NET Framework 4.7.2 game API build passed. 12 real-filesystem storage checks cover empty first setup, no Workshop import, server/client/cache separation and preservation of manually added files. Prior ID, catalog, manifest, cleanup, join diagnostic and allocation fixtures pass. These checks do not replace live Unity/DS testing. Users confirmed 0.2.3 hides local songs on an empty server and plays them in singleplayer; transitions without restarting the game remain a separate reported issue and are not addressed by this storage update.

## Credits

Inspired by Sovana122: https://github.com/Sovana122/Sationeers-CustomSound/tree/speaker
Original license and attribution are preserved in LICENSE-Sovana.txt. Matching source and test fixtures are supplied separately.
