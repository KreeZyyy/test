# Custom SoundAlert 0.2.4 — multiplayer status

The shared client/server mod keeps audio in `sounds` beside that installation's `BepInEx` directory. Remote cache is separate at `CustomSoundAlertData/server-cache` under the same installation root. First setup only creates empty directories. No copying or migration occurs; users add their own sounds manually. Existing files remain untouched.

The LaunchPadBooster join prefix carries validated server IDs, labels, extensions, lengths and SHA256 hashes. Dedicated servers scan metadata without finding AudioManager or decoding audio. Remote clients hide private local sounds, and only server catalog entries with a matching verified cache can play. An empty server list selects no custom audio, including any cached or local songs. Server and client use the same mod build.

The protocol limits entries to IDs 100–199, 100 sounds, 32 MiB per source file, 128 MiB total source data, labels of 96 characters and 64 KiB manifest payload. These bounds do not limit decoded PCM memory.

Automatic audio transfer, download progress and synchronized late-join playback remain unimplemented. Join-prefix registration/send/receive logs remain enabled. A missing receive log can mean world join did not reach catalog processing; it does not alone prove the server mod is absent.

User live evidence: 0.2.3 loaded on DS, local songs hidden on empty server, songs present and playing in singleplayer. Switching sessions without restarting has been reported to freeze/crash; cause is unresolved. 0.2.4 changes storage, not session switching. New storage integration still needs a live game/server check. Automated filesystem, catalog, manifest, cleanup and allocation checks pass.
