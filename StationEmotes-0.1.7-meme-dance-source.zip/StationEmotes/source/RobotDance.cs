using System;
using System.Linq;
using Assets.Scripts;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Inventory;
using Assets.Scripts.Objects.Entities;
using Assets.Scripts.Emotes;
using UnityEngine;
namespace StationEmotes
{
 [DefaultExecutionOrder(10000)]
 public sealed class RobotDance:MonoBehaviour
 {
  internal bool Active {get;private set;}
  private bool meme;
  internal int Index=>Active?(meme?Plugin.MemeDance:Plugin.Dance):0;
  private Human owner;private Transform[] bones;private Quaternion[] rest;private Vector3[] axes,secondary;
  private float started;private Vector3 origin;
  internal void Begin(Human human,Animator animator,bool memeDance=false)
  {
   Stop();if(animator==null||!animator.isHuman){Plugin.Log.LogWarning("Robot dance needs a humanoid avatar; skipped.");return;}
   HumanBodyBones[] ids={HumanBodyBones.LeftUpperArm,HumanBodyBones.RightUpperArm,HumanBodyBones.LeftLowerArm,HumanBodyBones.RightLowerArm,HumanBodyBones.Spine,HumanBodyBones.LeftUpperLeg,HumanBodyBones.RightUpperLeg,HumanBodyBones.LeftLowerLeg,HumanBodyBones.RightLowerLeg};
   if(memeDance)ids=ids.Concat(new[]{HumanBodyBones.Hips}).ToArray();
   var rig=ids.Select(animator.GetBoneTransform).ToArray();
   if(rig.Any(t=>t==null||t.parent==null)||rig.Distinct().Count()!=rig.Length){Plugin.Log.LogWarning("Robot dance bones incomplete; skipped.");return;}
   var facing=human.CharacterRotationY!=null?human.CharacterRotationY:human.transform;
   meme=memeDance;owner=human;bones=rig;rest=rig.Select(t=>t.localRotation).ToArray();axes=new Vector3[rig.Length];secondary=new Vector3[rig.Length];
   for(int i=0;i<rig.Length;i++){var world=i<2||i==9?facing.forward:i==4?facing.up:facing.right;axes[i]=Quaternion.Inverse(rig[i].parent.rotation)*world;secondary[i]=Quaternion.Inverse(rig[i].parent.rotation)*facing.right;}
   started=Time.unscaledTime;origin=human.transform.position;Active=true;
   Plugin.Log.LogInfo((meme?"Meme":"Robot")+" dance started; human="+human.ReferenceId);
  }
  private void LateUpdate()
  {
   if(!Active)return;
   if(owner==null||owner.IsBeingDestroyed||owner.State!=EntityState.Alive||GameManager.GameState!=GameState.Running){Stop();return;}
   if(HeldEmote.MovingLocally(owner)||owner.LeftHandSlot?.Get()!=null||owner.RightHandSlot?.Get()!=null||(owner.transform.position-origin).sqrMagnitude>.01f){Stop(true);return;}
   float t=Time.unscaledTime-started,s=RobotDancePolicy.Sample(t),bend=Mathf.Abs(s);
   float blend=Mathf.SmoothStep(0,1,Mathf.Clamp01(t/.4f));
   for(int i=0;i<bones.Length;i++)
   {
    float angle=meme?MemeDancePolicy.Angle(i,t):i==0?-45f+22f*s:i==1?45f+22f*s:i==2?-65f-20f*s:i==3?-65f+20f*s:i==4?8f*s:i==5?-5f*s:i==6?5f*s:8f*bend;
    float pitch=meme?MemeDancePolicy.ShoulderPitch(i,t):0f;
    if(bones[i]!=null)bones[i].localRotation=Quaternion.Slerp(rest[i],Quaternion.AngleAxis(angle,axes[i])*Quaternion.AngleAxis(pitch,secondary[i])*rest[i],blend);
   }
  }
  internal void Stop(bool notify=false)
  {
   bool send=Active&&notify&&owner!=null&&owner==InventoryManager.ParentHuman&&GameManager.GameState==GameState.Running;
   var emotes=owner?.EmoteController;
   if(Active&&bones!=null)for(int i=0;i<bones.Length;i++)if(bones[i]!=null)bones[i].localRotation=rest[i];
   Active=false;owner=null;bones=null;rest=null;axes=null;secondary=null;
   if(send&&emotes!=null)try{emotes.OnEmote(new EmoteData(Plugin.Cancel,0,EmoteType.Body));}catch(Exception e){Plugin.Log.LogWarning("Dance cancel relay failed: "+e);}
  }
  private void OnDisable(){Stop();}
  private void OnDestroy(){Stop();}
 }
}
