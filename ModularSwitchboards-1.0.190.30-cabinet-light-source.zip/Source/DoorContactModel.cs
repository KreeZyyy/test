using UnityEngine;
namespace ModularSwitchboards
{
    internal static class DoorContactModel
    {
        internal static MeshRenderer Install(DinBreaker owner,Material black,Material grey)
        {
            for(int pin=0;pin<2;pin++)
            {
                var terminal=new GameObject("DoorContactTerminal"+pin){layer=owner.gameObject.layer};terminal.transform.SetParent(owner.transform,false);terminal.transform.localPosition=new Vector3(0,pin*.024f,0);DoorModules.TerminalCube(terminal.transform,1);
                var a=new WirePoint(-.009f,pin*.024f,.0114f);var end=new WirePoint(-.014f,.004f+pin*.016f,.064f);
                var path=DoorModuleLayout.DoorFlexGeometry.Build(a,a+new WirePoint(-.012f,0,.014f),end+new WirePoint(.006f,0,-.015f),end);
                var wire=DoorModules.Part(owner.transform,"DoorContactFixedLead"+pin,WireMesh.Build(path),CabinetGeometry.Materials[3]);WireVisualLighting.Apply(wire);
            }
            var body=DoorModules.Part(owner.transform,"DoorContactHousing",DoorModules.Box(new Vector3(-.014f,.012f,.080f),new Vector3(.016f,.038f,.032f)),black);
            DoorModules.Part(owner.transform,"DoorContactMount",DoorModules.Box(new Vector3(-.019f,.012f,.076f),new Vector3(.006f,.046f,.044f)),grey);
            for(int side=-1;side<=1;side+=2)DoorModules.Part(owner.transform,"DoorContactMountScrew",DoorModules.Box(new Vector3(-.014f,.012f+side*.020f,.098f),new Vector3(.006f,.004f,.002f)),black);
            var plunger=new GameObject("DoorContactPlunger"){layer=owner.gameObject.layer};plunger.transform.SetParent(owner.transform,false);
            DoorModules.Part(plunger.transform,"DoorContactActuator",DoorModules.Box(new Vector3(-.014f,.012f,.104f),new Vector3(.008f,.012f,.016f)),grey);
            var view=owner.gameObject.AddComponent<DoorContactView>();view.Owner=owner;view.Plunger=plunger.transform;return body;
        }
    }
    public sealed class DoorContactView:MonoBehaviour
    {
        public DinBreaker Owner;public Transform Plunger;
        private bool initialized,last;
        private void LateUpdate()
        {
            if(Owner==null||Plunger==null)return;
            bool open=CabinetWiring.CabinetOf(Owner)?.IsOpen==true;
            if(initialized&&open==last)return;initialized=true;last=open;
            Plunger.localPosition=new Vector3(0,0,open?0:-.008f);
            DoorModules.PaintCubes(transform);
        }
    }
}
