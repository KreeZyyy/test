namespace ModularSwitchboards
{
    internal static class DoorContactLayout
    {
        internal static bool Closed(bool ready,bool doorsOpen)=>ready&&doorsOpen;
        internal static bool Fits(int y,int min,int max,int slots)=>y>=min&&y+(slots-1)*10<=max&&y%10==0;
        internal static bool Overlaps(int a,int countA,int b,int countB)=>a<=b+(countB-1)*10&&b<=a+(countA-1)*10;
    }
}
