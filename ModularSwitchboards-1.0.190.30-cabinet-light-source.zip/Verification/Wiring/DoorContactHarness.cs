using System;using System.Linq;using ModularSwitchboards;
internal static class DoorContactHarness
{
 internal static void Run()
 {
  int checks=0;void Check(bool ok,string why){checks++;if(!ok)throw new Exception(why);}
  foreach(var range in new[]{(-90,80),(-190,180)})
  for(int y=range.Item1;y<=range.Item2;y+=10)
  {
   Check(DoorContactLayout.Fits(y,range.Item1,range.Item2,2)==(y<range.Item2),"two slots must fit including last slot");
   Check(DoorContactLayout.Overlaps(y,2,y,1),"first bridge slot occupied");
   Check(DoorContactLayout.Overlaps(y,2,y+10,1),"second bridge slot occupied");
   Check(DoorContactLayout.Overlaps(y+10,1,y,2),"bridge placement must also reject sensor footprint");
   Check(!DoorContactLayout.Overlaps(y,2,y+20,1),"next free bridge slot remains available");
   Check(DoorContactLayout.Overlaps(y,2,y+10,2),"overlapping contacts rejected");
  }
  foreach(var kind in new[]{CabinetWireKind.Normal,CabinetWireKind.Heavy,CabinetWireKind.SuperHeavy})
  {
   var source=new CabinetWireEnd(0,0);var input=new CabinetWireEnd(80000000001,0);var output=new CabinetWireEnd(80000000001,1);var lamp=new CabinetWireEnd(80000000002,0);
   var wires=new[]{new CabinetWireSaveData{From=source,To=input,CableKind=kind,CableUnits=1,Points=new[]{0f,0f,.06f,.1f,0f,.06f}},new CabinetWireSaveData{From=output,To=lamp,CableKind=kind,CableUnits=1,Points=new[]{.1f,.024f,.06f,.14f,.15f,.06f}}};
   foreach(bool ready in new[]{false,true})foreach(bool open in new[]{false,true})
   {
    var closed=DoorContactLayout.Closed(ready,open)?new[]{input.Owner}:Array.Empty<long>();
    Check(WireCircuit.Reachable(source,lamp,wires,closed)==(ready&&open),"manual contact must conduct only while complete and open");
    Check(!WireCircuit.Reachable(source,lamp,wires.Take(1),closed),"missing manually wired OUT cannot power lamp");
   }
   foreach(var wire in wires){SerdeHarness.AssertRoundTrip(wire);checks++;}
  }
  Console.WriteLine("Door Contact: "+checks+" footprint/circuit/save checks passed.");
 }
}
