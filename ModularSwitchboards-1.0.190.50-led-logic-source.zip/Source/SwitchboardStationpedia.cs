using System.Linq;
using Assets.Scripts;
using Assets.Scripts.Objects;
using Assets.Scripts.UI;
using Assets.Scripts.Util;
namespace ModularSwitchboards
{
    internal static class SwitchboardStationpedia
    {
        internal static string Category(Thing thing)
        {
            const string prefix="Modular Switchboards";
            string name=thing.PrefabName,kind=StationpediaCatalog.Kind(name);
            if(thing is MultiConstructor&&SwitchboardKitModel.IsKit(thing))return prefix+" Kits";
            if(name==DoorSmartDisplay.PrefabId)return prefix+" Smart Modules";
            if(kind=="door"||name==DoorDial.PrefabId)return prefix+" Door Modules";
            if(DinModuleCatalog.Specs.TryGetValue(name??"",out var spec))return prefix+(spec.Smart||spec.SmartOutput||spec.SmartContactor?" Smart Modules":" Modules");
            return prefix+" Necessary";
        }
        internal static void PopulateLists()
        {
            var data=Stationpedia.DataHandler;
            // Remove only our records before adding them once under Electronics.
            // Regeneration/language changes must not duplicate entries.
            foreach(var page in data._listDictionary.Values)
                foreach(var entries in page.Values)
                    entries.RemoveAll(e=>e.PageLink!=null&&e.PageLink.StartsWith("Thing",System.StringComparison.Ordinal)&&
                        StationpediaCatalog.Kind(e.PageLink.Substring(5))!=null);
            foreach(var page in data._listDictionary.Values)
                if(page.TryGetValue("Modular Switchboards",out var previous)&&previous.Count==0)page.Remove("Modular Switchboards");
            foreach(var thing in Prefab.AllPrefabs.Where(t=>t!=null&&!t.HideInStationpedia&&(!SwitchboardsMod.IsCabinetName(t.PrefabName)||CabinetDocumentation.Listed(t.PrefabName))&&StationpediaCatalog.Kind(t.PrefabName)!=null).OrderBy(t=>t.PrefabName))
                data.AddNewListItem("Electronics",Category(thing),new StationCategoryInsert{
                    PageLink="Thing"+thing.PrefabName,NameOfThing=thing.DisplayName,PrefabHash=thing.PrefabHash,InsertImage=thing.Thumbnail});
        }
        internal static void FormatDevice(Thing prefab,ref StationpediaPage page)
        {
            if(prefab is CabinetLamp&&page!=null)page.BasePowerDraw=CabinetLamp.Watts.ToStringPrefix("W","yellow");
        }
        internal static void FormatBuildStates(Thing prefab,ref StationpediaPage page)
        {
            // The third native state only supports legacy saved inner covers.
            // F1 documents the current frame + plastic shell construction instead.
            if(prefab==null||!SwitchboardsMod.IsCabinetName(prefab.PrefabName)||page==null||page.BuildStates==null)return;
            if(page.BuildStates.Count==3)page.BuildStates.RemoveAt(2);
        }
        internal static void FormatDoorLogic(Thing prefab,ref StationpediaPage page)
        {
            if(!(prefab is DinBreaker part)||!DoorControlLogic.Supported(part)||page==null)return;
            // Door controls are physical Structures, not native Device prefabs.
            // Document the same fields/access modes provided by the Smart Core view.
            page.LogicInsert.Clear();
            foreach(var type in DoorControlLogic.Fields(part))
                page.LogicInsert.Add(new StationLogicInsert{
                    LogicName=Assets.Scripts.Localization.ParseHelpText("{LOGICTYPE:"+type+"}"),
                    LogicAccessTypes=DoorControlLogic.Writable(part,type)?Assets.Scripts.Localization2.GameStrings.LogicReadWrite:Assets.Scripts.Localization2.GameStrings.LogicRead});
        }
        internal static void FormatBindings(Thing prefab,ref StationpediaPage page)
        {
            if(!(prefab is SmartModule)||page==null)return;
            // Runtime private Output addresses are not physical screws on Core.
            // Keep IC10/Lua bindings intact; format only the generated F1 page.
            page.LogicBindings.Clear();
            page.LogicBindings.Add(new StationBinding{Header="db",Label="CORE"});
            page.HasBindings=true;
        }
        internal static void FormatSlots(Thing prefab,ref StationpediaPage page)
        {
            if(page==null||!DinModuleCatalog.Specs.TryGetValue(prefab.PrefabName,out var spec)||!spec.Fuse)return;
            foreach(var slot in page.SlotInserts)
                if(slot.SlotIndex=="0"){slot.SlotName="Cable Fuse ";slot.SlotType="Cable Fuse";}
        }
        internal static void ExpandQuery(ref string searchText)=>searchText=StationpediaCatalog.ExpandQuery(searchText);
        // Keep prefab registration/kit construction intact; filter only the F1 entry.
        internal static bool AllowCreativeEntry(ICreativeSpawnable __0)
            =>!(__0 is Thing item&&(item.PrefabName==SwitchboardsMod.CoverName||item.PrefabName==SwitchboardsMod.MediumCoverName));
        internal static bool CreativeSearch(ICreativeSpawnable thing,string text,string pattern,ref bool __result)
        {
            if(!(thing is Thing item)||!StationpediaCatalog.Matches(item.PrefabName,pattern))return true;
            __result=true;return false;
        }
        internal static bool Search(StationpediaPage __instance,string text,string pattern,ref bool __result)
        {
            if(SwitchboardsMod.IsCabinetName(__instance.PrefabName)&&!CabinetDocumentation.Listed(__instance.PrefabName)){__result=false;return false;}
            if(!StationpediaCatalog.Matches(__instance.PrefabName,pattern))return true;
            __result=true;return false;
        }
    }
}
