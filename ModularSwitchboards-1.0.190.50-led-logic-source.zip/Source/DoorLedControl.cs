using System;
using Assets.Scripts;
namespace ModularSwitchboards
{
    internal static class DoorLedControl
    {
        internal static bool Lit(bool disabled,bool energized)=>!disabled&&energized;
        internal static void Set(DinBreaker owner,double value)
        {
            if(owner==null||!owner.IsDoorLed||owner.IsCursor||owner.IsBeingDestroyed||!owner.IsStructureCompleted||!GameManager.RunSimulation||double.IsNaN(value)||double.IsInfinity(value))return;
            bool disabled=value==0d;
            if(owner.LedDisabled==disabled)return;
            owner.LedDisabled=disabled;
            if(disabled)owner.DoorLit=false;
            owner.NetworkUpdateFlags|=32768;
        }
    }
}
