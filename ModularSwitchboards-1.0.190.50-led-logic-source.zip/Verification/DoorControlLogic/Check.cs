// Exercises the production read-only view. Stubs do not simulate Unity or IC10 execution.
using System;using System.Collections.Generic;using System.Linq;using ModularSwitchboards;
public interface IReferencable{string DisplayName{get;}ushort NetworkUpdateFlags{get;set;}long ReferenceId{get;set;}bool BeingDestroyed{get;set;}void PrintDebugInfo(bool verbose=false);void OnAssignedReference();}
namespace Assets.Scripts {public static class GameManager {public static bool RunSimulation=true;}}
namespace Assets.Scripts.GridSystem {public enum LogicType{Activate,On,PrefabHash,ReferenceId,NameHash,Setting,Power}public enum LogicSlotType{Quantity}}
namespace Assets.Scripts.Objects {public class Thing {}}
namespace Assets.Scripts.Objects.Motherboards {public class Slot {}}
namespace Assets.Scripts.Objects.Pipes {
 using Assets.Scripts.GridSystem;using Assets.Scripts.Objects.Motherboards;
 public interface ILogicable:IReferencable {int TotalSlots{get;}Thing GetAsThing{get;}bool HasAnySlots{get;}Slot GetSlot(int i);int GetPrefabHash();int GetNextSlotId(int i,bool f);string ToTooltip();bool IsLogicSlotReadable();bool IsLogicReadable();bool IsLogicWritable();bool CanLogicRead(LogicType t);bool CanLogicWrite(LogicType t);void SetLogicValue(LogicType t,double v);double GetLogicValue(LogicType t);bool CanLogicRead(LogicSlotType t,int i);double GetLogicValue(LogicSlotType t,int i);int GetNameHash();}
}
namespace ModularSwitchboards {
 class Board {public object PrimaryHost;}
 class Wiring {public List<DinBreaker> Breakers=new();}
 class SwitchboardCabinet {public bool IsStructureCompleted=true;public Wiring Wiring=new();}
 class SmartModule {public bool IsCursor,IsBeingDestroyed,IsStructureCompleted=true;public SwitchboardCabinet Cabinet;}
 class DinBreaker:Assets.Scripts.Objects.Thing,IReferencable {
  public bool IsDoorButton,IsDoorIsolator,IsDoorStop,IsDoorLed,LedDisabled,DoorLit,IsCursor,IsBeingDestroyed,IsStructureCompleted=true,OnOff;public int PrefabHash=17,NameHash=31;public Board Board;
  public string DisplayName=>"control";public ushort NetworkUpdateFlags{get;set;}public long ReferenceId{get;set;}public bool BeingDestroyed{get=>IsBeingDestroyed;set=>IsBeingDestroyed=value;}public void PrintDebugInfo(bool v=false){}public void OnAssignedReference(){}public int GetNameHash()=>NameHash;
 }
}
class Check {
 static int n;static void A(bool b,string why){n++;if(!b)throw new Exception(why);}
 static void Main(){
  var cabinet=new SwitchboardCabinet();var foreign=new SwitchboardCabinet();var core=new SmartModule{Cabinet=cabinet};
  foreach(int kind in new[]{0,1,2}){
   var control=new DinBreaker{ReferenceId=100+kind,Board=new Board{PrimaryHost=cabinet},IsDoorButton=kind==0,IsDoorIsolator=kind==1,IsDoorStop=kind==2};cabinet.Wiring.Breakers.Add(control);
   var view=DoorControlLogic.Local(core).Single(x=>x.ReferenceId==control.ReferenceId);
   A(view.CanLogicRead(Assets.Scripts.GridSystem.LogicType.Activate),"requested control not readable");
   foreach(bool state in new[]{false,true,false}){control.OnOff=state;A(view.GetLogicValue(Assets.Scripts.GridSystem.LogicType.Activate)==(state?1:0),"Activate not live native state");}
   A(!view.CanLogicWrite(Assets.Scripts.GridSystem.LogicType.Activate)&&!view.IsLogicWritable(),"control became writable");
   bool blocked=false;try{view.SetLogicValue(Assets.Scripts.GridSystem.LogicType.Activate,1);}catch(InvalidOperationException){blocked=true;}A(blocked&&!control.OnOff,"logic write changed physical state");
   A(view.GetLogicValue(Assets.Scripts.GridSystem.LogicType.PrefabHash)==17&&view.GetLogicValue(Assets.Scripts.GridSystem.LogicType.ReferenceId)==control.ReferenceId,"native identity lost");
   control.NameHash=99;A(view.GetNameHash()==99&&view.GetLogicValue(Assets.Scripts.GridSystem.LogicType.NameHash)==99,"rename hash was cached");
   A(ReferenceEquals(view,DoorControlLogic.Local(core).Single(x=>x.ReferenceId==control.ReferenceId)),"read view is not stable");
   A(ReferenceEquals(view.GetAsThing,control),"view fabricated another Thing");
   control.IsCursor=true;A(!DoorControlLogic.Local(core).Any(x=>x.ReferenceId==control.ReferenceId),"cursor visible");control.IsCursor=false;
   control.IsBeingDestroyed=true;A(!DoorControlLogic.Local(core).Any(x=>x.ReferenceId==control.ReferenceId),"destroyed control visible");control.IsBeingDestroyed=false;
   control.IsStructureCompleted=false;A(!DoorControlLogic.Local(core).Any(x=>x.ReferenceId==control.ReferenceId),"unfinished control visible");control.IsStructureCompleted=true;
  }
  cabinet.Wiring.Breakers.Add(new DinBreaker{ReferenceId=999,IsDoorButton=true,Board=new Board{PrimaryHost=foreign}});
  cabinet.Wiring.Breakers.Add(new DinBreaker{ReferenceId=998,Board=new Board{PrimaryHost=cabinet}});
  A(DoorControlLogic.Local(core).Count()==3,"foreign cabinet or non-control exposed");
  core.IsCursor=true;A(!DoorControlLogic.Local(core).Any(),"cursor core exposed controls");core.IsCursor=false;
  core.IsBeingDestroyed=true;A(!DoorControlLogic.Local(core).Any(),"destroyed core exposed controls");core.IsBeingDestroyed=false;
  core.IsStructureCompleted=false;A(!DoorControlLogic.Local(core).Any(),"unfinished core exposed controls");core.IsStructureCompleted=true;
  cabinet.IsStructureCompleted=false;A(!DoorControlLogic.Local(core).Any(),"unfinished cabinet exposed controls");
  cabinet.IsStructureCompleted=true;
  var led=new DinBreaker{ReferenceId=200,IsDoorLed=true,Board=new Board{PrimaryHost=cabinet}};cabinet.Wiring.Breakers.Add(led);
  var lamp=DoorControlLogic.Local(core).Single(x=>x.ReferenceId==200);
  A(lamp.GetLogicValue(Assets.Scripts.GridSystem.LogicType.On)==1,"default LED is not enabled");
  A(lamp.CanLogicWrite(Assets.Scripts.GridSystem.LogicType.On)&&lamp.IsLogicWritable(),"LED On not writable");
  A(!lamp.CanLogicWrite(Assets.Scripts.GridSystem.LogicType.Power)&&!lamp.CanLogicRead(Assets.Scripts.GridSystem.LogicType.Activate),"LED exposed wrong capabilities");
  foreach(bool powered in new[]{false,true})foreach(int command in new[]{0,1}) {
   lamp.SetLogicValue(Assets.Scripts.GridSystem.LogicType.On,command);
   led.DoorLit=DoorLedControl.Lit(led.LedDisabled,powered);
   A(lamp.GetLogicValue(Assets.Scripts.GridSystem.LogicType.On)==command,"On does not report permission");
   A(lamp.GetLogicValue(Assets.Scripts.GridSystem.LogicType.Power)==(powered&&command==1?1:0),"LED does not require both permission and wired energy");
  }
  led.DoorLit=true;lamp.SetLogicValue(Assets.Scripts.GridSystem.LogicType.On,0);A(!led.DoorLit&&led.LedDisabled,"off is not immediate");
  led.NetworkUpdateFlags=0;lamp.SetLogicValue(Assets.Scripts.GridSystem.LogicType.On,0);A(led.NetworkUpdateFlags==0,"duplicate off creates network traffic");
  lamp.SetLogicValue(Assets.Scripts.GridSystem.LogicType.On,1);A(!led.LedDisabled&&!led.DoorLit&&led.NetworkUpdateFlags==32768,"on generated light without a power tick or missed sync");
  Assets.Scripts.GameManager.RunSimulation=false;lamp.SetLogicValue(Assets.Scripts.GridSystem.LogicType.On,0);A(!led.LedDisabled,"client changed LED command");Assets.Scripts.GameManager.RunSimulation=true;
  foreach(double invalid in new[]{double.NaN,double.PositiveInfinity,double.NegativeInfinity}){lamp.SetLogicValue(Assets.Scripts.GridSystem.LogicType.On,invalid);A(!led.LedDisabled,"nonfinite command changed LED");}
  led.NameHash=123;A(lamp.GetNameHash()==123,"LED name hash stale");
  Console.WriteLine(n+" production door-control/LED logic checks passed (state, LED permission/power, write guards, cabinet scope, rename, lifetime).");
 }
}
