using System;using System.IO;using System.Xml.Serialization;using ModularSwitchboards;using Assets.Scripts.Networking;
namespace Assets.Scripts {public static class GameManager{public static bool RunSimulation=true;}}
namespace Assets.Scripts.Networking {
 public class RocketBinaryWriter:BinaryWriter{public RocketBinaryWriter(Stream s):base(s){}public void WriteBoolean(bool v)=>Write(v);public void WriteInt32(int v)=>Write(v);}
 public class RocketBinaryReader:BinaryReader{public RocketBinaryReader(Stream s):base(s){}}
}
namespace Assets.Scripts.Objects {
 public class StructureSaveData{}
 public class Thing{
  public static bool IsNetworkUpdateRequired(ushort bit,ushort flags)=>(bit&flags)!=0;
  public virtual void BuildUpdate(RocketBinaryWriter w,ushort flags){w.WriteInt32(123);}
  public virtual void ProcessUpdate(RocketBinaryReader r,ushort flags){if(r.ReadInt32()!=123)throw new Exception("base update framing");}
  public virtual void SerializeOnJoin(RocketBinaryWriter w){w.WriteInt32(321);}
  public virtual void DeserializeOnJoin(RocketBinaryReader r){if(r.ReadInt32()!=321)throw new Exception("base join framing");}
 }
}
namespace LibConstruct {public class PlacementBoardStructureSaveData{}public static class BoardStructureHooks {public static void SerializeOnJoin(RocketBinaryWriter w,object o){w.Write(123456789012L);}public static void DeserializeOnJoin(RocketBinaryReader r,object o){if(r.ReadInt64()!=123456789012L)throw new Exception("mount framing");}}}
namespace ModularSwitchboards {
 public partial class DinBreaker:Assets.Scripts.Objects.Thing{
  public bool IsDoorLed,DoorLit,LedDisabled,IsContactor,ContactorClosed,IsFuseHolder,OnOff,Tripped;
  private const ushort ModuleUpdate=32768;private int fuseBurnSequence=0;
 }
 static class DinFuseAudio {public static void Play(DinBreaker o){}}
}
class Check {
 static int count;static void A(bool b,string why){count++;if(!b)throw new Exception(why);}
 const int End=159753;
 static void Main(){
  foreach(int type in new[]{0,1,2})foreach(bool disabled in new[]{false,true})foreach(bool lit in new[]{false,true}) {
   DinBreaker Make()=>new DinBreaker{IsDoorLed=type==0,IsContactor=type==1,IsFuseHolder=type==2};
   var source=Make();source.DoorLit=lit;source.LedDisabled=disabled;source.ContactorClosed=true;source.Tripped=true;source.OnOff=true;
   using var join=new MemoryStream();var writer=new RocketBinaryWriter(join);source.SerializeOnJoin(writer);writer.WriteInt32(End);writer.Flush();join.Position=0;
   var dest=Make();var reader=new RocketBinaryReader(join);dest.DeserializeOnJoin(reader);
   A(reader.ReadInt32()==End&&join.Position==join.Length,"join length/next object corrupted");
   A(dest.Tripped&&(!source.IsContactor||dest.ContactorClosed),"existing contactor/trip state lost");
   A(!source.IsDoorLed||dest.DoorLit==lit&&dest.LedDisabled==disabled,"LED join lost light/permission");
   foreach(ushort flags in new ushort[]{0,32768,65535}) {
    using var update=new MemoryStream();var w=new RocketBinaryWriter(update);source.BuildUpdate(w,flags);w.WriteInt32(End);w.Flush();update.Position=0;
    var target=Make();var rr=new RocketBinaryReader(update);target.ProcessUpdate(rr,flags);
    A(rr.ReadInt32()==End&&update.Position==update.Length,"update length/next object corrupted");
    A(flags==0?!target.Tripped:target.Tripped,"module update flag ignored");
    if(flags!=0)A(!source.IsDoorLed||target.DoorLit==lit&&target.LedDisabled==disabled,"LED update lost permission");
   }
  }
  var xml=new XmlSerializer(typeof(DinBreakerSaveData));
  using(var old=new StringReader("<DinBreakerSaveData><Tripped>false</Tripped></DinBreakerSaveData>")){var s=(DinBreakerSaveData)xml.Deserialize(old);A(!s.DoorLedDisabled,"old save no longer defaults to powered LED behavior");}
  foreach(bool off in new[]{false,true}){var s=new DinBreakerSaveData{DoorLedDisabled=off};using var text=new StringWriter();xml.Serialize(text,s);using var input=new StringReader(text.ToString());A(((DinBreakerSaveData)xml.Deserialize(input)).DoorLedDisabled==off,"LED permission not retained in XML");}
  Console.WriteLine(count+" extracted production LED update/join/XML checks passed (non-LED framing and old-save defaults included; native base/transport stubs).");
 }
}
