using System;using System.Xml.Serialization;using Assets.Scripts;using Assets.Scripts.Networking;using Assets.Scripts.Objects;using LibConstruct;
namespace ModularSwitchboards{
public sealed class DinBreakerSaveData : StructureSaveData
    {
        [XmlElement] public PlacementBoardStructureSaveData RailBoard;
        [XmlElement] public bool Tripped;
        [XmlElement] public int BodyPaintVersion;
        [XmlElement] public int BatteryConstructionVersion;
        [XmlElement] public bool DoorLedDisabled;
    }
public partial class DinBreaker{
public override void BuildUpdate(RocketBinaryWriter writer,ushort flags){base.BuildUpdate(writer,flags);if(Thing.IsNetworkUpdateRequired(ModuleUpdate,flags)){writer.WriteBoolean(Tripped);writer.WriteBoolean(IsDoorLed?DoorLit:IsContactor?ContactorClosed:!IsFuseHolder&&OnOff);writer.WriteInt32(fuseBurnSequence);if(IsDoorLed)writer.WriteBoolean(LedDisabled);}}
public override void ProcessUpdate(RocketBinaryReader reader,ushort flags)
        {
            base.ProcessUpdate(reader,flags);
            if(Thing.IsNetworkUpdateRequired(ModuleUpdate,flags))
            {
                Tripped=reader.ReadBoolean();bool on=reader.ReadBoolean();if(IsDoorLed)DoorLit=on;else if(IsContactor)ContactorClosed=on;else if(!IsFuseHolder)OnOff=on;
                int incoming=reader.ReadInt32();
                if(IsDoorLed)LedDisabled=reader.ReadBoolean();
                uint advance=unchecked((uint)(incoming-fuseBurnSequence));
                // Duplicate/older updates must not replay a burn. This also notices
                // a new cartridge burning when both snapshots already say Tripped.
                if(advance!=0&&advance<0x80000000u)
                {
                    fuseBurnSequence=incoming;
                    if(!GameManager.RunSimulation)DinFuseAudio.Play(this);
                }
            }
        }
public override void SerializeOnJoin(RocketBinaryWriter writer)
        {
            base.SerializeOnJoin(writer);
            BoardStructureHooks.SerializeOnJoin(writer, this);writer.WriteBoolean(Tripped);writer.WriteInt32(fuseBurnSequence);writer.WriteBoolean(IsDoorLed&&DoorLit);if(IsDoorLed)writer.WriteBoolean(LedDisabled);if(IsContactor)writer.WriteBoolean(ContactorClosed);
        }
public override void DeserializeOnJoin(RocketBinaryReader reader)
        {
            base.DeserializeOnJoin(reader);
            BoardStructureHooks.DeserializeOnJoin(reader, this);Tripped=reader.ReadBoolean();fuseBurnSequence=reader.ReadInt32();bool led=reader.ReadBoolean();if(IsDoorLed){DoorLit=led;LedDisabled=reader.ReadBoolean();}if(IsContactor)ContactorClosed=reader.ReadBoolean();
        }
}
}