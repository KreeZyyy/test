using System;
using System.Collections.Generic;
using System.Linq;
using Assets.Scripts;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Inventory;
using Assets.Scripts.Networking;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Entities;
using Assets.Scripts.Objects.Items;
using Assets.Scripts.Objects.Motherboards;
using LibConstruct;
using UnityEngine;

namespace ModularSwitchboards
{
    public sealed class CabinetWirePaintTarget : MonoBehaviour { public CabinetWireSaveData Wire; }

    public sealed class CabinetWireTarget : MonoBehaviour { public CabinetWireEnd End; }

    public sealed partial class CabinetWiring : MonoBehaviour
    {
        internal const ushort UpdateFlag=32768;
        internal const int CurrentRouteVersion=9;
        public SwitchboardCabinet Owner;
        private readonly List<CabinetWireSaveData> wires=new List<CabinetWireSaveData>();
        private readonly Dictionary<long,CabinetWireEnd> pending=new Dictionary<long,CabinetWireEnd>();
        private readonly Dictionary<long,float> pendingUntil=new Dictionary<long,float>();
        private readonly Dictionary<CabinetWireEnd,Contact> contacts=new Dictionary<CabinetWireEnd,Contact>();
        private readonly List<Mesh> damageMeshes=new List<Mesh>();
        private readonly List<GameObject> visuals=new List<GameObject>();
        private readonly List<Collider> colliders=new List<Collider>();
        internal readonly CabinetWiringPower Power=new CabinetWiringPower();
        private Transform shell,visualRoot,doorVisualRoot,rightDoorVisualRoot;
        private readonly List<WireRect> railObstacles=new List<WireRect>();
        private WireRect[] moduleReservations=WireModuleSpace.Reservations().ToArray();
        private readonly Dictionary<CabinetWireSaveData,MeshRenderer> wireRenderers=new Dictionary<CabinetWireSaveData,MeshRenderer>();
        private GameObject preview;
        private WirePoint[] previewPath;
        private int previewFrame=-1;
        private CabinetWireKind previewKind;
        private bool needsReroute,cleanupOnLoad;
        private string migrationFailure;
        private float nextRefresh,topologyReadyAt,nextLedRefresh;
        private string topology;
        private float routingHalfWidth=WireRouting.HalfWidth,routingHalfHeight=WireRouting.HalfHeight;
        private bool shapeReady;
        private bool rebuild=true;
        private int revision,routeRevision=-1;
        private CabinetWireEnd routeFrom,routeTo;
        private CabinetWireKind routeKind;
        private WirePoint[] route;
        private string routeFailure;
        private int routeSlot;
        private sealed class Contact {internal CabinetWireEnd End;internal Vector3 Position,Aim,Exit;internal WireRect Bounds;internal GameObject Marker;internal bool Door;internal int Leaf;internal float LeadSide;}
        internal static SwitchboardCabinet CabinetOf(DinBreaker breaker)=>breaker.IsDoorPart?breaker.Board?.PrimaryHost as SwitchboardCabinet:(breaker.Board?.PrimaryHost as DinRail)?.Board?.PrimaryHost as SwitchboardCabinet;
        internal IEnumerable<DinBreaker> Breakers=>(Owner.RailBoard==null?Enumerable.Empty<DinBreaker>():Owner.RailBoard.Structures.OfType<DinRail>().Where(r=>r.Modules!=null).SelectMany(r=>r.Modules.Structures.OfType<DinBreaker>())).Concat(Owner.DoorBoards.SelectMany(b=>b.Structures.OfType<DinBreaker>()));
        internal IEnumerable<DinTransformer> Transformers=>Owner.RailBoard==null?Enumerable.Empty<DinTransformer>():Owner.RailBoard.Structures.OfType<DinRail>().Where(r=>r.Modules!=null).SelectMany(r=>r.Modules.Structures.OfType<DinTransformer>()).Where(t=>!t.IsBeingDestroyed);
        internal IEnumerable<DinStationBattery> StationBatteries=>Owner.RailBoard==null?Enumerable.Empty<DinStationBattery>():Owner.RailBoard.Structures.OfType<DinRail>().Where(r=>r.Modules!=null).SelectMany(r=>r.Modules.Structures.OfType<DinStationBattery>()).Where(b=>!b.IsBeingDestroyed);
        private IEnumerable<long> PowerConducting=>Breakers.Where(b=>b.Conducting&&(!b.IsBatteryModule||!BatteryBranchLimit.IsBlocked(b.ReferenceId))).Select(b=>b.ReferenceId).Concat(Transformers.Where(t=>t.Conducting).Select(t=>t.ReferenceId)).Concat(StationBatteries.Where(t=>t.Conducting).Select(t=>t.ReferenceId));
        internal IEnumerable<CabinetLamp> Lamps=>Owner.RailBoard==null?Enumerable.Empty<CabinetLamp>():Owner.RailBoard.Structures.OfType<CabinetLamp>().Where(l=>!l.IsBeingDestroyed);
        internal IEnumerable<DoorSmartDisplay> DoorDisplays=>Owner.DoorBoards.SelectMany(b=>b.Structures.OfType<DoorSmartDisplay>()).Where(d=>!d.IsBeingDestroyed);
        internal IEnumerable<DoorDial> DoorDials=>Owner.DoorBoards.SelectMany(b=>b.Structures.OfType<DoorDial>()).Where(d=>!d.IsBeingDestroyed);
        private IEnumerable<long> DialIds=>DoorDials.Select(d=>d.ReferenceId);
        internal Assets.Scripts.Objects.Electrical.Cable DialCable(long id){
            if(Owner.IsCursor||!Owner.IsStructureCompleted||Owner.GridController==null)return null;
            int output=DoorDialCircuit.Output(id,wires,BridgeIds,DialIds,NetIds);
            var port=output==1?Owner.Output1Connection:output==2?Owner.Output2Connection:output==3?Owner.Output3Connection:null;
            return port?.GetCable()?.CableNetwork==null?null:port.GetCable();
        }
        internal DinBreaker NetForDial(long id){
            if(Owner==null||Owner.IsCursor||!Owner.IsStructureCompleted)return null;
            var bridges=Breakers.Where(m=>m.IsDoorBridge&&m.IsStructureCompleted&&!m.IsBeingDestroyed&&!m.IsCursor).Select(m=>m.ReferenceId);
            long net=DoorDialCircuit.Net(id,wires,bridges,DialIds,NetIds);
            return net==0?null:Breakers.FirstOrDefault(m=>m.ReferenceId==net&&m.IsSmartOutputModule&&m.IsStructureCompleted&&!m.IsBeingDestroyed&&!m.IsCursor);
        }
        internal IEnumerable<DoorDial> DialsForNet(long id)=>DoorDials.Where(d=>d.IsStructureCompleted&&!d.IsBeingDestroyed&&!d.IsCursor&&NetForDial(d.ReferenceId)?.ReferenceId==id);
        private IEnumerable<long> DisplayIds=>DoorDisplays.Select(d=>d.ReferenceId);
        private IEnumerable<long> BridgeIds=>Breakers.Where(b=>b.IsDoorBridge&&!b.IsBeingDestroyed).Select(b=>b.ReferenceId);
        private string displayCircuitKey;
        private readonly Dictionary<long,long> displayTargets=new Dictionary<long,long>();
        internal DoorSmartDisplay DisplayForOutput(long output){
            string key=revision+"|"+topology;
            if(displayCircuitKey!=key){displayCircuitKey=key;displayTargets.Clear();var outputs=Contactors.Select(c=>c.ReferenceId).ToArray();var bridges=BridgeIds.ToArray();var displays=DisplayIds.ToArray();foreach(long id in outputs)displayTargets[id]=SmartDoorDisplayCircuit.Target(id,wires,bridges,displays,outputs);}
            return displayTargets.TryGetValue(output,out var target)?DoorDisplays.FirstOrDefault(d=>d.ReferenceId==target&&d.IsStructureCompleted&&!d.IsCursor):null;
        }
        internal SmartContactor OutputForDisplay(long id){var matches=Contactors.Where(o=>!o.IsCursor&&o.IsStructureCompleted&&DisplayForOutput(o.ReferenceId)?.ReferenceId==id).Take(2).ToArray();return matches.Length==1?matches[0]:null;}
        internal IEnumerable<SmartModule> SmartModules=>Owner.RailBoard==null?Enumerable.Empty<SmartModule>():Owner.RailBoard.Structures.OfType<DinRail>().Where(r=>r.Modules!=null).SelectMany(r=>r.Modules.Structures.OfType<SmartModule>());
        internal IEnumerable<SmartContactor> Contactors=>Owner.RailBoard==null?Enumerable.Empty<SmartContactor>():Owner.RailBoard.Structures.OfType<DinRail>().Where(r=>r.Modules!=null).SelectMany(r=>r.Modules.Structures.OfType<SmartContactor>()).Where(c=>!c.IsBeingDestroyed);
        internal bool SmartOutputConnected(long output)=>DisplayForOutput(output)!=null||SmartControlIndicator.Connected(output,wires,
            Breakers.Where(c=>c.IsContactor&&!c.IsBeingDestroyed).Select(c=>c.ReferenceId));
        internal bool TerminalLive(long id,int pin=0)
        {
            if(Owner==null||Owner.IsCursor||!Owner.IsStructureCompleted||Owner.GridController==null)return false;
            var graph=CircuitWires.ToArray();var closed=PowerConducting.ToArray();var target=new CabinetWireEnd(id,pin);
            return LiveInputs.Any(feed=>WireCircuit.Reachable(feed,target,graph,closed))||Breakers.Any(m=>!m.IsBeingDestroyed&&m.IsBatteryModule&&!BatteryBranchLimit.IsBlocked(m.ReferenceId)&&m.Battery!=null&&m.Battery.PowerStored>0&&WireCircuit.Reachable(new CabinetWireEnd(m.ReferenceId,1),target,graph,closed))||StationBatteries.Any(m=>m.Conducting&&m.PowerStored>0&&WireCircuit.Reachable(new CabinetWireEnd(m.ReferenceId,1),target,graph,closed));
        }
        internal IEnumerable<long> SmartIds=>SmartModules.Where(m=>!m.IsBeingDestroyed).Select(m=>m.ReferenceId);
        internal Assets.Scripts.Objects.Electrical.Cable SmartPowerCable(SmartModule module)
        {
            if(Owner==null||Owner.IsCursor||!Owner.IsStructureCompleted||Owner.GridController==null)return null;
            // Power follows the live internal circuit, independently of any external data/output cable.
            var graph=CircuitWires.ToArray();var closed=PowerConducting.ToArray();var tap=new CabinetWireEnd(module.ReferenceId,0);
            var feeds=Owner.InputContacts.Select(i=>new CabinetWireEnd(0,i)).Where(feed=>WireCircuit.Reachable(feed,tap,graph,closed)).ToArray();
            if(feeds.Length==0)return null;
            if(Transformers.Any(t=>feeds.Any(feed=>WireCircuit.Reachable(feed,new CabinetWireEnd(t.ReferenceId,0),graph,closed))&&WireCircuit.Reachable(new CabinetWireEnd(t.ReferenceId,1),tap,graph,closed)))return SmartCable(module.ReferenceId);
            return InputCableFor(tap,graph,closed);
        }
        private IEnumerable<CabinetWireEnd> LiveInputs=>Owner.InputContacts.Where(i=>(Owner.InputPort(i)?.GetCable()?.CableNetwork?.PotentialLoad??0)>0).Select(i=>new CabinetWireEnd(0,i));
        private Assets.Scripts.Objects.Electrical.Cable InputCableFor(CabinetWireEnd tap,IEnumerable<CabinetWireSaveData> wires,IEnumerable<long> closed)
        {
            var graph=wires.ToArray();var ids=closed.ToArray();
            var cables=Owner.InputContacts.Where(i=>WireCircuit.Reachable(new CabinetWireEnd(0,i),tap,graph,ids)).Select(i=>Owner.InputPort(i)?.GetCable()).Where(c=>c?.CableNetwork!=null).ToArray();
            return cables.Select(c=>c.CableNetwork).Distinct().Count()==1?cables.FirstOrDefault():null;
        }

        internal Assets.Scripts.Objects.Electrical.Cable SmartCable(SmartModule module)
        {
            return SmartCable(module.ReferenceId);
        }
        internal Assets.Scripts.Objects.Electrical.Cable SmartCable(long id,int tapContact=0)
        {
            if(Owner==null||Owner.IsCursor||!Owner.IsStructureCompleted||Owner.GridController==null)return null;
            var modules=Breakers.ToArray();
            int selection=SmartCircuit.Selection(id,CircuitWires,
                modules.Where(b=>b.Conducting).Select(b=>b.ReferenceId),
                modules.Where(b=>!b.IsAnalyserModule&&!b.IsBatteryModule&&!b.IsSmartOutputModule&&!b.IsDoorPart).Select(b=>b.ReferenceId).Concat(Contactors.Select(c=>c.ReferenceId)),tapContact,Owner.InputContacts.Select(i=>new CabinetWireEnd(0,i)));
            if(selection==AnalyserCircuit.Input)return InputCableFor(new CabinetWireEnd(id,tapContact),CircuitWires,modules.Where(m=>m.Conducting&&(!m.IsBatteryModule||!BatteryBranchLimit.IsBlocked(m.ReferenceId))||!m.IsAnalyserModule&&!m.IsBatteryModule&&!m.IsDoorPart&&!m.IsSmartOutputModule).Select(m=>m.ReferenceId).Concat(Contactors.Select(c=>c.ReferenceId)));
            if(selection==0)return null;
            var cables=new[]{Owner.Output1Connection,Owner.Output2Connection,Owner.Output3Connection}
                .Select((port,i)=>new{port,bit=i==2?8:1<<i}).Where(p=>(selection&p.bit)!=0)
                .Select(p=>p.port?.GetCable()).ToArray();
            // Register the real device on exactly one native network. Never bridge
            // unrelated output data networks through the internal module.
            if(cables.Select(c=>c?.CableNetwork).Distinct().Count()!=1)return null;
            return cables.FirstOrDefault(c=>c!=null&&c.CableNetwork!=null);
        }

        private IEnumerable<CabinetWireSaveData> CircuitWires=>ContactorCircuit.WithNormallyClosed(BaseCircuitWires,Breakers.Where(m=>m.HasNormallyClosedContact&&!m.IsBeingDestroyed).Select(m=>m.ReferenceId),Breakers.Where(m=>m.ContactorClosed).Select(m=>m.ReferenceId));
        private IEnumerable<CabinetWireSaveData> BaseCircuitWires=>DoorModuleLayout.Through(SmartContactorCircuit.ValidWires(DoorDialCircuit.PowerWires(wires.Where(w=>!w.Burnt),BridgeIds,DialIds),Contactors.Select(c=>c.ReferenceId),Breakers.Where(c=>c.IsContactor).Select(c=>c.ReferenceId),BridgeIds),Breakers.Where(m=>m.IsDoorBridge&&!m.IsBeingDestroyed).Select(m=>m.ReferenceId));
        private Transform DoorFrame=>DoorModules.Frame(Owner);
        private Transform Frame(Contact c)=>c.Door?DoorModules.Frame(Owner,c.Leaf==1):Shell;
        private Transform WireFrame(CabinetWireSaveData wire)=>contacts.TryGetValue(wire.From,out var c)?Frame(c):Shell;
        private static int Surface(Contact c)=>c.Door?c.Leaf+1:0;
        private int WireSurface(CabinetWireSaveData wire)=>contacts.TryGetValue(wire.From,out var c)?Surface(c):0;
        private bool IsDoorWire(CabinetWireSaveData w)=>contacts.TryGetValue(w.From,out var c)&&c.Door;
        private bool WireEndpointReady(CabinetWireEnd end)
        {
            if(end.Owner==0)return true;
            var module=Breakers.Cast<Structure>().Concat(Lamps).Concat(DoorDisplays).Concat(DoorDials).Concat(Transformers).Concat(StationBatteries).Concat(SmartModules).Concat(Contactors).FirstOrDefault(m=>m.ReferenceId==end.Owner);
            return module!=null&&module.IsStructureCompleted&&!module.IsCursor&&!module.IsBeingDestroyed;
        }
        private bool CanConnectContacts(CabinetWireEnd a,CabinetWireEnd b,out string reason)
        {
            reason=null;
            if(!WireEndpointReady(a)||!WireEndpointReady(b)){reason="Complete the module before connecting cables.";return false;}
            if(!contacts.TryGetValue(a,out var ca)||!contacts.TryGetValue(b,out var cb)){reason="Contact unavailable.";return false;}
            if(Surface(ca)!=Surface(cb)){reason="Wire the plate and door separately through the Door Terminal Bridge.";return false;}
            if(!SmartContactorCircuit.Allowed(a,b,Contactors.Select(c=>c.ReferenceId),Breakers.Where(c=>c.IsContactor).Select(c=>c.ReferenceId),BridgeIds))
            {reason="Smart Output OUT connects to contactor A1 or the plate side of a dedicated display Door Bridge.";return false;}
            foreach(var end in new[]{a,b})if(DisplayIds.Contains(end.Owner)){
                var other=end.Equals(a)?b:a;if(end.Contact!=0||other.Contact!=3||!BridgeIds.Contains(other.Owner)){reason="Display DATA IN connects only to the door side of a dedicated Door Bridge.";return false;}}
            var candidate=new CabinetWireSaveData{From=a,To=b};
            if(!SmartDoorDisplayCircuit.Valid(wires.Concat(new[]{candidate}),BridgeIds,DisplayIds,Contactors.Select(c=>c.ReferenceId))){reason="Use one Smart Output, one dedicated Door Bridge and one door display; keep power and A1 wiring separate.";return false;}
            if(!DoorDialCircuit.Valid(wires.Concat(new[]{candidate}),BridgeIds,DialIds,NetIds)){reason="Dial DATA needs its own Door Bridge connected to one Net DATA contact or one external Output terminal.";return false;}
            foreach(var end in new[]{a,b})if(end.Contact==2&&Breakers.Any(c=>c.ReferenceId==end.Owner&&c.IsContactor))
            {
                var other=end.Equals(a)?b:a;
                if(!other.IsSource&&!Breakers.Any(m=>m.ReferenceId==other.Owner&&m.IsDoorBridge))
                {reason="Connect A1 to a supply contact or a door terminal bridge; the coil is not a power output.";return false;}
            }
            if(!Power.CanJoinBatteryBranch(a,b)){reason=BatteryBranchLimit.Warning;return false;}
            return WireCircuit.CanConnect(a,b,wires,Breakers.Select(m=>m.ReferenceId).Concat(Lamps.Select(l=>l.ReferenceId)).Concat(DisplayIds).Concat(DialIds).Concat(Transformers.Select(t=>t.ReferenceId)).Concat(StationBatteries.Select(t=>t.ReferenceId)).Concat(SmartIds).Concat(Contactors.Select(c=>c.ReferenceId)),out reason,capacity:Capacity,passages:Breakers.Where(m=>m.IsDoorBridge).Select(m=>m.ReferenceId),normallyClosed:Breakers.Where(m=>m.HasNormallyClosedContact).Select(m=>m.ReferenceId),dataTaps:NetIds);
        }
        private Transform Shell=>shell!=null?shell:(shell=Owner.transform.Find("SwitchboardModel/CompletedShell"));
        internal static WirePoint Point(Vector3 p)=>new WirePoint(p.x,p.y,p.z);
        internal static Vector3 Vector(WirePoint p)=>new Vector3(p.X,p.Y,p.Z);
        internal bool HasWires(long breaker)=>wires.Any(w=>w.From.Owner==breaker||w.To.Owner==breaker);
        internal Assets.Scripts.Networks.CableNetwork AnalysedNetwork(DinBreaker analyser,out string reason,out string source)
        {
            reason=null;source=null;
            if(Owner==null||Owner.IsCursor||!Owner.IsStructureCompleted||Owner.GridController==null){reason="No cable network found.";return null;}
            var modules=Breakers.ToArray();
            int output=AnalyserCircuit.Selection(analyser.ReferenceId,CircuitWires,PowerConducting,modules.Where(b=>!b.IsAnalyserModule&&!b.IsBatteryModule&&!b.IsSmartOutputModule&&!b.IsDoorPart).Select(b=>b.ReferenceId),Owner.InputContacts.Select(i=>new CabinetWireEnd(0,i)));
            if(output==AnalyserCircuit.Input){source="Input";var supply=InputCableFor(new CabinetWireEnd(analyser.ReferenceId,0),CircuitWires,PowerConducting.Concat(modules.Where(m=>!m.IsAnalyserModule&&!m.IsBatteryModule&&!m.IsSmartOutputModule&&!m.IsDoorPart).Select(m=>m.ReferenceId)))?.CableNetwork;if(supply==null)reason="No cable network found on Input.";return supply;}
            if(output==0){reason=wires.Any(w=>w.From.Equals(new CabinetWireEnd(analyser.ReferenceId,1)))?"No conducting path from analyser OUT to an output.":"Place the analyzer before protection to read Input, or connect its OUT to the measured output.";return null;}
            var chosen=new[]{Owner.Output1Connection,Owner.Output2Connection,Owner.Output3Connection}.Select((port,i)=>new{port,index=i+1,bit=i==2?8:1<<i}).Where(p=>(output&p.bit)!=0).ToArray();
            source=string.Join(" / ",chosen.Select(p=>"Output "+p.index));var networks=chosen.Select(p=>p.port?.GetCable()?.CableNetwork).ToArray();
            if(networks.Distinct().Count()>1){reason="Analyser leads to different networks.";return null;}
            var network=networks.FirstOrDefault();if(network==null)reason="No cable network found on "+source+".";return network;
        }
        internal bool HasAnyWires=>wires.Count!=0;
        internal static bool IsCoil(DynamicThing item)=>CabinetCableCoils.TryKind(item,out _);
        private static bool LocalTools()=>!GameManager.IsBatchMode&&IsCoil(InventoryManager.ActiveHandSlot?.Get());
        internal string ContactName(CabinetWireEnd e)
        {if(Lamps.Any(l=>l.ReferenceId==e.Owner))return "Cabinet Light POWER IN (50 W)";if(e.Owner==0&&CabinetPorts.Combiner(Owner.PrefabName))return e.Contact==1?"Output":e.Contact==0?"Input 1":e.Contact==4?"Input 2":"Input 3";if(Contactors.Any(c=>c.ReferenceId==e.Owner))return "Smart Output OUT — A1 or display Door Bridge (Core powered)";if(DialIds.Contains(e.Owner))return "Door Dial DATA";if(DisplayIds.Contains(e.Owner))return "Smart Door Display DATA IN";if(SmartIds.Contains(e.Owner))return SwitchboardNames.SmartCoreTitle+" POWER IN";if(StationBatteries.Any(t=>t.ReferenceId==e.Owner))return "Battery "+(e.Contact==0?"IN":"OUT");if(Transformers.Any(t=>t.ReferenceId==e.Owner))return "Transformer "+(e.Contact==0?"IN":"OUT (limited)");var m=Breakers.FirstOrDefault(b=>b.ReferenceId==e.Owner);if(m!=null&&m.IsContactor)return e.Contact==2?"Contactor A1 (top right)":e.Contact==0?"Contactor IN (top left)":m.HasNormallyClosedContact?(e.Contact==ContactorCircuit.NcPin?"Contactor NC (bottom right)":"Contactor NO (bottom left)"):"Contactor OUT (bottom)";if(m!=null&&m.IsSmartOutputModule)return "Smart Net DATA";return m!=null&&m.IsDoorBridge?"Bridge "+(e.Contact==2?"plate":"door")+" (through)":m!=null&&m.IsDoorLed?"LED "+(e.IsSource?"OUT":"IN"):e.ToString();}
        private int Capacity(CabinetWireEnd e)
        {
            if(Lamps.Any(l=>l.ReferenceId==e.Owner))return 1;
            if(e.Owner==0)return CabinetPorts.Combiner(Owner.PrefabName)&&e.Contact==1?CabinetPorts.InputCount(Owner.PrefabName):e.Capacity;
            var module=Breakers.FirstOrDefault(m=>m.ReferenceId==e.Owner);
            return PowerContactCapacity.Get(e.Contact,Transformers.Any(t=>t.ReferenceId==e.Owner)||StationBatteries.Any(t=>t.ReferenceId==e.Owner)||module!=null&&!module.IsDoorPart&&!module.IsSmartModule&&!module.IsSmartOutputModule,
                module!=null&&module.IsDoorBridge,module!=null&&module.IsContactor);
        }
        private IEnumerable<long> NetIds=>Breakers.Where(m=>m.IsSmartOutputModule&&!m.IsBeingDestroyed).Select(m=>m.ReferenceId);
        private bool CanStartContact(CabinetWireEnd e)=>WireDataTap.CanStart(e,wires,Capacity(e));
        private void Changed(){migrationFailure=null;previewRouteJob.Cancel();HidePreview();revision++;routeRevision=-1;rebuild=true;Owner.NetworkUpdateFlags|=UpdateFlag;RefreshPower();}
        private void RefreshPower()
        {
            var modules=Breakers.ToArray();
            if(GameManager.RunSimulation)ApplyWireTrips(modules,Power.DrainTrips());
            if(GameManager.RunSimulation)
            {
                bool live=!Owner.IsCursor&&Owner.IsStructureCompleted&&Owner.GridController!=null&&(Owner.InputConnection?.GetCable()?.CableNetwork?.PotentialLoad??0)>0;
                var cells=modules.Where(m=>!m.IsBeingDestroyed&&m.IsBatteryModule&&!BatteryBranchLimit.IsBlocked(m.ReferenceId)&&m.Battery!=null&&m.Battery.PowerStored>0).Select(m=>m.ReferenceId).Concat(StationBatteries.Where(b=>b.Conducting&&b.PowerStored>0).Select(b=>b.ReferenceId));
                var energized=ContactorCircuit.Resolve(BaseCircuitWires,modules.Where(m=>!m.IsContactor&&m.Conducting&&(!m.IsBatteryModule||!BatteryBranchLimit.IsBlocked(m.ReferenceId))).Select(m=>m.ReferenceId).Concat(Transformers.Where(t=>t.Conducting).Select(t=>t.ReferenceId)).Concat(StationBatteries.Where(t=>t.Conducting).Select(t=>t.ReferenceId)),modules.Where(m=>m.IsContactor&&!m.IsBeingDestroyed).Select(m=>m.ReferenceId),modules.Where(m=>m.IsContactor&&m.Conducting).Select(m=>m.ReferenceId),live,cells,Contactors.Where(c=>c.Conducting).Select(c=>new CabinetWireEnd(c.ReferenceId,SmartContactorCircuit.OutputPin)).Concat(LiveInputs.Where(e=>e.Contact!=0)),modules.Where(m=>m.HasNormallyClosedContact&&!m.IsBeingDestroyed).Select(m=>m.ReferenceId));
                foreach(var contactor in modules.Where(m=>m.IsContactor))if(contactor.ContactorClosed!=energized.Contains(contactor.ReferenceId))
                {contactor.ContactorClosed=energized.Contains(contactor.ReferenceId);contactor.NetworkUpdateFlags|=32768;}
            }
            RefreshWirePower(modules);
            if(GameManager.RunSimulation&&Time.unscaledTime>=nextLedRefresh)
            {
                nextLedRefresh=Time.unscaledTime+.1f;
                var graph=CircuitWires.ToArray();var closed=PowerConducting.ToArray();
                bool inputLive=(Owner.InputConnection?.GetCable()?.CableNetwork?.PotentialLoad??0)>0;
                var cells=modules.Where(m=>m.IsBatteryModule&&!BatteryBranchLimit.IsBlocked(m.ReferenceId)&&m.Battery!=null&&m.Battery.PowerStored>0).Select(m=>m.ReferenceId).Concat(StationBatteries.Where(b=>b.Conducting&&b.PowerStored>0).Select(b=>b.ReferenceId)).ToArray();
                foreach(var led in modules.Where(m=>m.IsDoorLed)){bool on=DoorModuleLayout.Energized(led.ReferenceId,graph,closed,inputLive,cells,LiveInputs.Where(e=>e.Contact!=0));if(led.DoorLit!=on){led.DoorLit=on;led.NetworkUpdateFlags|=32768;}}
            }
        }
        internal void Tick()
        {
            if(Owner==null||Owner.IsCursor||!Owner.IsStructureCompleted)return;
            if(Time.unscaledTime>=nextRefresh)
            {
                nextRefresh=Time.unscaledTime+.15f;RefreshContacts();
                if(GameManager.RunSimulation)
                    foreach(var actor in pendingUntil.Where(p=>p.Value<Time.unscaledTime).Select(p=>p.Key).ToArray())
                    {pending.Remove(actor);pendingUntil.Remove(actor);Owner.NetworkUpdateFlags|=UpdateFlag;}
            }
            if(!Owner.IsOpen&&GameManager.RunSimulation&&pending.Count>0){pending.Clear();pendingUntil.Clear();Owner.NetworkUpdateFlags|=UpdateFlag;}
            if(needsReroute&&GameManager.RunSimulation&&!PlacementBoard.Loading&&Owner.RailBoard!=null&&Time.unscaledTime>=topologyReadyAt&&wires.All(w=>contacts.ContainsKey(w.From)&&contacts.ContainsKey(w.To)))RerouteLegacy();
            if(cleanupOnLoad&&GameManager.RunSimulation&&!PlacementBoard.Loading&&Owner.RailBoard!=null&&Owner.DoorBoard!=null&&Owner.BridgeBoard!=null&&Time.unscaledTime>=topologyReadyAt+5f)
            {
                // A removed prefab has no live board owner after loading completes.
                // Drop only orphaned connections, never a still-loading module.
                var smartIds=new HashSet<long>(SmartIds);
                var outputs=new HashSet<long>(Contactors.Select(c=>c.ReferenceId));
                var obsolete=wires.Where(w=>smartIds.Contains(w.From.Owner)||(smartIds.Contains(w.To.Owner)&&w.To.Contact!=0)||(WireDataTap.Stored(w)&&!WireDataTap.Allowed(w.From,w.To,NetIds))||!SmartContactorCircuit.Allowed(w.From,w.To,outputs,Breakers.Where(c=>c.IsContactor).Select(c=>c.ReferenceId),BridgeIds)).ToArray();
                if(obsolete.Length>0)
                {
                    if(!CanRefundWires(obsolete))return; // Keep saved wires until every kind can be refunded.
                    if(!RefundWires(obsolete,Owner.transform.position,null))return;
                    foreach(var wire in obsolete)wires.Remove(wire);
                    Changed();
                }
                var live=new HashSet<long>(Breakers.Select(m=>m.ReferenceId).Concat(DisplayIds).Concat(DialIds).Concat(Transformers.Select(t=>t.ReferenceId)).Concat(StationBatteries.Select(t=>t.ReferenceId)).Concat(SmartIds).Concat(Contactors.Select(c=>c.ReferenceId)));
                int removed=wires.RemoveAll(w=>(w.From.Owner!=0&&!live.Contains(w.From.Owner))||(w.To.Owner!=0&&!live.Contains(w.To.Owner)));
                cleanupOnLoad=false;
                if(removed>0){ModDiagnostics.Log("[Modular Switchboards] Removed "+removed+" orphaned wires after obsolete modules were discarded.");Changed();}
            }
            RefreshPower();
            if(rebuild){RebuildVisuals();rebuild=false;}
            bool show=Owner.IsOpen&&!Owner.HasInnerCover,tools=show&&LocalTools();
            if(visualRoot!=null)visualRoot.gameObject.SetActive(show);
            if(doorVisualRoot!=null)doorVisualRoot.gameObject.SetActive(Owner.IsOpen);if(rightDoorVisualRoot!=null)rightDoorVisualRoot.gameObject.SetActive(Owner.IsOpen);
            var human=GameManager.IsBatchMode?null:Human.LocalHuman;pending.TryGetValue(human!=null?human.ReferenceId:0,out var selected);
            foreach(var c in contacts.Values)
            {
                if(c.Marker==null)continue;
                if(!tools){if(c.Marker.activeSelf)c.Marker.SetActive(false);continue;}
                bool available=WireEndpointReady(c.End)&&CanStartContact(c.End)&&(selected==null||selected.Equals(c.End)||
                    CanConnectContacts(selected,c.End,out _));
                c.Marker.SetActive(tools&&available);
                var renderer=c.Marker.GetComponent<MeshRenderer>();
                if(renderer!=null)Color(renderer,c.End.Equals(selected)?ColorType.Yellow:c.End.IsNeutral?ColorType.Blue:c.End.IsSource?ColorType.Green:ColorType.Orange);
            }
            bool cutting=!GameManager.IsBatchMode&&InventoryManager.ActiveHandSlot?.Get() is WireCutter&&show;
            int hover=cutting&&CursorManager.Instance!=null?WireAt(CursorManager.CursorHit.point):-1;
            var paintedWire=!GameManager.IsBatchMode&&Owner.IsOpen&&InventoryManager.ActiveHandSlot?.Get() is ISprayer&&CursorManager.Instance!=null&&CursorManager.CursorThing==Owner
                ?PaintWireAt(CursorManager.CursorHit.point):null;
            RefreshWireColours(hover,paintedWire);
            if(!tools||!show||previewFrame!=Time.frameCount)HidePreview();
        }
        private void RefreshContacts()
        {
            if(!shapeReady&&Owner!=null){shapeReady=true;routingHalfWidth=(float)System.Math.Floor((CabinetShape.Width(Owner.PrefabName)*.5f-.032f+.000001f)/WireRouting.Step)*WireRouting.Step;routingHalfHeight=(float)System.Math.Floor((CabinetShape.Height(Owner.PrefabName)*.5f-.022f+.000001f)/WireRouting.Step)*WireRouting.Step;moduleReservations=WireModuleSpace.Reservations(CabinetShape.RailWidth(Owner.PrefabName),CabinetShape.Rows(Owner.PrefabName).Select(y=>y*.0018f)).ToArray();}

            if(Shell==null)return;
            var breakers=Breakers.Where(b=>!b.IsBeingDestroyed).ToArray();
            var transformers=Transformers.ToArray();
            var stationBatteries=StationBatteries.ToArray();
            var smart=SmartModules.Where(m=>!m.IsBeingDestroyed).ToArray();
            var contactors=Contactors.ToArray();
            var displays=DoorDisplays.ToArray();var dials=DoorDials.ToArray();
            var rails=Owner.RailBoard==null?new DinRail[0]:Owner.RailBoard.Structures.OfType<DinRail>().ToArray();
            var signature=string.Join(";",breakers.Select(b=>b.ReferenceId+":"+b.ModuleWidth+":"+(b.IsDoorPart?b.GetLocalGrid().ToString():Shell.InverseTransformPoint(b.Transform.position).ToString("F5"))).OrderBy(x=>x))+"|"+string.Join(";",rails.Select(r=>r.ReferenceId+":"+Shell.InverseTransformPoint(r.Transform.position).ToString("F5")).OrderBy(x=>x));
            signature+="|smart:"+string.Join(";",smart.Select(m=>m.ReferenceId+":"+Shell.InverseTransformPoint(m.transform.position).ToString("F5")));
            signature+="|transformers:"+string.Join(";",transformers.Select(t=>t.ReferenceId+":"+Shell.InverseTransformPoint(t.Transform.position).ToString("F5")));
            signature+="|contactors:"+string.Join(";",contactors.Select(c=>c.ReferenceId+":"+Shell.InverseTransformPoint(c.Transform.position).ToString("F5")));
            signature+="|batteries:"+string.Join(";",stationBatteries.Select(b=>b.ReferenceId+":"+Shell.InverseTransformPoint(b.transform.position).ToString("F5")));
            signature+="|doorDisplays:"+string.Join(";",displays.Select(d=>d.ReferenceId+":"+Owner.IsRightBoard(d.Board)+":"+d.GetLocalGrid()));
            signature+="|doorDials:"+string.Join(";",dials.Select(d=>d.ReferenceId+":"+Owner.IsRightBoard(d.Board)+":"+d.GetLocalGrid()));
            signature+="|lamps:"+string.Join(";",Lamps.Select(l=>l.ReferenceId+":"+l.GetLocalGrid()));
            if(topology==signature&&contacts.Count>0)return;
            topology=signature;topologyReadyAt=Time.unscaledTime+.5f;ClearVisuals();contacts.Clear();railObstacles.Clear();
            foreach(var lamp in Lamps)
            {
                var p=Shell.InverseTransformPoint(lamp.transform.TransformPoint(CabinetLampModel.Terminal(lamp)));
                var bounds3=CabinetWallMount.TransformedBounds(lamp.Bounds,Shell.worldToLocalMatrix*lamp.transform.localToWorldMatrix);
                var bounds=new WireRect(bounds3.min.x,bounds3.max.x,bounds3.min.y,bounds3.max.y);
                var aim=Shell.InverseTransformPoint(lamp.transform.TransformPoint(CabinetLampModel.TerminalAim(lamp)));
                AddContact(new CabinetWireEnd(lamp.ReferenceId,0),p,aim,new Vector3(p.x-.020f,p.y,WireRouting.Plane),bounds);
                railObstacles.Add(bounds);
            }
            foreach(var rail in rails)
            {
                var model=rail.transform.Find("DinRailModel");var mesh=model?.GetComponent<MeshFilter>()?.sharedMesh;
                if(model==null||mesh==null)continue;
                var bounds=mesh.bounds;var min=Vector3.one*float.MaxValue;var max=Vector3.one*float.MinValue;
                foreach(float x in new[]{bounds.min.x,bounds.max.x})foreach(float y in new[]{bounds.min.y,bounds.max.y})foreach(float z in new[]{bounds.min.z,bounds.max.z})
                {var p=Shell.InverseTransformPoint(model.TransformPoint(new Vector3(x,y,z)));min=Vector3.Min(min,p);max=Vector3.Max(max,p);}
                railObstacles.Add(new WireRect(min.x,max.x,min.y,max.y));
            }
            foreach(var terminal in Owner.GetComponentsInChildren<CabinetTerminalBlock>(true))
            {
                var p=Shell.InverseTransformPoint(terminal.FrontContactWorld(0));
                var center=Shell.InverseTransformPoint(terminal.transform.position);
                int index=(int)terminal.TerminalId;int slot=CabinetPorts.ContactSlot(Owner.PrefabName,index);
                // Upper reverse outputs need a longer straight entry before the
                // route turns upward; keep the turn clear of its own fixed lead.
                float exitOffset=slot==0?.033f:CabinetLayout.Reversed(Owner.PrefabName)&&slot>0?.033f:.027f;
                AddContact(new CabinetWireEnd(0,index),p,Shell.InverseTransformPoint(terminal.transform.TransformPoint(terminal.SelectionPoint)),new Vector3(center.x+(CabinetLayout.Reversed(Owner.PrefabName)&&slot>0&&!CabinetShape.Medium(Owner.PrefabName)?-Math.Sign(center.x)*.024f:0),center.y+(center.y>0?-exitOffset:exitOffset),WireRouting.Plane),
                    new WireRect(center.x-.036f,center.x+.036f,center.y-.016f,center.y+.016f));
            }
            foreach(var dial in dials){
                bool right=Owner.IsRightBoard(dial.Board);var frame=DoorModules.Frame(Owner,right);if(frame==null)continue;
                var center=frame.InverseTransformPoint(dial.transform.position);var bounds=new WireRect(center.x-.021f,center.x+.021f,center.y-.027f,center.y+.027f);
                var entry=frame.InverseTransformPoint(dial.transform.TransformPoint(new Vector3(0,.023f,-.030f)));
                var aim=frame.InverseTransformPoint(dial.transform.TransformPoint(new Vector3(0,.016f,-.0385f)));
                var end=new CabinetWireEnd(dial.ReferenceId,0);AddContact(end,entry,aim,new Vector3(entry.x,center.y+.042f,.043f),bounds);contacts[end].Door=true;contacts[end].Leaf=right?1:0;
            }
            foreach(var display in displays){
                bool right=Owner.IsRightBoard(display.Board);var frame=DoorModules.Frame(Owner,right);if(frame==null)continue;
                var center=frame.InverseTransformPoint(display.transform.TransformPoint(new Vector3(.05f,0,0)));
                var bounds=new WireRect(center.x-.09f,center.x+.09f,center.y-.038f,center.y+.038f);
                var entry=frame.InverseTransformPoint(display.transform.TransformPoint(new Vector3(DoorDisplayRearLayout.X,DoorDisplayRearLayout.WireY,DoorDisplayRearLayout.WireZ)));
                var aim=frame.InverseTransformPoint(display.transform.TransformPoint(new Vector3(DoorDisplayRearLayout.X,DoorDisplayRearLayout.Y,DoorDisplayRearLayout.ScrewZ)));
                var end=new CabinetWireEnd(display.ReferenceId,0);AddContact(end,entry,aim,new Vector3(entry.x,center.y+.052f,.043f),bounds);contacts[end].Door=true;contacts[end].Leaf=right?1:0;
            }
            foreach(var breaker in breakers)
            {
                if(breaker.IsDoorPart){AddDoorContacts(breaker);continue;}
                var model=breaker.transform.Find("DinBreakerModel");if(model==null)continue;
                var center=Shell.InverseTransformPoint(model.position);
                var p0=Shell.InverseTransformPoint(model.TransformPoint(new Vector3(-.0088f,-.0375f,0)));
                var p1=Shell.InverseTransformPoint(model.TransformPoint(new Vector3(.0088f+(breaker.ModuleWidth-1)*DinLayout.SlotPitch/DinBreakerModel.VisualScale.x,.0375f,0)));
                var bounds=new WireRect(Mathf.Min(p0.x,p1.x),Mathf.Max(p0.x,p1.x),Mathf.Min(p0.y,p1.y),Mathf.Max(p0.y,p1.y));
                foreach(int pin in breaker.HasNormallyClosedContact?new[]{0,1,2,ContactorCircuit.NcPin}:breaker.IsContactor?new[]{0,1,2}:breaker.IsSmartOutputModule?new[]{0}:new[]{0,1})
                {
                    // Keep logical contact 0 for saved wires; only its physical entry moves down.
                    int physicalPin=breaker.IsSmartOutputModule?1:pin==2?0:pin==ContactorCircuit.NcPin?1:pin;
                    float contactX=breaker.ContactOffsetX+(breaker.IsContactor?(pin==0?.004f:pin==2?-.004f:breaker.HasNormallyClosedContact?(pin==1?.004f:-.004f):0):0);
                    var p=Shell.InverseTransformPoint(model.TransformPoint(Vector(WireContactLayout.BreakerEntry(physicalPin))+Vector3.right*contactX));
                    var exit=new Vector3(p.x,physicalPin==0?bounds.Top+.015375f:bounds.Bottom-.015375f,WireRouting.Plane);
                    AddContact(new CabinetWireEnd(breaker.ReferenceId,pin),p,Shell.InverseTransformPoint(model.TransformPoint(Vector(WireContactLayout.BreakerAim(physicalPin))+Vector3.right*contactX)),exit,bounds);
                }
            }
            foreach(var transformer in transformers)
            {
                var bounds3=CabinetWallMount.TransformedBounds(transformer.Bounds,Shell.worldToLocalMatrix*transformer.transform.localToWorldMatrix);
                var bounds=new WireRect(bounds3.min.x,bounds3.max.x,bounds3.min.y,bounds3.max.y);
                foreach(int pin in new[]{0,1})
                {
                    var p=Shell.InverseTransformPoint(transformer.transform.TransformPoint(pin==0?transformer.InternalInput:transformer.InternalOutput));
                    float rx=(p.x-(bounds.Left+bounds.Right)*.5f)/Mathf.Max(.001f,(bounds.Right-bounds.Left)*.5f),ry=(p.y-(bounds.Bottom+bounds.Top)*.5f)/Mathf.Max(.001f,(bounds.Top-bounds.Bottom)*.5f);
                    bool lateral=Mathf.Abs(rx)>Mathf.Abs(ry);float side=lateral?(rx<0?-1:1):0;
                    var exit=lateral?new Vector3(side<0?bounds.Left-.015375f:bounds.Right+.015375f,p.y,WireRouting.Plane):new Vector3(p.x,ry<0?bounds.Bottom-.015375f:bounds.Top+.015375f,WireRouting.Plane);
                    var end=new CabinetWireEnd(transformer.ReferenceId,pin);AddContact(end,p,Shell.InverseTransformPoint(transformer.transform.TransformPoint(pin==0?transformer.InternalInputAim:transformer.InternalOutputAim)),exit,bounds);contacts[end].LeadSide=side;
                }
            }
            foreach(var battery in stationBatteries)
            {
                var b=CabinetWallMount.TransformedBounds(battery.ModelBounds,Shell.worldToLocalMatrix*battery.transform.localToWorldMatrix);
                var bounds=new WireRect(b.min.x,b.max.x,b.min.y,b.max.y);
                for(int pin=0;pin<2;pin++)
                {
                    var p=Shell.InverseTransformPoint(battery.transform.TransformPoint(pin==0?battery.InternalInput:battery.InternalOutput));
                    var exit=new Vector3(p.x,pin==0?Mathf.Max(p.y,bounds.Top)+.015375f:Mathf.Min(p.y,bounds.Bottom)-.015375f,WireRouting.Plane);
                    var aim=Shell.InverseTransformPoint(battery.transform.TransformPoint(pin==0?battery.InternalInputAim:battery.InternalOutputAim));
                    AddContact(new CabinetWireEnd(battery.ReferenceId,pin),p,aim,exit,bounds);
                }
            }
            foreach(var contactor in contactors)
            {
                var model=contactor.transform.Find("DinBreakerModel");if(model==null)continue;
                var p0=Shell.InverseTransformPoint(model.TransformPoint(new Vector3(-.0088f,-.0375f,0)));var p1=Shell.InverseTransformPoint(model.TransformPoint(new Vector3(.0088f+(SmartContactor.SlotCount-1)*DinLayout.SlotPitch/DinBreakerModel.VisualScale.x,.0375f,0)));
                var bounds=new WireRect(Mathf.Min(p0.x,p1.x),Mathf.Max(p0.x,p1.x),Mathf.Min(p0.y,p1.y),Mathf.Max(p0.y,p1.y));
                for(int pin=SmartContactorCircuit.OutputPin;pin<=SmartContactorCircuit.OutputPin;pin++)
                {
                    int physical=1;float x=SmartContactor.CenterX;
                    var entry=Shell.InverseTransformPoint(model.TransformPoint(Vector(WireContactLayout.BreakerEntry(physical))+Vector3.right*x));
                    var aim=Shell.InverseTransformPoint(model.TransformPoint(Vector(WireContactLayout.BreakerAim(physical))+Vector3.right*x));
                    AddContact(new CabinetWireEnd(contactor.ReferenceId,pin),entry,aim,new Vector3(entry.x,physical==0?bounds.Top+.015375f:bounds.Bottom-.015375f,WireRouting.Plane),bounds);
                }
            }
            foreach(var module in smart)
            {
                var model=module.transform.Find("DinBreakerModel");if(model==null)continue;
                var p0=Shell.InverseTransformPoint(model.TransformPoint(new Vector3(-.0088f,-.0375f,0)));
                var p1=Shell.InverseTransformPoint(model.TransformPoint(new Vector3(.0088f+3*DinLayout.SlotPitch/DinBreakerModel.VisualScale.x,.0375f,0)));
                var bounds=new WireRect(Mathf.Min(p0.x,p1.x),Mathf.Max(p0.x,p1.x),Mathf.Min(p0.y,p1.y),Mathf.Max(p0.y,p1.y));
                for(int pin=0;pin<1;pin++)
                {
                    var p=Shell.InverseTransformPoint(model.TransformPoint(Vector(WireContactLayout.BreakerEntry(pin))+Vector3.right*DinSmartLayout.CenterX));
                    var exit=new Vector3(p.x,pin==0?bounds.Top+.015375f:bounds.Bottom-.015375f,WireRouting.Plane);
                    AddContact(new CabinetWireEnd(module.ReferenceId,pin),p,Shell.InverseTransformPoint(model.TransformPoint(Vector(WireContactLayout.BreakerAim(pin))+Vector3.right*DinSmartLayout.CenterX)),exit,bounds);
                }
            }
            if(GameManager.RunSimulation&&migrationFailure==null)
            {
                var batteryIds=new HashSet<long>(breakers.Where(b=>b.IsBatteryModule||b.IsDoorPart||b.IsSmartOutputModule).Select(b=>b.ReferenceId).Concat(smart.Select(m=>m.ReferenceId)).Concat(contactors.Select(m=>m.ReferenceId)).Concat(transformers.Select(t=>t.ReferenceId)).Concat(stationBatteries.Select(t=>t.ReferenceId)).Concat(displays.Select(d=>d.ReferenceId)).Concat(dials.Select(d=>d.ReferenceId)).Concat(Lamps.Select(l=>l.ReferenceId)));
                foreach(var wire in wires)
                {
                    var points=Expand(wire.Points);
                    if((wire.From.Owner==0||batteryIds.Contains(wire.From.Owner))&&contacts.TryGetValue(wire.From,out var from)&&(points[0]-Point(from.Position)).Squared>.000001f)needsReroute=true;
                    if((wire.To.Owner==0||batteryIds.Contains(wire.To.Owner))&&contacts.TryGetValue(wire.To,out var to)&&(points[points.Length-1]-Point(to.Position)).Squared>.000001f)needsReroute=true;
                }
            }
            // References may not be loaded yet: do not prune saved wires until a real deconstruction event.
            revision++;routeRevision=-1;rebuild=true;

        }
        private void AddDoorContacts(DinBreaker module)
        {
            bool right=Owner.IsRightBoard(module.Board);var frame=DoorModules.Frame(Owner,right);if(frame==null)return;
            if(module.IsDoorBridge)
            {
                float y=Shell.InverseTransformPoint(module.transform.position).y;
                float x=Shell.InverseTransformPoint(module.transform.position).x,side=right?-1:1;
                float doorShift=CabinetShape.DoorBridgeShift(Owner.PrefabName);
                for(int pin=2;pin<4;pin++)
                {
                    bool door=pin==3;var end=new CabinetWireEnd(module.ReferenceId,pin);
                    var pos=new Vector3(door?side*(.163f-doorShift):x+side*.009f,y,door?.0114f:.0244f);
                    var aim=new Vector3(door?side*(.1678f-doorShift):x+side*.0042f,y,door?.01956f:.03256f);
                    var exit=new Vector3(door?side*(.153f-doorShift):x+side*.024f,y,door?.043f:WireRouting.Plane);
                    var body=door?new WireRect(right?-.181f+doorShift:.164f-doorShift,right?-.164f+doorShift:.181f-doorShift,y-.011f,y+.011f):new WireRect(x-.009f,x+.008f,y-.011f,y+.011f);
                    AddContact(end,pos,aim,exit,body);contacts[end].Door=door;contacts[end].Leaf=right?1:0;contacts[end].LeadSide=door?-side:side;
                }
                return;
            }
            var center=frame.InverseTransformPoint(module.transform.position);var box=new WireRect(center.x-.019f,center.x+.019f,center.y-.024f,center.y+.024f);
            for(int pin=0;pin<2;pin++)
            {
                float sign=pin==0?1:-1;var entry=frame.InverseTransformPoint(module.transform.TransformPoint(new Vector3(0,sign*.023f,-.030f)));
                var aim=frame.InverseTransformPoint(module.transform.TransformPoint(new Vector3(0,sign*.016f,-.0385f)));
                var end=new CabinetWireEnd(module.ReferenceId,pin);AddContact(end,entry,aim,new Vector3(entry.x,center.y+sign*.043f,.043f),box);contacts[end].Door=true;contacts[end].Leaf=right?1:0;
            }
        }
        private void AddContact(CabinetWireEnd end,Vector3 position,Vector3 aim,Vector3 exit,WireRect bounds)
        {contacts[end]=new Contact{End=end,Position=position,Aim=aim,Exit=exit,Bounds=bounds};}
        private bool TryContact(Attack attack,out Contact contact)
        {
            contact=null;if(Shell==null)return false;
            var p=attack.Position;float best=.016f*.016f;
            foreach(var c in contacts.Values){float distance=(p-Frame(c).TransformPoint(c.Aim)).sqrMagnitude;if(distance<best){best=distance;contact=c;}}
            return contact!=null;
        }
        internal bool ContainsInteractionPoint(Vector3 world)
        {
            if(Shell==null)return false;var p=Shell.InverseTransformPoint(world);
            if(Mathf.Abs(p.x)<CabinetShape.Width(Owner.PrefabName)*.5f-.01f&&Mathf.Abs(p.y)<CabinetShape.Height(Owner.PrefabName)*.5f-.01f&&p.z>=0&&p.z<.16f)return true;
            foreach(var frame in new[]{DoorFrame,DoorModules.Frame(Owner,true)})if(frame!=null){var q=frame.InverseTransformPoint(world);if(Mathf.Abs(q.x)<.19f&&Mathf.Abs(q.y)<CabinetShape.Height(Owner.PrefabName)*.5f-.02f&&q.z>=-.003f&&q.z<.09f)return true;}return false;
        }
        internal bool TryAttack(Attack attack,bool doAction,out Thing.DelayedActionInstance result)
        {
            result=null;
            if(attack.SourceItem is ISprayer sprayer&&TryPaintWire(attack,sprayer,doAction,out result))return true;
            bool cutting=attack.SourceItem is WireCutter;
            var coil=IsCoil(attack.SourceItem)?attack.SourceItem as Stackable:null;
            if(!cutting&&coil==null)return false;
            if(Owner.HasInnerCover){result=new Thing.DelayedActionInstance{Duration=0};result.Fail("Remove the inner cover with a wrench first.");return true;}
            HidePreview();
            result=new Thing.DelayedActionInstance{Duration=0};
            if(Owner.IsCursor||!Owner.IsStructureCompleted||!Owner.IsOpen){result.Fail("Open the completed cabinet first.");return true;}
            var actor=attack.SourceItem.RootParentHuman;
            if(actor==null){result.Fail("Hold a cable coil to connect, or wire cutters to remove a wire.");return true;}
            if((actor.Transform.position-Owner.Transform.position).sqrMagnitude>16f){result.Fail("Move closer to the cabinet.");return true;}
            RefreshContacts();
            if(migrationFailure!=null)result.AppendStateMessage(migrationFailure);
            long actorId=actor.ReferenceId;
            if(!cutting&&attack.IsDestroy)
            {
                result.ActionMessage="Cancel wire selection";
                if(doAction&&GameManager.RunSimulation){pending.Remove(actorId);pendingUntil.Remove(actorId);Owner.NetworkUpdateFlags|=UpdateFlag;}
                return true;
            }
            if(cutting)
            {
                result.ActionMessage="Cut internal wire";
                int index=WireAt(attack.Position);
                if(index<0){result.Fail("Aim at an internal wire to cut it.");return true;}
                result.ActionMessage=wires[index].Burnt?"Remove burnt "+CabinetWireKinds.Title(wires[index].CableKind)+" wire (no coil recovery)":"Cut "+CabinetWireKinds.Title(wires[index].CableKind)+" internal wire";
                var refund=CabinetCableCoils.RefundPrefab(wires[index].CableKind);
                if(refund==null&&!wires[index].Burnt){result.Fail("Cable coil prefab unavailable.");return true;}
                if(doAction&&GameManager.RunSimulation)
                {
                    if(!CabinetWireRefund.TryRefund(new[]{wires[index]},attack.Position,attack.OtherHand)){result.Fail("Could not return the coloured coil.");return true;}
                    wires.RemoveAt(index);pending.Remove(actorId);pendingUntil.Remove(actorId);Changed();
                }
                return true;
            }
            if(!TryContact(attack,out var target)){result.Fail("Choose a highlighted contact. Right click cancels; wire cutters remove a wire.");return true;}
            if(!WireEndpointReady(target.End)){result.Fail("Complete the module before connecting cables.");return true;}
            if(!CanStartContact(target.End)){result.Fail("Contact occupied.");return true;}
            if(!pending.TryGetValue(actorId,out var selected))
            {
                result.ActionMessage="Select "+ContactName(target.End);
                if(doAction&&GameManager.RunSimulation){pending[actorId]=target.End;pendingUntil[actorId]=Time.unscaledTime+60;Owner.NetworkUpdateFlags|=UpdateFlag;}
                return true;
            }
            if(selected.Equals(target.End))
            {
                result.ActionMessage="Cancel wire selection";
                if(doAction&&GameManager.RunSimulation){pending.Remove(actorId);pendingUntil.Remove(actorId);Owner.NetworkUpdateFlags|=UpdateFlag;}
                return true;
            }
            if(!contacts.ContainsKey(selected)){result.Fail("Selected contact no longer exists. Select it again.");if(doAction&&GameManager.RunSimulation){pending.Remove(actorId);Owner.NetworkUpdateFlags|=UpdateFlag;}return true;}
            if(!CanConnectContacts(selected,target.End,out var reason)){result.Fail(reason);return true;}
            if(wires.Count>=64){result.Fail("Cabinet wire capacity reached.");return true;}
            if(coil.Quantity<1){result.Fail("One cable coil unit is required.");return true;}
            CabinetCableCoils.TryKind(coil,out var cableKind);
            WireCircuit.Orient(selected,target.End,out var from,out var to);
            if(routeRevision!=revision||!from.Equals(routeFrom)||!to.Equals(routeTo)||routeKind!=cableKind)
            {
                if(!doAction)
                {
                    if(!PollPreviewRoute(from,to,cableKind)){result.ActionMessage="Calculating cable route";result.Fail("Calculating a clear route...");return true;}
                }
                else
                {
                    // A local preview normally supplies the cached result. A cold
                    // authoritative server can still validate a committed action.
                    routeFrom=from;routeTo=to;routeKind=cableKind;routeRevision=revision;route=MakeRoute(from,to,out routeSlot,out routeFailure,cableKind);
                }
            }
            result.ActionMessage="Wire ("+CabinetWireKinds.Title(cableKind)+") "+ContactName(from)+" -> "+ContactName(to);
            result.AppendStateMessage("Rated load: "+(CabinetCableCoils.Rating(cableKind)/1000f).ToString("0.###")+" kW.");
            if(route==null){result.Fail(routeFailure??"No clear route. Move a wire or a breaker first.");return true;}
            int colour=CabinetWireRefund.CoilColour(coil);
            if(!doAction)ShowPreview(route,cableKind,colour);
            if(doAction&&GameManager.RunSimulation)
            {
                if(coil.RemoveQuantity(1)!=1){result.Fail("Cable coil is empty.");return true;}
                wires.Add(new CabinetWireSaveData{From=from,To=to,InputSlot=routeSlot,RouteVersion=CurrentRouteVersion,CableUnits=1,CableKind=cableKind,ColorIndex=colour,Points=Flatten(route)});
                pending.Remove(actorId);pendingUntil.Remove(actorId);Changed();
            }
            return true;
        }
        private int WireAt(Vector3 world,float radius=.012f)
        {
            float best=radius*radius;int found=-1;
            for(int i=0;i<wires.Count;i++){var frame=WireFrame(wires[i]);if(frame==null)continue;var p=Point(frame.InverseTransformPoint(world));var path=Expand(wires[i].Points);for(int j=1;j<path.Length;j++){float distance=WireRouting.SegmentDistanceSquared(p,p,path[j-1],path[j]);if(distance<best){best=distance;found=i;}}}return found;
        }
        private WireRoutePlanner CaptureRoutePlanner()
        {
            var planner=new WireRoutePlanner{prefabName=Owner.PrefabName,routingHalfWidth=routingHalfWidth,routingHalfHeight=routingHalfHeight,moduleReservations=(WireRect[])moduleReservations.Clone()};
            foreach(var c in contacts.Values)
            {
                var end=new CabinetWireEnd(c.End.Owner,c.End.Contact);
                planner.contacts[end]=new WireRoutePlanner.Contact{End=end,Position=Point(c.Position),Exit=Point(c.Exit),Bounds=c.Bounds,Door=c.Door,Leaf=c.Leaf,LeadSide=c.LeadSide};
                planner.capacities[end]=Capacity(c.End)+(WireDataTap.Output(end)?1:0); // geometry slots only; power capacity remains unchanged
            }
            planner.railObstacles.AddRange(railObstacles);
            foreach(var w in wires)planner.wires.Add(new CabinetWireSaveData{From=new CabinetWireEnd(w.From.Owner,w.From.Contact),To=new CabinetWireEnd(w.To.Owner,w.To.Contact),Points=(float[])w.Points.Clone(),CableKind=w.CableKind,InputSlot=w.InputSlot});
            return planner;
        }
        private WirePoint[] MakeRoute(CabinetWireEnd from,CabinetWireEnd to,out int slot,out string failure,CabinetWireKind kind=CabinetWireKind.Normal)
            =>CaptureRoutePlanner().MakeRoute(from,to,out slot,out failure,kind);
        internal bool WouldBlockModule(PlacementBoard board,Grid3 position,int width=1)
        {
            if(Shell==null)return false;
            var c=Shell.InverseTransformPoint(board.GridToWorld(position));
            var first=WireModuleSpace.At(c.x,c.y);var last=WireModuleSpace.At(c.x+(width-1)*DinLayout.SlotPitch,c.y);
            var r=new WireRect(first.Left,last.Right,first.Bottom,first.Top);
            return wires.Where(w=>!IsDoorWire(w)).Any(w=>{var p=Expand(w.Points);for(int i=1;i<p.Length;i++)if(WireRouting.SegmentHitsRect(p[i-1],p[i],r,WireVisualProfiles.Get(w.CableKind).Radius+.001f))return true;return false;});
        }
        internal bool WouldBlockRail(PlacementBoard board,Grid3 position)
        {
            if(Shell==null)return false;
            var center=Shell.InverseTransformPoint(board.GridToWorld(position));
            var bounds=new WireRect(center.x-.162f,center.x+.162f,center.y-.0175f,center.y+.0175f);
            return wires.Where(w=>!IsDoorWire(w)).Any(w=>{var path=Expand(w.Points);for(int i=1;i<path.Length;i++)if(WireRouting.SegmentHitsRect(path[i-1],path[i],bounds,WireVisualProfiles.Get(w.CableKind).Radius+.001f))return true;return false;});
        }
        private void RerouteLegacy()
        {
            needsReroute=false;
            // A failed atomic migration needs an actual wiring change before retrying.
            // Periodic contact refresh must not restart synchronous A* on unchanged saved paths.
            if(migrationFailure!=null)return;
            if(WireRouteUpgrade.TryPromote(wires,end=>contacts.TryGetValue(end,out var c)?(WirePoint?)Point(c.Position):null,CurrentRouteVersion)){Changed();return;}
            var backup=wires.ToArray();wires.Clear();
            foreach(var old in backup.OrderBy(w=>w.From.Owner==0?0:1))
            {
                var path=MakeRoute(old.From,old.To,out var slot,out var failure,old.CableKind);
                if(path==null)
                {
                    wires.Clear();wires.AddRange(backup);migrationFailure="Existing route needs manual rewiring: "+failure;
                    Debug.LogWarning("[Modular Switchboards] "+migrationFailure+" Connections and coil quantities preserved.");return;
                }
                wires.Add(new CabinetWireSaveData{From=old.From,To=old.To,InputSlot=slot,RouteVersion=CurrentRouteVersion,CableUnits=old.CableUnits,CableKind=old.CableKind,ColorIndex=old.ColorIndex,Burnt=old.Burnt,Points=Flatten(path)});
            }
            migrationFailure=null;Changed();
            ModDiagnostics.Log("[Modular Switchboards] Existing wiring rerouted around reserved future module spaces without changing connections or coil quantities.");
        }
        private void HidePreview(){if(preview!=null)preview.SetActive(false);}
        private void ShowPreview(WirePoint[] path,CabinetWireKind kind,int colour)
        {
            if(GameManager.IsBatchMode||Shell==null)return;
            if(preview==null)
            {
                preview=new GameObject("WireRoutePreview"){layer=Owner.gameObject.layer};preview.transform.SetParent(Shell,false);
                preview.AddComponent<MeshFilter>();var renderer=preview.AddComponent<MeshRenderer>();renderer.sharedMaterial=CabinetGeometry.Materials[3];Color(renderer,ColorType.Yellow);
            }
            if(!ReferenceEquals(previewPath,path)||previewKind!=kind)
            {
                var filter=preview.GetComponent<MeshFilter>();if(filter.sharedMesh!=null)Destroy(filter.sharedMesh);
                filter.sharedMesh=WireMesh.Build(path,kind);
                var renderer=preview.GetComponent<MeshRenderer>();WireVisualGenerator.Surface(renderer,kind);Color(renderer,ColorType.Yellow);previewPath=path;previewKind=kind;
            }
            Color(preview.GetComponent<MeshRenderer>(),(ColorType)colour);
            preview.transform.SetParent(contacts.TryGetValue(routeFrom,out var c)?Frame(c):Shell,false);
            previewFrame=Time.frameCount;preview.SetActive(Owner.IsOpen);
        }
        private static bool CanRefundWires(IEnumerable<CabinetWireSaveData> batch)=>batch.Where(w=>!w.Burnt).All(w=>CabinetCableCoils.RefundPrefab(w.CableKind)!=null);
        internal bool CanRefundBreaker(long id)=>CanRefundWires(wires.Where(w=>w.From.Owner==id||w.To.Owner==id));
        private static bool RefundWires(IEnumerable<CabinetWireSaveData> batch,Vector3 position,Slot destination)=>CabinetWireRefund.TryRefund(batch,position,destination);
        internal void RefundAndRemoveBreaker(long id,Vector3 position,Slot destination)
        {
            if(!GameManager.RunSimulation)return;
            var batch=wires.Where(w=>w.From.Owner==id||w.To.Owner==id).ToArray();
            if(!CanRefundWires(batch))throw new InvalidOperationException("Cable coil prefab unavailable during module demolition");
            if(!RefundWires(batch,position,destination))throw new InvalidOperationException("Could not return coloured wire coils");RemoveBreaker(id);
        }
        internal void RemoveBreaker(long id)
        {
            if(wires.RemoveAll(w=>w.From.Owner==id||w.To.Owner==id)>0)Changed();
            foreach(var actor in pending.Where(p=>p.Value.Owner==id).Select(p=>p.Key).ToArray()){pending.Remove(actor);pendingUntil.Remove(actor);Owner.NetworkUpdateFlags|=UpdateFlag;}
            topology=null;
        }
        internal static float[] Flatten(IList<WirePoint> points){var result=new float[points.Count*3];for(int i=0;i<points.Count;i++){result[i*3]=points[i].X;result[i*3+1]=points[i].Y;result[i*3+2]=points[i].Z;}return result;}
        internal static WirePoint[] Expand(float[] values)
        {if(values==null||values.Length%3!=0)return new WirePoint[0];var result=new WirePoint[values.Length/3];for(int i=0;i<result.Length;i++)result[i]=new WirePoint(values[i*3],values[i*3+1],values[i*3+2]);return result;}
        internal CabinetWireSaveData[] Save()=>wires.ToArray();
        internal void Load(IEnumerable<CabinetWireSaveData> saved)
        {
            wires.Clear();pending.Clear();pendingUntil.Clear();cleanupOnLoad=GameManager.RunSimulation;
            // Boards may not have loaded yet. Retain the narrowly shaped data leaf;
            // deferred cleanup verifies its real Net owner after all boards are ready.
            var loaded=(saved??Enumerable.Empty<CabinetWireSaveData>()).Take(64).ToArray();
            var taps=loaded.Where(WireDataTap.Stored).Select(w=>w.To.Owner).Distinct().ToArray();
            foreach(var w in loaded)
                if(Valid(w)&&WireCircuit.CanConnect(w.From,w.To,wires,wires.SelectMany(x=>new[]{x.From.Owner,x.To.Owner}).Concat(new[]{w.From.Owner,w.To.Owner}).Where(id=>id!=0).Distinct(),out _,allowLegacyBypass:true,capacity:e=>e.Owner==0?(CabinetPorts.Combiner(Owner.PrefabName)&&e.Contact==1?CabinetPorts.InputCount(Owner.PrefabName):e.Capacity):(e.Contact==0||e.Contact==1||e.Contact==ContactorCircuit.NcPin||e.IsNeutral?3:1),dataTaps:taps))wires.Add(w);
            needsReroute=GameManager.RunSimulation&&wires.Any(w=>w.RouteVersion<CurrentRouteVersion);
            topology=null;revision++;routeRevision=-1;rebuild=true;
        }
        private bool Valid(CabinetWireSaveData w)=>w!=null&&ValidEnd(w.From)&&ValidEnd(w.To)&&(w.From.IsSource||w.From.IsNeutral||WireDataTap.Stored(w))&&(!w.To.IsSource||w.To.IsNeutral)&&w.Points!=null&&w.Points.Length>=6&&w.Points.Length<=1536&&w.Points.Length%3==0&&w.CableUnits==1&&CabinetWireKinds.Valid(w.CableKind)&&w.RouteVersion>=0&&w.RouteVersion<=CurrentRouteVersion&&w.InputSlot>=0&&w.InputSlot<16&&
            Expand(w.Points).All(p=>!float.IsNaN(p.X)&&!float.IsInfinity(p.X)&&!float.IsNaN(p.Y)&&!float.IsInfinity(p.Y)&&!float.IsNaN(p.Z)&&!float.IsInfinity(p.Z)&&Math.Abs(p.X)<=CabinetShape.Width(Owner?.PrefabName)*.5f-((w.From.IsNeutral||w.To.IsNeutral)?0f:.02f)&&Math.Abs(p.Y)<=CabinetShape.Height(Owner?.PrefabName)*.5f-.01f&&p.Z>=0&&p.Z<=.15f);
        private static bool ValidEnd(CabinetWireEnd e)=>e!=null&&e.Owner>=0&&e.Contact>=0&&(e.Contact<4||e.Owner==0&&(e.Contact==4||e.Contact==6)||e.Owner!=0&&e.Contact==ContactorCircuit.NcPin);
        internal void Write(RocketBinaryWriter writer)
        {
            writer.WriteInt32(-4);writer.WriteInt32(wires.Count);foreach(var w in wires){WriteEnd(writer,w.From);WriteEnd(writer,w.To);writer.WriteInt32(w.InputSlot);writer.WriteInt32(w.RouteVersion);writer.WriteInt32(w.ColorIndex);writer.WriteInt32((int)w.CableKind);writer.WriteBoolean(w.Burnt);writer.WriteInt32(w.Points.Length);foreach(var p in w.Points)writer.WriteSingle(p);}
            writer.WriteInt32(pending.Count);foreach(var p in pending){writer.WriteInt64(p.Key);WriteEnd(writer,p.Value);}
        }
        internal void Read(RocketBinaryReader reader)
        {
            var previouslyBurnt=new HashSet<string>(wires.Where(w=>w.Burnt).Select(WireIdentity));
            int header=reader.ReadInt32();bool damaged=header==-4;bool typed=damaged||header==-3;bool colored=typed||header==-2;int count=colored?reader.ReadInt32():header;if(count<0||count>64)throw new InvalidOperationException("Invalid cabinet wire count.");var loaded=new List<CabinetWireSaveData>();
            for(int i=0;i<count;i++){var w=new CabinetWireSaveData{From=ReadEnd(reader),To=ReadEnd(reader),InputSlot=reader.ReadInt32(),RouteVersion=reader.ReadInt32()};if(colored)w.ColorIndex=reader.ReadInt32();if(typed){w.CableKind=(CabinetWireKind)reader.ReadInt32();if(!CabinetWireKinds.Valid(w.CableKind))throw new InvalidOperationException("Invalid cabinet wire kind.");}if(damaged)w.Burnt=reader.ReadBoolean();int n=reader.ReadInt32();if(n<6||n>1536||n%3!=0)throw new InvalidOperationException("Invalid cabinet wire path.");w.Points=new float[n];for(int j=0;j<n;j++)w.Points[j]=reader.ReadSingle();loaded.Add(w);}Load(loaded);
            if(receivedWireState&&!GameManager.RunSimulation)foreach(var wire in wires.Where(w=>w.Burnt&&!previouslyBurnt.Contains(WireIdentity(w))))PlayWireRupture(wire);receivedWireState=true;
            count=reader.ReadInt32();if(count<0||count>128)throw new InvalidOperationException("Invalid cabinet wire selection count.");for(int i=0;i<count;i++){long actor=reader.ReadInt64();var end=ReadEnd(reader);if(ValidEnd(end))pending[actor]=end;}
        }
        private static void WriteEnd(RocketBinaryWriter writer,CabinetWireEnd end){writer.WriteInt64(end.Owner);writer.WriteInt32(end.Contact);}
        private static CabinetWireEnd ReadEnd(RocketBinaryReader reader)=>new CabinetWireEnd(reader.ReadInt64(),reader.ReadInt32());
        internal static bool IsWireVisual(string name)=>name=="InternalWire"||name=="WireContact"||name=="WireRoutePreview"||name=="WireRuptureEnds";
        private void Color(MeshRenderer renderer,ColorType color)
        {
            // Per-material blocks override renderer-wide blocks. Write at slot 0,
            // so a stale cabinet color can never mask this wire's own color.
            var block=new MaterialPropertyBlock();renderer.GetPropertyBlock(block,0);
            block.SetFloat(Thing.DiffuseIndexPropertyID,(int)color);block.SetColor(Thing.EMISSION_COLOR,UnityEngine.Color.black);
            renderer.SetPropertyBlock(block,0);
        }
        private void Register(Collider c){colliders.Add(c);Thing._colliderLookup[c]=Owner;}
        private void ClearVisuals()
        {
            if(preview!=null){preview.SetActive(false);var mesh=preview.GetComponent<MeshFilter>()?.sharedMesh;if(mesh!=null)Destroy(mesh);Destroy(preview);preview=null;previewPath=null;}
            foreach(var mesh in damageMeshes)if(mesh!=null)Destroy(mesh);damageMeshes.Clear();
            wireRenderers.Clear();
            foreach(var c in colliders)if(c!=null&&Thing._colliderLookup.TryGetValue(c,out var thing)&&thing==Owner)Thing._colliderLookup.Remove(c);colliders.Clear();
            foreach(var go in visuals)if(go!=null){go.SetActive(false);var filter=go.GetComponent<MeshFilter>();if(filter!=null&&go.name=="InternalWire")Destroy(filter.sharedMesh);Destroy(go);}visuals.Clear();
            if(visualRoot!=null){visualRoot.gameObject.SetActive(false);Destroy(visualRoot.gameObject);visualRoot=null;}
            if(doorVisualRoot!=null){doorVisualRoot.gameObject.SetActive(false);Destroy(doorVisualRoot.gameObject);doorVisualRoot=null;}
            if(rightDoorVisualRoot!=null){rightDoorVisualRoot.gameObject.SetActive(false);Destroy(rightDoorVisualRoot.gameObject);rightDoorVisualRoot=null;}
            foreach(var c in contacts.Values)c.Marker=null;
        }
        private void RebuildVisuals()
        {
            ClearVisuals();if(Shell==null||GameManager.IsBatchMode)return;
            visualRoot=new GameObject("InternalWiring").transform;visualRoot.SetParent(Shell,false);
            doorVisualRoot=new GameObject("DoorInternalWiring").transform;doorVisualRoot.SetParent(DoorFrame,false);
            var rightFrame=DoorModules.Frame(Owner,true);if(rightFrame!=null){rightDoorVisualRoot=new GameObject("RightDoorInternalWiring").transform;rightDoorVisualRoot.SetParent(rightFrame,false);}
            foreach(var wire in wires)
            {
                if(!contacts.ContainsKey(wire.From)||!contacts.ContainsKey(wire.To))continue;
                var path=Expand(wire.Points);if(path.Length<2)continue;
                var go=new GameObject("InternalWire"){layer=Owner.gameObject.layer};go.transform.SetParent(IsDoorWire(wire)?(contacts[wire.From].Leaf==1?rightDoorVisualRoot:doorVisualRoot):visualRoot,false);visuals.Add(go);
                Mesh damage=null;
                go.AddComponent<MeshFilter>().sharedMesh=wire.Burnt?CabinetWireDamage.Body(path,wire.CableKind,out damage):WireMesh.Build(path,wire.CableKind);
                // Body uses exactly the intact wire's renderer/material/paint path.
                var renderer=go.AddComponent<MeshRenderer>();WireVisualGenerator.Surface(renderer,wire.CableKind);Color(renderer,WireColor(wire));wireRenderers[wire]=renderer;
                if(damage!=null)
                {
                    damageMeshes.Add(damage);var ends=new GameObject("WireRuptureEnds"){layer=Owner.gameObject.layer};ends.transform.SetParent(go.transform,false);
                    ends.AddComponent<MeshFilter>().sharedMesh=damage;CabinetWireDamage.Surface(ends.AddComponent<MeshRenderer>());
                }
                for(int i=1;i<path.Length;i++)
                {
                    var a=Vector(path[i-1]);var b=Vector(path[i]);var delta=b-a;if(delta.sqrMagnitude<1e-10f)continue;
                    var hit=new GameObject("WireHit"){layer=Owner.gameObject.layer};hit.transform.SetParent(go.transform,false);hit.transform.localPosition=(a+b)*.5f;hit.transform.localRotation=Quaternion.LookRotation(delta);
                    var box=hit.AddComponent<BoxCollider>();box.size=new Vector3(.006f,.006f,delta.magnitude);Register(box);hit.AddComponent<CabinetWirePaintTarget>().Wire=wire;
                }
            }
            foreach(var c in contacts.Values)
            {
                var go=new GameObject("WireContact"){layer=Owner.gameObject.layer};go.transform.SetParent(Frame(c),false);go.transform.localPosition=c.Aim+Vector3.forward*.004f;
                go.AddComponent<MeshFilter>().sharedMesh=WireMesh.Contact;
                var marker=go.AddComponent<MeshRenderer>();marker.sharedMaterial=CabinetGeometry.Materials[3];WireVisualLighting.Apply(marker);var target=go.AddComponent<CabinetWireTarget>();target.End=c.End;
                var hit=go.AddComponent<SphereCollider>();hit.radius=.0075f;Register(hit);visuals.Add(go);c.Marker=go;go.SetActive(false);
            }
        }
        private void OnDestroy(){previewRouteJob.Dispose();ClearVisuals();}
    }
    internal static class WireMesh
    {
        private static Mesh contact;
        internal static Mesh Contact
        {
            get
            {
                if(contact!=null)return contact;
                var v=new[]{Vector3.right,Vector3.left,Vector3.up,Vector3.down,Vector3.forward,Vector3.back};
                contact=new Mesh{name="Switchboards.WireContact"};contact.vertices=v.Select(p=>p*.0045f).ToArray();
                contact.triangles=new[]{4,0,2,4,2,1,4,1,3,4,3,0,5,2,0,5,1,2,5,3,1,5,0,3};contact.RecalculateNormals();CabinetGeometry.ApplyNativeUv(contact);contact.RecalculateBounds();return contact;
            }
        }
        internal static Mesh Build(WirePoint[] path,CabinetWireKind kind=CabinetWireKind.Normal)=>WireVisualGenerator.Build(path,kind);
    }
}
