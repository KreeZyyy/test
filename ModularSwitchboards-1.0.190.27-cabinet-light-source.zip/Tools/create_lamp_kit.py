"""Independent lamp crate authoring; settle with settle_kit.py before baking."""
from pathlib import Path
import json,struct
r=Path(__file__).resolve().parents[1];shell=json.loads((r/'Art/RailKit/source.json').read_text())['shell']
for p in shell['vertices']:p[0]*=1.4
meshes={}
for width in (.59612436,.330):
 v=[];ts={}
 for name,role in [('Body','0'),('Diffuser','1')]:
  b=(r/f'Assets/CabinetLamp/{name}.meshbin').read_bytes();_,n,g=struct.unpack_from('<iii',b);o=12;start=len(v)
  for i in range(n):
   x,y,z,u,w=struct.unpack_from('<5f',b,o);o+=20
   v.append([x*width/1.528524,(z-.1086)*.13,(y-.1624)*.13])
  for i in range(g):
   c=struct.unpack_from('<i',b,o)[0];o+=4;ids=struct.unpack_from('<'+'i'*c,b,o);o+=c*4
   # x,z,y swaps handedness. Reverse winding so Unity sees the outer faces.
   for j in range(0,c,3):ts.setdefault(role,[]).extend(start+ids[j+k] for k in (0,2,1))
 low=min(p[1]for p in v)
 for p in v:p[1]-=low
 meshes[width]=dict(vertices=v,triangles=ts)
parts=[dict(name=f'Lamp{i}',mesh=meshes[w],metadata=dict(width=w))for i,w in enumerate([.59612436,.330,.330,.59612436,.330,.59612436,.330,.330])]
f=r/'Art/LampKit';f.mkdir(exist_ok=True)
(f/'source.json').write_text(json.dumps(dict(shell=shell,contents=dict(vertices=[],triangles={}))))
(f/'pile-input.json').write_text(json.dumps(dict(kind='ModuleKit',seed=1957,parts=parts,half_width=.342,half_depth=.232,corner_limit=.54,max_height=.34,tilt=.35)))
