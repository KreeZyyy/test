namespace ModularSwitchboards
{
    internal static class CabinetLampWiringGeometry
    {
        // The front lamp and fixed lead are not solid blockers in the plate routing
        // plane. Reserve only the real Door Bridge terminal footprint, not the
        // huge bounding box spanning plate terminal and front-mounted housing.
        internal static float PlateX(bool medium)=>medium?.300f:.177f;
        internal static float LeadSide(bool medium)=>medium?0f:-1f;
        internal static WirePoint FixedLeadControl(WirePoint start,bool medium)=>start+(medium?new WirePoint(.018f,0,.005f):new WirePoint(.003f,0,.050f));
        internal static WireRect PlateBounds(WirePoint center)=>new WireRect(center.X-.011f,center.X+.011f,center.Y-.012f,center.Y+.012f);
        internal static WirePoint Exit(WirePoint entry)=>new WirePoint(entry.X-.020f,entry.Y,WireRouting.Plane);
    }
}
