using System;using System.Linq;using ModularSwitchboards;
partial class RouteHarness
{
    internal static void RunCabinetLamp()
    {
        int checks=0;
        foreach(bool medium in new[]{false,true})foreach(var kind in new[]{CabinetWireKind.Normal,CabinetWireKind.Heavy,CabinetWireKind.SuperHeavy})
        {
            var h=new RouteHarness{Owner=new(){PrefabName=medium?"medium":"small"},routingHalfWidth=medium?.366f:.168f,routingHalfHeight=medium?.477f:.228f};
            h.moduleReservations=medium?WireModuleSpace.Reservations(.65f,new[]{-.27f,0,.27f}).ToArray():WireModuleSpace.Reservations(.35f,new[]{-.108f,.108f}).ToArray();
            if(medium)h.railObstacles.Add(new WireRect(-.325f,.325f,.2525f,.2875f));
            else h.railObstacles.Add(new WireRect(-.14175f,.14175f,.0905f,.1255f));
            float x=CabinetLampWiringGeometry.PlateX(medium),y=medium?.425f:.195f;
            var source=new CabinetWireEnd(10,1);var target=new CabinetWireEnd(80,0);
            h.PowerModules.Add(10);
            h.contacts[source]=new Contact{End=source,Position=new(0,medium?.219375f:.057375f,.043f),Exit=new(0,medium?.204f:.042f,WireRouting.Plane),Bounds=new(-.0198f,.0198f,medium?.219375f:.057375f,medium?.320625f:.158625f)};
            var entry=new WirePoint(x-.009f,y,.0244f);var exit=CabinetLampWiringGeometry.Exit(entry);
            var box=CabinetLampWiringGeometry.PlateBounds(new WirePoint(x,y,.013f));
            h.contacts[target]=new Contact{End=target,Position=new(entry.X,entry.Y,entry.Z),Exit=new(exit.X,exit.Y,exit.Z),Bounds=box,LeadSide=CabinetLampWiringGeometry.LeadSide(medium)};
            if(!medium)
            {
                if(x!=.177f||CabinetLampWiringGeometry.LeadSide(false)!=-1f)throw new Exception("Small terminal must sit on visual-left rim with inward wire entry");checks++;
                var start=new WirePoint(x+.009f,y,.0244f);var control=CabinetLampWiringGeometry.FixedLeadControl(start,false);
                if(control.X>.2f-.001f)throw new Exception("Small fixed lead bows outside cabinet");checks++;
                var lead=DoorModuleLayout.DoorFlexGeometry.Build(start,control,new WirePoint(.182f,.238f,.080f),new WirePoint(.162f,.238f,.080f));
                if(lead.Any(p=>p.X>.199f||p.X<.150f))throw new Exception("Small fixed lead must stay along outer edge");checks++;
            }
            if(!medium){if(h.moduleReservations.Any(r=>WireModuleSpace.Overlaps(r,box)))throw new Exception("small lamp terminal blocks a reserved module position");checks++;}
            if(box.Contains(exit,.004f))throw new Exception("lamp exit inside its own terminal obstacle");checks++;
            var path=h.MakeRoute(source,target,out _,out var failure,kind);
            if(path==null)throw new Exception("lamp "+(medium?"Medium":"Small")+" "+kind+": "+failure);checks++;
            if((path[path.Length-1]-entry).Squared>1e-10f)throw new Exception("lamp route misses terminal");checks++;
            // Same fixture with previous full lamp AABB: its own target is buried.
            var old=h.contacts[target].Bounds;h.contacts[target].Bounds=new WireRect(medium?-.298f:-.165f,medium?.305f:.172f,y-.012f,medium?.5f:.25f);h.railObstacles.Add(h.contacts[target].Bounds);
            if(h.MakeRoute(source,target,out _,out _,kind)!=null)throw new Exception("old full lamp bounds did not reproduce blocked target");checks++;
            h.contacts[target].Bounds=old;h.railObstacles.Clear();
        }
        Console.WriteLine(checks+" actual route-planner lamp checks passed (Small/Medium, normal/heavy/superheavy, old obstruction reproduced)");
    }
}
