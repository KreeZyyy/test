# Custom SoundAlert 0.2.3 — multiplayer status

This is an experimental server-catalog prototype, not a completed audio distribution system.

- Server join data contains IDs, labels, extensions, byte counts and SHA256 hashes.
- IDs are restricted to 100–199, at most 100 entries. Each encoded file is limited to 32 MiB, the catalog to 128 MiB of source files and labels to 96 characters. These limits do not bound decoded PCM memory.
- A remote client ignores its private local sounds directory. Audio can play only from a size/hash-verified file in `<persistentDataPath>/CustomSoundAlert/server-cache/<sha256>.<extension>`.
- Automatic file transfer, download progress and synchronized late-join playback are not implemented. Without a matching cached file, custom server audio is silent.
- Dedicated servers scan metadata and publish the catalog without discovering AudioManager or decoding clips.
- Catalog/role changes stop custom events, invalidate old registrations, release owned decoded clips and remove only their exact native lookup entries. Disconnect resets pending server metadata.
- The renamed mod/network identity requires the same Custom SoundAlert build on participating peers.

Automated checks cover manifest parsing, limits, Unicode, invalid entries, cache hashing, local-folder isolation, shared catalog preservation, ownership invalidation, cleanup and Update discovery behavior. Native API compilation passes. Live Unity joins, reconnects, SP→MP→SP transitions, dedicated-server playback and real FPS remain unverified for this build.

## Empty-server test in 0.2.3
One common ZIP is used on client and server and contains no audio. Server creates sounds beside the DLL at startup. Leave it empty to publish zero custom entries. The common ZIP leaves the existing local sounds folder untouched. Start SP, join empty DS, return to SP, then reconnect. Expect local custom sounds in SP and only vanilla on empty DS. No downloading is implemented. Missing-folder creation and empty manifest/context transitions passed fixtures; live DS join/return playback awaits the user test.
