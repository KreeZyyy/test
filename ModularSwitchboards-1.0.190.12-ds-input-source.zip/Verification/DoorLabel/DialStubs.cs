using System.Linq;using LibConstruct;using Assets.Scripts.GridSystem;namespace ModularSwitchboards{public class DoorDial:DoorSmartDisplay{  internal static DoorDial Target(PlacementBoard board,Grid3 p){
   var host=board?.PrimaryHost as SwitchboardCabinet;
   return host?.DoorBoardFor(board)?.Structures.OfType<DoorDial>().FirstOrDefault(d=>!d.IsBeingDestroyed&&!d.IsCursor&&d.IsStructureCompleted&&Same(board.WorldToGrid(d.transform.position),p));
  }
  private static bool Same(Grid3 a,Grid3 b)=>a.x==b.x&&a.y==b.y&&a.z==b.z;
}}