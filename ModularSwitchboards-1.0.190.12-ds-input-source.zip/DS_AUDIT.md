# Dedicated server audit — 1.0.190.4

Confirmed runtime evidence (1.0.190.3 user DS logs): owned IN/socket registered; embedded IC10 socket and all Smart/DIN/door prefabs prepared; 63-prefab preview/hitbox audit and registration passed; printer recipes verified; server Ready; save completed; IC10 rebound and user confirms execution; Smart Output indicators update. These observations do not establish every wiring/battery/paint/save-load combination.

## Fixed in this revision

- SimpleFabricatorBase.SetIcon is a world-space renderer/texture callback. Native code accesses ValidDynamicThings[CurrentIndex].Thumbnail.texture without a null check. Custom icon generation intentionally returns null in headless mode. A Harmony prefix now skips this visual method when batch mode or a Null graphics device is detected. It does not patch recipe selection, manufacturing, inventory, saves or network simulation. On a graphical client the original method executes. The log does not identify the exact selected recipe; no claim is made that the particular null object was proven from the log alone.
- SmallNativeBatteryFace.Subset previously copied GPU vertex buffers unconditionally. It now uses the existing CPU-only HeadlessMeshCopy.Selected path in headless mode, preserving native vertex channels and selected triangles. Graphical clients retain the existing path. The source must still be CPU readable; no substitute geometry is silently introduced.
- HeadlessGeometryAudit wording now distinguishes informational unreadable source meshes from registration failures, and notes that owned IN and embedded IC10 no longer read those source meshes.

## Other reviewed paths

- CabinetIcons, FittedCoverIcons and DinBatteryThumbnail already avoid thumbnail creation/readback on DS. LeverTextures already avoids GPU recoloring there. Portable cover texture cleanup checks ownership for null. No dummy texture generation was added to the server.
- NativeApcHolder and DinAnalyserModel already choose CPU mesh copies on DS. CabinetGeometry.ReadNativeMesh rejects unreadable native sources before GPU buffer access. CabinetWallMount can use bounds; optional APC UV/warning reads catch unavailable mesh data.
- Camera lookups in cabinet/nameplate/terminal labels tolerate a missing Camera.main. Labels also update colliders: they were not disabled wholesale, to retain server interaction behavior.
- NativeBatteryReference and NativeCableReference export helpers have no callers in current Source. No battery extraction was re-enabled.
- Native mesh reads still exist for APC-derived components, native battery faces, analyser, console bezel/indicator and door display geometry. Registration passed on the supplied server build; this does not guarantee future game revisions keep those sources CPU readable. This revision does not claim all model dependencies are baked.

## Validation

Native build: zero warnings/errors. 80 production headless/client shader/material/icon-prefix policy checks pass, covering batch/Null-device and normal graphics combinations. 16 existing production CPU-only selection/channel-preservation checks pass. ZIP contents and embedded assembly verified during packaging. No local Unity/DS runtime is available: repeat server startup to verify the two SetIcon exceptions are gone, and test manufacturing plus native battery construction if used. User installation remains a normal mod update; no server configuration/game DLL edits required.

## 1.0.190.5 join repair

Native join serialization writes interaction list indices; deserialization indexes the current list before construction state is read. Smart Core previously used shorter lists at stages 0/1 than stage 2. All three stages now share the same canonical ordered interaction table, selected before both SerializeOnJoin and DeserializeOnJoin. Slot collider, native lookup removal and IsInteractable still follow completion/cabinet access. No packet bytes or action-state values are discarded. Server and client must use this same revision. Also skips Stationpedia.AddConstructedBy on headless servers: the native UI-only page helper logs errors for intentionally absent server thumbnails. Client Stationpedia remains unchanged.

142 production join/index, slot access, cache, stage rollback and chip-preservation checks pass, including all nine server/client stage combinations; 80 graphics policy checks pass. Full Unity multiplayer reconnect still requires live testing.
