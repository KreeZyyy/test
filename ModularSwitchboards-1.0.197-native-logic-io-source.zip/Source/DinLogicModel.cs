using System;using System.Linq;using System.Reflection;using System.Collections.Generic;
using Assets.Scripts;using Assets.Scripts.Objects;using Assets.Scripts.Objects.Electrical;using Assets.Scripts.Objects.Motherboards;using Assets.Scripts.Util;using Assets.Scripts.UI;using HarmonyLib;using Rendering;using UnityEngine;using UnityEngine.Rendering;
namespace ModularSwitchboards {
 internal static class DinLogicModel {
  internal const float Center=.02025f;
  internal static Vector3 Entry(int pin)=>new Vector3(Center+(pin==0?.018f:pin==2?-.018f:0),pin==1?-.050625f:.050625f,.03335f);
  internal static Vector3 Aim(int pin)=>new Vector3(Entry(pin).x,pin==1?-.042f:.042f,.0685f);
  private static readonly MethodInfo Clone=AccessTools.Method(typeof(object),"MemberwiseClone");
  private sealed class Control {internal Interactable Meta;internal bool Physical;}
  private static void Surface(MeshRenderer r){r.sharedMaterials=CabinetGeometry.Materials;int[] palette={(int)ColorType.Black,(int)ColorType.Gray,(int)ColorType.White,(int)ColorType.Black,(int)ColorType.Gray};for(int i=0;i<5;i++){var b=new MaterialPropertyBlock();b.SetFloat(Thing.DiffuseIndexPropertyID,palette[i]);b.SetColor(Thing.EMISSION_COLOR,Color.black);r.SetPropertyBlock(b,i);}}
  private static void BlackPart(Transform parent,string name,Vector3 point,Vector3 size){var g=new GameObject(name){layer=parent.gameObject.layer};g.transform.SetParent(parent,false);g.transform.localPosition=point;g.AddComponent<MeshFilter>().sharedMesh=DinBreakerModel.ControlMesh(name,Vector3.zero,size);var r=g.AddComponent<MeshRenderer>();r.sharedMaterials=Enumerable.Repeat(CabinetGeometry.Materials[3],5).ToArray();var b=new MaterialPropertyBlock();b.SetFloat(Thing.DiffuseIndexPropertyID,(int)ColorType.Black);b.SetColor(Thing.EMISSION_COLOR,Color.black);r.SetPropertyBlock(b);}
  internal static void Install(LogicUnitBase m,string native,Transform storage){
   // Retain actions/state material colours only. No original mesh, collider or control object survives.
   var controls=m.Interactables.Select(i=>new Control{Meta=(Interactable)Clone.Invoke(i,null),Physical=i.Collider!=null}).ToArray();
   var stateMaterials=new Dictionary<string,Material>();foreach(var key in new[]{"powerOff","powerOn","errorEmissive","error"})stateMaterials[key]=(Material)AccessTools.Field(typeof(Objects.Electrical.LogicOnOffButton),key).GetValue(m.OnOffButton);
   foreach(var child in m.transform.Cast<Transform>().ToArray())UnityEngine.Object.DestroyImmediate(child.gameObject);
   foreach(var c in m.GetComponents<Collider>())UnityEngine.Object.DestroyImmediate(c);
   foreach(var c in m.GetComponents<MeshFilter>())UnityEngine.Object.DestroyImmediate(c);
   foreach(var c in m.GetComponents<Renderer>())UnityEngine.Object.DestroyImmediate(c);
   foreach(var c in m.GetComponents<Animator>())UnityEngine.Object.DestroyImmediate(c);
   ThingColliderCache.Reset(m);m.BaseAnimator=null;m.AnimComponents=new List<Effects.StateMaterialChanger>();m.BrokenBuildStates=new List<BrokenBuildState>();m.CustomNavMeshFilter=null;m.Slots=new List<Slot>();
   AccessTools.Field(typeof(Thing),"MaterialChanger").SetValue(m,null);
   var face=new GameObject("AuthoredLogicFace"){layer=m.gameObject.layer};face.transform.SetParent(m.transform,false);face.transform.localPosition=new Vector3(Center,0,0);face.AddComponent<MeshFilter>().sharedMesh=DinLogicFrontGeometry.Front(native);Surface(face.AddComponent<MeshRenderer>());
   var poses=DinLogicControlLayout.For(native);var actions=new List<Interactable>();
   foreach(var c in controls){var action=c.Meta;action.Parent=m;action.Collider=null;
    if(c.Physical){var pose=poses.Single(p=>p.Action==(int)action.Action);bool led=pose.Action==36;var go=new GameObject(led?"AuthoredLogicLED":"AuthoredLogicScrew"+pose.Action){layer=m.gameObject.layer};go.transform.SetParent(m.transform,false);go.transform.localPosition=new Vector3(Center+pose.X,pose.Y,.0818f);
     go.AddComponent<MeshFilter>().sharedMesh=led?DinLogicFrontGeometry.Lens():DinLogicFrontGeometry.Screw();var r=go.AddComponent<MeshRenderer>();Collider hit;
     if(led){var sphere=go.AddComponent<SphereCollider>();sphere.radius=.0042f;sphere.center=new Vector3(0,0,.0015f);hit=sphere;
      var controller=go.AddComponent<Objects.Electrical.LogicOnOffButton>();foreach(var entry in stateMaterials)AccessTools.Field(controller.GetType(),entry.Key).SetValue(controller,entry.Value);AccessTools.Field(controller.GetType(),"parentLogicUnit").SetValue(controller,m);AccessTools.Field(controller.GetType(),"buttonRenderer").SetValue(controller,r);AccessTools.Field(controller.GetType(),"buttonCollider").SetValue(controller,hit);m.OnOffButton=controller;r.sharedMaterials=new[]{stateMaterials["powerOff"],stateMaterials["powerOff"],stateMaterials["powerOff"],stateMaterials["powerOff"],stateMaterials["powerOff"]};
     }else{var click=go.AddComponent<BoxCollider>();click.center=new Vector3(0,0,.0015f);click.size=new Vector3(.0084f,.0084f,.006f);hit=click;Surface(r);}
     hit.isTrigger=true;action.Collider=hit;
    }actions.Add(action);
   }m.Interactables=actions;
   var body=new GameObject("DinBreakerModel"){layer=m.gameObject.layer};body.transform.SetParent(m.transform,false);body.transform.localScale=DinBreakerModel.VisualScale;
   var mesh=DinBreakerModel.Build(width:(DinLayout.SlotPitch*2-.0009f)/DinBreakerModel.VisualScale.x,centerX:Center/DinBreakerModel.VisualScale.x,plain:true,noTerminals:true);
   body.AddComponent<MeshFilter>().sharedMesh=mesh;var renderer=body.AddComponent<MeshRenderer>();renderer.sharedMaterials=CabinetGeometry.Materials;
   var box=body.AddComponent<BoxCollider>();box.center=mesh.bounds.center;box.size=mesh.bounds.size;
   m._staticColliders=new List<Collider>{box};m._dynamicColliders=new List<Collider>();m._selfColliders=new List<Collider>();
   for(int pin=0;pin<3;pin++){
    var go=new GameObject(pin==0?"LogicDataIn":pin==1?"LogicDataOut":"LogicPower"){layer=m.gameObject.layer};go.transform.SetParent(m.transform,false);go.transform.localPosition=Aim(pin);
    var screw=DinBreakerModel.ControlMesh("LogicTerminalScrew",Vector3.zero,new Vector3(.011f,.008f,.0018f));go.AddComponent<MeshFilter>().sharedMesh=screw;var sr=go.AddComponent<MeshRenderer>();sr.sharedMaterials=Enumerable.Repeat(CabinetGeometry.Materials[4],5).ToArray();var block=new MaterialPropertyBlock();block.SetFloat(Thing.DiffuseIndexPropertyID,(int)ColorType.Gray);block.SetColor(Thing.EMISSION_COLOR,Color.black);sr.SetPropertyBlock(block);
    BlackPart(go.transform,"ScrewRecess",new Vector3(0,0,-.0012f),new Vector3(.014f,.012f,.002f));
    BlackPart(go.transform,"ScrewSlot",new Vector3(0,0,.001f),new Vector3(.008f,.001f,.0003f));
    BlackPart(m.transform,"CableSocket"+pin,new Vector3(Entry(pin).x,Entry(pin).y+(pin==1?.00135f:-.00135f),Entry(pin).z),new Vector3(.014f,.003f,.012f));
    var h=go.AddComponent<BoxCollider>();h.size=new Vector3(.014f,.012f,.008f);m._staticColliders.Add(h);
    var c=m.OpenEnds[pin];var anchor=new GameObject("LogicCableEntry"+pin).transform;anchor.SetParent(m.transform,false);anchor.localPosition=Entry(pin);anchor.localRotation=Quaternion.LookRotation(pin==1?Vector3.up:Vector3.down,Vector3.forward);c.Transform=anchor;c.Collider=h;c.Parent=m;
   }
   m.Bounds=new Bounds(new Vector3(Center,0,.041f),new Vector3(.0801f,.10125f,.084f));m.GridBounds=new GridBounds(m);m.UseCellPosition=false;m.ForceGridBounds.Clear();m.StructureCollisionType=CollisionType.BlockCustom;m.SelectionDisplay=SelectionHighlightMethod.Bounds;m.SurfaceArea=.032f;m.UpgradePrefab=null;
   m.CustomColor=GameManager.GetColorSwatch((int)ColorType.White);m.EmissionColor=Color.black;DinBreakerModel.Refresh(m);
   m.HasColorState=false;m.MPBRenderers.Clear();m.PaintableMaterial=null;m.structureRenderMode=StructureRenderMode.Standard;
   m.Renderers=m.GetComponentsInChildren<MeshRenderer>(true).Select(rr=>new ThingRenderer(m,rr)).ToList();
   foreach(var c in m.Interactables)c.CacheBounds();
   var state=m.BuildStates[0];state.Visualizer=renderer;state.RendererInstance=null;state.StateMeshes=new List<Mesh>();state.Colliders=m.GetComponentsInChildren<Collider>(true).ToList();state.Interactables=m.Interactables;
   state.LinkedGameObjects=m.GetComponentsInChildren<Transform>(true).Where(t=>t!=m.transform).Select(t=>t.gameObject).ToList();state.RenderMode=BuildStateRenderMode.OnMineAndPreviousStates;
   AccessTools.Field(typeof(BuildState),"initialDrawData").SetValue(state,new DrawData{mesh=null,materials=new Material[0]});m.CacheStates(true);
   var all=ModelBlueprint.Build(m.transform,includeDisabled:true);FittedModelCollider.Install(m,all);foreach(var c in state.Colliders)if(c!=null&&!state.LinkedGameObjects.Contains(c.gameObject))state.LinkedGameObjects.Add(c.gameObject);
   var bp=new GameObject("DinLogicBlueprint"){layer=m.gameObject.layer};bp.transform.SetParent(storage,false);var f0=bp.AddComponent<MeshFilter>();f0.sharedMesh=all;var r0=bp.AddComponent<MeshRenderer>();r0.sharedMaterial=CabinetGeometry.Materials[4];var wire=bp.AddComponent<Wireframe>();wire.BlueprintTransform=bp.transform;wire.BlueprintBounds=all.bounds;wire.BlueprintMeshFilter=f0;wire.BlueprintRenderer=r0;bp.AddComponent<CabinetBlueprint>();m.Blueprint=bp;m.BlueprintOrientVector=Vector3.zero;
   // Fitted-body replacement can delete a box. Leave no serialized collider cache for clones to inherit.
   ThingColliderCache.Reset(m);DinLogicSurface.Restore(m);PrefabAudioOwner.Rebind(m);
  }
 }
}
