using Assets.Scripts.Objects;using UnityEngine;
namespace ModularSwitchboards {
 internal static class DinLogicPortHelpers {
  internal const float MaxSize=.018f;
  internal static void Fit(Structure cursor){
   if(!(cursor is IDinLogic)||!cursor.IsCursor)return;
   var logic=((IDinLogic)cursor).Logic;
   foreach(var port in logic.OpenEnds){var r=port.HelperRenderer;if(r==null||port.Transform==null)continue;
    r.transform.SetPositionAndRotation(port.Transform.position,port.Transform.rotation);
    var f=r.GetComponent<MeshFilter>();var size=f!=null&&f.sharedMesh!=null?Vector3.Scale(f.sharedMesh.bounds.size,r.transform.lossyScale):r.bounds.size;
    float longest=Mathf.Max(Mathf.Abs(size.x),Mathf.Max(Mathf.Abs(size.y),Mathf.Abs(size.z)));
    if(longest>.000001f)r.transform.localScale*=MaxSize/longest;
   }
  }
 }
}
