using System.Collections.Generic;using UnityEngine;
namespace ModularSwitchboards {
 // Authored in metres from the measured IN envelope, not read/copied from a game mesh.
 internal static class CabinetInputGeometry {
  internal const float Width=.100f,Height=.162f,CenterY=.0366f,Mouth=.034f,Depth=.016f;
  internal static readonly Vector3 ReferenceSocket=new Vector3(-.5f,0,.317412257f),ReferenceAxis=Vector3.forward,ReferenceVisual=new Vector3(-.5f,0,.25f);
  internal static readonly Bounds Target=new Bounds(new Vector3(0,0,-.006f),new Vector3(.065f,.065f,.024f));
  internal static Mesh Build(){var v=new List<Vector3>();var n=new List<Vector3>();var t=new List<int>[5];for(int i=0;i<5;i++)t[i]=new List<int>();
   // Continuous rounded plate with a real socket aperture. No painted-on fake opening.
   BatteryAperture.Box(v,n,t[1],new Vector3(0,CenterY,.0016f),new Vector3(Width,Height,.0032f),.001f,Mouth,Mouth);
   BatteryAperture.Walls(v,n,t[3],new Vector3(0,0,-.0064f),new Vector3(Width,Height,.0192f),Mouth,Mouth);
   RoundedGeometry.Box(v,n,t[3],new Vector3(0,0,-.015f),new Vector3(Mouth,Mouth,.002f),.0004f);
   foreach(float side in new[]{-1f,1f}){RoundedGeometry.Box(v,n,t[4],new Vector3(side*.0115f,0,-.0105f),new Vector3(.004f,.020f,.004f),.0004f);RoundedGeometry.Box(v,n,t[4],new Vector3(0,side*.0115f,-.0105f),new Vector3(.020f,.004f,.004f),.0004f);}
   // Own stamped lightning mark in the free upper portion of the plate.
   var bolt=new[]{new Vector3(-.004f,.102f,.0035f),new Vector3(.008f,.102f,.0035f),new Vector3(.001f,.092f,.0035f),new Vector3(.009f,.092f,.0035f),new Vector3(-.008f,.076f,.0035f),new Vector3(-.002f,.087f,.0035f),new Vector3(-.009f,.087f,.0035f)};int start=v.Count;v.AddRange(bolt);for(int i=0;i<bolt.Length;i++)n.Add(Vector3.forward);foreach(int id in new[]{0,2,1,0,6,2,2,4,3,2,5,4,2,6,5})t[3].Add(start+id);
   var mesh=new Mesh{name="Switchboards.OwnInputPanel"};mesh.SetVertices(v);mesh.SetNormals(n);mesh.subMeshCount=5;for(int i=0;i<5;i++)mesh.SetTriangles(t[i],i);CabinetGeometry.ApplyNativeUv(mesh);mesh.RecalculateBounds();return mesh;
  }
 }
}
