using System.Linq;using Assets.Scripts;using UnityEngine;
namespace ModularSwitchboards {
 internal static class HeadlessGeometryAudit {
  internal static void Log(){if(!ServerGraphics.Headless)return;var names=new[]{"StructureConsoleLED5","StructureAirConditioner"};foreach(var prefab in WorldManager.Instance.SourcePrefabs.Where(p=>p!=null&&names.Contains(p.PrefabName))){var unreadable=prefab.GetComponentsInChildren<MeshFilter>(true).Where(f=>f.sharedMesh!=null&&!f.sharedMesh.isReadable).Select(f=>f.sharedMesh.name).Distinct().ToArray();if(unreadable.Length>0)Debug.LogWarning("[Modular Switchboards] DS preflight: remaining legacy geometry must be checked for "+prefab.PrefabName+": "+string.Join(",",unreadable)+". Own IN is independent of these meshes.");}}
 }
}
