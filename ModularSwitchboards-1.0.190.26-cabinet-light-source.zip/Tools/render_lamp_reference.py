import bpy,struct
from pathlib import Path
from mathutils import Vector
r=Path(__file__).resolve().parents[1]
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
pts=[]
for name in ('Body','Diffuser'):
 b=(r/f'Assets/CabinetLamp/{name}.meshbin').read_bytes();_,n,g=struct.unpack_from('<iii',b);o=12;v=[];uv=[];t=[]
 for i in range(n):
  x,y,z,u,w=struct.unpack_from('<5f',b,o);o+=20;v.append((-x*.195,-(y-.1624)*.13,(z-.1086)*.13));uv.append((u,w))
 for i in range(g):
  c=struct.unpack_from('<i',b,o)[0];o+=4;t.extend(struct.unpack_from('<'+'i'*c,b,o));o+=c*4
 me=bpy.data.meshes.new(name);me.from_pydata(v,[],[t[i:i+3] for i in range(0,len(t),3)]);me.update();layer=me.uv_layers.new()
 for loop in me.loops:layer.data[loop.index].uv=uv[loop.vertex_index]
 ob=bpy.data.objects.new(name,me);bpy.context.collection.objects.link(ob);pts+=v
 m=bpy.data.materials.new(name);m.use_nodes=True;p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Roughness'].default_value=.38
 tex=m.node_tree.nodes.new('ShaderNodeTexImage');tex.image=bpy.data.images.load(str(r/f'Assets/CabinetLamp/{name}.png'));m.node_tree.links.new(tex.outputs['Color'],p.inputs['Base Color']);me.materials.append(m)
lo=Vector([min(p[i]for p in pts) for i in range(3)]);hi=Vector([max(p[i]for p in pts) for i in range(3)]);c=(lo+hi)/2;size=(hi-lo).length
s=bpy.context.scene;s.render.engine='CYCLES';s.cycles.samples=64;s.cycles.use_denoising=False;s.render.resolution_x=512;s.render.resolution_y=512;s.render.resolution_percentage=100;s.render.film_transparent=True;s.world.color=(.3,.3,.3);s.view_settings.view_transform='Standard'
bpy.ops.object.camera_add(location=c+Vector((.24,-1.6,.85))*size);cam=bpy.context.object;cam.rotation_euler=(c-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=size*1.2;s.camera=cam
for off,power in [((1,-3,4),350),((-3,-1,2),180)]:
 bpy.ops.object.light_add(type='AREA',location=c+Vector(off)*size);l=bpy.context.object;l.data.energy=power*size**2;l.data.size=3*size;l.rotation_euler=(c-l.location).to_track_quat('-Z','Y').to_euler()
s.render.filepath=str(r/'Assets/Icons/CabinetLamp.png');bpy.ops.render.render(write_still=True)
