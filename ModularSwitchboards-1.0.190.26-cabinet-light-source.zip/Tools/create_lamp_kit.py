from pathlib import Path
import json,struct,math
r=Path(__file__).resolve().parents[1];shell=json.loads((r/'Art/RailKit/source.json').read_text())['shell']
for p in shell['vertices']:p[0]*=1.4
v=[];ts={};
for name,role in [('Body','0'),('Diffuser','1')]:
 b=(r/f'Assets/CabinetLamp/{name}.meshbin').read_bytes();_,n,g=struct.unpack_from('<iii',b);o=12;vs=[]
 for i in range(n):
  x,y,z,u,w=struct.unpack_from('<5f',b,o);o+=20;vs.append((x,y,z))
 groups=[]
 for i in range(g):
  c=struct.unpack_from('<i',b,o)[0];o+=4;groups+=struct.unpack_from('<'+'i'*c,b,o);o+=c*4
 for width,zoff in [(.59612436,-.115),(.330,.115)]:
  start=len(v)
  for x,y,z in vs:
   # Own baked lamp, diffuser facing up inside the open transport crate.
   v.append([x*width/1.528524,.29+(z-.1086)*.13,zoff+(y-.1624)*.13])
  ts.setdefault(role,[]).extend(start+i for i in groups)
(r/'Art/LampKit').mkdir(exist_ok=True);(r/'Assets/LampKit').mkdir(exist_ok=True)
(r/'Art/LampKit/source.json').write_text(json.dumps(dict(shell=shell,contents=dict(vertices=v,triangles=ts))))
p=r/'Tools/create_module_kit.py';s=p.read_text().replace("'DoorKit','SmartKit')","'DoorKit','SmartKit','LampKit')");p.write_text(s)
