# Station Emotes 0.1.35
Requires BepInEx and StationeersLaunchPad. Replace the previous mod version, do not enable duplicate versions.

Hold F10 and select with the mouse; release to play. F11 or movement cancels. Esc closes the menu only. Native Wave loops; Salute and Sit hold. Custom Hands up, Point, Robot dance, Meme dance, Agree, Disagree and Facepalm require empty hands. Agree repeats a gentle nod, Disagree repeats a head shake, Facepalm holds the right palm in front of the visor. All persist until cancelled, switched or the same entry selected again. Observing clients should use the same version.

0.1.22 refines the radial menu with larger filled spacesuit silhouettes and helmet visors, icon-only sectors, central gesture names, opaque convex sector fills to avoid antialiased triangle seams, an orange selection arc and quieter footer hints. Selection policy, F10 controls, animations and network behavior are unchanged from 0.1.21. Live game appearance remains unverified.

The previous0.1.16 update corrects Facepalm wrist/IK-goal frame conversion. The job samples the native hand bone and native humanoid hand goal from the same animation stream, preserves their relative position/rotation, and maps the desired wrist pose into the correct goal frame. Imported bone axes are no longer treated as AvatarIKGoal axes.

The target height uses actual eye_l/eye_r landmarks where uniquely available. Named index/middle bones still calibrate the palm. Head-relative offsets remain in world distance units, and the palm follows the head tilt applied after the solver. Helmet detection and mesh-aware forward clearance remain separate from the bare-head profile. Unknown rigs use bounded fallback profiles. No guarantee is made for visual fit across every head/helmet: check both helmet and no-helmet appearances in game. Other gestures/dances are unchanged.

0.1.13 added three gestures and a larger ten-item wheel. IDs Agree41006, Disagree41007 and Facepalm41008 use the existing game emote message and cancellation/transition path. Facepalm uses humanoid right-hand IK; nod/shake use head transforms in the same owned overlay. No new root movement or game simulation is added.

The dance baseline from 0.1.12 keeps the 0.1.11 owned PreviousInputs overlay graph (confirmed live for Hands up and Point). It corrects dance ordering: humanoid pelvis/knee motion is submitted before SolveIK, then five upper-body transform slots are applied after SolveIK. Raw leg/hip transform slots are not applied over solved feet. This prevents the IK pass from rebuilding away the visible upper-body dance and prevents subsequent raw leg rotations from undoing foot support. The character root is not moved.

The 0.1.11 user log recorded 49 processed humanoid frames and 9/9 or 10/10 bone updates for dances despite their lack of visible motion. These counters prove execution, not visual correctness. The IK pass is the code path that distinguishes dance from working arm poses. The change requires another live visual test.

Custom poses still use procedural stream bone updates, with humanoid foot IK for dance where available. No imported animation clip or new physical movement is included. Native animations and cancellation policies are unchanged.

The earlier 0.1.10 scheduling failure was addressed in 0.1.11. Execution counters remain logged after one second; actual Unity rendering, graph evaluation, foot IK and multiplayer appearance still require live verification.

Build: source/StationEmotes.csproj, net472. Set GameManagedDirectory, BepInExDirectory and LaunchPadDirectory. Use the installed game UnityEngine.AnimationModule (including UnityEngine.Experimental.Animations output extensions) and PhysicsModule. Do not ship game or loader DLLs.


## Chair transitions — 0.1.35 prototype
Replaces the failed 0.1.23 pelvis-world-position interpolation. Ordinary chair entry is staged: a short alignment step (0.35s), turn toward the native seated facing direction (0.55s), then sit (0.85s). Exit reverses these phases. The body pose remains upright through alignment/turn; only the final phase blends toward the native seated pose. A small opposing thigh swing accompanies the alignment step; this is procedural, not a walking clip or foot IK.

Get In is accepted only while grounded directly in front of an empty ordinary Seat. Uses the chair's native ExitPosition as the front anchor, with ±0.45m lateral tolerance, -0.15..0.75m forward tolerance and ±0.55m height tolerance. Other positions return a disabled interaction with an English explanation. Native occupancy/entry validation remains intact; special seats and placing other items are not redesigned.

The common CharacterRotationY visual parent moves the complete skeleton, including HeadBone and its helmet/hair attachments. Runtime validation requires that the head belongs to that hierarchy; otherwise the transition is skipped and logged. Hips are blended in local space only. The main camera in first person is mapped through the same staged visual parent. Third-person camera translates by the visual offset, retaining its orbit. Visual offsets are restored before each animation update and on cancellation.

Native server root position, collider and slot ownership still change immediately. This is a staged visual transition, not collision-aware character locomotion, root-motion import or pathfinding. No new network messages. Every client needs the same build for consistent rendering; multiplayer timing and live visual quality remain unverified. Large native moves over 1.5m skip smoothing. F11/new emote/movement/death/slot change/unload cancel the transition.

Only ordinary exact Seat is enabled. Toilets, atmospheric/control/rocket seats and beds remain unchanged. No new wheel entry: use the chair normally.

Test in-game: stand on the floor directly before a normal empty chair and use Get In; observe the short alignment, turn, head/helmet attachment, camera and final sit. Exit and check the reverse sequence. Repeat from the sides/back to verify the front-only message; repeat with another player observing. Feet and staged orientation still require live validation.


## 0.1.35 standing-plane height fix
The 0.1.24 user test showed the full transition playing above the floor. The front/exit marker was allowed to contribute world Y to the alignment path. The final visual root Y now uses the captured entry standing height throughout approach and turn, blending to the native seat height only during the sit phase. On exit it reaches the native standing target height during rise, then holds it for turn/step. The first-person camera's relative vertical offset follows the same phase policy. Horizontal alignment, facing, head hierarchy, front-only entry gate and native physics/network ownership are unchanged. This is not a new foot IK solution. Live height/contact verification remains required.


## 0.1.35 temporary third-person chair inspection camera
The local player switches to third person during the chair transition, using the native SetThirdPersonCamera API so the head, helmet and wear visibility are updated. A temporary three-quarter overview tracks the animated visual root rather than the already seated physical root. A raycast shortens its desired 2.7m distance for walls; tight rooms can still restrict visibility. The native seated camera path does not consistently invoke the free third-person orbit, so the inspection view positions the camera after native updates.

On completion/cancel/disable/unload the prior view mode is restored. An existing third-person view remains third person. Camera control is scoped to the current local human and camera controller; remote players, dedicated servers and cinematic mode do not start an inspection view. No changes to emote-wheel animations, chair timing, height policy, physics or networking. Live appearance and restoration still need in-game validation.


## Current chair prototype: 0.1.35 footwork
Replaces the small thigh swing with alternating world-space foot contacts and a two-bone leg solve after moving the visual parent. Entry uses two alignment steps (0.70s total), six turning steps (1.35s), then sit (1.05s): 3.10s total. Exit rises, turns with six steps, then takes two alignment steps. The support foot retains its world contact while the swing foot follows an eased trajectory with up to 7.5cm lift. Measured ankle-to-floor clearance and local ground probes supply contact height. Small lateral weight transfer follows the support foot; head/chest anticipate the turn.

The final sit phase eases leg control back to the native seat pose. The last two exit steps converge to the live native standing feet. Missing leg bones skip the transition. A one-time warning reports contacts outside reachable leg length. This is still a procedural animation, not an imported authored walking clip, full pathfinding or an authoritative movement simulation. Ground raycasts and an analytical two-bone solver are used; natural appearance and foot reach need live testing.

The temporary third-person inspection camera from 0.1.26 remains enabled during chair transitions and restores the prior mode afterward. Front-only entry and standing-height policy remain; physics/slot/network behavior is unchanged. Test in a clear area before a standard chair, inspecting the planted foot, lifted foot, knee bending, turn direction, head and final settle, then repeat exit and multiplayer observation.


## Current chair prototype: 0.1.35 choreography rebuild
Based on 0.1.27; the rejected 0.1.28 torso-angle clamp and timing patch are not included. This rebuild separates the physical native slot transition, the visual model path, calibrated body pose, pelvis support and foot contacts. Native root/physics/slot/network ownership still change through the original game methods. No imported animation clip or authoritative walking/pathfinding is added.

Step counts are now per interaction: no alignment steps below 7cm; otherwise 2–4 short steps based on distance. Turns below 9 degrees have no turn steps; larger turns use 2–6 even steps based on angle. A 90-degree turn uses four rather than always six. The last pair shares the final stance. Entry approaches, turns, pauses briefly, bends and sits. Exit first transfers weight while seated, rises above the support feet, pauses in standing, then takes any necessary steps away. Timings vary with the plan.

On entry the standing skeleton is calibrated: pelvis rotation relative to the visual root, pelvis height/offset above the feet, torso local rotations and foot stance. A weak per-human cache supplies the same standing reference on exit. If the character loaded already seated and has no reference, exit uses native movement; enter a chair once to calibrate. Entry during another active emote also falls back to native entry so a dance/sit pose is not mistaken for standing.

The overlay reads unmodified native hip/foot endpoints before replacing any pose. Pelvis position follows the planned support feet instead of being dragged by the common visual root. Swing-foot lift does not raise the pelvis. Sitting bends vertically before moving the pelvis back; rising transfers weight horizontally while still seated, then raises the pelvis. Authored preparation lean is limited to 5 degrees for sit and 6 degrees for rise relative to the captured standing frame. This is not a post-hoc world-angle correction. The native seat/standing pose takes over smoothly at the endpoint. Upper body, small counter-arm movement and head anticipation follow this choreography. The forward knee pole is explicit, while the two-bone leg solve preserves foot targets.

All planned step locations need supported floor. Missing ground or an unavailable native pose stream cancels visual smoothing and retains the game's native slot result; it does not invent a floating contact. Leg-reach warnings remain available. Toilets, beds, atmospheric/control/rocket chairs remain excluded.

### Inspection controls during a chair transition
- F8: toggle normal / quarter speed.
- F7: pause/resume the choreography clock.
- F11: cancel the visual transition and restore view mode.
An on-screen hint shows the current phase. These controls affect local visual inspection; they do not pause the world, the native Animator or another client's transition. The temporary third-person camera uses a more side-on view and follows the actual pelvis. First/third view restoration and wall-distance shortening remain.

### Live test needed
Stand idle on supported ground just before a normal empty chair, then use Get In. Use F8 and F7 to inspect the transfer, knee bend, pelvis path, head, each planted foot and final native settle. Exit and inspect weight transfer before rising. Repeat for small and large approach angles and another observing client. Game compilation and math/stub checks do not establish visual quality, Unity transform IK correctness, contact/reach, rendering or multiplayer synchronization.


## 0.1.35 full torso / native handoff fix
User screenshots localize an abrupt seated-pose handoff just before sitting and a large whole-body forward pitch during rise. The old overlay calibrated only mapped Spine, Chest and Head. Intermediate spine and neck ancestors could therefore keep native seated rotations while the pelvis and selected mapped nodes were using standing rotations. The last leg solve also retained full IK strength until its graph was removed, which could suddenly change the native knee bend plane.

Standing calibration now walks the complete hips-to-head ancestor chain (up to eight nodes), including unmapped upper-spine and neck nodes. The animation job records unmodified local rotations for the complete chain before writing any mapped overlay bones. Pelvis, mapped body job and every torso ancestor share the same posture interpolation. Rise no longer starts rotating the pelvis during the weight-transfer-only interval. The optional 5/6-degree preparation lean is distributed through the first two spine nodes in parent-local axes, never applied as a rotation of the pelvis/leg chain. Native endpoint rotations remain exact.

During sitting, native foot blending now begins at 35% of body progress and continues to the endpoint, replacing the compressed final-18% handoff. Analytical leg IK strength fades by the complementary weight; it is zero at the exact native endpoint. Native legs retain their own knee plane at handoff. Pelvis support uses the planned support feet, rather than allowing the moving native-foot blend to drag the support center. Exit leg control also fades at the existing end-release phase. Adaptive steps, floor checks, F8 slow, F7 pause, F11 cancel and inspection camera are retained.

Live test both reported moments: slow just before the seat takes over, then inspect rise preparation from the side. Full Unity transform hierarchy, clip timing, contacts and multiplayer are not exercised by the math/stub checks. This remains a visual prototype; native server position/physics/slot ownership still changes immediately.


## 0.1.35 exit-only rise refinement
User reports that standing still pitches the whole body forward, while sitting should be retained. Exit now has 0.24s of straightening while seated, 0.24s of weight transfer and only then the 1.05s rise. Adaptive steps and standing settle remain. Entry scheduling, stepping, sit path and native handoff are unchanged from 0.1.30.

Pelvis orientation and the complete torso-chain standing reference settle during the initial seated straightening, rather than continuously changing during lift. Neck/head can use the unmodified standing Animator rotations to avoid carrying a downward chair-looking head pose throughout rise. Preparation lean is reduced from 6 to 4 degrees and remains confined to the spine.

The snapshot and standing reference also measure the anatomical pelvis-to-head direction in visual-root space. During exit, a minimal quaternion correction aligns the interpolated torso direction with the calibrated source-to-standing direction before the foot solver runs. This avoids assuming that a particular pelvis bone Euler axis means upright. The correction fades to zero at the native standing handoff. This is not the rejected 0.1.28 arbitrary world-angle clamp.

F8 slow, F7 pause, F11 cancel and the inspection camera remain. Inspect the new HUD stages: straighten while seated -> weight transfer -> rise -> stand -> steps away if needed. Native server root/physics/slot movement remains immediate. Actual appearance, transform IK and multiplayer are still unverified.


## 0.1.35 verified floor plane for rise support
Code review confirmed that the initial rise contacts were copied directly from native seated ankle positions. The old downward ray only calculated/clamped sole clearance; it never projected those initial support points onto the floor. It also accepted the first hit without excluding furniture or player colliders. This could feed seated-foot elevation into the standing pelvis target. This code-path flaw is confirmed; actual scene hit identities still need a live log.

Standing calibration now measures ankle-to-floor clearance using all downward hits, rejecting chair/player colliders and non-walkable normals. It stores floor height relative to the chair and the measured sole clearance. During rise, both initial foot targets are projected onto verified floor plus that clearance. The displayed feet settle onto those targets during the initial seated-straightening phase; the support calculation already uses the floor targets during that placement. Standing pelvis height therefore no longer inherits the native seated ankle height.

Planned steps and final exit contacts also use the filtered floor query. Candidates outside the calibrated floor band (-0.35m/+0.20m) are rejected, so another elevated flat surface cannot silently become the floor. Missing/invalid support skips the custom visual transition and retains native slot movement; there is no guessed 8cm or seated-height fallback. This prototype expects nearby supported ground rather than arbitrary stair navigation. No angle/timing/torso changes are added in this version.

Per-transition logs: `Chair floor entry/exit L/R` reports source ankle Y, support ankle Y, selected floor Y, sole clearance, collider name and rejected chair/human hit counts. `Chair rise support` reports seated pelvis Y, support ankle Y, standing calibration offset, calculated standing pelvis Y and native standing pelvis Y. Send these lines if the posture remains wrong; they distinguish floor-selection problems from pose problems.

Build and synthetic ray-hit tests do not execute the actual Unity scene. F8/F7 inspection remains local and the native server root/physics/slot/network behavior is unchanged.


## 0.1.35 calibration and reach diagnostics
The live 0.1.32 log confirms the selected frame floor at Y=128.000 and corrected support ankles at 128.071. Standing target pelvis 128.442–128.443 is within ~1.4cm of the native target, but calibration hip offset is only ~0.37m. That may be avatar scale, a bent/casting reference pose, or another issue; this version measures rather than changing pose angles.

The old `outside leg reach` warning was triggered by post-solve foot error, so it did not establish that the geometric target was unreachable. New diagnostics distinguish `Unreachable` (outside the upper+lower length range, including minimum folding reach), `SolverResidual` (inside reach but the full IK solution misses), `Valid` and `Invalid`. Full-solver error is measured before intentional IK blending, while final output error and IK weight are reported separately. Length-scaled error thresholds are used for diagnostics only.

After one Get In / exit, find these client-log lines:
- `Chair calibration pose`: world pelvis/ankle reference, calibrated local offset, avatar/model scale, control mode, grounded/casting flags and active clip names/weights per layer.
- `Chair calibration leg L/R`: segment lengths, extension ratio, knee flexion and source joint/ankle coordinates.
- `Chair leg sample L/R`: one sample per phase/leg, including horizontal/vertical target distance, actual pose span, min/max reach, target coordinates and errors.
- `Chair leg reach L/R`: bounded warnings per phase/leg/failure class, identifying geometric or solver failures.

These diagnostics are local-player only and rate-limited by phase. F7/F8/F11, floor selection, poses, step timing and solver transforms remain unchanged. Source verification confirms the leg-solver operation sequence is identical to 0.1.32 apart from measuring full error and emitting diagnostics. Build/math checks do not validate the actual game pose or resolve the visual problem yet.


## 0.1.35 reachable exit foot placement
Live diagnostics establish a valid GravityIdle standing reference (avatarScale 0.507, leg extension ratio 0.991) and correctly selected frame floor. The actual failure was earlier in preparation: a 0.402m leg was asked to span 0.471–0.481m when lowering seated feet that stayed 0.313–0.328m in front of the hip joint. Later rise samples were reachable and the solver error was zero. This version changes that preparation order rather than the standing calibration or sitting animation.

Exit snapshots preserve both knee and upper-leg joint positions before the native root move. New foot-floor targets start beneath the knees and are restricted to the leg's reachable floor disc, with max(8mm, 2.5% leg length) reserve from full extension. The existing filtered floor query verifies each target; an impossible or unsupported target skips custom smoothing instead of fabricating support. Feet first retract horizontally at their seated height (0.28s), then lower to the verified floor (0.24s), then weight transfers over them (0.24s). Rise begins at 0.76s. Trunk straightening still occurs during the initial 0.24s.

Exit step distance is recalculated from the tucked feet; shorter strides can produce 4–8 exit steps instead of a long two-step move. Entry step counts/timing are unchanged. A shallow support dip of at most 3cm is allowed before exit leg solving when standing/stepping contacts are near full extension; it is computed from actual joint/target reach, not an arbitrary extra lean. Diagnostic reach warnings remain if more correction would be needed.

The new `Chair foot tuck L/R` log reports source/target ankle coordinates and planned floor distance versus maximum reach. Existing leg/scale/floor diagnostics and F7/F8/F11 remain. Synthetic tests replay rounded left/right lengths/distances from the posted log throughout retraction and lowering, and verify the earlier 4mm stepping overextension can be removed by shallow support lowering. These tests do not run Unity contact/collision/rendering or prove natural appearance. Test chair-base clearance and both motions in-game. Native root, physics, slot ownership and network protocol are unchanged.

## 0.1.35 chair endpoints

0.1.35: Capture standing and native seated endpoints in a floor-upright frame. Use shared pelvis path in both directions, two foot placement steps before sitting, and reverse foot retraction after seat contact. Freeze native endpoint bone rotations and blend to live animation at completion. Preserve exit foot reach safeguards.
Rebuilt after temporary workspace reset from published 0.1.34 source with the prepared 0.1.35 changes. Clean compilation against real game APIs.
452 production exit-placement checks passed, including logged geometry (math stubs).
Math stubs verify placement and timing, not rendered Unity animation, collisions, controller transitions or multiplayer. Historical fixtures are retained and are not all rerun for this version.

## 0.1.36 planted feet

0.1.36: On chair exit, keep the seated foot orientation during horizontal tucking, then smoothly rotate both feet to the calibrated standing orientation during lowering (0.28–0.52 s). Feet are planted before weight transfer begins. Native final pose release and walking targets are preserved.

## 0.1.37 — toilet and seat directions

0.1.37 — toilet seating and per-slot chair directions

Toilet: a native Entity/Seated slot and a small front interaction zone provide Sit / stand, including while wearing a suit. Original Activate/Use passes through only for the seated occupant after the entry interval and active visual transition finish. The original suit, sanitation, water, pollution, temperature, pressure and waste checks remain unchanged. Forward/ascend also uses the game's exit input. Child interactions/free look are enabled while seated and restored on exit.

Seats: transitions identify the exact selected/occupied slot, not slot zero or the furniture root. Recognized classes are Seat (including subclasses), AtmosphericSeat/ControlChair and CrewModuleChair, plus the toilet. Each slot's upright world rotation controls facing. Exit body yaw stays outward throughout rising and stepping; local camera yaw no longer chooses the exit turn. Native rocket lock/flight checks still run. Verified floor support and obstruction checks precede normal exits.

Double seats: existing native entity slots are retained. A Seat prefab explicitly named Double/TwoSeat/2Seat with one seated entity slot gets left/right anchors and a second native entity slot; spacing is derived from render width and clamped to 0.18–0.35 m per side. Separate front interaction zones select the two positions. Multi-position exits project forward from each cushion, including opposite-facing slots. This fallback relies on prefab names and model bounds; alignment needs in-game testing.

Runtime slot additions use native slot indices for occupancy, saving and network messages. Install the same mod version on server and clients and restart the game/server after updating. Slot alignment, save/reload behavior, concurrent multiplayer occupancy, native Harmony patch execution and rendered animation were not exercised in Unity here.

Validation:
- Clean compilation against real Stationeers API assemblies.
- 573 production seat geometry/facing/readiness checks with System.Numerics-backed quaternion math stubs: rotated and opposite-facing seats, separate left/right exits, outward yaw through the full exit, entry facing, readiness gates, invalid timestamps and double-seat layout bounds.
- 560 production exit-foot placement checks, including the prior logged leg geometry and foot flattening before weight transfer.
- 19 real-game API metadata checks (reflection only).
- A standalone invocation of Harmony AccessTools failed in its Mono-specific initializer under the external .NET 8 harness. Only metadata checks are reported as passing; actual Harmony activation must be checked in the game.
Historical verification fixtures retained; other suites were not rerun.

## 0.1.38 — visible interactions and body facing

0.1.38 — visible seat interactions and anatomical exit facing

Fixes reported from 0.1.37:
- The actual toilet bowl Activate action offers Sit down when not seated, even in a suit. After entry, the same visible bowl offers original Use only after readiness checks pass. Quantity-modifier + click offers Stand up; native forward/ascend exit remains available. The separate small control is optional.
- Cursor lookup now routes actual visible furniture collider hits to the nearest seated Entity slot. Each slot has an initialized Interactable and registered action, including missing native controls. Shared colliders can select both double-seat positions, and multi-seat prompts include the position number. Slot indices stay fixed while aiming; occupied targets remain selected and report occupancy.
- Explicit Double/TwoSeat/2Seat furniture named Seat/Chair/Sofa/Couch can receive two native entity slots even when the original model was decorative with no seated slots. Existing native positions are retained. Former one-position doubles still use the bounded left/right layout. Native unsupported furniture gets a normal exit/input/free-look bridge.
- Exit pelvis targets use the calibrated standing pelvis basis instead of the potentially opposing native endpoint yaw. After torso lean, yaw is aligned from anatomical shoulder-right crossed with torso-up toward the seat's outward direction, before solving planted legs. The correction changes no pelvis position, scale or tilt. Diagnostics log body yaw error before/after by exit stage.

Original suit, sanitation, water, temperature, pressure and waste logic is not replaced. Native flight locks and occupied-seat checks remain in place. Use identical mod versions on server and clients and restart after updating runtime slot layouts.

Validation:
- Clean compilation against real game API assemblies.
- 460 production interaction-prefix/surface-routing/anatomical-facing checks with game and math stubs. Covers visible-bowl Sit in suit, no movement on hover, native slot move, delayed use pass-through, modifier stand, occupancy/position/state/building gates, server-only entry side effects, action registration/idempotence, actual surface selection of left/right slots, preservation of other controls, and shoulder-derived yaw across 144 yaw/lean/bind-axis combinations.
- 573 production seat geometry/facing/readiness checks.
- 560 production exit-foot reach/placement/flattening checks.
- 23 real-game metadata checks, including the exact GetInteractable(Collider) lookup hook and native AltKey/CursorHit fields.
- ZIP integrity and version metadata checks.

Limitations: These do not execute Harmony inside Unity, actual renderer/physics hit testing, saved-world load, multiplayer replication, real sanitation/water simulation or rendered humanoid animation. The standalone .NET 8 runner is not the game's Mono runtime. Actual furniture names, zero-slot double-seat geometry/camera anchor and toilet alignment still need in-game validation. Other historical verification fixtures are retained but were not all rerun.

## 0.1.39 — native seats and grounded feet

0.1.39 — grounded foot transitions, close approach, native bench anchors

Reported fixes:
- Exit final steps no longer take positions/rotations from the raw native standing endpoint. Their targets use the calibrated standing foot offsets and rotations in the outward-facing frame, with verified floor heights. The final positional blend uses the same stance. Foot orientation stays fully controlled through the final positional IK release, so the old opposing native yaw is not blended back during stepping away.
- Entry positional and foot-orientation IK stay active through the whole sit/rest-feet path; they release only during the final handover. Native seated foot rotation is allowed only once the commanded ankle has lifted over 8 mm above the calibrated floor ankle height, with a smooth 4 cm release band. Ground rotations use the actual native grounded standing pose, preserving rig bind axes and anatomical ankle/toe height offsets.
- Chair approach checks use the selected native seat anchor instead of a distant exit marker: nearby forward positions are accepted. The toilet uses a grounded, finite reach check around the visible bowl slot (up to 1.45 m, same floor tolerance), independent of the toilet model's forward-axis convention. Original suit/water/sanitation checks still run only for seated Use.
- Per user direction, all automatic double-seat anchor generation/repositioning is removed. No native bench/chair slot is created, moved or replaced. Existing native entity slots and their transforms are used directly; surface selection and animation bind to those slots. Original native position count is logged. If a furniture prefab has only one native position, this version does not invent a second one.

Validation:
- Clean compilation against the real game API assemblies.
- 461 production foot-contact/final-yaw/approach checks with System.Numerics-backed math stubs: opposing native foot rotations cannot enter exit contacts; grounded entry feet cannot adopt seated toe-up rotations; lifted foot release, standing stance, close-front chair approach, orientation-independent nearby toilet approach, invalid/out-of-range rejection, and IK kept through the rest-feet interval.
- 462 production interaction/surface/anatomical-facing checks with game and math stubs, including preservation of native slot object identity, transforms, positions and indices while initializing controls.
- 560 production foot-reach/placement checks.
- 23 real-game API metadata checks.
- Version metadata and ZIP integrity checks.

Limitations: no actual Unity/Harmony activation, floor raycasts, rendered humanoid/helmet motion, saved-world load or multiplayer replication was run here. Native layout logs and in-game testing are needed to confirm each bench's original position count and model alignment. All peers should use this version and restart to reconstruct the original furniture prefabs instead of the prior version's temporary modified anchors. Historical fixtures remain, but not all old suites were rerun.

## 0.1.40 — native furniture controls

0.1.40 — restore native furniture interaction hitboxes

Removed the GetInteractable(Collider) surface-routing Harmony patch, nearest-slot routing, and the initialization hooks which added/rebound chair controls at Awake or mod load. Cushions, backrests and other body colliders no longer acquire an extra sitting action from StationEmotes. The original game decides which colliders offer seating. Native slot positions/counts are retained; existing entry/exit animation hooks and the 0.1.39 exit-facing behavior remain.

Toilet-specific controls remain separate. This cleanup does not fix the still-reported toilet approach rejection or the entry right-toe pose. Those need further in-game diagnosis.

Validation: clean compilation against real Stationeers APIs. Inspected active source: no SeatSurfaceInteractionPatch, SeatInteractionRouting, FromSurface mapping, or chair-control initialization hooks remain; ChairTransition entry/exit hooks remain. Runtime/source ZIP CRC and version metadata verified. No new tests were added for this removal. Historical surface-routing fixtures describe removed behavior and were not run as current-version tests. Live Unity rendering, hit testing and multiplayer not exercised.

Restart the game/server after installing on all peers to discard cached control/collider mappings from previous versions. Existing native game hitboxes remain visible where the game itself provides them.

## 0.1.41 — toilet entry and toe contact

0.1.41 — toilet entry and grounded toe joints

Includes the unpublished 0.1.40 cleanup: no added cushion/backrest Sit routing or injected chair controls; original native chair interaction hitboxes and position counts remain. The successful 0.1.39 outward exit-facing code is retained.

Toilet: removed the additional ChairTransition.InFront eligibility check from the existing bowl/slot sitting action. This custom gate previously combined root/pivot distance and an IsGrounded capsule check and still rejected valid visible-bowl interactions. Entry now follows the native cursor reach/PreventInteraction path, retaining actor-alive, completed-structure, free-slot, slot-lock and already-seated guards. Suit use restrictions, water/sanitation logic and the seated-use readiness gate still pass through to the original handler after entry.

Toe contact: ankles alone do not control separately animated toe joints. Snapshots now locate both toe joints using the humanoid LeftToes/RightToes mapping, with a nearest toe-named descendant fallback that excludes renderers. The calibrated native standing toe local rotations are retained alongside ankle poses. Toe native rotations are captured in the animation stream before any overlay bone writes and cached with the native endpoint. While waiting for that endpoint, source toe rotations are held too. During entry contact, toe rotations stay at the calibrated standing values until the target foot lifts over the existing clearance threshold; lifted seated feet blend to the captured native seated toe pose. Exit toes return to calibrated standing rotation during planting and retain it through stepping away. Missing toe mappings leave native behavior unchanged and are recorded in the calibration log:
Chair foot joints: L=<bone or unmapped>, R=<bone or unmapped>

Validation:
- Clean compilation against actual game API assemblies.
- 16 production toilet-prefix entry/use checks using game stubs, including an InFront helper that throws if called: hover without movement, entry in suit without the custom geometry/ground gate, native slot movement once, delayed original Use pass-through, modifier stand, occupancy/lock/build-state/alive guards and no authoritative movement on clients.
- 78 production toe mapping/contact/stream/cache checks with bone/math/stream stubs: mapped and named joints, wrong-foot and renderer rejection, missing joints, planted toe rotation despite a native toe curl, lifted release, exit planting, native capture readiness and immutable cached toe endpoints with live handover blending.
- 461 retained foot-contact/facing/approach-helper math checks.
- 23 real-game API metadata checks.
- Source inspection confirms no whole-surface seat routing was restored and native toe capture precedes overlay writes. ZIP integrity/version checks pass.

Limitations: native Unity graph binding, actual model toe mapping, rendered toe appearance, physical contact/cursor selection, saved-world load and multiplayer were not exercised here. The right-toe explanation is an identified missing part of our control path, not a rendered proof of the user's exact model. If a toe is unmapped, the calibration log identifies that. Restart all peers after updating. Other historical verification fixtures are retained but not reported as rerun current-version tests.
