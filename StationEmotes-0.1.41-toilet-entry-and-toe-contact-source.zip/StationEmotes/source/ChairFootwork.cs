using UnityEngine;
using System.Collections.Generic;
namespace StationEmotes
{
 internal sealed class ChairFootwork
 {
  private sealed class Step{internal int Foot;internal float Start,Duration;internal Vector3 Position;internal Quaternion Rotation;}
  private readonly HashSet<string> legSamples=new HashSet<string>(),legWarnings=new HashSet<string>();
  private readonly ChairTransition.Snapshot s;private readonly Step[] steps;
  private readonly Vector3[] initial=new Vector3[2],rawInitial=new Vector3[2];private readonly Quaternion[] initialRotation=new Quaternion[2];
  private readonly Vector3[] seatFloor=new Vector3[2],exitStand=new Vector3[2];
  private readonly float[] sole=new float[2],floor=new float[2];private bool prepared,reportedSupport,grounded=true;
  internal ChairFootwork(ChairTransition.Snapshot snapshot)
  {
   s=snapshot;steps=new Step[s.Plan.StepCount];initial[0]=s.LeftFootPosition;initial[1]=s.RightFootPosition;
   initialRotation[0]=s.LeftFootRotation;initialRotation[1]=s.RightFootRotation;
   for(int i=0;i<2;i++)
   {
    rawInitial[i]=initial[i];sole[i]=s.Standing.Sole[i];
    float expected=s.Seat.ThingTransform.position.y+s.Standing.FloorRelativeToSeat[i];
    ChairFloorContact contact;
    if(!ChairFloorProbe.Try(initial[i],s.Seat,s.Human,expected,out contact))
    {grounded=false;Plugin.Log.LogWarning("Chair transition skipped: no verified floor under the initial foot.");continue;}
    floor[i]=contact.Point.y;
    if(!s.Entering)
    {
     Vector3 tucked;
     if(!ChairExitPlacement.TryTarget(s.LegUpper[i],s.LegKnee[i],rawInitial[i],ChairFloorPolicy.Ankle(floor[i],sole[i]),out tucked))
     {grounded=false;Plugin.Log.LogWarning("Chair exit skipped: feet cannot reach verified floor from the seat.");continue;}
     ChairFloorContact underKnee;
     if(!ChairFloorProbe.Try(tucked,s.Seat,s.Human,floor[i],out underKnee)||
      !ChairExitPlacement.TryTarget(s.LegUpper[i],s.LegKnee[i],rawInitial[i],ChairFloorPolicy.Ankle(underKnee.Point.y,sole[i]),out tucked))
     {grounded=false;Plugin.Log.LogWarning("Chair exit skipped: no reachable floor under the tucked foot.");continue;}
     ChairFloorContact verified;
     if(!ChairFloorProbe.Try(tucked,s.Seat,s.Human,underKnee.Point.y,out verified)||Mathf.Abs(verified.Point.y-underKnee.Point.y)>.002f)
     {grounded=false;Plugin.Log.LogWarning("Chair exit skipped: tucked-foot floor height is inconsistent.");continue;}
     floor[i]=verified.Point.y;initial[i]=tucked;
     float reach=(s.LegKnee[i]-s.LegUpper[i]).magnitude+(rawInitial[i]-s.LegKnee[i]).magnitude;
     Plugin.Log.LogInfo("Chair foot tuck "+(i==0?"L":"R")+": source="+rawInitial[i].ToString("F3")+", target="+tucked.ToString("F3")+", floorDistance="+(tucked-s.LegUpper[i]).magnitude.ToString("F3")+", maxReach="+reach.ToString("F3"));
    }
    Plugin.Log.LogInfo("Chair floor "+(s.Entering?"entry":"exit")+" "+(i==0?"L":"R")+": source ankleY="+rawInitial[i].y.ToString("F3")+", support ankleY="+initial[i].y.ToString("F3")+", floorY="+floor[i].ToString("F3")+", sole="+sole[i].ToString("F3")+", hit="+contact.Name+", rejected chair/human="+contact.Chairs+"/"+contact.Humans);
   }
  }
  internal bool Prepare(Vector3 end,Quaternion facing,ChairNativePose native)
  {
   if(!grounded)return false;
   if(!native.Ready||s.TargetPose==null)return true;
   native=s.TargetPose.Resolve(native,0);
   if(!s.Entering)
   {
    for(int side=0;side<2;side++)
    {
     var point=ChairFootContact.StandingFoot(end,ChairPoseFrame.Upright(facing),s.Standing.Feet[side]);ChairFloorContact contact;
     if(!ChairFloorProbe.Try(point,s.Seat,s.Human,floor[side],out contact))return false;
     point.y=ChairFloorPolicy.Ankle(contact.Point.y,sole[side]);exitStand[side]=point;
    }
   }
   if(prepared)
   {
    if(!s.Entering&&s.Plan.WalkSteps>0)
    {
     // Final contacts share the outward, calibrated stance; raw endpoint yaw is not reintroduced.
     for(int i=steps.Length-2;i<steps.Length;i++)
     {int foot=steps[i].Foot;steps[i].Position=exitStand[foot];steps[i].Rotation=ChairFootContact.GroundRotation(ChairPoseFrame.Upright(facing),s.Standing.FootRotations[foot]);}
    }
    return true;
   }
   if(s.Entering)
   {
    for(int side=0;side<2;side++)
    {
     var upper=side==0?native.LeftUpper:native.RightUpper;var knee=side==0?native.LeftKnee:native.RightKnee;var ankle=side==0?native.Left:native.Right;
     Vector3 point;ChairFloorContact support;
     if(!ChairExitPlacement.TryTarget(upper,knee,ankle,floor[side]+sole[side],out point)||!ChairFloorProbe.Try(point,s.Seat,s.Human,floor[side],out support)||!ChairExitPlacement.TryTarget(upper,knee,ankle,support.Point.y+sole[side],out point))
     {Plugin.Log.LogWarning("Chair entry skipped: seat endpoint has no reachable floor contact.");return false;}
     seatFloor[side]=point;
    }
   }
   var front=s.Front;front.y=s.Entering?s.Position.y:end.y;
   for(int i=0;i<steps.Length;i++)
   {
    float start,duration,advance;bool turning;s.Plan.Step(i,out start,out duration,out advance,out turning);
    int foot=i%2;Vector3 root;Quaternion rotation;
    if(turning){root=front;rotation=Quaternion.Slerp(ChairPoseFrame.Upright(s.Rotation),ChairPoseFrame.Upright(facing),advance);}
    else{root=Vector3.Lerp(s.Entering?s.Position:front,s.Entering?front:end,advance);rotation=ChairPoseFrame.Upright(s.Entering?s.Rotation:facing);}
    var point=s.Entering&&i>=s.Plan.WalkSteps+s.Plan.TurnSteps?seatFloor[foot]:root+rotation*s.Standing.Feet[foot];point.y=initial[foot].y;
    if(s.Entering&&i>=s.Plan.WalkSteps+s.Plan.TurnSteps)rotation=ChairPoseFrame.Upright(facing);
    ChairFloorContact hit;
    if(!ChairFloorProbe.Try(point,s.Seat,s.Human,floor[foot],out hit))
    {Plugin.Log.LogWarning("Chair transition skipped: a planned footstep has no verified floor.");return false;}
    point.y=ChairFloorPolicy.Ankle(hit.Point.y,sole[foot]);
    steps[i]=new Step{Foot=foot,Start=start,Duration=duration,Position=point,Rotation=ChairFootContact.GroundRotation(rotation,s.Standing.FootRotations[foot])};
   }
   prepared=true;return true;
  }
  internal Vector3 WeightShift(float elapsed,Quaternion rotation)=>Vector3.zero; // Pelvis follows foot support instead of shifting the complete model.
  internal void Apply(float elapsed,Transform visual,Quaternion facing,ChairNativePose native,ChairTorsoStream torso,ChairTorsoStream toes)
  {
   if(!prepared||!native.Ready||s.TargetPose==null)return;
   float end=s.Plan.EndRelease(elapsed);
   native=s.TargetPose.Resolve(native,end);torso=s.TargetPose.ResolveTorso(torso,end);toes=s.TargetPose.ResolveToes(toes,end);
   var frame=ChairPoseFrame.Upright(visual.rotation);var rightAxis=frame*Vector3.right;var forwardAxis=frame*Vector3.forward;
   var left=initial[0];var right=initial[1];
   if(!s.Entering){left=ChairExitPlacement.Sample(rawInitial[0],initial[0],elapsed);right=ChairExitPlacement.Sample(rawInitial[1],initial[1],elapsed);}var lr=initialRotation[0];var rr=initialRotation[1];
   if(!s.Entering)
   {
    float planted=ChairExitPlacement.PlantRotation(elapsed);
    var floorFrame=ChairPoseFrame.Upright(facing);
    lr=Quaternion.Slerp(lr,ChairFootContact.GroundRotation(floorFrame,s.Standing.FootRotations[0]),planted);
    rr=Quaternion.Slerp(rr,ChairFootContact.GroundRotation(floorFrame,s.Standing.FootRotations[1]),planted);
   }
   int swing=-1;float swingProgress=0;
   foreach(var step in steps)
   {
    if(elapsed<step.Start)break;
    float p=ChairStepPolicy.Progress(elapsed,step.Start,step.Duration);
    var old=step.Foot==0?left:right;var oldRotation=step.Foot==0?lr:rr;
    bool moved=(step.Position-old).magnitude>=.015f||Quaternion.Angle(oldRotation,step.Rotation)>8f;
    var goal=Vector3.Lerp(old,step.Position,p)+Vector3.up*(moved?ChairStepPolicy.Lift(p):0);
    var rotation=Quaternion.Slerp(oldRotation,step.Rotation,p);
    if(step.Foot==0){left=goal;lr=rotation;}else{right=goal;rr=rotation;}
    if(p<1){if(moved){swing=step.Foot;swingProgress=p;}break;}
   }
   float body=s.Plan.Body(elapsed);
   float settle=s.Entering?s.Plan.Rest(elapsed):end;
   var supportLeft=left;var supportRight=right;
   if(!s.Entering&&elapsed<.52f){supportLeft.y=initial[0].y;supportRight.y=initial[1].y;}
   if(s.Entering&&elapsed>=s.Plan.RestStart)
   {
    var seat=s.TargetPose.World();
    left=ChairExitPlacement.ReverseSample(seat.Left,seatFloor[0],elapsed-s.Plan.RestStart);
    right=ChairExitPlacement.ReverseSample(seat.Right,seatFloor[1],elapsed-s.Plan.RestStart);
    left=Vector3.Lerp(left,native.Left,end);right=Vector3.Lerp(right,native.Right,end);
   }
   else if(!s.Entering){left=Vector3.Lerp(left,exitStand[0],end);right=Vector3.Lerp(right,exitStand[1],end);}
   // Grounded entry contacts stay in the actual native standing rotation until lifted.
   // Exit contacts retain outward yaw even while positional IK releases to the idle animator.
   lr=ChairFootContact.Rotation(s.Entering,lr,native.LeftRotation,settle,left.y-(floor[0]+sole[0]));
   rr=ChairFootContact.Rotation(s.Entering,rr,native.RightRotation,settle,right.y-(floor[1]+sole[1]));
   float ik=ChairFootContact.LegWeight(end),rotationWeight=ChairFootContact.RotationWeight(s.Entering,end);
   var middle=ChairBodyPath.Support(supportLeft,supportRight,swing,swingProgress);
   var standingOffset=s.Entering?s.Standing.HipAboveFeet:s.TargetPose.HipAboveFeet;
   var standingHip=middle+frame*standingOffset;
   if(!s.Entering&&!reportedSupport&&elapsed>=s.Plan.BodyStart)
   {reportedSupport=true;Plugin.Log.LogInfo("Chair rise support: seated pelvisY="+s.HipPosition.y.ToString("F3")+", floor ankleY="+middle.y.ToString("F3")+", endpoint hip offsetY="+(frame*standingOffset).y.ToString("F3")+", standing pelvisY="+standingHip.y.ToString("F3")+", native standing pelvisY="+native.Hips.y.ToString("F3"));}
   Vector3 hipPosition;Quaternion hipRotation;
   float lean;
   if(s.Entering)
   {
    // Bend vertically before translating the pelvis back above the cushion.
    hipPosition=ChairBodyPath.Pelvis(true,s.HipPosition,standingHip,native.Hips,0,body,settle);
    lean=ChairBodyPath.Lean(true,0,body);
    hipRotation=Quaternion.Slerp(frame*s.Standing.HipRotation,native.HipRotation,ChairBodyPath.Posture(body));
   }
   else
   {
    // Transfer weight over planted feet while still seated, then rise over that support.
    float transfer=s.Plan.Preparation(elapsed);
    hipPosition=ChairBodyPath.Pelvis(false,s.HipPosition,standingHip,native.Hips,transfer,body,end);
    lean=ChairBodyPath.Lean(false,transfer,body);
    var upright=frame*s.Standing.HipRotation;
    hipRotation=Quaternion.Slerp(s.HipRotation,upright,ChairBodyPath.Posture(body));
    // Keep the calibrated standing pelvis basis; native endpoint yaw can oppose planted feet.
   }
   var hips=s.Bones[0];hips.SetPositionAndRotation(hipPosition,hipRotation);
   // Include every actual spine/neck ancestor, including unmapped UpperChest and Neck.
   // Use the same interpolation factor as the pelvis, with unmodified native samples.
   float posture=ChairBodyPath.Posture(body);
   for(int i=0;i<s.Standing.Torso.Length;i++)
   {
    var node=s.Standing.Torso[i];if(node==null)continue;var sampled=torso.Get(i);
    var nativeLocal=sampled.Ready?sampled.NativeRotation:node.localRotation;
    node.localRotation=Quaternion.Slerp(s.SourceTorso[i],nativeLocal,posture);
   }
   // The small preparation lean belongs to the spine, never the pelvis/whole leg chain.
   for(int i=0;i<Mathf.Min(2,s.Standing.Torso.Length);i++)
   {
    var node=s.Standing.Torso[i];if(node==null||node.parent==null)continue;
    var axis=Quaternion.Inverse(node.parent.rotation)*rightAxis;
    node.localRotation=Quaternion.AngleAxis(lean*(i==0?.6f:.4f),axis)*node.localRotation;
   }
   if(end<1)
   {
    var sourceDirection=s.Entering?frame*s.Standing.TorsoDirection:frame*s.SourceTorsoDirection;
    var targetDirection=frame*s.TargetPose.TorsoDirection;
    var desired=Vector3.Slerp(sourceDirection,targetDirection,posture).normalized;
    desired=Quaternion.AngleAxis(lean,rightAxis)*desired;
    hips.rotation=ChairRiseOrientation.Align(hips.rotation,s.Bones[3].position-hips.position,desired,1-end);
   }
   if(!s.Entering&&s.Bones[4]!=null&&s.Bones[7]!=null&&s.Bones[3]!=null)
   {
    var shoulderRight=s.Bones[7].position-s.Bones[4].position;
    var torsoUp=s.Bones[3].position-hips.position;
    var outward=s.SeatFacing*Vector3.forward;
    var before=ChairBodyFacing.Forward(shoulderRight,torsoUp);
    hips.rotation=ChairBodyFacing.Align(hips.rotation,shoulderRight,torsoUp,outward);
    var after=ChairBodyFacing.Forward(s.Bones[7].position-s.Bones[4].position,s.Bones[3].position-hips.position);
    if(legSamples.Add("body-facing/"+s.Plan.Stage(elapsed)))
     Plugin.Log.LogInfo("Chair body facing: stage="+s.Plan.Stage(elapsed)+", yaw error before/after="+Vector3.Angle(before,outward).ToString("F1")+"/"+Vector3.Angle(after,outward).ToString("F1"));
   }
   // Small opposite arm swing; hands relax into the native seat pose during the last phase.
   if(swing>=0)
   {
    float arm=6f*Mathf.Sin(swingProgress*Mathf.PI)*(swing==0?1:-1);
    if(s.Bones[4]!=null)s.Bones[4].rotation=Quaternion.AngleAxis(arm,rightAxis)*s.Bones[4].rotation;
    if(s.Bones[7]!=null)s.Bones[7].rotation=Quaternion.AngleAxis(-arm,rightAxis)*s.Bones[7].rotation;
   }
   if(ik>.95f)
   {
    float reachLeft=(s.Bones[11].position-s.Bones[10].position).magnitude+(s.Bones[12].position-s.Bones[11].position).magnitude;
    float reachRight=(s.Bones[14].position-s.Bones[13].position).magnitude+(s.Bones[15].position-s.Bones[14].position).magnitude;
    float drop=Mathf.Max(ChairExitPlacement.RequiredDrop(s.Bones[10].position,left,reachLeft),ChairExitPlacement.RequiredDrop(s.Bones[13].position,right,reachRight));
    // A shallow, bounded knee bend keeps near-limit standing/stepping contacts reachable.
    if(drop>0)hips.position-=Vector3.up*Mathf.Min(drop,.03f);
   }
   Solve(s.Bones[10],s.Bones[11],s.Bones[12],left,lr,forwardAxis,ik,rotationWeight,0,elapsed);
   Solve(s.Bones[13],s.Bones[14],s.Bones[15],right,rr,forwardAxis,ik,rotationWeight,1,elapsed);
   for(int side=0;side<2;side++)
   {
    var toe=s.ToeBones[side];if(toe==null||!s.Standing.ToeReady[side])continue;
    var sampled=toes.Get(side);
    var target=sampled.Ready?sampled.NativeRotation:toe.localRotation;
    float clearance=(side==0?left.y:right.y)-(floor[side]+sole[side]);
    toe.localRotation=ChairToeContact.Rotation(s.Entering,s.ToeRotations[side],s.Standing.ToeRotations[side],target,settle,clearance,elapsed);
   }
   float turn=s.Plan.Turn(elapsed);
   float lead=Mathf.Clamp(Vector3.SignedAngle(forwardAxis,ChairPoseFrame.Upright(facing)*Vector3.forward,Vector3.up),-18,18)*Mathf.Sin(turn*Mathf.PI);
   if(s.Bones[2]!=null)s.Bones[2].rotation=Quaternion.AngleAxis(lead*.35f,Vector3.up)*s.Bones[2].rotation;
   if(s.Bones[3]!=null)s.Bones[3].rotation=Quaternion.AngleAxis(lead*.65f,Vector3.up)*s.Bones[3].rotation;
  }
  private void Solve(Transform upper,Transform lower,Transform foot,Vector3 target,Quaternion rotation,Vector3 forward,float weight,float rotationWeight,int side,float elapsed)
  {
   if(upper==null||lower==null||foot==null)return;
   if(weight<=0){foot.rotation=Quaternion.Slerp(foot.rotation,rotation,rotationWeight);return;}
   var originalUpper=upper.rotation;var originalLower=lower.rotation;var originalFoot=foot.rotation;
   var a=upper.position;var b=lower.position;var c=foot.position;
   float u=(b-a).magnitude,l=(c-b).magnitude,d=(target-a).magnitude;
   if(u<.01f||l<.01f||d<.001f)return;
   var direction=(target-a)/d;
   var pole=Vector3.ProjectOnPlane(forward,direction);
   if(pole.sqrMagnitude<.0001f)pole=Vector3.ProjectOnPlane(b-a,direction);
   if(pole.sqrMagnitude<.0001f)return;
   float axial,lateral;ChairStepPolicy.Knee(u,l,d,out axial,out lateral);
   var knee=a+direction*axial+pole.normalized*lateral;
   upper.rotation=Quaternion.FromToRotation(b-a,knee-a)*upper.rotation;
   lower.rotation=Quaternion.FromToRotation(foot.position-lower.position,target-lower.position)*lower.rotation;
   float fullError=(foot.position-target).magnitude;
   var solvedUpper=upper.rotation;var solvedLower=lower.rotation;
   upper.rotation=Quaternion.Slerp(originalUpper,solvedUpper,weight);
   lower.rotation=Quaternion.Slerp(originalLower,solvedLower,weight);
   foot.rotation=Quaternion.Slerp(originalFoot,rotation,rotationWeight);
   if(!s.Entering)
   {
    string phase=s.Plan.Stage(elapsed),key=phase+"/"+side;
    float error=(foot.position-target).magnitude;
    var measured=ChairLegMetrics.Measure(a,b,c,target,fullError);
    if(legSamples.Add(key))ChairRigDiagnostics.Leg(s,phase,side,elapsed,measured,error,fullError,weight,false);
    string warningKey=key+"/"+measured.Status;
    if(weight>.95f&&measured.Status!=ChairReachStatus.Valid&&legWarnings.Add(warningKey))
     ChairRigDiagnostics.Leg(s,phase,side,elapsed,measured,error,fullError,weight,true);
   }
  }
 }
}
