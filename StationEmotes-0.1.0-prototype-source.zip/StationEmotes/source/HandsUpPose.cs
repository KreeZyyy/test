using System;
using System.Linq;
using Assets.Scripts;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Objects.Entities;
using UnityEngine;
namespace StationEmotes
{
    [DefaultExecutionOrder(10000)]
    public sealed class HandsUpPose:MonoBehaviour
    {
        private Human owner;private Transform[] bones;
        private Quaternion[] rest,target;private bool active;
        private float started;private Vector3 position;
        internal static bool TryRig(Animator animator,out Transform[] rig,out string why)
        {
            rig=null;why="Animator unavailable";if(animator==null||animator.runtimeAnimatorController==null)return false;
            if(animator.isHuman)
                rig=new[]{animator.GetBoneTransform(HumanBodyBones.LeftUpperArm),animator.GetBoneTransform(HumanBodyBones.LeftLowerArm),animator.GetBoneTransform(HumanBodyBones.LeftHand),animator.GetBoneTransform(HumanBodyBones.RightUpperArm),animator.GetBoneTransform(HumanBodyBones.RightLowerArm),animator.GetBoneTransform(HumanBodyBones.RightHand)};
            else
            {
                var all=animator.GetComponentsInChildren<Transform>(true);
                string[][] names={new[]{"leftupperarm","upperarml","lupperarm","bip001lupperarm","mixamorigleftarm","leftarm"},new[]{"leftlowerarm","lowerarml","lforearm","bip001lforearm","mixamorigleftforearm","leftforearm"},new[]{"lefthand","handl","lhand","bip001lhand","mixamoriglefthand"},new[]{"rightupperarm","upperarmr","rupperarm","bip001rupperarm","mixamorigrightarm","rightarm"},new[]{"rightlowerarm","lowerarmr","rforearm","bip001rforearm","mixamorigrightforearm","rightforearm"},new[]{"righthand","handr","rhand","bip001rhand","mixamorigrighthand"}};
                rig=new Transform[6];
                for(int i=0;i<6;i++)
                {
                    var matches=all.Where(t=>names[i].Contains(new string(t.name.Where(char.IsLetterOrDigit).ToArray()).ToLowerInvariant())).ToArray();
                    if(matches.Length!=1){why="Generic rig bone "+i+" has "+matches.Length+" matches; F9 report needed";return false;}
                    rig[i]=matches[0];
                }
            }
            if(rig.Any(t=>t==null)||rig.Distinct().Count()!=6){why="Arm bones missing or ambiguous";return false;}
            for(int i=0;i<6;i+=3)
                if(!rig[i+1].IsChildOf(rig[i])||!rig[i+2].IsChildOf(rig[i+1])||rig[i].parent==null||rig[i+1].parent==null||(rig[i+1].position-rig[i].position).sqrMagnitude<.000001f||(rig[i+2].position-rig[i+1].position).sqrMagnitude<.000001f)
                {why="Unsupported arm hierarchy or zero-length bones";return false;}
            why=null;return true;
        }
        internal void Begin(Human human,Animator animator)
        {
            Stop();if(!TryRig(animator,out var rig,out _))return;
            owner=human;bones=new[]{rig[0],rig[1],rig[3],rig[4]};rest=bones.Select(t=>t.localRotation).ToArray();target=new Quaternion[4];
            for(int side=0;side<2;side++)
            {
                int j=side*3,k=side*2;var upper=rig[j];var lower=rig[j+1];var hand=rig[j+2];
                var desiredDirection=(human.transform.up+human.transform.right*(side==0?-.25f:.25f)).normalized;
                var delta=Quaternion.FromToRotation(lower.position-upper.position,desiredDirection);
                var upperWorld=delta*upper.rotation;
                target[k]=Quaternion.Inverse(upper.parent.rotation)*upperWorld;
                var lowerWorld=Quaternion.FromToRotation(hand.position-lower.position,human.transform.up)*lower.rotation;
                target[k+1]=Quaternion.Inverse(delta*lower.parent.rotation)*lowerWorld;
            }
            position=human.transform.position;started=Time.unscaledTime;active=true;enabled=true;
        }
        void LateUpdate()
        {
            if(!active)return;
            if(owner==null||owner.IsBeingDestroyed||owner.State!=EntityState.Alive||GameManager.GameState!=GameState.Running||owner.LeftHandSlot?.Get()!=null||owner.RightHandSlot?.Get()!=null||(owner.transform.position-position).sqrMagnitude>.04f){Stop();return;}
            float t=Time.unscaledTime-started;
            if(t>=3.5f){Stop();return;}
            float weight=Mathf.SmoothStep(0,1,Mathf.Min(t/.25f,(3.5f-t)/.35f));
            for(int i=0;i<bones.Length;i++)if(bones[i]!=null)bones[i].localRotation=Quaternion.Slerp(rest[i],target[i],weight);
        }
        internal void Stop()
        {
            if(active&&bones!=null)for(int i=0;i<bones.Length;i++)if(bones[i]!=null)bones[i].localRotation=rest[i];
            active=false;bones=null;rest=null;target=null;owner=null;
        }
        void OnDisable(){Stop();}
        void OnDestroy(){Stop();}
    }
}
