using System;
using System.Linq;
using System.Reflection;
using Assets.Scripts;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Inventory;
using Assets.Scripts.Objects.Entities;
using Assets.Scripts.Emotes;
using BepInEx.Logging;
using HarmonyLib;
using StationeersMods.Interface;
using UnityEngine;

namespace StationEmotes
{
    [StationeersMod("kreezy.stationemotes", "Station Emotes TEST", "0.1.0")]
    public sealed class Plugin:ModBehaviour
    {
        internal const int HandsUp=41001,Cancel=41002;
        internal static readonly FieldInfo BodyAnimator=AccessTools.Field(typeof(EmoteController),"_animator");
        internal static readonly FieldInfo HumanField=AccessTools.Field(typeof(EmoteController),"_human");
        internal static ManualLogSource Log;
        private Harmony harmony;
        public override void OnLoaded(ContentHandler handler)
        {
            base.OnLoaded(handler);Log=BepInEx.Logging.Logger.CreateLogSource("StationEmotes");
            harmony=new Harmony("kreezy.stationemotes");
            try{harmony.PatchAll(typeof(Plugin).Assembly);Log.LogInfo("0.1.0 TEST loaded: F9 rig report, F10 hands up, F11 cancel. Procedural pose, not an imported clip.");}
            catch(Exception e){enabled=false;Log.LogError(e);}
        }
        void Update()
        {
            if(GameManager.IsBatchMode||GameManager.GameState!=GameState.Running)return;
            var human=InventoryManager.ParentHuman;
            if(human==null||human.State!=EntityState.Alive||human.EmoteController==null)return;
            if(Input.GetKeyDown(KeyCode.F9))Report(human.EmoteController);
            if(Input.GetKeyDown(KeyCode.F11)){human.EmoteController.OnEmote(new EmoteData(Cancel,0,EmoteType.Body));return;}
            if(!Input.GetKeyDown(KeyCode.F10))return;
            if(human.LeftHandSlot?.Get()!=null||human.RightHandSlot?.Get()!=null){Log.LogWarning("Empty both hands before the test pose.");return;}
            var animator=BodyAnimator.GetValue(human.EmoteController) as Animator;
            if(!HandsUpPose.TryRig(animator,out _,out string why)){Report(human.EmoteController);Log.LogWarning("Hands-up skipped: "+why);return;}
            human.EmoteController.OnEmote(new EmoteData(HandsUp,3500,EmoteType.Body));
        }
        internal static void Report(EmoteController owner)
        {
            try
            {
                var a=BodyAnimator.GetValue(owner) as Animator;
                if(a==null){Log.LogWarning("Body Animator unavailable.");return;}
                Log.LogInfo("RIG controller="+(a.runtimeAnimatorController?.name??"none")+"; avatar="+(a.avatar?.name??"none")+"; humanoid="+a.isHuman+"; layers="+a.layerCount);
                for(int i=0;i<a.layerCount;i++)Log.LogInfo("LAYER "+i+": "+a.GetLayerName(i)+"; weight="+a.GetLayerWeight(i));
                foreach(var p in a.parameters)Log.LogInfo("PARAM "+p.name+"; type="+p.type);
                foreach(var clip in a.runtimeAnimatorController?.animationClips??Array.Empty<AnimationClip>())Log.LogInfo("CLIP "+clip.name+"; seconds="+clip.length+"; humanoid="+clip.humanMotion);
                var bones=a.GetComponentsInChildren<Transform>(true);Log.LogInfo("RIG transforms="+bones.Length);
                foreach(var t in bones.Take(180))Log.LogInfo("BONE "+Path(t,a.transform));
                if(HandsUpPose.TryRig(a,out var rig,out string why))Log.LogInfo("TEST RIG READY: "+string.Join(", ",rig.Select(t=>Path(t,a.transform))));
                else Log.LogWarning("TEST RIG UNSUPPORTED: "+why);
            }
            catch(Exception e){Log.LogWarning("Rig report failed: "+e);}
        }
        private static string Path(Transform t,Transform root)
        {string result=t.name;for(var p=t.parent;p!=null&&p!=root;p=p.parent)result=p.name+"/"+result;return result;}
        [HarmonyPatch(typeof(EmoteController),"DoEmote")]
        private static class PlayPatch
        {
            static bool Prefix(EmoteController __instance,EmoteData __0)
            {
                if(__0.EmoteType!=EmoteType.Body)return true;
                if(__0.AnimationIndex!=HandsUp&&__0.AnimationIndex!=Cancel){__instance.GetComponent<HandsUpPose>()?.Stop();return true;}
                // Consume our IDs on DS too; only native relay needs to run there.
                if(GameManager.IsBatchMode)return false;
                try
                {
                    var pose=__instance.GetComponent<HandsUpPose>();
                    if(__0.AnimationIndex==Cancel){pose?.Stop();return false;}
                    var human=HumanField.GetValue(__instance) as Human;
                    var animator=BodyAnimator.GetValue(__instance) as Animator;
                    if(human==null||human.State!=EntityState.Alive||human.LeftHandSlot?.Get()!=null||human.RightHandSlot?.Get()!=null)return false;
                    if(!HandsUpPose.TryRig(animator,out _,out string reason)){Log.LogWarning("Remote/local pose skipped: "+reason);return false;}
                    if(pose==null)pose=__instance.gameObject.AddComponent<HandsUpPose>();
                    pose.Begin(human,animator);Log.LogInfo("Hands-up started; human="+human.ReferenceId);
                }
                catch(Exception e){Log.LogWarning("Hands-up skipped: "+e);}
                return false;
            }
        }
        void OnDestroy()
        {
            if(!GameManager.IsBatchMode)foreach(var p in UnityEngine.Object.FindObjectsOfType<HandsUpPose>())p.Stop();
            harmony?.UnpatchSelf();
        }
    }
}
