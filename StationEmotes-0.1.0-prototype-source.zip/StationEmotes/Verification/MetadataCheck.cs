using System;using System.Linq;using Mono.Cecil;
class Check{
 static int n;static void Assert(bool b,string message){n++;if(!b)throw new Exception(message);}
 static void Main(){
 using var game=AssemblyDefinition.ReadAssembly("/workspace/work/build-deps/Stationeers/rocketstation_Data/Managed/Assembly-CSharp.dll");
 var emote=game.MainModule.Types.Single(t=>t.FullName=="Assets.Scripts.Emotes.EmoteController");
 Assert(emote.Fields.Any(f=>f.Name=="_animator"&&f.FieldType.FullName=="UnityEngine.Animator"),"body Animator reflection binding invalid");
 Assert(emote.Fields.Any(f=>f.Name=="_human"&&f.FieldType.Name=="Human"),"Human reflection binding invalid");
 Assert(emote.Methods.Any(m=>m.Name=="DoEmote"&&m.Parameters.Count==1&&m.Parameters[0].ParameterType.Name=="EmoteData"),"Harmony target mismatch");
 Assert(emote.Methods.Any(m=>m.Name=="OnEmote"&&m.Parameters.Count==1&&m.Parameters[0].ParameterType.Name=="EmoteData"),"native dispatch missing");
 var msg=game.MainModule.Types.Single(t=>t.Name=="AnimationEmoteMessage");
 Assert(msg.Fields.Any(f=>f.Name=="AnimationIndex"&&f.FieldType.FullName=="System.Int32"),"native IDs not Int32");
 Assert(msg.Fields.Any(f=>f.Name=="Delay"&&f.FieldType.FullName=="System.Int32"),"native delay changed");
 Assert(msg.Fields.Any(f=>f.Name=="HumanNetId"&&f.FieldType.FullName=="System.Int64"),"native human identity changed");
 Assert(msg.Methods.Single(m=>m.Name=="Process").Body.Instructions.Any(i=>i.Operand is MethodReference r&&r.Name=="SendToClients"),"native relay absent");
 using var mod=AssemblyDefinition.ReadAssembly("/tmp/station-emotes-010/StationEmotes/Assemblies/StationEmotes.dll");
 var plugin=mod.MainModule.Types.Single(t=>t.Name=="Plugin");
 Assert(plugin.CustomAttributes.Any(a=>a.AttributeType.FullName=="StationeersMods.Interface.StationeersMod"),"loader metadata missing");
 var pose=mod.MainModule.Types.Single(t=>t.Name=="HandsUpPose");
 Assert(pose.Methods.Any(m=>m.Name=="OnDisable")&&pose.Methods.Any(m=>m.Name=="OnDestroy"),"lifecycle restoration absent");
 Assert(!mod.MainModule.AssemblyReferences.Any(a=>a.Name=="LibConstruct"),"unexpected dependency");
 Assert(mod.MainModule.Resources.Count==0,"unexpected bundled assets");
 Console.WriteLine(n+" native API/metadata compatibility checks passed. No Unity animation or network execution performed.");
 }
}
