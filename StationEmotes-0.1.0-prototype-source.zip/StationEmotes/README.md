# Station Emotes0.1.0 — first test
Requires BepInEx and StationeersLaunchPad. Install exactly one StationEmotes folder and enable it in LaunchPad. Use the same test version on observing clients; server installation is recommended for a consistent test setup. No LibConstruct or sound mod dependency.

In a loaded world, empty both hands and stand still. Press F9 once to log body animator, avatar, layers, parameters, clip names and transform paths. Press F10 for the3.5-second procedural hands-up pose. F11 cancels using the same native emote channel. Movement beyond20cm, taking a held item, death, leaving the world or component teardown also ends the local pose. New native emotes cancel it too.

First verify in third person with native camera controls or ask a second player to observe. First-person arms/viewmodel are not separately overridden. Do not judge success solely from first-person view.

If nothing happens, send BepInEx LogOutput.log containing StationEmotes RIG / BONE / TEST RIG lines. Generic rigs need an unambiguous supported arm chain; otherwise the prototype refuses to guess.

This is a procedural bone-pose test, NOT an imported Animator clip. It writes only four arm-bone rotations in LateUpdate, restores captured rotations when stopped, and does not move the character root, change colliders, modify the shared controller or create a new packet format. Existing AnimationEmoteMessage carries IDs41001(pose)/41002(cancel). All clients need these handlers for the pose to be visible.

Remaining live verification: Harmony installation, actual skeleton matching, rotation axes and IK order, suit/body variants, third-person appearance, existing native emotes and multiplayer visibility. Visual clipping or incorrect arm placement is possible in this experimental version. No live Unity test was available during preparation.
