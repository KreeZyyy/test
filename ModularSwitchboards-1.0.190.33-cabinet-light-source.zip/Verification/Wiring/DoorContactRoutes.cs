using System;using System.Linq;using ModularSwitchboards;
partial class RouteHarness
{
 internal static void RunDoorContactRoutes()
 {
  int checks=0;
  foreach(bool medium in new[]{false,true})foreach(int side in new[]{-1,1})foreach(int pin in new[]{0,1})foreach(var kind in new[]{CabinetWireKind.Normal,CabinetWireKind.Heavy,CabinetWireKind.SuperHeavy})
  {
   if(!medium&&side==1)continue;
   var h=new RouteHarness{Owner=new(){PrefabName=medium?"medium":"small"},routingHalfWidth=medium?.366f:.168f,routingHalfHeight=medium?.477f:.228f};
   h.moduleReservations=WireModuleSpace.Reservations(medium?.65f:.35f,medium?new[]{-.27f,0,.27f}:new[]{-.108f,.108f}).ToArray();
   var source=new CabinetWireEnd(10,1);var target=new CabinetWireEnd(90,0);h.PowerModules.Add(10);
   h.contacts[source]=new Contact{End=source,Position=new(0,medium?.219375f:.057375f,.043f),Exit=new(0,medium?.204f:.042f,WireRouting.Plane),Bounds=new(-.0198f,.0198f,medium?.219375f:.057375f,medium?.320625f:.158625f)};
   float center=side*(medium?.357f:.177f),x=center-side*.009f,y=-side*DoorContactLayout.ContactY(pin);
   var entry=new WirePoint(x,y,.0244f);var exit=new WirePoint(center-side*.030f,y,WireRouting.Plane);
   var bounds=new WireRect(x-(side==1?.009f:.018f),x+(side==1?.018f:.009f),y-.011f,y+.011f);
   h.contacts[target]=new Contact{End=target,Position=new(x,y,.0244f),Exit=new(exit.X,exit.Y,exit.Z),Bounds=bounds};
   if(bounds.Contains(exit,.004f))throw new Exception("sensor terminal exit is inside its own body");checks++;
   var path=h.MakeRoute(source,target,out _,out var failure,kind);if(path==null)throw new Exception("sensor route "+medium+" side"+side+" pin"+pin+" "+kind+": "+failure);checks++;
   if((path[path.Length-1]-entry).Squared>1e-10f)throw new Exception("sensor route misses terminal");checks++;
  }
  Console.WriteLine("Door Contact: "+checks+" terminal route checks passed.");
 }
}
