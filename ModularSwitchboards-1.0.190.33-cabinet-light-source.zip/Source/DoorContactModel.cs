using UnityEngine;
namespace ModularSwitchboards
{
    internal static class DoorContactModel
    {
        internal static MeshRenderer Install(DinBreaker owner,Material black,Material grey)
        {
            for(int pin=0;pin<2;pin++)
            {
                var terminal=new GameObject("DoorContactTerminal"+pin){layer=owner.gameObject.layer};terminal.transform.SetParent(owner.transform,false);terminal.transform.localPosition=new Vector3(0,pin*.024f,0);DoorModules.TerminalCube(terminal.transform,1);
                var path=DoorContactLayout.FixedLead(pin);
                var wire=DoorModules.Part(owner.transform,"DoorContactFixedLead"+pin,WireMesh.Build(path),CabinetGeometry.Materials[3]);WireVisualLighting.Apply(wire);
            }
            var assembly=new GameObject("DoorContactRimAssembly"){layer=owner.gameObject.layer};assembly.transform.SetParent(owner.transform,false);assembly.transform.localPosition=new Vector3(0,0,DoorContactLayout.FrontOffset);
            var root=assembly.transform;
            var body=DoorModules.Part(root,"DoorContactHousing",DoorModules.Box(new Vector3(-.008f,.012f,.065f),new Vector3(.030f,.032f,.038f)),black);
            for(int pin=0;pin<2;pin++)
            {
                var inlet=DoorModules.Part(root,"DoorContactCableInlet",DoorModuleGeometry.Cylinder(.0032f,.042f,.048f),black);inlet.transform.localPosition=new Vector3(-.014f,.004f+pin*.016f,0);
            }
            var collar=DoorModules.Part(root,"DoorContactPlungerCollar",DoorModuleGeometry.Cylinder(.0055f,.083f,.089f),black);collar.transform.localPosition=new Vector3(-.008f,.012f,0);
            var plunger=new GameObject("DoorContactPlunger"){layer=owner.gameObject.layer};plunger.transform.SetParent(root,false);
            var actuator=DoorModules.Part(plunger.transform,"DoorContactActuator",DoorModuleGeometry.Cylinder(.0033f,.088f,.112f),grey);actuator.transform.localPosition=new Vector3(-.008f,.012f,0);
            var view=owner.gameObject.AddComponent<DoorContactView>();view.Owner=owner;view.Plunger=plunger.transform;return body;
        }
    }
    public sealed class DoorContactView:MonoBehaviour
    {
        public DinBreaker Owner;public Transform Plunger;
        private bool initialized,last;
        private void LateUpdate()
        {
            if(Owner==null||Plunger==null)return;
            bool open=CabinetWiring.CabinetOf(Owner)?.IsOpen==true;
            if(initialized&&open==last)return;initialized=true;last=open;
            Plunger.localPosition=new Vector3(0,0,open?0:-.008f);
            DoorModules.PaintCubes(transform);
        }
    }
}
