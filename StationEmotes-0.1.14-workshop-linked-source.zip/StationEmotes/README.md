# Station Emotes 0.1.14
Requires BepInEx and StationeersLaunchPad. Replace the previous mod version, do not enable duplicate versions.

Hold F10 and select with the mouse; release to play. F11 or movement cancels. Esc closes the menu only. Native Wave loops; Salute and Sit hold. Custom Hands up, Point, Robot dance, Meme dance, Agree, Disagree and Facepalm require empty hands. Agree repeats a gentle nod, Disagree repeats a head shake, Facepalm holds the right palm in front of the visor. All persist until cancelled, switched or the same entry selected again. Observing clients should use the same version.

0.1.14 fixes Facepalm on humanoid avatars without optional finger mappings. Only the right arm and hand are required. When fingers are unavailable or degenerate, position IK still brings the hand to the visor while wrist orientation stays with the native animation. Available valid fingers enable the more precise palm alignment. The other gestures and dances are unchanged.

0.1.13 added three gestures and a larger ten-item wheel. IDs Agree41006, Disagree41007 and Facepalm41008 use the existing game emote message and cancellation/transition path. Facepalm uses humanoid right-hand IK; nod/shake use head transforms in the same owned overlay. No new root movement or game simulation is added.

The dance baseline from 0.1.12 keeps the 0.1.11 owned PreviousInputs overlay graph (confirmed live for Hands up and Point). It corrects dance ordering: humanoid pelvis/knee motion is submitted before SolveIK, then five upper-body transform slots are applied after SolveIK. Raw leg/hip transform slots are not applied over solved feet. This prevents the IK pass from rebuilding away the visible upper-body dance and prevents subsequent raw leg rotations from undoing foot support. The character root is not moved.

The 0.1.11 user log recorded 49 processed humanoid frames and 9/9 or 10/10 bone updates for dances despite their lack of visible motion. These counters prove execution, not visual correctness. The IK pass is the code path that distinguishes dance from working arm poses. The change requires another live visual test.

Custom poses still use procedural stream bone updates, with humanoid foot IK for dance where available. No imported animation clip or new physical movement is included. Native animations and cancellation policies are unchanged.

The earlier 0.1.10 scheduling failure was addressed in 0.1.11. Execution counters remain logged after one second; actual Unity rendering, graph evaluation, foot IK and multiplayer appearance still require live verification.

Build: source/StationEmotes.csproj, net472. Set GameManagedDirectory, BepInExDirectory and LaunchPadDirectory. Use the installed game UnityEngine.AnimationModule (including UnityEngine.Experimental.Animations output extensions) and PhysicsModule. Do not ship game or loader DLLs.
