using System;
using Assets.Scripts;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Inventory;
using Assets.Scripts.Objects.Entities;
using Assets.Scripts.Emotes;
using UnityEngine;
namespace StationEmotes
{
 internal static class GesturePolicy
 {
  // Two gentle nods/shakes, followed by a pause. Continuous until cancelled.
  internal static float Sample(float seconds)
  {
   if(float.IsNaN(seconds)||float.IsInfinity(seconds)||seconds<0)return 0;
   float phase=seconds%2.6f;
   return phase<1.6f?(float)Math.Sin(phase/1.6f*Math.PI*4)* (float)Math.Sin(phase/1.6f*Math.PI):0;
  }
 }
 [DefaultExecutionOrder(10000)]
 public sealed class GesturePose:MonoBehaviour
 {
  internal bool Active {get;private set;}
  internal int Index {get;private set;}
  private Human owner;private NativePose pose;private Quaternion rest;private Vector3 axis,origin;
  private float started;
  internal void Begin(Human human,Animator animator,int kind)
  {
   Stop();if(animator==null||!animator.isHuman)return;
   var head=animator.GetBoneTransform(HumanBodyBones.Head);
   if(head==null||head.parent==null){Plugin.Log.LogWarning("Gesture skipped: humanoid head missing.");return;}
   var facing=human.CharacterRotationY!=null?human.CharacterRotationY:human.transform;
   owner=human;Index=kind;rest=head.localRotation;origin=human.transform.position;
   axis=Quaternion.Inverse(head.parent.rotation)*(kind==Plugin.Disagree?facing.up:facing.right);
   pose=new NativePose();
   if(!pose.Attach(animator,new[]{head})){Stop();return;}
   if(kind==Plugin.Facepalm)
   {
    var hand=animator.GetBoneTransform(HumanBodyBones.RightHand);
    var index=animator.GetBoneTransform(HumanBodyBones.RightIndexProximal);
    var little=animator.GetBoneTransform(HumanBodyBones.RightLittleProximal);
    var middle=animator.GetBoneTransform(HumanBodyBones.RightMiddleProximal);
    var upper=animator.GetBoneTransform(HumanBodyBones.RightUpperArm);
    var lower=animator.GetBoneTransform(HumanBodyBones.RightLowerArm);
    if(hand==null||upper==null||lower==null){Stop();Plugin.Log.LogWarning("Facepalm skipped: right arm or hand missing.");return;}
    // Finger mappings are OPTIONAL in a valid humanoid avatar. They improve
    // palm orientation, but must never prevent the native arm IK from running.
    bool orient=false;var desiredHand=hand.rotation;
    if(index!=null&&little!=null&&middle!=null)
    {
     var fingers=middle.position-hand.position;
     var normal=-Vector3.Cross(index.position-hand.position,little.position-hand.position);
     if(fingers.sqrMagnitude>.000001f&&normal.sqrMagnitude>.00000001f)
     {
      var frame=Quaternion.LookRotation(normal.normalized,fingers.normalized);
      desiredHand=Quaternion.LookRotation(-facing.forward,facing.up)*Quaternion.Inverse(frame)*hand.rotation;
      orient=true;
     }
    }
    var target=head.position+facing.forward*.16f+facing.up*.10f+facing.right*.025f;
    pose.SetFacepalm(head.InverseTransformPoint(target),Quaternion.Inverse(head.rotation)*desiredHand,orient);
    Plugin.Log.LogInfo("Facepalm arm IK ready; finger-based palm alignment="+orient);

   }
   started=Time.unscaledTime;Active=true;
   Plugin.Log.LogInfo("Gesture started: id="+kind+", human="+human.ReferenceId);
  }
  private void Update()
  {
   if(!Active)return;
   if(owner==null||owner.IsBeingDestroyed||owner.State!=EntityState.Alive||GameManager.GameState!=GameState.Running){Stop();return;}
   if(HeldEmote.MovingLocally(owner)||owner.LeftHandSlot?.Get()!=null||owner.RightHandSlot?.Get()!=null||(owner.transform.position-origin).sqrMagnitude>.01f){Stop(true);return;}
   float t=Time.unscaledTime-started,blend=Mathf.SmoothStep(0,1,Mathf.Clamp01(t/.55f));
   float angle=Index==Plugin.Facepalm?9f:GesturePolicy.Sample(t)*(Index==Plugin.Disagree?18f:13f);
   pose.Set(0,Quaternion.AngleAxis(angle,axis)*rest,blend);
   if(!pose.Submit(owner,false))Stop(true);
  }
  internal void Stop(bool notify=false)
  {
   bool send=Active&&notify&&owner!=null&&owner==InventoryManager.ParentHuman&&GameManager.GameState==GameState.Running;
   var emotes=owner?.EmoteController;Active=false;Index=0;pose?.Dispose();pose=null;owner=null;
   if(send&&emotes!=null)try{emotes.OnEmote(new EmoteData(Plugin.Cancel,0,EmoteType.Body));}catch(Exception e){Plugin.Log.LogWarning("Gesture cancel relay failed: "+e);}
  }
  private void OnDisable(){Stop();}private void OnDestroy(){Stop();}
 }
}
