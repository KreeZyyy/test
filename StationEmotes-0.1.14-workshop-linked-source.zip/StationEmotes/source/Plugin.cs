using System;
using System.Linq;
using System.Reflection;
using Assets.Scripts;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Inventory;
using Assets.Scripts.Objects.Entities;
using Assets.Scripts.Emotes;
using BepInEx.Logging;
using HarmonyLib;
using StationeersMods.Interface;
using UnityEngine;

namespace StationEmotes
{
    [StationeersMod("kreezy.stationemotes", "Station Emotes", "0.1.14")]
    public sealed class Plugin:ModBehaviour
    {
        internal const int HandsUp=41001,Cancel=41002,Point=41003,Dance=41004,MemeDance=41005,Agree=41006,Disagree=41007,Facepalm=41008;
        internal static bool IsGesture(int id)=>id==Agree||id==Disagree||id==Facepalm;
        internal static readonly FieldInfo BodyAnimator=AccessTools.Field(typeof(EmoteController),"_animator");
        internal static readonly FieldInfo HumanField=AccessTools.Field(typeof(EmoteController),"_human");
        internal static ManualLogSource Log;
        private Harmony harmony;
        public override void OnLoaded(ContentHandler handler)
        {
            base.OnLoaded(handler);Log=BepInEx.Logging.Logger.CreateLogSource("StationEmotes");
            harmony=new Harmony("kreezy.stationemotes");
            try{harmony.PatchAll(typeof(Plugin).Assembly);Log.LogInfo("0.1.14 loaded: F9 rig report, hold F10 emote menu, F11 cancel. Custom poses use a PreviousInputs Animator overlay; dance uses humanoid foot IK.");}
            catch(Exception e){enabled=false;Log.LogError(e);}
        }
        void Update()
        {
            if(GameManager.IsBatchMode||GameManager.GameState!=GameState.Running){EmoteWheel.Close();return;}
            var human=InventoryManager.ParentHuman;
            if(human==null||human.State!=EntityState.Alive||human.EmoteController==null){EmoteWheel.Close();return;}
            if(Input.GetKeyDown(KeyCode.F9))Report(human.EmoteController);
            if(Input.GetKeyDown(KeyCode.F11)){EmoteWheel.Close();human.EmoteController.OnEmote(new EmoteData(Cancel,0,EmoteType.Body));return;}
            EmoteWheel.Tick(human);
        }
        internal static void TriggerSelection(Human human,int selection)
        {
            if(human==null||human!=InventoryManager.ParentHuman||human.State!=EntityState.Alive||human.EmoteController==null)return;
            int[] ids={2,1,3,HandsUp,Point,Dance,MemeDance,Agree,Disagree,Facepalm};
            if(selection<0||selection>=ids.Length)return;
            var held=human.EmoteController.GetComponent<HeldEmote>();
            if(human.EmoteController.GetComponent<GesturePose>()?.Index==ids[selection]||held?.Active==true&&held.Index==ids[selection]||selection>=3&&human.EmoteController.GetComponent<HandsUpPose>()?.Index==ids[selection]||selection>=5&&human.EmoteController.GetComponent<RobotDance>()?.Index==ids[selection])
            {human.EmoteController.OnEmote(new EmoteData(Cancel,0,EmoteType.Body));return;}
            if(HeldEmote.MovingLocally(human)){Log.LogWarning("Stand still before starting an emote.");return;}
            string[] native={"wave","salute","sit"};
            if(selection<native.Length){Emote.Trigger(native[selection]);return;}
            if(human.LeftHandSlot?.Get()!=null||human.RightHandSlot?.Get()!=null){Log.LogWarning("Empty both hands before the emote.");return;}
            var animator=BodyAnimator.GetValue(human.EmoteController) as Animator;
            if(!HandsUpPose.TryRig(animator,out _,out string why)){Report(human.EmoteController);Log.LogWarning("Arm pose skipped: "+why);return;}
            human.EmoteController.OnEmote(new EmoteData(ids[selection],3500,EmoteType.Body));
        }
        internal static void Report(EmoteController owner)
        {
            try
            {
                var a=BodyAnimator.GetValue(owner) as Animator;
                if(a==null){Log.LogWarning("Body Animator unavailable.");return;}
                Log.LogInfo("RIG controller="+(a.runtimeAnimatorController?.name??"none")+"; avatar="+(a.avatar?.name??"none")+"; humanoid="+a.isHuman+"; layers="+a.layerCount);
                for(int i=0;i<a.layerCount;i++)
                {
                    var state=a.GetCurrentAnimatorStateInfo(i);
                    Log.LogInfo("LAYER "+i+": "+a.GetLayerName(i)+"; weight="+a.GetLayerWeight(i)+"; state="+state.fullPathHash+"; time="+state.normalizedTime);
                    foreach(var c in a.GetCurrentAnimatorClipInfo(i))Log.LogInfo("ACTIVE CLIP "+i+": "+c.clip?.name+"; weight="+c.weight);
                }
                foreach(var p in a.parameters)Log.LogInfo("PARAM "+p.name+"; type="+p.type);
                foreach(var clip in a.runtimeAnimatorController?.animationClips??Array.Empty<AnimationClip>())Log.LogInfo("CLIP "+clip.name+"; seconds="+clip.length+"; humanoid="+clip.humanMotion);
                var bones=a.GetComponentsInChildren<Transform>(true);Log.LogInfo("RIG transforms="+bones.Length);
                foreach(var t in bones.Take(180))Log.LogInfo("BONE "+Path(t,a.transform));
                if(HandsUpPose.TryRig(a,out var rig,out string why))Log.LogInfo("RIG READY: "+string.Join(", ",rig.Select(t=>Path(t,a.transform))));
                else Log.LogWarning("RIG UNSUPPORTED: "+why);
            }
            catch(Exception e){Log.LogWarning("Rig report failed: "+e);}
        }
        private static string Path(Transform t,Transform root)
        {string result=t.name;for(var p=t.parent;p!=null&&p!=root;p=p.parent)result=p.name+"/"+result;return result;}
        [HarmonyPatch(typeof(EmoteController),"DoEmote")]
        private static class PlayPatch
        {
            static bool Prefix(EmoteController __instance,EmoteData __0)
            {
                if(__0.EmoteType!=EmoteType.Body)return true;
                if(!GameManager.IsBatchMode)
                {
                    var transition=__instance.GetComponent<EmoteTransition>();
                    if(__0.AnimationIndex==Cancel){if(transition!=null)transition.Cancel();else EmoteTransition.StopBody(__instance);return false;}
                    if((__0.AnimationIndex>=1&&__0.AnimationIndex<=3||(__0.AnimationIndex==HandsUp||__0.AnimationIndex==Point||__0.AnimationIndex==Dance||__0.AnimationIndex==MemeDance||IsGesture(__0.AnimationIndex)))&&transition?.Applying!=true)
                    {
                        if(transition==null)transition=__instance.gameObject.AddComponent<EmoteTransition>();
                        transition.Schedule(__instance,__0);return false;
                    }
                }
                __instance.GetComponent<GesturePose>()?.Stop();
                if(IsGesture(__0.AnimationIndex))
                {
                    if(GameManager.IsBatchMode)return false;
                    try
                    {
                        var human=HumanField.GetValue(__instance) as Human;
                        var animator=BodyAnimator.GetValue(__instance) as Animator;
                        if(human==null||human.State!=EntityState.Alive||HeldEmote.MovingLocally(human)||human.LeftHandSlot?.Get()!=null||human.RightHandSlot?.Get()!=null)return false;
                        EmoteTransition.StopBody(__instance);
                        var gesture=__instance.GetComponent<GesturePose>()??__instance.gameObject.AddComponent<GesturePose>();
                        gesture.Begin(human,animator,__0.AnimationIndex);
                    }
                    catch(Exception e){Log.LogWarning("Gesture skipped: "+e);}
                    return false;
                }
                __instance.GetComponent<RobotDance>()?.Stop();
                if(__0.AnimationIndex==Dance||__0.AnimationIndex==MemeDance)
                {
                    if(GameManager.IsBatchMode)return false;
                    try
                    {
                    var human=HumanField.GetValue(__instance) as Human;
                    var animator=BodyAnimator.GetValue(__instance) as Animator;
                    if(human==null||human.State!=EntityState.Alive||HeldEmote.MovingLocally(human)||human.LeftHandSlot?.Get()!=null||human.RightHandSlot?.Get()!=null)return false;
                    __instance.GetComponent<HandsUpPose>()?.Stop();__instance.GetComponent<HeldEmote>()?.Stop(false);
                    var dance=__instance.GetComponent<RobotDance>()??__instance.gameObject.AddComponent<RobotDance>();
                    dance.Begin(human,animator,__0.AnimationIndex==MemeDance);
                    }
                    catch(Exception e){Log.LogWarning("Robot dance skipped: "+e);}
                    return false;
                }
                if(__0.AnimationIndex>=1&&__0.AnimationIndex<=3)
                {
                    if(GameManager.IsBatchMode)return false;
                    try
                    {
                        var human=HumanField.GetValue(__instance) as Human;
                        if(human==null||human.State!=EntityState.Alive||HeldEmote.MovingLocally(human))return false;
                        __instance.GetComponent<HandsUpPose>()?.Stop();
                        var sit=__instance.GetComponent<HeldEmote>()??__instance.gameObject.AddComponent<HeldEmote>();
                        sit.Begin(human,BodyAnimator.GetValue(__instance) as Animator,__instance,__0.AnimationIndex);
                    }
                    catch(Exception e){Log.LogWarning("Held emote skipped: "+e);}
                    return false;
                }
                __instance.GetComponent<HeldEmote>()?.Stop(false);
                if(__0.AnimationIndex!=HandsUp&&__0.AnimationIndex!=Point&&__0.AnimationIndex!=Cancel){__instance.GetComponent<HandsUpPose>()?.Stop();return true;}
                // Consume our IDs on DS too; only native relay needs to run there.
                if(GameManager.IsBatchMode)return false;
                try
                {
                    var pose=__instance.GetComponent<HandsUpPose>();
                    if(__0.AnimationIndex==Cancel){pose?.Stop();return false;}
                    var human=HumanField.GetValue(__instance) as Human;
                    var animator=BodyAnimator.GetValue(__instance) as Animator;
                    if(human==null||human.State!=EntityState.Alive||human.LeftHandSlot?.Get()!=null||human.RightHandSlot?.Get()!=null)return false;
                    if(!HandsUpPose.TryRig(animator,out _,out string reason)){Log.LogWarning("Remote/local pose skipped: "+reason);return false;}
                    if(pose==null)pose=__instance.gameObject.AddComponent<HandsUpPose>();
                    pose.Begin(human,animator,__0.AnimationIndex==Point);if(pose.Active)Log.LogInfo((__0.AnimationIndex==Point?"Point":"Hands-up")+" started; human="+human.ReferenceId);
                }
                catch(Exception e){Log.LogWarning("Arm pose skipped: "+e);}
                return false;
            }
        }
        void OnDestroy()
        {
            EmoteWheel.Close();
            if(!GameManager.IsBatchMode)foreach(var p in UnityEngine.Object.FindObjectsOfType<HandsUpPose>())p.Stop();
            if(!GameManager.IsBatchMode)foreach(var p in UnityEngine.Object.FindObjectsOfType<HeldEmote>())p.Stop(false);
            if(!GameManager.IsBatchMode)foreach(var p in UnityEngine.Object.FindObjectsOfType<EmoteTransition>())p.Cancel();
            if(!GameManager.IsBatchMode)foreach(var p in UnityEngine.Object.FindObjectsOfType<RobotDance>())p.Stop();
            if(!GameManager.IsBatchMode)foreach(var p in UnityEngine.Object.FindObjectsOfType<GesturePose>())p.Stop();
            harmony?.UnpatchSelf();
        }
    }
}
