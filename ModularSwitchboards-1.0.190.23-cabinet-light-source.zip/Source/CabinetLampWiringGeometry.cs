namespace ModularSwitchboards
{
    internal static class CabinetLampWiringGeometry
    {
        // The front lamp and fixed lead are not solid blockers in the plate routing
        // plane. Reserve only the real Door Bridge terminal footprint, not the
        // huge bounding box spanning plate terminal and front-mounted housing.
        internal static WireRect PlateBounds(WirePoint center)=>new WireRect(center.X-.011f,center.X+.011f,center.Y-.012f,center.Y+.012f);
        internal static WirePoint Exit(WirePoint entry)=>new WirePoint(entry.X-.020f,entry.Y,WireRouting.Plane);
    }
}
