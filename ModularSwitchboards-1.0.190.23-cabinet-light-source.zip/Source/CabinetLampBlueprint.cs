using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;
namespace ModularSwitchboards
{
    // Only explicit owned lamp parts belong in its snapshot. Never traverse the
    // construction cursor, which also contains fill meshes and line-only edges.
    internal static class CabinetLampBlueprint
    {
        internal static Mesh Build(Mesh body,Mesh lens,Mesh terminal,Matrix4x4 terminalMatrix,Mesh lead)
        {
            var vertices=new List<Vector3>();var triangles=new List<int>();
            Append(body,Matrix4x4.identity,vertices,triangles);Append(lens,Matrix4x4.identity,vertices,triangles);
            Append(terminal,terminalMatrix,vertices,triangles);Append(lead,Matrix4x4.identity,vertices,triangles);
            if(triangles.Count==0)throw new InvalidOperationException("Cabinet light preview has no triangle geometry.");
            var mesh=new Mesh{name="CabinetLamp.OwnPartsBlueprint",indexFormat=IndexFormat.UInt32};mesh.SetVertices(vertices);mesh.SetTriangles(triangles,0);mesh.RecalculateNormals();mesh.RecalculateBounds();return mesh;
        }
        private static void Append(Mesh source,Matrix4x4 matrix,List<Vector3> vertices,List<int> triangles)
        {
            if(source==null)return;
            int first=vertices.Count;Vector3[] points=null;bool mirrored=matrix.determinant<0;
            for(int sub=0;sub<source.subMeshCount;sub++)
            {
                // Check BEFORE GetTriangles: Unity reports an error for Lines/Points.
                if(source.GetTopology(sub)!=MeshTopology.Triangles)continue;
                var ids=source.GetTriangles(sub);
                if(ids.Length%3!=0)throw new InvalidOperationException("Invalid lamp preview triangle count.");
                if(points==null){points=source.vertices;foreach(var point in points)vertices.Add(matrix.MultiplyPoint3x4(point));}
                for(int i=0;i<ids.Length;i+=3){triangles.Add(first+ids[i]);triangles.Add(first+ids[i+(mirrored?2:1)]);triangles.Add(first+ids[i+(mirrored?1:2)]);}
            }
        }
    }
}
