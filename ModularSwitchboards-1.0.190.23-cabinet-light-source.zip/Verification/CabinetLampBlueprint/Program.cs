using System;using System.Collections.Generic;using System.Linq;using ModularSwitchboards;using UnityEngine;
namespace UnityEngine.Rendering{public enum IndexFormat{UInt32}}
namespace UnityEngine{
 public enum MeshTopology{Triangles,Lines,Points}
 public struct Vector3{public float x,y,z;public Vector3(float a,float b,float c){x=a;y=b;z=c;}}
 public struct Matrix4x4{public float determinant,shift;public static Matrix4x4 identity=>new Matrix4x4{determinant=1};public Vector3 MultiplyPoint3x4(Vector3 v)=>new Vector3(v.x+shift,v.y,v.z);}
 public class Mesh{public string name;public Rendering.IndexFormat indexFormat;public Vector3[] vertices=new[]{new Vector3(0,0,0),new Vector3(1,0,0),new Vector3(0,1,0)};public MeshTopology[] topology=new[]{MeshTopology.Triangles};public int reads;public int[] output;public int subMeshCount=>topology.Length;public MeshTopology GetTopology(int s)=>topology[s];public int[] GetTriangles(int s){reads++;if(topology[s]!=MeshTopology.Triangles)throw new Exception("Unity line/point triangle read");return new[]{0,1,2};}public void SetVertices(List<Vector3> v){vertices=v.ToArray();}public void SetTriangles(List<int> v,int sub){output=v.ToArray();}public void RecalculateNormals(){}public void RecalculateBounds(){}}
}
class Program{
 static int n;static void Check(bool ok,string why){n++;if(!ok)throw new Exception(why);}
 static void Main(){
  foreach(var mode in new[]{MeshTopology.Lines,MeshTopology.Points}){
   var body=new Mesh();var helper=new Mesh{topology=new[]{mode}};var result=CabinetLampBlueprint.Build(body,helper,null,Matrix4x4.identity,null);
   Check(helper.reads==0,"non-triangle submesh reached GetTriangles");Check(body.reads==1&&result.output.Length==3,"triangle model lost");Check(result.vertices.Length==3,"helper vertices entered preview");
   bool emptyRejected=false;try{CabinetLampBlueprint.Build(helper,null,null,Matrix4x4.identity,null);}catch(InvalidOperationException){emptyRejected=true;}Check(emptyRejected&&helper.reads==0,"empty helper-only preview not safely rejected");
  }
  var mixed=new Mesh{topology=new[]{MeshTopology.Lines,MeshTopology.Triangles,MeshTopology.Points}};var m=CabinetLampBlueprint.Build(null,null,mixed,new Matrix4x4{determinant=-1,shift=3},null);
  Check(mixed.reads==1,"mixed topology read extra submeshes");Check(m.output.SequenceEqual(new[]{0,2,1}),"mirrored winding wrong");Check(m.vertices[0].x==3,"terminal transform missing");
  var a=new Mesh();var b=new Mesh();var c=new Mesh();var d=new Mesh();var all=CabinetLampBlueprint.Build(a,b,c,Matrix4x4.identity,d);Check(all.output.Length==12&&all.vertices.Length==12,"four explicit lamp parts not combined");Check(all.output.SequenceEqual(new[]{0,1,2,3,4,5,6,7,8,9,10,11}),"part index offsets wrong");
  Console.WriteLine(n+" production lamp blueprint topology/parts/transform regression checks passed");
 }
}
