using System;using System.Linq;using System.Collections.Generic;using System.Diagnostics;using ModularSwitchboards;
static class GraphCacheHarness
{
 internal static void Run()
 {
  int checks=0;void Check(bool ok,string why){checks++;if(!ok)throw new Exception(why);}
  var r=new Random(188);var graph=new WireCircuitGraph();
  var ends=Enumerable.Range(0,12).SelectMany(id=>Enumerable.Range(0,4).Select(pin=>new CabinetWireEnd(id,pin))).ToArray();
  for(int iteration=0;iteration<40;iteration++)
  {
   var wires=Enumerable.Range(0,35).Select(_=>new CabinetWireSaveData{From=ends[r.Next(ends.Length)],To=ends[r.Next(ends.Length)],Burnt=r.Next(5)==0}).ToList();
   var closed=Enumerable.Range(1,11).Where(_=>r.Next(2)==0).Select(i=>(long)i).ToArray();graph.Update(wires,closed);
   foreach(var a in ends)foreach(var b in ends)Check(graph.Reachable(a,b)==WireCircuit.Reachable(a,b,wires,closed),"Cached graph differs from original traversal");
   var pathGraph=new WireCircuitGraph();var paths=new WireCircuitPaths(pathGraph);var eligible=closed.Where(id=>id%3!=0).ToArray();paths.Update(wires,closed,eligible);
   foreach(var a in ends.Take(8))foreach(var b in ends.Skip(8).Take(8)){
    var expected=eligible.Where(id=>WireCircuit.Reachable(a,new CabinetWireEnd(id,0),wires,closed)&&WireCircuit.Reachable(new CabinetWireEnd(id,1),b,wires,closed)).ToArray();
    Check(paths.Path(a,b).SequenceEqual(expected),"Cached power path differs");var original=paths.Path(a,b);paths.Update(wires,closed,eligible);Check(ReferenceEquals(original,paths.Path(a,b)),"Stable path reallocated");
   }
   wires[0].Burnt=!wires[0].Burnt;paths.Update(wires,closed,eligible);
   foreach(var a in ends.Take(8))Check(paths.Path(a,ends[10]).SequenceEqual(eligible.Where(id=>WireCircuit.Reachable(a,new CabinetWireEnd(id,0),wires,closed)&&WireCircuit.Reachable(new CabinetWireEnd(id,1),ends[10],wires,closed))),"Burn did not invalidate power paths");
   wires[0].Burnt=!wires[0].Burnt;
   int builds=graph.Builds,searches=graph.Searches;for(int tick=0;tick<20;tick++){Check(!graph.Update(wires,closed),"Unchanged topology rebuilt");graph.Reachable(ends[0],ends[1]);}
   Check(graph.Builds==builds&&graph.Searches==searches,"Idle query repeated graph work");
   wires[0].Burnt=!wires[0].Burnt;Check(graph.Update(wires,closed),"Burn did not invalidate graph");
   // IDs/pins can be mutated in place: reference identity alone is insufficient.
   wires[0].From=new CabinetWireEnd(999,1);Check(graph.Update(wires,closed),"Endpoint replacement not detected");
   wires[0].From.Contact=0;Check(graph.Update(wires,closed),"In-place endpoint mutation not detected");
   if(closed.Length>0){closed[0]=999;Check(graph.Update(wires,closed),"In-place conducting IDs mutation not detected");}
  }
  var from=new CabinetWireEnd(0,0);var to=new CabinetWireEnd(0,1);var points=new[]{0f,0f,0f,0f,1f,0f};
  var saved=new CabinetWireSaveData{From=from,To=to,Points=points,RouteVersion=8,ColorIndex=6,CableKind=CabinetWireKind.Heavy,CableUnits=1,Burnt=true};var batch=new[]{saved};
  WirePoint? Position(CabinetWireEnd e)=>e.Equals(from)?new WirePoint(0,0,0):new WirePoint(0,1,0);
  Check(WireRouteUpgrade.TryPromote(batch,Position,9)&&saved.RouteVersion==9&&ReferenceEquals(saved.Points,points)&&saved.Burnt&&saved.ColorIndex==6&&saved.CableKind==CabinetWireKind.Heavy&&saved.CableUnits==1,"Unchanged v8 path was modified");
  saved.RouteVersion=8;Check(!WireRouteUpgrade.TryPromote(batch,e=>new WirePoint(1,0,0),9)&&saved.RouteVersion==8,"Moved contact bypassed migration");
  saved.RouteVersion=7;Check(!WireRouteUpgrade.TryPromote(batch,Position,9),"Old geometry bypassed migration");
  saved.RouteVersion=8;Check(!WireRouteUpgrade.TryPromote(batch,e=>null,9),"Missing endpoint accepted");
  var second=new CabinetWireSaveData{From=from,To=to,Points=points,RouteVersion=7};Check(!WireRouteUpgrade.TryPromote(new[]{saved,second},Position,9)&&saved.RouteVersion==8,"Partial promotion changed saved version");
  var chain=Enumerable.Range(0,60).Select(i=>new CabinetWireSaveData{From=new CabinetWireEnd(i,1),To=new CabinetWireEnd(i+1,0)}).ToList();var ids=Enumerable.Range(0,61).Select(i=>(long)i).ToArray();graph.Update(chain,ids);var start=new CabinetWireEnd(0,0);var finish=new CabinetWireEnd(60,1);graph.Reachable(start,finish);
  var timer=Stopwatch.StartNew();long before=GC.GetAllocatedBytesForCurrentThread();for(int i=0;i<1000;i++)WireCircuit.Reachable(start,finish,chain,ids);long oldBytes=GC.GetAllocatedBytesForCurrentThread()-before;timer.Stop();double oldMs=timer.Elapsed.TotalMilliseconds;
  timer.Restart();before=GC.GetAllocatedBytesForCurrentThread();for(int i=0;i<1000;i++){graph.Update(chain,ids);Check(graph.Reachable(start,finish),"Warm chain lost connectivity");}long newBytes=GC.GetAllocatedBytesForCurrentThread()-before;timer.Stop();
  Console.WriteLine($"{checks} graph-cache/route-upgrade checks passed. Isolated 1000-query benchmark: original {oldMs:F2}ms/{oldBytes}B, cached {timer.Elapsed.TotalMilliseconds:F2}ms/{newBytes}B. Not an in-game FPS measurement.");
 }
}
