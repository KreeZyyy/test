using System;using System.Linq;using ModularSwitchboards;
partial class RouteHarness {
 internal static void RunScreenshot(){
 foreach(float rowY in new[]{0f,.27f}) foreach(float z in new[]{.06535f}) foreach(int column in new[]{5,7,10,13}){
 var h=new RouteHarness();h.Owner.PrefabName="medium";h.routingHalfWidth=.366f;h.routingHalfHeight=.477f;h.moduleReservations=WireModuleSpace.Reservations(.65f,new[]{-.27f,0f,.27f}).ToArray();
 foreach(float row in new[]{-.27f,0f,.27f})h.railObstacles.Add(new(-.264f,.304f,row-.0175f,row+.0175f));
 for(int i=0;i<14;i++){float x=-.243f+i*.0405f;for(int pin=0;pin<2;pin++){var e=new CabinetWireEnd(10+i,pin);h.contacts[e]=new(){End=e,Position=new(x,rowY+(pin==0?1:-1)*.050625f,z),Exit=new(x,rowY+(pin==0?1:-1)*.066f,WireRouting.Plane),Bounds=new(x-.0198f,x+.0198f,rowY-.050625f,rowY+.050625f)};}}
 for(int i=1;i<=3;i++){float x=i==1?.23f:i==2?0:-.23f;var e=new CabinetWireEnd(0,i);h.contacts[e]=new(){End=e,Position=new(x,.425f,.033f),Exit=new(x,.407f,WireRouting.Plane),Bounds=new(x-.036f,x+.036f,.424f,.456f)};}

 for(int n=0;n<2;n++){var previous=h.MakeRoute(new(10+n,1),new(0,n+1),out int used,out string why,CabinetWireKind.Heavy);if(previous!=null)h.wires.Add(new(){From=new(10+n,1),To=new(0,n+1),InputSlot=used,CableKind=CabinetWireKind.Heavy,Points=Flatten(previous)});Console.WriteLine($"previous {n} {why}");}
 var path=h.MakeRoute(new(10+column,1),new(0,3),out _,out string failure,CabinetWireKind.SuperHeavy);if(path==null)throw new Exception($"Mixed Heavy/SuperHeavy reverseMedium row={rowY} col={column}: {failure}");Console.WriteLine($"Mixed reverseMedium row={rowY} col={column}: {path.Length} points passed.");
 }
 }
}
