using System;using System.Linq;using System.IO;using System.Xml.Serialization;using ModularSwitchboards;
partial class SerdeHarness
{
 internal static void RunVariants()
 {
  int checks=0;void Check(bool ok,string text){checks++;if(!ok)throw new Exception(text);}
  foreach(string name in new[]{"small","reverse",SwitchboardsMod.MediumCabinetName,SwitchboardsMod.MediumReverseCabinetName,SwitchboardsMod.SmallCombinerName,SwitchboardsMod.SmallCombinerReverseName,SwitchboardsMod.MediumCombinerName,SwitchboardsMod.MediumCombinerReverseName})
  {
   bool medium=CabinetShape.Medium(name);float x=medium?.36f:.16f,y=medium?.44f:.211f;
   var routes=new[]{
    new CabinetWireSaveData{From=new(0,0),To=new(51,0),CableKind=CabinetWireKind.Normal,RouteVersion=6,InputSlot=15,ColorIndex=7,Points=new[]{0f,y,.014f,x,y-.04f,.06535f,x,0f,.06535f}},
    new CabinetWireSaveData{From=new(51,ContactorCircuit.NcPin),To=new(0,medium?3:2),CableKind=CabinetWireKind.Heavy,RouteVersion=6,InputSlot=1,ColorIndex=8,Points=new[]{x,0f,.06535f,-x,-y,.06535f}},
    new CabinetWireSaveData{From=new(900,2),To=new(901,0),CableKind=CabinetWireKind.SuperHeavy,RouteVersion=6,ColorIndex=5,Points=new[]{-.197f,y-.01f,.0244f,-.15f,y-.02f,.06535f}}
   };
   if(CabinetPorts.Combiner(name)){routes[0].From=new(0,4);routes[1].To=new(0,1);if(medium)routes[2].From=new(0,6);}
   var serializer=new XmlSerializer(typeof(CabinetWireSaveData[]));var xml=new StringWriter();serializer.Serialize(xml,routes);var loaded=(CabinetWireSaveData[])serializer.Deserialize(new StringReader(xml.ToString()));
   var first=new SerdeHarness();first.Owner.PrefabName=name;first.Load(loaded);Check(first.wires.Count==3,name+": XML wires dropped");
   using var packet=new MemoryStream();first.Write(new(packet));packet.Position=0;var second=new SerdeHarness();second.Owner.PrefabName=name;second.Read(new(packet));Check(second.wires.Count==3,name+": join/load wires dropped");
   for(int i=0;i<routes.Length;i++){
    var wire=second.wires[i];Check(wire.Points.SequenceEqual(routes[i].Points),name+": exact cable path changed");Check(wire.From.Equals(routes[i].From)&&wire.To.Equals(routes[i].To),name+": endpoint identity changed");Check(wire.CableKind==routes[i].CableKind&&wire.ColorIndex==routes[i].ColorIndex&&wire.InputSlot==routes[i].InputSlot&&wire.CableUnits==1&&wire.RouteVersion==6,name+": wire metadata changed");
   }
   var merge=Enumerable.Range(0,4).Select(i=>new CabinetWireSaveData{From=new(100+i,1),To=new(200,0),Points=new[]{.05f,.07f,.08f,.09f,.08f,.08f},RouteVersion=9}).ToArray();
   var fan=new SerdeHarness();fan.Owner.PrefabName=name;fan.Load(merge);Check(fan.Save().Length==3,name+": three module IN wires lost or fourth admitted");
   using(var network=new MemoryStream()){fan.Write(new(network));network.Position=0;var joined=new SerdeHarness();joined.Owner.PrefabName=name;joined.Read(new(network));Check(joined.Save().Length==3,name+": joined fan-in lost");}
   // Reject true out-of-bounds paths without dropping valid neighbours.
   var invalid=new CabinetWireSaveData{From=new(0,0),To=new(600,0),RouteVersion=6,Points=new[]{CabinetShape.Width(name)*.5f+.001f,0f,.05f,0f,0f,.05f}};
   second.Load(routes.Concat(new[]{invalid}));Check(second.wires.Count==3,name+": outside width accepted or valid wires dropped");
   invalid.Points[0]=0;invalid.Points[1]=CabinetShape.Height(name)*.5f+.001f;second.Load(new[]{invalid});Check(second.wires.Count==0,name+": outside height accepted");
   invalid.Points[1]=0;invalid.Points[2]=float.NaN;second.Load(new[]{invalid});Check(second.wires.Count==0,name+": NaN accepted");
   invalid.Points[2]=.151f;second.Load(new[]{invalid});Check(second.wires.Count==0,name+": invalid depth accepted");
   if(medium){var oldLimit=new SerdeHarness();oldLimit.Load(routes);Check(oldLimit.wires.Count==0,name+": regression fixture did not exceed Small bounds");}
  }
  Console.WriteLine(checks+" variant wire persistence checks passed: all eight cabinet profiles XML and binary load, exact paths, endpoints, color, slot and malformed guards.");
 }
}
