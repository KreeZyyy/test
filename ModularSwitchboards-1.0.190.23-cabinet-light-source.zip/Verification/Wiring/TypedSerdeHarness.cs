using System;using System.IO;using System.Linq;using System.Xml.Serialization;using ModularSwitchboards;
partial class SerdeHarness
{
 internal static void RunKinds()
 {
  int checks=0;void Check(bool ok,string s){checks++;if(!ok)throw new Exception(s);}
  var sample=new CabinetWireSaveData{From=new(0,0),To=new(10,0),CableKind=CabinetWireKind.SuperHeavy,RouteVersion=6,ColorIndex=8,Points=new[]{0f,.20f,.05f,.04f,.10f,.05f}};
  var serializer=new XmlSerializer(typeof(CabinetWireSaveData));var xml=new StringWriter();serializer.Serialize(xml,sample);
  var legacy=xml.ToString().Replace(" CableKind=\"SuperHeavy\"","");var old=(CabinetWireSaveData)serializer.Deserialize(new StringReader(legacy));Check(old.CableKind==CabinetWireKind.Normal&&old.ColorIndex==8,"legacy XML loses type default or paint");
  foreach(var kind in new[]{CabinetWireKind.Normal,CabinetWireKind.Heavy,CabinetWireKind.SuperHeavy}){
   sample.CableKind=kind;var first=new SerdeHarness();first.Load(new[]{sample});using var stream=new MemoryStream();first.Write(new(stream));long end=stream.Position;new RocketBinaryWriter(stream).WriteInt32(1776);stream.Position=0;var second=new SerdeHarness();second.Read(new(stream));Check(second.wires.Single().CableKind==kind&&second.wires[0].ColorIndex==8,"typed binary loses kind/paint");Check(stream.Position==end&&new RocketBinaryReader(stream).ReadInt32()==1776,"binary framing lost");
   var sw=new StringWriter();serializer.Serialize(sw,sample);var read=(CabinetWireSaveData)serializer.Deserialize(new StringReader(sw.ToString()));Check(read.CableKind==kind&&read.Points.SequenceEqual(sample.Points),"XML kind/path lost");
  }
  // Version -2 from every painted pre-1.0.70 installation.
  using(var stream=new MemoryStream()){
   var w=new RocketBinaryWriter(stream);w.WriteInt32(-2);w.WriteInt32(1);WriteEnd(w,sample.From);WriteEnd(w,sample.To);w.WriteInt32(sample.InputSlot);w.WriteInt32(sample.RouteVersion);w.WriteInt32(sample.ColorIndex);w.WriteInt32(sample.Points.Length);foreach(var p in sample.Points)w.WriteSingle(p);w.WriteInt32(0);stream.Position=0;var read=new SerdeHarness();read.Read(new(stream));Check(read.wires.Single().CableKind==CabinetWireKind.Normal&&read.wires[0].ColorIndex==8&&read.wires[0].Points.SequenceEqual(sample.Points),"painted legacy binary unreadable");
  }
  foreach(int invalid in new[]{-1,3,100,int.MaxValue}){
   sample.CableKind=(CabinetWireKind)invalid;var first=new SerdeHarness();first.Load(new[]{sample});Check(first.wires.Count==0,"invalid save kind accepted");
   // Write from a deliberately malformed in-memory snapshot to test network reader.
   first.wires.Add(sample);using var stream=new MemoryStream();first.Write(new(stream));stream.Position=0;bool rejected=false;try{new SerdeHarness().Read(new(stream));}catch(InvalidOperationException){rejected=true;}Check(rejected,"invalid network kind accepted");
  }
  Console.WriteLine(checks+" production typed-wire XML/join/update checks passed: all kinds and paint, absent legacy kind, both old packet versions, exact framing and invalid-kind guards.");
 }
}
