using System.Reflection;
using ModularSwitchboards;
using Assets.Scripts.Networks;
// Explicit native cycle boundaries: output offers remain pinned through all
// provider callbacks, then a new electricity tick resets allocation/load state.
static class PowerCycle
{
 internal static void Next(CabinetWiringPower p)
 {
  var engine=(CabinetCombinerPower)typeof(CabinetWiringPower).GetField("power",BindingFlags.NonPublic|BindingFlags.Instance).GetValue(p);
  engine.BeginOwnTick();engine.EndOwnTick();
 }
 internal static void Use(CabinetWiringPower p,CableNetwork n,float value){p.Generated(n);p.Use(n,value);}
}
