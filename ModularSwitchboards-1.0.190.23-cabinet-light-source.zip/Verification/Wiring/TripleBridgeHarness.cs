using System;using System.Linq;using ModularSwitchboards;
partial class RouteHarness{
 internal static void RunTripleBridge(){
 var h=new RouteHarness();h.Breakers=new[]{new DinBreaker{ReferenceId=900,IsDoorBridge=true}};var bridge=new CabinetWireEnd(900,3);
 h.contacts[bridge]=new(){End=bridge,Door=true,Position=new(.163f,.192f,.0114f),Exit=new(.153f,.192f,.043f),Bounds=new(.164f,.181f,.181f,.203f)};
 for(int i=0;i<4;i++){float x=.1f-i*.1f;var e=new CabinetWireEnd(100+i,0);h.contacts[e]=new(){End=e,Door=true,Position=new(x,.098f,.017f),Exit=new(x,.118f,.043f),Bounds=new(x-.019f,x+.019f,.051f,.099f)};}
 for(int i=0;i<3;i++){var target=new CabinetWireEnd(100+i,0);var path=h.MakeRoute(bridge,target,out int slot,out string fail);if(path==null)throw new Exception("bridge branch "+i+": "+fail);h.wires.Add(new(){From=bridge,To=target,InputSlot=slot,RouteVersion=9,CableKind=CabinetWireKind.Normal,Points=Flatten(path)});SerdeHarness.AssertRoundTrip(h.wires.Last());}
 SerdeHarness.AssertTriple(h.wires.ToArray());
 if(h.CanConnectContacts(bridge,new(103,0),out _))throw new Exception("fourth bridge wire allowed");
 h.wires.Clear();h.Breakers=new[]{new DinBreaker{ReferenceId=900,IsDoorBridge=true}}.Concat(Enumerable.Range(0,3).Select(i=>new DinBreaker{ReferenceId=100+i,IsDoorLed=true})).ToArray();
 for(int i=0;i<3;i++){float x=.1f-i*.1f;var source=new CabinetWireEnd(100+i,1);h.contacts[source]=new(){End=source,Door=true,Position=new(x,.052f,.017f),Exit=new(x,.032f,.043f),Bounds=new(x-.019f,x+.019f,.051f,.099f)};var path=h.MakeRoute(source,bridge,out int slot,out string failure);if(path==null)throw new Exception("shared target bridge "+i+": "+failure);h.wires.Add(new(){From=source,To=bridge,InputSlot=slot,RouteVersion=9,Points=Flatten(path)});}
 SerdeHarness.AssertTriple(h.wires.ToArray());
 Console.WriteLine("Triple door bridge: all3 branches routed and serialized; fourth rejected.");
 }
}

partial class SerdeHarness{internal static void AssertTriple(CabinetWireSaveData[] batch){var first=new SerdeHarness();first.Load(batch);if(first.wires.Count!=3)throw new Exception("load drops multi-wire bridge");using var stream=new System.IO.MemoryStream();first.Write(new(stream));stream.Position=0;var joined=new SerdeHarness();joined.Read(new(stream));if(joined.wires.Count!=3)throw new Exception("network drops multi-wire bridge");}}
