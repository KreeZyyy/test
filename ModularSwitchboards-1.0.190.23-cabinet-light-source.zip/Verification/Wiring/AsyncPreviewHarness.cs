using System;using System.Linq;using System.Threading;using System.Diagnostics;using ModularSwitchboards;
namespace ModularSwitchboards {
 public sealed partial class CabinetWiring {
  internal Func<WireRoutePlanner> Factory;internal int Captures,revision,routeRevision=-1,routeSlot;internal CabinetWireEnd routeFrom,routeTo;internal CabinetWireKind routeKind;internal WirePoint[] route;internal string routeFailure;
  private WireRoutePlanner CaptureRoutePlanner(){Captures++;return Factory();}
  internal bool Poll(CabinetWireEnd a,CabinetWireEnd b,CabinetWireKind k)=>PollPreviewRoute(a,b,k);
  internal void Stop()=>previewRouteJob.Dispose();
 }
}
partial class RouteHarness {
 internal static void RunAsyncPreview(){
  int checks=0;void Check(bool b,string m){checks++;if(!b)throw new Exception(m);}
  var h=new RouteHarness{Owner=new(){PrefabName="medium"},routingHalfWidth=.366f,routingHalfHeight=.477f};h.moduleReservations=WireModuleSpace.Reservations(.65f,new[]{-.27f,0f,.27f}).ToArray();
  foreach(float row in new[]{-.27f,0f,.27f})h.railObstacles.Add(new(-.264f,.304f,row-.0175f,row+.0175f));
  var input=new CabinetWireEnd(0,0);var target=new CabinetWireEnd(10,0);
  h.contacts[input]=new(){End=input,Position=new(0,-.425f,.033f),Exit=new(0,-.407f,WireRouting.Plane),Bounds=new(-.036f,.036f,-.456f,-.424f)};
  h.contacts[target]=new(){End=target,Position=new(-.243f,.320625f,.06535f),Exit=new(-.243f,.336f,WireRouting.Plane),Bounds=new(-.2628f,-.2232f,.219375f,.320625f)};
  var direct=h.MakeRoute(input,target,out int slot,out string failure,CabinetWireKind.SuperHeavy);Check(direct!=null,"preview fixture: "+failure);
  var captured=h.CaptureRoutePlanner();h.contacts[target].Position=new(0,0,0);h.railObstacles.Clear();var snapshot=captured.MakeRoute(input,target,out int s,out _,CabinetWireKind.SuperHeavy);Check(s==slot&&Flatten(snapshot).SequenceEqual(Flatten(direct)),"snapshot reads mutated live contacts/rails");
  h.contacts[target].Position=new(-.243f,.320625f,.06535f);foreach(float row in new[]{-.27f,0f,.27f})h.railObstacles.Add(new(-.264f,.304f,row-.0175f,row+.0175f));
  var client=new CabinetWiring{Factory=h.CaptureRoutePlanner};var clock=Stopwatch.StartNew();bool ready=client.Poll(input,target,CabinetWireKind.SuperHeavy);double first=clock.Elapsed.TotalMilliseconds;Check(first<150,"preview poll blocks on routing");
  var deadline=Stopwatch.StartNew();while(!ready&&deadline.ElapsedMilliseconds<10000){Thread.Sleep(1);ready=client.Poll(input,target,CabinetWireKind.SuperHeavy);}Check(ready&&client.route!=null,"background preview did not complete");Check(Flatten(client.route).SequenceEqual(Flatten(direct)),"worker result differs from synchronous validation");Check(client.Captures==1,"same pending key restarts worker");
  for(int i=0;i<100;i++)Check(client.Poll(input,target,CabinetWireKind.SuperHeavy),"completed cache disappeared");Check(client.Captures==1,"cached result recaptures geometry");
  client.revision++;client.Poll(input,target,CabinetWireKind.Heavy);client.revision++;client.Poll(input,target,CabinetWireKind.Normal);Check(client.Captures==3,"revision/type switch does not replace stale jobs");client.Stop();
  var cancelled=h.CaptureRoutePlanner();using(var token=new CancellationTokenSource()){cancelled.cancellation=token.Token;token.Cancel();bool threw=false;try{cancelled.MakeRoute(input,target,out _,out _);}catch(OperationCanceledException){threw=true;}Check(threw,"planner ignores cancellation");}
  using(var job=new WireRouteJob()){job.Start(1,new(9999,0),target,CabinetWireKind.Normal,h.CaptureRoutePlanner());WireRouteJob.Result result=null;deadline.Restart();while(!job.TryRead(out result)&&deadline.ElapsedMilliseconds<10000)Thread.Sleep(1);Check(result?.Failure!=null,"worker exception is not observed/reported");job.Cancel();Check(!job.Matches(1,input,target,CabinetWireKind.Normal)&&!job.TryRead(out _),"cancelled job remains visible");}
  Check(WireRouting.Radius==WireRouting.DefaultRadius,"worker/snapshot leaks thread routing scope");
  Console.WriteLine($"{checks} actual async preview checks passed: first poll {first:0.00}ms, immutable snapshot, exact route equivalence, single capture/cache, stale revision/type cancellation, faults and thread budget isolation.");
 }
}
