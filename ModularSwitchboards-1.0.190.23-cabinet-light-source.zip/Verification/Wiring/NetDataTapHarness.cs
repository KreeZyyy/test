using System;using System.IO;using System.Linq;using System.Xml.Serialization;using System.Collections.Generic;using ModularSwitchboards;
static class NetDataTapHarness{
 static int n;static CabinetWireEnd E(long id,int pin)=>new(id,pin);static CabinetWireSaveData W(long a,int ap,long b,int bp)=>new(){From=E(a,ap),To=E(b,bp),RouteVersion=9,Points=new[]{0f,0f,.06f,.02f,.02f,.06f}};
 static void Check(bool b,string s){n++;if(!b)throw new Exception(s);}static bool Allow(CabinetWireEnd a,CabinetWireEnd b,List<CabinetWireSaveData> wires,long[] nets)=>WireCircuit.CanConnect(a,b,wires,new long[]{11,12},out _,dataTaps:nets);
 internal static void Run(){long[] nets={90,91,92};
 foreach(int output in new[]{1,2,3})foreach(bool reverse in new[]{false,true}){
 var end=E(0,output);var net=E(90,0);var feed=W(11,1,0,output);var wires=new List<CabinetWireSaveData>{feed};var a=reverse?net:end;var b=reverse?end:net;
 Check(Allow(a,b,wires,nets),"direct tap rejected in either click order");Check(!Allow(a,b,wires,Array.Empty<long>()),"generic input/input rule bypassed without Net metadata");Check(WireDataTap.CanStart(end,wires,1),"powered Output cannot be selected for data");
 WireCircuit.Orient(a,b,out var from,out var to);Check(from.Equals(end)&&to.Equals(net),"tap orientation reversed");var tap=W(0,output,90,0);wires.Add(tap);
 Check(!Allow(E(12,1),end,wires,nets),"data slot admits extra power feeder");Check(!Allow(end,E(91,0),wires,nets),"second direct data tap admitted on same terminal");Check(!Allow(E(0,output==1?2:1),net,wires,nets),"one Net joined two output networks");Check(!WireDataTap.CanStart(end,wires,1),"full power+data contact still offered");
 int bit=output==3?8:1<<(output-1);Check(SmartCircuit.Selection(90,wires,new long[]{11},new long[]{11})==bit,"wrong Output network");Check(SmartCircuit.Selection(90,wires,Array.Empty<long>(),new long[]{11})==bit,"trip changed selected Output network");
 wires.Insert(0,W(0,0,11,0));Check(SmartCircuit.Selection(90,wires,new long[]{11},Array.Empty<long>())==bit,"Input reachability overrides explicit Output tap");
 var power=WireDataTap.PowerWires(wires).ToArray();Check(!power.Contains(tap)&&power.Contains(feed),"tap participates in power graph or feeder removed");Check(!WireCircuit.Reachable(end,net,power,new long[]{11}),"data tap created energy path");Check(WireCircuit.Reachable(E(0,0),end,power,new long[]{11}),"tap changed existing power path");
 wires.Remove(feed);Check(Allow(E(12,1),end,wires,nets),"data-first installation prevents later power feed");
 }
 foreach(long other in new long[]{80,100,200})Check(!Allow(E(0,1),E(other,0),new(),nets),"Output feeds Core/battery/transformer IN");
 Check(!Allow(E(90,0),E(91,0),new(),nets),"Net-Net input connection admitted");Check(!Allow(E(0,1),E(0,2),new(),nets),"Output-Output connection admitted");Check(Allow(E(0,0),E(90,0),new(),nets),"existing Input-Net connection regressed");Check(Allow(E(11,1),E(90,0),new(),nets),"existing breaker-Net connection regressed");
 var combined=new List<CabinetWireSaveData>{W(11,1,0,1),W(12,1,0,1),W(13,1,0,1)};
 int CombinerCapacity(CabinetWireEnd e)=>WireDataTap.Output(e)?3:e.Capacity;
 Check(WireCircuit.CanConnect(E(0,1),E(90,0),combined,new long[]{11,12,13},out _,capacity:CombinerCapacity,dataTaps:nets),"full collecting Output rejected separate DATA slot");
 combined.Add(W(0,1,90,0));Check(!WireCircuit.CanConnect(E(14,1),E(0,1),combined,new long[]{11,12,13,14},out _,capacity:CombinerCapacity,dataTaps:nets),"collecting Output gained extra power feeder");Check(WireDataTap.PowerWires(combined).Count()==3,"collecting Output lost power feeders or retained data edge");
 var burnt=W(0,1,90,0);burnt.Burnt=true;Check(SmartCircuit.Selection(90,new[]{burnt},Array.Empty<long>(),Array.Empty<long>())==0,"burnt data wire still selects network");
 for(int i=0;i<500;i++){int output=i%3+1;var wire=W(0,output,90+i,0);Check(WireDataTap.PowerWires(new[]{wire}).Count()==0,"random tap leaked energy edge");Check(SmartCircuit.Selection(90+i,new[]{wire},Array.Empty<long>(),Array.Empty<long>())==(output==3?8:1<<(output-1)),"random tap selected wrong network");}
 Console.WriteLine(n+" Net DATA direct-output production topology/capacity checks passed.");
 }
}
partial class SerdeHarness{
 internal static void RunNetTap(){int n=0;
 foreach(int output in new[]{1,2,3})foreach(bool dataFirst in new[]{false,true}){
 var power=new CabinetWireSaveData{From=new(11,1),To=new(0,output),RouteVersion=9,Points=new[]{0f,0f,.06f,.02f,.02f,.06f}};var tap=new CabinetWireSaveData{From=new(0,output),To=new(90,0),RouteVersion=9,CableKind=CabinetWireKind.Heavy,ColorIndex=5,Points=new[]{0f,0f,.06f,.02f,.02f,.06f}};
 var original=dataFirst?new[]{tap,power}:new[]{power,tap};var source=new SerdeHarness();source.Load(original);if(source.wires.Count!=2)throw new Exception("power+data lost before module boards are loaded");
 using var bytes=new MemoryStream();source.Write(new(bytes));bytes.Position=0;var restored=new SerdeHarness();restored.Read(new(bytes));if(restored.wires.Count!=2||!restored.wires.Any(w=>WireDataTap.Stored(w)&&w.CableKind==CabinetWireKind.Heavy&&w.ColorIndex==5))throw new Exception("network/save lost data tap");
 var serializer=new XmlSerializer(typeof(CabinetWireSaveData[]));using var text=new StringWriter();serializer.Serialize(text,original);var loaded=(CabinetWireSaveData[])serializer.Deserialize(new StringReader(text.ToString()));var xml=new SerdeHarness();xml.Load(loaded);if(xml.wires.Count!=2)throw new Exception("XML data tap lost");n+=3;
 }
 Console.WriteLine(n+" actual CabinetWiring Load/Write/Read/XML data tap checks passed (module identities deliberately unavailable during load).");
 }
}
partial class RouteHarness{
 internal static void RunNetTap(){
 foreach(bool reverse in new[]{false,true}){
 var h=new RouteHarness();h.moduleReservations=Array.Empty<WireRect>();
 var input=new CabinetWireEnd(11,1);var output=new CabinetWireEnd(0,1);var net=new CabinetWireEnd(90,0);
 float sign=reverse?-1:1;
 h.contacts[input]=new(){End=input,Position=new(-.10f*sign,0,.065f),Exit=new(-.10f*sign,-.04f,WireRouting.Plane),Bounds=new(-.12f,.0f,-.025f,.025f)};
 h.contacts[output]=new(){End=output,Position=new(.08f*sign,-.20f,.033f),Exit=new(.08f*sign,-.18f,WireRouting.Plane),Bounds=new(.08f*sign-.03f,.08f*sign+.03f,-.23f,-.195f)};
 h.contacts[net]=new(){End=net,Position=new(.06f*sign,.13f,.065f),Exit=new(.06f*sign,.17f,WireRouting.Plane),Bounds=new(.06f*sign-.025f,.06f*sign+.025f,.105f,.155f)};
 var feeder=h.MakeRoute(input,output,out int feedSlot,out var fail);if(feeder==null)throw new Exception("test feeder routing: "+fail);h.wires.Add(new(){From=input,To=output,InputSlot=feedSlot,RouteVersion=9,Points=Flatten(feeder)});
 var data=h.MakeRoute(output,net,out int tapSlot,out fail);if(data==null)throw new Exception("direct DATA tap routing over occupied Output: "+fail);SerdeHarness.AssertRoundTrip(new(){From=output,To=net,InputSlot=tapSlot,RouteVersion=9,Points=Flatten(data)});
 Console.WriteLine("Direct DATA route with occupied Output passed; mirrored="+reverse+", points="+data.Length);
 }
 }
}
