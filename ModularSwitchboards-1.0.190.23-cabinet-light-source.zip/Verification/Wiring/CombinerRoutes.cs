using System;using System.Linq;using ModularSwitchboards;
partial class RouteHarness
{
 internal static void RunCombiner(bool merge=false)
 {
  foreach(bool medium in new[]{false,true})foreach(bool reverse in new[]{false,true})
  {
   float sign=reverse?-1:1,terminal=medium?.44f:.211f,row=medium?0:(reverse?.108f:-.108f);
   int inputs=medium?3:2,count=merge?3:inputs;var h=new RouteHarness{Owner=new(){PrefabName=medium?(reverse?"collectormediumreverse":"collectormedium"):(reverse?"collectorsmallreverse":"collectorsmall")},routingHalfWidth=(float)Math.Floor(((medium?.4f:.2f)-.032f+.000001f)/WireRouting.Step)*WireRouting.Step,routingHalfHeight=(float)Math.Floor(((medium?.5f:.25f)-.022f+.000001f)/WireRouting.Step)*WireRouting.Step};
   float width=medium?.65f:.35f;var rows=medium?new[]{-.27f,0,.27f}:new[]{-.108f,.108f};h.moduleReservations=WireModuleSpace.Reservations(width,rows).ToArray();
   float halfRail=DinLayout.RailLength(width)*.5f,offset=DinLayout.FirstModuleSlot*DinLayout.SlotPitch*.5f;
   foreach(float y in rows)h.railObstacles.Add(new(-halfRail+offset,halfRail+offset,y-.0175f,y+.0175f));
   var output=new CabinetWireEnd(0,1);h.contacts[output]=new(){End=output,Position=new(0,(terminal-.015f)*sign,.033f),Exit=new(0,(terminal-.033f)*sign,WireRouting.Plane),Bounds=new(-.036f,.036f,terminal*sign-.016f,terminal*sign+.016f)};
   for(int i=0;i<count;i++)
   {
    int branch=merge&&!medium?(i<2?0:1):i%inputs;int contact=branch==0?0:branch==1?4:6;float x=medium?(branch==0?.23f:branch==1?0:-.23f):(branch==0?.108f:-.108f);var input=new CabinetWireEnd(0,contact);
    h.contacts[input]=new(){End=input,Position=new(x,(-terminal+.015f)*sign,.033f),Exit=new(reverse&&!medium?x-Math.Sign(x)*.024f:x,(-terminal+(reverse?.033f:.027f))*sign,WireRouting.Plane),Bounds=new(x-.036f,x+.036f,-terminal*sign-.016f,-terminal*sign+.016f)};
    float mx=medium?(i-(count-1)*.5f)*.081f:(((count-1)*.5f-i)*.06075f);var bounds=new WireRect(mx-.0198f,mx+.0198f,row-.050625f,row+.050625f);
    for(int pin=0;pin<2;pin++){var end=new CabinetWireEnd(10+i,pin);h.contacts[end]=new(){End=end,Position=new(mx,row+(pin==0?.050625f:-.050625f),.06535f),Exit=new(mx,row+(pin==0?.066f:-.066f),WireRouting.Plane),Bounds=bounds};}
   }
   CabinetWireEnd common=output;
   if(merge)
   {
    common=new CabinetWireEnd(50,0);float ay=medium?.27f:(reverse?-.108f:.108f);var bounds=new WireRect(-.0198f,.1008f,ay-.050625f,ay+.050625f);
    h.PowerModules.Add(50);for(int pin=0;pin<2;pin++){var end=new CabinetWireEnd(50,pin);h.contacts[end]=new(){End=end,Position=new(.0405f,ay+(pin==0?.050625f:-.050625f),.06535f),Exit=new(.0405f,ay+(pin==0?.066f:-.066f),WireRouting.Plane),Bounds=bounds};}
   }
   foreach(int i in Enumerable.Range(0,count))foreach(bool supply in new[]{true,false})
   {
    var from=supply?new CabinetWireEnd(0,(merge&&!medium?(i<2?0:1):i%inputs)==0?0:(merge&&!medium?(i<2?0:1):i%inputs)==1?4:6):new CabinetWireEnd(10+i,1);var to=supply?new CabinetWireEnd(10+i,0):common;
    using var cancel=new System.Threading.CancellationTokenSource(TimeSpan.FromSeconds(20));var planner=h.CaptureRoutePlanner();planner.cancellation=cancel.Token;var path=planner.MakeRoute(from,to,out int slot,out string fail);if(path==null)throw new Exception($"Combiner medium={medium} reverse={reverse}: branch={i} supply={supply} {from}->{to}: {fail}");
    h.wires.Add(new(){From=from,To=to,InputSlot=slot,Points=Flatten(path)});
   }
   if(merge)
   {
    using var cancel=new System.Threading.CancellationTokenSource(TimeSpan.FromSeconds(20));var planner=h.CaptureRoutePlanner();planner.cancellation=cancel.Token;var from=new CabinetWireEnd(50,1);var path=planner.MakeRoute(from,output,out int slot,out string fail);if(path==null)throw new Exception("Shared analyzer OUT: "+fail);h.wires.Add(new(){From=from,To=output,InputSlot=slot,Points=Flatten(path)});
   }
   if(h.wires.Count(w=>w.To.Equals(common))!=count)throw new Exception("Common output does not accept all branches");
   Console.WriteLine($"Combiner route fixture medium={medium} reverse={reverse}: {h.wires.Count} actual production routes, {count} branches into {(merge?"analyzer IN":"common OUT")}.");
  }
 }
}
