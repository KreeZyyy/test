using System.Collections.Generic;
namespace Assets.Scripts.Networks{public class CableNetwork{public float PotentialLoad,RequiredLoad;public PowerTick PowerTick=new();}public class PowerTick{public PowerProvider[] InputOutputDevices=new PowerProvider[0];}public class PowerProvider{public Assets.Scripts.Objects.Pipes.Device Device;}}
namespace Assets.Scripts.Objects.Pipes{public class Device{public long ReferenceId;public const int MaxProviderRecursionIterations=64;public virtual bool IsProviderToDevice(Device device,ref List<long> visited)=>false;}}
namespace Assets.Scripts.Objects.Items{public class BatteryCell{public long ReferenceId;public float PowerStored,PowerMaximum=36000;public float PowerDelta=>System.Math.Max(0,PowerMaximum-PowerStored);}}
namespace ModularSwitchboards
{
 public class StubCable{public Assets.Scripts.Networks.CableNetwork CableNetwork;}
 public class StubConnection{public StubCable cable=new();public StubCable GetCable()=>cable;}
 public class SwitchboardCabinet{public string PrefabName="small";public Dictionary<int,StubConnection> ExtraInputs=new();public System.Collections.Generic.IEnumerable<int> InputContacts=>System.Linq.Enumerable.Concat(new[]{0},ExtraInputs.Keys);public StubConnection InputPort(int contact)=>contact==0?InputConnection:ExtraInputs.TryGetValue(contact,out var value)?value:null;public StubConnection Output3Connection;public bool IsStructureCompleted=true,IsCursor;public object GridController=new();public StubConnection InputConnection=new(),Output1Connection=new(),Output2Connection=new();}
 public class DinBreaker{public bool IsSmartOutputModule,HasNormallyClosedContact,IsContactor,ContactorClosed,OnOff,IsBeingDestroyed,IsFuseHolder,FusePresent,IsBatteryModule,IsAnalyserModule,IsDoorLed,IsDoorStop,IsDoorBridge;public bool IsDoorPart=>IsDoorLed||IsDoorStop||IsDoorBridge;public Assets.Scripts.Objects.Items.BatteryCell Battery;public float RatedWatts=4000f;public bool Conducting=>!IsBeingDestroyed&&(IsContactor?ContactorClosed:(IsDoorStop?!OnOff:(IsDoorPart||IsBatteryModule||IsAnalyserModule||(IsFuseHolder?FusePresent:OnOff))));public long ReferenceId;}
}

namespace Assets.Scripts.Objects{public enum ConnectionRole{Input,Output,Output2,Waste}}
namespace UnityEngine{public struct Vector3{public float x,y,z;public Vector3(float x,float y,float z){this.x=x;this.y=y;this.z=z;}}}
namespace ModularSwitchboards{static class SwitchboardsMod{public const string SmallCombinerName="collectorsmall",SmallCombinerReverseName="collectorsmallreverse",MediumCombinerName="collectormedium",MediumCombinerReverseName="collectormediumreverse";public const string MediumReverseCabinetName="mediumreverse";public const string MediumCabinetName="medium";}}

namespace ModularSwitchboards{public class DinTransformer{public long ReferenceId;}public class SmartContactor{public long ReferenceId;}}

namespace ModularSwitchboards {static class CabinetPorts {public static int ContactSlot(string name,int contact)=>!Combiner(name)?contact:contact==1?0:contact==0?1:contact==4?2:3;public static int InputCount(string name)=>name!=null&&name.Contains("medium")?3:2;public static bool Combiner(string name)=>name!=null&&name.StartsWith("collector");}}
