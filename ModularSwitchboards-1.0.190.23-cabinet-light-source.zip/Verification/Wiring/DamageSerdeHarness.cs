using System;using System.IO;using System.Linq;using System.Xml.Serialization;using ModularSwitchboards;
partial class SerdeHarness {
 internal static void RunDamage(){
 var wire=new CabinetWireSaveData{From=new(0,0),To=new(10,0),CableKind=CabinetWireKind.SuperHeavy,ColorIndex=5,Burnt=true,RouteVersion=8,Points=new[]{0f,.1f,.06f,.1f,.1f,.06f}};
 var xml=new XmlSerializer(typeof(CabinetWireSaveData));using var text=new StringWriter();xml.Serialize(text,wire);var restored=(CabinetWireSaveData)xml.Deserialize(new StringReader(text.ToString()));if(!restored.Burnt||restored.ColorIndex!=5||restored.CableKind!=wire.CableKind)throw new Exception("XML lost rupture/type/paint");
 var host=new SerdeHarness();host.Load(new[]{wire});var client=new SerdeHarness();void Sync(){using var packet=new MemoryStream();host.Write(new(packet));packet.Position=0;client.Read(new(packet));}
 Sync();if(!client.wires.Single().Burnt||client.ruptureEffects!=0)throw new Exception("initial join loses damage or replays rupture effect");Sync();if(client.ruptureEffects!=0)throw new Exception("unchanged damage replay");wire.Burnt=false;Sync();wire.Burnt=true;Sync();if(client.ruptureEffects!=1)throw new Exception("new rupture should emit once on client");Sync();if(client.ruptureEffects!=1)throw new Exception("periodic sync repeats rupture");
 using var legacy=new MemoryStream();var w=new RocketBinaryWriter(legacy);w.WriteInt32(-3);w.WriteInt32(1);WriteEnd(w,wire.From);WriteEnd(w,wire.To);w.WriteInt32(0);w.WriteInt32(7);w.WriteInt32(5);w.WriteInt32(2);w.WriteInt32(6);foreach(float p in wire.Points)w.WriteSingle(p);w.WriteInt32(0);legacy.Position=0;var old=new SerdeHarness();old.Read(new(legacy));if(old.wires.Count!=1||old.wires[0].Burnt||old.wires[0].CableKind!=CabinetWireKind.SuperHeavy)throw new Exception("v177 packet migration failed");
 Console.WriteLine("Rupture XML/network checks passed: burnt/type/paint roundtrip, legacy177 default intact, late join silent, new event once, repeated sync silent.");
 }
}
