using System;using System.Linq;using ModularSwitchboards;
partial class RouteHarness
{
 internal static void RunLargeWires()
 {
  int checks=0;void Check(bool ok,string message){checks++;if(!ok)throw new Exception(message);}
  Check(WireRouting.Radius==WireRouting.DefaultRadius&&WireRouting.Clearance==WireRouting.DefaultClearance,"default route budget changed");
  using(WireRouting.ForWire(.004f,.004f)){
   Check(WireRouting.Radius==.004f&&Math.Abs(WireRouting.Clearance-.009f)<1e-6,"8mm wire budget missing");
   var obstacle=new[]{new WireRect(-.01f,.01f,-.01f,.01f)};Check(!WireRouting.Clear(new(-.02f,.014f,.06f),new(.02f,.014f,.06f),obstacle,Array.Empty<WirePoint[]>(),false),"8mm wire allowed too close to module");
   var occupied=new[]{new[]{new WirePoint(-.04f,0,.06f),new WirePoint(.04f,0,.06f)}};Check(!WireRouting.Clear(new(-.04f,.008f,.06f),new(.04f,.008f,.06f),Array.Empty<WireRect>(),occupied,false),"two 8mm wires overlap");Check(WireRouting.Clear(new(-.04f,.012f,.06f),new(.04f,.012f,.06f),Array.Empty<WireRect>(),occupied,false),"wide wire safe separation rejected");
   using(WireRouting.ForWire(.0012f,.0012f))Check(WireRouting.Radius==.004f&&Math.Abs(WireRouting.Clearance-.009f)<1e-6,"thin nested budget inherits thick footprint");Check(WireRouting.Radius==.004f,"nested route scope not restored");
  }
  Check(WireRouting.Radius==WireRouting.DefaultRadius,"large route budget leaked");
  var h=new RouteHarness();var input=new CabinetWireEnd(0,0);var target=new CabinetWireEnd(10,0);h.railObstacles.Add(new(-.162f,.162f,.0905f,.1255f));h.railObstacles.Add(new(-.162f,.162f,-.1255f,-.0905f));
  h.contacts[input]=new(){End=input,Position=new(0,.196f,.033f),Exit=new(0,.178f,WireRouting.Plane),Bounds=new(-.036f,.036f,.195f,.227f)};
  h.contacts[target]=new(){End=target,Position=new(-.10125f,.158625f,.06535f),Exit=new(-.10125f,.174f,WireRouting.Plane),Bounds=new(-.121f,-.081f,.057375f,.158625f)};
  var path=h.MakeRoute(input,target,out int slot,out string failure,CabinetWireKind.SuperHeavy);Check(path!=null,"actual 8mm route failed: "+failure);Check(WireRouting.Radius==WireRouting.DefaultRadius,"actual route failed to release scope");
  var old=new CabinetWireSaveData{From=input,To=target,CableKind=CabinetWireKind.SuperHeavy,ColorIndex=5,CableUnits=1,RouteVersion=6,InputSlot=slot,Points=Flatten(path)};h.wires.Add(old);h.RerouteLegacy();Check(h.wires.Count==1&&h.wires[0].CableKind==CabinetWireKind.SuperHeavy&&h.wires[0].ColorIndex==5&&h.wires[0].CableUnits==1&&h.wires[0].RouteVersion==9,"route migration lost typed colour or quantity");
  Console.WriteLine(checks+" large-wire routing checks passed: 8mm obstacle/inter-wire spacing, nested budget isolation, actual route, and old coloured Super Heavy migration.");
 }
}
