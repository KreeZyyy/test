using System;
using System.Collections.Generic;
using System.Linq;
using ModularSwitchboards;
using Assets.Scripts.Networks;
using Assets.Scripts.Objects.Items;
static class BatteryHarness
{
 static int count;static void Check(bool value,string message){count++;if(!value)throw new Exception(message);}
 static CabinetWireSaveData W(long a,int ap,long b,int bp)=>new(){From=new(a,ap),To=new(b,bp)};
 internal static void Run()
 {
  var c=new SwitchboardCabinet();var input=new CableNetwork{PotentialLoad=5000};var one=new CableNetwork{RequiredLoad=1000};var two=new CableNetwork{RequiredLoad=1000};
  c.InputConnection.cable.CableNetwork=input;c.Output1Connection.cable.CableNetwork=one;c.Output2Connection.cable.CableNetwork=two;
  var cell=new BatteryCell{ReferenceId=100,PowerStored=2000,PowerMaximum=5000};var battery=new DinBreaker{ReferenceId=10,IsBatteryModule=true,Battery=cell};
  var fuse=new DinBreaker{ReferenceId=20,OnOff=true,RatedWatts=1000};
  var modules=new[]{battery,fuse};var wires=new List<CabinetWireSaveData>{W(0,0,10,0),W(10,1,20,0),W(20,1,0,1)};
  var p=new CabinetWiringPower();p.Refresh(c,wires,modules);PowerCycle.Next(p);
  Check(p.Generated(one)>=5000,"Battery module doesn't pass input");PowerCycle.Use(p,one,500);Check(cell.PowerStored==2000&&p.Used(input)==1500,"Input not preferred over battery or charge demand wrong");
  p.Receive(input,1500);PowerCycle.Next(p);Check(cell.PowerStored==3000&&p.Used(input)==1000,"Charging or energy repayment wrong");
  input.PotentialLoad=0;p.Refresh(c,wires,modules);PowerCycle.Next(p);float offered=p.Generated(one);Check(offered==3000&&p.Generated(one)==offered,"Repeated generated queries consume/reserve twice");PowerCycle.Use(p,one,500);Check(cell.PowerStored==2500&&p.DrainTrips().Length==0,"Backup drain wrong");
  p.Refresh(c,wires,modules);PowerCycle.Next(p);p.Generated(one);PowerCycle.Use(p,one,1001);Check(p.DrainTrips().Contains(20),"Downstream protection bypassed during battery backup");
  fuse.OnOff=false;p.Refresh(c,wires,modules);PowerCycle.Next(p);Check(p.Generated(one)==0,"OFF didn't isolate backup");
  fuse.OnOff=true;battery.Battery=null;p.Refresh(c,wires,modules);PowerCycle.Next(p);Check(p.Generated(one)==0,"Missing battery generated backup");input.PotentialLoad=5000;p.Refresh(c,wires,modules);PowerCycle.Next(p);Check(p.Generated(one)==5000,"Empty battery bay blocks mains passthrough");p.ObserveIdle(one);
  // A charged cell disconnected from IN still powers only its downstream output.
  battery.Battery=cell;input.PotentialLoad=0;wires.RemoveAt(0);p.Refresh(c,wires,modules);PowerCycle.Next(p);float before=cell.PowerStored;Check(p.Generated(one)==before&&p.Generated(two)==0,"Disconnected IN prevents backup or leaks to other output");PowerCycle.Use(p,one,100);Check(cell.PowerStored==before-100&&p.Used(input)==0,"Backup manufactured input debt or charge without IN path");
  p.Refresh(c,wires,modules);PowerCycle.Next(p);p.Generated(one);fuse.OnOff=false;p.Refresh(c,wires,modules);PowerCycle.Next(p);Check(p.Generated(one)==0,"Pending offer bypassed newly opened protection");p.ObserveIdle(one);fuse.OnOff=true;
  // Two advertised output budgets reserve one common battery, regardless of callback order.
  wires=new(){W(10,1,0,1),W(10,1,0,2)};cell.PowerStored=1000;p=new();p.Refresh(c,wires,new[]{battery});PowerCycle.Next(p);
  float a=p.Generated(one),b=p.Generated(two);Check(a+b==1000,"Battery duplicated across output budgets");PowerCycle.Use(p,one,a);p.Refresh(c,wires,new[]{battery});PowerCycle.Use(p,two,b);Check(cell.PowerStored==0&&p.Used(input)==0,"Energy reservation lost across refresh/second output callback");
  cell.PowerStored=1000;p.Refresh(c,wires,new[]{battery});PowerCycle.Next(p);a=p.Generated(one);b=p.Generated(two);PowerCycle.Use(p,two,b);PowerCycle.Use(p,one,a);Check(cell.PowerStored==0,"Reverse callback order duplicated/lost battery energy");
  cell.PowerStored=1000;p.Refresh(c,wires,new[]{battery});PowerCycle.Next(p);p.Generated(one);p.ObserveIdle(one);Check(cell.PowerStored==1000,"Unused advertised energy drained battery");PowerCycle.Next(p);Check(p.Generated(one)>0,"Idle offer didn't release reservation");p.ObserveIdle(one);
  // No charge can appear without delivered input energy; clamp at native capacity.
  wires=new(){W(0,0,10,0)};input.PotentialLoad=1000;cell.PowerStored=4900;p=new();p.Refresh(c,wires,new[]{battery});PowerCycle.Next(p);Check(p.Used(input)==100,"Charge demand exceeds room");p.Receive(input,50);Check(cell.PowerStored==4950,"Partial charge not conserved");p.Receive(input,10000);Check(cell.PowerStored==5000&&p.Used(input)==0,"Overfilled native battery");
  // Charging itself passes through upstream fuse and counts toward its load.
  fuse.RatedWatts=500;wires=new(){W(0,0,20,0),W(20,1,10,0)};cell.PowerStored=0;p=new();p.Refresh(c,wires,modules);PowerCycle.Next(p);p.Used(input);p.Receive(input,1000);Check(cell.PowerStored==1000&&p.DrainTrips().Contains(20),"Charging bypasses upstream protection");
  // Existing bridge debt must survive first battery module installation.
  p=new();wires=new(){W(0,0,20,0),W(20,1,0,1)};p.Refresh(c,wires,new[]{fuse});PowerCycle.Next(p);PowerCycle.Use(p,one,100);p.Refresh(c,wires,modules);PowerCycle.Next(p);Check(p.Used(input)==100,"Activation discarded input debt");p.Receive(input,100);Check(p.Used(input)==0,"Activation debt not repaid");
  var rng=new Random(881);var extra=new DinBreaker{ReferenceId=30,IsBatteryModule=true,Battery=new BatteryCell{ReferenceId=101,PowerMaximum=5000}};
  wires=new(){W(10,1,30,0),W(30,1,0,1),W(30,1,0,2)};input.PotentialLoad=0;
  for(int iteration=0;iteration<1000;iteration++){
   cell.PowerStored=(float)rng.NextDouble()*5000;extra.Battery.PowerStored=(float)rng.NextDouble()*5000;
   float initial=cell.PowerStored+extra.Battery.PowerStored;p=new();p.Refresh(c,wires,new[]{battery,extra});PowerCycle.Next(p);
   a=p.Generated(one);b=p.Generated(two);Check(a+b<=initial+.002f,"Two batteries over-advertised combined charge");
   float useA=a*(float)rng.NextDouble(),useB=b*(float)rng.NextDouble();
   if(iteration%2==0){PowerCycle.Use(p,one,useA);p.Refresh(c,wires,new[]{battery,extra});PowerCycle.Use(p,two,useB);}else{PowerCycle.Use(p,two,useB);p.Refresh(c,wires,new[]{battery,extra});PowerCycle.Use(p,one,useA);}
   Check(Math.Abs(initial-cell.PowerStored-extra.Battery.PowerStored-useA-useB)<.004f&&p.Used(input)==0,"Random backup lost or manufactured energy");
  }
  Console.WriteLine("Production battery bridge passed "+count+" checks: mains, charge, backup, isolation, shared reservations, callback order, idle, capacity, charge protection and existing debt.");
 }
}
