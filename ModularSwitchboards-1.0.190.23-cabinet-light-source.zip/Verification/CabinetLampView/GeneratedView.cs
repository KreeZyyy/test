using UnityEngine;
namespace ModularSwitchboards
{
    public sealed class CabinetLampView:MonoBehaviour
    {
        private CabinetLamp owner;private MeshRenderer diffuser;private Light[] glows;
        private SwitchboardCabinet boundCabinet;private CabinetDoor door;
        private MaterialPropertyBlock block;
        private bool dirty=true,hasVisibility,lastVisibility;
        private static readonly int Emission=Shader.PropertyToID("_EmissionColor");
        private void OnEnable(){Bind();}
        private void Bind()
        {
            owner=GetComponent<CabinetLamp>();diffuser=transform.Find("CabinetLampDiffuser")?.GetComponent<MeshRenderer>();
            glows=transform.Find("CabinetLampGlow")?.GetComponentsInChildren<Light>(true);
            if(block==null)block=new MaterialPropertyBlock();
            boundCabinet=null;door=null;dirty=true;hasVisibility=false;
        }
        internal void Invalidate(){dirty=true;}
        private void OnDisable()
        {
            if(glows!=null)foreach(var light in glows)if(light!=null)light.enabled=false;
            hasVisibility=false;
        }
        private void LateUpdate()
        {
            if(owner==null)return;
            var cabinet=owner.Cabinet;
            if(cabinet!=boundCabinet){boundCabinet=cabinet;door=cabinet!=null?cabinet.GetComponent<CabinetDoor>():null;}
            bool on=!owner.IsCursor&&owner.IsStructureCompleted&&owner.Lit;
            bool aperture=cabinet!=null&&(cabinet.IsOpen||(door!=null&&door.Hinge!=null&&Quaternion.Angle(door.Hinge.localRotation,Quaternion.identity)>.5f));
            bool visible=CabinetLampLighting.Visible(on,aperture);
            if(dirty)DoorModules.PaintCubes(owner.transform);
            if(dirty||!hasVisibility||visible!=lastVisibility)
            {
                if(glows!=null)foreach(var light in glows)if(light!=null)light.enabled=visible;
                if(diffuser!=null){block.Clear();block.SetColor(Emission,visible?Color.white*1.2f:Color.black);diffuser.SetPropertyBlock(block);diffuser.SetPropertyBlock(block,0);}
                lastVisibility=visible;hasVisibility=true;dirty=false;
            }
        }
    }
}
