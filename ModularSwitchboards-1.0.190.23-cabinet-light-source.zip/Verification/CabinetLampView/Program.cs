using System;using System.Reflection;using ModularSwitchboards;using UnityEngine;
namespace UnityEngine{
 public struct Quaternion{public float angle;public static Quaternion identity=>default;public static float Angle(Quaternion a,Quaternion b)=>Math.Abs(a.angle-b.angle);}
 public struct Color{public static Color white=>default;public static Color black=>default;public static Color operator *(Color c,float f)=>c;}
 public static class Shader{public static int PropertyToID(string s)=>1;}
 public class MaterialPropertyBlock{public static int Created;public MaterialPropertyBlock(){Created++;}public void Clear(){}public void SetColor(int id,Color c){}}
 public class Light{public static int Writes;private bool live;public bool enabled{get=>live;set{Writes++;live=value;}}}
 public class MeshRenderer{public static int Writes;public void SetPropertyBlock(MaterialPropertyBlock b){Writes++;}public void SetPropertyBlock(MaterialPropertyBlock b,int sub){Writes++;}}
 public class Transform{public static int Finds,Scans;public Quaternion localRotation;public MeshRenderer lens;public Light[] lights;public Transform Find(string n){Finds++;return this;}public T GetComponent<T>()where T:class=>lens as T;public T[] GetComponentsInChildren<T>(bool all){Scans++;return lights as T[];}}
 public class MonoBehaviour{public Transform transform;public CabinetLamp lamp;public T GetComponent<T>()where T:class=>lamp as T;}
}
namespace ModularSwitchboards{
 public class CabinetLamp{public bool IsCursor,IsStructureCompleted=true,Lit=true;public Transform transform;public SwitchboardCabinet Cabinet;}
 public class SwitchboardCabinet{public bool IsOpen=true;public int DoorQueries;public CabinetDoor door=new(){Hinge=new Transform()};public T GetComponent<T>()where T:class{DoorQueries++;return door as T;}}
 public class CabinetDoor{public Transform Hinge;}
 public static class DoorModules{public static int Restores;public static void PaintCubes(Transform t){Restores++;}}
}
class Program{
 static int n;static void Check(bool c,string m){n++;if(!c)throw new Exception(m);}
 static void Invoke(object o,string n)=>o.GetType().GetMethod(n,BindingFlags.Instance|BindingFlags.NonPublic).Invoke(o,null);
 static void Main(){var t=new Transform{lens=new MeshRenderer(),lights=new[]{new Light(),new Light(),new Light()}};var cabinet=new SwitchboardCabinet();var lamp=new CabinetLamp{Cabinet=cabinet,transform=t};var view=new CabinetLampView{lamp=lamp,transform=t};Invoke(view,"OnEnable");Invoke(view,"LateUpdate");
  Check(t.lights[0].enabled&&t.lights[2].enabled,"powered open fixture dark");var initial=(MaterialPropertyBlock.Created,MeshRenderer.Writes,Light.Writes,Transform.Finds,Transform.Scans,DoorModules.Restores,cabinet.DoorQueries);
  for(int i=0;i<10000;i++)Invoke(view,"LateUpdate");
  Check(initial==(MaterialPropertyBlock.Created,MeshRenderer.Writes,Light.Writes,Transform.Finds,Transform.Scans,DoorModules.Restores,cabinet.DoorQueries),"stable frames recreated blocks, scanned children, restored palette, queried door or rewrote lights/materials");
  cabinet.IsOpen=false;cabinet.door.Hinge.localRotation=new Quaternion{angle=50};Invoke(view,"LateUpdate");Check(t.lights[0].enabled,"closing animation cut illumination early");cabinet.door.Hinge.localRotation=Quaternion.identity;Invoke(view,"LateUpdate");Check(!t.lights[0].enabled&&!t.lights[2].enabled,"closed cabinet leaked illumination");Check(lamp.Lit,"optical close changed supplied state");
  cabinet.IsOpen=true;Invoke(view,"LateUpdate");Check(t.lights[1].enabled,"reopen failed");view.Invalidate();int restores=DoorModules.Restores;Invoke(view,"LateUpdate");Check(DoorModules.Restores==restores+1,"paint invalidation ignored");Invoke(view,"LateUpdate");Check(DoorModules.Restores==restores+1,"paint invalidation repeats forever");
  int blocks=MaterialPropertyBlock.Created;Invoke(view,"OnDisable");Check(!t.lights[0].enabled,"disable left illumination on");Invoke(view,"OnEnable");Invoke(view,"LateUpdate");Check(MaterialPropertyBlock.Created==blocks,"enable recreated reusable block");lamp.Lit=false;Invoke(view,"LateUpdate");Check(!t.lights[1].enabled,"power-off failed");Console.WriteLine(n+" actual view cache/state checks passed, including 10000 stable frames with zero extra block creation/scans/palette restores/property writes");
 }
}
