from pathlib import Path
root=Path(__file__).resolve().parents[2]
source=(root/'Source/CabinetLampModel.cs').read_text()
view=source[source.index('    public sealed class CabinetLampView:MonoBehaviour'):]
(root/'Verification/CabinetLampView/GeneratedView.cs').write_text('using UnityEngine;\nnamespace ModularSwitchboards\n{\n'+view)
