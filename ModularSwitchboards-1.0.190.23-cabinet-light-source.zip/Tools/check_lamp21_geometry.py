from pathlib import Path
import struct,math
r=Path(__file__).resolve().parents[1];orig=1.528524*.195;checks=0;thin=0
def base(v):
 x,y,z=v;return(x*.195,-(z-.1086)*.13,.132+(y-.1624)*.13-.045*max(0,min(1,(.1477-y)/.1477)))
for cab,row,tx,ty in [(.4,110,.14,-.003),(.8,250,.3,-.025)]:
 width=min(orig*2,cab-.07);ratio=width/orig;ceiling=.244*(2 if cab==.8 else 1)-.0002;raiseY=ceiling-row*.0018-.019419603
 def profile(v):
  px,py,pz=base(v);f=max(0,min(1,(v[1]-.13)/.05));sx=px+max(-1,min(1,px/(orig*.4)))*(width-orig)/2
  roof=max(0,min(1,(py-.003)/.0054))*f
  return(sx*(1-f)+px*ratio*f,py*(1-roof)+.019419603*roof+raiseY,pz*(1-f)+(.159+(pz-.159)*2.5)*f)
 for name in ['Body','Diffuser']:
  data=(r/'Assets/CabinetLamp'/f'{name}.meshbin').read_bytes();_,n,g=struct.unpack_from('<iii',data);native=[struct.unpack_from('<5f',data,12+i*20)[:3] for i in range(n)];p=[profile(v) for v in native];off=12+n*20
  assert max(abs(v[0]) for v in p)<cab*.5-.025;checks+=1
  assert max(v[1]+row*.0018 for v in p)<=cab*.625+1e-7;checks+=1
  assert max(v[2]+.014 for v in p)<.185;checks+=1
  if name=='Diffuser':assert min(v[2]+.014 for v in p)>.1035;checks+=1
  if name=='Body':
   roof=[profile(v)[1]+row*.0018 for v in native if v[1]>=.18 and base(v)[1]>=.0084]
   assert len(roof)>2 and max(roof)-min(roof)<1e-7;checks+=1
   assert abs(roof[0]-ceiling)<1e-7;checks+=1
  for group in range(g):
   count=struct.unpack_from('<i',data,off)[0];off+=4;ids=struct.unpack_from('<'+'i'*count,data,off);off+=4*count
   for i in range(0,count,3):
    vs=[native[k] for k in ids[i:i+3]]
    if all(v[1]<.13 and v[0]*.195>orig*.4 for v in vs) or all(v[1]<.13 and v[0]*.195<-orig*.4 for v in vs):
     for j in range(3):
      a,b=vs[j],vs[(j+1)%3];assert abs(math.dist(base(a),base(b))-math.dist(profile(a),profile(b)))<1e-6
     thin+=1
 assert tx+.029<cab*.5-.025;checks+=1
 assert math.hypot(tx,(row*.0018+ty)-(.44 if cab==.8 else .211))>.1;checks+=1
 # Fixed lead enters the real visible mouth, not the outlying native grid anchor.
 mouth=profile((.75,-.000207672,0));end=profile((.7495,-.000207672,0))
 assert 0<mouth[0]-end[0]<.0002;checks+=1
 assert abs(mouth[1]-end[1])<1e-9 and abs(mouth[2]-end[2])<1e-9;checks+=1
 start=(tx+.009,row*.0018+ty,.0244);end=(end[0],end[1]+row*.0018,end[2]+.014)
 b=(start[0]+.018,start[1],start[2]+.005);c=(end[0]+.020,end[1],end[2])
 assert c[0]>end[0] and c[1:]==end[1:];checks+=1
 for i in range(25):
  t=i/24;u=1-t;q=[start[k]*u*u*u+3*b[k]*u*u*t+3*c[k]*u*t*t+end[k]*t*t*t for k in range(3)]
  assert abs(q[0])<cab*.5-.025 and 0<q[2]<.1035
 checks+=1
 assert tx-.009-.020>0;checks+=1
 print('profile',cab,'roof',ceiling,'socket entry',end,'width',width)
assert thin>0
assert 'CabinetLampSocketBridge' not in (r/'Source/CabinetLampModel.cs').read_text()
assert 'ModelBlueprint.Build(' not in (r/'Source/CabinetLampModel.cs').read_text()
print(checks,'clearance/terminal-placement checks and',thin,'thin-support triangle checks passed')

blob=(r/'Assets/Cabinet.meshbin').read_bytes();version,mats,count=struct.unpack_from('<iii',blob,4);off=16+mats*24;roof_planes=[]
for model in range(count):
 n=struct.unpack_from('<i',blob,off)[0];off+=4;v=[];norm=[]
 for i in range(n):
  item=struct.unpack_from('<6f',blob,off);off+=24;v.append(item[:3]);norm.append(item[3:])
 for group in range(mats):
  length=struct.unpack_from('<i',blob,off)[0];off+=4;ids=struct.unpack_from('<'+'i'*length,blob,off);off+=4*length
  if model!=1:continue
  for j in range(0,length,3):
   tri=[v[k] for k in ids[j:j+3]];ns=[norm[k] for k in ids[j:j+3]]
   if min(p[1] for p in tri)>.24 and all(n[1]<-.9 for n in ns) and min(p[0] for p in tri)<-.17 and max(p[0] for p in tri)>.17:roof_planes.append(sum(p[1] for p in tri)/3)
assert len(roof_planes)==2 and all(abs(y-.244)<1e-7 for y in roof_planes)
print('Own cabinet inner roof .244 m verified from both full-span ceiling triangles (Medium stretches by2).')
