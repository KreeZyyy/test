namespace ModularSwitchboards
{
    internal static class CabinetLampLighting
    {
        internal const int Count=3;
        internal const float Intensity=.55f;
        internal static float Offset(int index,float width)=>(index-1)*width*.36f;
        internal static float Range(bool medium)=>medium?1.6f:.95f;
        // Optical occlusion only. This is never used by the electrical service node:
        // closing a door does not disconnect the lamp or stop its 50 W consumption.
        internal static bool Visible(bool supplied,bool open)=>supplied&&open;
    }
}
