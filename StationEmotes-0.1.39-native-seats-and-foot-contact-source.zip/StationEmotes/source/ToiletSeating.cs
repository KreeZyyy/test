using System;
using System.Collections.Generic;
using Assets.Scripts;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Inventory;
using Assets.Scripts.Localization2;
using Assets.Scripts.Networking;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Entities;
using Assets.Scripts.UI;
using Assets.Scripts.Util;
using HarmonyLib;
using Objects.Structures;
using UnityEngine;
namespace StationEmotes
{
 // A native entity slot: the game owns occupancy, movement, save data and replication.
 internal static class ToiletSeating
 {
  internal const string Marker="StationEmotesToiletSeat";
  internal static Slot Slot(StructureToilet t)=>t?.Slots?.Find(s=>s.StringKey==Marker);
  internal static Vector3 Front(StructureToilet t)=>t.transform.TransformPoint(new Vector3(0,0,.65f));
  internal static void InstallLoaded()
  {
   foreach(var t in Resources.FindObjectsOfTypeAll<StructureToilet>())Ensure(t,true);
  }
  internal static void Ensure(StructureToilet t,bool initialized)
  {
   if(t==null)return;
   var slot=Slot(t);
   if(slot==null)
   {
    var anchor=new GameObject(Marker);anchor.transform.SetParent(t.transform,false);
    // Initial standard-toilet alignment; native seated hips are about .42 m above the entity origin.
    anchor.transform.localPosition=new Vector3(0,0,.05f);
    var hitObject=new GameObject(Marker+"Control");hitObject.layer=t.Interactables.Find(i=>i.Action==InteractableType.Activate)?.Collider?.gameObject.layer??t.gameObject.layer;hitObject.transform.SetParent(t.transform,false);
    hitObject.transform.localPosition=new Vector3(0,.35f,.36f);
    var hit=hitObject.AddComponent<BoxCollider>();hit.size=new Vector3(.36f,.16f,.10f);hit.isTrigger=true;
    var action=(InteractableType)Enum.Parse(typeof(InteractableType),"Slot"+((t.Slots?.Count??0)+1));
    slot=new Slot{StringKey=Marker,StringHash=Animator.StringToHash(Marker),Parent=t,Type=Assets.Scripts.Objects.Slot.Class.Entity,
     Location=anchor.transform,EntityControlMode=MovementController.Mode.Seated,RealWorldScale=true,
     IsInteractable=true,IsSwappable=false,AllowDragging=false,Action=action,Collider=hit};
    t.Slots=t.Slots==null?new List<Slot>():new List<Slot>(t.Slots);t.Slots.Add(slot);
    var control=new Interactable{StringKey=Marker,StringHash=Animator.StringToHash(Marker),Parent=t,Action=action,Collider=hit,Bounds=new Bounds(hit.center,hit.size),OriginalBounds=new Bounds(hit.center,hit.size)};
    t.Interactables=new List<Interactable>(t.Interactables);t.Interactables.Add(control);
   }
   if(t.GetComponent<ToiletOccupancy>()==null)t.gameObject.AddComponent<ToiletOccupancy>();
   if(initialized)
   {
    // Prefabs may already be awake when LaunchPad loads the mod. Register their added controls too.
    slot.Parent=t;slot.Initialize();
    var control=t.Interactables.Find(i=>i.Action==slot.Action);if(control==null)return;
    control.Parent=t;control.Initialize();control.Bounds=new Bounds(slot.Collider.center,slot.Collider.size);control.OriginalBounds=control.Bounds;
    Register(t,"_slotLookup",slot.Collider,slot);
    Register(t,"_interactableLookup",slot.Action,control);
    Register(t,"_interactableColliderLookup",slot.Collider,control);
   }
  }
  internal static void Register(Thing parent,string field,object key,object value)
  {
   var info=AccessTools.Field(typeof(Thing),field);
   var map=info?.GetValue(parent) as System.Collections.IDictionary;
   if(map==null&&info!=null){map=(System.Collections.IDictionary)Activator.CreateInstance(info.FieldType);info.SetValue(parent,map);}
   if(map!=null)map[key]=value;
  }
  internal static bool Exit(Human h,StructureToilet t)
  {
   if(h.LockedToSeat)return false;
   var slot=h.ParentSlot;
   if(slot==null||slot!=Slot(t)||!ChairSeatRouting.TryExit(h,slot,out var position))return false;
   if(NetworkManager.IsClient)
   {
    NetworkClient.SendToServer(new MoveToWorldMessage{ChildId=h.ReferenceId,Force=0,IsPrecisionPlacement=true,Position=position,Rotation=ChairSeatRouting.Facing(slot),Velocity=Vector3.zero,AngularVelocity=Vector3.zero});
    if(!h.IsLocalPlayer)return true;
   }
   return h.MoveToWorld(position,ChairSeatRouting.Facing(slot),Vector3.zero,Vector3.zero);
  }
 }
 internal sealed class ToiletOccupancy:MonoBehaviour
 {
  internal Human Occupant;internal float ReadyAt;
  internal void Enter(Human h,float duration){Occupant=h;ReadyAt=Time.time+duration;(h.GetComponent<ToiletInteractionState>()??h.gameObject.AddComponent<ToiletInteractionState>()).Begin(h);}
  private void Update()
  {
   var toilet=GetComponent<StructureToilet>();if(toilet==null)return;
   var current=ToiletSeating.Slot(toilet)?.Get() as Human;
   // Restored occupied slots have no new entry animation; do not leave them blocked forever.
   if(current!=Occupant){Occupant=current;ReadyAt=Time.time+.25f;}
  }
 }
 [HarmonyPatch(typeof(Thing),"Awake")]
 internal static class ToiletAwakePatch
 {
  static void Prefix(Thing __instance)
  {
   if(__instance is StructureToilet t)ToiletSeating.Ensure(t,false);

  }
  static void Postfix(Thing __instance){if(ChairSeatRouting.Supported(__instance))SeatInteractionRouting.Ensure(__instance);}
 }
 [HarmonyPatch(typeof(StructureToilet),"InteractWith")]
 internal static class ToiletInteractPatch
 {
  static bool Prefix(StructureToilet __instance,Interactable __0,Interaction __1,bool __2,ref Thing.DelayedActionInstance __result)
  {
   var slot=ToiletSeating.Slot(__instance);if(slot==null)return true;
   var h=__1.SourceThing as Human;
   if(__0.Action==slot.Action||(__0.Action==InteractableType.Activate&&(h==null||h.ParentSlot!=slot||__1.AltKey)))
   {
    bool seated=h!=null&&h.ParentSlot==slot;
    var result=new Thing.DelayedActionInstance{Duration=.25f,ActionMessage=seated?"Stand up":"Sit down"};
    __result=result;
    if(h==null||h.State!=EntityState.Alive)return Fail(result,"Only a conscious engineer can sit here.");
    if(!__instance.IsStructureCompleted)return Fail(result,"Finish building the toilet first.");
    if(seated)
    {
     if(__2&&GameManager.RunSimulation&&!ToiletSeating.Exit(h,__instance))return Fail(result,"The space in front of the toilet is blocked.");
     result.Succeed();return false;
    }
    if(slot.IsLocked||h.ParentSlot!=null||slot.Get()!=null)return Fail(result,"The toilet is occupied or you are already seated.");
    if(!ChairTransition.InFront(h,__instance))return Fail(result,"Move closer to the toilet on solid ground to sit down.");
    if(__2&&GameManager.RunSimulation)OnServer.MoveToSlot(h,slot);
    result.Succeed();return false;
   }
   if(__0.Action!=InteractableType.Activate)return true;
   var state=__instance.GetComponent<ToiletOccupancy>();
   bool ready=ToiletUsePolicy.Ready(h!=null&&h.ParentSlot==slot&&state!=null&&state.Occupant==h,h!=null&&h.GetComponent<ChairTransition>()?.Active==true,Time.time,state?.ReadyAt??float.PositiveInfinity);
   if(ready)return true; // Original suit, sanitation, water, pressure and waste handling stay authoritative.
   __result=new Thing.DelayedActionInstance{Duration=1,ActionMessage=GameStrings.Use};
   return Fail(__result,"Finish sitting down before using the toilet. Hold the quantity modifier and click to stand, or move forward.");
  }
  private static bool Fail(Thing.DelayedActionInstance result,string message){result.ExtendedMessage=message;result.Fail();return false;}
 }
 [HarmonyPatch(typeof(DynamicThing),"MoveToSlot",new Type[]{typeof(Slot),typeof(Thing),typeof(bool)})]
 internal static class ToiletEnterPatch
 {
  static void Prefix(DynamicThing __instance,Slot __0,out float __state)
  {
   __state=0;
   if(__instance is Human h&&__0?.Parent is StructureToilet t&&__0==ToiletSeating.Slot(t))
   {
    var delta=ToiletSeating.Front(t)-h.ThingTransform.position;delta.y=0;
    __state=new ChairPlan(true,delta.magnitude,Quaternion.Angle(ChairPoseFrame.Upright(h.CharacterRotationY!=null?h.CharacterRotationY.rotation:h.ThingTransform.rotation),ChairPoseFrame.Upright(t.transform.rotation))).Duration+.25f;
   }
  }
  static void Postfix(DynamicThing __instance,Slot __0,bool __result,float __state)
  {
   if(__result&&__state>0&&__instance is Human h&&__0.Parent is StructureToilet t)
    (t.GetComponent<ToiletOccupancy>()??t.gameObject.AddComponent<ToiletOccupancy>()).Enter(h,__state);
  }
 }
 [HarmonyPatch(typeof(Human),"ExitAnything")]
 internal static class ToiletExitPatch
 {
  static bool Prefix(Human __instance,ref bool __result)
  {
   if(!(__instance.ParentSlot?.Parent is StructureToilet t)||__instance.ParentSlot!=ToiletSeating.Slot(t))return true;
   __result=ToiletSeating.Exit(__instance,t);return false;
  }
 }
}
namespace StationEmotes
{
 internal sealed class ToiletInteractionState:UnityEngine.MonoBehaviour
 {
  private Assets.Scripts.Objects.Entities.Human human;private bool previous,changed;
  internal void Begin(Assets.Scripts.Objects.Entities.Human h)
  {if(changed)return;human=h;previous=h.AllowChildInteraction;changed=true;h.AllowChildInteraction=true;}
  private void Update()
  {
   if(human==null||!ChairSeatRouting.Supported(human.ParentSlot)||human.ParentSlot.Parent is global::IExitable){Restore();UnityEngine.Object.Destroy(this);}
  }
  internal void Restore(){if(changed&&human!=null)human.AllowChildInteraction=previous;changed=false;}
  private void OnDisable()=>Restore();
  private void OnDestroy()=>Restore();
 }
 [HarmonyLib.HarmonyPatch(typeof(Assets.Scripts.Objects.Entities.Human),"SeatedInFreeLook")]
 internal static class ToiletFreeLookPatch
 {
  static void Postfix(Assets.Scripts.Objects.Entities.Human __instance,ref bool __result)
  {
   if(ChairSeatRouting.Supported(__instance.ParentSlot)&&!(__instance.ParentSlot.Parent is global::IExitable))
    __result=__instance.State==EntityState.Alive&&!__instance.Unconscious&&!__instance.IsOccluded&&(__instance.OrganBrain==null||__instance.OrganBrain.IsOnline);
  }
 }
}

namespace StationEmotes
{
 [HarmonyLib.HarmonyPatch(typeof(Assets.Scripts.Objects.Entities.Human),"OnExitInventory")]
 internal static class ToiletInteractionRestorePatch
 {
  static void Postfix(Assets.Scripts.Objects.Entities.Human __instance,Assets.Scripts.Objects.Thing __0)
  {
   if(!ChairSeatRouting.Supported(__0)||__0 is global::IExitable)return;
   var state=__instance.GetComponent<ToiletInteractionState>();if(state==null)return;
   state.Restore();UnityEngine.Object.Destroy(state);
  }
 }
 [HarmonyLib.HarmonyPatch(typeof(Assets.Scripts.Objects.Slot),"get_DisplayName")]
 internal static class AddedSeatSlotNamePatch
 {
  static bool Prefix(Assets.Scripts.Objects.Slot __instance,ref string __result)
  {
   if(__instance.StringKey==ToiletSeating.Marker){__result="Seat";return false;}
   if(__instance.StringKey=="StationEmotesDoubleSeat"){__result="Seat (right)";return false;}
   return true;
  }
 }
 [HarmonyLib.HarmonyPatch(typeof(Assets.Scripts.Objects.Interactable),"get_DisplayName")]
 internal static class AddedSeatControlNamePatch
 {
  static bool Prefix(Assets.Scripts.Objects.Interactable __instance,ref string __result)
  {
   if(__instance.StringKey==ToiletSeating.Marker){__result="Sit / stand";return false;}
   if(__instance.StringKey=="StationEmotesDoubleSeat"){__result="Seat (right)";return false;}
   return true;
  }
 }
}
