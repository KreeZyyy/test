using Assets.Scripts.Objects.Entities;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Structures;
using UnityEngine;
namespace StationEmotes
{
 internal struct ChairFloorContact{internal Vector3 Point;internal string Name;internal int Chairs,Humans;}
 internal static class ChairFloorProbe
 {
  internal static bool Try(Vector3 ankle,Thing seat,Human human,float expected,out ChairFloorContact contact)
  {
   contact=new ChairFloorContact();
   float top=float.IsNaN(expected)?ankle.y+.45f:Mathf.Max(ankle.y+.45f,expected+.6f);
   float length=float.IsNaN(expected)?1.6f:Mathf.Clamp(top-expected+.45f,.8f,3f);
   var origin=new Vector3(ankle.x,top,ankle.z);
   var hits=Physics.RaycastAll(origin,Vector3.down,length,human.AllButPlayerImmune,QueryTriggerInteraction.Ignore);
   float best=float.PositiveInfinity;bool found=false;
   foreach(var hit in hits)
   {
    if(hit.collider==null)continue;
    bool chair=hit.collider.transform.IsChildOf(seat.ThingTransform)||hit.collider.GetComponentInParent<Seat>()!=null;
    bool actor=hit.collider.GetComponentInParent<Human>()!=null;
    if(chair)contact.Chairs++;if(actor)contact.Humans++;
    if(!ChairFloorPolicy.Accept(hit.normal.y,hit.point.y,expected,chair,actor)||hit.distance>=best)continue;
    found=true;best=hit.distance;contact.Point=hit.point;contact.Name=hit.collider.name;
   }
   return found;
  }
  internal static bool Calibrate(ChairTransition.Snapshot s,ChairStandingPose pose)
  {
   for(int i=0;i<2;i++)
   {
    var ankle=i==0?s.LeftFootPosition:s.RightFootPosition;ChairFloorContact contact;
    if(!Try(ankle,s.Seat,s.Human,float.NaN,out contact)||!ChairFloorPolicy.Clearance(ankle.y-contact.Point.y))
    {Plugin.Log.LogWarning("Chair standing calibration skipped: no valid floor/ankle clearance.");return false;}
    pose.Sole[i]=Mathf.Max(0,ankle.y-contact.Point.y);
    pose.FloorRelativeToSeat[i]=contact.Point.y-s.Seat.ThingTransform.position.y;
   }
   return true;
  }
 }
}
