using System.Reflection;
[assembly: AssemblyVersion("0.1.39.0")]
[assembly: AssemblyFileVersion("0.1.39.0")]
