using System;
using System.Collections.Generic;
using Assets.Scripts;
using Assets.Scripts.Inventory;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Entities;
using HarmonyLib;
using Objects.Structures;
using UnityEngine;
namespace StationEmotes
{
 internal static class SeatInteractionRouting
 {
  internal static void InstallLoaded()
  {
   foreach(var thing in Resources.FindObjectsOfTypeAll<Thing>())
    if(ChairSeatRouting.Supported(thing))Ensure(thing);
  }
  internal static void Ensure(Thing thing)
  {
   if(thing.Slots==null)return;
   for(int i=0;i<thing.Slots.Count;i++)
   {
    var slot=thing.Slots[i];
    if(slot.Type!=Slot.Class.Entity||slot.EntityControlMode!=MovementController.Mode.Seated||slot.Location==null)continue;
    slot.Parent=thing;slot.Action=(InteractableType)Enum.Parse(typeof(InteractableType),"Slot"+(i+1));
    var control=thing.Interactables.Find(c=>c.Action==slot.Action);
    if(control==null)
    {
     control=new Interactable{Parent=thing,Action=slot.Action,StringKey=slot.StringKey,StringHash=slot.StringHash,Collider=slot.Collider};
     thing.Interactables=new List<Interactable>(thing.Interactables);thing.Interactables.Add(control);
    }
    control.Parent=thing;control.Initialize();
    ToiletSeating.Register(thing,"_interactableLookup",slot.Action,control);
    slot.Interactable=control;
   }
  }
  internal static Interactable FromSurface(Thing thing,Collider collider,Interactable original)
  {
   if(collider==null||thing is StructureToilet||!ChairSeatRouting.Supported(thing)||thing.Slots==null)return original;
   // Dedicated power, door and other native controls retain their actions.
   if(original!=null&&original.Slot==null)return original;
   var slots=thing.Slots.FindAll(ChairSeatRouting.Supported);if(slots.Count==0)return original;
   var hit=CursorManager.CursorHit;
   var point=hit.collider==collider?hit.point:collider.bounds.center;
   var positions=new Vector3[slots.Count];for(int i=0;i<positions.Length;i++)positions[i]=slots[i].Location.position;
   int index=SeatSelectionPolicy.Nearest(point,positions);if(index<0)return original;
   var control=slots[index].Interactable;
   if(control==null){Ensure(thing);control=slots[index].Interactable;}
   if(control==null)return original;
   // Reuse the visible, raycast-selected furniture surface. Added trigger hitboxes are not required.
   control.Collider=collider;
   if(collider is BoxCollider box)control.Bounds=new Bounds(box.center,box.size);
   else if(collider is MeshCollider mesh&&mesh.sharedMesh!=null)control.Bounds=mesh.sharedMesh.bounds;
   else
   {
    var bounds=collider.bounds;control.Bounds=new Bounds(collider.transform.InverseTransformPoint(bounds.center),bounds.size);
   }
   control.OriginalBounds=control.Bounds;
   return control;
  }
 }
 [HarmonyPatch(typeof(Thing),"GetInteractable",new Type[]{typeof(Collider)})]
 internal static class SeatSurfaceInteractionPatch
 {
  static void Postfix(Thing __instance,Collider __0,ref Interactable __result)
   =>__result=SeatInteractionRouting.FromSurface(__instance,__0,__result);
 }
}
namespace StationEmotes
{
 [HarmonyPatch(typeof(Human),"OnEnterInventory")]
 internal static class AddedFurnitureInteractionPatch
 {
  static void Postfix(Human __instance,Thing __0)
  {
   if(ChairSeatRouting.Supported(__0)&&!(__0 is global::IExitable))
    (__instance.GetComponent<ToiletInteractionState>()??__instance.gameObject.AddComponent<ToiletInteractionState>()).Begin(__instance);
  }
 }
 [HarmonyPatch(typeof(Human),"ExitAnything")]
 internal static class AddedFurnitureExitPatch
 {
  static bool Prefix(Human __instance,ref bool __result)
  {
   var slot=__instance.ParentSlot;
   if(!ChairSeatRouting.Supported(slot)||slot.Parent is StructureToilet||slot.Parent is global::IExitable)return true;
   __result=false;
   if(__instance.LockedToSeat||!ChairSeatRouting.TryExit(__instance,slot,out var point))return false;
   var rotation=ChairSeatRouting.Facing(slot);
   if(Assets.Scripts.Networking.NetworkManager.IsClient)
   {
    Assets.Scripts.NetworkClient.SendToServer(new Assets.Scripts.Networking.MoveToWorldMessage{ChildId=__instance.ReferenceId,Force=0,IsPrecisionPlacement=true,Position=point,Rotation=rotation,Velocity=Vector3.zero,AngularVelocity=Vector3.zero});
    if(!__instance.IsLocalPlayer){__result=true;return false;}
   }
   __result=__instance.MoveToWorld(point,rotation,Vector3.zero,Vector3.zero);return false;
  }
 }
}
