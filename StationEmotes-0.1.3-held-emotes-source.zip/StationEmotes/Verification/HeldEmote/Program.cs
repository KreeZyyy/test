using System;using System.Reflection;using StationEmotes;using UnityEngine;using Assets.Scripts;using Assets.Scripts.GridSystem;using Assets.Scripts.Inventory;using Assets.Scripts.Objects.Entities;using Assets.Scripts.Emotes;
namespace UnityEngine{
 public class MonoBehaviour{}
 public sealed class DefaultExecutionOrder:Attribute{public DefaultExecutionOrder(int i){}}
 public struct Vector3{public float x;public Vector3(float n){x=n;}public float sqrMagnitude=>x*x;public static Vector3 operator-(Vector3 a,Vector3 b)=>new(a.x-b.x);}
 public class Transform{public Vector3 position;}
 public enum AnimatorControllerParameterType{Int}
 public class AnimatorControllerParameter{public int nameHash=7;public AnimatorControllerParameterType type=AnimatorControllerParameterType.Int;}
 public static class Time{public static float unscaledTime;}
 public class AnimationClip{public string name;}
 public struct AnimatorClipInfo{public AnimationClip clip;public float weight;}
 public struct AnimatorStateInfo{public int fullPathHash;public float normalizedTime;}
 public class Animator{public int layerCount;public AnimatorClipInfo[] Clips=Array.Empty<AnimatorClipInfo>();public float Normalized,Played=-1;public int CrossFades;public bool IsInTransition(int l)=>false;public AnimatorClipInfo[] GetCurrentAnimatorClipInfo(int l)=>Clips;public AnimatorStateInfo GetCurrentAnimatorStateInfo(int l)=>new(){fullPathHash=42,normalizedTime=Normalized};public void Play(int hash,int layer,float time){Played=time;}public void CrossFadeInFixedTime(int h,float f,int l,float offset){CrossFades++;}public int Value;public AnimatorControllerParameter[] parameters={new()};public int GetInteger(int h)=>Value;public void SetInteger(int h,int v){Value=v;}}
 public static class Cursor{public static bool visible;}
}
namespace Assets.Scripts.GridSystem{public enum GameState{None,Running}}
namespace Assets.Scripts{public static class GameManager{public static GameState GameState=GameState.Running;}public enum KeyInputState{Game,Other}public static class KeyManager{public static float Forward,Right,Ascend,Descend;public static KeyInputState InputState=KeyInputState.Game;public static float GetForwardAxis()=>Forward;public static float GetRightAxis()=>Right;public static float GetAscend()=>Ascend;public static float GetDescend()=>Descend;}}
namespace Assets.Scripts.UI{public static class InputWindowBase{public static bool IsInputWindow;}}
namespace Assets.Scripts.Objects.Entities{public enum EntityState{Alive,Dead}public class Human{public bool IsBeingDestroyed;public EntityState State=EntityState.Alive;public Transform transform=new();}}
namespace Assets.Scripts.Inventory{public static class InventoryManager{public static Human ParentHuman;}}
namespace Assets.Scripts.Emotes{public enum EmoteType{Body}public struct EmoteData{public int Id;public EmoteData(int id,int duration,EmoteType type){Id=id;}}public class EmoteController{public static int EmoteIndexHash=7;public int Sends;public Action OnSend;public void OnEmote(EmoteData d){Sends++;OnSend?.Invoke();}}}
namespace StationEmotes{public static class Plugin{public const int Cancel=41002;public static Logger Log=new();}public class Logger{public void LogWarning(string s){}}}
class Program{
 static int n;static void Check(bool b,string m){n++;if(!b)throw new Exception(m);}static void Tick(HeldEmote s,string method="Update")=>typeof(HeldEmote).GetMethod(method,BindingFlags.Instance|BindingFlags.NonPublic).Invoke(s,null);
 static void Main(){
 var h=new Human();InventoryManager.ParentHuman=h;var a=new Animator();var c=new EmoteController();var sit=new HeldEmote();
 sit.Begin(h,a,c);Check(sit.Active&&a.Value==3,"sit did not start");for(int i=0;i<2000;i++){Tick(sit);Tick(sit,"LateUpdate");}Check(sit.Active&&a.Value==3,"held sit expired without cancel");
 a.Value=0;Tick(sit,"LateUpdate");Check(a.Value==3,"old emote reset cancelled held sit");
 c.OnSend=()=>sit.Stop(false);KeyManager.Forward=1;Tick(sit);Check(!sit.Active&&a.Value==0&&c.Sends==1,"forward input failed to stop+relay");Tick(sit);Check(c.Sends==1,"duplicate cancel relayed");KeyManager.Forward=0;
 foreach(int axis in new[]{1,2,3}){sit.Begin(h,a,c);if(axis==1)KeyManager.Right=-1;if(axis==2)KeyManager.Ascend=1;if(axis==3)KeyManager.Descend=1;Tick(sit);Check(!sit.Active,"movement axis ignored");KeyManager.Right=KeyManager.Ascend=KeyManager.Descend=0;}
 sit.Begin(h,a,c);a.Value=2;sit.Stop(false);Check(a.Value==2,"stop overwrote another emote");
 sit.Begin(h,a,c);sit.Stop(false);Check(!sit.Active&&a.Value==0,"explicit stop failed");
 var remote=new Human();int sent=c.Sends;sit.Begin(remote,a,c);KeyManager.Forward=1;Tick(sit);Check(sit.Active,"local keys cancelled remote sit");remote.transform.position=new(.2f);Tick(sit);Check(!sit.Active&&c.Sends==sent,"remote movement sent local message");KeyManager.Forward=0;
 sit.Begin(h,a,c);h.transform.position=new(.2f);Tick(sit);Check(!sit.Active&&c.Sends==sent+1,"external local motion failed to relay cancel");
 sit.Begin(h,a,c);h.State=EntityState.Dead;Tick(sit);Check(!sit.Active&&a.Value==0,"death cleanup failed");h.State=EntityState.Alive;
 sit.Begin(h,a,c);GameManager.GameState=GameState.None;Tick(sit);Check(!sit.Active,"world exit cleanup failed");GameManager.GameState=GameState.Running;
 sit.Begin(h,a,c);Tick(sit,"OnDisable");Check(!sit.Active&&a.Value==0,"disable cleanup failed");
 sit.Begin(h,a,c);Tick(sit,"OnDestroy");Check(!sit.Active&&a.Value==0,"destroy cleanup failed");
 a.parameters=Array.Empty<AnimatorControllerParameter>();sit.Begin(h,a,c);Check(!sit.Active,"unsupported animator accepted");
 KeyManager.Forward=1;UnityEngine.Cursor.visible=true;Check(!HeldEmote.MovingLocally(h),"UI typing counted as motion");
 a.parameters=new[]{new AnimatorControllerParameter()};KeyManager.Forward=0;UnityEngine.Cursor.visible=false;
 a.layerCount=1;
 foreach(var pair in new[]{(1,"SaluteR",.6f,.45f),(3,"Sitting",.95f,.85f)}){
  a.Clips=new[]{new AnimatorClipInfo{clip=new AnimationClip{name=pair.Item2},weight=1f}};a.Normalized=pair.Item3;a.Played=-1;
  sit.Begin(h,a,c,pair.Item1);Tick(sit,"LateUpdate");Check(sit.Active&&a.Value==pair.Item1&&Math.Abs(a.Played-pair.Item4)<.001f,"native hold phase incorrect");sit.Stop(false);
 }
 a.Clips=new[]{new AnimatorClipInfo{clip=new AnimationClip{name="wave"},weight=1f}};a.Normalized=.95f;
 sit.Begin(h,a,c,2);Tick(sit,"LateUpdate");Check(sit.Active&&a.CrossFades==1,"wave did not repeat");sit.Stop(false);
 Check(HeldEmotePolicy.TargetTime(2,.3f)==null,"wave interrupted before loop point");
 Check(HeldEmotePolicy.TargetTime(1,.1f)==null,"salute frozen during entry");
 Check(HeldEmotePolicy.TargetTime(1,float.NaN)==null,"invalid animation phase accepted");
 a.Clips=Array.Empty<AnimatorClipInfo>();sit.Begin(h,a,c,1);Time.unscaledTime=4;Tick(sit,"LateUpdate");Check(!sit.Active,"missing animation did not fail closed");
 Console.WriteLine(n+" production HeldEmote checks passed: hold, movement, cancellation, relay scope, timer interference and lifecycle cleanup.");
 }
}
