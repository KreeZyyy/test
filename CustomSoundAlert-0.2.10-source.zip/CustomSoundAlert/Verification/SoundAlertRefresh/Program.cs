using System;using System.Collections.Generic;using CustomSoundAlert;using Assets.Scripts.Objects;using Assets.Scripts.Objects.Clothing;using Assets.Scripts.Objects.Items;
namespace Assets.Scripts.Objects{public class Thing{public bool IsBeingDestroyed,IsCursor;}}
namespace Assets.Scripts.Objects.Clothing{public class SuitBase:Thing{byte id;public bool Powered=true;public byte SoundVolume=42;public int Plays;public byte SoundAlert{get=>id;set{id=value;Plays++;}}}}
namespace Assets.Scripts.Objects.Items{public class AdvancedTablet:Thing{byte id;public bool Powered=true,OnOff=true;public byte SoundVolume=67;public int Plays;public byte SoundAlert{get=>id;set{id=value;Plays++;}}}}
class Program{
 static int n;static void Check(bool b,string m){n++;if(!b)throw new Exception(m);}
 static void Main(){
 var suit=new SuitBase{SoundAlert=100};var tablet=new AdvancedTablet{SoundAlert=101};int initialSuit=suit.Plays,initialTablet=tablet.Plays;var ready=new HashSet<int>();Thing[] hosts={suit,tablet};Check(SoundAlertRefresh.Refresh(hosts,ready.Contains)==0&&suit.Plays==initialSuit&&tablet.Plays==initialTablet,"played before download/registration");ready.Add(100);ready.Add(101);Check(SoundAlertRefresh.Refresh(hosts,ready.Contains)==2,"ready hosts not refreshed");Check(suit.Plays==initialSuit+1&&tablet.Plays==initialTablet+1,"native setters not invoked");Check(suit.SoundAlert==100&&tablet.SoundAlert==101,"authoritative IDs changed");Check(suit.SoundVolume==42&&tablet.SoundVolume==67,"volumes changed");
 foreach(byte id in new byte[]{0,1,45,99,200,255}){var vanilla=new SuitBase{SoundAlert=id};int before=vanilla.Plays;Check(SoundAlertRefresh.Refresh(new Thing[]{vanilla},_=>true)==0&&vanilla.Plays==before,"noncustom/stop replayed");}
 var off=new SuitBase{SoundAlert=100,Powered=false};var tabletOff=new AdvancedTablet{SoundAlert=101,OnOff=false};var tabletUnpowered=new AdvancedTablet{SoundAlert=101,Powered=false};Check(SoundAlertRefresh.Refresh(new Thing[]{off,tabletOff,tabletUnpowered},ready.Contains)==0,"off/unpowered auto-play");var missing=new SuitBase{SoundAlert=199};Check(SoundAlertRefresh.Refresh(new Thing[]{missing},ready.Contains)==0,"unavailable clip replayed");
 var cursor=new SuitBase{SoundAlert=100,IsCursor=true};var destroyed=new AdvancedTablet{SoundAlert=101,IsBeingDestroyed=true};Check(SoundAlertRefresh.Refresh(new Thing[]{cursor,destroyed,null,new Thing()},ready.Contains)==0,"cursor/destroyed/unrelated touched");
 // A failed download is unavailable; the old verified custom sound still resumes.
 Check(SoundAlertRefresh.Refresh(hosts,id=>id==100)==1,"partial-success refresh incorrect");Check(suit.SoundAlert==100&&tablet.SoundAlert==101,"partial-success IDs changed");
 Console.WriteLine(n+" production SoundAlert refresh checks passed: download-before-play, native suit/tablet setters, same IDs/volume, stop/vanilla/off/unpowered/cursor safety and partial availability.");
 }
}
