using System;
using System.Collections.Generic;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Clothing;
using Assets.Scripts.Objects.Items;
namespace CustomSoundAlert
{
    internal static class SoundAlertRefresh
    {
        // A network SoundAlert can arrive while its clip is still downloading.
        // Re-enter the native setter once when registered clips become available,
        // preserving the authoritative ID, volume and native stop/play machinery.
        internal static int Refresh(IEnumerable<Thing> hosts,Func<int,bool> available,Action<string> diagnostics=null)
        {
            int refreshed=0;
            foreach(var host in hosts)
            {
                if(host==null||host.IsBeingDestroyed||host.IsCursor)continue;
                if(host is SuitBase suit)
                {
                    int id=suit.SoundAlert;
                    diagnostics?.Invoke("SoundAlert host "+suit.GetType().Name+": ID="+id+", volume="+suit.SoundVolume+", powered="+suit.Powered+", custom clip ready="+(id>=100&&id<=199&&available(id)));
                    if(suit.Powered&&id>=100&&id<=199&&available(id))
                    {suit.SoundAlert=(byte)id;refreshed++;}
                }
                else if(host is AdvancedTablet tablet)
                {
                    int id=tablet.SoundAlert;
                    diagnostics?.Invoke("SoundAlert host "+tablet.GetType().Name+": ID="+id+", volume="+tablet.SoundVolume+", on="+tablet.OnOff+", powered="+tablet.Powered+", custom clip ready="+(id>=100&&id<=199&&available(id)));
                    if(tablet.OnOff&&tablet.Powered&&id>=100&&id<=199&&available(id))
                    {tablet.SoundAlert=(byte)id;refreshed++;}
                }
            }
            return refreshed;
        }
    }
}
