# Station Emotes 0.1.10

Requires BepInEx and StationeersLaunchPad. Install the StationEmotes folder as a LaunchPad mod. Replace the previous version; do not enable two versions together.

Hold F10, select with the mouse, release to play. F11 or movement ends the active emote. Selecting another emote first cancels the previous one. Esc closes the selection menu only.

Wave loops; Salute and Sit hold the native game animations. Hands up, Point, Robot dance and Meme dance need empty hands. All observing clients need the same mod version; use it on the server too.

Custom poses now run as an AnimationScriptPlayable inside the original Animator graph, after the native controller. The controller and its parameters remain in place. The mod removes only its own animation node on cancel. It does not replace the controller or destroy its graph.

0.1.10 separates pose updates from humanoid-only IK: a generic animation stream no longer drops the entire pose. It checks graph connection success and logs execution count, humanoid frame count and applied bone count after one second. Floor-support failures are logged. The supplied 0.1.9 client log contained successful dance starts and no attachment failure; it did not establish whether the animation job executed. The exact runtime cause remains unconfirmed.

Dance retains animated legs and hips. Unity humanoid IK solves both feet against floor probes. The character root is never translated or rotated by the mod. This is a stationary dance, not the unpublished 0.1.8 walking experiment. Dance stops when ground support is lost. No imported animation clip is included.

F9 records rig and native animation details for diagnosis.

Validation: compilation against the actual game managed DLLs and static assembly checks passed. Live Unity graph insertion, visual foot placement, slopes and multiplayer timing still require an in-game test. IK does not guarantee visually perfect feet on every surface.
