# Custom SoundAlert 0.2.11 — server audio download test

Custom SoundAlert IDs 100–199 for Speakers, Suits and Advanced Tablets. One identical mod for client and dedicated server. Requires StationeersLaunchPad, BepInEx and LaunchPadBooster. Use 0.2.11 on both peers for this transfer test.

Workshop: https://steamcommunity.com/sharedfiles/filedetails/?id=3844423968

## 0.2.11: password visibility on Steam/RocketNet joins and post-world status panel

The native join can hide the main menu canvas before its password prompt is created. This client-only workaround temporarily reveals that existing canvas and hides the loading screen only while the native password prompt is open. Confirm/cancel restore the previous join UI and invoke the original authentication callbacks with the unchanged password. Passwords are never logged. The workaround now covers RocketNet as well as Steam P2P during client joins, and skips an already visible prompt. Dedicated-server UI is unchanged. This addresses a hidden prompt; it does not repair Steam SDK initialization, lobby creation or unrelated transport failures.

Sound requests start only after GameState is Running and the game's loading screen is gone. The status panel uses the game's own Dear ImGui overlay frame instead of Unity OnGUI. It appears after world loading, remains visible during download and decoding, and displays Ready to play after native loading. It does not pause the world or lock player controls. The completion message disappears after 12 seconds. A log line confirms that the panel actually rendered.

## Files outside Workshop

```text
Stationeers/ (or the dedicated server installation)
  BepInEx/
  sounds/                         # your local or server audio
    100_server_test.wav
  CustomSoundAlertData/
    server-cache/                 # downloaded and verified server audio
    .legacy-import-v1             # completed one-time migration
```

The mod resolves the parent of the actual BepInEx folder, independent of the current working directory. Each installation has its own files. Add WAV, OGG or MP3 files named `<id>_<label>.<extension>`, with unique IDs 100–199, to that installation's sounds folder. Restart after editing files. The mod ZIP contains no songs.

## First setup and migration

If the new folders do not exist, the mod creates them. On first launch it copies supported audio from the old sounds folder beside its DLL, and hash-named cache files from the previous application persistent-data cache, into the new locations. If old folders do not exist, the new folders remain empty. Existing destination files are never overwritten, originals are never deleted. A completed migration is marked once so future Workshop bundles cannot repeatedly re-import audio. Failed copies clean temporary files and can retry on restart. Logs show migration counts and absolute paths. Keep the old server sounds folder empty before first migration if you want a vanilla-only server.

Files already manually added beside BepInEx stay untouched. Downloaded sounds go only into server-cache, never into your local sounds folder. Server cache filenames use the manifest's SHA256 and allowed extension; server labels are not used as paths.

## 0.2.11 cyclic selector

The sound screwdriver now wraps in both directions, skipping unassigned slots at either end and between sounds. The preview and action use the same target.

## Tooltip correction

Fixes the reported exception when aiming a screwdriver at the sound selector. The complete sound-selector preview/action now uses a nonempty target name and a safe localized token replacement, avoiding GameString.AsString/String.Format on this path. Missing or malformed templates fall back to a plain Cycle to message; absent source slots return the tool requirement. The native volume button is unchanged.

## Speaker screwdriver selection

The sound selector skips unassigned numeric slots. For example, 45 advances directly to 100 and previous from 100 returns to 45. Gaps between custom IDs are skipped as well, and the Cycle to preview uses the same target. The selector wraps from the last usable entry to the first, and previous from the first to the last. Tool requirements, volume control, numeric IC10 IDs and adjacent selection remain unchanged.

## 0.2.11 password dialog timing

The visibility workaround waits two seconds (using unscaled time) before revealing the existing native password prompt. During that wait the current loading/menu visibility is left unchanged. The native prompt and original authentication callbacks are prepared immediately; no network verification or password processing is replaced. Cancel, disconnect or leaving the join state cancels pending display. Confirmation/cancellation still restores the previous join UI. This delay needs live testing.

## Native SoundAlert registration

Custom clips now set their numeric GameAudioClipsData.SoundAlert before the game's LoadAudioData call. Both native lookups (name hash and SoundAlert ID) must point to the registered data before a clip is counted ready. The prior build exposed IDs via a Harmony lookup while leaving the native ID index empty. Registration now rejects collisions and rolls back partial writes; context cleanup removes only entries still owned by this mod from both native indexes. The existing post-download native setter refresh is retained.

After loading, logs include each suit/tablet's actual SoundAlert value, volume, power/on state and whether its custom clip is registered. This distinguishes missing native registration from an IC10 target/value issue. Download logs also identify transfer sessions, to diagnose any apparent completed-file counter reset. A new regression checks that completed file counts never decrease within one two-file transfer. The reported live counter issue still needs its client log.

## Post-download playback refresh

After all download attempts, verified files are decoded and the shared ID/name catalog is committed again. A SoundAlert value can have arrived on a suit or Advanced Tablet before its file was ready. The client now re-enters the native SoundAlert setter once for an already selected, available custom ID on a powered suit or an on/powered tablet. The ID and volume are preserved, and the normal native stop/play code performs the refresh. Zero, vanilla IDs, unavailable files, off/unpowered devices and construction/destroyed objects are skipped. No extra catalog network message is needed; the ID catalog was already refreshed. The Speaker's existing custom-event and list behavior is unchanged by this correction. Live confirmation is pending.

## Automatic server downloads

After the world join, the client verifies existing server-cache files on a worker task. Missing or corrupt files are requested from the host in 8 KiB chunks. Downloads use one outstanding chunk request per client, a bounded fair server queue and a shared server limit of 256 KiB/s of audio payload with a 32 KiB burst. Actual wire traffic includes Base64/protocol overhead. A chunk times out after 10 seconds and is retried twice before that file fails. Other files can continue after one fails.

The client checks every chunk's size and order, verifies the full byte count and SHA256, then atomically publishes the verified file. Corrupt/incomplete data is never registered for playback. The server serves only its startup catalog's indexed files and refuses sources changed since that snapshot. Client responses are accepted only from the current host and must match the active file's random token, ID and offset.

On-screen messages show checking, downloading, filename, current file number, completed/required file counts, percentage, retry, verification, loading and ready-to-play states. The download phase uses only two lines: `Downloading [1/2] Name: 12%` and `Downloaded files: 0 / 2`. Detailed failures also go to BepInEx/LogOutput.log. The panel remains visible throughout download/loading, then keeps the completion message for 12 seconds. Cancellation/disconnect removes the current partial file; completed cache files persist. An abruptly terminated process can leave an unused .part file, which is never treated as playable audio.

Remote clients use only the server catalog and verified server cache. A private local file with the same ID is never substituted. A server with no custom sounds remains vanilla-only. Rejoining with a valid cache needs no new download. After all download attempts finish, available verified files are loaded and attached using the game's native audio paths. Download completion and ready-to-play are separate notifications.

## Installation and live test

Close the game/server. Extract the common mod ZIP over the existing CustomSoundAlert mod folder; keep a single installed copy. Keep your installation-level sounds and cache directories. No personal audio is bundled. Update both client and server before testing.

1. Leave a short, valid `100_server_test.wav` only in the server's sounds folder; restart the server.
2. Join with the client. Its own local ID 100 may contain a different song; do not copy the server file into local sounds.
3. Expect the server label, download/progress/verified/loading/ready messages, a SHA-named file in server-cache, and playback of the server WAV.
4. Reconnect after a clean game restart. Expect cache verification without another download, and correct playback.
5. Test an empty server separately: no local or cached custom sound should become available.

Users confirmed the earlier build downloaded server audio to the separate cache and played it after a direct IP join. The earlier overlay was not visible; this build changes its rendering path. The post-world panel is now confirmed visible in 0.2.8, showing Ready to play for cached server audio. The expanded password visibility workaround still needs live testing. Synchronizing playback position for late joiners is not implemented. Previously reported freezes/crashes while switching sessions without restarting remain unresolved and are not addressed here. Large songs still consume decoded PCM memory; encoded file limits do not bound decoded memory.

## Verification and limits

Native .NET Framework 4.7.2 API build passes. Production-code fixtures cover 40 transfer cases and 32 network-adapter checks with real temporary files and mocked game/network APIs, including roundtrips, SHA failure, corrupt cache replacement, sender authority, queue/rate limits, ordering, retries, cancellation, UI status and idle allocations. 429 sparse-dial checks cover the actual preview/action patch, both directions, holes, bounds, screwdriver requirements and native control passthrough. 20 join-interface checks exercise the actual password/overlay patches against UI stubs, preserving callbacks, cancellation, exception cleanup and RocketNet/Steam behavior plus DS exclusions. 16 SoundAlert refresh checks cover the production helper and native setter re-entry, same ID/volume, late availability, off/unpowered/stop/vanilla exclusions and partial download success. 16 native registration/cleanup checks execute the real registration helper against an AudioManager stub with native-like indexes, including direct unpatched ID lookup, collision rejection and partial rollback. Storage/migration/catalog/manifest regressions also pass. Live Unity audio decoding, overlay layout, RakNet/Steam transport and multiplayer behavior still require testing.

Catalog bounds: IDs 100–199, at most 100 entries, 32 MiB per source file, 128 MiB source bytes total, 96-character labels and 64 KiB manifest payload. Normal game sounds keep their native handling.

## Credits

Inspired by Sovana122: https://github.com/Sovana122/Sationeers-CustomSound/tree/speaker
Original license and attribution are preserved in LICENSE-Sovana.txt. Matching source and verification fixtures are provided separately.

Live 0.2.10 feedback: SoundAlert playback works after first download and password entry works. User requested only a two-second visibility delay for the next build; native audio/download behavior is retained.
