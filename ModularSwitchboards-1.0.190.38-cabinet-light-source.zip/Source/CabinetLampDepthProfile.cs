namespace ModularSwitchboards
{
    // One-sided casing and diffuser extension; keep front edges and thin inlet fixed.
    internal static class CabinetLampDepthProfile
    {
        private static float Clamp(float value)=>value<0?0:value>1?1:value;
        internal static float Extend(float z,float nativeY,bool medium,bool surface,float coverFront)
        {
            if(!medium||!surface)return z;
            float shoulder=Clamp((nativeY-.13f)/.003f);
            float rearWeight=Clamp((.145f-z)/.012f);
            float rear=coverFront+.032f-.014f;
            return z+(rear-z)*rearWeight*shoulder;
        }
    }
}
