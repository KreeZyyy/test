import bpy,json,sys,struct
from pathlib import Path
from mathutils import Vector,Matrix
args=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else []
if not args:raise SystemExit('Pass geometry JSON exported by Verification/DinLogicOwn')
r=Path(__file__).resolve().parents[1];out=Path('/tmp/ownlogic-preview202');out.mkdir(exist_ok=True);data=json.loads(Path(args[0]).read_text());bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
def mat(name,color,metal=0):
 m=bpy.data.materials.new(name);m.diffuse_color=(*color,1);m.use_nodes=True;p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*color,1);p.inputs['Roughness'].default_value=.65;p.inputs['Metallic'].default_value=metal;return m
black=mat('Own black front',(.018,.021,.024));grey=mat('Own grey frame',(.16,.17,.18));white=mat('Own white print',(.72,.75,.73));slot=mat('Own black slot',(.003,.004,.005));silver=mat('Own contact metal',(.31,.35,.35),.6);red=mat('Reference red status',(.48,.009,.004));body=mat('DIN white shell',(.62,.66,.65));rail=mat('DIN rail',(.22,.25,.26),.5);back=mat('Mounting plate',(.09,.11,.12));palette=[black,grey,white,slot,silver]
def mesh(name,dump,pos,mats):
 vs=[(pos[0]-v[0],pos[1]+v[1],pos[2]+v[2]) for v in dump['vertices']];ts=[];slots=[]
 for j,group in enumerate(dump['triangles']):
  for i in range(0,len(group),3):ts.append([group[i],group[i+2],group[i+1]]);slots.append(j)
 m=bpy.data.meshes.new(name);m.from_pydata(vs,[],ts);m.update();o=bpy.data.objects.new(name,m);bpy.context.collection.objects.link(o)
 for material in mats:m.materials.append(material)
 for p,s in zip(m.polygons,slots):p.material_index=s
 return o

def box(name,p,size,material,bevel=0):
 bpy.ops.mesh.primitive_cube_add(size=1,location=p);o=bpy.context.object;o.name=name;o.dimensions=size;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.append(material)
 if bevel:mod=o.modifiers.new('Rounded own casing','BEVEL');mod.width=bevel;mod.segments=3;o.modifiers.new('Own normals','WEIGHTED_NORMAL')
 return o
def output_selector():
 b=(r/'Assets/HousingAddressScrew.meshbin').read_bytes();count,groups=struct.unpack_from('<ii',b);points=[struct.unpack_from('<5f',b,8+20*i)[:3] for i in range(count)];lo=[min(v[i] for v in points) for i in range(3)];hi=[max(v[i] for v in points) for i in range(3)];scale=.0096/max(hi[0]-lo[0],hi[1]-lo[1]);vertices=[[(v[0]-(lo[0]+hi[0])/2)*scale,(v[1]-(lo[1]+hi[1])/2)*scale,(v[2]-lo[2])*scale] for v in points];offset=8+count*20;triangles=[]
 for i in range(groups):
  n=struct.unpack_from('<i',b,offset)[0];offset+=4;triangles.append(list(struct.unpack_from('<'+'i'*n,b,offset)));offset+=4*n
 return {'vertices':vertices,'triangles':triangles}
selector=output_selector()
font=bpy.data.fonts.load('/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf')
def label(value,p,width,height,ink):
 curve=bpy.data.curves.new('Smart-style print','FONT');curve.body=value;curve.align_x='CENTER';curve.align_y='CENTER';curve.font=font
 ob=bpy.data.objects.new('Smart-style print',curve);bpy.context.collection.objects.link(ob);ob.location=p;curve.materials.append(ink);bpy.context.view_layer.update();factor=min(width/max(ob.dimensions.x,.00001),height/max(ob.dimensions.y,.00001));ob.scale=(factor,factor,factor);ob.visible_shadow=False;return ob
for i,d in enumerate(data):
 before=set(bpy.data.objects);x=(i%4-1.5)*.119;y=.084 if i<4 else -.084
 mesh('DIN shared housing',json.loads(Path(args[1]).read_text()),(x,y,0),[body]*5)
 box('DIN shoulder',(x,y,.06785),(.0801,.0702,.0092),body,.0015)
 front=dict(d['front']);front['vertices']=[[v[0]*.86,v[1]*.80,.04124+v[2]*.42] for v in front['vertices']];mesh(d['native'],front,(x,y,0),palette)
 name=d['native'].replace('StructureLogic','');name=name.replace('BatchSlot','Batch Slot').replace('BatchReader','Batch\nReader').replace('BatchWriter','Batch\nWriter').replace('SlotReader','Slot\nReader').replace('ReagentReader','Reagent\nReader')
 if name in ['Reader','Writer','Mirror']:name='Logic\n'+name
 label(name,(x,y,.07465),.052,.019,white)
 for p in d['poses']:
  led=p['action']==36;mesh('Own diode' if led else 'Output selector',d['lens'] if led else selector,(x-p['x']*.86,y+p['y']*.64,.0748),[red]*5 if led else [silver]*5)
  if not led:label(p['label'],(x-p['x']*.86,y+p['y']*.64+(.0073 if p['y']>0 else -.0073),.07465),.016,.0044,white)
 for pin in range(3):
  px=x+(-.018 if pin==0 else .018 if pin==1 else 0);py=y+(.042 if pin==2 else -.042);box('Shared cable screw',(px,py,.066355),(.02025,.01215,.001725),silver,.0006);box('Shared cable slot',(px,py,.06739),(.0135,.00135,.000575),slot,.00015)
  for radius,delta,material in [(.0042,.000135,silver),(.0032,.00027,slot)]:
   bpy.ops.mesh.primitive_circle_add(vertices=16,radius=radius,fill_type='NGON',location=(px,y+(.050625+delta if pin==2 else -.050625-delta),.03335),rotation=(1.57079632679 if pin==2 else -1.57079632679,0,0));ob=bpy.context.object;ob.name='Shared round cable entry';ob.data.materials.append(material)
 for ob in set(bpy.data.objects)-before:
  ob['variant']=i
  if ob.type=='MESH' and not ob.name.startswith(('DIN shared housing','DIN body','DIN shoulder','StructureLogic')):ob.visible_shadow=False
for y in [-.084,.084]:box('Rail',(0,y,-.008),(.48,.026,.014),rail,.001)
box('Plate',(0,0,-.025),(.54,.34,.018),back,.003)
world=bpy.context.scene.world;world.use_nodes=True;world.node_tree.nodes['Background'].inputs[0].default_value=(.18,.20,.22,1);world.node_tree.nodes['Background'].inputs[1].default_value=.5
for loc,power,size in [((-.3,.4,.65),4,.5),((.5,-.1,.45),2,.4)]:
 bpy.ops.object.light_add(type='AREA',location=loc);ob=bpy.context.object;ob.data.energy=power;ob.data.size=size;ob.rotation_euler=(-ob.location).to_track_quat('-Z','Y').to_euler()
bpy.ops.object.camera_add();cam=bpy.context.object;cam.data.type='ORTHO'
def camera(pos,target,scale):
 pos=Vector(pos);fw=(Vector(target)-pos).normalized();rt=fw.cross(Vector((0,1,0))).normalized();up=rt.cross(fw).normalized();cam.matrix_world=Matrix([[rt.x,up.x,-fw.x,pos.x],[rt.y,up.y,-fw.y,pos.y],[rt.z,up.z,-fw.z,pos.z],[0,0,0,1]]);cam.data.ortho_scale=scale
sc=bpy.context.scene;sc.camera=cam;sc.render.engine='CYCLES';sc.cycles.samples=24;sc.cycles.use_denoising=False;sc.render.resolution_x=1400;sc.render.resolution_y=900;sc.render.resolution_percentage=100;sc.view_settings.view_transform='Standard';sc.render.image_settings.file_format='PNG';camera((.015,.17,.9),(0,0,.01),.58);sc.render.filepath=str(out/'DIN-Logic-IO-own-models.png');bpy.ops.wm.save_as_mainfile(filepath=str(out/'DIN-Logic-IO-own.blend'));bpy.ops.render.render(write_still=True)
sc.cycles.samples=16;sc.render.resolution_x=192;sc.render.resolution_y=192;sc.render.film_transparent=True
for i,d in enumerate(data):
 for ob in bpy.data.objects:
  if ob.type=='MESH':ob.hide_render=ob.get('variant',-1)!=i
 x=(i%4-1.5)*.119;y=.084 if i<4 else -.084;camera((x+.008,y+.025,.4),(x,y,.04),.125);sc.render.filepath=str(out/(d['native'].replace('StructureLogic','DinLogic')+'.png'));bpy.ops.render.render(write_still=True)
