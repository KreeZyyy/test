using UnityEngine;
namespace ModularSwitchboards {
 internal static class DinLogicFaceLayout {
  internal const float OriginZ=.04124f,ScaleX=.86f,ScaleY=.80f,ScaleZ=.42f,ControlZ=.0748f,PrintZ=.07465f,ControlScaleY=.64f;
  internal static float LabelY(float y)=>y*ControlScaleY+(y>0?.0073f:-.0073f);
  internal static bool LabelVisible(int action)=>action!=36;
  internal static Vector3 Scale=>new Vector3(ScaleX,ScaleY,ScaleZ);
 }
}
