## 1.0.202 — Smaller inset chip, raised pins and larger controls

The chip and its side contacts are 14% narrower and about 15% shorter than 1.0.201, leaving more visible Output fascia around all four sides. Its mesh thickness increases from 0.18 to 0.42 of the authored depth, while its back stays seated at 72.32 mm. The black chip front is at 74.42 mm; side contacts stand proud up to 75.51 mm. Only the solid chip and housing cast/receive shadows; text and setting details do not project glyph shadows.

The existing Output selector head grows from 6.4 to 9.6 mm, with its original model and UVs retained. Own click boxes grow to 11 × 11 × 8 mm. Controls move inward with the chip, stay separate and remain bound to the same native actions. LED lens/controller/materials are unchanged; it follows the inward control layout. The Output casing, three cable terminals, cable-entry coordinates, network roles and saved wiring stay unchanged.

White setting text grows from 3.5 to 4.4 mm high, with row labels placed toward the outer top/bottom edges to leave the title clear. The title fitting area grows to 52 × 19 mm. The ON text and cable screw labels remain absent. Native colour/atlas restoration from 1.0.201 is retained.

Validation: 876 authored geometry/control/closed-casing/inset-chip/label-spacing checks; palette/helper/shadow fixture and compiled native/Output/font contracts; native build. Authoring preview updated across eight variants. Full native material lighting, actual dynamic font sizing and clicks still need a live client check.

## 1.0.201 — Output body, bare chip and actual Output setting selectors

DIN Logic now calls SmartContactorModel.Body(noTerminals:true), the actual two-position Output casing factory. Its default Output behavior is unchanged. The separate authored grey bezel is removed: only the black chip body and its side pins sit on the fascia. Existing top POWER and two bottom IN/OUT cable screws/round entries retain their established positions and roles.

Setting controls reuse HousingAddressScrew.Build, the exact existing Output selector resource, fitted to a 6.4 mm control head with its original UVs/material surface retained. This follows the user's explicit request to use the same Output model; no new game chip/front import is added. Own click boxes remain bound to the original native selector actions. The authored status LED lens, native status material/controller, location and click action are unchanged.

The ON label and cable screw labels (IN / OUT / PWR) are removed. IN, VAR and other setting labels are white, larger (up to 16 × 3.5 mm), and use the same bold font pipeline as Output. Text restore clears inherited property blocks and restores serialized intended colour plus white/emissive Output-style ink after Awake/native refresh; dark terminal labels use separate ink. This addresses the black text seen in the user's 1.0.200 screenshot. Output selector material snapshots are also restored after cloning/paint.

Validation: native build with zero warnings/errors; 728 own chip/control/layout checks; 320 palette/helper regression checks; 132 compiled Output body/selector/text restoration, inheritance/save/join/wiring contracts. Real game font colour, model material appearance, click alignment and lighting require client validation. Authoring preview shows geometry and approximate materials, not the native texture atlas.

## 1.0.200 — Match the existing Output/Core design

DIN Logic retains the established two-position DIN body, but its authored chip fascia is now seated against the Output/Core front plane. The former full-depth extra bezel is compressed to a shallow trim; controls follow the new front depth and scaled panel height, and bounds shrink accordingly. Layout checks keep the bezel touching the housing, its front below 73.7 mm and control tips below 77 mm.

Cable terminals now use DinBreakerModel.CableTerminal, which calls the same TerminalScrew primitive used by the ordinary Core/Output DIN housing. Their dimensions, rounded edges and black slots match those modules. Round 16-segment grey/black cable entry disks use the same EndDisk primitive and 4.2/3.2 mm radii as the original DIN entries. Both are generated before the native UV/tangent pass. Existing pin centres, separate data/power roles, cable routing and saved-wire migration remain unchanged; click targets follow the full-size terminal heads.

The pixel title/control labels are no longer emitted on the panel. Logic and Smart NET/Output now share SmartModuleFont.Get: the same built-in font selection, bold weight and depth-tested font atlas rendering. Logic prints title-case function names, selectors and IN/OUT/PWR using its own TextMesh objects. A shared white ink material preserves black/white vertex colours and follows dynamic font atlas rebuilds. Label fit dimensions serialize into Unity clones and are reapplied when glyph bounds become ready. No original game chip mesh or click collider is imported.

Validation: native build, 690 geometry/control/closed-casing/flush-layout checks, 320 palette/helper/round-entry checks with correct black shared screw slots, and 127 compiled shared-font/terminal/native/save/wiring contracts. Authoring previews use a metrically compatible bold sans-serif; actual Unity font rendering, final fascia depth, shadows and clicking still need live client verification.

## 1.0.199 — Reuse the clean battery-holder casing for DIN Logic

Removes the custom post-build socket cutter added in 1.0.198. Its Mesh.Clear erased the UV/tangent channels generated by the shared casing builder, producing the coloured atlas fragments visible on end faces in the game. The earlier geometry tests and Blender preview checked positions/colours but did not expose the missing native atlas UVs.

DinLogicHousing.Build now directly calls the same established DinBreakerModel builder and DinBatteryLayout dimensions used by our two-position battery holder, with a closed face, plain top and no spindle or generic terminal decorations. No mesh edits run after its native UV/tangent generation. Our own chip panel, lettering, screw controls, LED and click colliders remain mounted on the front. The battery socket, battery item and native battery models are not imported or installed.

Cable entry marks sit just outside the clean end faces; the additional socket liners and destructive openings are removed. Bottom-left IN0, bottom-right OUT1, top-centre POWER2, small terminal screws, route escape and saved data-wire migration remain as in 1.0.198. Native functions and wiring identities are unchanged.

Validation: native build with zero warnings/errors; 656 actual authored geometry/control/cache/layout/closed-casing checks; 118 compiled native/wiring/shared-casing contracts, including direct reuse of the established factory, no post-build geometry rewrite/cutter and retained native UV generation. Palette/helper code is unchanged from the 308 checks in 1.0.198. Authoring preview/icons updated; native textured game rendering still requires client verification.

## 1.0.198 — DIN Logic terminal alignment, own small helpers and shadows

All eight variants use bottom-left DATA IN (index 0), bottom-right DATA OUT (index 1), and one centred top POWER (index 2). Positive local X is viewer-left. Screw heads are now 7 × 6 mm; their smaller click boxes remain aligned with cable targets. IN / OUT / PWR markings sit on the white shoulders. A shared terminal layout drives screw centres, cable entries, socket cut-outs, and route escape direction. The old generic central end disks are suppressed with `noTerminals`. Actual 9 mm square openings are clipped from our end faces, with recessed black backs and liners; there are no extra fake holes.

Only the housing casts and receives shadows. The panel, glyphs, pads, controls, LED and terminal details no longer project tiny text/contact silhouettes onto the cabinet. Hidden copied cursor renderers explicitly stop casting shadows as well.

The existing native helper renderer/reference and port metadata stay intact, but its mesh is replaced by our own 12 mm arrow, with its tip at the exact cable entry. It is re-fitted after native placement updates, compensates for parent scale, suppresses extra helper child renderers, and casts no shadows. This removes reliance on the native arrow's bounds and pivot. Non-mesh helpers are hidden safely while retaining the native reference.

Moved saved DIN cable endpoints join the existing atomic rerouting check. Rerouting now preserves the LogicData flag (previously omitted from the copied wire record), alongside connections, cable type, colour, quantity and damage state. Routing failure retains the complete old wiring and reports manual rewiring, as before. Native selector actions, ticks, save/network contracts and pin identities remain unchanged.

Validation: native build with zero warnings/errors; 656 own geometry/control/cache/layout/socket checks; 308 palette/helper/shadow checks; 113 compiled native and moved-wire contracts. Updated tooltips, wiring labels and F1 help match the terminal layout. Updated own-model preview and eight icons. Blender is an authoring preview; real game placement arrows, shadows, cable migration and interactions still require client validation. Previous network/service regressions are carried forward, not claimed as freshly rerun.

## 1.0.197 — Restore DIN Logic role colours and fit cursor helpers

Fixes the blue, indistinguishable DIN Logic fronts reported from 1.0.196. Unity cloning does not retain MaterialPropertyBlocks, and the native colour writer was treating the whole authored model as a paintable unit. Only the housing now enters that native renderer list; native paint-cache discovery is disabled for the DIN Logic types. Restore our own per-role palette after native Awake, renderer registration and colour/material refresh, with a throttled fallback refresh. White casing/lettering, black face/recesses and grey screw/contact metal stay distinct. LED blocks are cleared without replacing the native state material, so its normal/error colours remain under native logic control.

Cursor helpers for these eight modules keep their original references, roles and types but are normalized to 18 mm and placed at the exact own terminal anchors. Native helper grid snapping no longer spreads the arrows away from the DIN body. Other game/cabinet helpers are unchanged.

Validation: native build; actual palette/helper source fixtures covering missing clone blocks, native blue tint, repeat restoration, untouched LED materials/unowned objects, exact anchors and stable 18 mm scaling; compiled native/control/save/join/collider ordering checks. Actual game rendering still needs confirmation. Own geometry/colliders and previous startup fixes are retained.

## 1.0.196 — Own DIN Logic models and interaction colliders

Replaces the imported native Logic I/O fronts with our own procedural panel, side pads, 5x7 lettering, hex screw heads and twelve-sided LED lens on the existing two-position DIN housing. Native geometry and original hitboxes are not retained. All clickable targets are newly created box/sphere colliders. Reference measurements are rounded to millimetres and colour/state references are used for consistency; the finished model contains our generated vertices only.

Original action IDs, native logic classes, state handling, save/network payloads and 10 W wiring behavior remain. New interactables bind our colliders to the existing actions. A fresh native state controller drives our LED renderer; no original control GameObject survives. No native face mesh resources or extraction code are compiled into the game DLL. Eight new icons match the authored models.

Fixes the cursor Awake collision failure: fitted-body replacement now removes the deleted box from all three collision caches as well as build-state lists and lookup. Each DIN Logic instance/cursor starts native Awake with fresh cache lists so native CacheColliders appends only the current hierarchy. This preserves real native collision handling rather than suppressing its exception. The 1.0.195 null-slot/isolated-kit fix remains.

Validated: native build, own geometry/hitbox separation and bounds, cursor/instance cache append simulations, compiled native inheritance/save/join and reset-before-Awake order. Full live-game placement, clicking and status changes still need testing.

Authoritative geometry: Source/DinLogicFrontGeometry.cs and RoundedGeometry.cs. Control positions/actions: Source/DinLogicControlLayout.cs (rounded reference measurements, not geometry). Own components/colliders and native logic wiring: DinLogicModel.cs. No native mesh arrays are imported or embedded for these eight variants.

Verification/DinLogicOwn links actual builders and ThingColliderCache; it exports an own-geometry JSON with no game geometry input. Render that JSON with Tools/render_din_logic.py. The Blender preview and icons use that export and are not game screenshots.
