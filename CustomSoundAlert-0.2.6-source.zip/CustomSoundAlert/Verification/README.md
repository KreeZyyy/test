# Verification

Requires .NET SDK 8. Run each fixture with `dotnet run --project <path> -c Release`:

- `source/tests/Check.csproj`: 16 custom alert ID checks.
- `Verification/Catalog/Check.csproj`: 58 shared enum/catalog checks.
- `Verification/Manifest/Check.csproj`: 128 manifest/cache checks using temporary files.
- `Verification/Cleanup/Check.csproj`: actual ReleaseClips body, 8 cleanup checks against native API stubs.
- `Verification/Performance/Check.csproj`: actual Update/IsReady bodies against API stubs, 100,000 stable updates and 200,000 ownership lookups, no managed allocations in the measured loops.

Performance/ExtractedUpdate.cs is copied from Plugin.cs between `void Update()` and `IEnumerator Load(`. Cleanup/ExtractedCleanup.cs is copied between `static void ReleaseClips()` and `bool loading;`. Refresh these files after implementation changes. Fixtures model Unity null/destroyed behavior but are not a live Unity runtime or an FPS benchmark. RESULTS.txt records this build's results.

- `Verification/EmptyServer/Check.csproj`: executes actual Configure/Serialize/Deserialize and RefreshCatalogContext using networking/Unity stubs. Creates a missing server sounds folder, publishes an empty manifest, exercises MP waiting/empty/reconnect/SP role restoration and verifies private file bytes. The actual local audio reload remains a live game check. ExtractedContext.cs is copied from Plugin.cs between RefreshCatalogContext() and float nextCheck.

- `Verification/Storage/Check.csproj`: 12 filesystem checks for missing-directory setup, destination preservation and independent installations.
- `Verification/Migration/Check.csproj`: 13 checks for nonoverwriting legacy import, source preservation, cache separation, missing old folders, once-only behavior and failure retry.
- `Verification/Transfer/Check.csproj`: 34 checks executing production downloader/file server against real files, including verified transfer, cache reuse/repair, SHA mismatch, stale/order/duplicate messages, cancellation, bounded timeout retry, bad chunks/offsets/IDs, source changes, empty catalog and one-file failure continuation.
- `Verification/TransferNetwork/Check.csproj`: 28 checks executing the actual network adapter and wire message classes against game API stubs: registration, serialization, malformed data, peer authority, queue caps, rate budget, zero idle allocations, full client completion, GUI message and cancellation.

The cache downloader and adapter tests compile real production code; they do not launch Unity, the real network transport or audio decoder. Live verification remains necessary. Read RESULTS.txt for this build. Source build requires UnityEngine.IMGUIModule in addition to the existing dependencies.

- `Verification/SparseDial/Check.csproj`: 423 checks for production ModeCatalog.Step and extracted SparseDialPatch; native API stubs cover dry-run tooltip, actual interaction, wrong tools, reverse, untouched volume, safe adjacent vanilla selection, null/malformed localization templates and absent source slot. ExtractedDial.cs copies the InteractWith patch body from Plugin.cs; its Prefix visibility is changed only to invoke it from the fixture.
