using System;using System.Collections.Generic;using System.Reflection;using StationEmotes;using UnityEngine;using Assets.Scripts.Objects;using Assets.Scripts.Objects.Entities;using Objects.Structures;
class Check{
 static int n;static void A(bool b,string m){n++;if(!b)throw new Exception(m);}
 static bool Near(float a,float b)=>Math.Abs(a-b)<.0001f;
 static bool Run(Human h,Slot slot,ref bool result){object[] args={h,slot,result};var answer=(bool)typeof(ToiletSeatPreparationPatch).GetMethod("Prefix",BindingFlags.NonPublic|BindingFlags.Static).Invoke(null,args);result=(bool)args[2];return answer;}
 static void Main(){
 foreach(float pivot in new[]{0f,.5f,1f})foreach(float scale in new[]{.5f,1f,2f}){
 var toilet=new StructureToilet();toilet.transform.position=new Vector3(10,128+pivot,20);toilet.transform.localScale=new Vector3(scale,scale,scale);
 var slot=new Slot{Parent=toilet,Location=new Transform{parent=toilet.transform}};toilet.Seat=slot;
 toilet.Interactables.Add(new Interactable{Action=InteractableType.Activate,Collider=new Collider{bounds=new Bounds(new Vector3(10.1f,128.6f,20.2f),Vector3.one)}});
 var h=new Human();h.transform.position=new Vector3(10,128,21);var source=h.transform.position;
 ChairFloorProbe.Found=true;ChairFloorProbe.Height=128;bool result=true;
 A(Run(h,slot,ref result),"valid floor rejected");
 A(Near(slot.Location.position.y,128),"toilet pivot still raises entity origin");
 A(Near(slot.Location.position.x,10.1f)&&Near(slot.Location.position.z,20.2f),"anchor not centred on original bowl control");
 A(Near(slot.Location.lossyScale.y,1),"toilet parent scales native seated avatar");
 A(Near(slot.Location.position.y+.42f*slot.Location.lossyScale.y,128.42f),"native seated pelvis remains floating above normal rim height");
 A((h.transform.position-source).sqrMagnitude==0&&h.ParentSlot==null,"preparation moved actor before source pose capture");
 A(ChairFloorProbe.LastDepth==3.5f&&float.IsNaN(ChairFloorProbe.LastExpected),"floor lookup used actor/pivot tolerance");
 }
 var t=new StructureToilet();var s=new Slot{Parent=t,Location=new Transform{parent=t.transform}};t.Seat=s;var human=new Human();bool ok=true;
 ChairFloorProbe.Found=false;A(!Run(human,s,ref ok)&&!ok,"missing floor falls back to floating native teleport");
 ChairFloorProbe.Found=true;t.transform.localScale=new Vector3(1,0,1);ok=true;A(!Run(human,s,ref ok)&&!ok,"invalid parent scale accepted");
 s.Occupant=new Human();int calls=ChairFloorProbe.Calls;A(Run(human,s,ref ok)&&ChairFloorProbe.Calls==calls,"occupied actor anchor moved");s.Occupant=null;
 var ordinary=new Slot{Parent=new Thing(),Location=new Transform()};A(Run(human,ordinary,ref ok),"normal chair entry intercepted by toilet preparation");
 A(FlatBenchPolicy.Matches("StructureSeatBenchFlat","",""),"native flat prefab not recognised");
 A(FlatBenchPolicy.Matches("Other","Other","Bench (Flat)"),"reported flat bench not recognised by display name");
 A(!FlatBenchPolicy.Matches("StructureSeatBenchAngled","","Bench (Angled)"),"angled bench misclassified");
 A(!FlatBenchPolicy.Matches("StructureSeat","","Chair"),"normal chair misclassified");
 var flat=new Thing{PrefabName="StructureSeatBenchFlat",DisplayName="Bench (Flat)"};
 var nativeSlot=new Slot{Parent=flat,Location=new Transform{position=new Vector3(0,128,0)}};
 human.transform.position=new Vector3(0,128,-.5f);human.GroundChecks=0;
 A(ChairTransition.InFront(human,nativeSlot)&&human.GroundChecks==0,"flat bench still blocked by ordinary front/ground test");
 A(nativeSlot.Location.position.z==0,"flat access moved original native slot");
 nativeSlot.Parent=new Thing{PrefabName="StructureSeatBenchAngled"};
 A(!ChairTransition.InFront(human,nativeSlot)&&human.GroundChecks==1,"ordinary chair eligibility was removed too");
 A(!ChairEndpointPolicy.Blocks(1,0,true),"inactive layer still prevents native capture");
 A(!ChairEndpointPolicy.Blocks(1,.005f,true),"negligible layer still prevents native capture");
 A(ChairEndpointPolicy.Blocks(0,0,true),"base layer transition ignored");
 A(ChairEndpointPolicy.Blocks(1,1,true),"active upper layer transition ignored");
 A(!ChairEndpointPolicy.Blocks(0,1,false),"stable base layer blocked");
 Console.WriteLine(n+" production toilet preparation/pivot/scale and flat-bench/readiness checks passed (game/math stubs).");
 }}
namespace UnityEngine{
 public struct Vector3{public float x,y,z;public Vector3(float a,float b,float c){x=a;y=b;z=c;}public static Vector3 one=>new Vector3(1,1,1);public static Vector3 up=>new Vector3(0,1,0);public static Vector3 forward=>new Vector3(0,0,1);public static float Dot(Vector3 a,Vector3 b)=>a.x*b.x+a.y*b.y+a.z*b.z;public static Vector3 Cross(Vector3 a,Vector3 b)=>new Vector3(a.y*b.z-a.z*b.y,a.z*b.x-a.x*b.z,a.x*b.y-a.y*b.x);public float sqrMagnitude=>x*x+y*y+z*z;public static Vector3 operator -(Vector3 a,Vector3 b)=>new Vector3(a.x-b.x,a.y-b.y,a.z-b.z);public string ToString(string s)=>x+","+y+","+z;}
 public struct Quaternion{public static Vector3 operator *(Quaternion q,Vector3 v)=>v;}
 public class Transform{
 public Vector3 position,localScale=Vector3.one;public Transform parent;
 public Vector3 lossyScale=>parent==null?localScale:new Vector3(parent.lossyScale.x*localScale.x,parent.lossyScale.y*localScale.y,parent.lossyScale.z*localScale.z);
 public Vector3 TransformPoint(Vector3 p)=>new Vector3(position.x+p.x*lossyScale.x,position.y+p.y*lossyScale.y,position.z+p.z*lossyScale.z);
 }
 public struct Bounds{public Vector3 center,size;public Bounds(Vector3 c,Vector3 s){center=c;size=s;}}
 public class Collider{public Bounds bounds;}
 public static class Mathf{public static float Abs(float x)=>Math.Abs(x);public static float Max(float a,float b)=>Math.Max(a,b);}
}
namespace HarmonyLib{
 public class HarmonyPriority:Attribute{public HarmonyPriority(int value){}}
 public static class Priority{public const int First=800;}
}
namespace Assets.Scripts.Objects{
 public enum InteractableType{Activate}
 public class Thing{public string PrefabName,name,DisplayName;public Transform transform=new Transform();public Transform ThingTransform=>transform;}
 public class DynamicThing:Thing{}
 public class Slot{public Thing Parent;public Transform Location;public Human Occupant;public Human Get()=>Occupant;}
 public class Interactable{public InteractableType Action;public Collider Collider;}
}
namespace Assets.Scripts.Objects.Entities{public class Human:DynamicThing{public Slot ParentSlot;public int AllButPlayerImmune,GroundChecks;public bool IsGrounded(int mask,float distance){GroundChecks++;return false;}}}
namespace Objects.Structures{public class StructureToilet:Thing{public Slot Seat;public List<Interactable> Interactables=new List<Interactable>();}}
namespace StationEmotes{
 internal struct ChairFloorContact{public Vector3 Point;}
 internal static class ChairFloorProbe{
 public static bool Found;public static float Height,LastDepth,LastExpected;public static int Calls;
 public static bool Try(Vector3 p,StructureToilet t,Human h,float expected,out ChairFloorContact floor,float depth){Calls++;LastDepth=depth;LastExpected=expected;floor=new ChairFloorContact{Point=new Vector3(p.x,Height,p.z)};return Found;}}
 internal static class Plugin{public static LogStub Log=new LogStub();}
 internal class LogStub{public void LogWarning(string s){}public void LogInfo(string s){}}
}

namespace StationEmotes{internal static class ChairSeatRouting{public static Quaternion Facing(Slot slot)=>new Quaternion();}}
