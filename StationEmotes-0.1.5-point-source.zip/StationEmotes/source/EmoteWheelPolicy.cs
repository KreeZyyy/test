using System;
namespace StationEmotes
{
    internal static class EmoteWheelPolicy
    {
        // Five equal sectors, clockwise from top. Labels share this count.
        internal const int Count=5;
        internal static int Select(float x,float y)
        {
            if(float.IsNaN(x)||float.IsNaN(y)||float.IsInfinity(x)||float.IsInfinity(y)||x*x+y*y<35f*35f)return -1;
            double angle=(Math.Atan2(y,x)*180.0/Math.PI+90.0+360.0)%360.0;
            return ((int)Math.Floor((angle+36.0)/72.0))%Count;
        }
    }
}
