using System.Collections;
using System.Linq;
using HarmonyLib;
using LibConstruct;
namespace ModularSwitchboards
{
    internal static class RailBoardLoadOrder
    {
        // FinishLoad iterates pending boards without a parent-before-child guarantee.
        // Resolve pending rail hosts before any module grid coordinates are applied.
        internal static void BeforeFinishLoad()
        {
            var refs=(IDictionary)AccessTools.Field(typeof(PlacementBoard),"LoadingRefs").GetValue(null);
            foreach(var reference in refs.Values)
            {
                var contract=reference.GetType().GetInterfaces().First(t=>t.Name=="IBoardRef");
                var board=(PlacementBoard)contract.GetProperty("Board").GetValue(reference,null);
                if(!(board?.PrimaryHost is SwitchboardCabinet cabinet))continue;
                var waiting=(IEnumerable)AccessTools.Field(typeof(PlacementBoard),"AwaitingRegister").GetValue(board);
                foreach(var item in waiting)
                    if(AccessTools.Field(item.GetType(),"Structure").GetValue(item) is DinRail rail)
                        DinRailModel.Resize(rail,cabinet.PrefabName);
            }
        }
    }
}
