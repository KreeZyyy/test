using System.Collections.Generic;
using System.Linq;
using Assets.Scripts.Networks;
using Assets.Scripts.Objects.Electrical;
using Assets.Scripts.Objects.Pipes;
namespace ModularSwitchboards
{
    internal static class ModuleNetworkRegistration
    {
        // Native AddDevice already notifies every device and dirties the lists.
        // Do not add unchanged registrations or repeat those notifications.
        internal static void Synchronize(CableNetwork network,Device module,IEnumerable<Cable> cables)
        {
            var wanted=new HashSet<Cable>(cables);
            bool added=false,removed=false;
            foreach(var cable in wanted)
                if(network.GetDeviceRegistration(module)?.Contains(cable)!=true)
                {network.AddDevice(cable,module);added=true;}
            var current=network.GetDeviceRegistration(module);
            if(current!=null)foreach(var stale in current.Where(c=>!wanted.Contains(c)).ToArray())
            {network.RemoveDevice(stale,module);removed=true;}
            // Removing one of several cables does not trigger a native refresh.
            // If an add already notified the network, no second notification is needed.
            if(removed&&!added&&network.GetDeviceRegistration(module)!=null)
            {network.DirtyPowerAndDataDeviceLists();network.RefreshNetworkDevice(module);}
        }
    }
}
