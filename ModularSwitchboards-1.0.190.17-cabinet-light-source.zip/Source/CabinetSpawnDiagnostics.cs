using System.Text;
using Assets.Scripts.Objects;
using UnityEngine;
namespace ModularSwitchboards
{
    // Bounded observations of the actual cloned hierarchy; never changes saves,
    // transforms, cover state or visibility. Needed for intermittent spawn reports.
    [DefaultExecutionOrder(1000)]
    public sealed class CabinetSpawnDiagnostics:MonoBehaviour
    {
        private Structure owner;
        private int observations,lastState=int.MinValue;
        private bool lastOpen;
        private float next;
        private void OnEnable(){observations=0;lastState=int.MinValue;next=0f;}
        private void LateUpdate()
        {
            if(owner==null)owner=GetComponent<Structure>();
            if(owner==null||owner.IsCursor||owner.GridController==null)return;
            bool changed=lastState!=owner.CurrentBuildStateIndex||lastOpen!=owner.IsOpen;
            if(!changed&&(observations>=3||Time.unscaledTime<next))return;
            var model=transform.Find("SwitchboardModel");if(model==null)return;
            var shell=model.Find("CompletedShell");if(shell==null)return;
            var text=new StringBuilder("[Modular Switchboards] Cabinet spawn view: ");
            text.Append(owner.ReferenceId).Append("; prefab=").Append(owner.PrefabName)
                .Append("; state=").Append(owner.CurrentBuildStateIndex).Append("; open=").Append(owner.IsOpen)
                .Append("; root=").Append(transform.position.ToString("F5")).Append("; rotation=").Append(transform.rotation)
                .Append("; model=").Append(model.localPosition.ToString("F5")).Append("; modelRotation=").Append(model.localRotation)
                .Append("; shell=").Append(shell.gameObject.activeInHierarchy);
            foreach(var renderer in model.GetComponentsInChildren<MeshRenderer>(true))
            {
                if(renderer.GetComponentInParent<Thing>()!=owner)continue;
                var mesh=renderer.GetComponent<MeshFilter>()?.sharedMesh;
                text.Append(" | ").Append(renderer.name).Append(": active=").Append(renderer.gameObject.activeInHierarchy)
                    .Append(", enabled=").Append(renderer.enabled).Append(", mesh=").Append(mesh==null?"null":mesh.name)
                    .Append(", centre=").Append(model.InverseTransformPoint(renderer.bounds.center).ToString("F5"));
            }
            ModDiagnostics.Log(text.ToString());
            lastState=owner.CurrentBuildStateIndex;lastOpen=owner.IsOpen;observations++;next=Time.unscaledTime+2f;
        }
    }
}
