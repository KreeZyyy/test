using System;
using System.Diagnostics;
using System.Reflection;
using Assets.Scripts.Networks;
using Assets.Scripts.Objects;
using HarmonyLib;
namespace ModularSwitchboards
{
    // Observe synchronous work only. Never swallow an exception or change power results.
    internal static class CablePlacementTiming
    {
        [ThreadStatic] private static Sample current;
        internal sealed class Sample
        {
            internal long Start;internal int Depth;internal string Root;
            internal long ProviderTicks,PowerTicks,NetworkTicks;internal int Providers,Power,Networks;
            internal long NetworkId;internal int Cables,Devices;
        }
        internal sealed class Scope {internal Sample Sample;internal long Start;internal string Kind;internal bool Root;}
        internal static void Configure(Harmony harmony)
        {
            foreach(var name in new[]{"Add","AddDevice","RefreshNetworkDevice"})
            {
                var target=name=="Add"?AccessTools.Method(typeof(CableNetwork),name,new[]{typeof(Assets.Scripts.Objects.Electrical.Cable)}):name=="AddDevice"?AccessTools.Method(typeof(CableNetwork),name,new[]{typeof(Assets.Scripts.Objects.Electrical.Cable),typeof(Assets.Scripts.Objects.Pipes.Device)}):AccessTools.Method(typeof(CableNetwork),name);
                harmony.Patch(target,prefix:new HarmonyMethod(typeof(CablePlacementTiming),nameof(BeginNetwork)),finalizer:new HarmonyMethod(typeof(CablePlacementTiming),nameof(End)));
            }
            harmony.Patch(AccessTools.Method(typeof(SmallGrid),"WillJoinNetwork"),prefix:new HarmonyMethod(typeof(CablePlacementTiming),nameof(BeginPlacement)),finalizer:new HarmonyMethod(typeof(CablePlacementTiming),nameof(End)));
            foreach(var name in new[]{"IsProviderToDevice","GetGeneratedPower","GetUsedPower","UsePower","ReceivePower"})
                harmony.Patch(AccessTools.Method(typeof(SwitchboardCabinet),name),prefix:new HarmonyMethod(typeof(CablePlacementTiming),nameof(BeginPower)),finalizer:new HarmonyMethod(typeof(CablePlacementTiming),nameof(End)));
        }
        private static Scope Begin(string kind)
        {
            if(!ServerGraphics.Headless)return null;
            bool root=current==null;if(root)current=new Sample{Start=Stopwatch.GetTimestamp(),Root=kind};
            current.Depth++;return new Scope{Sample=current,Start=Stopwatch.GetTimestamp(),Kind=kind,Root=root};
        }
        private static void BeginPlacement(out Scope __state){__state=Begin("placement");}
        private static void BeginNetwork(CableNetwork __instance,MethodBase __originalMethod,out Scope __state)
        {
            __state=Begin(__originalMethod.Name);if(__state==null)return;
            var s=__state.Sample;s.NetworkId=__instance.ReferenceId;s.Cables=__instance.CableList.Count;s.Devices=__instance.DeviceList.Count;
        }
        private static void BeginPower(MethodBase __originalMethod,out Scope __state){__state=Begin(__originalMethod.Name);}
        private static Exception End(Exception __exception,Scope __state)
        {
            if(__state==null)return __exception;
            var s=__state.Sample;long elapsed=Stopwatch.GetTimestamp()-__state.Start;
            if(__state.Kind=="IsProviderToDevice"){s.Providers++;s.ProviderTicks+=elapsed;}
            else if(__state.Kind=="Add"||__state.Kind=="AddDevice"||__state.Kind=="RefreshNetworkDevice"){s.Networks++;s.NetworkTicks+=elapsed;}
            else if(__state.Kind!="placement"){s.Power++;s.PowerTicks+=elapsed;}
            s.Depth--;
            if(__state.Root)
            {
                current=null;double ms=(Stopwatch.GetTimestamp()-s.Start)*1000d/Stopwatch.Frequency;
                if(ms>=50)UnityEngine.Debug.LogWarning("[Modular Switchboards] Cable timing "+SwitchboardsMod.Version+": root="+s.Root+" totalMs="+ms.ToString("F1",System.Globalization.CultureInfo.InvariantCulture)+" network="+s.NetworkId+" cables="+s.Cables+" devices="+s.Devices+" networkCalls="+s.Networks+" networkInclusiveMs="+Ms(s.NetworkTicks)+" providerCalls="+s.Providers+" providerInclusiveMs="+Ms(s.ProviderTicks)+" powerCalls="+s.Power+" powerInclusiveMs="+Ms(s.PowerTicks)+" exception="+(__exception==null?"none":__exception.GetType().Name));
            }
            return __exception;
        }
        private static string Ms(long ticks)=>(ticks*1000d/Stopwatch.Frequency).ToString("F1",System.Globalization.CultureInfo.InvariantCulture);
    }
}
