using System;
using System.Collections.Generic;
using UnityEngine;
namespace ModularSwitchboards
{
    internal static class AirChipSocketGeometry
    {
        internal const float Width=.046f,Height=.051f;
        // Measured in the user's native AirConditioner Diagnostics export.
        // The IC socket is recessed at z=.11327..15576. The surrounding grey
        // panel/white cabinet are separate surfaces at z=.20526 and above.
        // Keep complete original triangles, rather than clipping a cube through
        // that surrounding housing and carrying its cut panels onto the DIN face.
        internal static bool Contains(Vector3 p)=>p.x>=-.006f&&p.x<=.126f&&p.y>=.703f&&p.y<=.846f&&p.z>=.111f&&p.z<=.158f;
        internal static List<int>[] Select(Vector3[] vertices,int[][] source)
        {
            var groups=new List<int>[source.Length];
            for(int role=0;role<source.Length;role++)
            {
                var selected=groups[role]=new List<int>();var triangles=source[role];
                for(int i=0;i<triangles.Length;i+=3)
                {
                    int a=triangles[i],b=triangles[i+1],c=triangles[i+2];
                    if(Contains(vertices[a])&&Contains(vertices[b])&&Contains(vertices[c]))selected.AddRange(new[]{a,b,c});
                }
            }
            return groups;
        }
        private static Mesh baked;
        // Same selected vertices/UVs/triangles as the diagnostics export, baked at authoring time.
        // Never reads a game mesh, on either client or dedicated server.
        internal static Mesh Load()
        {
            if(baked!=null)return baked;
            using(var stream=typeof(AirChipSocketGeometry).Assembly.GetManifestResourceStream("ModularSwitchboards.AirChipSocket.meshbin"))
            {
                if(stream==null)throw new InvalidOperationException("Embedded IC10 socket geometry is missing.");
                using(var reader=new System.IO.BinaryReader(stream))
                {
                    if(reader.ReadInt32()!=0x53434941)throw new System.IO.InvalidDataException("Invalid IC10 socket header.");
                    int count=reader.ReadInt32(),roles=reader.ReadInt32();
                    if(count<3||count>65535||roles<1||roles>32)throw new System.IO.InvalidDataException("Invalid IC10 socket counts.");
                    var vertices=new List<Vector3>();var uv=new List<Vector2>();
                    for(int i=0;i<count;i++){vertices.Add(new Vector3(reader.ReadSingle(),reader.ReadSingle(),reader.ReadSingle()));uv.Add(new Vector2(reader.ReadSingle(),reader.ReadSingle()));}
                    var mesh=new Mesh{name="Smart.BakedAirIC10SocketOnly"};mesh.SetVertices(vertices);mesh.SetUVs(0,uv);mesh.subMeshCount=roles;
                    for(int role=0;role<roles;role++)
                    {
                        int length=reader.ReadInt32();if(length<0||length%3!=0||length>1000000)throw new System.IO.InvalidDataException("Invalid IC10 socket triangles.");
                        var ids=new int[length];for(int i=0;i<length;i++){ids[i]=reader.ReadInt32();if(ids[i]<0||ids[i]>=count)throw new System.IO.InvalidDataException("Invalid IC10 socket index.");}
                        mesh.SetTriangles(ids,role);
                    }
                    if(stream.Position!=stream.Length)throw new System.IO.InvalidDataException("Unexpected IC10 socket trailing data.");
                    mesh.RecalculateNormals();mesh.RecalculateTangents();mesh.RecalculateBounds();baked=mesh;return baked;
                }
            }
        }
        internal static float Fit(Bounds socket)=>Mathf.Min(Width/socket.size.x,Height/socket.size.y);
    }
}
