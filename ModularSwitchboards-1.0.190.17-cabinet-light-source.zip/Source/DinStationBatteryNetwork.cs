using System;
using System.Linq;
using System.Collections.Generic;
using Assets.Scripts.Networks;
using Assets.Scripts.Objects.Electrical;
using Assets.Scripts.Objects.Pipes;
using HarmonyLib;
namespace ModularSwitchboards
{
    internal static class DinStationBatteryNetwork
    {
        private static readonly System.Reflection.PropertyInfo PowerCable=AccessTools.Property(typeof(Device),"PowerCable"),PowerCables=AccessTools.Property(typeof(Device),"PowerCables"),DataCables=AccessTools.Property(typeof(Device),"DataCables");
        private sealed class Binding {internal Cable Cable;internal CableNetwork Network;}
        private static readonly Dictionary<DinStationBattery,Binding> Bound=new Dictionary<DinStationBattery,Binding>();
        internal static void Refresh(DinStationBattery module)
        {
            var cable=module.Cabinet?.Wiring.SmartCable(module.ReferenceId);var network=cable?.CableNetwork;
            if(Bound.TryGetValue(module,out var old)&&old.Cable==cable&&old.Network==network&&(network==null||network.GetDeviceRegistration(module)?.Contains(cable)==true))return;
            Unbind(module);if(network==null)return;
            Bound[module]=new Binding{Cable=cable,Network=network};module.DataCable=cable;module.InputNetwork=network;
            PowerCable.SetValue(module,null,null);PowerCables.SetValue(module,Array.Empty<Cable>(),null);DataCables.SetValue(module,new[]{cable},null);
            ModuleNetworkRegistration.Synchronize(network,module,new[]{cable});
        }
        internal static void Unbind(DinStationBattery module)
        {
            if(Bound.TryGetValue(module,out var old)){old.Network?.RemoveDevice(module);Bound.Remove(module);}
            module.DataCable=null;module.InputNetwork=null;module.OutputNetwork=null;PowerCable.SetValue(module,null,null);PowerCables.SetValue(module,Array.Empty<Cable>(),null);DataCables.SetValue(module,Array.Empty<Cable>(),null);
        }
    }
}
