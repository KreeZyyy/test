using System;
using System.Collections.Generic;
using System.Linq;
using Assets.Scripts;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Objects;
using UnityEngine;

namespace ModularSwitchboards
{
    // Shared placement reference; CabinetPowerInput registers the logical port separately.
    public sealed class OvenInputPanelMetadata : MonoBehaviour
    {
        public Vector3 SocketPoint, SocketAxis, CableCell, BodyCell, PanelFaceAxis;
        public Vector3 VisualAnchorPoint, SocketToVisualOffset;
        public Vector3 NativeSocketPoint, NativeSocketAxis, NativeVisualAnchor;
        public bool FunctionalConnection;
        public BoxCollider NativeStyleCollider;
    }

    internal static class OvenInputPanel
    {
        internal const string RootName="OvenInputPanel";
        private static Mesh cached;
        private static Vector3 nativeAnchor,nativeAxis;
        private static Vector3 visualAnchor;

        internal static void Install(SwitchboardCabinet cabinet)
        {
            if(CabinetShape.Medium(cabinet.PrefabName)){MediumInputPanel.Install(cabinet);return;}
            GameObject root=null;
            try
            {
                if(cached==null)Capture();
                var socket=NativeCableLayout.Read(CabinetLayout.InputCell(cabinet.PrefabName),CabinetLayout.InputOutward(cabinet.PrefabName));
                root=new GameObject(RootName){layer=cabinet.gameObject.layer};
                root.transform.SetParent(cabinet.transform.Find("SwitchboardModel/CompletedShell"),false);
                // Turn in the horizontal panel plane around the fixed socket origin.
                // Keep the future logical socket point and axis unchanged.
                root.transform.localRotation=Quaternion.Euler(0,0,CabinetLayout.Reversed(cabinet.PrefabName)?180f:0f)*Quaternion.Euler(-90f,0f,0f)*Quaternion.Euler(0f,0f,180f);
                root.AddComponent<MeshFilter>().sharedMesh=cached;
                var renderer=root.AddComponent<MeshRenderer>();renderer.sharedMaterials=CabinetGeometry.Materials;
                for(int role=0;role<5;role++){var block=new MaterialPropertyBlock();block.SetFloat(Thing.DiffuseIndexPropertyID,role==4?(int)Assets.Scripts.Objects.Motherboards.ColorType.Red:CabinetGeometry.PaletteIndices[role]);renderer.SetPropertyBlock(block,role);}
                renderer.shadowCastingMode=UnityEngine.Rendering.ShadowCastingMode.On;renderer.receiveShadows=true;
                var marker=root.AddComponent<OvenInputPanelMetadata>();
                marker.SocketPoint=socket.Point;marker.SocketAxis=socket.Forward;
                marker.PanelFaceAxis=root.transform.localRotation*Vector3.forward;
                marker.CableCell=socket.CableCell.ToVector3();marker.BodyCell=socket.BodyCell.ToVector3();
                marker.NativeSocketPoint=nativeAnchor;marker.NativeSocketAxis=nativeAxis;marker.NativeVisualAnchor=visualAnchor;
                marker.FunctionalConnection=false;
                var collider=root.AddComponent<MeshCollider>();collider.sharedMesh=cached;
                var target=new GameObject("InputSocketHitbox"){layer=cabinet.gameObject.layer};target.transform.SetParent(root.transform,false);var hit=target.AddComponent<BoxCollider>();hit.center=CabinetInputGeometry.Target.center;hit.size=CabinetInputGeometry.Target.size;marker.NativeStyleCollider=hit;
                cabinet.BuildStates[1].Colliders.Add(collider);
                Align(cabinet);CabinetModel.SetBounds(cabinet);
                ModDiagnostics.Log("[Modular Switchboards] Own CPU IN panel installed; no runtime oven model read; socket="+socket.Point.ToString("F6")+
                    " axis="+socket.Forward+" cableCell="+marker.CableCell+" bodyCell="+marker.BodyCell+
                    "; native oven anchor="+nativeAnchor.ToString("F6")+"; power registration follows panel installation.");
            }
            catch(Exception ex)
            {
                if(root!=null)
                {
                    var collider=root.GetComponent<MeshCollider>();
                    if(collider!=null)cabinet.BuildStates[1].Colliders.Remove(collider);
                    UnityEngine.Object.DestroyImmediate(root);
                }
                throw new InvalidOperationException("Own IN panel setup failed; no partial input will be registered.",ex);
            }
        }

        private static void Capture()
        {
            cached=CabinetInputGeometry.Build();
            nativeAnchor=CabinetInputGeometry.ReferenceSocket;nativeAxis=CabinetInputGeometry.ReferenceAxis;visualAnchor=CabinetInputGeometry.ReferenceVisual;
        }

        internal static void Align(Structure cabinet)
        {
            if(CabinetShape.Medium(cabinet.PrefabName)){MediumInputPanel.Align(cabinet);return;}
            var root=cabinet.transform.Find("SwitchboardModel/CompletedShell/"+RootName);
            if(root==null)return;var data=root.GetComponent<OvenInputPanelMetadata>();
            if(data==null)return;
            // Cancel visual wall-fit translation so the original power anchor,
            // projected to the visible face at the mesh origin, remains on the cable-grid socket position.
            // The selected housing edge is y=+/-0.25 m. The face belongs on that surface,
            // while the proposed native cable endpoint remains separate metadata.
            var visual=data.SocketPoint;visual.y=(CabinetShape.Medium(cabinet.PrefabName)?.7505f:.2505f)*CabinetLayout.YSign(cabinet.PrefabName);
            data.VisualAnchorPoint=visual;
            data.SocketToVisualOffset=visual-data.SocketPoint;
            root.localPosition=root.parent.InverseTransformPoint(cabinet.transform.position)+visual;
            OvenInputSupport.Fit(cabinet);
        }

        internal static void IncludeBounds(Structure cabinet,ref Bounds bounds)
        {
            var root=cabinet.transform.Find("SwitchboardModel/CompletedShell/"+RootName);
            if(root==null)return;
            foreach(var filter in root.GetComponentsInChildren<MeshFilter>(true))if(filter.sharedMesh!=null)
                bounds.Encapsulate(CabinetWallMount.TransformedBounds(filter.sharedMesh.bounds,cabinet.transform.worldToLocalMatrix*filter.transform.localToWorldMatrix));
        }
    }
}
