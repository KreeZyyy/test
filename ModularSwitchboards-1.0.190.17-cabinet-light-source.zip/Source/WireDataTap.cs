using System.Collections.Generic;
using System.Linq;
namespace ModularSwitchboards
{
    // A direct Output -> Net DATA connection is a data observation leaf, never a power edge.
    internal static class WireDataTap
    {
        internal static bool Output(CabinetWireEnd e)=>e!=null&&e.Owner==0&&e.Contact>=1&&e.Contact<=3;
        internal static bool Stored(CabinetWireEnd from,CabinetWireEnd to)=>Output(from)&&to!=null&&to.Owner!=0&&to.Contact==0;
        internal static bool Allowed(CabinetWireEnd a,CabinetWireEnd b,IEnumerable<long> nets)
            =>Stored(a,b)&&(nets?.Contains(b.Owner)??false)||Stored(b,a)&&(nets?.Contains(a.Owner)??false);
        internal static bool Stored(CabinetWireSaveData w)=>w!=null&&Stored(w.From,w.To);
        internal static IEnumerable<CabinetWireSaveData> PowerWires(IEnumerable<CabinetWireSaveData> wires)=>wires.Where(w=>!Stored(w));
        internal static int Occupied(CabinetWireEnd end,IEnumerable<CabinetWireSaveData> wires,bool data)
            =>wires.Count(w=>(w.From.Equals(end)||w.To.Equals(end))&&(!Output(end)||Stored(w)==data));
        internal static bool CanStart(CabinetWireEnd end,IEnumerable<CabinetWireSaveData> wires,int powerCapacity)
            =>Occupied(end,wires,false)<powerCapacity||Output(end)&&Occupied(end,wires,true)<1;
    }
}
