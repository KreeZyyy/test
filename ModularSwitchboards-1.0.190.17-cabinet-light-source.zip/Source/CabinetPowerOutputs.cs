using System;
using System.Collections.Generic;
using System.Linq;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Objects;
using Assets.Scripts.Util;
using UnityEngine;

namespace ModularSwitchboards
{
    public sealed class CabinetOutputSocket : MonoBehaviour
    {
        public ConnectionRole Role;
        public Vector3[] LocalJoinProfile;
        public Vector3 CableCell,BodyCell,ContactPoint;
        public Bounds LocalVisualBounds,LocalJoinBounds;
        public bool HasVisualBounds,HasJoinBounds;
    }
    public sealed class CabinetOutputCasing : MonoBehaviour
    {
        [NonSerialized] public Mesh InstanceMesh;
        [NonSerialized] public bool FitFailed;
        private void OnDestroy(){if(InstanceMesh!=null)UnityEngine.Object.Destroy(InstanceMesh);}
    }
    internal static class CabinetPowerOutputs
    {
        internal const string RootName="SwitchboardPowerOutputs",CasingName="OutputTCasing";
        internal static bool TryInstall(SwitchboardCabinet cabinet)
        {
            var colliders=new List<Collider>(cabinet.BuildStates[1].Colliders);
            var linked=new List<GameObject>(cabinet.BuildStates[1].LinkedGameObjects);
            var ports=new List<Connection>(cabinet.OpenEnds);
            try {Install(cabinet);return true;}
            catch(Exception ex)
            {
                cabinet.OpenEnds=ports;
                var outputs=cabinet.transform.Find(RootName);
                if(outputs!=null)UnityEngine.Object.DestroyImmediate(outputs.gameObject);
                var casing=cabinet.transform.Find("SwitchboardModel/CompletedShell/"+CasingName);
                if(casing!=null)UnityEngine.Object.DestroyImmediate(casing.gameObject);
                cabinet.BuildStates[1].Colliders=colliders;cabinet.BuildStates[1].LinkedGameObjects=linked;
                CabinetModel.SetBounds(cabinet);
                Debug.LogError("[Modular Switchboards] Output MODEL unavailable; cabinet, Input and DIN registration preserved: "+ex);
                return false;
            }
        }
        internal static void Install(SwitchboardCabinet cabinet)
        {
            if(cabinet.OpenEnds==null||cabinet.OpenEnds.Count==0)throw new InvalidOperationException("Install Input before the outputs.");
            var shell=cabinet.transform.Find("SwitchboardModel/CompletedShell");
            var root=new GameObject(RootName){layer=cabinet.gameObject.layer};root.transform.SetParent(cabinet.transform,false);
            cabinet.BuildStates[1].LinkedGameObjects.Add(root);
            var cells=new HashSet<Grid3>{cabinet.transform.InverseTransformPoint(cabinet.OpenEnds[0].Transform.position).ToGrid(SmallGrid.SmallGridSize,SmallGrid.SmallGridOffset)};
            // Positive canonical shell X is the viewer's left, as confirmed by the terminal labels.
            var left=cabinet.transform.InverseTransformDirection(shell.TransformDirection(Vector3.right)).normalized;
            var front=cabinet.transform.InverseTransformDirection(shell.TransformDirection(Vector3.forward)).normalized;
            for(int i=0;i<CabinetShape.OutputCount(cabinet.PrefabName);i++)
            {
                var outward=OutputPlacement.Outward(cabinet.PrefabName,i,left);
                var socket=NativeCableLayout.ReadForBody(OutputPlacement.Body(cabinet.PrefabName,i,left,SmallGrid.SmallGridSize),outward);
                if(!cells.Add(socket.CableCell))throw new InvalidOperationException("Output cable cell overlaps another port.");
                var role=CabinetPorts.BranchRole(cabinet.PrefabName,i);
                var go=new GameObject("Output"+(i+1)){layer=cabinet.gameObject.layer};go.transform.SetParent(root.transform,false);
                go.transform.localPosition=socket.Point;go.transform.localRotation=Quaternion.LookRotation(socket.Forward,front);
                var data=go.AddComponent<CabinetOutputSocket>();data.Role=role;data.CableCell=socket.CableCell.ToVector3();data.BodyCell=socket.BodyCell.ToVector3();data.ContactPoint=socket.ContactPoint;
                var hit=ExternalCablePorts.AttachNativeOutput(cabinet,go.transform);
                // The logical node identifies a cable cell. The physical mouth belongs
                // at that native cable's inward endpoint, not at the cell centre.
                hit.transform.localPosition=Quaternion.Inverse(go.transform.localRotation)*(socket.ContactPoint-socket.Point);
                var aperture=cabinet.transform.InverseTransformPoint(hit.transform.position);
                if((aperture-socket.ContactPoint).sqrMagnitude>1e-8f)
                    throw new InvalidOperationException("Output visual aperture is off its native cable endpoint.");
                if(!ReadVisualBounds(go.transform,out var localBounds))throw new InvalidOperationException("New APC output model is empty.");
                data.LocalVisualBounds=localBounds;data.HasVisualBounds=true;
                data.LocalJoinBounds=CabinetWallMount.TransformedBounds(ExternalCablePorts.OutputJoinBounds,go.transform.worldToLocalMatrix*hit.transform.localToWorldMatrix);
                data.HasJoinBounds=true;
                var joinMatrix=go.transform.worldToLocalMatrix*hit.transform.localToWorldMatrix;data.LocalJoinProfile=ApcLugCompletion.InterfaceProfile.Select(joinMatrix.MultiplyPoint3x4).ToArray();
                RegisterOutput(cabinet,go.transform,hit,role);
                cabinet.BuildStates[1].Colliders.Add(hit);
                ModDiagnostics.Log("[Modular Switchboards] "+go.name+" native grid: point="+socket.Point.ToString("F6")+
                    "; visual mouth="+socket.ContactPoint.ToString("F6")+"; inward axis="+socket.Forward+"; cable cell="+socket.CableCell+"; body cell="+socket.BodyCell);
            }
            var casing=new GameObject(CasingName){layer=cabinet.gameObject.layer};casing.transform.SetParent(shell,false);
            casing.AddComponent<CabinetOutputCasing>();casing.AddComponent<MeshFilter>();
            casing.AddComponent<MeshRenderer>().sharedMaterials=CabinetGeometry.Materials;
            var collider=casing.AddComponent<MeshCollider>();cabinet.BuildStates[1].Colliders.Add(collider);
            Fit(cabinet);CabinetRearSurface.Restore(casing.GetComponent<MeshRenderer>());CabinetModel.SetBounds(cabinet);
            ModDiagnostics.Log("[Modular Switchboards] Output housing installed; "+CabinetShape.OutputCount(cabinet.PrefabName)+" independent native power ports; no internal bridge.");
        }
        internal static void RegisterOutput(SwitchboardCabinet cabinet,Transform anchor,Collider hit,ConnectionRole role)
        {
            if(role!=ConnectionRole.Output && role!=ConnectionRole.Output2&&role!=ConnectionRole.Waste&&!(CabinetPorts.Combiner(cabinet.PrefabName)&&role==ConnectionRole.Input))
                throw new InvalidOperationException("Only output roles belong to the output connectors.");
            if(anchor==null||hit==null)throw new InvalidOperationException("Output geometry is not ready.");
            if(cabinet.OpenEnds.Any(p=>p.ConnectionRole==role))throw new InvalidOperationException("Duplicate output role: "+role);
            var port=new Connection(cabinet){Transform=anchor,Collider=hit,ConnectionRole=role,
                ConnectionType=cabinet.IsStructureCompleted?NetworkType.Power:NetworkType.None};
            port.Validate();cabinet.OpenEnds.Add(port);
        }
        // Native cursor setup removes model renderers/filters for its blueprint.
        // Runtime fitting must not depend on those temporary preview components.
        internal static void TryFit(Structure cabinet)
        {
            if(cabinet.IsCursor)return;
            var casing=cabinet.transform.Find("SwitchboardModel/CompletedShell/"+CasingName);
            var state=casing==null?null:casing.GetComponent<CabinetOutputCasing>();
            if(state==null||state.FitFailed)return;
            try {Fit(cabinet);}
            catch(Exception ex)
            {
                state.FitFailed=true;
                Debug.LogError("[Modular Switchboards] Output MODEL wall fit paused after one failure; existing model retained: "+ex);
            }
        }
        private static bool ReadVisualBounds(Transform port,out Bounds result)
        {
            Bounds? bounds=null;
            foreach(var filter in port.GetComponentsInChildren<MeshFilter>(true))
            {
                if(filter.sharedMesh==null)continue;
                var b=CabinetWallMount.TransformedBounds(filter.sharedMesh.bounds,port.worldToLocalMatrix*filter.transform.localToWorldMatrix);
                if(bounds.HasValue){var v=bounds.Value;v.Encapsulate(b);bounds=v;}else bounds=b;
            }
            result=bounds??new Bounds();return bounds.HasValue;
        }
        internal static void Fit(Structure cabinet)
        {
            if(cabinet.IsCursor)return;
            var shell=cabinet.transform.Find("SwitchboardModel/CompletedShell");
            var root=cabinet.transform.Find(RootName);var casing=shell==null?null:shell.Find(CasingName);
            if(root==null||casing==null)return;
            Bounds? total=null;
            float xmin=0,xmax=0;
            var ports=root.GetComponentsInChildren<CabinetOutputSocket>(true);
            if(ports.Length!=CabinetShape.OutputCount(cabinet.PrefabName))throw new InvalidOperationException("Unexpected output model metadata count: "+ports.Length);
            if(CabinetShape.Medium(cabinet.PrefabName)){FitMedium(cabinet,shell,casing,ports);return;}
            foreach(var port in ports.Where(p=>p.Role!=ConnectionRole.Waste))
            {
                if(!port.HasVisualBounds)
                {
                    if(!ReadVisualBounds(port.transform,out var measured))throw new InvalidOperationException("Output model has neither cached bounds nor a mesh.");
                    port.LocalVisualBounds=measured;port.HasVisualBounds=true;
                }
                var bounds=CabinetLayout.MapBounds(cabinet.PrefabName,CabinetWallMount.TransformedBounds(port.HasJoinBounds?port.LocalJoinBounds:port.LocalVisualBounds,shell.worldToLocalMatrix*port.transform.localToWorldMatrix));
                if(bounds.center.x>0)xmax=bounds.min.x+.004f;else xmin=bounds.max.x-.004f;
                if(total.HasValue){var b=total.Value;b.Encapsulate(bounds);total=b;}else total=bounds;
            }
            if(!total.HasValue)return;
            var body=CabinetLayout.MapBounds(cabinet.PrefabName,NativeRearBox.BodyBounds(cabinet));var arms=total.Value;
            // Match the actual native connector cross-section, without scaling it.
            float half=arms.size.y*.5f;
            float low=arms.min.y,barTop=arms.max.y,stemTop=body.min.y+.004f;
            if(xmin>=-half||xmax<=half||barTop>=stemTop)throw new InvalidOperationException("Native T dimensions invalid: xmin="+xmin+" xmax="+xmax+" half="+half+" barTop="+barTop+" stemTop="+stemTop+" arms="+arms+" body="+body);
            float zmin=arms.min.z,zmax=arms.max.z;
            List<Vector2> Section(float inset)
            {
                var corners=new[]{new Vector2(xmin,low+inset),new Vector2(xmax,low+inset),new Vector2(xmax,barTop-inset),
                    new Vector2(half-inset,barTop-inset),new Vector2(half-inset,stemTop),new Vector2(-half+inset,stemTop),
                    new Vector2(-half+inset,barTop-inset),new Vector2(xmin,barTop-inset)};
                return ChamferOutline(corners,.003f);
            }
            // One planar chamfer matching the native APC slope (5.776 / 10).
            float bevelDepth=Mathf.Min(.010f,Mathf.Min((zmax-zmin)*.3f,half*.4f/.5776f));
            float bevelInset=bevelDepth*.5776f;
            var outlines=new List<List<Vector2>>{Section(bevelInset),Section(0),Section(0)};
            var depths=new List<float>{zmin,zmin+bevelDepth,zmax};
            var vertices=new List<Vector3>();var indices=new List<int>();int n=outlines[0].Count;
            for(int level=0;level<outlines.Count;level++)foreach(var p in outlines[level])vertices.Add(new Vector3(p.x,p.y,depths[level]));
            for(int level=0;level+1<outlines.Count;level++)for(int i=0;i<n;i++)
            {
                int a=level*n+i,b=level*n+(i+1)%n,c=b+n,d=a+n;
                indices.AddRange(new[]{a,b,c,a,c,d});
            }
            foreach(bool front in new[]{false,true})
            {
                int level=front?outlines.Count-1:0,first=vertices.Count;var outline=outlines[level];
                foreach(var p in outline)vertices.Add(new Vector3(p.x,p.y,depths[level]));
                var triangles=Triangulate(outline);
                for(int i=0;i<triangles.Count;i+=3)
                    indices.AddRange(front?new[]{first+triangles[i],first+triangles[i+1],first+triangles[i+2]}:new[]{first+triangles[i],first+triangles[i+2],first+triangles[i+1]});
            }
            // Separate triangle vertices so planar bevels keep hard normal edges.
            var flatVertices=new List<Vector3>();
            foreach(int index in indices)flatVertices.Add(vertices[index]);
            vertices=flatVertices;indices=Enumerable.Range(0,vertices.Count).ToList();
            var third=ports.FirstOrDefault(p=>p.Role==ConnectionRole.Waste);
            if(third!=null)
            {
                var b=CabinetWallMount.TransformedBounds(third.LocalJoinBounds,shell.worldToLocalMatrix*third.transform.localToWorldMatrix);
                float top=arms.min.y+.0005f,bottom=b.max.y-.004f;
                DinRailModel.AddBox(vertices,indices,new Vector3(0,(top+bottom)*.5f,(zmin+zmax)*.5f),new Vector3(.06f,top-bottom,zmax-zmin-.0006f));
            }
            CabinetLayout.MapMesh(cabinet.PrefabName,vertices,indices);
            var state=casing.GetComponent<CabinetOutputCasing>();
            if(state.InstanceMesh==null)state.InstanceMesh=new Mesh{name="Switchboards.NativeGridTCasing"};
            var mesh=state.InstanceMesh;mesh.Clear();mesh.SetVertices(vertices);mesh.subMeshCount=5;
            for(int i=0;i<5;i++)mesh.SetTriangles(i==CabinetRearSurface.Role?indices.ToArray():new int[0],i);
            mesh.RecalculateNormals();CabinetGeometry.ApplyNativeUv(mesh);CabinetRearSurface.ApplyUv(mesh);mesh.RecalculateBounds();
            casing.GetComponent<MeshFilter>().sharedMesh=mesh;var hit=casing.GetComponent<MeshCollider>();hit.sharedMesh=null;hit.sharedMesh=mesh;
        }
        private static void FitMedium(Structure cabinet,Transform shell,Transform casing,CabinetOutputSocket[] ports)
        {
            var joins=ports.Select(p=>CabinetWallMount.TransformedBounds(p.LocalJoinBounds,shell.worldToLocalMatrix*p.transform.localToWorldMatrix)).OrderBy(b=>b.center.x).ToArray();
            var profiles=ports.Select(p=>p.LocalJoinProfile.Select(v=>CabinetLayout.Map(cabinet.PrefabName,(shell.worldToLocalMatrix*p.transform.localToWorldMatrix).MultiplyPoint3x4(v))).ToArray()).OrderBy(r=>r.Average(v=>v.x)).ToArray();
            var layers=NativeLugSection.Layers(profiles);
            float wideHalf=layers.Max(layer=>layer.HalfWidth);
            float barTop=-CabinetShape.Height(cabinet.PrefabName)*.5f+.004f,barBottom=barTop-.07f;
            float stemTop=NativeRearBox.BodyBounds(cabinet).min.y+.004f;
            var outlines=layers.Select(layer=>MediumOutputHousing.Chamfer(MediumOutputHousing.Outline(layer.Centers,layer.Ends,layer.HalfWidth,barBottom+(wideHalf-layer.HalfWidth),barTop-(wideHalf-layer.HalfWidth),stemTop),.003f)).ToArray();
            var depths=layers.Select(layer=>layer.Depth).ToArray();
            var vertices=new List<Vector3>();var indices=new List<int>();int n=outlines[0].Count;
            for(int level=0;level<outlines.Length;level++)foreach(var v in outlines[level])vertices.Add(new Vector3(v.x,v.y,depths[level]));
            for(int level=0;level+1<outlines.Length;level++)for(int i=0;i<n;i++){int j=(i+1)%n,a=level*n+i,b=level*n+j;indices.AddRange(new[]{a,b,b+n,a,b+n,a+n});}
            for(int level=0;level<outlines.Length;level+=outlines.Length-1)
            {
                int start=vertices.Count;foreach(var v in outlines[level])vertices.Add(new Vector3(v.x,v.y,depths[level]));
                var cap=Triangulate(outlines[level]);for(int i=0;i<cap.Count;i+=3)indices.AddRange(level==0?new[]{start+cap[i],start+cap[i+2],start+cap[i+1]}:new[]{start+cap[i],start+cap[i+1],start+cap[i+2]});
            }
            CabinetLayout.MapMesh(cabinet.PrefabName,vertices,indices);
            var state=casing.GetComponent<CabinetOutputCasing>();if(state.InstanceMesh==null)state.InstanceMesh=new Mesh{name="Switchboards.MediumDownwardOutputs"};
            // Separate face vertices to preserve hard sheet-metal edges.
            var flat=indices.Select(i=>vertices[i]).ToList();var mesh=state.InstanceMesh;mesh.Clear();mesh.SetVertices(flat);mesh.subMeshCount=5;
            for(int i=0;i<5;i++)mesh.SetTriangles(i==CabinetRearSurface.Role?Enumerable.Range(0,flat.Count).ToArray():new int[0],i);
            mesh.RecalculateNormals();CabinetGeometry.ApplyNativeUv(mesh);CabinetRearSurface.ApplyUv(mesh);mesh.RecalculateBounds();casing.GetComponent<MeshFilter>().sharedMesh=mesh;
            var hit=casing.GetComponent<MeshCollider>();hit.sharedMesh=null;hit.sharedMesh=mesh;
        }
        private static List<Vector2> ChamferOutline(Vector2[] corners,float radius)
        {
            var result=new List<Vector2>();
            for(int i=0;i<corners.Length;i++)
            {
                var p=corners[i];var before=corners[(i+corners.Length-1)%corners.Length];var after=corners[(i+1)%corners.Length];
                float r=Mathf.Min(radius,Mathf.Min((before-p).magnitude,(after-p).magnitude)*.25f);
                var a=p+(before-p).normalized*r;var b=p+(after-p).normalized*r;
                result.Add(a);result.Add(b);
            }
            return result;
        }
        private static float Cross(Vector2 a,Vector2 b,Vector2 c)=>(b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x);
        private static List<int> Triangulate(List<Vector2> p)
        {
            var remaining=Enumerable.Range(0,p.Count).ToList();var result=new List<int>();int guard=p.Count*p.Count;
            while(remaining.Count>3 && guard-->0)
            {
                bool clipped=false;
                for(int i=0;i<remaining.Count;i++)
                {
                    int a=remaining[(i+remaining.Count-1)%remaining.Count],b=remaining[i],c=remaining[(i+1)%remaining.Count];
                    if(Cross(p[a],p[b],p[c])<=1e-10f)continue;
                    bool occupied=remaining.Any(v=>v!=a&&v!=b&&v!=c&&Cross(p[a],p[b],p[v])>=-1e-10f&&Cross(p[b],p[c],p[v])>=-1e-10f&&Cross(p[c],p[a],p[v])>=-1e-10f);
                    if(occupied)continue;
                    result.AddRange(new[]{a,b,c});remaining.RemoveAt(i);clipped=true;break;
                }
                if(!clipped)throw new InvalidOperationException("Cannot triangulate output housing.");
            }
            if(remaining.Count!=3)throw new InvalidOperationException("Incomplete output housing cap.");
            result.AddRange(remaining);return result;
        }
        internal static void IncludeBounds(Structure cabinet,ref Bounds bounds)
        {
            foreach(var path in new[]{RootName,"SwitchboardModel/CompletedShell/"+CasingName})
            {
                var root=cabinet.transform.Find(path);if(root==null)continue;
                foreach(var filter in root.GetComponentsInChildren<MeshFilter>(true))if(filter.sharedMesh!=null)
                    bounds.Encapsulate(CabinetWallMount.TransformedBounds(filter.sharedMesh.bounds,cabinet.transform.worldToLocalMatrix*filter.transform.localToWorldMatrix));
            }
        }
    }
}
