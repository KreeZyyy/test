using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Assets.Scripts;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Electrical;
using Assets.Scripts.Objects.Motherboards;
using UnityEngine;
using UnityEngine.Rendering;
namespace ModularSwitchboards
{
    // User-requested native battery reference export; no source prefab mutations.
    internal static class NativeBatteryReference
    {
        [Serializable] public sealed class Report
        {
            public string version=SwitchboardsMod.Version,gameAssembly=typeof(Battery).Assembly.FullName;
            public bool graphicsUvStartsAtTop=SystemInfo.graphicsUVStartsAtTop;public string graphicsDevice=SystemInfo.graphicsDeviceType.ToString();
            public string coordinates="Vertices in native prefab-local metres; UVs and submesh indices unchanged.";
            public List<BatteryData> batteries=new List<BatteryData>();public List<TextureData> textures=new List<TextureData>();public List<string> errors=new List<string>();
        }
        [Serializable] public sealed class BatteryData
        {
            public string prefab,paintMaterial,screen,switchPivot,switchRenderer;public float capacity,diffuseIndex,smoothnessIndex;
            public Vector3 offPosition,onPosition;public List<string> indicators=new List<string>();public List<string> displayMaterials=new List<string>();
            public List<Surface> stateMaterials=new List<Surface>();public List<Node> hierarchy=new List<Node>();public List<Stage> stages=new List<Stage>();
            public List<Part> parts=new List<Part>();
        }
        [Serializable] public sealed class Node{public string path,parent;public Vector3 position,scale;public Quaternion rotation;public Matrix4x4 toPrefab;public bool active;public string[] components;}
        [Serializable] public sealed class Stage{public int index;public string renderer;}
        [Serializable] public sealed class Part
        {
            public string path,mesh;public List<Attribute> attributes=new List<Attribute>();public List<Stream> streams=new List<Stream>();public Vector3[] vertices;public Vector2[] uv;public Matrix4x4 meshToPrefab;
            public List<Property> globalBlock=new List<Property>();public List<Surface> surfaces=new List<Surface>();
        }
        [Serializable] public sealed class Attribute{public string attribute,format;public int dimension,stream,offset;}
        [Serializable] public sealed class Stream{public int stream,stride,bytes;public string file,error;}
        [Serializable] public sealed class Surface
        {
            public int submesh;public int[] triangles;public string material,shader;public bool paintable;
            public List<Property> properties=new List<Property>();
        }
        [Serializable] public sealed class Property
        {
            public string name,type,texture,blockTexture;public int textureId,blockTextureId;public bool blockHasProperty;
            public float value,blockFloat;public Color color,blockColor;public Vector4 vector,blockVector;public Vector2 scale,offset;
        }
        [Serializable] public sealed class TextureData
        {
            public int id,width,height,slice;public string name,dimension,format,file,error;
        }
        private static bool attempted;
        internal static void Capture()
        {
            if(attempted||GameManager.IsBatchMode)return;attempted=true;
            string stem="ModularSwitchboards-Batteries-reference-"+SwitchboardsMod.Version;
            string directory=Path.Combine(Application.persistentDataPath,stem),zip=directory+".zip";
            try
            {
                if(File.Exists(zip)){ModDiagnostics.Log("[Modular Switchboards] BATTERY REFERENCE already available: "+zip);return;}
                var sources=WorldManager.Instance.SourcePrefabs;
                var selected=new List<Battery>();foreach(string name in new[]{"StructureBattery","StructureBatteryLarge"})
                {
                    var battery=sources.OfType<Battery>().FirstOrDefault(b=>b.PrefabName==name);
                    if(battery==null)throw new InvalidOperationException("Native battery missing: "+name);selected.Add(battery);
                }
                Directory.CreateDirectory(directory);var report=new Report();var textures=new Dictionary<int,Texture>();var slices=new HashSet<int>{(int)ColorType.Red,(int)ColorType.Black,(int)ColorType.White};
                foreach(var cable in selected)
                {
                    var data=new BatteryData{prefab=cable.PrefabName,capacity=cable.PowerMaximum,paintMaterial=cable.PaintableMaterial?.name,diffuseIndex=cable.CustomColor==null?-1:cable.CustomColor.Index,smoothnessIndex=cable.SmoothnessIndex};report.batteries.Add(data);
                    AddSlice(slices,data.diffuseIndex);AddSlice(slices,data.smoothnessIndex);
                    foreach(var node in cable.GetComponentsInChildren<Transform>(true))data.hierarchy.Add(new Node{
                        path=NodePath(node,cable.transform),parent=node==cable.transform?null:NodePath(node.parent,cable.transform),
                        position=node.localPosition,rotation=node.localRotation,scale=node.localScale,active=node.gameObject.activeSelf,
                        toPrefab=cable.transform.worldToLocalMatrix*node.localToWorldMatrix,
                        components=node.GetComponents<Component>().Where(c=>c!=null).Select(c=>c.GetType().FullName).ToArray()});
                    for(int stage=0;stage<cable.BuildStates.Count;stage++)data.stages.Add(new Stage{index=stage,renderer=cable.BuildStates[stage].Visualizer==null?null:NodePath(cable.BuildStates[stage].Visualizer.transform,cable.transform)});
                    var indicators=HarmonyLib.AccessTools.Field(typeof(Battery),"displayRenderers").GetValue(cable) as MeshRenderer[];
                    if(indicators!=null)foreach(var indicator in indicators)data.indicators.Add(indicator==null?null:NodePath(indicator.transform,cable.transform));
                    var displayMaterials=HarmonyLib.AccessTools.Field(typeof(Battery),"displayModeMaterials").GetValue(cable) as Material[];
                    if(displayMaterials!=null)foreach(var m in displayMaterials){data.displayMaterials.Add(m?.name);if(m!=null&&m.shader!=null)data.stateMaterials.Add(new Surface{material=m.name,shader=m.shader.name,properties=Properties(m,new MaterialPropertyBlock(),textures,slices)});}
                    data.screen=cable.Screen==null?null:NodePath(cable.Screen.transform,cable.transform);
                    var nativeSwitch=cable.SwitchOnOff??cable.GetComponentsInChildren<Objects.SwitchOnOff>(true).FirstOrDefault();
                    if(nativeSwitch!=null){var type=typeof(Objects.SwitchOnOff);
                        var pivot=HarmonyLib.AccessTools.Field(type,"switchTransform").GetValue(nativeSwitch) as Transform;
                        var rocker=HarmonyLib.AccessTools.Field(type,"switchRenderer").GetValue(nativeSwitch) as MeshRenderer;
                        data.switchPivot=pivot==null?null:NodePath(pivot,cable.transform);data.switchRenderer=rocker==null?null:NodePath(rocker.transform,cable.transform);
                        data.offPosition=(Vector3)HarmonyLib.AccessTools.Field(type,"offPosition").GetValue(nativeSwitch);data.onPosition=(Vector3)HarmonyLib.AccessTools.Field(type,"onPosition").GetValue(nativeSwitch);
                        foreach(string field in new[]{"off","on","onPowered","error"}){
                            var value=HarmonyLib.AccessTools.Field(type,field).GetValue(nativeSwitch);var modes=value is Material[] array?array:new[]{value as Material};
                            foreach(var m in modes)if(m!=null&&m.shader!=null)data.stateMaterials.Add(new Surface{material=field+":"+m.name,shader=m.shader.name,properties=Properties(m,new MaterialPropertyBlock(),textures,slices)});}}
                    foreach(var renderer in cable.GetComponentsInChildren<MeshRenderer>(true))
                    {
                        var mesh=renderer.GetComponent<MeshFilter>()?.sharedMesh;if(mesh==null)continue;
                        try
                        {
                            CabinetGeometry.ReadNativeMesh(mesh,out var vertices,out var uv,out var groups);var matrix=cable.transform.worldToLocalMatrix*renderer.transform.localToWorldMatrix;
                            for(int i=0;i<vertices.Length;i++)vertices[i]=matrix.MultiplyPoint3x4(vertices[i]);
                            var part=new Part{path=NodePath(renderer.transform,cable.transform),mesh=mesh.name,vertices=vertices,uv=uv,meshToPrefab=matrix};data.parts.Add(part);
                            WriteObj(Path.Combine(directory,data.prefab+"-part-"+(data.parts.Count-1)+".obj"),vertices,uv,groups);
                            foreach(var attribute in mesh.GetVertexAttributes())part.attributes.Add(new Attribute{attribute=attribute.attribute.ToString(),format=attribute.format.ToString(),dimension=attribute.dimension,stream=mesh.GetVertexAttributeStream(attribute.attribute),offset=mesh.GetVertexAttributeOffset(attribute.attribute)});
                            for(int stream=0;stream<mesh.vertexBufferCount;stream++)
                            {
                                var raw=new Stream{stream=stream,stride=mesh.GetVertexBufferStride(stream)};part.streams.Add(raw);
                                try{using(var buffer=mesh.GetVertexBuffer(stream)){raw.bytes=buffer.count*buffer.stride;if(raw.bytes%4!=0)throw new InvalidOperationException("Unaligned vertex buffer");var words=new uint[raw.bytes/4];buffer.GetData(words);var bytes=new byte[raw.bytes];Buffer.BlockCopy(words,0,bytes,0,bytes.Length);raw.file="mesh-"+(report.batteries.Count-1)+"-part-"+(data.parts.Count-1)+"-stream-"+stream+".bin";File.WriteAllBytes(Path.Combine(directory,raw.file),bytes);}}
                                catch(Exception ex){raw.error=ex.Message;report.errors.Add(cable.PrefabName+" vertex stream "+stream+": "+ex.Message);}
                            }
                            var global=new MaterialPropertyBlock();renderer.GetPropertyBlock(global);var materials=renderer.sharedMaterials;
                            for(int i=0;i<groups.Length;i++)
                            {
                                var material=i<materials.Length?materials[i]:null;var block=new MaterialPropertyBlock();renderer.GetPropertyBlock(block,i);
                                var surface=new Surface{submesh=i,triangles=groups[i],material=material?.name,shader=material?.shader?.name,paintable=material==cable.PaintableMaterial};part.surfaces.Add(surface);
                                if(material==null||material.shader==null)continue;
                                surface.properties=Properties(material,block,textures,slices);if(i==0)part.globalBlock=Properties(material,global,textures,slices);
                            }
                        }
                        catch(Exception ex){report.errors.Add(cable.PrefabName+" / "+renderer.name+": "+ex.Message);}
                    }
                    if(data.parts.Count==0)report.errors.Add(cable.PrefabName+": no mesh geometry captured");
                }
                foreach(var texture in textures.Values)
                {
                    if(texture is Texture2DArray array)foreach(int slice in slices.Where(n=>n>=0&&n<array.depth).OrderBy(n=>n))report.textures.Add(ExportTexture(texture,slice,directory));
                    else report.textures.Add(ExportTexture(texture,0,directory));
                }
                File.WriteAllText(Path.Combine(directory,"Batteries-reference.json"),DiagnosticJson.Serialize(report));
                File.WriteAllText(Path.Combine(directory,"README.txt"),"Native battery reference capture. Batteries-reference.json contains geometry in metres, original UVs, submeshes, raw vertex streams with attribute layouts (normals/tangents remain in mesh-local coordinates; meshToPrefab records the transform), shader/material properties, renderer property blocks and capacity, full hierarchy, construction-stage renderer paths, original indicator paths/material names, switch pivot and OFF/ON angles. Texture filenames match recorded instance IDs. Texture arrays export the used index values plus Red/Black/White slices, not every unused palette layer. PNG data is RGBA32 GPU readback; original texture format is recorded in the manifest. Read errors are recorded per texture/mesh; this is not a complete export when errors exist. This capture does not change source prefabs, the DIN model, stored charge or live wiring.");
                System.IO.Compression.ZipFile.CreateFromDirectory(directory,zip);
                ModDiagnostics.Log("[Modular Switchboards] BATTERY REFERENCE upload this file: "+zip+"; prefabs="+report.batteries.Count+"; mesh errors="+report.errors.Count+"; texture errors="+report.textures.Count(t=>t.error!=null));
            }
            catch(Exception ex){Debug.LogError("[Modular Switchboards] BATTERY REFERENCE failed: "+ex);}
        }
        private static void WriteObj(string path,Vector3[] vertices,Vector2[] uv,int[][] groups)
        {
            using(var output=new StreamWriter(path))
            {
                output.WriteLine("# Native prefab-local metres; material groups match Batteries-reference.json");
                foreach(var p in vertices)output.WriteLine(FormattableString.Invariant($"v {p.x:R} {p.y:R} {p.z:R}"));
                foreach(var p in uv)output.WriteLine(FormattableString.Invariant($"vt {p.x:R} {p.y:R}"));
                for(int g=0;g<groups.Length;g++){output.WriteLine("g submesh_"+g);var ids=groups[g];for(int i=0;i<ids.Length;i+=3)
                {int a=ids[i]+1,b=ids[i+1]+1,c=ids[i+2]+1;output.WriteLine(uv.Length==vertices.Length?$"f {a}/{a} {b}/{b} {c}/{c}":$"f {a} {b} {c}");}}
            }
        }
        private static void AddSlice(HashSet<int> slices,float value){if(!float.IsNaN(value)&&!float.IsInfinity(value)&&value>=0&&value<2048&&Math.Abs(value-Math.Round(value))<.001f)slices.Add((int)Math.Round(value));}
        private static List<Property> Properties(Material material,MaterialPropertyBlock block,Dictionary<int,Texture> textures,HashSet<int> slices)
        {
            var result=new List<Property>();var shader=material.shader;
            for(int i=0;i<shader.GetPropertyCount();i++)
            {
                string name=shader.GetPropertyName(i);int id=Shader.PropertyToID(name);var type=shader.GetPropertyType(i);var p=new Property{name=name,type=type.ToString(),blockHasProperty=block.HasProperty(id)};result.Add(p);
                if(type==ShaderPropertyType.Texture)
                {
                    var texture=material.GetTexture(id);var overridden=block.GetTexture(id);p.texture=texture?.name;p.blockTexture=overridden?.name;p.textureId=texture==null?0:texture.GetInstanceID();p.blockTextureId=overridden==null?0:overridden.GetInstanceID();p.scale=material.GetTextureScale(name);p.offset=material.GetTextureOffset(name);
                    if(texture!=null)textures[texture.GetInstanceID()]=texture;if(overridden!=null)textures[overridden.GetInstanceID()]=overridden;
                }
                else if(type==ShaderPropertyType.Color){p.color=material.GetColor(id);if(p.blockHasProperty)p.blockColor=block.GetColor(id);}
                else if(type==ShaderPropertyType.Vector){p.vector=material.GetVector(id);if(p.blockHasProperty)p.blockVector=block.GetVector(id);}
                else if(type==ShaderPropertyType.Float||type==ShaderPropertyType.Range){p.value=material.GetFloat(id);if(p.blockHasProperty)p.blockFloat=block.GetFloat(id);if(name.IndexOf("Index",StringComparison.OrdinalIgnoreCase)>=0){AddSlice(slices,p.value);if(p.blockHasProperty)AddSlice(slices,p.blockFloat);}}
            }
            return result;
        }
        private static TextureData ExportTexture(Texture texture,int slice,string directory)
        {
            var info=new TextureData{id=texture.GetInstanceID(),name=texture.name,width=texture.width,height=texture.height,slice=slice,dimension=texture.dimension.ToString(),format=texture.graphicsFormat.ToString()};Texture2D readable=null;
            try
            {
                if(!(texture is Texture2D)&&!(texture is Texture2DArray))throw new InvalidOperationException("Unsupported texture dimension");
                if(texture.width<=0||texture.height<=0||texture.width>8192||texture.height>8192)throw new InvalidOperationException("Texture size exceeds readback bound");
                if(!SystemInfo.supportsAsyncGPUReadback)throw new InvalidOperationException("GPU texture readback unsupported on this renderer");
                var read=AsyncGPUReadback.Request(texture,0,0,texture.width,0,texture.height,slice,1,TextureFormat.RGBA32);read.WaitForCompletion();if(read.hasError)throw new InvalidOperationException("GPU readback failed");
                var pixels=read.GetData<byte>().ToArray();readable=new Texture2D(texture.width,texture.height,TextureFormat.RGBA32,false);readable.LoadRawTextureData(pixels);readable.Apply();
                string file="texture-"+texture.GetInstanceID()+"-slice-"+slice+".png";File.WriteAllBytes(Path.Combine(directory,file),readable.EncodeToPNG());info.file=file;
            }
            catch(Exception ex){info.error=ex.Message;}
            finally{if(readable!=null)UnityEngine.Object.Destroy(readable);}
            return info;
        }
        private static string NodePath(Transform current,Transform root){var names=new List<string>();while(current!=null){names.Add(current==root?current.name:current.name+"["+current.GetSiblingIndex()+"]");if(current==root)break;current=current.parent;}names.Reverse();return string.Join("/",names);}
    }
}
