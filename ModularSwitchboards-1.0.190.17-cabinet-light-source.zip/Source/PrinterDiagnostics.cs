using System;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using Assets.Scripts;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Electrical;
using Assets.Scripts.Networking;
using HarmonyLib;
using UnityEngine;
namespace ModularSwitchboards
{
    // Observe only. Never consume an interaction, change a recipe or suppress an exception.
    internal static class PrinterDiagnostics
    {
        internal static void Configure(Harmony harmony)
        {
            harmony.Patch(AccessTools.Method(typeof(SimpleFabricatorBase),"InputFinished"),prefix:new HarmonyMethod(typeof(PrinterDiagnostics),nameof(Selection)));
            harmony.Patch(AccessTools.Method(typeof(SetRecipeMessage),"Process"),prefix:new HarmonyMethod(typeof(PrinterDiagnostics),nameof(Receive)),finalizer:new HarmonyMethod(typeof(PrinterDiagnostics),nameof(ReceiveError)));
            harmony.Patch(AccessTools.Method(typeof(SimpleFabricatorBase),"InteractWith"),prefix:new HarmonyMethod(typeof(PrinterDiagnostics),nameof(Interaction)),finalizer:new HarmonyMethod(typeof(PrinterDiagnostics),nameof(InteractionError)));
        }
        internal static void Catalogue()
        {
            Observe(()=>
            {
                var recipes=ElectronicsPrinter.RecipeComparable;
                var rows=recipes.DynamicThings.Select(p=>p.PrefabName+":"+p.PrefabHash+":"+(int)p.RecipeTier).ToArray();
                ModDiagnostics.Log(Prefix+"catalogue count="+recipes.AllRecipes.Count+"; listed="+rows.Length+"; order="+Digest(string.Join("\n",rows))+"; recipeHash="+recipes.CurrentRecipeHash+"; entries="+string.Join(",",rows));
            });
        }
        private static string Prefix=>"[Modular Switchboards] Printer diagnostic "+SwitchboardsMod.Version+"; headless="+ServerGraphics.Headless+"; simulation="+GameManager.RunSimulation+"; ";
        internal static string Digest(string value)
        {
            using(var hash=SHA256.Create())return BitConverter.ToString(hash.ComputeHash(Encoding.UTF8.GetBytes(value))).Replace("-","");
        }
        private static void Selection(SimpleFabricatorBase __instance,DynamicThing __0)
        {
            if(!(__instance is ElectronicsPrinter))return;
            Observe(()=>ModDiagnostics.Log(Prefix+"selection target="+__instance.ReferenceId+"; selected="+(__0==null?"null":__0.PrefabName)+"; index="+__instance.ValidDynamicThings.IndexOf(__0)+"; "+State(__instance)));
        }
        private static void Receive(SetRecipeMessage __instance)
        {
            Observe(()=>{var p=Thing.Find<ElectronicsPrinter>(__instance.TargetId);if(p!=null)ModDiagnostics.Log(Prefix+"server selection target="+p.ReferenceId+"; receivedIndex="+__instance.RecipeIndex+"; receivedProduct="+p.GetProduct(__instance.RecipeIndex)?.PrefabName+"; "+State(p));});
        }
        private static Exception ReceiveError(SetRecipeMessage __instance,Exception __exception)
        {
            if(__exception!=null)Observe(()=>{if(Thing.Find<ElectronicsPrinter>(__instance.TargetId)!=null)Debug.LogError(Prefix+"selection exception: "+__exception);});
            return __exception;
        }
        private static void Interaction(SimpleFabricatorBase __instance,Interactable __0,bool __2)
        {
            if(!(__instance is ElectronicsPrinter)||!__2||__0==null||__0.Action!=InteractableType.Activate)return;
            Observe(()=>ModDiagnostics.Log(Prefix+"print interaction; target="+__instance.ReferenceId+"; "+State(__instance)));
        }
        private static Exception InteractionError(SimpleFabricatorBase __instance,Exception __exception)
        {
            if(__instance is ElectronicsPrinter&&__exception!=null)Observe(()=>Debug.LogError(Prefix+"interaction exception: "+__exception));
            return __exception;
        }
        private static string State(SimpleFabricatorBase p)
        {
            var product=p.GetProduct(p.CurrentIndex);var recipe=p.GetRecipe();
            return "index="+p.CurrentIndex+"; product="+product?.PrefabName+"; valid="+p.ValidDynamicThings.Count+"; order="+Digest(string.Join("\n",p.ValidDynamicThings.Select(x=>x.PrefabName)))+"; tier="+p.CurrentTier+"; on="+p.OnOff+"; powered="+p.Powered+"; activate="+p.Activate+"; error="+p.Error+"; completed="+p.IsStructureCompleted+"; canManufacture="+p.CurrentBuildState.CanManufacture+"; ingredients="+p.ReagentMixture.Contains(recipe);
        }
        private static void Observe(Action action)
        {
            try{action();}catch(Exception ex){Debug.LogWarning("[Modular Switchboards] Printer diagnostic unavailable: "+ex.GetType().Name+": "+ex.Message);}
        }
    }
}
