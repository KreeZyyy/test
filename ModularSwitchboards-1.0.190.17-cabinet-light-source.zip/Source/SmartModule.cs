using System;
using System.Collections;
using System.Collections.Generic;
using Assets.Scripts.UI;
using HarmonyLib;
using System.Linq;
using System.Xml.Serialization;
using Assets.Scripts;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Networking;
using Assets.Scripts.Networks;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Electrical;
using Assets.Scripts.Objects.Pipes;
using Assets.Scripts.Objects.Items;
using Assets.Scripts.Objects.Motherboards;
using Cysharp.Threading.Tasks;
using LibConstruct;
using UnityEngine;
namespace ModularSwitchboards
{
    public sealed class SmartModuleSaveData:LogicBaseSaveData
    {
        [XmlElement]public PlacementBoardStructureSaveData RailBoard;
        [XmlElement]public int CodeError;
        [XmlElement]public int ConstructionVersion;
        [XmlElement]public ulong LastEditor;
        [XmlElement]public bool CustomDisplayText;
        [XmlElement]public int DisplayColor=(int)ColorType.Green;
    }
    // One IC housing device with an integrated native LED surface. Keep the
    // LogicDisplay base for its renderer, Mode/Setting/Color and existing saves;
    // the holder contract below owns chip execution, errors and stack access.
    public sealed class SmartModule:LogicDisplay,IPlacementBoardStructure,ICircuitHolder,IMemoryReadable,IMemoryWritable
    {
        public PlacementBoard Board{get;set;}
        public PlacementBoard.BoardCell[] BoardCells{get;set;}
        [SerializeField]internal Mesh UnfinishedCoreBody,DisplayCoreBody,FinishedCoreBody;
        internal bool CoilAssembly(DynamicThing item)=>CurrentBuildStateIndex==1&&!IsCursor&&!IsStructureCompleted&&CabinetCableCoils.IsHeavy(item);
        public int ModuleWidth=>DinSmartLayout.Slots;
        public SwitchboardCabinet Cabinet=>(Board?.PrimaryHost as DinRail)?.Board?.PrimaryHost as SwitchboardCabinet;
        public ProgrammableChip Chip=>IsStructureCompleted&&Slots.Count==1?Slots[0].Get() as ProgrammableChip:null;
        public ulong LastEditedBy{get;set;}
        public override string[] ModeStrings=>SmartDisplayModes.Names;
        private CabinetWiring lastWiring;
        internal CabinetWiring AttachedWiring
        {
            get{var current=Cabinet?.Wiring;if(current!=null)lastWiring=current;return current!=null?current:lastWiring!=null?lastWiring:null;}
        }
        internal Cable BoundCable;
        internal Cable[] BoundDataCables=Array.Empty<Cable>();
        internal CableNetwork[] BoundDataNetworks=Array.Empty<CableNetwork>();
        internal Cable BoundPowerCable;
        internal CableNetwork BoundPowerNetwork;
        internal CableNetwork BoundNetwork;
        private SmartRunState runStatus;
        private SmartOutputSession outputSession;
        internal bool OutputsReady=>!GameManager.RunSimulation||(outputSession?.Ready??false);
        private int statusErrorLine=-1;
        private string statusText;
        private char[] statusGlyphs;
        private bool customDisplayText;
        private int displayColor=(int)ColorType.Green;
        private static readonly System.Reflection.FieldInfo CompileErrorLine=AccessTools.Field(typeof(ProgrammableChip),"_compileErrorLineNumber");
        internal SmartRunState RunStatus=>!IsStructureCompleted||!Powered||!OnOff?SmartRunState.Off:runStatus;
        private void RefreshRunStatus()
        {
            if(!NetworkManager.IsServer)return;
            var chip=Chip;
            bool lua=SmartLuaRuntime.IsLua(chip);
            bool fault=chip!=null&&((!lua&&chip.CompilationError)||codeError!=0||!string.IsNullOrEmpty(lua?SmartLuaRuntime.Error(chip):chip.GetErrorCode()));
            var status=SmartRunStatus.Evaluate(Powered,OnOff,chip!=null,fault,chip!=null&&!string.IsNullOrWhiteSpace(chip.GetSourceCode().ToString()));
            int line=-1;
            if(fault&&chip!=null)
            {
                if(lua)line=SmartStatusDisplay.LuaLine(SmartLuaRuntime.Error(chip));
                else if(chip.CompilationError&&CompileErrorLine?.GetValue(chip) is ushort compileLine)line=compileLine;
                else if(!string.IsNullOrWhiteSpace(chip.GetErrorCode())&&int.TryParse(chip.ErrorLineNumberString,out var nativeLine))line=nativeLine;
            }
            if(status!=runStatus||line!=statusErrorLine){runStatus=status;statusErrorLine=line;NetworkUpdateFlags|=512;}
        }
        private void RefreshStatusDisplay()
        {
            // Fault status always owns the surface. During healthy execution the
            // chip may replace WORK with packed ASCII text written to Setting.
            var state=RunStatus;
            bool custom=state==SmartRunState.Running&&customDisplayText&&Mode!=SmartDisplayModes.AutoRun;
            var swatch=GameManager.GetColorSwatch(state==SmartRunState.Fault?(int)ColorType.Orange:custom?displayColor:(int)ColorType.Green);
            if(swatch?.Emissive!=null)DigitOn=swatch.Emissive;
            var text=SmartStatusDisplay.Text(state,statusErrorLine,custom?SmartNativeDisplayText.Read(this):null);
            if(custom)
                text=SmartStatusDisplay.Fit(text,(int)(MaxPixelWidth/GameManager.DigitPixel),ch=>{var glyph=GameManager.GetDigitMesh(ch);return glyph==null?-1:glyph.PixelWidth+1;},Mode==SmartDisplayModes.String);
            if(text!=statusText){statusText=text;statusGlyphs=text.ToCharArray();}
            SetDisplay(statusGlyphs);
        }
        public override void OnSettingChanged()
        {
            base.OnSettingChanged();
            if(GameManager.IsMainThread&&DigitTransform!=null&&GameManager.GameState==GameState.Running)RefreshStatusDisplay();
        }
        public override void OnInteractableUpdated(Interactable interactable)
        {
            base.OnInteractableUpdated(interactable);
            if(interactable.Action==InteractableType.OnOff)RefreshOutputSession();
            if(GameManager.IsMainThread&&DigitTransform!=null&&GameManager.GameState==GameState.Running)RefreshStatusDisplay();
        }
        private void SetCustomDisplayText(bool enabled)
        {
            if(customDisplayText==enabled)return;
            customDisplayText=enabled;
            if(NetworkManager.IsServer)NetworkUpdateFlags|=512;
        }
        internal void RecordDisplayWrite()
        {
            if(customDisplayText)return;
            SetCustomDisplayText(true);
            base.OnSettingChanged();
            RefreshStatusDisplay();
        }
        public override PassiveTooltip GetPassiveTooltip(Collider collider)
        {
            var tip=base.GetPassiveTooltip(collider);var chip=Chip;bool lua=SmartLuaRuntime.IsLua(chip);string detail=chip==null?"":lua?SmartLuaRuntime.Error(chip):chip.GetErrorCode();
            string state=RunStatus==SmartRunState.Running?"IC10 running":RunStatus==SmartRunState.Fault?"IC10 error":!Powered?"No power":!OnOff?"OFF":chip==null?"No IC10 installed":"IC10 idle";
            if(lua)state=state.Replace("IC10","Lua");
            tip.Extended=state+(string.IsNullOrWhiteSpace(detail)?"":"\n"+detail.Trim())+"\nSmart bus: "+SmartBus.Outputs(this).Count()+" Net modules, "+SmartBus.Networks(this).Length+" data networks, "+SmartBus.LocalInputs(this).Count()+" local Dial inputs; "+SmartBus.AddressedOutputs(this).Count()+" Outputs (d0–d5: A1 or door display). Core IN is power only.";return tip;
        }
        public override void BuildUpdate(RocketBinaryWriter writer,ushort type){base.BuildUpdate(writer,type);if(Thing.IsNetworkUpdateRequired(512u,type)){writer.WriteByte((byte)runStatus);writer.WriteInt32(statusErrorLine);writer.WriteBoolean(customDisplayText);writer.WriteInt32(displayColor);}}
        public override void ProcessUpdate(RocketBinaryReader reader,ushort type){base.ProcessUpdate(reader,type);if(Thing.IsNetworkUpdateRequired(512u,type)){runStatus=(SmartRunState)reader.ReadByte();statusErrorLine=reader.ReadInt32();customDisplayText=reader.ReadBoolean();displayColor=reader.ReadInt32();}}
        private float nextLink;
        private int codeError;
        
        private float nextStatus;
        public override void Awake(){PrefabAudioOwner.PrepareInstance(this);base.Awake();BoardStructureHooks.Awake(this);}
        public override Grid3 GetLocalGrid()=>Board==null?default(Grid3):Board.WorldToGrid(transform.position);
        public override CanConstructInfo CanConstruct()
        {
            if(IsCursor){MountPlacement.AfterRaycast();MountBoardResolver.Resolve(CursorManager.Instance);}
            if(!(Board is DinModuleBoard board))return CanConstructInfo.InvalidPlacement("Aim at an available four-position span on a DIN rail.");
            var p=board.WorldToGrid(transform.position);
            if(IsCursor)
            {
                if(MountPlacement.TryLockedGrid(this,board,out var locked))p=locked;
                else p=new Grid3(DoorModuleLayout.SnapSlot(p.x,DinLayout.FirstModuleSlot*10,(DinLayout.FirstModuleSlot+((DinRail)board.PrimaryHost).ModuleCapacity-4)*10),0,0);
                PlacementBoard.CursorGrid=p;PlacementBoard.CursorRotation=0;transform.SetPositionAndRotation(board.GridToWorld(p),board.IndexToRotation(0));
            }
            return board.CanPlace(p,board.RotationToIndex(transform.rotation),4)?CanConstructInfo.ValidPlacement:CanConstructInfo.InvalidPlacement("Choose four free DIN positions.");
        }
        public override DelayedActionInstance AttackWith(Attack attack,bool doAction=true)
        {
            // Status glyph colours are controlled separately from housing paint.
            // Keep the native spray interaction and its normal consumption guards.
            if(IsPaintable&&attack.SourceItem is ISprayer sprayer)return ISprayer.DoSpray(this,sprayer,doAction);
            return base.AttackWith(attack,doAction);
        }
        protected override CanConstructInfo CanDeconstruct()
            =>Cabinet==null||!Cabinet.CanAccessModules?CanConstructInfo.InvalidPlacement("Open the cabinet and remove the cover first."):
              Chip!=null?CanConstructInfo.InvalidPlacement("Remove the IC10 first."):
              SmartBus.HasLeftNeighbour(this,ModuleWidth)?CanConstructInfo.InvalidPlacement("Remove the Smart extensions from the left first."):
              !ModuleDismantle.CanRefund(this)?CanConstructInfo.InvalidPlacement("Cable coil prefab unavailable."):CanConstructInfo.ValidPlacement;
        public override void OnDeregistered(){CircuitHolders.Deregister(this);if(GameManager.RunSimulation&&SmartLuaRuntime.IsLua(Chip))SmartLuaRuntime.SetActivity(Chip,true);AttachedWiring?.Power.RemoveOwnTransformer(ReferenceId);ModuleDismantle.Unlink(this);SmartModuleNetwork.Unbind(this);base.OnDeregistered();if(Board!=null)BoardStructureHooks.OnDeregistered(this);}
        public override void OnDestroy(){AttachedWiring?.Power.RemoveOwnTransformer(ReferenceId);ModuleDismantle.Unlink(this);if(GameManager.RunSimulation)SmartLuaRuntime.Detach(Chip);SmartModuleNetwork.Unbind(this);base.OnDestroy();}
        public override void OnRegistered(Cell cell){base.OnRegistered(cell);RegisterExecution();SmartChipAccess.Refresh(this);}
        public override void OnFinishedLoad(){base.OnFinishedLoad();outputSession=null;RegisterExecution();}
        private void RegisterExecution()
        {
            // Device.Awake normally registers ICircuitHolder. Board placement may
            // finish after cursor setup, so also bind once the placed/load instance is ready.
            // Native DensePoolReference prevents duplicate registration.
            if(!IsCursor&&GameManager.GameState!=GameState.None)CircuitHolders.Register(this);
        }
        private void LateUpdate()
        {
            if(IsCursor)return;
            RefreshStatusDisplay();
            if(Cabinet!=null)lastWiring=Cabinet.Wiring;
            if(Cabinet==null){RefreshServicePower();if(BoundNetwork!=null||BoundPowerNetwork!=null)SmartModuleNetwork.Unbind(this);return;}
            if(Time.unscaledTime>=nextLink){nextLink=Time.unscaledTime+.15f;SmartModuleNetwork.Refresh(this);RefreshServicePower();}
            if(Time.unscaledTime>=nextStatus){nextStatus=Time.unscaledTime+.1f;RefreshRunStatus();if(Chip==null)ResetOutputCommands();}
            foreach(var hit in BuildStates[0].Colliders)if(hit!=null)hit.enabled=Cabinet.IsOpen;
            SmartChipAccess.Refresh(this);
        }
        public override void UpdateStateVisualizer(bool visualOnly=false)
        {
            base.UpdateStateVisualizer(visualOnly);
            if(CurrentBuildStateIndex>=0&&!IsCursor&&transform.Find("DinBreakerModel")!=null)
            {
                SmartChipAccess.Refresh(this);
                SmartCoreConstruction.RefreshBody(this);
                FittedModelCollider.Rebuild(this);
            }
        }
        internal void ClearSupplyPower(){SetPower(null,false);RefreshOutputSession();}
        public override float GetUsedPower(CableNetwork network)=>-1f;
        public override bool AllowSetPower(CableNetwork network)=>false;
        protected override void AssessPower(CableNetwork network,bool isOn)=>RefreshServicePower();
        private void RefreshServicePower()
        {
            if(!GameManager.RunSimulation)return;
            SetPower(null,!IsCursor&&!IsBeingDestroyed&&IsStructureCompleted&&OnOff&&Cabinet!=null&&Cabinet.Wiring.Power.ServicePowered(ReferenceId));
            RefreshOutputSession();
        }
        public override void OnAddCableNetwork(CableNetwork network){}
        public override void OnRemoveCableNetwork(CableNetwork network){if(network==BoundPowerNetwork)AssessPower(null,false);}
        public override bool PreventInteraction(out DelayedActionInstance failure,Interactable interactable,Interaction interaction)
        {
            if(!IsStructureCompleted){failure=new DelayedActionInstance{Duration=0f}.Fail("Complete the Core before using its controls or IC10 slot.");return true;}
            if(interactable.Action==InteractableType.Slot1&&(!IsStructureCompleted||Cabinet==null||!Cabinet.CanAccessModules))
            {failure=new DelayedActionInstance{Duration=0f}.Fail("Complete the Core and open the cabinet before inserting IC10.");return true;}
            return base.PreventInteraction(out failure,interactable,interaction);
        }
        public override DelayedActionInstance InteractWith(Interactable interactable,Interaction interaction,bool doAction=true)
        {
            if(!IsStructureCompleted)return new DelayedActionInstance{Duration=0f}.Fail("Complete the Core before using its controls or IC10 slot.");
            if(interactable.Action==InteractableType.Slot1&&(!IsStructureCompleted||Cabinet==null||!Cabinet.CanAccessModules))
                return new DelayedActionInstance{Duration=0f}.Fail("Open the cabinet and remove the cover first.");
            var result=base.InteractWith(interactable,interaction,doAction);
            if(interactable.Action==InteractableType.Slot1&&result!=null&&Chip!=null)
            {
                var error=Chip.GetErrorCode();
                result.ExtendedMessage=SmartChipTooltip.Once(result.ExtendedMessage,error);
                var originalState=result.GetStateMessage();
                var state=SmartChipTooltip.Once(originalState,error,result.ExtendedMessage);
                if(state!=originalState)
                {
                    result.ClearStateMessage();
                    if(!string.IsNullOrEmpty(state))result.AppendStateMessage(state.TrimEnd('\r','\n'));
                }
            }
            return result;
        }
        public override void OnChildEnterInventory(DynamicThing child){base.OnChildEnterInventory(child);if(GameManager.RunSimulation&&child is ProgrammableChip){SetCustomDisplayText(false);ResetOutputCommands();Chip.Reset();ClearError();}}
        public override void OnChildExitInventory(DynamicThing child){if(GameManager.RunSimulation&&child is ProgrammableChip lua)SmartLuaRuntime.Detach(lua);base.OnChildExitInventory(child);if(GameManager.RunSimulation&&child is ProgrammableChip chip){chip.Reset();SetCustomDisplayText(false);ResetOutputCommands();ClearError();}}
        public void ClearError()=>RaiseError(0);
        public void RaiseError(int state){codeError=state;if(GameManager.RunSimulation&&InteractError!=null)OnServer.Interact(InteractError,state==0?0:1);}
        public bool IsValidIndex(int index)=>index==int.MaxValue||SmartOutputAddresses.Valid(index);
        public ILogicable GetLogicableFromIndex(int index,int networkIndex=int.MinValue)=>index==int.MaxValue?(networkIndex==int.MinValue?this:SmartBus.NetworkAt(this,networkIndex)):index>=0&&networkIndex==int.MinValue?SmartBus.OutputAt(this,index):null;
        public ILogicable GetLogicableFromId(int id,int networkIndex=int.MinValue)
        {
            if(id==ReferenceId)return networkIndex==int.MinValue?this:SmartBus.NetworkAt(this,networkIndex);
            var device=Referencable.Find<Device>(id);
            return device!=null&&SmartBus.Devices(this).Any(d=>d==device)?networkIndex==int.MinValue?(ILogicable)device:device.GetNetwork(networkIndex):null;
        }
        public List<ILogicable> GetBatchOutput()=>SmartBus.Devices(this).Cast<ILogicable>().ToList();
        public List<LogicBinding> GetLogicBindings()=>new[]{new LogicBinding("HOUSING")}.Concat(Enumerable.Range(0,SmartOutputAddresses.Count).Select(i=>new LogicBinding(i,"SCREW_"+i))).ToList();
        public void SetDeviceLabel(int index,string label){}
        public void HasPut(){}
        public UniTask HaltAndCatchFire(){if(GameManager.RunSimulation)OnServer.Interact(InteractOnOff,0);return UniTask.CompletedTask;}
        private void RefreshOutputSession()
        {
            if(!GameManager.RunSimulation||IsCursor||GameManager.GameState!=GameState.Running)return;
            if(outputSession==null)outputSession=new SmartOutputSession();
            bool ready=!IsBeingDestroyed&&IsStructureCompleted&&Cabinet!=null&&Powered&&OnOff&&Chip!=null&&GameManager.GameState==GameState.Running;
            outputSession.Refresh(ready,()=>{
                ResetOutputCommands();
                if(ready){Chip?.Reset();ClearError();}
            });
        }
        private void ResetOutputCommands()
        {
            if(GameManager.RunSimulation)foreach(var output in SmartBus.PowerOutputs(this).ToArray())output.ResetProgramCommand();
        }
        public string GetSourceCode()=>Chip==null?"":Chip.GetSourceCode();
        public void SetSourceCode(string source){if(Chip!=null){SetCustomDisplayText(false);ResetOutputCommands();Chip.SetSourceCode(source,this);Chip.SendUpdate();}}
        public void Execute()
        {
            
            if(!GameManager.RunSimulation)return;
            // Called by ElectricityManager -> CircuitHolders, exactly as IC Housing.
            // Refresh our paid internal supply rather than requiring a native power cable.
            RefreshServicePower();
            var chip=Chip;
            bool inactive=IsCursor||!IsStructureCompleted||Cabinet==null||!OnOff||!Powered||GameManager.GameState!=GameState.Running||WorldManager.IsGamePaused||chip==null;
            bool lua=SmartLuaRuntime.IsLua(chip);
            if(lua)SmartLuaRuntime.SetActivity(chip,inactive);
            if(inactive)return;
            if(!lua&&chip.CompilationError)return;
            if(lua&&!SmartLuaRuntime.Ready)return;
            // StationeersLua patches this native entry point, including its own
            // save/compile/pause guards and GameTickSpeedSeconds. Do not tick its VM twice.
            chip.Execute(CircuitHousing.RUN_COUNT);
            
        }
        public override bool CanLogicRead(LogicType type)=>type==LogicType.Color||type==LogicType.Mode||type==LogicType.LineNumber||base.CanLogicRead(type);
        public override bool CanLogicWrite(LogicType type)=>type==LogicType.Color||type==LogicType.Mode||type==LogicType.LineNumber||base.CanLogicWrite(type);
        public override double GetLogicValue(LogicType type)=>type==LogicType.RequiredPower?(IsStructureCompleted&&OnOff?UsedPower:0):type==LogicType.Color?displayColor:type==LogicType.LineNumber?(Chip==null?-1:Chip.LineNumber):base.GetLogicValue(type);
        public override void SetLogicValue(LogicType type,double value)
        {
            if(type==LogicType.Color)
            {
                if(!double.IsNaN(value)&&!double.IsInfinity(value)&&value>=int.MinValue&&value<=int.MaxValue&&GameManager.IsValidColor((int)value))
                {
                    displayColor=(int)value;
                    if(NetworkManager.IsServer)NetworkUpdateFlags|=512;
                }
                return;
            }
            if(type==LogicType.Mode&&value==SmartDisplayModes.AutoRun)SetCustomDisplayText(false);
            if(type==LogicType.Setting)SetCustomDisplayText(true);
            if(type==LogicType.LineNumber){if(Chip!=null)Chip.LineNumber=(uint)value;}
            else base.SetLogicValue(type,value);
        }
        // Native housing stack contract: expose the installed chip's memory,
        // never a second independent memory buffer on the display.
        public double ReadMemory(int address)
        {
            var chip=Chip;if(chip==null)throw new NullReferenceException("No programmable chip installed.");
            return chip.ReadMemory(address);
        }
        public void WriteMemory(int address,double value)
        {
            var chip=Chip;if(chip==null)throw new NullReferenceException("No programmable chip installed.");
            chip.WriteMemory(address,value);
        }
        public void ClearMemory()
        {
            var chip=Chip;if(chip==null)throw new NullReferenceException("No programmable chip installed.");
            chip.ClearMemory();
        }
        public int GetStackSize()=>Chip?.GetStackSize()??0;
        public override bool CanLogicRead(LogicSlotType type,int slotId)
            =>slotId>=0&&slotId<Slots.Count&&(type==LogicSlotType.LineNumber||base.CanLogicRead(type,slotId));
        public override double GetLogicValue(LogicSlotType type,int slotId)
        {
            if(slotId<0||slotId>=Slots.Count)return double.NaN;
            if(type==LogicSlotType.LineNumber&&Slots[slotId].Get() is ILogicable chip)return chip.GetLogicValue(LogicType.LineNumber);
            return base.GetLogicValue(type,slotId);
        }
        public override ThingSaveData SerializeSave(){ThingSaveData data=new SmartModuleSaveData();InitialiseSaveData(ref data);return data;}
        protected override void InitialiseSaveData(ref ThingSaveData data){base.InitialiseSaveData(ref data);if(data is SmartModuleSaveData save){save.ConstructionVersion=1;if(Board!=null)save.RailBoard=BoardStructureHooks.SerializeSave(this);save.CodeError=codeError;save.LastEditor=LastEditedBy;save.CustomDisplayText=customDisplayText;save.DisplayColor=displayColor;}}
        public override void DeserializeSave(ThingSaveData data){if(data is SmartModuleSaveData oldCore&&oldCore.ConstructionVersion<1&&oldCore.CurrentBuildState==0)oldCore.CurrentBuildState=2;else if(data is DinBreakerSaveData oldModule&&oldModule.CurrentBuildState==0)oldModule.CurrentBuildState=2;base.DeserializeSave(data);if(data is SmartModuleSaveData save){codeError=save.CodeError;LastEditedBy=save.LastEditor;customDisplayText=save.CustomDisplayText;displayColor=GameManager.IsValidColor(save.DisplayColor)?save.DisplayColor:(int)ColorType.Green;if(save.RailBoard!=null)BoardStructureHooks.DeserializeSave(this,save.RailBoard);}else if(data is DinBreakerSaveData old){OnOff=true;if(old.RailBoard!=null)BoardStructureHooks.DeserializeSave(this,old.RailBoard);}}
        public override void SerializeOnJoin(RocketBinaryWriter writer){SmartChipAccess.PrepareForJoin(this);base.SerializeOnJoin(writer);BoardStructureHooks.SerializeOnJoin(writer,this);writer.WriteInt32(codeError);writer.WriteByte((byte)RunStatus);writer.WriteInt32(statusErrorLine);writer.WriteBoolean(customDisplayText);writer.WriteInt32(displayColor);}
        public override void DeserializeOnJoin(RocketBinaryReader reader){SmartChipAccess.PrepareForJoin(this);base.DeserializeOnJoin(reader);BoardStructureHooks.DeserializeOnJoin(reader,this);codeError=reader.ReadInt32();runStatus=(SmartRunState)reader.ReadByte();statusErrorLine=reader.ReadInt32();customDisplayText=reader.ReadBoolean();displayColor=reader.ReadInt32();}
    }
}
