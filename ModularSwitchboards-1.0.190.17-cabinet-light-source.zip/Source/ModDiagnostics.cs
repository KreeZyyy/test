using System.Diagnostics;
namespace ModularSwitchboards
{
    // Normal releases omit call sites and argument formatting entirely.
    // Errors and actionable warnings continue through Unity's original logger.
    internal static class ModDiagnostics
    {
        [Conditional("SWITCHBOARD_DIAGNOSTICS")]
        internal static void Log(object message){UnityEngine.Debug.Log(message);}
    }
}
