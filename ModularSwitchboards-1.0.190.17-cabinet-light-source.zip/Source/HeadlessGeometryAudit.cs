using System.Linq;using Assets.Scripts;using UnityEngine;
namespace ModularSwitchboards {
 internal static class HeadlessGeometryAudit {
  internal static void Log(){if(!ServerGraphics.Headless)return;var names=new[]{"StructureConsoleLED5","StructureAirConditioner"};foreach(var prefab in WorldManager.Instance.SourcePrefabs.Where(p=>p!=null&&names.Contains(p.PrefabName))){var unreadable=prefab.GetComponentsInChildren<MeshFilter>(true).Where(f=>f.sharedMesh!=null&&!f.sharedMesh.isReadable).Select(f=>f.sharedMesh.name).Distinct().ToArray();if(unreadable.Length>0)Debug.LogWarning("[Modular Switchboards] DS preflight: native mesh availability (informational; not a registration failure) for "+prefab.PrefabName+": "+string.Join(",",unreadable)+". Own IN and baked IC10 socket do not read these meshes.");}}
 }
}
