using System;
using System.Collections.Generic;
using System.Linq;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Electrical;
using Assets.Scripts.Networks;
using UnityEngine;

namespace ModularSwitchboards
{
    public enum CabinetTerminalId { Input=0, Output1=1, Output2=2,Output3=3,Input2=4,Input3=6 }

    // Fixed cabinet interfaces; front contacts are reserved for the custom wire system.
    public sealed class CabinetTerminalBlock : MonoBehaviour
    {
        public SwitchboardCabinet Owner;
        public CabinetTerminalId TerminalId;
        public ConnectionRole ExternalRole;
        public Vector3[] FrontContacts,RearContacts;
        public Vector3 SelectionPoint;
        public TextMesh Label;
        public BoxCollider TerminalCollider;
        public Connection ExternalConnection => Owner?.OpenEnds?.FirstOrDefault(c=>c.ConnectionRole==ExternalRole);
        // Resolve through this terminal's role, never Device.PowerCable (shared first-cable cache).
        public Cable ExternalCable => Owner!=null && !Owner.IsCursor && Owner.IsStructureCompleted && Owner.GridController!=null
            ? ExternalConnection?.GetCable() : null;
        public CableNetwork ExternalNetwork => ExternalCable?.CableNetwork;
        public Vector3 FrontContactWorld(int index)=>transform.TransformPoint(FrontContacts[index]);
        private void LateUpdate()
        {
            if(Label==null || Owner==null)return;
            var renderer=Label.GetComponent<MeshRenderer>();
            var size=renderer.localBounds.size;
            Label.transform.localScale=Vector3.one*Mathf.Min(.060f/Mathf.Max(.0001f,size.x),.012f/Mathf.Max(.0001f,size.y));
            var camera=Camera.main;
            bool visible=!Owner.IsCursor && Owner.IsStructureCompleted;
            if(visible && camera!=null)
            {
                var toLabel=Label.transform.position-camera.transform.position;
                visible=Vector3.Dot(transform.forward,-toLabel)>0f;

            }
            renderer.enabled=visible;
            DepthLabelText.Apply(Label);
        }
    }

    internal static class CabinetTerminalBlocks
    {
        internal const string RootName="CabinetTerminalBlocks";
        private static Mesh body,redTail,labelBorder,labelPlate;
        internal static readonly Vector3[] Centers={new Vector3(0,.211f,.014f),new Vector3(.108f,-.211f,.014f),new Vector3(-.108f,-.211f,.014f)};
        internal static readonly string[] Labels={"Input","Output 1","Output 2"};
        private static readonly ConnectionRole[] Roles={ConnectionRole.Input,ConnectionRole.Output,ConnectionRole.Output2};

        internal static void Install(SwitchboardCabinet cabinet)
        {
            if(body==null)
            {
                body=BuildBody();redTail=BuildTail(0);
                var border=new Geometry();border.Box(Vector3.zero,new Vector3(.068f,.022f,.0015f),.001f,3);labelBorder=border.Finish("Switchboards.TerminalLabelBorder");
                var plate=new Geometry();plate.Box(new Vector3(0,0,.001f),new Vector3(.065f,.019f,.001f),.0007f,1);labelPlate=plate.Finish("Switchboards.TerminalLabelPlate");
            }
            Font font=null;
            foreach(var name in new[]{"LegacyRuntime.ttf","Arial.ttf"})
            {try{font=Resources.GetBuiltinResource<Font>(name);}catch(Exception){}if(font!=null)break;}
            if(font==null)font=Resources.FindObjectsOfTypeAll<Font>().FirstOrDefault();
            if(font==null)Debug.LogWarning("[Modular Switchboards] Terminal font unavailable; terminal geometry retained without labels.");
            var shell=cabinet.transform.Find("SwitchboardModel/CompletedShell");
            var parent=new GameObject(RootName){layer=cabinet.gameObject.layer};parent.transform.SetParent(shell,false);
            for(int i=0;i<1+CabinetShape.OutputCount(cabinet.PrefabName);i++)
            {
                var root=new GameObject(CabinetPorts.SlotLabel(cabinet.PrefabName,i)){layer=cabinet.gameObject.layer};root.transform.SetParent(parent.transform,false);var center=CabinetLayout.Map(cabinet.PrefabName,CabinetShape.Terminal(cabinet.PrefabName,i));root.transform.localPosition=center;
                if(center.y>0)root.transform.localRotation=Quaternion.Euler(0,0,180f);
                var block=root.AddComponent<CabinetTerminalBlock>();block.Owner=cabinet;block.TerminalId=(CabinetTerminalId)CabinetPorts.SlotContact(cabinet.PrefabName,i);block.ExternalRole=i==0?CabinetPorts.SingleRole(cabinet.PrefabName):CabinetPorts.BranchRole(cabinet.PrefabName,i-1);
                block.FrontContacts=new[]{CabinetWiring.Vector(WireContactLayout.TerminalEntry)};
                block.SelectionPoint=CabinetWiring.Vector(WireContactLayout.TerminalAim);
                block.RearContacts=new[]{new Vector3(0,-.026f,-.006f)};
                Surface(root.transform,"TerminalInsulator",body);
                Surface(root.transform,"TerminalWireRed",redTail);
                var hit=root.AddComponent<BoxCollider>();hit.center=new Vector3(0,0,.016f);hit.size=new Vector3(.072f,.032f,.032f);
                block.TerminalCollider=hit;
                cabinet.BuildStates[1].Colliders.Add(hit);
                // Labels have their own unrotated frame, independent of the top terminal turn.
                var labelFrame=new GameObject("TerminalLabelFrame"){layer=cabinet.gameObject.layer};labelFrame.transform.SetParent(parent.transform,false);
                // Mount on the actual interior plate at z=.013, independently
                // of the terminal contact height. Border rear is local z=-.00075.
                const float plateFront=.013f, borderHalfDepth=.00075f;
                var labelOffset=CabinetShape.Medium(cabinet.PrefabName)&&i==2?new Vector3(0,-.035f*CabinetLayout.YSign(cabinet.PrefabName),0):i==0?new Vector3(.078f,0,0):new Vector3(-Mathf.Sign(center.x)*.071f,0,0);
                labelFrame.transform.localPosition=new Vector3(center.x+labelOffset.x,center.y+labelOffset.y,plateFront+borderHalfDepth);
                Surface(labelFrame.transform,"TerminalLabelBorder",labelBorder);
                Surface(labelFrame.transform,"TerminalLabelPlate",labelPlate);
                if(font!=null)
                {
                    var label=new GameObject("TerminalLabelText"){layer=cabinet.gameObject.layer};label.transform.SetParent(labelFrame.transform,false);
                    label.transform.localPosition=new Vector3(0,0,.0016f);label.transform.localRotation=Quaternion.Euler(0,180f,0);
                    var text=label.AddComponent<TextMesh>();text.font=font;text.fontSize=128;text.fontStyle=FontStyle.Bold;text.characterSize=.012f;
                    text.anchor=TextAnchor.MiddleCenter;text.alignment=TextAlignment.Center;text.richText=false;text.color=Color.black;text.text=CabinetPorts.SlotLabel(cabinet.PrefabName,i);
                    DepthLabelText.Apply(text);block.Label=text;
                }
            }
            ModDiagnostics.Log("[Modular Switchboards] Fixed terminal blocks installed for "+cabinet.PrefabName+": "+CabinetPorts.InputCount(cabinet.PrefabName)+" input(s), "+(CabinetPorts.Combiner(cabinet.PrefabName)?1:CabinetShape.OutputCount(cabinet.PrefabName))+" output(s); no internal bridge.");
        }

        private static void Surface(Transform parent,string name,Mesh mesh)
        {
            var go=new GameObject(name){layer=parent.gameObject.layer};go.transform.SetParent(parent,false);
            go.AddComponent<MeshFilter>().sharedMesh=mesh;var renderer=go.AddComponent<MeshRenderer>();renderer.sharedMaterials=CabinetGeometry.Materials;
            RestoreWireColor(renderer);
        }
        internal static bool RestoreWireColor(MeshRenderer renderer)
        {
            bool wire=renderer.name=="TerminalWireRed",plate=renderer.name=="TerminalLabelPlate";
            if(!wire&&!plate)return false;
            int role=wire?3:1;
            var block=new MaterialPropertyBlock();renderer.GetPropertyBlock(block,role);
            block.SetFloat(Thing.DiffuseIndexPropertyID,(int)(wire?Assets.Scripts.Objects.Motherboards.ColorType.Red:Assets.Scripts.Objects.Motherboards.ColorType.White));
            block.SetColor(Thing.EMISSION_COLOR,Color.black);renderer.SetPropertyBlock(block,role);return true;
        }
        private sealed class Geometry
        {
            internal readonly List<Vector3> Vertices=new List<Vector3>(),Normals=new List<Vector3>();
            internal readonly List<int>[] Triangles=Enumerable.Range(0,5).Select(_=>new List<int>()).ToArray();
            internal void Box(Vector3 center,Vector3 size,float radius,int role)=>RoundedGeometry.Box(Vertices,Normals,Triangles[role],center,size,radius);
            internal void Quad(Vector3 a,Vector3 b,Vector3 c,Vector3 d,Vector3 normal,int role)
            {
                int start=Vertices.Count;Vertices.AddRange(new[]{a,b,c,d});Normals.AddRange(new[]{normal,normal,normal,normal});Triangles[role].AddRange(new[]{start,start+1,start+2,start,start+2,start+3});
            }
            internal Mesh Finish(string name)
            {
                var mesh=new Mesh{name=name};mesh.SetVertices(Vertices);mesh.SetNormals(Normals);mesh.subMeshCount=5;
                for(int i=0;i<5;i++)mesh.SetTriangles(Triangles[i],i);CabinetGeometry.ApplyNativeUv(mesh);mesh.RecalculateBounds();return mesh;
            }
        }
        private static Mesh BuildBody()
        {
            var g=new Geometry();
            g.Box(new Vector3(0,0,.005f),new Vector3(.072f,.032f,.010f),.002f,3);
            foreach(float x in new[]{0f})
            {
                ContactCube(g,x);
            }
            return g.Finish("Switchboards.SingleTerminal");
        }
        internal static Mesh BuildBridgeCube()
        {
            var g=new Geometry();g.Box(new Vector3(0,0,.005f),new Vector3(.035f,.032f,.010f),.002f,3);
            ContactCube(g,0,true);return g.Finish("Switchboards.BridgeTerminalCube");
        }
        private static void ContactCube(Geometry g,float x,bool bridge=false)
        {
                g.Box(new Vector3(x,0,.019f),new Vector3(.031f,.030f,.026f),.002f,1);
                // Front screw head; the wire entry is on the end face, like a DIN terminal.
                Disk(g,new Vector3(x,WireContactLayout.TerminalScrewY,.0323f),.0045f,4);
                g.Box(new Vector3(x,WireContactLayout.TerminalScrewY,.0326f),new Vector3(.006f,.001f,.0005f),.0001f,3);
                foreach(int end in bridge?new[]{-1,1}:new[]{1})
                {
                    EndDisk(g,new Vector3(x,end*(WireContactLayout.TerminalEntryY+.0001f),WireContactLayout.TerminalEntryZ),bridge?.006f:.0042f,4,end);
                    EndDisk(g,new Vector3(x,end*(WireContactLayout.TerminalEntryY+.0002f),WireContactLayout.TerminalEntryZ),bridge?.0046f:.0032f,3,end);
                }
        }
        private static void Disk(Geometry g,Vector3 center,float radius,int role)
        {
            for(int i=0;i<16;i++)
            {
                float a=i*Mathf.PI/8,b=(i+1)*Mathf.PI/8;
                var p=center+new Vector3(Mathf.Cos(a)*radius,Mathf.Sin(a)*radius,0);
                var q=center+new Vector3(Mathf.Cos(b)*radius,Mathf.Sin(b)*radius,0);
                int start=g.Vertices.Count;g.Vertices.AddRange(new[]{center,p,q});g.Normals.AddRange(new[]{Vector3.forward,Vector3.forward,Vector3.forward});g.Triangles[role].AddRange(new[]{start,start+1,start+2});
            }
        }
        private static void EndDisk(Geometry g,Vector3 center,float radius,int role,int end=1)
        {
            for(int i=0;i<16;i++)
            {
                float a=i*Mathf.PI/8,b=(i+1)*Mathf.PI/8;
                var p=center+new Vector3(Mathf.Cos(a)*radius,0,Mathf.Sin(a)*radius);
                var q=center+new Vector3(Mathf.Cos(b)*radius,0,Mathf.Sin(b)*radius);
                int start=g.Vertices.Count;g.Vertices.AddRange(new[]{center,q,p});g.Normals.AddRange(new[]{Vector3.up*end,Vector3.up*end,Vector3.up*end});g.Triangles[role].AddRange(end>0?new[]{start,start+1,start+2}:new[]{start,start+2,start+1});
            }
        }
        private static Mesh BuildTail(float x)
        {
            var g=new Geometry();
            // Fixed insulated conductor disappears through the mounting plate.
            var path=new[]{new Vector3(x,-.010f,.014f),new Vector3(x,-.018f,.014f),new Vector3(x,-.023f,.011f),new Vector3(x,-.026f,.005f),new Vector3(x,-.026f,-.006f)};
            var centerline=path.Select(p=>new WirePoint(p.x,p.y,p.z)).ToArray();
            var ring=new Vector3[path.Length,12];var right=new WirePoint();var tangent=new WirePoint();
            for(int point=0;point<path.Length;point++)
            {
                var section=WireTube.Ring(centerline,point,12,ref right,ref tangent);
                for(int i=0;i<12;i++)ring[point,i]=path[point]+CabinetWiring.Vector(section[i])*WireRouting.Radius;
            }
            for(int segment=0;segment+1<path.Length;segment++)for(int i=0;i<12;i++)
            {
                int next=(i+1)%12;
                var normal=(ring[segment,i]+ring[segment,next]-path[segment]*2f).normalized;
                g.Quad(ring[segment,i],ring[segment,next],ring[segment+1,next],ring[segment+1,i],normal,3);
            }
            return g.Finish("Switchboards.FixedTerminalTail");
        }
    }
}
