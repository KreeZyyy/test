using System.Collections.Generic;using UnityEngine;
namespace ModularSwitchboards {
 // Authored in metres from the measured IN envelope, not read/copied from a game mesh.
 internal static class CabinetInputGeometry {
  internal const float Width=.100f,Height=.162f,CenterY=.0366f,Mouth=.050f,Depth=.016f;
  internal static readonly Vector3 ReferenceSocket=new Vector3(-.5f,0,.317412257f),ReferenceAxis=Vector3.forward,ReferenceVisual=new Vector3(-.5f,0,.25f);
  internal static readonly Bounds Target=new Bounds(new Vector3(0,0,-.006f),new Vector3(.065f,.065f,.024f));
  internal static Mesh Build(){var v=new List<Vector3>();var n=new List<Vector3>();var t=new List<int>[5];for(int i=0;i<5;i++)t[i]=new List<int>();
   // Continuous rounded plate with a real socket aperture. No painted-on fake opening.
   BatteryAperture.Box(v,n,t[1],new Vector3(0,CenterY,.0016f),new Vector3(Width,Height,.0032f),.001f,Mouth,Mouth,.014645f,.014645f);
   BatteryAperture.Walls(v,n,t[3],new Vector3(0,0,-.0064f),new Vector3(Width,Height,.0192f),Mouth,Mouth,.014645f,.014645f);
   RoundedGeometry.Box(v,n,t[3],new Vector3(0,0,-.015f),new Vector3(Mouth,Mouth,.002f),.0004f);
   // Two brass contact pads inside the faceted circular recess.
   foreach(float side in new[]{-1f,1f})RoundedGeometry.Box(v,n,t[2],new Vector3(side*.011f,0,-.009f),new Vector3(.012f,.013f,.006f),.0006f);
   // Raised lightning silhouette, authored from the reference proportions.
   var bolt=new[]{new Vector3(.003f,.112f,.006f),new Vector3(-.017f,.079f,.006f),new Vector3(-.002f,.082f,.006f),new Vector3(-.004f,.047f,.006f),new Vector3(.020f,.089f,.006f),new Vector3(.004f,.086f,.006f)};
   int start=v.Count;v.AddRange(bolt);for(int i=0;i<bolt.Length;i++)n.Add(Vector3.forward);
   foreach(int id in new[]{0,1,2,0,2,5,2,3,4,2,4,5})t[4].Add(start+id);
   for(int i=0;i<bolt.Length;i++){var a=bolt[i];var b=bolt[(i+1)%bolt.Length];var edge=b-a;var normal=new Vector3(edge.y,-edge.x,0).normalized;int k=v.Count;v.AddRange(new[]{new Vector3(a.x,a.y,.0032f),new Vector3(b.x,b.y,.0032f),b,a});for(int j=0;j<4;j++)n.Add(normal);t[4].AddRange(new[]{k,k+1,k+2,k,k+2,k+3});}
   var mesh=new Mesh{name="Switchboards.OwnInputPanel"};mesh.SetVertices(v);mesh.SetNormals(n);mesh.subMeshCount=5;for(int i=0;i<5;i++)mesh.SetTriangles(t[i],i);CabinetGeometry.ApplyNativeUv(mesh);mesh.RecalculateBounds();return mesh;
  }
 }
}
