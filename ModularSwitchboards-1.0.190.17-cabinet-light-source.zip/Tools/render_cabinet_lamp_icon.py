from pathlib import Path
import json,math
from PIL import Image,ImageDraw
root=Path(__file__).resolve().parents[1];d=json.loads((root/'Assets/CabinetLamp/NativeSettings.json').read_text());parts=[]
# Read independent baked geometry; renders a reference thumbnail, no game asset lookup.
import struct
for name in ('Body','Diffuser'):
 b=(root/'Assets/CabinetLamp'/f'{name}.meshbin').read_bytes();magic,n,groups=struct.unpack_from('<iii',b);offset=12;vertices=[];uv=[]
 for i in range(n):
  x,y,z,u,v=struct.unpack_from('<5f',b,offset);offset+=20;vertices.append((x,y,z));uv.append((u,v))
 tex=Image.open(root/'Assets/CabinetLamp'/f'{name}.png').convert('RGB')
 for g in range(groups):
  length=struct.unpack_from('<i',b,offset)[0];offset+=4;ids=struct.unpack_from('<'+'i'*length,b,offset);offset+=4*length
  for j in range(0,length,3):
   vs=[vertices[k] for k in ids[j:j+3]];us=[uv[k] for k in ids[j:j+3]];u=sum(t[0] for t in us)/3;v=sum(t[1] for t in us)/3
   color=tex.getpixel((int((u%1)*(tex.width-1)),int((1-v%1)*(tex.height-1))))
   parts.append((vs,color))
def project(p):
 x,y,z=p;return (x-.4*z,-y+.28*z,.12*x+.1*y+z)
allp=[project(p) for vs,c in parts for p in vs];xmin=min(p[0] for p in allp);xmax=max(p[0] for p in allp);ymin=min(p[1] for p in allp);ymax=max(p[1] for p in allp);scale=min(450/(xmax-xmin),340/(ymax-ymin));cx=(xmax+xmin)/2;cy=(ymax+ymin)/2
im=Image.new('RGBA',(512,512),(0,0,0,0));draw=ImageDraw.Draw(im)
for vs,col in sorted(parts,key=lambda t:sum(project(p)[2] for p in t[0])):
 pts=[project(p) for p in vs];draw.polygon([(256+(p[0]-cx)*scale,256+(p[1]-cy)*scale) for p in pts],fill=(*col,255))
im.save(root/'Assets/Icons/CabinetLamp.png');print(root/'Assets/Icons/CabinetLamp.png')
