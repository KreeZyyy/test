"""Bake only the IC10 socket from an authoring-time AirConditioner diagnostics export.
Usage: python Tools/bake_air_chip_socket.py export.json Assets/AirChipSocket.meshbin
No game installation or GPU is used by the resulting runtime asset.
"""
import json,struct,sys
from pathlib import Path
source=Path(sys.argv[1]); model=next(m for m in json.loads(source.read_text())['Meshes'] if m['Name']=='StructureAirConditioner')
v=model['Vertices']; uv=model['Uv']; points=[]; tex=[]; remap={}; groups=[]
def inside(p):return -.006<=p['x']<=.126 and .703<=p['y']<=.846 and .111<=p['z']<=.158
for part in model['Parts']:
 out=[]; ids=part['Triangles']
 for i in range(0,len(ids),3):
  tri=ids[i:i+3]
  if all(inside(v[k]) for k in tri):
   for k in tri:
    if k not in remap:remap[k]=len(points);points.append(v[k]);tex.append(uv[k])
    out.append(remap[k])
 groups.append(out)
assert points and all(len(g)%3==0 for g in groups)
data=bytearray(struct.pack('<iii',0x53434941,len(points),len(groups)))
for a,b in zip(points,tex):data+=struct.pack('<5f',a['x'],a['y'],a['z'],b['x'],b['y'])
for ids in groups:data+=struct.pack('<i',len(ids))+struct.pack('<'+'i'*len(ids),*ids)
Path(sys.argv[2]).write_bytes(data)
print(f'{len(points)} vertices, {sum(map(len,groups))//3} triangles, {len(groups)} material groups, {len(data)} bytes')
