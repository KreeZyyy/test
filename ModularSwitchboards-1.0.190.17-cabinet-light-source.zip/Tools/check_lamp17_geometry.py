from pathlib import Path
import struct,math
r=Path('/tmp/switchboards-lamp-kit');orig=1.528524*.195;checks=0;thin=0
def base(v):
 x,y,z=v;return(x*.195,-(z-.1086)*.13,.132+(y-.1624)*.13-.045*max(0,min(1,(.1477-y)/.1477)))
for cab,row,tx,ty in [(.4,110,.14,-.018),(.8,250,.3,-.055)]:
 width=min(orig*2,cab-.07);ratio=width/orig;raiseY=.018 if cab==.8 else .026
 def profile(v):
  px,py,pz=base(v);f=max(0,min(1,(v[1]-.13)/.05));sx=px+max(-1,min(1,px/(orig*.4)))*(width-orig)/2
  return(sx*(1-f)+px*ratio*f,py+raiseY,pz*(1-f)+(.159+(pz-.159)*2.5)*f)
 for name in ['Body','Diffuser']:
  data=(r/'Assets/CabinetLamp'/f'{name}.meshbin').read_bytes();_,n,g=struct.unpack_from('<iii',data);native=[struct.unpack_from('<5f',data,12+i*20)[:3] for i in range(n)];p=[profile(v) for v in native];off=12+n*20
  assert max(abs(v[0]) for v in p)<cab*.5-.025;checks+=1
  assert max(v[1]+row*.0018 for v in p)<cab*.625;checks+=1
  assert max(v[2]+.014 for v in p)<.185;checks+=1
  if name=='Diffuser':assert min(v[2]+.014 for v in p)>.1035;checks+=1
  for group in range(g):
   count=struct.unpack_from('<i',data,off)[0];off+=4;ids=struct.unpack_from('<'+'i'*count,data,off);off+=4*count
   for i in range(0,count,3):
    vs=[native[k] for k in ids[i:i+3]]
    if all(v[1]<.13 and v[0]*.195>orig*.4 for v in vs) or all(v[1]<.13 and v[0]*.195<-orig*.4 for v in vs):
     for j in range(3):
      a,b=vs[j],vs[(j+1)%3];assert abs(math.dist(base(a),base(b))-math.dist(profile(a),profile(b)))<1e-6
     thin+=1
 assert tx+.029<cab*.5-.025;checks+=1
 assert math.hypot(tx,(row*.0018+ty)-(.44 if cab==.8 else .211))>.1;checks+=1
 print('profile',cab,'plate terminal',tx,row*.0018+ty,'width',width)
assert thin>0
assert 'CabinetLampSocketBridge' not in (r/'Source/CabinetLampModel.cs').read_text()
print(checks,'clearance/terminal-placement checks and',thin,'thin-support triangle checks passed')
