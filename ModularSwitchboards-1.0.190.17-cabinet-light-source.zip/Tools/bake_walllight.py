"""Bake original native long-angled lamp body and diffuser, not destroyed/shadow meshes."""
import json,struct,sys
from pathlib import Path
source=Path(sys.argv[1]);destination=Path(sys.argv[2]);data=json.loads(source.read_text());destination.mkdir(parents=True,exist_ok=True)
summary=[]
for part in data['parts']:
 if part['path'] not in ('.','./Bulb'):continue
 assert not part.get('error')
 points=part['vertices'];uv=part['uv'];groups=part['triangles'];m=part['matrix']
 assert len(points)==len(uv) and points
 transformed=[]
 for v in points:transformed.append([sum(m['m'+str(row)+str(col)]*v['xyz'[col]] for col in range(3))+m['m'+str(row)+'3'] for row in range(3)])
 blob=bytearray(struct.pack('<iii',0x504d414c,len(points),len(groups)))
 for p,t in zip(transformed,uv):blob+=struct.pack('<5f',*p,t['x'],t['y'])
 triangles=0
 for g in groups:
  ids=g['values'];assert len(ids)%3==0 and all(0<=i<len(points) for i in ids)
  blob+=struct.pack('<i',len(ids))+struct.pack('<'+'i'*len(ids),*ids);triangles+=len(ids)//3
 name='Body' if part['path']=='.' else 'Diffuser';(destination/(name+'.meshbin')).write_bytes(blob)
 summary.append({'part':name,'vertices':len(points),'triangles':triangles,'min':[min(p[i] for p in transformed) for i in range(3)],'max':[max(p[i] for p in transformed) for i in range(3)],'materials':part['materials']})
settings={'sourcePrefab':data['prefab'],'sourceOnly':'No runtime prefab/model lookup. Original coordinates retained; final mount transform not set yet.','parts':summary,'lights':data['lights'],'scalarFields':data['fields'],'connectionNodes':[c for c in data['components'] if 'Connection' in c['path']],'textures':'NOT CAPTURED: GPU readback failed; do not substitute guessed material.'}
(destination/'NativeSettings.json').write_text(json.dumps(settings,indent=2));print(json.dumps([{k:v for k,v in p.items() if k!='materials'} for p in summary],indent=2))
