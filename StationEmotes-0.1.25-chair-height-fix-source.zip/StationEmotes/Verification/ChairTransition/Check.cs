using System;using StationEmotes;using UnityEngine;using UnityEngine.Animations;
class Check{
 static int n;static void A(bool b){n++;if(!b)throw new Exception("chair check "+n);}static bool Near(float a,float b)=>Math.Abs(a-b)<.0001f;
 static void Main(){
 A(ChairTransitionPolicy.Move(0)==0);A(ChairTransitionPolicy.Move(.35f)==1);A(ChairTransitionPolicy.Rotate(.35f)==0);A(Near(ChairTransitionPolicy.Rotate(.9f),1));A(ChairTransitionPolicy.Blend(.9f)==0);A(Near(ChairTransitionPolicy.Blend(1.75f),1));
 foreach(var phase in new Func<float,float>[]{ChairTransitionPolicy.Move,ChairTransitionPolicy.Rotate,ChairTransitionPolicy.Blend}){float prev=0;for(int i=0;i<=200;i++){float b=phase(i*.01f);A(b>=prev-.000001f&&b>=0&&b<=1.000001f);prev=b;}}
 A(ChairTransitionPolicy.Ease(float.NaN)==0);A(ChairTransitionPolicy.Ease(float.PositiveInfinity)==1);A(ChairTransitionPolicy.SafeDistance(2.25f));A(!ChairTransitionPolicy.SafeDistance(2.26f));A(!ChairTransitionPolicy.SafeDistance(float.NaN));
 A(ChairTransitionPolicy.Front(0,0,0));A(ChairTransitionPolicy.Front(.45f,.75f,.55f));A(!ChairTransitionPolicy.Front(.46f,0,0));A(!ChairTransitionPolicy.Front(0,-.16f,0));A(!ChairTransitionPolicy.Front(0,.76f,0));A(!ChairTransitionPolicy.Front(0,0,.56f));A(!ChairTransitionPolicy.Front(float.NaN,0,0));A(!ChairTransitionPolicy.Front(0,float.PositiveInfinity,0));
 foreach(float t in new[]{0f,.5f,1f}){
 var hip=new State{Position=new Vector3(0,.8f,0),Local=Quaternion.Euler(40)};var arm=new State{Local=Quaternion.Euler(90)};
 var job=new ChairJob{StartHips=new Vector3(0,1,0),Blend=t};job.Set(0,new PoseSlot{Handle=new TransformStreamHandle(hip),Rotation=Quaternion.Euler(0)});job.Set(15,new PoseSlot{Handle=new TransformStreamHandle(arm),Rotation=Quaternion.Euler(0)});job.ProcessAnimation(default(AnimationStream));
 A(Near(hip.Position.y,1-.2f*t));A(Math.Abs(Quaternion.Angle(Quaternion.Euler(0),hip.Local)-40*t)<.1f);A(Math.Abs(Quaternion.Angle(Quaternion.Euler(0),arm.Local)-90*t)<.1f);var p=hip.Position;job.ProcessRootMotion(default(AnimationStream));A(hip.Position.y==p.y);
 }
 var left=new State{Local=Quaternion.Euler(0)};var right=new State{Local=Quaternion.Euler(0)};var step=new ChairJob{Step=1};step.Set(10,new PoseSlot{Handle=new TransformStreamHandle(left),Rotation=Quaternion.Euler(0)});step.Set(13,new PoseSlot{Handle=new TransformStreamHandle(right),Rotation=Quaternion.Euler(0)});step.ProcessAnimation(default(AnimationStream));A(Quaternion.Angle(left.Local,right.Local)>23.9f);
 foreach(float from in new[]{-3f,0f,2f})foreach(float to in new[]{-2f,.5f,4f}){
 for(int i=0;i<=90;i++)A(Near(ChairTransitionPolicy.Height(true,from,to,i*.01f),from));
 A(Near(ChairTransitionPolicy.Height(true,from,to,ChairTransitionPolicy.Duration),to));
 A(Near(ChairTransitionPolicy.Height(false,from,to,0),from));
 A(Near(ChairTransitionPolicy.Height(false,from,to,ChairTransitionPolicy.Sit),to));
 A(Near(ChairTransitionPolicy.Height(false,from,to,ChairTransitionPolicy.Duration),to));
 for(int i=0;i<=100;i++){float t=i*ChairTransitionPolicy.Duration/100;float h=ChairTransitionPolicy.Height(true,from,to,t);A(h>=Math.Min(from,to)-.00001f&&h<=Math.Max(from,to)+.00001f);}
 }
 Console.WriteLine(n+" staged chair policy/job checks passed (stream stubs; not Unity runtime).");}}
namespace UnityEngine
{
 public struct Vector3{public float x,y,z;public Vector3(float a,float b,float c){x=a;y=b;z=c;}public static Vector3 Lerp(Vector3 a,Vector3 b,float t)=>new Vector3(a.x+(b.x-a.x)*t,a.y+(b.y-a.y)*t,a.z+(b.z-a.z)*t);}
 public struct Quaternion{public static Quaternion operator *(Quaternion a,Quaternion b)=>new Quaternion{q=a.q*b.q};public static Quaternion Euler(float x,float y,float z)=>Euler(x);internal System.Numerics.Quaternion q;public static Quaternion Euler(float x)=>new Quaternion{q=System.Numerics.Quaternion.CreateFromAxisAngle(System.Numerics.Vector3.UnitX,x*(float)Math.PI/180)};public static Quaternion Slerp(Quaternion a,Quaternion b,float t)=>new Quaternion{q=System.Numerics.Quaternion.Slerp(a.q,b.q,t)};public static float Angle(Quaternion a,Quaternion b)=>(float)(2*Math.Acos(Math.Min(1,Math.Abs(System.Numerics.Quaternion.Dot(a.q,b.q))))*180/Math.PI);}
}
namespace UnityEngine.Animations
{
 public struct AnimationStream{}public interface IAnimationJob{void ProcessRootMotion(AnimationStream s);void ProcessAnimation(AnimationStream s);}
 public class State{public Vector3 Position;public Quaternion Rotation,Local;}
 public struct TransformStreamHandle{State state;public TransformStreamHandle(State s){state=s;}public bool IsValid(AnimationStream s)=>state!=null;public void Resolve(AnimationStream s){}public Vector3 GetLocalPosition(AnimationStream s)=>state.Position;public void SetLocalPosition(AnimationStream s,Vector3 p){state.Position=p;}public Vector3 GetPosition(AnimationStream s)=>state.Position;public Quaternion GetRotation(AnimationStream s)=>state.Rotation;public Quaternion GetLocalRotation(AnimationStream s)=>state.Local;public void SetPosition(AnimationStream s,Vector3 p){state.Position=p;}public void SetRotation(AnimationStream s,Quaternion q){state.Rotation=q;}public void SetLocalRotation(AnimationStream s,Quaternion q){state.Local=q;}}
}
namespace StationEmotes{internal struct PoseSlot{public UnityEngine.Animations.TransformStreamHandle Handle;public UnityEngine.Quaternion Rotation;}}
