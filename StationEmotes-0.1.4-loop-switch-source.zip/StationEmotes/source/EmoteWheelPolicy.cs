using System;
namespace StationEmotes
{
    internal static class EmoteWheelPolicy
    {
        // Screen coordinates: up=wave, right=salute, down=sit, left=hands up.
        internal static int Select(float x,float y)
        {
            if(float.IsNaN(x)||float.IsNaN(y)||float.IsInfinity(x)||float.IsInfinity(y)||x*x+y*y<35f*35f)return -1;
            return Math.Abs(y)>=Math.Abs(x)?(y<0?0:2):(x>0?1:3);
        }
    }
}
