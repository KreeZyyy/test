using System;
using Assets.Scripts;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Inventory;
using Assets.Scripts.Objects.Entities;
using Assets.Scripts.UI;
using Assets.Scripts.Util;
using HarmonyLib;
using ImGuiNET;
using UnityEngine;
using UnityEngine.Rendering;
namespace StationEmotes
{
    internal static class EmoteWheel
    {
        internal static bool Open {get;private set;}
        [ThreadStatic] internal static bool ReadingMouse;
        private static Human owner;
        private static Vector2 pointer;
        private static readonly string[] Labels={"Wave","Salute","Sit","Hands up\n(TEST)"};
        internal static void Close(){Open=false;owner=null;pointer=Vector2.zero;}
        private static bool CanUse()=>Application.isFocused&&!WorldManager.IsGamePaused&&InventoryManager.AllowMouseControl&&!Cursor.visible&&!InputWindowBase.IsInputWindow&&!ConsoleWindow.IsOpen&&!ImGuiLoadingScreen.IsShowing;
        internal static void Tick(Human human)
        {
            if(!CanUse()){Close();return;}
            if(!Open&&Input.GetKeyDown(KeyCode.F10)){Open=true;owner=human;pointer=Vector2.zero;return;}
            if(!Open)return;
            if(owner!=human||Input.GetKeyDown(KeyCode.Escape)){Close();return;}
            if(!Input.GetKey(KeyCode.F10))
            {
                int selected=EmoteWheelPolicy.Select(pointer.x,pointer.y);Close();
                Plugin.TriggerSelection(human,selected);return;
            }
            // Read the game's existing mouse axes while the OS pointer stays locked.
            var input=Singleton<InputManager>.Instance;
            ReadingMouse=true;
            try{pointer+=new Vector2(input.GetAxis("LookX"),-input.GetAxis("LookY"))*24f;}
            finally{ReadingMouse=false;}
            pointer=Vector2.ClampMagnitude(pointer,170f);
        }
        private static uint Color(float r,float g,float b,float a=1f)=>ImGui.GetColorU32(new Vector4(r,g,b,a));
        private static void Text(ImDrawListPtr draw,Vector2 p,string text,uint color)
        {draw.AddText(p-ImGui.CalcTextSize(text)*.5f,color,text);}
        internal static void Draw()
        {
            if(!Open||GameManager.IsBatchMode||GameManager.GameState!=GameState.Running||ImGui.GetCurrentContext()==IntPtr.Zero)return;
            try
            {
                var center=new Vector2(Screen.width*.5f,Screen.height*.5f);
                ImGui.SetNextWindowPos(center-new Vector2(225,235),ImGuiCond.Always);
                ImGui.SetNextWindowSize(new Vector2(450,470),ImGuiCond.Always);
                bool visible=ImGui.Begin("##StationEmotesWheel",ImGuiWindowFlags.NoDecoration|ImGuiWindowFlags.NoBackground|ImGuiWindowFlags.NoSavedSettings|ImGuiWindowFlags.NoInputs|ImGuiWindowFlags.NoFocusOnAppearing);
                try
                {
                    if(!visible)return;
                    var d=ImGui.GetWindowDrawList();int selected=EmoteWheelPolicy.Select(pointer.x,pointer.y);
                    d.AddCircleFilled(center,195,Color(.025f,.035f,.045f,.92f),64);
                    d.AddCircle(center,195,Color(.25f,.55f,.65f),64,2f);
                    Vector2[] offsets={new Vector2(0,-115),new Vector2(115,0),new Vector2(0,115),new Vector2(-115,0)};
                    for(int i=0;i<4;i++)
                    {
                        var p=center+offsets[i];bool hot=i==selected;
                        d.AddCircleFilled(p,61,hot?Color(.05f,.48f,.58f):Color(.10f,.14f,.18f),40);
                        d.AddCircle(p,61,hot?Color(.35f,.95f,1):Color(.30f,.36f,.42f),40,hot?2f:1f);
                        Text(d,p,Labels[i],Color(1,1,1));
                    }
                    d.AddCircleFilled(center,34,Color(.08f,.10f,.13f),32);
                    Text(d,center,"Cancel",Color(.75f,.80f,.83f));
                    d.AddCircleFilled(center+pointer,5,Color(1,.70f,.25f),16);
                    Text(d,center+new Vector2(0,-218),"EMOTES",Color(1,1,1));
                    Text(d,center+new Vector2(0,217),"Hold F10 + move mouse | Release to play | Esc cancels",Color(.8f,.85f,.9f));
                }
                finally{ImGui.End();}
            }
            catch(Exception e){Close();Plugin.Log.LogWarning("Emote menu closed: "+e);}
        }
    }
    [HarmonyPatch(typeof(ImGuiManager),"RenderImGuiTo")]
    internal static class EmoteWheelDraw
    {
        [HarmonyPrepare] static bool Prepare()=>!GameManager.IsBatchMode;
        static void Prefix(CommandBuffer cb,CommandBuffer ___commandBuffer)
        {if(ReferenceEquals(cb,___commandBuffer))EmoteWheel.Draw();}
    }
    [HarmonyPatch(typeof(InputManager),"GetAxis",new Type[]{typeof(string)})]
    internal static class EmoteWheelCamera
    {
        [HarmonyPrepare] static bool Prepare()=>!GameManager.IsBatchMode;
        static bool Prefix(string __0,ref float __result)
        {
            if(!EmoteWheel.Open||EmoteWheel.ReadingMouse||(__0!="LookX"&&__0!="LookY"))return true;
            __result=0f;return false;
        }
    }
}
