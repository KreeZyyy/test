using System;using StationEmotes;
class MenuPolicyCheck{
 static int count;static void Check(float x,float y,int want){count++;if(EmoteWheelPolicy.Select(x,y)!=want)throw new Exception("Wrong wheel selection at "+x+","+y);}
 static void Main(){
 Check(0,0,-1);Check(34,0,-1);Check(0,-34,-1);Check(24,24,-1);
 Check(0,-100,0);Check(25,-100,0);Check(-25,-100,0);
 Check(100,0,1);Check(100,25,1);Check(100,-25,1);
 Check(0,100,2);Check(-25,100,2);Check(25,100,2);
 Check(-100,0,3);Check(-100,25,3);Check(-100,-25,3);
 Check(35,0,1);Check(0,-35,0);Check(100,-100,0);Check(-100,100,2);
 Check(float.NaN,100,-1);Check(100,float.PositiveInfinity,-1);
 Console.WriteLine(count+" radial-selection checks passed (dead zone, directions, borders and invalid input).");
 }
}
