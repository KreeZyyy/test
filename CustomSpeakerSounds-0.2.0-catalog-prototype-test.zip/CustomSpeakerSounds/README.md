# Custom Speaker Sounds0.2.0 — catalog prototype, NOT a complete multiplayer release

Separate experimental branch from working0.1.5. Do not replace a public/live install yet. No automatic file transfer exists in this version. A joining client will therefore hear no custom sound unless a matching verified file already exists in its cache. No on-screen download progress or start-time playback alignment yet.

Implemented: optional LaunchPadBooster join-prefix protocol carrying a validated server-owned manifest with ID/name/format/byte count/SHA256; singleplayer folder and multiplayer cache separation; server metadata scan without AudioManager; server IDs/names derived on DS without decoding audio; multiplayer catalog selected from authenticated join data; private local files are not consulted for server sound selection. Cache paths use lowercase content hashes plus allowlisted extension, never server-provided names. Missing/invalid cache is silent; local sounds with colliding IDs are not substituted. Existing custom speaker events are stopped/detached at context change, suit/tablet custom playback stopped without changing authoritative SoundAlert, and stale load coroutines are invalidated. Ordinary game sounds retain original handling. Disconnect requests clear pending server catalog; next local context restores local loading. These Unity/session behaviors are implemented but not live-tested.

Bounds:100entries, IDs100..199,32MiBper encoded source file,128MiBtotal source bytes,96character labels,64KiBbase64 manifest. This limits protocol metadata and source files, not decoded PCM memory; decoder/duration budgeting must be added with file transfer. Cache validation verifies size plus SHA256. Catalog metadata is validated before publication; malformed manifests fail rather than falling back to private local sounds. Native network protocol is optional at Booster level; absent server support means no received server custom catalog and only vanilla remains. Behavior when client/server have different protocol versions or no client mod requires live verification; do not promise all mismatches safe.

Next: on-demand chunked transfers restricted to manifest hashes, per-client flow control/timeouts, temporary files plus atomic SHA-verified completion, user-facing progress, server/client startup readiness, and synchronized speaker start/seek for late joins. Need live checks for server with/without mod, SP->MP->SP/reconnect, DS no-audio registration, missing/valid/bad cache and wardrobe playback. Ready-to-publish0.1.5 remains unchanged.

Validation: native build0errors/1preexisting System.Net.Http reference conflict.128 production manifest/cache checks cover scan/IDrange/roundtrips0..100entries/Unicode labels/duplicate+bad entries/bounds/bad hashes/private-folder preservation/verified cache. Unity/coroutine/Booster join was not run here. Build references officialLaunchPadBooster, compatibility interface and BepInEx only; not bundled. No Lua dependency.


---
# Custom Speaker Sounds 0.1.5 — Shared SoundAlert catalog

Extends the actual EnumCollections.SpeakerSounds catalog from the same successfully loaded file/label map used for Speaker mode strings/hashes. Copies original data, fills indexed gaps, adds100..199, then publishes one completed collection. Values, integer IDs, Names, PaddedNames, LongestName and Length are consistent. Original enum type is unchanged; existing game code using the shared EnumCollection sees the expanded entries. Empty unused IDs have blank labels and no custom clip. Unavailable custom writes remain rejected; do not expect missing files to play. Speaker retains its native table because it uses a separate static array, but both representations are generated from the single loaded catalog.

Suit and Advanced Tablet custom writes now pass through their original SetLogicValue and SoundAlert setters (native clamping uses the expanded list). AudioManager.Find maps successfully loaded custom IDs. Stop0, volume and native playback/replication remain unchanged. This also addresses the demonstrated issue that extending Speaker.modeStrings alone did not extend the suit's clamp range. It has not yet been verified that the reported ID100->45 behavior is resolved in live Unity.

Build0errors/1existing System.Net.Http reference conflict warning.58 shared-catalog checks pass against a fixture with the native field layout, including original preservation, all table lengths, ID100/199 native clamp, sparse slots and reload. The production code compiles against actual game APIs; reflection mutation of readonly fields still needs Mono/Unity validation. Test singleplayer first using s db SoundAlert100, check actual stored SoundAlert, then0(stop). A chip outside the suit can use the user's batch command sb -693235651 SoundAlert100 when that hash matches the intended suit prefab. Keep original sounds folder. No server-file transfer or multiplayer handshake implemented.

---

# Custom Speaker Sounds 0.1.4 — Suit + Advanced Tablet test

Adds the same successfully loaded sounds/100..199 to SuitBase.SoundAlert and AdvancedTablet.SoundAlert. The original native setters still handle network flags and main-thread playback; the shared AudioManager.Find(SoundAlert) lookup supplies custom clip data. Normal/advanced suits derived from SuitBase use the patch. The native byte can hold100..199; vanilla IDs and0(stop) retain original behavior. Missing custom IDs are rejected with a warning, not clamped to another vanilla sound. SoundVolume/Volume remains native. No early AudioManager singleton creation was introduced.

For an IC10 chip hosted in the suit or Advanced Tablet, try:

```ic10
s db Volume 50
s db SoundAlert 100
sleep 3
s db SoundAlert 0
```

For Lua, if StationeersLua is installed, write LogicType.SoundAlert on the host using its base-unit index. The mod itself does not require Lua. Advanced Tablet needs its native power/on conditions. If a clip is not yet loaded the custom write is ignored; retry after the load-complete log. The shipped100_test.wav is a short test. Keep your existing sounds directory when updating; don't leave a second DLL copy enabled.

Build against supplied game managed DLLs, official StationeersLaunchPad1.2.1 compatibility interface and BepInEx5.4.23.2 completed with0errors/1existing System.Net.Http reference conflict warning.16 production ID policy checks and compiled-IL checks for both host setters/shared lookup passed. No Unity gameplay runtime is available here: sound audibility, repeat/stop/volume still require a live singleplayer test. No claim of multiplayer synchronization or file downloading; server-only catalog/cache design remains future work.

Dependencies are build references only and are not redistributed. MIT Sovana attribution retained. Modular Switchboards is untouched and remains1.0.190.12.

---

# Custom Speaker Sounds 0.1.3 — TEST
Autor: KreeZy. Řešení přidání herních zvukových událostí vychází z MIT projektu Sovana122/Sationeers-CustomSound, větve speaker (6d5ad7892cb947eaed2fe7377048fe1dd211982f).

## Úprava seznamu 0.1.3
Seznam v Stationpedii nyní obsahuje jen původní položky a úspěšně načtené vlastní soubory. Prázdná rezervovaná ID se nezobrazují jako Unused. ID z názvů souborů zůstávají stejná (100_test.wav = 100, 101_Ferrari.mp3 = 101). Tabulka názvů se sestaví jednou až po načtení všech souborů, z uchované kopie původního seznamu; načtení druhého souboru tak nepřepisuje první název. Dříve vytvořené stránky Speakeru se při dokončení načítání aktualizují.
Příčina předchozího chybějícího testu pod ID 100 není bez logu potvrzená. Každé selhání načtení nyní vypíše ID, název souboru a chybu; dokončení vypíše Sound list committed: 100=test, 101=Ferrari. Při dalším testu ověř obě položky a přehrání obou ID. Stationpedia Ascended a nativní vykreslení seznamu čekají na ověření ve hře.

## Zachovaná oprava přehrávání 0.1.2
Vlastní GameAudioClipsData nyní explicitně inicializuje ConcurrencyIds na prázdný seznam. Herní konstruktor tento seznam nevytváří a metody AddConcurrencySubscriptions/RemoveConcurrencySubscriptions jej bez kontroly čtou. Opravuje tím konkrétní příčinu výjimky při přehrání/zastavení vlastního zvuku. První přehrání už uživatel ohlásil; opravené zastavení a opakované spuštění ještě čeká na test ve hře.

## Zachovaná oprava inicializace správce
Verze 0.1.0 kontrolovala AudioManager.Instance už před vytvořením herního správce. Getter v dodané herní DLL volá Create() a může vytvořit nevybavený singleton. Verze 0.1.3 getter vůbec nevolá: vyhledává pouze existující AudioManager a čeká na AudioSourcePrefab, LoadedChannelData a MixerGroups. Je to oprava konkrétního mechanismu, který může způsobit chyby při načítání světa; výsledek ve hře zatím není ověřen.
Diagnostika se nově zapisuje přímo do BepInEx/LogOutput.log pod CustomSpeakerSounds.

## Instalace a první test
1. Ukonči hru. Při aktualizaci nahraď starou CustomSpeakerSounds.dll a About/About.xml; vlastní sounds ponech. Nenechávej zapnutou druhou kopii modu. Rozbal složku CustomSpeakerSounds do Dokumenty\My Games\Stationeers\mods (případně do své složky Dokumenty na OneDrive).
2. V LaunchPadu zapni Custom Speaker Sounds. Vyžaduje StationeersLaunchPad; nepotřebuje Lua ani ScriptedScreens. Pro první test vypni Custom Sounds od Sovany, aby případné změny stejného Speakeru neovlivnily výsledek.
3. Načti singleplayer. Speaker musí mít elektřinu a být v atmosféře. Připoj jej jako d0 k IC housing.
4. Nejdřív ověř, že stejný svět naběhne bez opakovaných chyb AudioManager. Pak nahraj test.ic10. Po vteřině mají zaznít tři tóny a potom ticho; skript po čtyřech vteřinách nastaví SoundAlert 0 a už zvuk znovu nespouští.
5. Ověř také původní zvuky Speakeru. Pokud nic neslyšíš nebo se zvuk opakuje, pošli BepInEx\LogOutput.log a popis výsledku. Hledej [CustomSpeakerSounds] Ready: ID 100.

## Vlastní hlášky
Nahraď sounds/100_test.wav vlastním WAV a restartuj hru. Jde o soubor uvnitř složky tohoto modu. Doporučený první test: krátký mono PCM WAV (16 bitů).
Další soubory: 101_varovani.wav, 102_kyslik.ogg… Platí ID 100 až 199, jedno ID na soubor. ID určuje číslo před prvním podtržítkem, nikoli pořadí souborů. Mod soubory nepřejmenovává. WAV/OGG/MP3 podporuje načítač Unity; jejich dekódování je nutné ověřit ve hře.
Použij s d0 SoundAlert 101 nebo s d0 Mode 101. Pro opětovné přehrání nejprve nastav SoundAlert 0, počkej aspoň jeden tick a teprve potom vyber ID. Neposílej stejné ID každým tickem. Hlasitost řídí Volume a přehrávání probíhá přes nativní zvuk Speakeru. Původní zvuky se nenahrazují.

## Rozsah ověření
Sestaveno proti dodané Assembly-CSharp.dll. Prošlo 17 kontrolami sestaveného IL: getter singletonu není volán ani z korutiny, mod nevytváří správce, kontroluje jeho připravenost a zachovává nativní registraci zvuků. Zkontrolovány podpisy Speaker.SetLogicValue, InteractMode, zvukové události a načítání AudioManageru. Unity a hra zde neběží: prostorový zvuk, ukončení přehrávání a kompatibilita s jinými mody čekají na herní test.
Build hlásí konflikt referencí System.Net.Http 4.1.2/4.2.0 pocházející z herní DLL; mod nepoužívá HttpClient. Distribuce obsahuje pouze vlastní modovou DLL, nikoli herní sestavení.
Verze 0.1.3 neobsahuje přenos souborů ze serveru. Multiplayer není ověřen; všechny strany by zatím potřebovaly shodné soubory a ID. Testuj na kopii světa: při odebrání modu zůstane ve světě uložený vlastní Mode, který je vhodné před odebráním resetovat na 0.
Ovládání tlačítkem Speakeru může procházet i rezervované mezery mezi vanilla zvuky a ID 100; pro tento test používej IC10. Mezery jsou nyní v seznamu Stationpedie skryté.

## Zdroj
https://github.com/Sovana122/Sationeers-CustomSound/tree/speaker
Zdroj našeho malého rozšíření a návod k sestavení je v source/ tohoto ZIPu. Jde o samostatný testovací addon inspirovaný autorovou implementací, nikoli o sestavení celé jeho rozpracované větve.
