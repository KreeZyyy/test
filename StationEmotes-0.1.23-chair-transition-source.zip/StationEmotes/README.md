# Station Emotes 0.1.23
Requires BepInEx and StationeersLaunchPad. Replace the previous mod version, do not enable duplicate versions.

Hold F10 and select with the mouse; release to play. F11 or movement cancels. Esc closes the menu only. Native Wave loops; Salute and Sit hold. Custom Hands up, Point, Robot dance, Meme dance, Agree, Disagree and Facepalm require empty hands. Agree repeats a gentle nod, Disagree repeats a head shake, Facepalm holds the right palm in front of the visor. All persist until cancelled, switched or the same entry selected again. Observing clients should use the same version.

0.1.22 refines the radial menu with larger filled spacesuit silhouettes and helmet visors, icon-only sectors, central gesture names, opaque convex sector fills to avoid antialiased triangle seams, an orange selection arc and quieter footer hints. Selection policy, F10 controls, animations and network behavior are unchanged from 0.1.21. Live game appearance remains unverified.

The previous0.1.16 update corrects Facepalm wrist/IK-goal frame conversion. The job samples the native hand bone and native humanoid hand goal from the same animation stream, preserves their relative position/rotation, and maps the desired wrist pose into the correct goal frame. Imported bone axes are no longer treated as AvatarIKGoal axes.

The target height uses actual eye_l/eye_r landmarks where uniquely available. Named index/middle bones still calibrate the palm. Head-relative offsets remain in world distance units, and the palm follows the head tilt applied after the solver. Helmet detection and mesh-aware forward clearance remain separate from the bare-head profile. Unknown rigs use bounded fallback profiles. No guarantee is made for visual fit across every head/helmet: check both helmet and no-helmet appearances in game. Other gestures/dances are unchanged.

0.1.13 added three gestures and a larger ten-item wheel. IDs Agree41006, Disagree41007 and Facepalm41008 use the existing game emote message and cancellation/transition path. Facepalm uses humanoid right-hand IK; nod/shake use head transforms in the same owned overlay. No new root movement or game simulation is added.

The dance baseline from 0.1.12 keeps the 0.1.11 owned PreviousInputs overlay graph (confirmed live for Hands up and Point). It corrects dance ordering: humanoid pelvis/knee motion is submitted before SolveIK, then five upper-body transform slots are applied after SolveIK. Raw leg/hip transform slots are not applied over solved feet. This prevents the IK pass from rebuilding away the visible upper-body dance and prevents subsequent raw leg rotations from undoing foot support. The character root is not moved.

The 0.1.11 user log recorded 49 processed humanoid frames and 9/9 or 10/10 bone updates for dances despite their lack of visible motion. These counters prove execution, not visual correctness. The IK pass is the code path that distinguishes dance from working arm poses. The change requires another live visual test.

Custom poses still use procedural stream bone updates, with humanoid foot IK for dance where available. No imported animation clip or new physical movement is included. Native animations and cancellation policies are unchanged.

The earlier 0.1.10 scheduling failure was addressed in 0.1.11. Execution counters remain logged after one second; actual Unity rendering, graph evaluation, foot IK and multiplayer appearance still require live verification.

Build: source/StationEmotes.csproj, net472. Set GameManagedDirectory, BepInExDirectory and LaunchPadDirectory. Use the installed game UnityEngine.AnimationModule (including UnityEngine.Experimental.Animations output extensions) and PhysicsModule. Do not ship game or loader DLLs.


## Chair transitions — 0.1.23 prototype
Ordinary Seat furniture now receives a 1.25-second procedural visual transition when the native MoveToSlot succeeds, and the reverse transition when MoveToWorld succeeds. No new menu item: use the chair normally. Captures the currently displayed hips world pose plus 15 body joints and blends toward the live native Animator output using a quintic ease. It is not an imported AnimationClip.

The server still commits occupancy, physics and the root position immediately through its original methods. Only the rendered skeleton is smoothed; the first-person camera is not smoothed, and this is not walking/pathfinding or collision-aware animated travel. Each modded client observes native moves and constructs its own transition; no extra network protocol. Multiplayer timing, foot contact and final appearance need live verification. Install the same build on all clients for consistent visuals.

Only exact ordinary Seat type is enabled: atmospheric/control/rocket chairs, toilets and beds are excluded. Toilet interaction has not changed. Transitions skip moves over 2.5m, stop on death, slot change, movement beyond 30cm, disable, unload, a new body emote or F11. Menu emotes are blocked until the transition completes. Original slot ownership and failures are not overridden.

Test: stand close to an ordinary chair, use Get In, observe from another player/third person, then exit normally. Check body position, knees, feet and orientation in both directions. F11 cancels the visual blend only.
