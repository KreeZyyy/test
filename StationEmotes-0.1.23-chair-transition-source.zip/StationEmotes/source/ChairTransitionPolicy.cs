using System;
namespace StationEmotes
{
 internal static class ChairTransitionPolicy
 {
  internal const float Duration=1.25f;
  internal static float Blend(float elapsed)
  {
   if(float.IsNaN(elapsed)||elapsed<=0)return 0;
   if(elapsed>=Duration)return 1;
   float t=elapsed/Duration;return t*t*t*(t*(t*6-15)+10);
  }
  internal static bool SafeDistance(float squared)=>!float.IsNaN(squared)&&!float.IsInfinity(squared)&&squared>=0&&squared<=6.25f;
 }
}
