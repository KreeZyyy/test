using System;
using Assets.Scripts;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Inventory;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Entities;
using Assets.Scripts.Objects.Structures;
using HarmonyLib;
using UnityEngine;
using UnityEngine.Animations;
using UnityEngine.Experimental.Animations;
using UnityEngine.Playables;
namespace StationEmotes
{
 // Visual interpolation only. Native slot ownership, collider, camera and network messages remain authoritative.
 public sealed class ChairTransition:MonoBehaviour
 {
  internal sealed class Snapshot
  {
   internal Human Human;internal Animator Animator;internal Transform Hips;
   internal Vector3 Position,Root;internal Quaternion Rotation;
   internal Transform[] Bones;internal Quaternion[] Rotations;
  }
  private static readonly HumanBodyBones[] Body={HumanBodyBones.Spine,HumanBodyBones.Chest,HumanBodyBones.Head,
   HumanBodyBones.LeftUpperArm,HumanBodyBones.LeftLowerArm,HumanBodyBones.LeftHand,
   HumanBodyBones.RightUpperArm,HumanBodyBones.RightLowerArm,HumanBodyBones.RightHand,
   HumanBodyBones.LeftUpperLeg,HumanBodyBones.LeftLowerLeg,HumanBodyBones.LeftFoot,
   HumanBodyBones.RightUpperLeg,HumanBodyBones.RightLowerLeg,HumanBodyBones.RightFoot};
  private PlayableGraph graph;private AnimationScriptPlayable playable;private ChairJob job;
  private Human human;private Slot expectedSlot;private Vector3 endRoot;private float start;private int startedFrame;
  internal bool Active=>graph.IsValid();
  // Exclude rocket, atmospheric and control chairs: their entry rules/cameras require separate validation.
  internal static bool Ordinary(Thing thing)=>thing!=null&&thing.GetType()==typeof(Seat);
  internal static Snapshot Capture(DynamicThing thing)
  {
   if(GameManager.IsBatchMode||GameManager.GameState!=GameState.Running||!(thing is Human h)||h.State!=EntityState.Alive||h.EmoteController==null)return null;
   try
   {
    h.GetComponent<ChairTransition>()?.Stop();
    var a=Plugin.BodyAnimator.GetValue(h.EmoteController) as Animator;
    if(a==null||!a.isHuman||!a.isActiveAndEnabled)return null;
    var hips=a.GetBoneTransform(HumanBodyBones.Hips);if(hips==null)return null;
    var s=new Snapshot{Human=h,Animator=a,Hips=hips,Position=hips.position,Rotation=hips.rotation,Root=h.ThingTransform.position,Bones=new Transform[Body.Length],Rotations=new Quaternion[Body.Length]};
    for(int i=0;i<Body.Length;i++){s.Bones[i]=a.GetBoneTransform(Body[i]);if(s.Bones[i]!=null)s.Rotations[i]=s.Bones[i].localRotation;}
    return s;
   }
   catch(Exception e){Plugin.Log.LogWarning("Chair capture skipped: "+e);return null;}
  }
  internal static void Complete(Snapshot s,bool success)
  {
   if(s==null||!success||s.Human==null)return;
   if(!ChairTransitionPolicy.SafeDistance((s.Human.ThingTransform.position-s.Root).sqrMagnitude))return;
   var component=s.Human.GetComponent<ChairTransition>()??s.Human.gameObject.AddComponent<ChairTransition>();component.Begin(s);
  }
  private void Begin(Snapshot s)
  {
   Stop();human=s.Human;expectedSlot=human.ParentSlot;endRoot=human.ThingTransform.position;
   try
   {
    human.EmoteController.GetComponent<EmoteTransition>()?.Cancel();EmoteTransition.StopBody(human.EmoteController);
    job=new ChairJob{Hips=s.Animator.BindStreamTransform(s.Hips),StartPosition=s.Position,StartRotation=s.Rotation};
    for(int i=0;i<s.Bones.Length;i++)if(s.Bones[i]!=null)job.Set(i,new PoseSlot{Handle=s.Animator.BindStreamTransform(s.Bones[i]),Rotation=s.Rotations[i]});
    graph=PlayableGraph.Create("StationEmotes chair transition");graph.SetTimeUpdateMode(DirectorUpdateMode.GameTime);
    playable=AnimationScriptPlayable.Create(graph,job,0);playable.SetProcessInputs(false);
    var output=AnimationPlayableOutput.Create(graph,"Chair transition",s.Animator);
    output.SetAnimationStreamSource(AnimationStreamSource.PreviousInputs);output.SetSortingOrder(1100);output.SetWeight(1);output.SetSourcePlayable(playable);
    start=Time.time;startedFrame=Time.frameCount;playable.Play();graph.Play();
    Plugin.Log.LogInfo("Chair transition started: "+(expectedSlot==null?"standing up":"sitting down")+"; native slot retained; visual blend=1.25s");
   }
   catch(Exception e){Stop();Plugin.Log.LogWarning("Chair transition skipped: "+e);}
  }
  private void Update()
  {
   if(!Active)return;
   if(human==null||human.State!=EntityState.Alive||GameManager.GameState!=GameState.Running||human.ParentSlot!=expectedSlot||(human.ThingTransform.position-endRoot).sqrMagnitude>.09f){Stop();return;}
   float elapsed=Time.time-start;
   job.Blend=ChairTransitionPolicy.Blend(elapsed);playable.SetJobData(job);
   // Give the output one complete evaluation at its endpoint before destroying our graph.
   if(elapsed>=ChairTransitionPolicy.Duration+.08f&&Time.frameCount>startedFrame+2)Stop();
  }
  internal void Stop(){if(graph.IsValid())graph.Destroy();human=null;}
  private void OnDisable()=>Stop();private void OnDestroy()=>Stop();
 }
 internal struct ChairJob:IAnimationJob
 {
  public TransformStreamHandle Hips;public Vector3 StartPosition;public Quaternion StartRotation;public float Blend;
  public PoseSlot A,B,C,D,E,F,G,H,I,J,K,L,M,N,O;
  public void Set(int i,PoseSlot s){switch(i){case 0:A=s;break;case 1:B=s;break;case 2:C=s;break;case 3:D=s;break;case 4:E=s;break;case 5:F=s;break;case 6:G=s;break;case 7:H=s;break;case 8:I=s;break;case 9:J=s;break;case 10:K=s;break;case 11:L=s;break;case 12:M=s;break;case 13:N=s;break;case 14:O=s;break;}}
  private PoseSlot Get(int i){switch(i){case 0:return A;case 1:return B;case 2:return C;case 3:return D;case 4:return E;case 5:return F;case 6:return G;case 7:return H;case 8:return I;case 9:return J;case 10:return K;case 11:return L;case 12:return M;case 13:return N;default:return O;}}
  public void ProcessRootMotion(AnimationStream stream){}
  public void ProcessAnimation(AnimationStream stream)
  {
   if(Hips.IsValid(stream))
   {
    Hips.Resolve(stream);var target=Hips.GetPosition(stream);var rotation=Hips.GetRotation(stream);
    Hips.SetPosition(stream,Vector3.Lerp(StartPosition,target,Blend));Hips.SetRotation(stream,Quaternion.Slerp(StartRotation,rotation,Blend));
   }
   for(int i=0;i<15;i++)
   {
    var bone=Get(i);if(!bone.Handle.IsValid(stream))continue;bone.Handle.Resolve(stream);
    bone.Handle.SetLocalRotation(stream,Quaternion.Slerp(bone.Rotation,bone.Handle.GetLocalRotation(stream),Blend));
   }
  }
 }
 [HarmonyPatch(typeof(DynamicThing),"MoveToSlot",new Type[]{typeof(Slot),typeof(Thing),typeof(bool)})]
 internal static class ChairEnterPatch
 {
  static void Prefix(DynamicThing __instance,Slot __0,out ChairTransition.Snapshot __state)
  {__state=__0!=null&&ChairTransition.Ordinary(__0.Parent)&&__instance.ParentSlot==null?ChairTransition.Capture(__instance):null;}
  static void Postfix(bool __result,ChairTransition.Snapshot __state)=>ChairTransition.Complete(__state,__result);
 }
 [HarmonyPatch(typeof(DynamicThing),"MoveToWorld",new Type[]{typeof(Vector3),typeof(Quaternion),typeof(Vector3),typeof(Vector3),typeof(float)})]
 internal static class ChairExitPatch
 {
  static void Prefix(DynamicThing __instance,out ChairTransition.Snapshot __state)
  {__state=ChairTransition.Ordinary(__instance.ParentSlot?.Parent)?ChairTransition.Capture(__instance):null;}
  static void Postfix(bool __result,ChairTransition.Snapshot __state)=>ChairTransition.Complete(__state,__result);
 }
}
