using System;
using StationEmotes;
using UnityEngine;
using UnityEngine.Animations;
class Check
{
 static int n;static void A(bool b){n++;if(!b)throw new Exception("chair transition assertion "+n);}static bool Near(float a,float b)=>Math.Abs(a-b)<.0001f;
 static void Main()
 {
  A(ChairTransitionPolicy.Blend(-1)==0);A(ChairTransitionPolicy.Blend(float.NaN)==0);A(ChairTransitionPolicy.Blend(0)==0);A(ChairTransitionPolicy.Blend(float.PositiveInfinity)==1);
  float prev=0;for(int i=0;i<=100;i++){float b=ChairTransitionPolicy.Blend(i*ChairTransitionPolicy.Duration/100);A(b>=prev-.000001f&&b>=0&&b<=1.000001f);prev=b;}
  A(Near(ChairTransitionPolicy.Blend(.625f),.5f));A(ChairTransitionPolicy.Blend(2)==1);
  A(ChairTransitionPolicy.SafeDistance(6.25f));A(!ChairTransitionPolicy.SafeDistance(6.26f));A(!ChairTransitionPolicy.SafeDistance(float.NaN));A(!ChairTransitionPolicy.SafeDistance(float.PositiveInfinity));A(!ChairTransitionPolicy.SafeDistance(-1));
  foreach(float t in new[]{0f,.5f,1f})
  {
   var hips=new State{Position=new Vector3(10,4,2),Rotation=Quaternion.Euler(80)};
   var bone=new State{Local=Quaternion.Euler(90)};
   var job=new ChairJob{Hips=new TransformStreamHandle(hips),StartPosition=new Vector3(0,2,0),StartRotation=Quaternion.Euler(0),Blend=t};
   job.Set(0,new PoseSlot{Handle=new TransformStreamHandle(bone),Rotation=Quaternion.Euler(0)});
   job.ProcessAnimation(default(AnimationStream));
   A(Near(hips.Position.x,10*t));A(Near(hips.Position.y,2+2*t));A(Near(hips.Position.z,2*t));
   A(Math.Abs(Quaternion.Angle(Quaternion.Euler(0),hips.Rotation)-80*t)<.1f);A(Math.Abs(Quaternion.Angle(Quaternion.Euler(0),bone.Local)-90*t)<.1f);
   var p=hips.Position;job.ProcessRootMotion(default(AnimationStream));A(hips.Position.x==p.x);
  }
  Console.WriteLine(n+" production chair blend/job checks passed (engine stream stubs; not a Unity runtime test).");
 }
}
namespace UnityEngine
{
 public struct Vector3{public float x,y,z;public Vector3(float a,float b,float c){x=a;y=b;z=c;}public static Vector3 Lerp(Vector3 a,Vector3 b,float t)=>new Vector3(a.x+(b.x-a.x)*t,a.y+(b.y-a.y)*t,a.z+(b.z-a.z)*t);}
 public struct Quaternion{internal System.Numerics.Quaternion q;public static Quaternion Euler(float x)=>new Quaternion{q=System.Numerics.Quaternion.CreateFromAxisAngle(System.Numerics.Vector3.UnitX,x*(float)Math.PI/180)};public static Quaternion Slerp(Quaternion a,Quaternion b,float t)=>new Quaternion{q=System.Numerics.Quaternion.Slerp(a.q,b.q,t)};public static float Angle(Quaternion a,Quaternion b)=>(float)(2*Math.Acos(Math.Min(1,Math.Abs(System.Numerics.Quaternion.Dot(a.q,b.q))))*180/Math.PI);}
}
namespace UnityEngine.Animations
{
 public struct AnimationStream{}public interface IAnimationJob{void ProcessRootMotion(AnimationStream s);void ProcessAnimation(AnimationStream s);}
 public class State{public Vector3 Position;public Quaternion Rotation,Local;}
 public struct TransformStreamHandle{State state;public TransformStreamHandle(State s){state=s;}public bool IsValid(AnimationStream s)=>state!=null;public void Resolve(AnimationStream s){}public Vector3 GetPosition(AnimationStream s)=>state.Position;public Quaternion GetRotation(AnimationStream s)=>state.Rotation;public Quaternion GetLocalRotation(AnimationStream s)=>state.Local;public void SetPosition(AnimationStream s,Vector3 p){state.Position=p;}public void SetRotation(AnimationStream s,Quaternion q){state.Rotation=q;}public void SetLocalRotation(AnimationStream s,Quaternion q){state.Local=q;}}
}
namespace StationEmotes{internal struct PoseSlot{public UnityEngine.Animations.TransformStreamHandle Handle;public UnityEngine.Quaternion Rotation;}}
