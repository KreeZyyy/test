## 1.0.196 — Own DIN Logic models and interaction colliders

Replaces the imported native Logic I/O fronts with our own procedural panel, side pads, 5x7 lettering, hex screw heads and twelve-sided LED lens on the existing two-position DIN housing. Native geometry and original hitboxes are not retained. All clickable targets are newly created box/sphere colliders. Reference measurements are rounded to millimetres and colour/state references are used for consistency; the finished model contains our generated vertices only.

Original action IDs, native logic classes, state handling, save/network payloads and 10 W wiring behavior remain. New interactables bind our colliders to the existing actions. A fresh native state controller drives our LED renderer; no original control GameObject survives. No native face mesh resources or extraction code are compiled into the game DLL. Eight new icons match the authored models.

Fixes the cursor Awake collision failure: fitted-body replacement now removes the deleted box from all three collision caches as well as build-state lists and lookup. Each DIN Logic instance/cursor starts native Awake with fresh cache lists so native CacheColliders appends only the current hierarchy. This preserves real native collision handling rather than suppressing its exception. The 1.0.195 null-slot/isolated-kit fix remains.

Validated: native build, own geometry/hitbox separation and bounds, cursor/instance cache append simulations, compiled native inheritance/save/join and reset-before-Awake order. Full live-game placement, clicking and status changes still need testing.

Authoritative geometry: Source/DinLogicFrontGeometry.cs and RoundedGeometry.cs. Control positions/actions: Source/DinLogicControlLayout.cs (rounded reference measurements, not geometry). Own components/colliders and native logic wiring: DinLogicModel.cs. No native mesh arrays are imported or embedded for these eight variants.

Verification/DinLogicOwn links actual builders and ThingColliderCache; it exports an own-geometry JSON with no game geometry input. Render that JSON with Tools/render_din_logic.py. The Blender preview and icons use that export and are not game screenshots.
