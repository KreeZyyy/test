using System;using System.Linq;using System.Collections.Generic;
namespace UnityEngine {
 public class Collider {public string Name;public bool Destroyed;}
 public struct Vector3 {public float x,y,z;public Vector3(float x,float y,float z){this.x=x;this.y=y;this.z=z;}public static Vector3 one=>new(1,1,1);public static Vector3 right=>new(1,0,0);public static Vector3 left=>new(-1,0,0);public static Vector3 up=>new(0,1,0);public static Vector3 down=>new(0,-1,0);public static Vector3 forward=>new(0,0,1);public static Vector3 back=>new(0,0,-1);public Vector3 normalized{get{float l=MathF.Sqrt(x*x+y*y+z*z);return l>0?this*(1/l):new();}}public static Vector3 operator+(Vector3 a,Vector3 b)=>new(a.x+b.x,a.y+b.y,a.z+b.z);public static Vector3 operator-(Vector3 a,Vector3 b)=>new(a.x-b.x,a.y-b.y,a.z-b.z);public static Vector3 operator*(Vector3 a,float n)=>new(a.x*n,a.y*n,a.z*n);public static Vector3 Cross(Vector3 a,Vector3 b)=>new(a.y*b.z-a.z*b.y,a.z*b.x-a.x*b.z,a.x*b.y-a.y*b.x);}
 public static class Mathf {public const float PI=MathF.PI,Deg2Rad=MathF.PI/180;public static float Abs(float v)=>MathF.Abs(v);public static float Sin(float v)=>MathF.Sin(v);public static float Cos(float v)=>MathF.Cos(v);public static float Min(float a,float b)=>MathF.Min(a,b);public static float Max(float a,float b)=>MathF.Max(a,b);public static float Clamp(float v,float a,float b)=>Math.Clamp(v,a,b);}
 public class Mesh {public string name;public List<Vector3> V=new(),N=new();public int subMeshCount;public Dictionary<int,int[]> T=new();public void SetVertices(List<Vector3> v)=>V=v.ToList();public void SetNormals(List<Vector3> n)=>N=n.ToList();public void SetTriangles(List<int> t,int s)=>T[s]=t.ToArray();public void RecalculateBounds(){}}
}
namespace Assets.Scripts.Objects {
 public class Thing {public List<UnityEngine.Collider> _staticColliders=new(),_dynamicColliders=new(),_selfColliders=new();public static Dictionary<UnityEngine.Collider,Thing> _colliderLookup=new();}
 public class Structure:Thing {public List<BuildState> BuildStates=new(){new()};}
 public class BuildState {public List<UnityEngine.Collider> Colliders=new();}
}
namespace ModularSwitchboards {static class CabinetGeometry {internal static void ApplyNativeUv(UnityEngine.Mesh m){}}}
