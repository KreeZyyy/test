using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Electrical;
using Assets.Scripts.Objects.Motherboards;
using UnityEngine;
using UnityEngine.Rendering;
namespace LogicIOAuthoring {
 public static class KitAppearance {
  [Serializable] public sealed class Report {
   public string status,version="0.2.0",gameAssembly=typeof(LogicUnitBase).Assembly.FullName,kit;
   public string coordinates="Original mesh-local metres; meshToPrefab and hierarchy preserve native transforms. OBJ parts are prefab-local metres.";
   public string texturePolicy="Referenced material/property-block indices plus default/red/green/black/white slices; unused palette layers are not exported. PNG files are RGBA32 GPU readback; source graphics format is recorded.";
   public List<Variant> variants=new List<Variant>();public List<MeshData> meshes=new List<MeshData>();public List<MaterialData> materials=new List<MaterialData>();public List<TextureData> textures=new List<TextureData>();public List<string> errors=new List<string>();
  }
  [Serializable] public sealed class Variant {public int kitIndex;public string prefab,nativeType;public List<Node> hierarchy=new List<Node>();public List<Part> parts=new List<Part>();public List<Stage> stages=new List<Stage>();public List<FieldData> nativeFields=new List<FieldData>();}
  [Serializable] public sealed class Node {public string path,parent;public Vector3 position,scale;public Quaternion rotation;public Matrix4x4 toPrefab;public bool active;public string[] components;}
  [Serializable] public sealed class Stage {public int index;public string visualizer;}
  [Serializable] public sealed class Part {public string path,kind,obj;public int meshId;public Matrix4x4 meshToPrefab;public bool rendererEnabled;public int[] materialIds;public List<Property> globalBlock=new List<Property>();public List<Block> slotBlocks=new List<Block>();public List<Block> globalBlocksBySlot=new List<Block>();}
  [Serializable] public sealed class Block {public int slot;public List<Property> properties;}
  [Serializable] public sealed class MeshData {public int id;public string name;public Vector3[] vertices,normals;public Vector4[] tangents;public Vector2[] uv;public List<Surface> submeshes=new List<Surface>();public List<Attribute> attributes=new List<Attribute>();public List<RawStream> streams=new List<RawStream>();}
  [Serializable] public sealed class Surface {public int slot;public string topology;public int[] triangles;}
  [Serializable] public sealed class Attribute {public string attribute,format;public int dimension,stream,offset;}
  [Serializable] public sealed class RawStream {public int stream,stride,bytes;public string file,error;}
  [Serializable] public sealed class MaterialData {public int id,renderQueue;public string name,shader;public string[] keywords;public List<Property> properties;}
  [Serializable] public sealed class Property {public string name,type;public int textureId,blockTextureId;public bool blockHasProperty;public float value,blockFloat;public Color color,blockColor;public Vector4 vector,blockVector;public Vector2 scale,offset;}
  [Serializable] public sealed class TextureData {public int id,width,height,slice;public string name,dimension,format,file,error;}
  [Serializable] public sealed class FieldData {public string component,path,field,type,value;public bool hasVector,hasQuaternion;public Vector3 vector;public Quaternion quaternion;public string[] materialRefs;}
  private sealed class Context {
   public readonly Report report=new Report();public readonly Dictionary<int,Texture> textures=new Dictionary<int,Texture>();public readonly HashSet<int> slices=new HashSet<int>{0,(int)ColorType.Red,(int)ColorType.Green,(int)ColorType.Black,(int)ColorType.White};public readonly Dictionary<int,MeshData> meshes=new Dictionary<int,MeshData>();public readonly HashSet<int> materials=new HashSet<int>();public string folder;
   public void Material(Material m){if(m==null||!materials.Add(m.GetInstanceID()))return;if(m.shader==null){report.errors.Add("Material has no shader: "+m.name);return;}report.materials.Add(new MaterialData{id=m.GetInstanceID(),name=m.name,shader=m.shader.name,keywords=m.shaderKeywords,renderQueue=m.renderQueue,properties=Properties(m,new MaterialPropertyBlock(),this)});}
  }
  public static Report Export(string kit,Structure[] variants,int[] kitIndices,string folder){
   Directory.CreateDirectory(folder);var c=new Context{folder=folder};c.report.kit=kit;
   foreach(var pair in variants.Select((v,i)=>new{v,i})){
    var source=pair.v;var data=new Variant{kitIndex=kitIndices[pair.i],prefab=source.PrefabName,nativeType=source.GetType().FullName};c.report.variants.Add(data);
    try{
     if(source.CustomColor!=null)AddSlice(c.slices,source.CustomColor.Index);AddSlice(c.slices,source.SmoothnessIndex);c.Material(source.PaintableMaterial);
     foreach(var node in source.GetComponentsInChildren<Transform>(true)){
      data.hierarchy.Add(new Node{path=PathOf(node,source.transform),parent=node==source.transform?null:PathOf(node.parent,source.transform),position=node.localPosition,rotation=node.localRotation,scale=node.localScale,toPrefab=source.transform.worldToLocalMatrix*node.localToWorldMatrix,active=node.gameObject.activeSelf,components=node.GetComponents<Component>().Where(v=>v!=null).Select(v=>v.GetType().FullName).ToArray()});
      foreach(var component in node.GetComponents<Component>().Where(v=>v!=null))CaptureFields(component,source.transform,data,c);
     }
     if(source.BuildStates!=null)for(int i=0;i<source.BuildStates.Count;i++){var view=source.BuildStates[i].Visualizer;data.stages.Add(new Stage{index=i,visualizer=view==null?null:PathOf(view.transform,source.transform)});}
     foreach(var renderer in source.GetComponentsInChildren<Renderer>(true)){
      Mesh mesh=null;bool owned=false;string kind="MeshFilter";
      try{
       if(renderer is SkinnedMeshRenderer){mesh=new Mesh();owned=true;((SkinnedMeshRenderer)renderer).BakeMesh(mesh);kind="SkinnedMeshRenderer baked current pose";}
       else mesh=renderer.GetComponent<MeshFilter>()?.sharedMesh;
       if(mesh==null)continue;
       MeshData geometry;if(!c.meshes.TryGetValue(mesh.GetInstanceID(),out geometry)){geometry=ReadMesh(mesh,c);c.meshes.Add(mesh.GetInstanceID(),geometry);c.report.meshes.Add(geometry);}
       var part=new Part{path=PathOf(renderer.transform,source.transform),kind=kind,meshId=geometry.id,meshToPrefab=source.transform.worldToLocalMatrix*renderer.transform.localToWorldMatrix,rendererEnabled=renderer.enabled,materialIds=renderer.sharedMaterials.Select(m=>m==null?0:m.GetInstanceID()).ToArray()};data.parts.Add(part);
       var global=new MaterialPropertyBlock();renderer.GetPropertyBlock(global);
       var mats=renderer.sharedMaterials;for(int i=0;i<mats.Length;i++){var m=mats[i];if(m==null)continue;c.Material(m);var block=new MaterialPropertyBlock();renderer.GetPropertyBlock(block,i);part.slotBlocks.Add(new Block{slot=i,properties=Properties(m,block,c)});part.globalBlocksBySlot.Add(new Block{slot=i,properties=Properties(m,global,c)});if(i==0)part.globalBlock=part.globalBlocksBySlot.Last().properties;}
       part.obj="variant-"+pair.i+"-part-"+(data.parts.Count-1)+".obj";WriteObj(System.IO.Path.Combine(folder,part.obj),geometry,part.meshToPrefab);
      }catch(Exception e){c.report.errors.Add(source.PrefabName+" / "+renderer.name+": "+e.Message);}finally{if(owned&&mesh!=null)UnityEngine.Object.Destroy(mesh);}
     }
     if(data.parts.Count==0)c.report.errors.Add(source.PrefabName+": no meshes captured");
    }catch(Exception e){c.report.errors.Add(source.PrefabName+": "+e.Message);}
   }
   foreach(var texture in c.textures.Values){if(texture is Texture2DArray){var a=(Texture2DArray)texture;foreach(int slice in c.slices.Where(i=>i>=0&&i<a.depth).OrderBy(i=>i))c.report.textures.Add(ReadTexture(texture,slice,folder));}else c.report.textures.Add(ReadTexture(texture,0,folder));}
   c.report.status=c.report.errors.Count==0&&c.report.textures.All(t=>t.error==null)?"complete":"partial: inspect mesh/material/texture errors";
   File.WriteAllText(System.IO.Path.Combine(folder,"LogicIO-kit-appearance.json"),JsonUtility.ToJson(c.report,true));
   File.WriteAllText(System.IO.Path.Combine(folder,"README.txt"),"Original kit model reference. JSON is authoritative for hierarchy, transforms, original geometry/UVs/submesh indices, raw vertex streams, shaders/material properties and renderer overrides. OBJ files are geometry-only prefab-local exports; OBJ does not reproduce custom texture-array shaders. PNG textures are RGBA32 readbacks; source formats and array slices are in JSON. Material/texture IDs are capture-local. All active AND inactive parts/construction stages are retained. Alternate material fields and switch transforms are recorded. No source prefab, material or game state was modified. Skinned meshes, if present, are marked baked current pose. Any mesh/texture errors mean the visual export is incomplete.");
   return c.report;
  }
  private static MeshData ReadMesh(Mesh mesh,Context c){
   Vector3[] vertices;Vector2[] uv;int[][] groups;NativeMeshReader.Read(mesh,out vertices,out uv,out groups);
   var data=new MeshData{id=mesh.GetInstanceID(),name=mesh.name,vertices=vertices,uv=uv,normals=mesh.isReadable?mesh.normals:new Vector3[0],tangents=mesh.isReadable?mesh.tangents:new Vector4[0]};
   for(int i=0;i<groups.Length;i++)data.submeshes.Add(new Surface{slot=i,topology=mesh.GetTopology(i).ToString(),triangles=groups[i]});
   foreach(var a in mesh.GetVertexAttributes())data.attributes.Add(new Attribute{attribute=a.attribute.ToString(),format=a.format.ToString(),dimension=a.dimension,stream=mesh.GetVertexAttributeStream(a.attribute),offset=mesh.GetVertexAttributeOffset(a.attribute)});
   for(int i=0;i<mesh.vertexBufferCount;i++){
    var raw=new RawStream{stream=i,stride=mesh.GetVertexBufferStride(i)};data.streams.Add(raw);
    try{using(var b=mesh.GetVertexBuffer(i)){raw.bytes=b.count*b.stride;if(raw.bytes%4!=0)throw new InvalidOperationException("Unaligned vertex buffer");var words=new uint[raw.bytes/4];b.GetData(words);var bytes=new byte[raw.bytes];Buffer.BlockCopy(words,0,bytes,0,bytes.Length);raw.file="mesh-"+data.id+"-stream-"+i+".bin";File.WriteAllBytes(System.IO.Path.Combine(c.folder,raw.file),bytes);}}
    catch(Exception e){raw.error=e.Message;c.report.errors.Add("Mesh "+mesh.name+" raw stream "+i+": "+e.Message);}
   }return data;
  }
  private static void CaptureFields(Component component,Transform root,Variant data,Context c){
   if(component is Transform||component is Renderer||component is MeshFilter)return;
   for(Type t=component.GetType();t!=null&&t!=typeof(MonoBehaviour)&&t!=typeof(Component)&&t!=typeof(UnityEngine.Object);t=t.BaseType)foreach(var field in t.GetFields(BindingFlags.Instance|BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.DeclaredOnly)){
    try{
     var type=field.FieldType;object value=field.GetValue(component);if(value==null)continue;
     if(value is Material){var m=(Material)value;c.Material(m);data.nativeFields.Add(new FieldData{component=component.GetType().FullName,path=PathOf(component.transform,root),field=t.Name+"."+field.Name,type=type.FullName,materialRefs=new[]{m.GetInstanceID().ToString()}});}
     else if(value is IEnumerable<Material>){var materials=((IEnumerable<Material>)value).Where(m=>m!=null).ToArray();foreach(var m in materials)c.Material(m);data.nativeFields.Add(new FieldData{component=component.GetType().FullName,path=PathOf(component.transform,root),field=t.Name+"."+field.Name,type=type.FullName,materialRefs=materials.Select(m=>m.GetInstanceID().ToString()).ToArray()});}
     else if(type.IsPrimitive||type.IsEnum||type==typeof(Vector3)||type==typeof(Quaternion)||value is Transform){string text=value is Transform?PathOf((Transform)value,root):Convert.ToString(value,System.Globalization.CultureInfo.InvariantCulture);data.nativeFields.Add(new FieldData{component=component.GetType().FullName,path=PathOf(component.transform,root),field=t.Name+"."+field.Name,type=type.FullName,value=text,hasVector=value is Vector3,vector=value is Vector3?(Vector3)value:Vector3.zero,hasQuaternion=value is Quaternion,quaternion=value is Quaternion?(Quaternion)value:Quaternion.identity});}
     else if(!(value is UnityEngine.Object)&&!(value is Delegate)&&(type.IsSerializable||type.Name.IndexOf("Material",StringComparison.OrdinalIgnoreCase)>=0)){
      var nested=new List<Material>();CollectMaterials(value,3,nested,new HashSet<object>());
      if(nested.Count>0){foreach(var m in nested)c.Material(m);data.nativeFields.Add(new FieldData{component=component.GetType().FullName,path=PathOf(component.transform,root),field=t.Name+"."+field.Name,type=type.FullName,materialRefs=nested.Select(m=>m.GetInstanceID().ToString()).Distinct().ToArray()});}
     }
    }catch(Exception e){c.report.errors.Add("Field "+component.GetType().Name+"."+field.Name+": "+e.Message);}
   }
  }
  private static void CollectMaterials(object value,int depth,List<Material> output,HashSet<object> seen){
   if(value==null||depth<0||!seen.Add(value))return;if(value is Material){output.Add((Material)value);return;}
   var type=value.GetType();if(value is UnityEngine.Object||value is Delegate||value is string||type.IsPrimitive||type.IsEnum)return;
   if(value is System.Collections.IEnumerable){int n=0;foreach(var element in (System.Collections.IEnumerable)value){if(n++>=256)break;CollectMaterials(element,depth-1,output,seen);}return;}
   if(!type.IsSerializable&&type.Name.IndexOf("Material",StringComparison.OrdinalIgnoreCase)<0)return;
   foreach(var f in type.GetFields(BindingFlags.Instance|BindingFlags.Public|BindingFlags.NonPublic)){try{CollectMaterials(f.GetValue(value),depth-1,output,seen);}catch{}}
  }
  private static List<Property> Properties(Material m,MaterialPropertyBlock block,Context c){
   var result=new List<Property>();var shader=m.shader;if(shader==null)return result;
   for(int i=0;i<shader.GetPropertyCount();i++){
    string name=shader.GetPropertyName(i);int id=Shader.PropertyToID(name);var type=shader.GetPropertyType(i);var p=new Property{name=name,type=type.ToString(),blockHasProperty=block.HasProperty(id)};result.Add(p);
    if(type==ShaderPropertyType.Texture){var tex=m.GetTexture(id);var over=block.GetTexture(id);p.textureId=tex==null?0:tex.GetInstanceID();p.blockTextureId=over==null?0:over.GetInstanceID();p.scale=m.GetTextureScale(name);p.offset=m.GetTextureOffset(name);if(tex!=null)c.textures[tex.GetInstanceID()]=tex;if(over!=null)c.textures[over.GetInstanceID()]=over;}
    else if(type==ShaderPropertyType.Color){p.color=m.GetColor(id);if(p.blockHasProperty)p.blockColor=block.GetColor(id);}
    else if(type==ShaderPropertyType.Vector){p.vector=m.GetVector(id);if(p.blockHasProperty)p.blockVector=block.GetVector(id);}
    else if(type==ShaderPropertyType.Float||type==ShaderPropertyType.Range||type.ToString()=="Int"){p.value=type.ToString()=="Int"?m.GetInt(id):m.GetFloat(id);if(p.blockHasProperty)p.blockFloat=block.GetFloat(id);if(name.IndexOf("Index",StringComparison.OrdinalIgnoreCase)>=0||name.IndexOf("Slice",StringComparison.OrdinalIgnoreCase)>=0||name.IndexOf("Layer",StringComparison.OrdinalIgnoreCase)>=0){AddSlice(c.slices,p.value);if(p.blockHasProperty)AddSlice(c.slices,p.blockFloat);}}
   }return result;
  }
  private static void AddSlice(HashSet<int> set,float value){if(!float.IsNaN(value)&&!float.IsInfinity(value)&&value>=0&&value<2048&&Math.Abs(value-Math.Round(value))<.001f)set.Add((int)Math.Round(value));}
  private static TextureData ReadTexture(Texture texture,int slice,string folder){
   var result=new TextureData{id=texture.GetInstanceID(),name=texture.name,width=texture.width,height=texture.height,slice=slice,dimension=texture.dimension.ToString(),format=texture.graphicsFormat.ToString()};Texture2D readable=null;
   try{
    if(!(texture is Texture2D)&&!(texture is Texture2DArray))throw new InvalidOperationException("Unsupported texture dimension: "+texture.dimension);
    if(texture.width<=0||texture.height<=0||texture.width>8192||texture.height>8192)throw new InvalidOperationException("Texture readback size out of bounds");
    if(!SystemInfo.supportsAsyncGPUReadback)throw new InvalidOperationException("Local GPU readback unavailable; run this visual exporter in the game client");
    var read=AsyncGPUReadback.Request(texture,0,0,texture.width,0,texture.height,slice,1,TextureFormat.RGBA32);read.WaitForCompletion();if(read.hasError)throw new InvalidOperationException("GPU texture readback failed");
    readable=new Texture2D(texture.width,texture.height,TextureFormat.RGBA32,false);readable.LoadRawTextureData(read.GetData<byte>().ToArray());readable.Apply();result.file="texture-"+result.id+"-slice-"+slice+".png";File.WriteAllBytes(System.IO.Path.Combine(folder,result.file),readable.EncodeToPNG());
   }catch(Exception e){result.error=e.Message;}finally{if(readable!=null)UnityEngine.Object.Destroy(readable);}return result;
  }
  private static void WriteObj(string file,MeshData mesh,Matrix4x4 matrix){
   using(var w=new StreamWriter(file)){
    w.WriteLine("# Original prefab-local metres. Material slots reference LogicIO-kit-appearance.json; no substitute MTL shader.");
    foreach(var v in mesh.vertices){var p=matrix.MultiplyPoint3x4(v);w.WriteLine(FormattableString.Invariant($"v {p.x:R} {p.y:R} {p.z:R}"));}
    foreach(var uv in mesh.uv)w.WriteLine(FormattableString.Invariant($"vt {uv.x:R} {uv.y:R}"));
    bool hasUv=mesh.uv.Length==mesh.vertices.Length;bool mirrored=matrix.determinant<0;
    foreach(var group in mesh.submeshes){w.WriteLine("g material_slot_"+group.slot);if(group.topology!="Triangles"){w.WriteLine("# Non-triangle topology retained in reference JSON: "+group.topology);continue;}for(int i=0;i<group.triangles.Length;i+=3){int a=group.triangles[i]+1,b=group.triangles[i+(mirrored?2:1)]+1,c=group.triangles[i+(mirrored?1:2)]+1;w.WriteLine(hasUv?$"f {a}/{a} {b}/{b} {c}/{c}":$"f {a} {b} {c}");}}
   }
  }
  private static string PathOf(Transform current,Transform root){var names=new List<string>();while(current!=null){names.Add(current.name+"["+current.GetSiblingIndex()+"]");if(current==root)break;current=current.parent;}names.Reverse();return string.Join("/",names);}
 }
}
