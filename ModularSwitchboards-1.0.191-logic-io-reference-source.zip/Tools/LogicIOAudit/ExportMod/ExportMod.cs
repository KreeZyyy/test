using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using Assets.Scripts.Objects;
using System.Linq;
using System.Reflection;
using System.Text;
using Assets.Scripts;
using Assets.Scripts.Objects.Electrical;
using LaunchPadBooster;
using UnityEngine;
namespace LogicIOAuthoring {
 public sealed class NativeLogicIOAuditMod:MonoBehaviour {
  public static readonly Mod Mod=new Mod("NativeLogicIOAudit","0.2.0");
  private static bool started;
  [Serializable] public sealed class PlanReport {public string status="Authoring plan based on loaded original prefabs; DIN modules are not implemented by this utility.";public Layout[] modules;}
  public void OnLoaded(List<GameObject> prefabs){if(started)return;started=true;StartCoroutine(Collect());}
  private IEnumerator Collect(){
   Debug.Log("[Logic I/O Audit] Waiting for the original Logic I/O kit and its nine types. Read-only appearance and authoring export; no game objects, wiring or save data will be changed.");
   yield return null;yield return null;
   while(!TryExport())yield return new WaitForSecondsRealtime(2f);
  }
  [Serializable] public sealed class KitReport {public string prefab,name;public int rawConstructablesCount;public string[] candidates;public Member[] variants;public string[] planningErrors;}
  [Serializable] public sealed class Member {public int index;public string prefab,name,nativeType;}
  private bool captureAttempted;
  private float nextError;
  private bool TryExport(){
   try {
    var world=WorldManager.Instance;if(world==null||world.SourcePrefabs==null)return false;
    Templates templates;
    using(var stream=Assembly.GetExecutingAssembly().GetManifestResourceStream("LogicIOAudit.Layouts.json"))using(var reader=new StreamReader(stream))templates=JsonUtility.FromJson<Templates>(reader.ReadToEnd());
    if(templates?.modules==null||templates.modules.Length!=9)throw new InvalidOperationException("Nine control templates required.");
    var types=new HashSet<string>(templates.modules.Select(m=>m.nativeType));
    var sourceKits=world.SourcePrefabs.OfType<MultiConstructor>().Where(k=>k.Constructables!=null).ToArray();
    var options=sourceKits.Select((k,i)=>new KitOption{sourceIndex=i,prefab=k.PrefabName,memberTypes=k.Constructables.Select(v=>v==null?null:v.GetType().FullName).ToArray()}).ToArray();
    var matches=KitSelection.Match(options,types);if(matches.Length==0)return false;
    var kits=matches.Select(m=>sourceKits[m.sourceIndex]).ToArray();var kit=kits[0];
    var entries=kit.Constructables.Select((v,i)=>new{v,i}).Where(e=>e.v!=null).ToArray();
    var variants=entries.Select(e=>e.v).ToArray();var originalIndices=entries.Select(e=>e.i).ToArray();captureAttempted=true;
    string folder=Path.Combine(Path.GetDirectoryName(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location)),"Export");
    try{Directory.CreateDirectory(folder);}catch{folder=Path.Combine(Application.persistentDataPath,"NativeLogicIOAudit");Directory.CreateDirectory(folder);}
    string stem="NativeLogicIO-kit-reference-"+DateTime.UtcNow.ToString("yyyyMMdd-HHmmss");string reference=Path.Combine(folder,stem);Directory.CreateDirectory(reference);
    var plans=new List<Layout>();var planningErrors=new List<string>();
    try{
     var snapshot=LogicIOPrefabSnapshot.Capture(variants);
     Write(Path.Combine(reference,"NativeLogicIO-prefabs.json"),JsonUtility.ToJson(snapshot,true));
     foreach(var m in snapshot.modules){try{
      var native=new Native{prefab=m.prefab,concreteType=m.concreteType,usedPower=m.usedPower,input1Index=m.input1Index,outputIndex=m.outputIndex,openEndsPermutation=m.openEndsPermutation,ports=m.ports.Select(p=>new Port{index=p.index,type=p.type,role=p.role}).ToArray(),controls=m.controls.Select(c=>new Control{index=c.index,actionId=c.actionId,action=c.action,label=c.label,physical=c.colliderType!="none"}).ToArray()};
      plans.Add(Planner.Build(native,templates.modules.Single(t=>t.nativeType==native.concreteType)));
     }catch(Exception e){planningErrors.Add(m.prefab+": "+e.Message);}}
    }catch(Exception e){planningErrors.Add("Native connector snapshot: "+e.Message);}
    Write(Path.Combine(reference,"NativeLogicIO-top-bottom-plan.json"),JsonUtility.ToJson(new PlanReport{modules=plans.ToArray()},true));
    Write(Path.Combine(reference,"NativeLogicIO-top-bottom-plan.svg"),PlannerDrawing.Draw(plans));
    Write(Path.Combine(reference,"LogicIO-kit.json"),JsonUtility.ToJson(new KitReport{prefab=kit.PrefabName,name=kit.DisplayName,rawConstructablesCount=kit.Constructables.Count,candidates=kits.Select(k=>k.PrefabName).ToArray(),variants=variants.Select((v,i)=>new Member{index=originalIndices[i],prefab=v.PrefabName,name=v.DisplayName,nativeType=v.GetType().FullName}).ToArray(),planningErrors=planningErrors.ToArray()},true));
    Debug.Log("[Logic I/O Audit] Exporting original models from "+kit.PrefabName+": "+variants.Length+" variants. A short graphics readback pause is expected.");
    var visuals=KitAppearance.Export(kit.PrefabName,variants,originalIndices,Path.Combine(reference,"Models"));
    string zip=reference+".zip";ZipFile.CreateFromDirectory(reference,zip);
    int errors=visuals.errors.Count+visuals.textures.Count(t=>t.error!=null)+planningErrors.Count;
    Debug.Log("[Logic I/O Audit] "+(errors==0?"COMPLETE":"PARTIAL ("+errors+" recorded errors)")+": upload "+zip+". Variants="+visuals.variants.Count+", meshes="+visuals.meshes.Count+", materials="+visuals.materials.Count+", texture images="+visuals.textures.Count+". No playable DIN modules were added.");return true;
   }catch(Exception e){if(captureAttempted){Debug.LogError("[Logic I/O Audit] Export failed: "+e);return true;}if(Time.unscaledTime>=nextError){nextError=Time.unscaledTime+30f;Debug.LogWarning("[Logic I/O Audit] Waiting/retry: "+e.Message);}return false;}
  }
  private static void Write(string file,string content){var temp=file+".tmp";File.WriteAllText(temp,content);if(File.Exists(file))File.Delete(file);File.Move(temp,file);}
 }
}
