using System.Collections.Generic;
using System;
namespace UnityEngine
{
 public struct Vector3{
  public float x,y,z;public Vector3(float a,float b,float c){x=a;y=b;z=c;}public float sqrMagnitude=>x*x+y*y+z*z;public float magnitude=>(float)Math.Sqrt(sqrMagnitude);public Vector3 normalized=>magnitude<.000001f?new Vector3():this*(1/magnitude);
  public static Vector3 up=>new Vector3(0,1,0);public static Vector3 right=>new Vector3(1,0,0);public static Vector3 forward=>new Vector3(0,0,1);
  public static Vector3 operator +(Vector3 a,Vector3 b)=>new Vector3(a.x+b.x,a.y+b.y,a.z+b.z);public static Vector3 operator -(Vector3 a,Vector3 b)=>new Vector3(a.x-b.x,a.y-b.y,a.z-b.z);public static Vector3 operator *(Vector3 a,float b)=>new Vector3(a.x*b,a.y*b,a.z*b);
  public static Vector3 Lerp(Vector3 a,Vector3 b,float t)=>a+(b-a)*Math.Max(0,Math.Min(1,t));
  public static float Dot(Vector3 a,Vector3 b)=>a.x*b.x+a.y*b.y+a.z*b.z;public static Vector3 Cross(Vector3 a,Vector3 b)=>new Vector3(a.y*b.z-a.z*b.y,a.z*b.x-a.x*b.z,a.x*b.y-a.y*b.x);public static Vector3 ProjectOnPlane(Vector3 a,Vector3 normal)=>a-normal*(Dot(a,normal)/normal.sqrMagnitude);
 }
 public struct Quaternion{
  internal System.Numerics.Quaternion Value;public static Quaternion Yaw(float d)=>new Quaternion{Value=System.Numerics.Quaternion.CreateFromAxisAngle(System.Numerics.Vector3.UnitY,d*(float)Math.PI/180)};public static Quaternion Pitch(float d)=>new Quaternion{Value=System.Numerics.Quaternion.CreateFromAxisAngle(System.Numerics.Vector3.UnitX,d*(float)Math.PI/180)};
  public static Quaternion operator *(Quaternion a,Quaternion b)=>new Quaternion{Value=a.Value*b.Value};public static Quaternion Inverse(Quaternion q)=>new Quaternion{Value=System.Numerics.Quaternion.Inverse(q.Value)};
  public static Vector3 operator *(Quaternion q,Vector3 v){var r=System.Numerics.Vector3.Transform(new System.Numerics.Vector3(v.x,v.y,v.z),q.Value);return new Vector3(r.X,r.Y,r.Z);}
  public static Quaternion Slerp(Quaternion a,Quaternion b,float t)=>new Quaternion{Value=System.Numerics.Quaternion.Slerp(a.Value,b.Value,Math.Max(0,Math.Min(1,t)))};
  public static Quaternion FromToRotation(Vector3 from,Vector3 to){float angle=(float)Math.Atan2(Vector3.Cross(from,to).y,Vector3.Dot(from,to));return new Quaternion{Value=System.Numerics.Quaternion.CreateFromAxisAngle(System.Numerics.Vector3.UnitY,angle)};}
 }
 public struct Bounds{public Vector3 center,size;public Bounds(Vector3 c,Vector3 s){center=c;size=s;}}
 public class Transform{
 public string name="bone";public Vector3 position;public Transform parent;public Renderer renderer;public List<Transform> children=new List<Transform>();
 public Vector3 InverseTransformPoint(Vector3 p)=>p-position;
 public bool IsChildOf(Transform ancestor){for(var p=this;p!=null;p=p.parent)if(p==ancestor)return true;return false;}
 public T GetComponent<T>()where T:class=>renderer as T;
 public T[] GetComponentsInChildren<T>(bool inactive){var nodes=new List<T>();foreach(var child in children){if(child is T node)nodes.Add(node);nodes.AddRange(child.GetComponentsInChildren<T>(inactive));}return nodes.ToArray();}
 }
 public class Renderer{}
 public enum HumanBodyBones{LeftToes,RightToes}
 public class Animator{public Transform Left,Right;public Transform GetBoneTransform(HumanBodyBones id)=>id==HumanBodyBones.LeftToes?Left:Right;}
 public class Collider{public Transform transform=new Transform();public Bounds bounds;}public class BoxCollider:Collider{public Vector3 center,size;}public class MeshCollider:Collider{public Mesh sharedMesh;}public class Mesh{public Bounds bounds;}
 public struct RaycastHit{public Collider collider;public Vector3 point;}public static class Time{public static float time;}public static class Resources{public static T[] FindObjectsOfTypeAll<T>()=>new T[0];}
}