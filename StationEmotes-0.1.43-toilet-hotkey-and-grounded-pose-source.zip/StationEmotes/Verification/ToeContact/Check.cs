using System;using StationEmotes;using UnityEngine;
class Check{
 static int n;static void A(bool b,string m){n++;if(!b)throw new Exception(m);}
 static bool Same(Quaternion a,Quaternion b)=>(a*Vector3.forward-b*Vector3.forward).magnitude<.0001f&&(a*Vector3.up-b*Vector3.up).magnitude<.0001f;
 static Transform Child(Transform p,string name){var t=new Transform{parent=p,name=name};p.children.Add(t);return t;}
 static void Main(){
 var left=new Transform{name="Foot_L"};var right=new Transform{name="Foot_R"};var lt=Child(left,"Toe_L");var rt=Child(right,"Toe_R");var animator=new Animator{Left=lt,Right=rt};
 A(ChairToeContact.Find(animator,left,true)==lt,"mapped left toe");A(ChairToeContact.Find(animator,right,false)==rt,"mapped right toe");
 animator.Right=null;A(ChairToeContact.Find(animator,right,false)==rt,"named toe fallback missing");
 animator.Right=lt;A(ChairToeContact.Find(animator,right,false)==rt,"opposite foot mapping accepted");
 var mesh=Child(right,"ToeMesh");mesh.renderer=new Renderer();right.children.Remove(rt);right.children.Insert(0,mesh);right.children.Add(rt);
 A(ChairToeContact.Find(animator,right,false)==rt,"renderer selected as toe joint");
 var empty=new Transform{name="Foot"};A(ChairToeContact.Find(new Animator(),empty,false)==null,"missing toe invented");A(ChairToeContact.Find(new Animator(),null,false)==null,"missing foot");
 foreach(float bind in new[]{-17f,0f,35f}){
 var standing=Quaternion.Pitch(bind);var seated=Quaternion.Pitch(bind+70);var source=Quaternion.Pitch(bind+55);
 foreach(float rest in new[]{0f,.25f,.5f,1f})foreach(float clearance in new[]{-.01f,0f,.004f,.008f})
  A(Same(ChairToeContact.Rotation(true,source,standing,seated,rest,clearance,2),standing),"ground-contact toe curled while ankle was held flat");
 A(Same(ChairToeContact.Rotation(true,source,standing,seated,0,.1f,2),standing),"toe released before seated-rest phase");
 A(Same(ChairToeContact.Rotation(true,source,standing,seated,1,.06f,2),seated),"lifted seated toe never released");
 A(Same(ChairToeContact.Rotation(false,source,standing,seated,0,0,.1f),source),"exit toe changed before tucking finished");
 A(Same(ChairToeContact.Rotation(false,source,standing,seated,0,0,.52f),standing),"exit toe not planted before weight transfer");
 A(Same(ChairToeContact.Rotation(false,source,standing,seated,1,0,3),standing),"final outward exit toe rotated back to raw seated sample");
 }
 var stream=new ChairTorsoStream{Count=2};
 stream.Set(0,new ChairTorsoSlot{Handle=new UnityEngine.Animations.TransformStreamHandle{Id=1}});
 stream.Set(1,new ChairTorsoSlot{Handle=new UnityEngine.Animations.TransformStreamHandle{Id=2}});
 var native=new UnityEngine.Animations.AnimationStream();
 UnityEngine.Animations.TransformStreamHandle.Values[1]=Quaternion.Pitch(60);UnityEngine.Animations.TransformStreamHandle.Values[2]=Quaternion.Pitch(80);
 stream.Capture(native);A(stream.Get(0).Ready&&stream.Get(1).Ready,"toe samples unavailable");
 A(Same(stream.Get(1).NativeRotation,Quaternion.Pitch(80)),"native toe was sampled incorrectly");
 var frozen=stream;UnityEngine.Animations.TransformStreamHandle.Values[2]=Quaternion.Pitch(10);stream.Capture(native);
 A(Same(frozen.Get(1).NativeRotation,Quaternion.Pitch(80)),"frozen native toe endpoint changed");
 A(Same(stream.Get(1).NativeRotation,Quaternion.Pitch(10)),"live native toe capture stopped updating");
 var anchor=new ChairPoseAnchor(new ChairNativePose{Ready=true},default(ChairTorsoStream),default(ChairLocalPose),new Vector3(),Quaternion.Yaw(0),frozen);
 A(Same(anchor.ResolveToes(stream,0).Get(1).NativeRotation,Quaternion.Pitch(80)),"cached toe target used live entry pose");
 A(Same(anchor.ResolveToes(stream,1).Get(1).NativeRotation,Quaternion.Pitch(10)),"toe handover did not resolve live endpoint");
 A(Same(anchor.ResolveToes(stream,.5f).Get(1).NativeRotation,Quaternion.Pitch(45)),"toe endpoint blend discontinuity");
 stream.Set(0,new ChairTorsoSlot());stream.Capture(native);A(!stream.Get(0).Ready&&stream.Get(1).Ready,"missing toe invalidated the other foot");
 Console.WriteLine(n+" production toe mapping/contact/stream-sampling checks passed (bone/math/stream stubs).");
 }}
namespace UnityEngine{public static class Mathf{
 public static float Clamp(float x,float a,float b)=>Math.Max(a,Math.Min(b,x));
 public static float Abs(float x)=>Math.Abs(x);public static float Max(float a,float b)=>Math.Max(a,b);public static float Sqrt(float x)=>(float)Math.Sqrt(x);
}}
namespace UnityEngine.Animations{
 public struct AnimationStream{}
 public struct TransformStreamHandle{
  public int Id;public static Quaternion[] Values=new Quaternion[3];
  public bool IsValid(AnimationStream s)=>Id>0;public void Resolve(AnimationStream s){}
  public Quaternion GetLocalRotation(AnimationStream s)=>Values[Id];
 }
}

namespace StationEmotes{
 internal static class ChairPoseFrame{internal static Quaternion Upright(Quaternion q)=>q;}
 internal struct ChairNativePose{
 public bool Ready;public Vector3 Hips,Left,Right,Head,LeftUpper,LeftKnee,RightUpper,RightKnee;
 public Quaternion HipRotation,LeftRotation,RightRotation;
 }}
