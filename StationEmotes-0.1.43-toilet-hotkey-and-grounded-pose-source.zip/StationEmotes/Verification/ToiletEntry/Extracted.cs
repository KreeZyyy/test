using System;using System.Collections.Generic;using System.Reflection;using UnityEngine;using StationEmotes;using Assets.Scripts;using Assets.Scripts.Objects;using Assets.Scripts.Objects.Entities;using Assets.Scripts.GridSystem;using Objects.Structures;
using Assets.Scripts.Localization2;namespace StationEmotes{
 internal static class ToiletInteractPatch
 {
  static bool Prefix(StructureToilet __instance,Interactable __0,Interaction __1,bool __2,ref Thing.DelayedActionInstance __result)
  {
   var slot=ToiletSeating.Slot(__instance);if(slot==null)return true;
   var h=__1.SourceThing as Human;
   if(__0.Action==slot.Action||(__0.Action==InteractableType.Activate&&(h==null||h.ParentSlot!=slot||__1.AltKey)))
   {
    bool seated=h!=null&&h.ParentSlot==slot;
    var result=new Thing.DelayedActionInstance{Duration=.25f,ActionMessage=seated?"Stand up":"Sit down"};
    __result=result;
    if(h==null||h.State!=EntityState.Alive)return Fail(result,"Only a conscious engineer can sit here.");
    if(!__instance.IsStructureCompleted)return Fail(result,"Finish building the toilet first.");
    if(seated)
    {
     if(__2&&GameManager.RunSimulation&&!ToiletSeating.Exit(h,__instance))return Fail(result,"The space in front of the toilet is blocked.");
     result.Succeed();return false;
    }
    if(slot.IsLocked||h.ParentSlot!=null||slot.Get()!=null)return Fail(result,"The toilet is occupied or you are already seated.");
    // Native cursor reach and PreventInteraction already gate this action; do not add a pivot/ground test.
    if(__2&&GameManager.RunSimulation)
    {
     OnServer.MoveToSlot(h,slot);
     if(h.ParentSlot!=slot)return Fail(result,"Unable to sit: no safe floor or available seat.");
    }
    result.Succeed();return false;
   }
   if(__0.Action!=InteractableType.Activate)return true;
   var state=__instance.GetComponent<ToiletOccupancy>();
   bool ready=ToiletUsePolicy.Ready(h!=null&&h.ParentSlot==slot&&state!=null&&state.Occupant==h,h!=null&&h.GetComponent<ChairTransition>()?.Active==true,Time.time,state?.ReadyAt??float.PositiveInfinity);
   if(ready)return true; // Original suit, sanitation, water, pressure and waste handling stay authoritative.
   __result=new Thing.DelayedActionInstance{Duration=1,ActionMessage=GameStrings.Use};
   return Fail(__result,"Finish sitting down before using the toilet. Hold the quantity modifier and click to stand, or move forward.");
  }
  private static bool Fail(Thing.DelayedActionInstance result,string message){result.ExtendedMessage=message;result.Fail();return false;}
 }
}