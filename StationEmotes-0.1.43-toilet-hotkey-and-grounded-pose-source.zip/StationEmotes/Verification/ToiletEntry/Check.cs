using System;using System.Collections.Generic;using System.Reflection;using UnityEngine;using StationEmotes;using Assets.Scripts;using Assets.Scripts.Objects;using Assets.Scripts.Objects.Entities;using Assets.Scripts.GridSystem;using Objects.Structures;
class Check{
 static int n;static void A(bool b,string m){n++;if(!b)throw new Exception(m);}
 static bool Invoke(StructureToilet t,Interactable c,Human h,bool action,bool alt,out Thing.DelayedActionInstance result){
 object[] args={t,c,new Interaction{SourceThing=h,AltKey=alt},action,null};var pass=(bool)typeof(ToiletInteractPatch).GetMethod("Prefix",BindingFlags.Static|BindingFlags.NonPublic).Invoke(null,args);result=(Thing.DelayedActionInstance)args[4];return pass;}
 static void Main(){
 var t=new StructureToilet();var slot=new Slot{Parent=t,StringKey=ToiletSeating.Marker,Location=new Transform(),Type=Slot.Class.Entity,Action=InteractableType.Slot1};t.Slots.Add(slot);
 var bowl=new Interactable{Parent=t,Action=InteractableType.Activate};var h=new Human{State=EntityState.Alive,SuitWorn=true,InFront=false};
 GameManager.RunSimulation=true;Thing.DelayedActionInstance result;
 A(!Invoke(t,bowl,h,false,false,out result)&&result.Success&&result.ActionMessage=="Sit down","visible bowl still uses the custom geometry/ground gate");
 A(OnServer.Moves==0,"hover moved actor");
 A(!Invoke(t,bowl,h,true,false,out result)&&result.Success&&h.ParentSlot==slot,"suit-wearing actor could not enter through native slot");
 A(OnServer.Moves==1,"entry moved actor twice");
 var state=new ToiletOccupancy{Occupant=h,ReadyAt=5};t.StateObject=state;Time.time=1;h.Transition.Active=true;
 A(!Invoke(t,bowl,h,true,false,out result)&&!result.Success,"use before entry finished");
 Time.time=5;h.Transition.Active=false;A(Invoke(t,bowl,h,true,false,out result),"original Use handler bypassed after seating");A(h.SuitWorn,"entry altered native suit state");
 A(!Invoke(t,bowl,h,false,true,out result)&&result.ActionMessage=="Stand up"&&ToiletSeating.Exits==0,"stand hover changed actor");
 A(!Invoke(t,bowl,h,true,true,out result)&&ToiletSeating.Exits==1,"stand action failed");
 h.ParentSlot=null;slot.Occupant=new Human();A(!Invoke(t,bowl,h,true,false,out result)&&!result.Success&&OnServer.Moves==1,"occupied toilet accepted actor");slot.Occupant=null;
 slot.IsLocked=true;A(!Invoke(t,bowl,h,true,false,out result)&&!result.Success,"locked slot entry");slot.IsLocked=false;
 h.ParentSlot=new Slot();A(!Invoke(t,bowl,h,true,false,out result)&&!result.Success,"nested seat entry");h.ParentSlot=null;
 t.IsStructureCompleted=false;A(!Invoke(t,bowl,h,true,false,out result)&&!result.Success,"unfinished toilet entry");t.IsStructureCompleted=true;
 h.State=EntityState.Dead;A(!Invoke(t,bowl,h,true,false,out result)&&!result.Success,"dead actor entry");h.State=EntityState.Alive;
 GameManager.RunSimulation=false;A(!Invoke(t,bowl,h,true,false,out result)&&OnServer.Moves==1,"client ran authoritative entry");
 A(Invoke(t,new Interactable{Action=InteractableType.OnOff},h,false,false,out result),"other controls intercepted");
 Console.WriteLine(n+" production toilet entry/use checks passed (game stubs).");
 }}
namespace UnityEngine
{
 public struct Vector3{
  public float x,y,z;public Vector3(float a,float b,float c){x=a;y=b;z=c;}public float sqrMagnitude=>x*x+y*y+z*z;public float magnitude=>(float)Math.Sqrt(sqrMagnitude);public Vector3 normalized=>magnitude<.000001f?new Vector3():this*(1/magnitude);
  public static Vector3 up=>new Vector3(0,1,0);public static Vector3 right=>new Vector3(1,0,0);public static Vector3 forward=>new Vector3(0,0,1);
  public static Vector3 operator +(Vector3 a,Vector3 b)=>new Vector3(a.x+b.x,a.y+b.y,a.z+b.z);public static Vector3 operator -(Vector3 a,Vector3 b)=>new Vector3(a.x-b.x,a.y-b.y,a.z-b.z);public static Vector3 operator *(Vector3 a,float b)=>new Vector3(a.x*b,a.y*b,a.z*b);
  public static float Dot(Vector3 a,Vector3 b)=>a.x*b.x+a.y*b.y+a.z*b.z;public static Vector3 Cross(Vector3 a,Vector3 b)=>new Vector3(a.y*b.z-a.z*b.y,a.z*b.x-a.x*b.z,a.x*b.y-a.y*b.x);public static Vector3 ProjectOnPlane(Vector3 a,Vector3 normal)=>a-normal*(Dot(a,normal)/normal.sqrMagnitude);
 }
 public struct Quaternion{
  internal System.Numerics.Quaternion Value;public static Quaternion Yaw(float d)=>new Quaternion{Value=System.Numerics.Quaternion.CreateFromAxisAngle(System.Numerics.Vector3.UnitY,d*(float)Math.PI/180)};public static Quaternion Pitch(float d)=>new Quaternion{Value=System.Numerics.Quaternion.CreateFromAxisAngle(System.Numerics.Vector3.UnitX,d*(float)Math.PI/180)};
  public static Quaternion operator *(Quaternion a,Quaternion b)=>new Quaternion{Value=a.Value*b.Value};public static Quaternion Inverse(Quaternion q)=>new Quaternion{Value=System.Numerics.Quaternion.Inverse(q.Value)};
  public static Vector3 operator *(Quaternion q,Vector3 v){var r=System.Numerics.Vector3.Transform(new System.Numerics.Vector3(v.x,v.y,v.z),q.Value);return new Vector3(r.X,r.Y,r.Z);}
  public static Quaternion FromToRotation(Vector3 from,Vector3 to){float angle=(float)Math.Atan2(Vector3.Cross(from,to).y,Vector3.Dot(from,to));return new Quaternion{Value=System.Numerics.Quaternion.CreateFromAxisAngle(System.Numerics.Vector3.UnitY,angle)};}
 }
 public struct Bounds{public Vector3 center,size;public Bounds(Vector3 c,Vector3 s){center=c;size=s;}}
 public class Transform{public Vector3 position;public Vector3 InverseTransformPoint(Vector3 p)=>p-position;}
 public class Collider{public Transform transform=new Transform();public Bounds bounds;}public class BoxCollider:Collider{public Vector3 center,size;}public class MeshCollider:Collider{public Mesh sharedMesh;}public class Mesh{public Bounds bounds;}
 public struct RaycastHit{public Collider collider;public Vector3 point;}public static class Time{public static float time;}public static class Resources{public static T[] FindObjectsOfTypeAll<T>()=>new T[0];}
}
namespace Assets.Scripts{
 public static class GameManager{public static bool RunSimulation;}
 public static class CursorManager{public static RaycastHit CursorHit;}
 public static class MovementController{public enum Mode{Seated}}
}
namespace Assets.Scripts.Inventory{}
namespace HarmonyLib{}
namespace Assets.Scripts.GridSystem{public enum EntityState{Alive,Dead}}
namespace Assets.Scripts.Localization2{public static class GameStrings{public const string Use="Use";}}
namespace Assets.Scripts.Objects{
 public enum InteractableType{Activate,Slot1,Slot2,OnOff}
 public class Thing{
  public List<Slot> Slots=new List<Slot>();public List<Interactable> Interactables=new List<Interactable>();public Dictionary<InteractableType,Interactable> Actions=new Dictionary<InteractableType,Interactable>();public object StateObject;public bool IsStructureCompleted=true;
  public T GetComponent<T>()where T:class=>StateObject as T;
  public class DelayedActionInstance{public float Duration;public string ActionMessage,ExtendedMessage;public bool Success;public DelayedActionInstance Succeed(){Success=true;return this;}public DelayedActionInstance Fail(){Success=false;return this;}}
 }
 public class Slot{public enum Class{Entity}public Class Type;public Assets.Scripts.MovementController.Mode EntityControlMode;public Thing Parent;public Transform Location;public InteractableType Action;public string StringKey;public int StringHash;public bool IsLocked;public BoxCollider Collider;public Interactable Interactable;public Thing Occupant;public Thing Get()=>Occupant;}
 public class Interactable{public Thing Parent;public Slot Slot;public InteractableType Action;public string StringKey;public int StringHash;public Collider Collider;public Bounds Bounds,OriginalBounds;public void Initialize(){Slot=Parent.Slots.Find(s=>s.Action==Action);if(Slot!=null)Slot.Interactable=this;}}
 public struct Interaction{public Thing SourceThing;public bool AltKey;}
}
namespace Assets.Scripts.Objects.Entities{
 public class Human:Thing{public Slot ParentSlot;public Assets.Scripts.GridSystem.EntityState State;public bool SuitWorn,InFront=true;public ChairTransition Transition=new ChairTransition();public new T GetComponent<T>()where T:class=>Transition as T;}
}
namespace Objects.Structures{public class StructureToilet:Thing{}}
namespace StationEmotes{
 public class ChairTransition{public bool Active;public static bool InFront(Human h,Thing t)=>throw new Exception("Extra position/ground gate was called");}
 internal class ToiletOccupancy{public Human Occupant;public float ReadyAt;}
 internal static class ToiletSeating{public const string Marker="StationEmotesToiletSeat";public static int Exits;public static Slot Slot(StructureToilet t)=>t.Slots.Find(s=>s.StringKey==Marker);public static bool Exit(Human h,StructureToilet t){Exits++;h.ParentSlot=null;return true;}public static void Register(Thing t,string f,object k,object v){if(f=="_interactableLookup")t.Actions[(InteractableType)k]=(Interactable)v;}}
 internal static class ChairSeatRouting{public static bool Supported(Thing t)=>true;public static bool Supported(Slot s)=>s!=null&&s.Location!=null;}
}
public static class OnServer{public static int Moves;public static void MoveToSlot(Human h,Slot s){Moves++;h.ParentSlot=s;s.Occupant=h;}}
