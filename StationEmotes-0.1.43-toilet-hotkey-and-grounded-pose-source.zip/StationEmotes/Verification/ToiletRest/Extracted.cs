using UnityEngine;namespace StationEmotes{
 internal static class ToiletRestPolicy
 {
  internal static Vector3 Foot(Vector3 hipJoint,Vector3 forward,Vector3 right,int side,float floorAnkle)
  {
   var foot=hipJoint+forward*.14f+right*(side==0?-.025f:.025f);foot.y=floorAnkle;return foot;
  }
  internal static Vector3 Reachable(Vector3 joint,Vector3 target,float reach)
  {
   float safe=Mathf.Max(0,reach-.002f),vertical=joint.y-target.y;
   float radius=Mathf.Sqrt(Mathf.Max(0,safe*safe-vertical*vertical));
   var offset=target-joint;offset.y=0;
   if(offset.magnitude>radius){offset=offset.normalized*radius;target.x=joint.x+offset.x;target.z=joint.z+offset.z;}
   return target;
  }
  internal static float Drop(Vector3 left,Vector3 right,Vector3 lfoot,Vector3 rfoot,float lreach,float rreach)
   =>Mathf.Min(.03f,Mathf.Max(ChairExitPlacement.RequiredDrop(left,lfoot,lreach),ChairExitPlacement.RequiredDrop(right,rfoot,rreach)));
 }
}