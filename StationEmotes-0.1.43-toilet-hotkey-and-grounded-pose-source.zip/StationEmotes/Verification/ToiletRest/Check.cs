using System;using StationEmotes;using UnityEngine;
class Check{
 static int n;static void A(bool b,string m){n++;if(!b)throw new Exception(m);}
 static void Main(){
 foreach(float yaw in new[]{0f,90f,180f,270f})foreach(float reach in new[]{.30f,.35f,.402f,.48f}){
 var forward=Quaternion.Yaw(yaw)*Vector3.forward;var right=Quaternion.Yaw(yaw)*Vector3.right;var centre=new Vector3(10,128.5f,20);var anchor=ToiletSeatGeometry.Anchor(centre,128,forward);
 A(Math.Abs(anchor.y-128.04f)<.0001f,"seat lift missing");A(Vector3.Dot(anchor-new Vector3(centre.x,anchor.y,centre.z),forward)>.1799f,"pelvis not shifted toward front edge");
 float nativeHip=.423f*reach/.402f,sole=.071f*reach/.402f;
 var mid=new Vector3(anchor.x,128+nativeHip+ToiletSeatGeometry.Lift,anchor.z);var left=mid-right*.075f;var other=mid+right*.075f;
 var lf=ToiletRestPolicy.Foot(left,forward,right,0,128+sole);var rf=ToiletRestPolicy.Foot(other,forward,right,1,128+sole);
 float drop=ToiletRestPolicy.Drop(left,other,lf,rf,reach,reach);
 A(drop>=0&&drop<=.030001f,"unbounded pelvis drop");
 left-=Vector3.up*drop;other-=Vector3.up*drop;
 lf=ToiletRestPolicy.Reachable(left,lf,reach);rf=ToiletRestPolicy.Reachable(other,rf,reach);
 A(Math.Abs(lf.y-(128+sole))<.0001f&&Math.Abs(rf.y-(128+sole))<.0001f,"feet lifted from floor");
 A((lf-left).magnitude<=reach-.0018f&&(rf-other).magnitude<=reach-.0018f,"pose stretches legs to reach floor");
 A(ToiletSeatGeometry.Lift-drop>=.0099f,"custom pose sank below previous seated height");
 A(Vector3.Dot(rf-lf,right)>.15f,"left/right ground contacts cross");
 }
 Console.WriteLine(n+" production toilet pose lift/forward/ground-contact/reach checks passed (math stubs).");
 }}
namespace UnityEngine{public static class Mathf{
 public static float Abs(float x)=>Math.Abs(x);public static float Sqrt(float x)=>(float)Math.Sqrt(x);public static float Max(float a,float b)=>Math.Max(a,b);public static float Min(float a,float b)=>Math.Min(a,b);public static float Clamp(float x,float a,float b)=>Math.Max(a,Math.Min(b,x));}}
