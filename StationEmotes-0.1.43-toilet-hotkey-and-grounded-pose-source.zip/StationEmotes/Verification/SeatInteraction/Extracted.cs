using System;using System.Collections.Generic;using UnityEngine;using Assets.Scripts;using Assets.Scripts.Objects;using Assets.Scripts.Objects.Entities;using Assets.Scripts.GridSystem;using Assets.Scripts.Localization2;using Objects.Structures;
namespace StationEmotes{
 internal static class ToiletInteractPatch
 {
  static bool Prefix(StructureToilet __instance,Interactable __0,Interaction __1,bool __2,ref Thing.DelayedActionInstance __result)
  {
   var slot=ToiletSeating.Slot(__instance);if(slot==null)return true;
   var h=__1.SourceThing as Human;
   if(__0.Action==slot.Action||(__0.Action==InteractableType.Activate&&(h==null||h.ParentSlot!=slot||__1.AltKey)))
   {
    bool seated=h!=null&&h.ParentSlot==slot;
    var result=new Thing.DelayedActionInstance{Duration=.25f,ActionMessage=seated?"Stand up":"Sit down"};
    __result=result;
    if(h==null||h.State!=EntityState.Alive)return Fail(result,"Only a conscious engineer can sit here.");
    if(!__instance.IsStructureCompleted)return Fail(result,"Finish building the toilet first.");
    if(seated)
    {
     if(__2&&GameManager.RunSimulation&&!ToiletSeating.Exit(h,__instance))return Fail(result,"The space in front of the toilet is blocked.");
     result.Succeed();return false;
    }
    if(slot.IsLocked||h.ParentSlot!=null||slot.Get()!=null)return Fail(result,"The toilet is occupied or you are already seated.");
    if(!ChairTransition.InFront(h,__instance))return Fail(result,"Move closer to the toilet on solid ground to sit down.");
    if(__2&&GameManager.RunSimulation)OnServer.MoveToSlot(h,slot);
    result.Succeed();return false;
   }
   if(__0.Action!=InteractableType.Activate)return true;
   var state=__instance.GetComponent<ToiletOccupancy>();
   bool ready=ToiletUsePolicy.Ready(h!=null&&h.ParentSlot==slot&&state!=null&&state.Occupant==h,h!=null&&h.GetComponent<ChairTransition>()?.Active==true,Time.time,state?.ReadyAt??float.PositiveInfinity);
   if(ready)return true; // Original suit, sanitation, water, pressure and waste handling stay authoritative.
   __result=new Thing.DelayedActionInstance{Duration=1,ActionMessage=GameStrings.Use};
   return Fail(__result,"Finish sitting down before using the toilet. Hold the quantity modifier and click to stand, or move forward.");
  }
  private static bool Fail(Thing.DelayedActionInstance result,string message){result.ExtendedMessage=message;result.Fail();return false;}
 }
 internal static class SeatInteractionRouting
 {
  internal static void InstallLoaded()
  {
   foreach(var thing in Resources.FindObjectsOfTypeAll<Thing>())
    if(ChairSeatRouting.Supported(thing))Ensure(thing);
  }
  internal static void Ensure(Thing thing)
  {
   if(thing.Slots==null)return;
   for(int i=0;i<thing.Slots.Count;i++)
   {
    var slot=thing.Slots[i];
    if(slot.Type!=Slot.Class.Entity||slot.EntityControlMode!=MovementController.Mode.Seated||slot.Location==null)continue;
    slot.Parent=thing;slot.Action=(InteractableType)Enum.Parse(typeof(InteractableType),"Slot"+(i+1));
    var control=thing.Interactables.Find(c=>c.Action==slot.Action);
    if(control==null)
    {
     control=new Interactable{Parent=thing,Action=slot.Action,StringKey=slot.StringKey,StringHash=slot.StringHash,Collider=slot.Collider};
     thing.Interactables=new List<Interactable>(thing.Interactables);thing.Interactables.Add(control);
    }
    control.Parent=thing;control.Initialize();
    ToiletSeating.Register(thing,"_interactableLookup",slot.Action,control);
    slot.Interactable=control;
   }
  }
  internal static Interactable FromSurface(Thing thing,Collider collider,Interactable original)
  {
   if(collider==null||thing is StructureToilet||!ChairSeatRouting.Supported(thing)||thing.Slots==null)return original;
   // Dedicated power, door and other native controls retain their actions.
   if(original!=null&&original.Slot==null)return original;
   var slots=thing.Slots.FindAll(ChairSeatRouting.Supported);if(slots.Count==0)return original;
   var hit=CursorManager.CursorHit;
   var point=hit.collider==collider?hit.point:collider.bounds.center;
   var positions=new Vector3[slots.Count];for(int i=0;i<positions.Length;i++)positions[i]=slots[i].Location.position;
   int index=SeatSelectionPolicy.Nearest(point,positions);if(index<0)return original;
   var control=slots[index].Interactable;
   if(control==null){Ensure(thing);control=slots[index].Interactable;}
   if(control==null)return original;
   // Reuse the visible, raycast-selected furniture surface. Added trigger hitboxes are not required.
   control.Collider=collider;
   if(collider is BoxCollider box)control.Bounds=new Bounds(box.center,box.size);
   else if(collider is MeshCollider mesh&&mesh.sharedMesh!=null)control.Bounds=mesh.sharedMesh.bounds;
   else
   {
    var bounds=collider.bounds;control.Bounds=new Bounds(collider.transform.InverseTransformPoint(bounds.center),bounds.size);
   }
   control.OriginalBounds=control.Bounds;
   return control;
  }
 }
}
