from pathlib import Path
root=Path(__file__).resolve().parents[2]
def extract(filename,classname):
    text=(root/'source'/filename).read_text()
    start=text.index(' internal static class '+classname)
    opening=text.index('{',start);depth=1;i=opening+1
    while depth:
        if text[i]=='{':depth+=1
        elif text[i]=='}':depth-=1
        i+=1
    return text[start:i]
header='using System;using System.Collections.Generic;using UnityEngine;using Assets.Scripts;using Assets.Scripts.Objects;using Assets.Scripts.Objects.Entities;using Assets.Scripts.GridSystem;using Assets.Scripts.Localization2;using Objects.Structures;\nnamespace StationEmotes{\n'
Path(__file__).with_name('Extracted.cs').write_text(header+extract('ToiletSeating.cs','ToiletInteractPatch')+'\n'+extract('SeatInteractionRouting.cs','SeatInteractionRouting')+'\n}\n')
