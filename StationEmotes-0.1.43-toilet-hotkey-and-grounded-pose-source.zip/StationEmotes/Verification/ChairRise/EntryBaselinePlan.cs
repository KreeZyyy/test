using System;
namespace StationEmotes
{
 // Per-interaction choreography. Step counts depend on distance and facing, not fixed loops.
 internal sealed class BaselineChairPlan
 {
  internal readonly bool Entering;
  internal readonly int WalkSteps,TurnSteps;
  internal readonly float WalkDuration,TurnDuration,BodyStart,TurnStart,WalkStart,Duration;
  internal const float Pause=.14f,Transfer=.22f,BodyDuration=1.05f;
  internal int StepCount=>WalkSteps+TurnSteps;
  internal BaselineChairPlan(bool entering,float distance,float angle)
  {
   Entering=entering;WalkSteps=Count(distance,.07f,.27f,4);TurnSteps=Count(Math.Abs(angle),9f,36f,6);
   WalkDuration=WalkSteps*.34f;TurnDuration=TurnSteps*.26f;
   if(entering){WalkStart=0;TurnStart=WalkDuration;BodyStart=WalkDuration+TurnDuration+Pause;Duration=BodyStart+BodyDuration+.14f;}
   else{BodyStart=Transfer;TurnStart=Transfer+BodyDuration+Pause;WalkStart=TurnStart+TurnDuration;Duration=WalkStart+WalkDuration+.14f;}
  }
  private static int Count(float value,float threshold,float stride,int maximum)
  {
   if(float.IsNaN(value)||float.IsInfinity(value)||value<=threshold)return 0;
   int count=(int)Math.Ceiling(value/stride);count=Math.Max(2,count);if((count&1)!=0)count++;
   return Math.Min(maximum,count);
  }
  internal float Walk(float time)=>WalkSteps==0?(time<WalkStart?0:1):ChairTransitionPolicy.Ease((time-WalkStart)/WalkDuration);
  internal float Turn(float time)=>TurnSteps==0?1:ChairTransitionPolicy.Ease((time-TurnStart)/TurnDuration);
  internal float Body(float time)=>ChairTransitionPolicy.Ease((time-BodyStart)/BodyDuration);
  internal float Preparation(float time)=>ChairTransitionPolicy.Ease(time/Transfer);
  internal float EndRelease(float time)=>ChairTransitionPolicy.Ease((time-(Duration-.14f))/.14f);
  internal string Stage(float time)
  {
   if(Entering){if(time<WalkDuration)return "approach";if(time<TurnStart+TurnDuration)return "turn";if(time<BodyStart)return "settle";if(time<BodyStart+BodyDuration)return "sit";return "native seat";}
   if(time<Transfer)return "weight transfer";if(time<TurnStart-Pause)return "rise";if(time<TurnStart)return "stand";if(time<WalkStart)return "turn";if(time<WalkStart+WalkDuration)return "step away";return "native standing";
  }
  internal void Step(int index,out float start,out float duration,out float advance,out bool turning)
  {
   turning=Entering?index>=WalkSteps:index<TurnSteps;
   int local=turning?(Entering?index-WalkSteps:index):(Entering?index:index-TurnSteps);
   int count=turning?TurnSteps:WalkSteps;duration=turning?.26f:.34f;
   start=(turning?TurnStart:WalkStart)+local*duration;
   // The last pair lands at the same final stance; no stranded half-step at the endpoint.
   advance=ChairTransitionPolicy.Ease(Math.Min(1,(local+1f)/Math.Max(1,count-1)));
  }
 }
}
