using System;
using StationEmotes;
using UnityEngine;
class Check
{
 static int checks;
 static void A(bool value,string message){checks++;if(!value)throw new Exception(message);}
 static bool Near(float a,float b)=>Math.Abs(a-b)<.0001f;
 static bool Near(Vector3 a,Vector3 b)=>(a-b).magnitude<.0001f;
 static void Main()
 {
  foreach(float yaw in new[]{0f,45f,90f,180f,270f})
  {
   var facing=Quaternion.Yaw(yaw);var right=facing*new Vector3(1,0,0);var forward=facing*Vector3.forward;
   var center=new Vector3(10,128,-20);var left=center-right*.24f;var second=center+right*.24f;
   // Shared prefab exit is in the middle. Both occupants must leave in front of their cushion.
   var shared=center+forward*.65f;shared.y=128;
   var lf=ChairSeatGeometry.Front(left,facing,shared,left,facing,true);
   var rf=ChairSeatGeometry.Front(second,facing,shared,left,facing,true);
   A(Near(lf,left+forward*.65f),"left exit collapsed to center");
   A(Near(rf,second+forward*.65f),"right exit collapsed to center");
   A(Near(Vector3.Dot(rf-lf,right),.48f),"slot separation lost");
   A(Near(Vector3.Dot(rf-second,right),0),"exit has sideways movement");
   A(Near(ChairSeatGeometry.Front(center,facing,shared,center,facing,false),shared),"single native exit changed");
   // Opposite-facing positions must leave on opposite sides.
   var opposite=Quaternion.Yaw(yaw+180);
   var back=ChairSeatGeometry.Front(second,opposite,shared,left,facing,true);
   A(Near(back,second-forward*.65f),"opposite seat exits wrong side");
   for(int tick=0;tick<=100;tick++)
   {
    float t=tick/100f;
    var rotation=ChairSeatGeometry.VisualRotation(false,Quaternion.Yaw(yaw+70),facing,t,Quaternion.Yaw(yaw-125),t);
    A(Near(rotation*Vector3.forward,forward),"exit body turns toward camera or native yaw");
   }
   var entry=ChairSeatGeometry.VisualRotation(true,Quaternion.Yaw(yaw-90),facing,1,facing,0);
   A(Near(entry*Vector3.forward,forward),"entry does not finish facing outward");
  }
  foreach(bool same in new[]{false,true})foreach(bool active in new[]{false,true})
   foreach(float time in new[]{0f,3.9f,4f,5f})
    A(ToiletUsePolicy.Ready(same,active,time,4)==(same&&!active&&time>=4),"toilet use before seated/finished");
  foreach(float bad in new[]{float.NaN,float.NegativeInfinity,float.PositiveInfinity})
  {A(!ToiletUsePolicy.Ready(true,false,bad,4),"invalid current time accepted");A(!ToiletUsePolicy.Ready(true,false,4,bad),"invalid completion time accepted");}
  A(ChairLayoutPolicy.DoubleName("StructureSeatSofaDouble"),"double prefab undetected");
  A(ChairLayoutPolicy.DoubleName("SeatTwoSeat"),"two-seat prefab undetected");
  A(!ChairLayoutPolicy.DoubleName("StructureChair"),"single became double");
  A(!ChairLayoutPolicy.DoubleName(null),"null name");
  foreach(float width in new[]{0f,.5f,1f,2f,10f,float.NaN,float.PositiveInfinity})
   A(ChairLayoutPolicy.HalfSpacing(width)>=.18f&&ChairLayoutPolicy.HalfSpacing(width)<=.35f,"unsafe double spacing");
  Console.WriteLine(checks+" production seat geometry, exit-facing and toilet readiness checks passed (math stubs).");
 }
}
namespace UnityEngine
{
 public struct Vector3
 {
  public float x,y,z;public Vector3(float x,float y,float z){this.x=x;this.y=y;this.z=z;}
  public static Vector3 forward=>new Vector3(0,0,1);
  public float magnitude=>(float)Math.Sqrt(x*x+y*y+z*z);
  public static Vector3 operator +(Vector3 a,Vector3 b)=>new Vector3(a.x+b.x,a.y+b.y,a.z+b.z);
  public static Vector3 operator -(Vector3 a,Vector3 b)=>new Vector3(a.x-b.x,a.y-b.y,a.z-b.z);
  public static Vector3 operator *(Vector3 a,float b)=>new Vector3(a.x*b,a.y*b,a.z*b);
  public static float Dot(Vector3 a,Vector3 b)=>a.x*b.x+a.y*b.y+a.z*b.z;
 }
 public struct Quaternion
 {
  internal System.Numerics.Quaternion Value;
  public static Quaternion Yaw(float degrees)=>new Quaternion{Value=System.Numerics.Quaternion.CreateFromAxisAngle(System.Numerics.Vector3.UnitY,degrees*(float)Math.PI/180)};
  public static Vector3 operator *(Quaternion q,Vector3 v){var r=System.Numerics.Vector3.Transform(new System.Numerics.Vector3(v.x,v.y,v.z),q.Value);return new Vector3(r.X,r.Y,r.Z);}
  public static Quaternion Slerp(Quaternion a,Quaternion b,float t)=>new Quaternion{Value=System.Numerics.Quaternion.Slerp(a.Value,b.Value,Math.Max(0,Math.Min(1,t)))};
 }
 public static class Mathf{public static float Clamp(float t,float a,float b)=>Math.Max(a,Math.Min(b,t));}
}
