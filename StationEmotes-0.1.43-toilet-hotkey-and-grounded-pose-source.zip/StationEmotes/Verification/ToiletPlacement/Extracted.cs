using System;using UnityEngine;using Assets.Scripts.Objects;using Assets.Scripts.Objects.Entities;using Objects.Structures;using HarmonyLib;namespace StationEmotes{internal static class ToiletSeating{internal static Slot Slot(StructureToilet t)=>t.Seat;
  internal static bool PrepareEntry(StructureToilet toilet,Human human)
  {
   var slot=Slot(toilet);if(slot?.Location==null)return false;
   var centre=toilet.transform.TransformPoint(new Vector3(0,0,.05f));
   var bowl=toilet.Interactables.Find(c=>c.Action==InteractableType.Activate)?.Collider;
   if(bowl!=null&&bowl.bounds.size.sqrMagnitude>.000001f)centre=bowl.bounds.center;
   var probe=centre;probe.y=Mathf.Max(centre.y,toilet.transform.position.y);
   ChairFloorContact floor;
   if(!ChairFloorProbe.Try(probe,toilet,human,float.NaN,out floor,3.5f))
   {Plugin.Log.LogWarning("Toilet entry skipped: no verified floor below bowl.");return false;}
   Vector3 scale;
   if(!ToiletSeatGeometry.TryUnitScale(toilet.transform.lossyScale,out scale))return false;
   slot.Location.localScale=scale;
   slot.Location.position=ToiletSeatGeometry.Anchor(centre,floor.Point.y,ChairPoseFrame.Upright(slot.Location.rotation)*Vector3.forward);
   var context=toilet.GetComponent<ToiletOccupancy>()??toilet.gameObject.AddComponent<ToiletOccupancy>();context.FloorY=floor.Point.y;context.FloorReady=true;
   Plugin.Log.LogInfo("Toilet seat anchor: floor="+floor.Point.y.ToString("F3")+", origin="+slot.Location.position.ToString("F3")+", parent scale="+toilet.transform.lossyScale.ToString("F3")+", slot world scale="+slot.Location.lossyScale.ToString("F3"));
   return true;
  }
}
 internal static class ToiletSeatPreparationPatch
 {
  [HarmonyPriority(Priority.First)]
  static bool Prefix(DynamicThing __instance,Slot __0,ref bool __result)
  {
   if(!(__instance is Human human)||!(__0?.Parent is StructureToilet toilet)||__0!=ToiletSeating.Slot(toilet)||__0.Get()!=null)return true;
   if(ToiletSeating.PrepareEntry(toilet,human))return true;
   __result=false;return false;
  }
 }
internal static class ChairTransition{
  internal static bool InFront(Human h,Slot slot)
  {
   if(slot==null)return false;
   if(!h.IsGrounded(h.AllButPlayerImmune,.12f))return false;
   var forward=ChairSeatRouting.Facing(slot)*Vector3.forward;
   var right=Vector3.Cross(Vector3.up,forward);
   var delta=h.ThingTransform.position-slot.Location.position;
   float height=h.ThingTransform.position.y-slot.Parent.ThingTransform.position.y;
   if(slot.Parent is Objects.Structures.StructureToilet)
   {delta.y=0;return ChairApproachPolicy.Toilet(delta.sqrMagnitude,height);}
   return ChairApproachPolicy.Seat(Vector3.Dot(delta,right),Vector3.Dot(delta,forward),height);
  }
}}