using System;using StationEmotes;using UnityEngine;
class Check{
 static int n;static void A(bool b,string m){n++;if(!b)throw new Exception(m);}static bool Near(float a,float b)=>Math.Abs(a-b)<.0001f;
 static void Main(){
 var upper=new Vector3(0,1,0);var knee=new Vector3(0,.5f,0);var ankle=new Vector3(0,0,0);
 var straight=ChairLegMetrics.Measure(upper,knee,ankle,ankle,0);A(Near(straight.Upper,.5f)&&Near(straight.Lower,.5f),"segment lengths");A(Near(straight.Maximum,1)&&Near(straight.Minimum,0),"reach range");A(Near(straight.KneeFlex,0)&&Near(straight.ReachRatio,1),"straight calibration");
 var bent=ChairLegMetrics.Measure(upper,knee,new Vector3(0,.5f,.5f),new Vector3(0,.5f,.5f),0);A(Near(bent.KneeFlex,90),"bent knee");A(Near(bent.ReachRatio,(float)Math.Sqrt(.5)),"bent extension ratio");
 var lateral=ChairLegMetrics.Measure(upper,knee,ankle,new Vector3(1,0,0),0);A(Near(lateral.Horizontal,1)&&Near(lateral.Vertical,1),"horizontal vs height");A(lateral.Status==ChairReachStatus.Unreachable&&lateral.Excess>.4f,"target too far");
 A(ChairLegMetrics.Classify(.5f,.5f,.9f,.1f)==ChairReachStatus.SolverResidual,"reachable target with solver error");A(ChairLegMetrics.Classify(.5f,.5f,1.2f,.1f)==ChairReachStatus.Unreachable,"geometric failure wins");A(ChairLegMetrics.Classify(.6f,.2f,.1f,0)==ChairReachStatus.Unreachable,"target too close to fold");A(ChairLegMetrics.Classify(.5f,.5f,.9f,.005f)==ChairReachStatus.Valid,"normal numerical error");
 foreach(float bad in new[]{float.NaN,float.PositiveInfinity,-1}){A(ChairLegMetrics.Classify(bad,.5f,.7f,0)==ChairReachStatus.Invalid,"invalid length");A(ChairLegMetrics.Classify(.5f,.5f,bad,0)==ChairReachStatus.Invalid,"invalid distance");}
 foreach(float scale in new[]{.5f,1f,2f}){A(ChairLegMetrics.Classify(.2f*scale,.2f*scale,.35f*scale,.001f)==ChairReachStatus.Valid,"scaled avatar");A(ChairLegMetrics.Classify(.2f*scale,.2f*scale,.6f*scale,0)==ChairReachStatus.Unreachable,"scaled unreachable");}
 Console.WriteLine(n+" production leg geometry/classification checks passed (vector math stubs).");}}
namespace UnityEngine{public struct Vector3{public float x,y,z;public Vector3(float a,float b,float c){x=a;y=b;z=c;}public static Vector3 operator -(Vector3 a,Vector3 b)=>new Vector3(a.x-b.x,a.y-b.y,a.z-b.z);public float magnitude=>(float)Math.Sqrt(x*x+y*y+z*z);public static float Angle(Vector3 a,Vector3 b){float denominator=a.magnitude*b.magnitude;if(denominator<.0000001)return 0;double dot=(a.x*b.x+a.y*b.y+a.z*b.z)/denominator;return (float)(Math.Acos(Math.Max(-1,Math.Min(1,dot)))*180/Math.PI);}}}
