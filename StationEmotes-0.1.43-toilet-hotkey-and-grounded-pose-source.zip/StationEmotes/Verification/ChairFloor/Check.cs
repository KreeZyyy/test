using System;using StationEmotes;using UnityEngine;using Assets.Scripts.Objects.Entities;using Assets.Scripts.Objects.Structures;
class Check{
 static int n;static void A(bool b,string m){n++;if(!b)throw new Exception(m);}static bool Near(float a,float b)=>Math.Abs(a-b)<.00001f;
 static Collider C(string name,object owner=null,Transform parent=null){return new Collider{name=name,transform=new Transform{Owner=owner,parent=parent}};}
 static RaycastHit H(Collider c,float y,float distance,float normal=1)=>new RaycastHit{collider=c,point=new Vector3(0,y,0),normal=new Vector3(0,normal,0),distance=distance};
 static void Main(){
 var seat=new Seat();var human=new Human();var floor=C("Frame floor");var seatCollider=C("Chair base",null,seat.ThingTransform);var humanCollider=C("Boot",human);var otherChair=new Seat();var otherCollider=C("Other chair",otherChair);
 Physics.Hits=new[]{H(seatCollider,.7f,.1f),H(humanCollider,.5f,.2f),H(C("Box"),.4f,.3f),H(floor,0,1),H(C("Lower floor"),-.2f,1.2f)};
 ChairFloorContact hit;A(ChairFloorProbe.Try(new Vector3(0,.8f,0),seat,human,0,out hit),"floor missing");A(hit.Name=="Frame floor"&&Near(hit.Point.y,0),"nearest raw hit mistaken for floor");A(hit.Chairs==1&&hit.Humans==1,"rejected-object diagnostics");A(Physics.LastQuery==QueryTriggerInteraction.Ignore,"trigger query");
 Physics.Hits=new[]{H(otherCollider,.1f,.1f),H(floor,0,1)};A(ChairFloorProbe.Try(new Vector3(),seat,human,0,out hit)&&hit.Name=="Frame floor","other chair accepted");
 Physics.Hits=new[]{H(seatCollider,.7f,.1f),H(humanCollider,.5f,.2f)};A(!ChairFloorProbe.Try(new Vector3(),seat,human,0,out hit),"invented floor fallback");
 Physics.Hits=new[]{H(floor,0,1,.4f)};A(!ChairFloorProbe.Try(new Vector3(),seat,human,0,out hit),"steep surface accepted");
 Physics.Hits=new[]{H(floor,.4f,.5f)};A(!ChairFloorProbe.Try(new Vector3(),seat,human,0,out hit),"raised plane accepted");
 Physics.Hits=new[]{H(floor,0,1)};var snap=new ChairTransition.Snapshot{Seat=seat,Human=human,LeftFootPosition=new Vector3(0,.12f,0),RightFootPosition=new Vector3(0,.12f,0)};var pose=new ChairStandingPose();A(ChairFloorProbe.Calibrate(snap,pose),"standing calibration");A(Near(pose.Sole[0],.12f)&&Near(pose.FloorRelativeToSeat[0],0),"floor/sole reference");
 foreach(float seatedAnkle in new[]{.12f,.5f,.9f,1.2f}){A(ChairFloorProbe.Try(new Vector3(0,seatedAnkle,0),seat,human,0,out hit),"height-dependent probe");float ankle=ChairFloorPolicy.Ankle(hit.Point.y,pose.Sole[0]);A(Near(ankle,.12f),"seated ankle leaked into support");A(Near(ankle+.82f,.94f),"standing pelvis plane");}
 snap.LeftFootPosition=new Vector3(0,.8f,0);A(!ChairFloorProbe.Calibrate(snap,new ChairStandingPose()),"invalid standing clearance accepted");
 A(!ChairFloorPolicy.Accept(1,float.NaN,0,false,false),"nonfinite hit");A(!ChairFloorPolicy.Accept(1,0,float.PositiveInfinity,false,false),"invalid reference");
 Console.WriteLine(n+" production floor selection/calibration checks passed (synthetic ray hits; not Unity physics).");}}
namespace UnityEngine{
 public struct Vector3{public float x,y,z;public Vector3(float a,float b,float c){x=a;y=b;z=c;}public static Vector3 down=>new Vector3(0,-1,0);}
 public static class Mathf{public static float Max(float a,float b)=>Math.Max(a,b);public static float Clamp(float x,float a,float b)=>Math.Max(a,Math.Min(b,x));}
 public class Transform{public Transform parent;public object Owner;public Vector3 position;public bool IsChildOf(Transform root){for(var t=this;t!=null;t=t.parent)if(t==root)return true;return false;}}
 public class Collider{public Transform transform;public string name;public T GetComponentInParent<T>() where T:class{for(var t=transform;t!=null;t=t.parent)if(t.Owner is T)return (T)t.Owner;return null;}}
 public struct RaycastHit{public Vector3 point,normal;public float distance;public Collider collider;}public enum QueryTriggerInteraction{Ignore}
 public static class Physics{public static RaycastHit[] Hits;public static QueryTriggerInteraction LastQuery;public static RaycastHit[] RaycastAll(Vector3 o,Vector3 d,float l,int m,QueryTriggerInteraction q){LastQuery=q;return Hits;}}
}
namespace Assets.Scripts.Objects.Entities{public class Human{public int AllButPlayerImmune=-1;}}
namespace Assets.Scripts.Objects.Structures{public class Seat{public Transform ThingTransform;public Seat(){ThingTransform=new Transform{Owner=this};}}}
namespace StationEmotes{internal static class Plugin{internal static LogStub Log=new LogStub();}internal class LogStub{public void LogWarning(string s){}}internal class ChairStandingPose{internal float[] Sole=new float[2],FloorRelativeToSeat=new float[2];}internal class ChairTransition{internal class Snapshot{internal Vector3 LeftFootPosition,RightFootPosition;internal Seat Seat;internal Human Human;}}}
