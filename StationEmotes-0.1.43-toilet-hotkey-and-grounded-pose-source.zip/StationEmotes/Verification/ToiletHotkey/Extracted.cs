using System;using UnityEngine;using Assets.Scripts;using Assets.Scripts.GridSystem;using Assets.Scripts.Inventory;using Assets.Scripts.Networking;using Assets.Scripts.Objects;using Assets.Scripts.Objects.Entities;using Assets.Scripts.UI;using Objects.Structures;namespace StationEmotes{
 internal static class ToiletUseHud
 {
  private static Human owner;private static StructureToilet toilet;private static Interactable control;
  private static bool visible,available,pending;private static float started,duration,messageUntil;private static string message="";
  internal static void Clear(){owner=null;toilet=null;control=null;visible=available=pending=false;message="";}
  private static bool InputAllowed()=>Application.isFocused&&!WorldManager.IsGamePaused&&InventoryManager.AllowMouseControl&&!Cursor.visible&&!InputWindowBase.IsInputWindow&&!ConsoleWindow.IsOpen&&!InputControlBase.IsRecording&&!ImGuiLoadingScreen.IsShowing&&!EmoteWheel.Open;
  private static bool Context(Human human,out StructureToilet target)
  {
   target=human?.ParentSlot?.Parent as StructureToilet;if(target==null||human.State!=EntityState.Alive||human.ParentSlot!=ToiletSeating.Slot(target))return false;
   var state=target.GetComponent<ToiletOccupancy>();
   return state!=null&&state.Occupant==human&&ToiletUsePolicy.Ready(true,human.GetComponent<ChairTransition>()?.Active==true,Time.time,state.ReadyAt);
  }
  private static Thing.DelayedActionInstance Preview(Human human,StructureToilet target,Interactable action,out Interaction interaction)
  {
   interaction=new Interaction(human,InventoryManager.ActiveHandSlot,target,false);
   if(InventoryManager.ActiveHandSlot==null)return null;
   if(target.PreventInteraction(out var failure,action,interaction))return failure;
   return target.InteractWith(action,interaction,false);
  }
  private static string Plain(string text)
  {
   if(string.IsNullOrWhiteSpace(text))return "";
   var result=new System.Text.StringBuilder();bool tag=false;
   foreach(char c in text){if(c=='<'){tag=true;continue;}if(c=='>'){tag=false;continue;}if(!tag)result.Append(c=='\n'||c=='\r'?' ':c);}
   var value=result.ToString().Trim();return value.Length>120?value.Substring(0,117)+"...":value;
  }
  private static void Explain(Thing.DelayedActionInstance preview)
  {
   message=Plain((preview?.ExtendedMessage??"")+" "+(preview?.GetStateMessage()??""));
   if(message.Length==0)message="The toilet cannot be used right now.";
   messageUntil=Time.time+4;
  }
  internal static void Tick(Human human)
  {
   if(GameManager.IsBatchMode||GameManager.GameState!=GameState.Running||!InputAllowed()||!Context(human,out var target)){Clear();return;}
   if(owner!=human||toilet!=target){Clear();owner=human;toilet=target;}
   control=target.Interactables.Find(c=>c.Action==InteractableType.Activate);
   if(control==null){Clear();return;}
   visible=true;
   var preview=Preview(human,target,control,out var interaction);available=preview!=null&&!preview.IsDisabled;
   if(!available){pending=false;if(Input.GetKeyDown(KeyCode.K))Explain(preview);return;}
   if(pending)
   {
    if(Time.time-started<duration)return;
    pending=false;
    // Both local and authoritative handlers revalidate suit/water/sanitation/seat state at completion.
    if(GameManager.RunSimulation)OnServer.InteractWith(control,interaction);
    else NetworkClient.InteractWith(control,interaction);
    return;
   }
   if(Input.GetKeyDown(KeyCode.K))
   {
    duration=Mathf.Clamp(preview.Duration,0,5);started=Time.time;pending=true;
   }
  }

}}