using System;using System.Collections.Generic;using System.Reflection;using StationEmotes;using UnityEngine;using Assets.Scripts;using Assets.Scripts.GridSystem;using Assets.Scripts.Inventory;using Assets.Scripts.Objects;using Assets.Scripts.Objects.Entities;using Assets.Scripts.UI;using Objects.Structures;
class Check{
 static int n;static void A(bool b,string m){n++;if(!b)throw new Exception(m);}
 static void Tick(Human h,float time,bool key=false){Time.time=time;Input.Down=key;ToiletUseHud.Tick(h);}
 static Human Setup(bool client=false){
 ToiletUseHud.Clear();GameManager.RunSimulation=!client;Application.isFocused=true;WorldManager.IsGamePaused=false;InventoryManager.AllowMouseControl=true;Cursor.visible=false;InputWindowBase.IsInputWindow=false;ConsoleWindow.IsOpen=false;InputControlBase.IsRecording=false;EmoteWheel.Open=false;
 OnServer.Calls=NetworkClient.Calls=0;InventoryManager.ActiveHandSlot=new Slot();
 var t=new StructureToilet();var h=new Human{State=EntityState.Alive};var slot=new Slot{Parent=t};t.Seat=slot;h.ParentSlot=slot;t.Context=new ToiletOccupancy{Occupant=h,ReadyAt=2};t.Interactables.Add(new Interactable{Action=InteractableType.Activate,Parent=t});return h;
 }
 static void Main(){
 var h=Setup();h.Transition.Active=true;Tick(h,2,true);Tick(h,4);A(OnServer.Calls==0,"use during active sitting transition");
 h=Setup();Tick(h,1,true);Tick(h,3);A(OnServer.Calls==0,"use before seated readiness");
 h=Setup();Tick(h,2,true);A(OnServer.Calls==0,"native delay skipped");Tick(h,2.4f,true);A(OnServer.Calls==0,"repeated K dispatched pending use");Tick(h,3);A(OnServer.Calls==1&&NetworkClient.Calls==0,"host native action not dispatched exactly once");Tick(h,3.1f);A(OnServer.Calls==1,"action repeated without new key press");
 h=Setup();var t=(StructureToilet)h.ParentSlot.Parent;t.Suit=true;Tick(h,2,true);Tick(h,4);A(OnServer.Calls==0,"suit condition bypassed");
 h=Setup();t=(StructureToilet)h.ParentSlot.Parent;t.Water=false;Tick(h,2,true);Tick(h,4);A(OnServer.Calls==0,"water condition bypassed");
 h=Setup();t=(StructureToilet)h.ParentSlot.Parent;t.Need=false;Tick(h,2,true);Tick(h,4);A(OnServer.Calls==0,"sanitation need bypassed");
 h=Setup();Tick(h,2,true);t=(StructureToilet)h.ParentSlot.Parent;t.Suit=true;Tick(h,2.5f);t.Suit=false;Tick(h,4);A(OnServer.Calls==0,"condition change did not cancel pending use");
 h=Setup();Tick(h,2,true);h.ParentSlot=null;Tick(h,4);A(OnServer.Calls==0,"use after leaving toilet");
 h=Setup();Tick(h,2,true);InputWindowBase.IsInputWindow=true;Tick(h,2.5f);InputWindowBase.IsInputWindow=false;Tick(h,4);A(OnServer.Calls==0,"input window did not cancel pending action");
 h=Setup();Tick(h,2,true);Application.isFocused=false;Tick(h,4);A(OnServer.Calls==0,"unfocused action");
 h=Setup();Tick(h,2,true);WorldManager.IsGamePaused=true;Tick(h,4);A(OnServer.Calls==0,"paused action");
 h=Setup();Tick(h,2,true);h.State=EntityState.Dead;Tick(h,4);A(OnServer.Calls==0,"dead actor action");
 h=Setup(true);Tick(h,2,true);Tick(h,3);A(NetworkClient.Calls==1&&OnServer.Calls==0,"client bypassed native network interaction");
 h=Setup();InventoryManager.ActiveHandSlot=null;Tick(h,2,true);Tick(h,4);A(OnServer.Calls==0,"null source slot network request");
 h=Setup();t=(StructureToilet)h.ParentSlot.Parent;t.Blocked=true;Tick(h,2,true);Tick(h,4);A(OnServer.Calls==0,"native PreventInteraction bypassed");
 Console.WriteLine(n+" production K-action delay/validation/cancellation/native-dispatch checks passed (game/input stubs).");
 }}
namespace UnityEngine{public static class Time{public static float time;}public static class Application{public static bool isFocused=true;}public static class Cursor{public static bool visible;}public enum KeyCode{K}public static class Input{public static bool Down;public static bool GetKeyDown(KeyCode k)=>Down;}public static class Mathf{public static float Clamp(float x,float a,float b)=>Math.Max(a,Math.Min(b,x));}}
namespace Assets.Scripts.GridSystem{public enum GameState{Running}}
namespace Assets.Scripts{public static class GameManager{public static bool IsBatchMode,RunSimulation;public static GameState GameState=GameState.Running;}public static class WorldManager{public static bool IsGamePaused;}public static class NetworkClient{public static int Calls;public static void InteractWith(Interactable a,Interaction i){Calls++;}}}
namespace Assets.Scripts.Networking{}
namespace Assets.Scripts.Inventory{public static class InventoryManager{public static bool AllowMouseControl=true;public static Slot ActiveHandSlot;}}
namespace Assets.Scripts.UI{public static class InputWindowBase{public static bool IsInputWindow;}public static class ConsoleWindow{public static bool IsOpen;}public static class InputControlBase{public static bool IsRecording;}public static class ImGuiLoadingScreen{public static bool IsShowing;}}
namespace Assets.Scripts.Objects{
 public enum InteractableType{Activate}public class Thing{public class DelayedActionInstance{public bool IsDisabled;public float Duration=1;public string ExtendedMessage="";public string GetStateMessage()=>"<color=red>Native condition failed</color>";}}
 public class Slot{public Thing Parent;}public class Interactable{public InteractableType Action;public Thing Parent;}
 public struct Interaction{public Thing SourceThing,DestinationThing;public Slot SourceSlot;public bool AltKey;public Interaction(Thing h,Slot s,Thing t,bool a){SourceThing=h;SourceSlot=s;DestinationThing=t;AltKey=a;}}
}
namespace Assets.Scripts.Objects.Entities{public enum EntityState{Alive,Dead}public class Human:Thing{public Slot ParentSlot;public EntityState State;public ChairTransition Transition=new ChairTransition();public T GetComponent<T>()where T:class=>Transition as T;}}
namespace Objects.Structures{public class StructureToilet:Thing{
 public Slot Seat;public ToiletOccupancy Context;public bool Suit,Water=true,Need=true,Blocked;public List<Interactable> Interactables=new List<Interactable>();
 public T GetComponent<T>()where T:class=>Context as T;
 public bool PreventInteraction(out DelayedActionInstance fail,Interactable a,Interaction i){fail=new DelayedActionInstance{IsDisabled=true};return Blocked;}
 public DelayedActionInstance InteractWith(Interactable a,Interaction i,bool action){if(action)throw new Exception("Preview executed action");return new DelayedActionInstance{IsDisabled=Suit||!Water||!Need};}
}}
namespace StationEmotes{public class ChairTransition{public bool Active;}public class ToiletOccupancy{public Human Occupant;public float ReadyAt;}internal static class ToiletSeating{internal static Slot Slot(StructureToilet t)=>t.Seat;}internal static class EmoteWheel{internal static bool Open;}}
public static class OnServer{public static int Calls;public static void InteractWith(Interactable a,Interaction i){Calls++;}}
