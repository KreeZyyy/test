using System;using StationEmotes;using UnityEngine;
class Check{
 static int n;static void A(bool b,string s){n++;if(!b)throw new Exception(s);}
 static bool Same(Quaternion a,Quaternion b)=>(a*Vector3.forward-b*Vector3.forward).magnitude<.0001f&&(a*Vector3.up-b*Vector3.up).magnitude<.0001f;
 static void Main(){
 foreach(float yaw in new[]{0f,45f,90f,180f,270f})foreach(float bind in new[]{0f,73f,180f}){
 var facing=Quaternion.Yaw(yaw);var calibration=Quaternion.Yaw(bind)*Quaternion.Pitch(-12);
 var contact=ChairFootContact.GroundRotation(facing,calibration);var badNative=Quaternion.Yaw(yaw+180)*Quaternion.Pitch(65);
 foreach(float p in new[]{0f,.25f,.5f,.9f,1f}){
 A(Same(ChairFootContact.Rotation(false,contact,badNative,p,p),contact),"exit final yaw turned toward raw endpoint");
 foreach(float clearance in new[]{-.01f,0f,.004f,.008f})
  A(Same(ChairFootContact.Rotation(true,contact,badNative,p,clearance),contact),"grounded sitting foot adopted toe-up pose");
 }
 A(Same(ChairFootContact.Rotation(true,contact,badNative,1,.06f),badNative),"lifted seated foot never released");
 var root=new Vector3(10,128,20);var left=new Vector3(-.115f,.071f,-.05f);var right=new Vector3(.115f,.071f,-.05f);
 var l=ChairFootContact.StandingFoot(root,facing,left);var r=ChairFootContact.StandingFoot(root,facing,right);
 A(Vector3.Dot(r-l,facing*Vector3.right)>.229f,"outward stance reversed left/right contacts");
 A(Math.Abs(l.y-128.071f)<.0001f&&Math.Abs(r.y-128.071f)<.0001f,"canonical stance changed sole height");
 }
 foreach(float ahead in new[]{.15f,.25f,.4f,.65f,1.2f})A(ChairApproachPolicy.Seat(0,ahead,0),"standing close in front of native slot rejected");
 A(!ChairApproachPolicy.Seat(0,-.2f,0),"entry behind chair accepted");
 A(!ChairApproachPolicy.Seat(1f,.5f,0),"wrong neighboring seat accepted");
 A(!ChairApproachPolicy.Seat(0,2,0),"out-of-reach chair accepted");
 foreach(float distance in new[]{.2f,.35f,.5f,.75f,1.2f,1.4f})A(ChairApproachPolicy.Toilet(distance*distance,0),"nearby visible bowl rejected");
 A(!ChairApproachPolicy.Toilet(4,0),"far toilet accepted");A(!ChairApproachPolicy.Toilet(.25f,2),"toilet on wrong floor accepted");
 foreach(float value in new[]{float.NaN,float.PositiveInfinity,float.NegativeInfinity}){
 A(!ChairApproachPolicy.Seat(value,.5f,0),"invalid seat side");
 A(!ChairApproachPolicy.Seat(0,value,0),"invalid seat ahead");
 A(!ChairApproachPolicy.Toilet(value,0),"invalid toilet distance");
 A(!ChairApproachPolicy.Toilet(.25f,value),"invalid toilet floor");}
 A(ChairFootContact.LegWeight(1)==0&&ChairFootContact.RotationWeight(true,1)==0,"entry final native handover blocked");
 A(ChairFootContact.LegWeight(0)==1&&ChairFootContact.RotationWeight(true,0)==1,"entry contact released before final handover");
 foreach(float phase in new[]{0f,.25f,.5f,.9f,1f})A(ChairFootContact.RotationWeight(false,phase)==1,"exit foot orientation faded during release");
 var plan=new ChairPlan(true,.3f,180);
 foreach(float offset in new[]{0f,.1f,.24f,.28f,.4f,.52f}){float t=plan.RestStart+offset;A(ChairFootContact.LegWeight(plan.EndRelease(t))>.999f,"leg IK faded while seated foot was still moving to rest");}
 Console.WriteLine(n+" production planted-foot, final-yaw and close-approach checks passed (math stubs).");
 }}
namespace UnityEngine{public static class Mathf{public static float Clamp(float a,float min,float max)=>Math.Max(min,Math.Min(max,a));}}
