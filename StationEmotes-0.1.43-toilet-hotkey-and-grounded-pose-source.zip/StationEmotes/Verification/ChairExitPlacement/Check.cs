using System;using StationEmotes;using UnityEngine;
class Check{
 static int n;static void A(bool b,string m){n++;if(!b)throw new Exception(m);}static bool Near(float a,float b)=>Math.Abs(a-b)<.0001f;
 static void Main(){
 // User's logged left-leg geometry, translated locally: u=.220, l=.181, original target span=.471.
 var hip=new Vector3(0,.352f,0);var knee=new Vector3(0,.300f,.21377f);var ankle=new Vector3(0,.148f,.31205f);Vector3 target;
 float reach=(knee-hip).magnitude+(ankle-knee).magnitude;
 A((new Vector3(ankle.x,0,ankle.z)-hip).magnitude>reach+.06f,"fixture must reproduce logged unreachable floor contact");
 A(ChairExitPlacement.TryTarget(hip,knee,ankle,0,out target),"tuck target rejected");A((target-hip).magnitude<reach-.007f,"tucked target must have reach reserve");A(target.z<ankle.z-.1f,"feet must retract before lowering");
 for(int i=0;i<=104;i++){float t=i*.005f;var p=ChairExitPlacement.Sample(ankle,target,t);A((p-hip).magnitude<=reach+.0001f,"unreachable preparation sample");if(t<=.28f)A(Near(p.y,ankle.y),"foot lowered before retraction");else A(Near(p.x,target.x)&&Near(p.z,target.z),"horizontal target changed while planting");}
 A(Near(ChairExitPlacement.Sample(ankle,target,0).z,ankle.z),"source endpoint");A(Near(ChairExitPlacement.Sample(ankle,target,.52f).y,0),"floor endpoint");A(!ChairExitPlacement.TryTarget(hip,knee,ankle,-1,out target),"invented impossible floor target");
 // The later logged 4mm overextension can be removed with a shallow support dip.
 var standingJoint=new Vector3(0,.371f,0);var farFoot=new Vector3(.164f,0,0);float drop=ChairExitPlacement.RequiredDrop(standingJoint,farFoot,.402f);A(drop>0&&drop<.015f,"near-limit support dip");standingJoint.y-=drop;A((standingJoint-farFoot).magnitude<.402f,"support dip did not restore reach");
 var plan=new ChairPlan(false,.52f,0);A(plan.WalkSteps>=4,"exit stride too long");A(plan.Preparation(.52f)==0&&plan.Body(.52f)==0,"body moved before feet were planted");A(plan.Preparation(.76f)==1&&plan.Body(.76f)==0,"rise before weight transfer");A(plan.Stage(.1f)=="tuck feet"&&plan.Stage(.4f)=="plant feet","phase labels");
 foreach(float distance in new[]{0f,.1f,.3f,.7f})foreach(float angle in new[]{0f,45f,180f}){var old=new BaselineChairPlan(true,distance,angle);var current=new ChairPlan(true,distance,angle);A(old.WalkSteps==current.WalkSteps&&old.TurnSteps==current.TurnSteps,"entry changed");}
 A(!ChairExitPlacement.TryTarget(hip,knee,ankle,float.NaN,out target),"invalid floor accepted");
 // Rounded left/right spans from the posted log, with a reconstructed knee plane.
 foreach(float horizontal in new[]{.313f,.328f}){
 var a=new Vector3(0,.352f,0);var foot=new Vector3(0,.15f,horizontal);var direction=(foot-a).normalized;float span=(foot-a).magnitude;
 float axial=(.220f*.220f-.181f*.181f+span*span)/(2*span);float lateral=(float)Math.Sqrt(.220f*.220f-axial*axial);
 var b=new Vector3(0,a.y+direction.y*axial+direction.z*lateral,direction.z*axial-direction.y*lateral);
 A(ChairExitPlacement.TryTarget(a,b,foot,0,out target),"logged leg target rejected");
 for(int i=0;i<=52;i++){var sample=ChairExitPlacement.Sample(foot,target,i*.01f);A((sample-a).magnitude<=.4011f,"logged leg still overextended");}}
 for(int i=0;i<=104;i++){float t=i*.005f;var a=ChairExitPlacement.Sample(ankle,new Vector3(0,0,.1f),t);var b=ChairExitPlacement.ReverseSample(ankle,new Vector3(0,0,.1f),.52f-t);A((a-b).magnitude<.0001f,"reverse placement symmetry");}
 var entry=new ChairPlan(true,.4f,90);A(entry.StepCount==entry.WalkSteps+entry.TurnSteps+2,"entry placement pair");A(Near(entry.RestStart,entry.BodyStart+ChairPlan.BodyDuration),"rest after sitting");A(entry.Rest(entry.RestStart)==0&&entry.Rest(entry.RestStart+.52f)==1,"rest endpoints");
 A(ChairExitPlacement.PlantRotation(0)==0&&ChairExitPlacement.PlantRotation(.28f)==0,"retain seated angle until tucked");
 A(ChairExitPlacement.PlantRotation(.52f)==1&&ChairExitPlacement.PlantRotation(.76f)==1,"flat before transfer and rise");
 float previous=0;for(int i=0;i<=104;i++){float value=ChairExitPlacement.PlantRotation(i*.005f);A(value>=previous&&value>=0&&value<=1,"monotonic planted rotation");previous=value;}
 A(System.Math.Abs(ChairExitPlacement.PlantRotation(.4f)-.5f)<.0001f,"smooth halfway rotation");
 Console.WriteLine(n+" production exit-placement checks passed, including logged geometry (math stubs).");}}
namespace UnityEngine{
 public struct Vector3{public float x,y,z;public Vector3(float a,float b,float c){x=a;y=b;z=c;}public float magnitude=>(float)Math.Sqrt(x*x+y*y+z*z);public Vector3 normalized=>this*(1/magnitude);public static Vector3 operator -(Vector3 a,Vector3 b)=>new Vector3(a.x-b.x,a.y-b.y,a.z-b.z);public static Vector3 operator *(Vector3 a,float b)=>new Vector3(a.x*b,a.y*b,a.z*b);public static Vector3 Lerp(Vector3 a,Vector3 b,float t)=>new Vector3(a.x+(b.x-a.x)*t,a.y+(b.y-a.y)*t,a.z+(b.z-a.z)*t);}
 public static class Mathf{public static float Clamp(float x,float a,float b)=>Math.Max(a,Math.Min(b,x));public static float Abs(float x)=>Math.Abs(x);public static float Max(float a,float b)=>Math.Max(a,b);public static float Sqrt(float x)=>(float)Math.Sqrt(x);}
}
