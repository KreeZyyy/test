using UnityEngine;
namespace StationEmotes
{
 // Bone forward axes are rig-specific. Shoulder right crossed with torso up gives anatomical forward.
 internal static class ChairBodyFacing
 {
  internal static Vector3 Forward(Vector3 shoulderRight,Vector3 torsoUp)
   =>Vector3.ProjectOnPlane(Vector3.Cross(shoulderRight,torsoUp),Vector3.up);
  internal static Quaternion Align(Quaternion pelvis,Vector3 shoulderRight,Vector3 torsoUp,Vector3 outward)
  {
   var actual=Forward(shoulderRight,torsoUp);
   var wanted=Vector3.ProjectOnPlane(outward,Vector3.up);
   if(actual.sqrMagnitude<.000001f||wanted.sqrMagnitude<.000001f)return pelvis;
   return Quaternion.FromToRotation(actual.normalized,wanted.normalized)*pelvis;
  }
 }
}
