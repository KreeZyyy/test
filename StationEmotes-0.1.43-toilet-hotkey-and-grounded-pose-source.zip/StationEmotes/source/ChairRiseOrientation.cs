using UnityEngine;
namespace StationEmotes
{
 internal static class ChairRiseOrientation
 {
  internal static Quaternion Align(Quaternion pelvis,Vector3 actual,Vector3 desired,float weight)
  {
   if(weight<=0||actual.sqrMagnitude<.000001f||desired.sqrMagnitude<.000001f)return pelvis;
   var correction=Quaternion.FromToRotation(actual.normalized,desired.normalized);
   return Quaternion.Slerp(Quaternion.identity,correction,weight)*pelvis;
  }
 }
}
