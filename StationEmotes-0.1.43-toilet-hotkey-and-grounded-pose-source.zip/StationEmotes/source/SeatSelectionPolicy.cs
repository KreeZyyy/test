using UnityEngine;
namespace StationEmotes
{
 internal static class SeatSelectionPolicy
 {
  internal static int Nearest(Vector3 hit,Vector3[] positions)
  {
   int choice=-1;float best=float.PositiveInfinity;
   for(int i=0;i<positions.Length;i++)
   {
    var delta=positions[i]-hit;delta.y=0;float distance=delta.sqrMagnitude;
    if(float.IsNaN(distance)||float.IsInfinity(distance)||distance>=best)continue;
    best=distance;choice=i;
   }
   return choice;
  }
 }
}
