using System;
namespace StationEmotes
{
 internal static class ChairApproachPolicy
 {
  private static bool Finite(float value)=>!float.IsNaN(value)&&!float.IsInfinity(value);
  internal static bool Seat(float side,float ahead,float height)
   =>Finite(side)&&Finite(ahead)&&Finite(height)&&Math.Abs(side)<=.75f&&ahead>=.10f&&ahead<=1.45f&&Math.Abs(height)<=.85f;
  // A visible bowl click within reach does not depend on the model's forward-axis convention.
  internal static bool Toilet(float distanceSquared,float height)
   =>Finite(distanceSquared)&&Finite(height)&&distanceSquared>=.01f&&distanceSquared<=2.1025f&&Math.Abs(height)<=.85f;
 }
}
