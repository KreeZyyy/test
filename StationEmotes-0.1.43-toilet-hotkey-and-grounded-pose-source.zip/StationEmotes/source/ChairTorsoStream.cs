using UnityEngine;
using UnityEngine.Animations;
namespace StationEmotes
{
 internal struct ChairTorsoSlot
 {
  public TransformStreamHandle Handle;public Quaternion NativeRotation;public bool Ready;
 }
 internal struct ChairTorsoStream
 {
  public int Count;public ChairTorsoSlot A,B,C,D,E,F,G,H;
  public ChairTorsoSlot Get(int i){switch(i){case 0:return A;case 1:return B;case 2:return C;case 3:return D;case 4:return E;case 5:return F;case 6:return G;default:return H;}}
  public void Set(int i,ChairTorsoSlot value){switch(i){case 0:A=value;break;case 1:B=value;break;case 2:C=value;break;case 3:D=value;break;case 4:E=value;break;case 5:F=value;break;case 6:G=value;break;default:H=value;break;}}
  public void Capture(AnimationStream stream)
  {
   for(int i=0;i<Count;i++)
   {
    var value=Get(i);value.Ready=value.Handle.IsValid(stream);
    if(value.Ready){value.Handle.Resolve(stream);value.NativeRotation=value.Handle.GetLocalRotation(stream);}
    Set(i,value);
   }
  }
 }
}
