using System;
using UnityEngine;
namespace StationEmotes
{
 internal static class ChairToeContact
 {
  internal static Transform Find(Animator animator,Transform foot,bool left)
  {
   var mapped=animator.GetBoneTransform(left?HumanBodyBones.LeftToes:HumanBodyBones.RightToes);
   if(mapped!=null&&mapped!=foot&&mapped.IsChildOf(foot))return mapped;
   if(foot==null)return null;
   Transform best=null;int bestDepth=int.MaxValue;
   foreach(var child in foot.GetComponentsInChildren<Transform>(true))
   {
    if(child==foot||child.name.IndexOf("toe",StringComparison.OrdinalIgnoreCase)<0||child.GetComponent<Renderer>()!=null)continue;
    int depth=0;for(var parent=child;parent!=null&&parent!=foot;parent=parent.parent)depth++;
    if(depth<bestDepth){bestDepth=depth;best=child;}
   }
   return best;
  }
  internal static Quaternion Rotation(bool entering,Quaternion source,Quaternion standing,Quaternion native,float rest,float clearance,float elapsed)
   =>entering?Quaternion.Slerp(standing,native,ChairFootContact.SeatedRotationRelease(rest,clearance)):
               Quaternion.Slerp(source,standing,ChairExitPlacement.PlantRotation(elapsed));
 }
}
