using System;
using System.Globalization;
using System.Text;
using Assets.Scripts;
using Assets.Scripts.Inventory;
using UnityEngine;
namespace StationEmotes
{
 internal static class ChairRigDiagnostics
 {
  private static string F(float value)=>value.ToString("F3",CultureInfo.InvariantCulture);
  private static string V(Vector3 value)=>"("+F(value.x)+","+F(value.y)+","+F(value.z)+")";
  private static bool Has(Animator a,int hash,AnimatorControllerParameterType type)
  {foreach(var p in a.parameters)if(p.nameHash==hash&&p.type==type)return true;return false;}
  internal static void Calibration(ChairTransition.Snapshot s,ChairStandingPose reference)
  {
   if(s.Human!=InventoryManager.ParentHuman)return;
   try
   {
    var a=s.Animator;var clips=new StringBuilder();
    for(int layer=0;layer<a.layerCount;layer++)
    {
     if(layer>0)clips.Append("; ");clips.Append("layer").Append(layer).Append(a.IsInTransition(layer)?" transitioning:":":");
     foreach(var clip in a.GetCurrentAnimatorClipInfo(layer))if(clip.clip!=null&&clip.weight>.01f)clips.Append(clip.clip.name).Append('@').Append(F(clip.weight)).Append(' ');
    }
    string mode=Has(a,MovementController.ControlModeHash,AnimatorControllerParameterType.Int)?a.GetInteger(MovementController.ControlModeHash).ToString():"n/a";
    string casting=Has(a,MovementController.CastingHash,AnimatorControllerParameterType.Bool)?a.GetBool(MovementController.CastingHash).ToString():"n/a";
    string ground=Has(a,MovementController.GroundedHash,AnimatorControllerParameterType.Bool)?a.GetBool(MovementController.GroundedHash).ToString():"n/a";
    Plugin.Log.LogInfo("Chair calibration pose: pelvis="+V(s.HipPosition)+", anklesMid="+V((s.LeftFootPosition+s.RightFootPosition)*.5f)+", hipOffsetLocal="+V(reference.HipAboveFeet)+", avatarScale="+F(a.humanScale)+", modelScale="+V(a.transform.lossyScale)+", mode="+mode+", grounded="+ground+", casting="+casting+", clips="+clips);
    for(int side=0;side<2;side++)
    {
     int i=side==0?10:13;var upper=s.Bones[i].position;var knee=s.Bones[i+1].position;var ankle=s.Bones[i+2].position;
     var metrics=ChairLegMetrics.Measure(upper,knee,ankle,ankle,0);
     Plugin.Log.LogInfo("Chair calibration leg "+(side==0?"L":"R")+": "+Describe(metrics)+", upperJoint="+V(upper)+", knee="+V(knee)+", ankle="+V(ankle));
    }
   }
   catch(Exception e){Plugin.Log.LogWarning("Chair calibration diagnostic unavailable: "+e.Message);}
  }
  private static string Describe(ChairLegMetrics m)=>"upper="+F(m.Upper)+", lower="+F(m.Lower)+", minReach="+F(m.Minimum)+", maxReach="+F(m.Maximum)+", actualSpan="+F(m.ActualSpan)+", reachRatio="+F(m.ReachRatio)+", kneeFlexDeg="+F(m.KneeFlex)+", targetSpan="+F(m.TargetSpan)+", horizontal="+F(m.Horizontal)+", vertical="+F(m.Vertical)+", excess="+F(m.Excess);
  internal static void Leg(ChairTransition.Snapshot s,string phase,int side,float elapsed,ChairLegMetrics metrics,float error,float fullError,float weight,bool warning)
  {
   if(s.Human!=InventoryManager.ParentHuman)return;
   var message="Chair leg "+(warning?"reach ":"sample ")+(side==0?"L":"R")+": stage="+phase+", t="+F(elapsed)+", status="+metrics.Status+", "+Describe(metrics)+", upperJoint="+V(metrics.UpperPosition)+", target="+V(metrics.TargetPosition)+", solverError="+F(fullError)+", outputError="+F(error)+", IK="+F(weight);
   if(warning)Plugin.Log.LogWarning(message);else Plugin.Log.LogInfo(message);
  }
 }
}
