using System;
using Assets.Scripts;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Inventory;
using Assets.Scripts.Objects.Entities;
using Assets.Scripts.UI;
using Assets.Scripts.Util;
using HarmonyLib;
using ImGuiNET;
using UnityEngine;
using UnityEngine.Rendering;
namespace StationEmotes
{
    internal static class EmoteWheel
    {
        internal static bool Open {get;private set;}
        [ThreadStatic] internal static bool ReadingMouse;
        private static Human owner;
        private static Vector2 pointer;
        private static readonly string[] Labels={"Wave","Salute","Sit","Hands up","Point","Robot dance","Meme dance","Agree","Disagree","Facepalm"};
        internal static void Close(){Open=false;owner=null;pointer=Vector2.zero;}
        private static bool CanUse()=>Application.isFocused&&!WorldManager.IsGamePaused&&InventoryManager.AllowMouseControl&&!Cursor.visible&&!InputWindowBase.IsInputWindow&&!ConsoleWindow.IsOpen&&!ImGuiLoadingScreen.IsShowing;
        internal static void Tick(Human human)
        {
            if(!CanUse()){Close();return;}
            if(!Open&&Input.GetKeyDown(KeyCode.F10)){Open=true;owner=human;pointer=Vector2.zero;return;}
            if(!Open)return;
            if(owner!=human||Input.GetKeyDown(KeyCode.Escape)){Close();return;}
            if(!Input.GetKey(KeyCode.F10))
            {
                int selected=EmoteWheelPolicy.Select(pointer.x,pointer.y);Close();
                Plugin.TriggerSelection(human,selected);return;
            }
            // Read the game's existing mouse axes while the OS pointer stays locked.
            var input=Singleton<InputManager>.Instance;
            ReadingMouse=true;
            try{pointer+=new Vector2(input.GetAxis("LookX"),-input.GetAxis("LookY"))*24f;}
            finally{ReadingMouse=false;}
            pointer=Vector2.ClampMagnitude(pointer,225f);
        }
        private static uint Color(float r,float g,float b,float a=1f)=>ImGui.GetColorU32(new Vector4(r,g,b,a));
        private static void Text(ImDrawListPtr draw,Vector2 p,string text,uint color)
        {draw.AddText(p-ImGui.CalcTextSize(text)*.5f,color,text);}
        private static Vector2 Direction(float angle)=>new Vector2(Mathf.Cos(angle*Mathf.Deg2Rad),Mathf.Sin(angle*Mathf.Deg2Rad));
        private static void Sector(ImDrawListPtr d,Vector2 c,float outer,float from,float to,uint color)
        {
            // One convex fan, opaque fill: no antialiased triangle seams.
            d.PathClear();d.PathLineTo(c);
            for(int k=0;k<=24;k++)d.PathLineTo(c+Direction(from+(to-from)*k/24f)*outer);
            d.PathFillConvex(color);
        }
        private static void Capsule(ImDrawListPtr d,Vector2 a,Vector2 b,float width,uint color)
        {
            d.AddLine(a,b,color,width);
            d.AddCircleFilled(a,width*.5f,color,16);d.AddCircleFilled(b,width*.5f,color,16);
        }
        // Filled spacesuit silhouettes with helmet visors; deliberately no text in sectors.
        private static void Icon(ImDrawListPtr d,Vector2 c,int id,uint color)
        {
            Action<float,float,float,float> limb=(x,y,u,v)=>Capsule(d,c+new Vector2(x,y),c+new Vector2(u,v),7f,color);
            uint visor=Color(.035f,.065f,.085f);
            d.AddCircleFilled(c+new Vector2(0,-23),10,color,28);
            d.AddRectFilled(c+new Vector2(-7,-26),c+new Vector2(7,-21),visor,2f);
            d.AddRectFilled(c+new Vector2(-9,-10),c+new Vector2(9,13),color,5f);
            d.AddRectFilled(c+new Vector2(-4,-5),c+new Vector2(4,1),visor,1f);
            if(id==2){limb(-5,13,13,13);limb(13,13,13,30);limb(3,13,21,13);limb(21,13,21,30);Capsule(d,c+new Vector2(-14,21),c+new Vector2(4,21),3,Color(.35f,.56f,.62f));}
            else if(id==6){limb(-5,13,-17,26);limb(5,13,14,19);limb(14,19,5,32);}
            else{limb(-5,13,-10,31);limb(5,13,10,31);}
            if(id==0){limb(-8,-6,-17,8);limb(8,-6,19,-16);limb(19,-16,19,-33);Capsule(d,c+new Vector2(27,-35),c+new Vector2(31,-29),2,color);}
            else if(id==1){limb(-8,-6,-16,10);limb(8,-6,23,-8);limb(23,-8,10,-25);}
            else if(id==9){limb(-8,-6,-16,10);limb(8,-6,21,0);limb(21,0,2,-24);d.AddCircleFilled(c+new Vector2(2,-24),5,color,16);}
            else if(id==3){limb(-8,-6,-21,-17);limb(-21,-17,-21,-33);limb(8,-6,21,-17);limb(21,-17,21,-33);}
            else if(id==4){limb(-8,-6,-17,10);limb(8,-6,29,-6);Capsule(d,c+new Vector2(29,-6),c+new Vector2(36,-6),3,color);}
            else if(id==5){limb(-8,-6,-23,-6);limb(-23,-6,-23,-21);limb(8,-6,23,-6);limb(23,-6,23,10);}
            else if(id==6){limb(-8,-6,-25,-19);limb(8,-6,27,5);Capsule(d,c+new Vector2(-32,-6),c+new Vector2(-35,1),2,color);Capsule(d,c+new Vector2(32,-17),c+new Vector2(35,-10),2,color);}
            else{limb(-8,-6,-17,10);limb(8,-6,17,10);if(id==7){Capsule(d,c+new Vector2(20,-30),c+new Vector2(24,-25),3,color);Capsule(d,c+new Vector2(24,-25),c+new Vector2(33,-36),3,color);}else if(id==8){Capsule(d,c+new Vector2(-26,-25),c+new Vector2(-32,-25),3,color);Capsule(d,c+new Vector2(26,-25),c+new Vector2(32,-25),3,color);}}
        }
        private static void DrawChairHint()
        {
            if(Open||GameManager.IsBatchMode||GameManager.GameState!=GameState.Running||ImGui.GetCurrentContext()==IntPtr.Zero)return;
            var chair=InventoryManager.ParentHuman?.GetComponent<ChairTransition>();if(chair?.Active!=true)return;
            var point=new Vector2(Screen.width*.5f,Screen.height*.78f);
            ImGui.SetNextWindowPos(point-new Vector2(250,28),ImGuiCond.Always);ImGui.SetNextWindowSize(new Vector2(500,64),ImGuiCond.Always);
            bool visible=ImGui.Begin("##ChairInspectionHint",ImGuiWindowFlags.NoDecoration|ImGuiWindowFlags.NoBackground|ImGuiWindowFlags.NoSavedSettings|ImGuiWindowFlags.NoInputs|ImGuiWindowFlags.NoFocusOnAppearing);
            try{if(visible){var d=ImGui.GetWindowDrawList();Text(d,point,chair.Description,Color(1,.8f,.48f));Text(d,point+new Vector2(0,24),"F8 slow    /    F7 pause    /    F11 stop",Color(.86f,.91f,.94f));}}
            finally{ImGui.End();}
        }
        internal static void Draw()
        {
            ToiletUseHud.Draw();
            DrawChairHint();
            if(!Open||GameManager.IsBatchMode||GameManager.GameState!=GameState.Running||ImGui.GetCurrentContext()==IntPtr.Zero)return;
            try
            {
                var center=new Vector2(Screen.width*.5f,Screen.height*.5f);
                ImGui.SetNextWindowPos(center-new Vector2(290,310),ImGuiCond.Always);
                ImGui.SetNextWindowSize(new Vector2(580,620),ImGuiCond.Always);
                bool visible=ImGui.Begin("##StationEmotesWheel",ImGuiWindowFlags.NoDecoration|ImGuiWindowFlags.NoBackground|ImGuiWindowFlags.NoSavedSettings|ImGuiWindowFlags.NoInputs|ImGuiWindowFlags.NoFocusOnAppearing);
                try
                {
                    if(!visible)return;
                    var d=ImGui.GetWindowDrawList();int selected=EmoteWheelPolicy.Select(pointer.x,pointer.y);
                    d.AddCircleFilled(center+new Vector2(0,5),249,Color(0,0,0,.28f),128);
                    d.AddCircleFilled(center,242,Color(.025f,.04f,.055f),128);
                    for(int i=0;i<EmoteWheelPolicy.Count;i++)
                    {
                        float angle=-90f+i*36f;bool hot=i==selected;
                        Sector(d,center,238,angle-17.4f,angle+17.4f,hot?Color(.93f,.49f,.16f):Color(.065f,.09f,.115f));
                        var axis=Direction(angle);
                        uint ink=hot?Color(1,.98f,.91f):Color(.70f,.81f,.86f);
                        Icon(d,center+axis*170f,i,ink);
                        if(hot){d.PathClear();for(int j=0;j<=24;j++)d.PathLineTo(center+Direction(angle-16f+j*32f/24f)*234f);d.PathStroke(Color(1,.75f,.38f),ImDrawFlags.None,3f);}
                    }
                    d.AddCircle(center,241,Color(.19f,.31f,.37f),128,1f);
                    d.AddCircleFilled(center,99,Color(.025f,.04f,.055f),80);
                    d.AddCircle(center,96,selected>=0?Color(.92f,.53f,.22f):Color(.18f,.36f,.42f),80,1.5f);
                    Text(d,center+new Vector2(0,-34),"EMOTES",Color(.40f,.61f,.67f));
                    Text(d,center+new Vector2(0,-1),selected<0?"Choose a gesture":Labels[selected],Color(.98f,.95f,.88f));
                    Text(d,center+new Vector2(0,31),selected<0?"Move mouse":"Release F10",Color(.59f,.71f,.77f));
                    var human=InventoryManager.ParentHuman;
                    bool needsHands=selected>=3&&human!=null&&(human.LeftHandSlot?.Get()!=null||human.RightHandSlot?.Get()!=null);
                    Text(d,center+new Vector2(0,263),needsHands?"Empty BOTH hands for this emote":"Release F10 to play    /    F11 to stop",needsHands?Color(1,.65f,.25f):Color(.85f,.9f,.92f));
                    Text(d,center+new Vector2(0,284),"Center or Esc to close",Color(.62f,.74f,.79f));
                    d.AddCircleFilled(center+pointer,6,Color(0,0,0,.7f),20);
                    d.AddCircleFilled(center+pointer,3,Color(1,.75f,.35f),20);
                }
                finally{ImGui.End();}
            }
            catch(Exception e){Close();Plugin.Log.LogWarning("Emote menu closed: "+e);}
        }
    }
    [HarmonyPatch(typeof(ImGuiManager),"RenderImGuiTo")]
    internal static class EmoteWheelDraw
    {
        [HarmonyPrepare] static bool Prepare()=>!GameManager.IsBatchMode;
        static void Prefix(CommandBuffer cb,CommandBuffer ___commandBuffer)
        {if(ReferenceEquals(cb,___commandBuffer))EmoteWheel.Draw();}
    }
    [HarmonyPatch(typeof(InputManager),"GetAxis",new Type[]{typeof(string)})]
    internal static class EmoteWheelCamera
    {
        [HarmonyPrepare] static bool Prepare()=>!GameManager.IsBatchMode;
        static bool Prefix(string __0,ref float __result)
        {
            if(!EmoteWheel.Open||EmoteWheel.ReadingMouse||(__0!="LookX"&&__0!="LookY"))return true;
            __result=0f;return false;
        }
    }
}
