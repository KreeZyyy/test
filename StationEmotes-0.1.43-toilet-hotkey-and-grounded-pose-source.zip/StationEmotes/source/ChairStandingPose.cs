using System.Runtime.CompilerServices;
using System.Collections.Generic;
using Assets.Scripts.Objects.Entities;
using UnityEngine;
namespace StationEmotes
{
 internal sealed class ChairStandingPose
 {
  private static readonly ConditionalWeakTable<Human,ChairStandingPose> cache=new ConditionalWeakTable<Human,ChairStandingPose>();
  internal Quaternion[] ToeRotations=new Quaternion[2];internal bool[] ToeReady=new bool[2];
  internal Quaternion HipRotation;internal Quaternion[] LocalRotations;
  internal Transform[] Torso;internal Quaternion[] TorsoRotations;
  internal Vector3 HipAboveFeet,TorsoDirection;
  internal float[] Sole=new float[2],FloorRelativeToSeat=new float[2];
  internal Vector3[] Feet=new Vector3[2];internal Quaternion[] FootRotations=new Quaternion[2];
  internal static ChairStandingPose Get(Human human){ChairStandingPose result;return cache.TryGetValue(human,out result)?result:null;}
  internal static void Remember(Human human,ChairStandingPose pose){cache.Remove(human);cache.Add(human,pose);}
  internal static ChairStandingPose Capture(ChairTransition.Snapshot s)
  {
   var inverse=Quaternion.Inverse(ChairPoseFrame.Upright(s.Rotation));var mid=(s.LeftFootPosition+s.RightFootPosition)*.5f;
   var result=new ChairStandingPose{HipRotation=inverse*s.HipRotation,HipAboveFeet=inverse*(s.HipPosition-mid),LocalRotations=(Quaternion[])s.Rotations.Clone()};
   result.Feet[0]=inverse*(s.LeftFootPosition-s.Position);result.Feet[1]=inverse*(s.RightFootPosition-s.Position);
   var chain=new List<Transform>();
   for(var node=s.Bones[3];node!=null&&node!=s.Bones[0];node=node.parent)chain.Add(node);
   chain.Reverse();if(chain.Count==0||chain.Count>8)return null;
   result.TorsoDirection=(inverse*(s.Bones[3].position-s.HipPosition)).normalized;
   result.Torso=chain.ToArray();result.TorsoRotations=new Quaternion[chain.Count];
   for(int i=0;i<chain.Count;i++)result.TorsoRotations[i]=chain[i].localRotation;
   result.FootRotations[0]=inverse*s.LeftFootRotation;result.FootRotations[1]=inverse*s.RightFootRotation;
   for(int i=0;i<2;i++){result.ToeReady[i]=s.ToeBones[i]!=null;if(result.ToeReady[i])result.ToeRotations[i]=s.ToeRotations[i];}
   Plugin.Log.LogInfo("Chair foot joints: L="+(s.ToeBones[0]!=null?s.ToeBones[0].name:"unmapped")+", R="+(s.ToeBones[1]!=null?s.ToeBones[1].name:"unmapped"));
   if(!ChairFloorProbe.Calibrate(s,result))return null;
   ChairRigDiagnostics.Calibration(s,result);return result;
  }
 }
 internal struct ChairNativePose
 {
  public bool Ready;public Vector3 Hips,Left,Right,Head,LeftUpper,LeftKnee,RightUpper,RightKnee;public Quaternion HipRotation,LeftRotation,RightRotation;
 }
}
