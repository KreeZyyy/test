namespace StationEmotes
{
 internal static class ToiletUsePolicy
 {
  internal static bool Ready(bool sameOccupant,bool transitionActive,float now,float readyAt)
   =>sameOccupant&&!transitionActive&&!float.IsNaN(now)&&!float.IsNaN(readyAt)&&!float.IsInfinity(now)&&!float.IsInfinity(readyAt)&&now>=readyAt;
 }
}
