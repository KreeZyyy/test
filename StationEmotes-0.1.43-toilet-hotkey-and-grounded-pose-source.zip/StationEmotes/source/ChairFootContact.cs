using UnityEngine;
namespace StationEmotes
{
 internal static class ChairFootContact
 {
  // Ground-contact rotations come from the actual calibrated native standing pose.
  internal static float SeatedRotationRelease(float rest,float clearance)
   =>rest*ChairTransitionPolicy.Ease((clearance-.008f)/.04f);
  internal static Quaternion GroundRotation(Quaternion facing,Quaternion calibrated)=>facing*calibrated;
  internal static Quaternion Rotation(bool entering,Quaternion contact,Quaternion seated,float rest,float clearance)
   =>entering?Quaternion.Slerp(contact,seated,SeatedRotationRelease(rest,clearance)):contact;
  internal static float LegWeight(float release)=>1-Mathf.Clamp(release,0,1);
  internal static float RotationWeight(bool entering,float release)=>entering?LegWeight(release):1;
  internal static Vector3 StandingFoot(Vector3 root,Quaternion facing,Vector3 calibrated)
   =>root+facing*calibrated;
 }
}
