using System;
using UnityEngine;
namespace StationEmotes
{
 internal enum ChairReachStatus{Valid,Unreachable,SolverResidual,Invalid}
 internal struct ChairLegMetrics
 {
  internal Vector3 UpperPosition,KneePosition,AnklePosition,TargetPosition;
  internal float Upper,Lower,Minimum,Maximum,ActualSpan,TargetSpan,Horizontal,Vertical,KneeFlex,ReachRatio,Excess;
  internal ChairReachStatus Status;
  internal static ChairReachStatus Classify(float upper,float lower,float distance,float residual)
  {
   if(!Finite(upper)||!Finite(lower)||!Finite(distance)||!Finite(residual)||upper<.01f||lower<.01f||distance<0||residual<0)return ChairReachStatus.Invalid;
   float maximum=upper+lower,tolerance=Math.Max(.002f,maximum*.005f);
   if(distance>maximum+tolerance||distance<Math.Abs(upper-lower)-tolerance)return ChairReachStatus.Unreachable;
   return residual>Math.Max(.008f,maximum*.025f)?ChairReachStatus.SolverResidual:ChairReachStatus.Valid;
  }
  private static bool Finite(float x)=>!float.IsNaN(x)&&!float.IsInfinity(x);
  internal static ChairLegMetrics Measure(Vector3 upper,Vector3 knee,Vector3 ankle,Vector3 target,float residual)
  {
   var delta=target-upper;
   var result=new ChairLegMetrics{UpperPosition=upper,KneePosition=knee,AnklePosition=ankle,TargetPosition=target,Upper=(knee-upper).magnitude,Lower=(ankle-knee).magnitude,ActualSpan=(ankle-upper).magnitude,
    TargetSpan=delta.magnitude,Horizontal=new Vector3(delta.x,0,delta.z).magnitude,Vertical=upper.y-target.y,
    KneeFlex=180f-Vector3.Angle(upper-knee,ankle-knee)};
   result.Minimum=Math.Abs(result.Upper-result.Lower);result.Maximum=result.Upper+result.Lower;result.ReachRatio=result.Maximum>.001f?result.ActualSpan/result.Maximum:0;
   result.Excess=Math.Max(0,Math.Max(result.TargetSpan-result.Maximum,result.Minimum-result.TargetSpan));result.Status=Classify(result.Upper,result.Lower,result.TargetSpan,residual);return result;
  }
 }
}
