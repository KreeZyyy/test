using UnityEngine;
namespace StationEmotes
{
 internal static class ChairBodyPath
 {
  internal static float Settle(float body)=>ChairTransitionPolicy.Ease((body-.35f)/.65f);
  internal static float Posture(float body)=>ChairTransitionPolicy.Ease(body);
  internal static float Lean(bool entering,float preparation,float body)=>entering?5f*Mathf.Sin(body*Mathf.PI):4f*preparation*(1-body);
  internal static Vector3 Support(Vector3 left,Vector3 right,int swinging,float progress)
  {
   var middle=(left+right)*.5f;middle.y=Mathf.Min(left.y,right.y);
   if(swinging>=0){var planted=swinging==0?right:left;float shift=.35f*Mathf.Sin(progress*Mathf.PI);middle.x=Mathf.Lerp(middle.x,planted.x,shift);middle.z=Mathf.Lerp(middle.z,planted.z,shift);}
   return middle;
  }
  internal static Vector3 Pelvis(bool entering,Vector3 seated,Vector3 support,Vector3 native,float preparation,float body,float release)
  {
   // One endpoint curve used in both directions. Exit adds only a small weight transfer.
   float seatedWeight=entering?body:1-body;
   var result=Vector3.Lerp(support,entering?native:seated,ChairTransitionPolicy.Ease((seatedWeight-.10f)/.90f));
   result.y=Mathf.Lerp(support.y,entering?native.y:seated.y,seatedWeight);
   if(!entering)
   {
    var delta=support-seated;delta.y=0;
    result+=delta*(.15f*preparation*(1-body));
    result=Vector3.Lerp(result,native,release);
   }
   return result;
  }
 }
}
