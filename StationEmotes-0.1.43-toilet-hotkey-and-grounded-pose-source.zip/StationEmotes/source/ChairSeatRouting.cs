using System;
using System.Collections.Generic;
using System.Reflection;
using Assets.Scripts;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Entities;
using Assets.Scripts.Objects.Electrical;
using Assets.Scripts.Objects.Structures;
using HarmonyLib;
using Objects.Rockets;
using Objects.Structures;
using UnityEngine;
namespace StationEmotes
{
 internal static class ChairSeatRouting
 {
  internal static bool Supported(Thing t)=>t is Seat||t is AtmosphericSeat||t is CrewModuleChair||t is StructureToilet;
  internal static bool Supported(Slot slot)=>slot!=null&&Supported(slot.Parent)&&slot.Type==Slot.Class.Entity&&slot.EntityControlMode==MovementController.Mode.Seated&&slot.Location!=null;
  internal static Slot First(Thing t)=>t?.Slots?.Find(Supported);
  internal static Quaternion Facing(Slot slot)=>ChairPoseFrame.Upright(slot.Location.rotation);
  internal static Vector3 NativeFront(Thing t)
  {
   if(t is Seat chair){try{return chair.ExitPosition;}catch(NullReferenceException){return chair.transform.position+chair.transform.forward*.65f;}}
   if(t is AtmosphericSeat control)return control.ExitPosition;
   if(t is CrewModuleChair crew){var exit=AccessTools.Field(typeof(CrewModuleChair),"_exitTransform").GetValue(crew) as Transform;return exit!=null?exit.position:crew.transform.position+crew.transform.forward*.65f;}
   if(t is StructureToilet toilet)return ToiletSeating.Front(toilet);
   return t.transform.position+t.transform.forward*.6f;
  }
  internal static Vector3 Front(Slot slot)
  {
   var first=First(slot.Parent);var point=NativeFront(slot.Parent);
   if(first==null)return point;
   return ChairSeatGeometry.Front(slot.Location.position,Facing(slot),point,first.Location.position,Facing(first),slot.Parent.Slots.FindAll(Supported).Count>1);
  }
  internal static bool TryExit(Human h,Slot slot,out Vector3 point)
  {
   point=Front(slot);
   float expected=h.ThingTransform.position.y;
   var standing=ChairStandingPose.Get(h);
   if(standing!=null)expected=slot.Parent.transform.position.y+(standing.FloorRelativeToSeat[0]+standing.FloorRelativeToSeat[1])*.5f;
   ChairFloorContact contact;
   if(!ChairFloorProbe.Try(point,slot.Parent,h,expected,out contact))return false;
   point.y=contact.Point.y;
   // Ignore the current occupant's own colliders, but reject other occupants and obstructions.
   var hits=Physics.OverlapCapsule(point+Vector3.up*.22f,point+Vector3.up*.7f,.18f,h.AllButPlayerImmune,QueryTriggerInteraction.Ignore);
   foreach(var hit in hits)if(hit!=null&&!hit.transform.IsChildOf(h.ThingTransform))return false;
   return true;
  }
 }
 // Every selected entity slot gets its own approach. Native flight/lock restrictions still run.
 [HarmonyPatch]
 internal static class ChairAllFrontPatch
 {
  static IEnumerable<MethodBase> TargetMethods()
  {
   yield return AccessTools.Method(typeof(Seat),"InteractWith");
   yield return AccessTools.Method(typeof(Thing),"InteractWith");
   yield return AccessTools.Method(typeof(CrewModuleChair),"InteractWith");
  }
  static bool Prefix(Thing __instance,Interactable __0,Interaction __1,bool __2,ref Thing.DelayedActionInstance __result)
  {
   var slot=__0.Slot;
   if(!ChairSeatRouting.Supported(slot)||slot.Parent!=__instance||__instance is StructureToilet||!(__1.SourceThing is Human h))return true;
   if(slot.Get()!=null)
   {
    var action=new Thing.DelayedActionInstance{Duration=.25f,ActionMessage="Stand up"};__result=action;
    if(slot.Get()!=h){action.ExtendedMessage="This seat is occupied.";action.Fail();return false;}
    if(h.LockedToSeat||(__instance is CrewModuleChair crew&&!crew.CanExitSeat()))
    {action.ExtendedMessage="This seat is currently locked.";action.Fail();return false;}
    if(!ChairSeatRouting.TryExit(h,slot,out var point)){action.ExtendedMessage="The space in front of this seat is blocked.";action.Fail();return false;}
    if(__2&&GameManager.RunSimulation&&!h.ExitAnything()){action.Fail();return false;}
    action.Succeed();return false;
   }
   var positions=__instance.Slots.FindAll(ChairSeatRouting.Supported);
   var result=new Thing.DelayedActionInstance{Duration=2,ActionMessage=positions.Count>1?"Sit down (seat "+(positions.IndexOf(slot)+1)+")":"Sit down"};__result=result;
   if(slot.IsLocked||h.ParentSlot!=null||!ChairTransition.InFront(h,slot))
   {result.ExtendedMessage="Stand directly in front of this seat to sit down.";result.Fail();return false;}
   if(__2&&GameManager.RunSimulation)OnServer.MoveToSlot(h,slot);
   result.Succeed();return false;
  }
 }
 // Native GetExitPosition is used before the client's MoveToWorld message is sent.
 [HarmonyPatch]
 internal static class ChairPerSlotExitPointPatch
 {
  static IEnumerable<MethodBase> TargetMethods()
  {
   yield return AccessTools.Method(typeof(Seat),"GetExitPosition");
   yield return AccessTools.Method(typeof(AtmosphericSeat),"GetExitPosition");
   yield return AccessTools.Method(typeof(CrewModuleChair),"GetExitPosition");
  }
  static bool Prefix(Thing __instance,Entity __0,ref Vector3 __result)
  {
   var slot=__0?.ParentSlot;
   if(slot==null||slot.Parent!=__instance||!ChairSeatRouting.Supported(slot))return true;
   if(__0 is Human h&&ChairSeatRouting.TryExit(h,slot,out var point))__result=point;
   else __result=ChairSeatRouting.Front(slot);
   return false;
  }
 }
 // Seat.Exit itself uses a common ExitPosition, so route the native exit call per occupied slot.
 [HarmonyPatch]
 internal static class ChairPerSlotExitPatch
 {
  static IEnumerable<MethodBase> TargetMethods()
  {
   yield return AccessTools.Method(typeof(Seat),"Exit");
   yield return AccessTools.Method(typeof(AtmosphericSeat),"Exit");
  }
  static bool Prefix(Human __0)
  {
   var slot=__0.ParentSlot;if(!ChairSeatRouting.Supported(slot))return true;
   if(ChairSeatRouting.TryExit(__0,slot,out var point))__0.MoveToWorld(point,ChairSeatRouting.Facing(slot),Vector3.zero,Vector3.zero);
   return false;
  }
 }
 [HarmonyPatch(typeof(Human),"ExitAnything")]
 internal static class ChairExitClearancePatch
 {
  static bool Prefix(Human __instance,ref bool __result)
  {
   var slot=__instance.ParentSlot;if(!ChairSeatRouting.Supported(slot))return true;
   if(__instance.LockedToSeat||!ChairSeatRouting.TryExit(__instance,slot,out var point)){__result=false;return false;}
   return true;
  }
 }

}
