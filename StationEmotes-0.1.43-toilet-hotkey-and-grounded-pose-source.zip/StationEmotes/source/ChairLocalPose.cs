using UnityEngine;namespace StationEmotes{internal struct ChairLocalPose{
 public Quaternion A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P;
 public Quaternion Get(int i){switch(i){case 0:return A;case 1:return B;case 2:return C;case 3:return D;case 4:return E;case 5:return F;case 6:return G;case 7:return H;case 8:return I;case 9:return J;case 10:return K;case 11:return L;case 12:return M;case 13:return N;case 14:return O;default:return P;}}
 public void Set(int i,Quaternion value){switch(i){case 0:A=value;break;case 1:B=value;break;case 2:C=value;break;case 3:D=value;break;case 4:E=value;break;case 5:F=value;break;case 6:G=value;break;case 7:H=value;break;case 8:I=value;break;case 9:J=value;break;case 10:K=value;break;case 11:L=value;break;case 12:M=value;break;case 13:N=value;break;case 14:O=value;break;case 15:P=value;break;}}
}}
