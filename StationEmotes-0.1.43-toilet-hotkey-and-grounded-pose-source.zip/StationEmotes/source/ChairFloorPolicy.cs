using System;
namespace StationEmotes
{
 internal static class ChairFloorPolicy
 {
  private static bool Finite(float x)=>!float.IsNaN(x)&&!float.IsInfinity(x);
  internal static bool Accept(float normalY,float height,float expected,bool chair,bool human)
  {
   if(chair||human||!Finite(normalY)||!Finite(height)||normalY<.65f)return false;
   return float.IsNaN(expected)||(Finite(expected)&&height>=expected-.35f&&height<=expected+.20f);
  }
  internal static bool Clearance(float value)=>Finite(value)&&value>=-.01f&&value<=.35f;
  internal static float Ankle(float floor,float sole)=>floor+sole;
 }
}
