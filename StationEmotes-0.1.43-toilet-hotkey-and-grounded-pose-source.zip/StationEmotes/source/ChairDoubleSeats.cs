using System.Collections.Generic;
using Assets.Scripts.Objects;
using UnityEngine;
namespace StationEmotes
{
 internal static class ChairDoubleSeats
 {
  private static readonly HashSet<string> reported=new HashSet<string>();
  internal static void InstallLoaded()
  {
   foreach(var thing in Resources.FindObjectsOfTypeAll<Thing>())
   {
    if(!ChairSeatRouting.Supported(thing)||thing.Slots==null)continue;
    var name=string.IsNullOrEmpty(thing.PrefabName)?thing.name:thing.PrefabName;
    var seats=thing.Slots.FindAll(ChairSeatRouting.Supported);if(seats.Count==0||!reported.Add(name))continue;
    Plugin.Log.LogInfo("Native seat layout: "+name+", seats="+seats.Count+"; original slot positions retained.");
    foreach(var slot in seats)Plugin.Log.LogInfo("Native seat "+slot.SlotIndex+": local="+slot.Location.localPosition.ToString("F3")+", yaw="+ChairSeatRouting.Facing(slot).eulerAngles.y.ToString("F1"));
   }
  }
 }
}
