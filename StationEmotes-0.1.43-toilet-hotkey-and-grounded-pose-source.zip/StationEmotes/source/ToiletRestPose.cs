using Assets.Scripts;
using Assets.Scripts.Objects.Entities;
using Objects.Structures;
using UnityEngine;
namespace StationEmotes
{
 // Toilet-only visual pose. No chair slot, native waste logic or physics root is replaced.
 [DefaultExecutionOrder(33000)]
 internal sealed class ToiletRestPose:MonoBehaviour
 {
  private readonly Vector3[] targets=new Vector3[2];
  private Human human;private Animator animator;private readonly Transform[] bones=new Transform[7],toes=new Transform[2];
  internal static void Begin(Human h)
  {
   if(GameManager.IsBatchMode||h==null||h.EmoteController==null)return;
   var pose=h.GetComponent<ToiletRestPose>()??h.gameObject.AddComponent<ToiletRestPose>();
   pose.human=h;pose.animator=Plugin.BodyAnimator.GetValue(h.EmoteController) as Animator;
   if(pose.animator==null||!pose.animator.isHuman)return;
   HumanBodyBones[] ids={HumanBodyBones.Hips,HumanBodyBones.LeftUpperLeg,HumanBodyBones.LeftLowerLeg,HumanBodyBones.LeftFoot,HumanBodyBones.RightUpperLeg,HumanBodyBones.RightLowerLeg,HumanBodyBones.RightFoot};
   for(int i=0;i<ids.Length;i++)pose.bones[i]=pose.animator.GetBoneTransform(ids[i]);
   for(int i=0;i<2;i++)pose.toes[i]=ChairToeContact.Find(pose.animator,pose.bones[i==0?3:6],i==0);
  }
  internal static ChairNativePose Endpoint(ChairTransition.Snapshot s,ChairNativePose native,ref ChairTorsoStream toeTarget)
  {
   var state=s.Seat.GetComponent<ToiletOccupancy>();if(state==null||!state.FloorReady)return native;
   var forward=s.SeatFacing*Vector3.forward;var right=s.SeatFacing*Vector3.right;
   var left=ToiletRestPolicy.Foot(native.LeftUpper,forward,right,0,state.FloorY+s.Standing.Sole[0]);
   var other=ToiletRestPolicy.Foot(native.RightUpper,forward,right,1,state.FloorY+s.Standing.Sole[1]);
   float l=(s.LegUpper[0]-s.LegKnee[0]).magnitude+(s.LeftFootPosition-s.LegKnee[0]).magnitude;
   float r=(s.LegUpper[1]-s.LegKnee[1]).magnitude+(s.RightFootPosition-s.LegKnee[1]).magnitude;
   float drop=ToiletRestPolicy.Drop(native.LeftUpper,native.RightUpper,left,other,l,r);
   var shift=Vector3.up*drop;native.Hips-=shift;native.Head-=shift;native.LeftUpper-=shift;native.RightUpper-=shift;native.LeftKnee-=shift;native.RightKnee-=shift;
   native.Left=ToiletRestPolicy.Reachable(native.LeftUpper,left,l);native.Right=ToiletRestPolicy.Reachable(native.RightUpper,other,r);native.LeftRotation=s.SeatFacing*s.Standing.FootRotations[0];native.RightRotation=s.SeatFacing*s.Standing.FootRotations[1];
   for(int side=0;side<2;side++)if(s.Standing.ToeReady[side]){var toe=toeTarget.Get(side);toe.Ready=true;toe.NativeRotation=s.Standing.ToeRotations[side];toeTarget.Set(side,toe);}
   Plugin.Log.LogInfo("Toilet custom pose: feet on floor, pelvis support correction="+drop.ToString("F3"));
   return native;
  }
  private void LateUpdate()
  {
   var t=human?.ParentSlot?.Parent as StructureToilet;
   if(human==null||t==null||human.ParentSlot!=ToiletSeating.Slot(t)){Destroy(this);return;}
   if(human.GetComponent<ChairTransition>()?.Active==true||animator==null||human.State!=EntityState.Alive)return;
   for(int i=0;i<bones.Length;i++)if(bones[i]==null)return;
   var state=t.GetComponent<ToiletOccupancy>();if(state==null||!state.FloorReady)return;
   var reference=ChairStandingPose.Get(human);var facing=ChairSeatRouting.Facing(human.ParentSlot);
   var forward=facing*Vector3.forward;var right=facing*Vector3.right;
   for(int side=0;side<2;side++)
   {
    float sole=reference!=null?reference.Sole[side]:Mathf.Clamp(animator.humanScale*.14f,.03f,.12f);
    var goal=ToiletRestPolicy.Foot(bones[side==0?1:4].position,forward,right,side,state.FloorY+sole);
    ChairFloorContact floor;if(!ChairFloorProbe.Try(goal,t,human,state.FloorY,out floor))return;
    goal.y=floor.Point.y+sole;targets[side]=goal;
   }
   float reachL=(bones[2].position-bones[1].position).magnitude+(bones[3].position-bones[2].position).magnitude;
   float reachR=(bones[5].position-bones[4].position).magnitude+(bones[6].position-bones[5].position).magnitude;
   bones[0].position-=Vector3.up*ToiletRestPolicy.Drop(bones[1].position,bones[4].position,targets[0],targets[1],reachL,reachR);
   for(int side=0;side<2;side++)
   {
    int start=side==0?1:4;targets[side]=ToiletRestPolicy.Reachable(bones[start].position,targets[side],side==0?reachL:reachR);
    var rotation=reference!=null?facing*reference.FootRotations[side]:bones[start+2].rotation;
    Solve(bones[start],bones[start+1],bones[start+2],targets[side],rotation,forward);
    if(toes[side]!=null&&reference!=null&&reference.ToeReady[side])toes[side].localRotation=reference.ToeRotations[side];
   }
  }
  private static void Solve(Transform upper,Transform knee,Transform foot,Vector3 target,Quaternion rotation,Vector3 forward)
  {
   var a=upper.position;var b=knee.position;var c=foot.position;float u=(b-a).magnitude,l=(c-b).magnitude,d=(target-a).magnitude;
   if(u<.01f||l<.01f||d<.001f)return;
   var direction=(target-a)/d;var pole=Vector3.ProjectOnPlane(forward,direction);if(pole.sqrMagnitude<.0001f)return;
   float axial,lateral;ChairStepPolicy.Knee(u,l,d,out axial,out lateral);
   var desired=a+direction*axial+pole.normalized*lateral;
   upper.rotation=Quaternion.FromToRotation(b-a,desired-a)*upper.rotation;
   knee.rotation=Quaternion.FromToRotation(foot.position-knee.position,target-knee.position)*knee.rotation;foot.rotation=rotation;
  }
 }
 internal static class ToiletRestPolicy
 {
  internal static Vector3 Foot(Vector3 hipJoint,Vector3 forward,Vector3 right,int side,float floorAnkle)
  {
   var foot=hipJoint+forward*.14f+right*(side==0?-.025f:.025f);foot.y=floorAnkle;return foot;
  }
  internal static Vector3 Reachable(Vector3 joint,Vector3 target,float reach)
  {
   float safe=Mathf.Max(0,reach-.002f),vertical=joint.y-target.y;
   float radius=Mathf.Sqrt(Mathf.Max(0,safe*safe-vertical*vertical));
   var offset=target-joint;offset.y=0;
   if(offset.magnitude>radius){offset=offset.normalized*radius;target.x=joint.x+offset.x;target.z=joint.z+offset.z;}
   return target;
  }
  internal static float Drop(Vector3 left,Vector3 right,Vector3 lfoot,Vector3 rfoot,float lreach,float rreach)
   =>Mathf.Min(.03f,Mathf.Max(ChairExitPlacement.RequiredDrop(left,lfoot,lreach),ChairExitPlacement.RequiredDrop(right,rfoot,rreach)));
 }
}
