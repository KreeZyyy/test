using UnityEngine;
namespace StationEmotes
{
 internal static class ChairSeatGeometry
 {
  internal static Quaternion VisualRotation(bool entering,Quaternion source,Quaternion facing,float turn,Quaternion native,float release)
   =>entering?Quaternion.Slerp(Quaternion.Slerp(source,facing,turn),native,release):facing;
  internal static Vector3 Front(Vector3 position,Quaternion facing,Vector3 nativeFront,Vector3 firstPosition,Quaternion firstFacing,bool multiple)
  {
   if(!multiple)return nativeFront;
   float distance=Vector3.Dot(nativeFront-firstPosition,firstFacing*Vector3.forward);
   if(float.IsNaN(distance)||float.IsInfinity(distance)||distance<.25f)distance=.65f;
   distance=Mathf.Clamp(distance,.45f,1.2f);
   var point=position+(facing*Vector3.forward)*distance;
   point.y=nativeFront.y+position.y-firstPosition.y;
   return point;
  }
 }
}
