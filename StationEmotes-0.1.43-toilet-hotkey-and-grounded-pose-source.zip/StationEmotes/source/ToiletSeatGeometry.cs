using UnityEngine;
namespace StationEmotes
{
 internal static class ToiletSeatGeometry
 {
  // Like native chair slots, the entity origin is on the floor; the seated clip supplies pelvis height.
  internal const float Lift=.04f,Forward=.18f;
  internal static Vector3 Anchor(Vector3 bowlCentre,float floorY)=>new Vector3(bowlCentre.x,floorY+Lift,bowlCentre.z);
  internal static Vector3 Anchor(Vector3 bowlCentre,float floorY,Vector3 forward)
   =>Anchor(bowlCentre,floorY)+Vector3.ProjectOnPlane(forward,Vector3.up).normalized*Forward;
  internal static bool TryUnitScale(Vector3 parentScale,out Vector3 local)
  {
   local=Vector3.one;
   if(!Valid(parentScale.x)||!Valid(parentScale.y)||!Valid(parentScale.z))return false;
   local=new Vector3(1/parentScale.x,1/parentScale.y,1/parentScale.z);return true;
  }
  private static bool Valid(float n)=>!float.IsNaN(n)&&!float.IsInfinity(n)&&Mathf.Abs(n)>.0001f;
 }
 internal static class ChairEndpointPolicy
 {
  internal static bool Blocks(int layer,float weight,bool inTransition)=>inTransition&&(layer==0||weight>.01f);
 }
 internal static class FlatBenchPolicy
 {
  internal static bool Matches(string prefab,string objectName,string display)
  {
   var name=(prefab+" "+objectName+" "+display).ToLowerInvariant();
   return name.Contains("flat")&&(name.Contains("bench")||name.Contains("seat"));
  }
 }
}
