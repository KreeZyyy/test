using UnityEngine;
namespace StationEmotes
{
 internal static class ChairPoseFrame
 {
  internal static Quaternion Upright(Quaternion rotation)
  {
   var forward=Vector3.ProjectOnPlane(rotation*Vector3.forward,Vector3.up);
   if(forward.sqrMagnitude<.000001f){var right=Vector3.ProjectOnPlane(rotation*Vector3.right,Vector3.up);forward=Vector3.Cross(right,Vector3.up);}
   return forward.sqrMagnitude<.000001f?Quaternion.identity:Quaternion.LookRotation(forward.normalized,Vector3.up);
  }
 }
}
