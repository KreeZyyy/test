using System;using StationEmotes;using UnityEngine;
class Check
{
 static int n;static void A(bool b,string m){n++;if(!b)throw new Exception(m);}static bool Near(float a,float b)=>Math.Abs(a-b)<.0001f;static bool Near(Vector3 a,Vector3 b)=>Near(a.x,b.x)&&Near(a.y,b.y)&&Near(a.z,b.z);
 static void Main()
 {
  A(new ChairPlan(true,0,0).StepCount==0,"unneeded steps");A(new ChairPlan(true,.1f,45).WalkSteps==2,"short walk");A(new ChairPlan(true,.8f,180).WalkSteps==4,"long walk");A(new ChairPlan(true,0,90).TurnSteps==4,"quarter turn");A(new ChairPlan(true,0,180).TurnSteps==6,"half turn");
  foreach(bool entering in new[]{true,false})foreach(float distance in new[]{0f,.06f,.2f,.7f})foreach(float angle in new[]{0f,8f,45f,90f,180f})
  {
   var p=new ChairPlan(entering,distance,angle);
   A(p.Body(0)==0&&p.Body(p.Duration)==1,"body endpoints");A(p.EndRelease(0)==0&&Near(p.EndRelease(p.Duration),1),"release endpoints");
   float previous=-1;
   for(int i=0;i<p.StepCount;i++){float start,duration,advance;bool turning;p.Step(i,out start,out duration,out advance,out turning);A(start>=previous-.0001f,"step overlap");A(start+duration<=p.Duration,"step outside plan");A(advance>0&&advance<=1,"step advance");previous=start+duration;}
   if(!entering&&p.StepCount>0){float start,d,a;bool turn;p.Step(0,out start,out d,out a,out turn);A(start>=p.BodyStart+ChairPlan.BodyDuration,"steps before standing");}
   for(int i=0;i<=50;i++){float t=p.Duration*i/50;A(p.Body(t)>=0&&p.Body(t)<=1,"body range");A(p.Walk(t)>=0&&p.Walk(t)<=1,"walk range");A(p.Turn(t)>=0&&p.Turn(t)<=1,"turn range");}
  }
  Vector3 seated=new Vector3(0,.45f,0),support=new Vector3(0,.95f,.3f),native=new Vector3(0,.94f,.32f);
  Vector3 before=ChairBodyPath.Pelvis(false,seated,support,native,0,0,0),transfer=ChairBodyPath.Pelvis(false,seated,support,native,1,0,0);
  A(Near(before,seated),"rise source");A(Near(transfer.y,seated.y)&&transfer.z>seated.z&&transfer.z<support.z,"transfer while seated");
  A(Near(ChairBodyPath.Pelvis(false,seated,support,native,1,1,0),support),"rise over support");A(Near(ChairBodyPath.Pelvis(false,seated,support,native,1,1,1),native),"rise native endpoint");
  A(Near(ChairBodyPath.Pelvis(true,seated,support,seated,0,0,0),support),"sit standing source");A(Near(ChairBodyPath.Pelvis(true,seated,support,seated,0,1,1),seated),"sit native endpoint");
  Vector3 left=new Vector3(-.12f,.08f,0),right=new Vector3(.12f,.08f,0),lifted=new Vector3(-.12f,.155f,0);
  var mid=ChairBodyPath.Support(lifted,right,0,.5f);A(Near(mid.y,.08f)&&mid.x>0,"swing must not lift pelvis / support weight");
  for(int i=0;i<=100;i++){float b=i/100f;A(Math.Abs(ChairBodyPath.Lean(true,0,b))<=5.0001f,"sit lean limit");A(Math.Abs(ChairBodyPath.Lean(false,1,b))<=6.0001f,"rise lean limit");A(ChairStepPolicy.Lift(b)>=0&&ChairStepPolicy.Lift(b)<=.0751f,"swing clearance");}
  foreach(float a in new[]{.35f,.45f,.55f})foreach(float b in new[]{.35f,.45f,.55f})foreach(float t in new[]{.2f,.6f,.95f}){float d=Math.Abs(a-b)+.001f+(a+b-Math.Abs(a-b)-.002f)*t,x,y;ChairStepPolicy.Knee(a,b,d,out x,out y);A(Near((float)Math.Sqrt(x*x+y*y),a)&&Near((float)Math.Sqrt((d-x)*(d-x)+y*y),b),"knee lengths");}
  Console.WriteLine(n+" production choreography/support/path checks passed (math stubs; no Unity runtime).");
 }
}
namespace UnityEngine
{
 public struct Vector3{public float x,y,z;public Vector3(float a,float b,float c){x=a;y=b;z=c;}public static Vector3 operator +(Vector3 a,Vector3 b)=>new Vector3(a.x+b.x,a.y+b.y,a.z+b.z);public static Vector3 operator *(Vector3 a,float b)=>new Vector3(a.x*b,a.y*b,a.z*b);public static Vector3 Lerp(Vector3 a,Vector3 b,float t)=>new Vector3(Mathf.Lerp(a.x,b.x,t),Mathf.Lerp(a.y,b.y,t),Mathf.Lerp(a.z,b.z,t));}
 public static class Mathf{public const float PI=(float)Math.PI;public static float Sin(float v)=>(float)Math.Sin(v);public static float Min(float a,float b)=>Math.Min(a,b);public static float Lerp(float a,float b,float t)=>a+(b-a)*Math.Max(0,Math.Min(1,t));}
}
