using UnityEngine;using UnityEngine.Animations;namespace StationEmotes{
 internal struct ChairJob:IAnimationJob
 {
  public Vector3 StartHips;public float Blend;public ChairNativePose Native;
  public PoseSlot A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P;
  public void Set(int i,PoseSlot s){switch(i){case 0:A=s;break;case 1:B=s;break;case 2:C=s;break;case 3:D=s;break;case 4:E=s;break;case 5:F=s;break;case 6:G=s;break;case 7:H=s;break;case 8:I=s;break;case 9:J=s;break;case 10:K=s;break;case 11:L=s;break;case 12:M=s;break;case 13:N=s;break;case 14:O=s;break;case 15:P=s;break;}}
  private PoseSlot Get(int i){switch(i){case 0:return A;case 1:return B;case 2:return C;case 3:return D;case 4:return E;case 5:return F;case 6:return G;case 7:return H;case 8:return I;case 9:return J;case 10:return K;case 11:return L;case 12:return M;case 13:return N;case 14:return O;default:return P;}}
  public void ProcessRootMotion(AnimationStream stream){}
  public void ProcessAnimation(AnimationStream stream)
  {
   // Read the native endpoints before replacing any rotations or pelvis coordinates.
   Native.Ready=false;
   if(A.Handle.IsValid(stream)&&M.Handle.IsValid(stream)&&P.Handle.IsValid(stream))
   {
    A.Handle.Resolve(stream);M.Handle.Resolve(stream);P.Handle.Resolve(stream);
    Native=new ChairNativePose{Ready=true,Hips=A.Handle.GetPosition(stream),HipRotation=A.Handle.GetRotation(stream),
     Left=M.Handle.GetPosition(stream),Right=P.Handle.GetPosition(stream),LeftRotation=M.Handle.GetRotation(stream),RightRotation=P.Handle.GetRotation(stream)};
   }
   for(int i=0;i<16;i++)
   {
    var bone=Get(i);if(!bone.Handle.IsValid(stream))continue;bone.Handle.Resolve(stream);
    var rotation=Quaternion.Slerp(bone.Rotation,bone.Handle.GetLocalRotation(stream),Blend);
    bone.Handle.SetLocalRotation(stream,rotation);
    if(i==0)bone.Handle.SetLocalPosition(stream,Vector3.Lerp(StartHips,bone.Handle.GetLocalPosition(stream),Blend));
   }
  }
 }
 internal struct ChairNativePose
 {
  public bool Ready;public Vector3 Hips,Left,Right;public Quaternion HipRotation,LeftRotation,RightRotation;
 }
}
