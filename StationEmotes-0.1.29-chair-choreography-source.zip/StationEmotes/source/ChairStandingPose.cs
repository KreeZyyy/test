using System.Runtime.CompilerServices;
using Assets.Scripts.Objects.Entities;
using UnityEngine;
namespace StationEmotes
{
 internal sealed class ChairStandingPose
 {
  private static readonly ConditionalWeakTable<Human,ChairStandingPose> cache=new ConditionalWeakTable<Human,ChairStandingPose>();
  internal Quaternion HipRotation;internal Quaternion[] LocalRotations;
  internal Vector3 HipAboveFeet;
  internal Vector3[] Feet=new Vector3[2];internal Quaternion[] FootRotations=new Quaternion[2];
  internal static ChairStandingPose Get(Human human){ChairStandingPose result;return cache.TryGetValue(human,out result)?result:null;}
  internal static void Remember(Human human,ChairStandingPose pose){cache.Remove(human);cache.Add(human,pose);}
  internal static ChairStandingPose Capture(ChairTransition.Snapshot s)
  {
   var inverse=Quaternion.Inverse(s.Rotation);var mid=(s.LeftFootPosition+s.RightFootPosition)*.5f;
   var result=new ChairStandingPose{HipRotation=inverse*s.HipRotation,HipAboveFeet=inverse*(s.HipPosition-mid),LocalRotations=(Quaternion[])s.Rotations.Clone()};
   result.Feet[0]=inverse*(s.LeftFootPosition-s.Position);result.Feet[1]=inverse*(s.RightFootPosition-s.Position);
   result.FootRotations[0]=inverse*s.LeftFootRotation;result.FootRotations[1]=inverse*s.RightFootRotation;return result;
  }
 }
 internal struct ChairNativePose
 {
  public bool Ready;public Vector3 Hips,Left,Right;public Quaternion HipRotation,LeftRotation,RightRotation;
 }
}
