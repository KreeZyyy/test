using System;
namespace StationEmotes
{
 internal static class ChairTransitionPolicy
 {
  internal const float Approach=.35f,Turn=.55f,Sit=.85f,Duration=Approach+Turn+Sit;
  internal static float Ease(float t){if(float.IsNaN(t)||t<=0)return 0;if(t>=1)return 1;return t*t*(3-2*t);}
  internal static float Move(float elapsed)=>Ease(elapsed/Approach);
  internal static float Rotate(float elapsed)=>Ease((elapsed-Approach)/Turn);
  internal static float Blend(float elapsed)=>Ease((elapsed-Approach-Turn)/Sit);
  internal static bool SafeDistance(float squared)=>!float.IsNaN(squared)&&!float.IsInfinity(squared)&&squared>=0&&squared<=2.25f;
  internal static bool Front(float side,float ahead,float height)=>!float.IsNaN(side)&&!float.IsNaN(ahead)&&!float.IsNaN(height)&&Math.Abs(side)<=.45f&&ahead>=-.15f&&ahead<=.75f&&Math.Abs(height)<=.55f;
 }
}
