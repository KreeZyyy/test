# Station Emotes 0.1.24
Requires BepInEx and StationeersLaunchPad. Replace the previous mod version, do not enable duplicate versions.

Hold F10 and select with the mouse; release to play. F11 or movement cancels. Esc closes the menu only. Native Wave loops; Salute and Sit hold. Custom Hands up, Point, Robot dance, Meme dance, Agree, Disagree and Facepalm require empty hands. Agree repeats a gentle nod, Disagree repeats a head shake, Facepalm holds the right palm in front of the visor. All persist until cancelled, switched or the same entry selected again. Observing clients should use the same version.

0.1.22 refines the radial menu with larger filled spacesuit silhouettes and helmet visors, icon-only sectors, central gesture names, opaque convex sector fills to avoid antialiased triangle seams, an orange selection arc and quieter footer hints. Selection policy, F10 controls, animations and network behavior are unchanged from 0.1.21. Live game appearance remains unverified.

The previous0.1.16 update corrects Facepalm wrist/IK-goal frame conversion. The job samples the native hand bone and native humanoid hand goal from the same animation stream, preserves their relative position/rotation, and maps the desired wrist pose into the correct goal frame. Imported bone axes are no longer treated as AvatarIKGoal axes.

The target height uses actual eye_l/eye_r landmarks where uniquely available. Named index/middle bones still calibrate the palm. Head-relative offsets remain in world distance units, and the palm follows the head tilt applied after the solver. Helmet detection and mesh-aware forward clearance remain separate from the bare-head profile. Unknown rigs use bounded fallback profiles. No guarantee is made for visual fit across every head/helmet: check both helmet and no-helmet appearances in game. Other gestures/dances are unchanged.

0.1.13 added three gestures and a larger ten-item wheel. IDs Agree41006, Disagree41007 and Facepalm41008 use the existing game emote message and cancellation/transition path. Facepalm uses humanoid right-hand IK; nod/shake use head transforms in the same owned overlay. No new root movement or game simulation is added.

The dance baseline from 0.1.12 keeps the 0.1.11 owned PreviousInputs overlay graph (confirmed live for Hands up and Point). It corrects dance ordering: humanoid pelvis/knee motion is submitted before SolveIK, then five upper-body transform slots are applied after SolveIK. Raw leg/hip transform slots are not applied over solved feet. This prevents the IK pass from rebuilding away the visible upper-body dance and prevents subsequent raw leg rotations from undoing foot support. The character root is not moved.

The 0.1.11 user log recorded 49 processed humanoid frames and 9/9 or 10/10 bone updates for dances despite their lack of visible motion. These counters prove execution, not visual correctness. The IK pass is the code path that distinguishes dance from working arm poses. The change requires another live visual test.

Custom poses still use procedural stream bone updates, with humanoid foot IK for dance where available. No imported animation clip or new physical movement is included. Native animations and cancellation policies are unchanged.

The earlier 0.1.10 scheduling failure was addressed in 0.1.11. Execution counters remain logged after one second; actual Unity rendering, graph evaluation, foot IK and multiplayer appearance still require live verification.

Build: source/StationEmotes.csproj, net472. Set GameManagedDirectory, BepInExDirectory and LaunchPadDirectory. Use the installed game UnityEngine.AnimationModule (including UnityEngine.Experimental.Animations output extensions) and PhysicsModule. Do not ship game or loader DLLs.


## Chair transitions — 0.1.24 prototype
Replaces the failed 0.1.23 pelvis-world-position interpolation. Ordinary chair entry is staged: a short alignment step (0.35s), turn toward the native seated facing direction (0.55s), then sit (0.85s). Exit reverses these phases. The body pose remains upright through alignment/turn; only the final phase blends toward the native seated pose. A small opposing thigh swing accompanies the alignment step; this is procedural, not a walking clip or foot IK.

Get In is accepted only while grounded directly in front of an empty ordinary Seat. Uses the chair's native ExitPosition as the front anchor, with ±0.45m lateral tolerance, -0.15..0.75m forward tolerance and ±0.55m height tolerance. Other positions return a disabled interaction with an English explanation. Native occupancy/entry validation remains intact; special seats and placing other items are not redesigned.

The common CharacterRotationY visual parent moves the complete skeleton, including HeadBone and its helmet/hair attachments. Runtime validation requires that the head belongs to that hierarchy; otherwise the transition is skipped and logged. Hips are blended in local space only. The main camera in first person is mapped through the same staged visual parent. Third-person camera translates by the visual offset, retaining its orbit. Visual offsets are restored before each animation update and on cancellation.

Native server root position, collider and slot ownership still change immediately. This is a staged visual transition, not collision-aware character locomotion, root-motion import or pathfinding. No new network messages. Every client needs the same build for consistent rendering; multiplayer timing and live visual quality remain unverified. Large native moves over 1.5m skip smoothing. F11/new emote/movement/death/slot change/unload cancel the transition.

Only ordinary exact Seat is enabled. Toilets, atmospheric/control/rocket seats and beds remain unchanged. No new wheel entry: use the chair normally.

Test in-game: stand on the floor directly before a normal empty chair and use Get In; observe the short alignment, turn, head/helmet attachment, camera and final sit. Exit and check the reverse sequence. Repeat from the sides/back to verify the front-only message; repeat with another player observing. Feet and staged orientation still require live validation.
