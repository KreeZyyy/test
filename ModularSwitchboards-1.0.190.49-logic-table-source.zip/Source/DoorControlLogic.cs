using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Motherboards;
using Assets.Scripts.Objects.Pipes;
using Assets.Scripts.GridSystem;
namespace ModularSwitchboards
{
    // Read-only view of an existing physical control. No new Thing/network ID,
    // power connection, interaction state or independently serialized state.
    internal sealed class DoorControlLogic:ILogicable
    {
        internal static readonly LogicType[] ReadFields={LogicType.Activate,LogicType.On,LogicType.PrefabHash,LogicType.ReferenceId,LogicType.NameHash};
        private readonly DinBreaker owner;
        private static readonly ConditionalWeakTable<DinBreaker,DoorControlLogic> views=new ConditionalWeakTable<DinBreaker,DoorControlLogic>();
        internal DoorControlLogic(DinBreaker control){owner=control;}
        internal static bool Supported(DinBreaker part)=>part!=null&&(part.IsDoorButton||part.IsDoorIsolator||part.IsDoorStop);
        private bool Ready=>Supported(owner)&&!owner.IsCursor&&!owner.IsBeingDestroyed&&owner.ReferenceId>0&&owner.IsStructureCompleted&&owner.Board?.PrimaryHost is SwitchboardCabinet host&&host.IsStructureCompleted;
        internal static IEnumerable<DoorControlLogic> Local(SmartModule core)
        {
            if(core==null||core.IsCursor||core.IsBeingDestroyed||!core.IsStructureCompleted||core.Cabinet==null)return Enumerable.Empty<DoorControlLogic>();
            return core.Cabinet.Wiring.Breakers.Where(Supported).Where(c=>ReferenceEquals(c.Board?.PrimaryHost,core.Cabinet)).Select(c=>views.GetValue(c,p=>new DoorControlLogic(p))).Where(v=>v.Ready);
        }
        public int TotalSlots=>0;public bool HasAnySlots=>false;public Thing GetAsThing=>owner;
        public Slot GetSlot(int slotIndex)=>null;public int GetNextSlotId(int slotIndex,bool isForward)=>-1;
        public int GetPrefabHash()=>owner.PrefabHash;public int GetNameHash()=>owner.GetNameHash();
        public string ToTooltip()=>DisplayName;
        public bool IsLogicSlotReadable()=>false;public bool IsLogicReadable()=>Ready;public bool IsLogicWritable()=>false;
        public bool CanLogicRead(LogicType type)=>Ready&&Array.IndexOf(ReadFields,type)>=0;
        public bool CanLogicWrite(LogicType type)=>false;
        public double GetLogicValue(LogicType type)
        {
            if(!CanLogicRead(type))return double.NaN;
            if(type==LogicType.Activate||type==LogicType.On)return owner.OnOff?1d:0d;
            if(type==LogicType.PrefabHash)return GetPrefabHash();
            if(type==LogicType.ReferenceId)return ReferenceId;
            return GetNameHash();
        }
        public void SetLogicValue(LogicType type,double value){throw new InvalidOperationException("Door control state is read-only; use the physical control.");}
        public bool CanLogicRead(LogicSlotType type,int slotId)=>false;
        public double GetLogicValue(LogicSlotType type,int slotId)=>double.NaN;
        public string DisplayName=>((IReferencable)owner).DisplayName;
        public ushort NetworkUpdateFlags {get=>owner.NetworkUpdateFlags;set=>owner.NetworkUpdateFlags=value;}
        public long ReferenceId {get=>owner.ReferenceId;set=>throw new InvalidOperationException("The control owns its reference ID.");}
        public bool BeingDestroyed {get=>owner.IsBeingDestroyed;set=>throw new InvalidOperationException("The control owns its lifetime.");}
        public void PrintDebugInfo(bool verbose=false){((IReferencable)owner).PrintDebugInfo(verbose);}
        public void OnAssignedReference(){}
    }
}
