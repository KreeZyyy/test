using Assets.Scripts.Inventory;using Assets.Scripts.Objects;using UnityEngine;
namespace ModularSwitchboards {
 // Created after the native cursor's text-removal pass, never on placed modules.
 public sealed class DinLogicPreviewMarks:MonoBehaviour {
  private Structure owner;private Font font;private readonly Material[] ink=new Material[3];private readonly TextMesh[] labels=new TextMesh[3];
  internal static void Ensure(Structure cursor){if(!(cursor is IDinLogic)||!cursor.IsCursor)return;var view=cursor.GetComponent<DinLogicPreviewMarks>()??cursor.gameObject.AddComponent<DinLogicPreviewMarks>();if(view.owner==null)view.Create(cursor);view.Refresh();}
  private void Create(Structure cursor){owner=cursor;font=SmartModuleFont.Get();if(font==null)return;var root=new GameObject("DinLogicPreviewPortMarks"){layer=cursor.gameObject.layer,tag=InventoryManager.HelperTag};root.transform.SetParent(cursor.transform,false);
   for(int pin=0;pin<3;pin++){var go=new GameObject("Preview"+DinLogicPreviewLabelLayout.Text(pin)){layer=root.layer};go.transform.SetParent(root.transform,false);go.transform.localPosition=DinLogicPreviewLabelLayout.Position(pin);go.transform.localRotation=Quaternion.Euler(0,180,0);var t=go.AddComponent<TextMesh>();labels[pin]=t;t.font=font;t.fontSize=64;t.fontStyle=FontStyle.Bold;t.characterSize=.004f;t.anchor=TextAnchor.MiddleCenter;t.alignment=TextAlignment.Center;t.richText=false;t.color=Color.white;t.text=DinLogicPreviewLabelLayout.Text(pin);font.RequestCharactersInTexture(t.text,64,FontStyle.Bold);DepthLabelText.Apply(t);
    ink[pin]=new Material(DepthLabelText.For(font)){name="Switchboards.Preview."+t.text,color=Color.green};ink[pin].EnableKeyword("_EMISSION");t.GetComponent<MeshRenderer>().sharedMaterial=ink[pin];var fit=go.AddComponent<DinLogicLabelFit>();fit.Width=DinLogicPreviewLabelLayout.Width;fit.Height=DinLogicPreviewLabelLayout.Height;fit.InkColor=Color.white;fit.Refresh();
   }
  }
  private void Refresh(){if(owner==null||!owner.IsCursor||font==null)return;var ports=((IDinLogic)owner).Logic.OpenEnds;for(int pin=0;pin<3&&pin<ports.Count;pin++){if(labels[pin]==null||ink[pin]==null)continue;var helper=ports[pin].HelperRenderer;var tint=helper!=null&&helper.sharedMaterial!=null?helper.sharedMaterial.color:Color.green;tint.a=1;ink[pin].mainTexture=font.material.mainTexture;ink[pin].color=tint;ink[pin].SetColor("_EmissionColor",tint*.65f);var r=labels[pin].GetComponent<MeshRenderer>();r.SetPropertyBlock(null);for(int i=0;i<r.sharedMaterials.Length;i++)r.SetPropertyBlock(null,i);r.sharedMaterial=ink[pin];r.forceRenderingOff=false;r.shadowCastingMode=UnityEngine.Rendering.ShadowCastingMode.Off;r.receiveShadows=false;}}
  private void LateUpdate()=>Refresh();
  private void OnDestroy(){foreach(var material in ink)if(material!=null)Destroy(material);}
 }
}
