using Assets.Scripts.Objects;using UnityEngine;using UnityEngine.Rendering;
namespace ModularSwitchboards {
 internal static class DinLogicPortHelpers {
  internal const float MaxSize=.018f;
  private static Mesh arrow;
  private static Mesh Arrow(){
   if(arrow!=null)return arrow;
   // Our own arrow, tip at the cable entry; no native pivot, bounds or size assumptions.
   arrow=new Mesh{name="Switchboards.DinLogic.PortArrow"};
   arrow.vertices=new[]{new Vector3(-.0015f,0,-MaxSize),new Vector3(.0015f,0,-MaxSize),new Vector3(.0015f,0,-MaxSize*.5f),new Vector3(.006f,0,-MaxSize*.5f),Vector3.zero,new Vector3(-.006f,0,-MaxSize*.5f),new Vector3(-.0015f,0,-MaxSize*.5f)};
   arrow.triangles=new[]{0,1,2,0,2,6,6,2,4,2,3,4,6,4,5,2,1,0,6,2,0,4,2,6,4,3,2,5,4,6};arrow.RecalculateNormals();arrow.RecalculateBounds();return arrow;
  }
  internal static void Fit(Structure cursor){
   if(!(cursor is IDinLogic)||!cursor.IsCursor)return;
   foreach(var port in ((IDinLogic)cursor).Logic.OpenEnds){var r=port.HelperRenderer;if(r==null||port.Transform==null)continue;
    foreach(var child in r.GetComponentsInChildren<Renderer>(true))if(child!=r)child.forceRenderingOff=true;
    var f=r.GetComponent<MeshFilter>();if(f==null){r.forceRenderingOff=true;continue;}f.sharedMesh=Arrow();
    r.transform.SetPositionAndRotation(port.Transform.position,port.Transform.rotation);
    r.transform.localScale=Vector3.one;var s=r.transform.lossyScale;
    r.transform.localScale=new Vector3(1/Mathf.Max(Mathf.Abs(s.x),.000001f),1/Mathf.Max(Mathf.Abs(s.y),.000001f),1/Mathf.Max(Mathf.Abs(s.z),.000001f));
    r.shadowCastingMode=ShadowCastingMode.Off;r.receiveShadows=false;
   }
   DinLogicPreviewMarks.Ensure(cursor);
  }
 }
}
