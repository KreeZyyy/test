using UnityEngine;
namespace ModularSwitchboards {
 internal static class DinLogicPreviewLabelLayout {
  internal const float Width=.028f,Height=.0055f;
  internal static string Text(int pin)=>pin==0?"IN":pin==1?"OUT":"POWER";
  internal static Vector3 Position(int pin)=>new Vector3(DinLogicTerminalLayout.Entry(pin).x,pin==2?.077f:-.077f,.086f);
 }
}
