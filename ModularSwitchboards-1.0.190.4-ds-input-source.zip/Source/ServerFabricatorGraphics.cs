using Assets.Scripts.Objects.Electrical;
using HarmonyLib;
namespace ModularSwitchboards
{
    // SetIcon only updates the world-space renderer/texture. The dedicated server
    // intentionally has no custom thumbnails. Recipe selection and manufacturing
    // remain in the original methods, outside this visual callback.
    internal static class ServerFabricatorGraphics
    {
        internal static void Configure(Harmony harmony)
        {
            harmony.Patch(AccessTools.Method(typeof(SimpleFabricatorBase),"SetIcon"),prefix:new HarmonyMethod(typeof(ServerFabricatorGraphics),nameof(BeforeSetIcon)));
        }
        internal static bool BeforeSetIcon()=>!ServerGraphics.Headless;
    }
}
